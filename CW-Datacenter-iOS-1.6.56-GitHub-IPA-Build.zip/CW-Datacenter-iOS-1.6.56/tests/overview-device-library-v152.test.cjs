const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'CWDatacenter/Resources/Web/app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'CWDatacenter/Resources/Web/index.html'), 'utf8');
const plist = fs.readFileSync(path.join(root, 'CWDatacenter/Info.plist'), 'utf8');

assert(html.includes('id="overviewGalleryDeviceSwitch"'));
assert(html.includes('id="overviewGalleryDeviceName"'));
assert(app.includes('discoverOverviewGalleryDeviceFolders'));
assert(app.includes('overviewGalleryFolderHasMediaParts'));
assert(app.includes('overviewGalleryPartKind(entry.name) === kind'));
assert(app.includes('overviewPathIsConfiguredProtected(deviceName, poolId)'));
assert(app.includes("'iosOverviewGallery:v2:'"));
assert(app.includes("encodeURIComponent(cameraPoolCache || 'pool_camera')"));
assert(app.includes('const deviceRoot = ensureOverviewGalleryDeviceFolder();'));
assert(app.includes('function overviewGalleryOwnDeviceFolder() { return iosCameraFolderName(); }'));
assert(app.includes("customDeviceName: iosCameraFolderName()"), 'Upload destination must still use the current iOS device name');
assert(plist.includes('<string>1.6.56</string>'));
assert(plist.includes('<string>10656</string>'));

console.log('PASS iOS 1.6.56 per-device Overview library selector');
