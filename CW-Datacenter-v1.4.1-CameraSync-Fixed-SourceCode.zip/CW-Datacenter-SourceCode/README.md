# CW Datacenter — MVP

## Bản sửa 1.4.1 — đồng bộ Camera iOS

- Ảnh/video từ Photo Library được upload theo khối 4 MB và tự tiếp tục đúng offset khi mạng gián đoạn.
- Bỏ giới hạn 120 giây cho toàn bộ file; video lớn chỉ áp dụng timeout riêng cho từng request.
- Tải tài nguyên iCloud tối đa 30 phút thay vì bỏ qua sau 60 giây.
- Nếu host lỗi sau 3 lần thử, tác vụ tạm dừng tại file hiện tại và hiển thị lỗi thật; lần chạy sau resume thay vì bỏ qua hàng loạt file.
- Sửa thứ tự khởi tạo cache ổ đĩa khiến `server.js` có thể lỗi khi chạy trực tiếp bằng Node.js.

Biến máy tính của bạn thành máy chủ lưu trữ file cho cả mạng LAN. Giao diện theo phong cách **CW Datacenter** (light theme, desktop-style layout).

## Cấu trúc
```
server/       Server chia sẻ file (Node.js, zero-dependency)
desktop/      Desktop client (Electron) — kết nối tới server
desktop-host/ Host app (Electron) — 1 cú click bật server + console
shared/       (không còn) — folder shared được tạo tự động, xem bên dưới
.tools/node   Node.js portable (không cần cài đặt hệ thống)
```

### Thư mục shared (không còn thư mục mặc định trong project)
Server không tạo/sử dụng thư mục `shared` trong thư mục dự án nữa. Khi chưa cấu hình, folder shared
mặc định là `<ổ đĩa mặc định của máy host>\shared` (chọn ổ đầu tiên có thể ghi).
Ở app client (tab **Cài đặt → Đồng bộ với máy chủ**), client chọn **2 nơi**:
1. Ổ/thư mục trên máy client làm nguồn đồng bộ
2. Ổ trên máy host — server sẽ tự tạo `shared` ngay trên ổ đó (ví dụ chọn D: → `D:\shared`)
làm nơi nhận file, sau đó mới bắt đầu đẩy file lên.

## Ứng dụng PC (.exe, portable — chạy luôn không cần cài)
- **HOST**: `desktop-host/dist/CW-Datacenter-Host-1.0.0-portable.exe` — mở là tự bật server, hiện log live, nút mở Host Console / Client Web / thư mục chia sẻ. Đóng cửa sổ = tắt server.
- **CLIENT**: `desktop/dist/CW-Datacenter-1.0.0-portable.exe` — nhập địa chỉ server → Connect.

Trình tự dùng: mở **CW-Datacenter-Host** trước, rồi mở **CW-Datacenter** (client) trên cùng máy hoặc máy khác trong LAN.

Build lại exe (khi sửa code): `cd desktop-host && npm run dist` hoặc `cd desktop && npm run dist` (cần Node.js).

## Cách chạy (không dùng exe)

### 1. Máy HOST
1. Mở `start-host.bat` (chọn "Allow" nếu Windows Firewall hỏi)
2. Màn hình console hiện **mật khẩu**, địa chỉ IP LAN và các URL
3. Mở **Host Console**: `http://localhost:8080/host.html`

### 2. Máy khác (client) — 2 cách
**Web:** mở trình duyệt → `http://<IP-host>:8080` → nhập mật khẩu

**Desktop:** chạy `start-desktop.bat` → nhập `http://<IP-host>:8080` → Connect
(Lần đầu sẽ tự cài Electron qua npm, cần mạng ~2 phút)

## Hai giao diện chính

### Client (trang chủ `/`)
- Titlebar + sidebar (Files, Recent, Trash, Transfers) đúng mockup CW Datacenter
- Toolbar: Search (Ctrl+F), Upload, New Folder, Download, Share Link, Refresh
- Breadcrumb điều hướng, bảng file với icon theo loại tệp
- Detail panel bên phải: preview ảnh/media, thông tin file, nút Open/Download/Rename/Delete
- Transfer panel cuối màn hình + trang Transfers đầy đủ: progress bar, tốc độ, ETA
- Kéo-thả file **hoặc thư mục** vào bảng để upload (giữ nguyên cấu trúc thư mục con)
- Bôi đen nhiều file → chuột phải: Tải về hết, Khóa hết, Thêm yêu thích hết, Chia sẻ link (mỗi file 1 link)

### Host Console (`/host.html`)
- Dashboard 4 thẻ: Storage Usage (máy thật), Network Activity (sparkline live), Connected Devices, Active Transfers
- Storage Pools + bảng thiết bị đã kết nối + Active Share Links
- Recent Activity (activity log thực: upload/download/edit/delete/login)
- System Health: donut CPU/RAM thật + uptime hệ thống
- Tab Logs, tab Shared Links (xem/revoke), tab Files, và nút **Connect Phone** (QR)

## Tính năng kỹ thuật

### Transfer (Giai đoạn 1)
- **Chunked upload 4MB** + resume: rớt mạng giữa chừng, upload lại sẽ tiếp nối từ offset (không tải lại từ đầu)
- **Download resume** qua HTTP Range, tự retry với exponential backoff khi mạng yếu
- Nút cancel trên mỗi transfer, hiện tốc độ + thời gian còn lại
- File > 512MB tải về dùng cơ chế stream của trình duyệt

### Share links
- Tạo link chia sẻ không cần mật khẩu: chọn thời hạn (1h → 30 ngày), hoặc "chỉ dùng 1 lần"
- Thư mục share tải về dạng ZIP (tự nén streaming)
- Trang công khai `/s/?id=...` cho người nhận, host console quản lý + revoke

### Mạng LAN / Tailscale
- Client tự detect kết nối LAN hay Tailscale (IP 100.64-127.x) + đo latency, hiển thị chip trên titlebar
- Host console hiện trạng thái Tailscale (ON/OFF, IP tailnet), phân biệt thiết bị kết nối qua LAN/Tailscale
- Banner mất kết nối + tự động reconnect mỗi 4s

### Nền tảng
- Đăng nhập bằng mật khẩu (token 7 ngày), khoá 30s sau 10 lần nhập sai
- Chống path traversal, giới hạn sửa file text 5MB
- Activity log 100 event, theo dõi thiết bị theo token
- CSP header trên toàn bộ pages
- Chunk upload dở dang tự dọn sau 24h (lưu trong `<root>/.cw-uploads`, ẩn khỏi danh sách file)

### UX Client (Giai đoạn 2)
- **Undo xoá**: xoá chuyển vào Thùng rác, hiện toast kèm nút Undo (giữ 30 ngày)
- **Phím tắt**: Ctrl+F tìm, Ctrl+U upload, Ctrl+R làm mới, Enter mở, F2 đổi tên, Del xoá, Backspace lên thư mục cha, Esc thoát tìm
- **Recent**: danh sách file vừa upload/tải/sửa, bấm là mở
- **Trash**: xem, khôi phục, xoá vĩnh viễn, hoặc dọn sạch thùng
- **Kết nối điện thoại bằng QR**: host console → Connect Phone → quét QR (đăng nhập tự động, code mời hết hạn sau 15 phút, ưu tiên IP LAN)
- Responsive: trên điện thoại tap 1 lần để mở file, ẩn hint phím
- Skeleton loading, banner mất kết nối + auto-reconnect

- Library note: QR encoder dùng `qrcode` 1.5.4 (MIT) đã được bundle tại `server/public/qr.js`.

### Settings UI + User quản lý (Giai đoạn 3)
- **3 cấp tài khoản**: admin (mật khẩu máy chủ, toàn quyền) · editor (upload/sửa/xoá) · viewer (chỉ xem/tải về)
- **Login client hỗ trợ username + mật khẩu** (bỏ trống username = đăng nhập admin bằng mật khẩu máy chủ)
- **Host Console → tab Users**: thêm/sửa/xoá tài khoản, đổi quyền, reset mật khẩu, ký-out mọi thiết bị của 1 user, xem số phiên đang online
- **Host Console → tab Settings**: đổi cổng (server tự chuyển cổng live, không cần restart), đổi mật khẩu admin (bắt buộc nhập mật khẩu hiện tại), đổi thư mục chia sẻ, chọn quyền mặc định cho QR invite (editor/viewer)
- Đổi quyền có hiệu lực **ngay lập tức** với phiên đang đăng nhập; xoá user tự huỷ toàn bộ token của user đó
- Viewer bị chặn toàn bộ thao tác ghi cả ở UI (ẩn nút, chặn phím tắt/kéo-thả/menu chuột phải) lẫn API (403)
- User tự đổi mật khẩu của mình qua Settings → "Change my password"
- Lưu ý: sau khi đổi cổng, browser cũ cần mở lại địa chỉ với cổng mới

### Đổi tài khoản + chọn ổ lưu trữ (Giai đoạn 4)
- **Host app (Electron) → nút "🔑 Đổi tài khoản & mật khẩu…"**: đổi cả tên đăng nhập admin lẫn mật khẩu server ngay trong cửa sổ host (yêu cầu mật khẩu hiện tại; tên mới 2-32 ký tự, không trùng user thường; các phiên đang đăng nhập không bị văng ra)
- **Host app → nút "⛃ Ổ lưu trữ…"**: modal liệt kê ổ mặc định (shared folder) + mọi ổ phát hiện được trên máy (C:, D:, USB cắm thêm…). Cắm ổ mới → bảng tự quét lại mỗi 5 giây. Tích chọn ổ để chia sẻ, chọn radio "Mặc định" để đặt ổ nhận file khi client không chọn
- **Host Console → tab Storage Drives**: cùng tính năng trên web (tab này trước đây chưa hoàn thiện, giờ đã dùng được); Settings thêm trường *Admin username*
- **Client (web + desktop)**: khi host bật từ 2 ổ trở lên, toolbar hiện **dropdown chọn ổ** (kèm dung lượng trống; ổ bị rút khỏi máy hiện "offline"). Mọi thao tác — duyệt file, upload/kéo-thả, New Folder, edit text, rename, delete, share link, download — thực hiện trên ổ đang chọn; Recent nhảy đúng ổ của file
- Mỗi ổ có riêng `.cw-uploads` (temp) và `.cw-trash`; bỏ chọn ổ chỉ ngừng chia sẻ, dữ liệu trên ổ giữ nguyên
- API mới/đổi: `GET /api/drives`, `POST /api/pools/config` (admin), `GET /api/pools` (có cờ `online`), `POST /api/settings` nhận thêm `adminUser`

## Dùng qua Tailscale (ra ngoài)
1. Cài [Tailscale](https://tailscale.com) trên cả máy host và máy từ xa, đăng nhập cùng tài khoản
2. Console host khi khởi động sẽ in `Remote client: http://100.x.x.x:8080`
3. Từ xa mở địa chỉ `100.x.x.x` đó (client tự nhận diện "Tailscale" + upload resume nếu mạng rớt)

## Cấu hình
Sửa `server/config.json`:
- `port`: cổng (mặc định 8080)
- `password`: mật khẩu đăng nhập
- `adminUser`: tên đăng nhập admin (mặc định `admin`; đổi qua nút "Đổi tài khoản & mật khẩu" ở host app)
- `root`: thư mục chia sẻ
- `pools`: danh sách ổ lưu trữ bổ sung đang bật (quản lý qua UI "Ổ lưu trữ", hạn chế sửa tay)
