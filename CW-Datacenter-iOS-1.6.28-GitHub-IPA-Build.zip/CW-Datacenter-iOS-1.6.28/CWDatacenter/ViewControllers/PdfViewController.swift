﻿import UIKit
import PDFKit
import WebKit

class PdfViewController: UIViewController, WKNavigationDelegate {

    private let urlString: String
    private let titleText: String
    private let directWeb: Bool

    private var pdfView: PDFView!
    private var activityIndicator: UIActivityIndicatorView!
    private var pageLabel: UILabel!
    private var localPdfUrl: URL?
    private var webView: WKWebView?

    init(url: String, titleText: String, directWeb: Bool = false) {
        self.urlString = url
        self.titleText = titleText
        self.directWeb = directWeb
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = titleText
        view.backgroundColor = .systemBackground

        if directWeb {
            navigationController?.setNavigationBarHidden(true, animated: false)
            setupActivityIndicator()
            loadDirectWeb()
            return
        }

        setupNavBar()
        setupPDFView()
        setupActivityIndicator()
        loadPDF()
    }

    private func setupNavBar() {
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Đóng", style: .plain, target: self, action: #selector(onCloseTapped))
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .action, target: self, action: #selector(onShareTapped))
    }

    private func setupPDFView() {
        pdfView = PDFView(frame: view.bounds)
        pdfView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        pdfView.autoScales = true
        pdfView.displayMode = .singlePageContinuous
        pdfView.displayDirection = .vertical
        view.addSubview(pdfView)

        NotificationCenter.default.addObserver(self, selector: #selector(onPageChanged), name: .PDFViewPageChanged, object: pdfView)

        pageLabel = UILabel()
        pageLabel.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        pageLabel.textColor = .white
        pageLabel.font = UIFont.systemFont(ofSize: 12.5, weight: .semibold)
        pageLabel.textAlignment = .center
        pageLabel.layer.cornerRadius = 12
        pageLabel.layer.masksToBounds = true
        pageLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(pageLabel)

        NSLayoutConstraint.activate([
            pageLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            pageLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16),
            pageLabel.heightAnchor.constraint(equalToConstant: 26),
            pageLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 90)
        ])
    }

    private func setupActivityIndicator() {
        activityIndicator = UIActivityIndicatorView(style: .large)
        activityIndicator.center = view.center
        activityIndicator.hidesWhenStopped = true
        view.addSubview(activityIndicator)
    }

    private func loadPDF() {
        guard let url = URL(string: urlString) else { return }
        activityIndicator.startAnimating()

        if url.isFileURL {
            if let doc = PDFDocument(url: url) {
                pdfView.document = doc
                localPdfUrl = url
                updatePageCount()
            }
            activityIndicator.stopAnimating()
            return
        }

        openRemoteStream(url)
    }

    private func openRemoteStream(_ fileUrl: URL) {
        guard var origin = URLComponents(url: fileUrl, resolvingAgainstBaseURL: false) else {
            activityIndicator.stopAnimating()
            return
        }
        origin.path = "/pdf-stream.html"
        origin.query = nil
        origin.fragment = nil
        var queryItems = [
            URLQueryItem(name: "file", value: fileUrl.absoluteString),
            URLQueryItem(name: "title", value: titleText)
        ]
        if let fileToken = URLComponents(url: fileUrl, resolvingAgainstBaseURL: false)?.queryItems?.first(where: { $0.name == "token" })?.value,
           !fileToken.isEmpty {
            queryItems.append(URLQueryItem(name: "token", value: fileToken))
        } else if !LocalProxy.shared.token.isEmpty {
            queryItems.append(URLQueryItem(name: "token", value: LocalProxy.shared.token))
        }
        origin.queryItems = queryItems
        guard let viewerUrl = origin.url else {
            activityIndicator.stopAnimating()
            return
        }
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .nonPersistent()
        let streamView = WKWebView(frame: view.bounds, configuration: configuration)
        streamView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        streamView.scrollView.contentInsetAdjustmentBehavior = .never
        pdfView.isHidden = true
        pageLabel.isHidden = true
        view.insertSubview(streamView, belowSubview: activityIndicator)
        webView = streamView
        streamView.load(URLRequest(url: viewerUrl, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 60))
        activityIndicator.stopAnimating()
    }

    private func loadDirectWeb() {
        guard let url = URL(string: urlString) else { return }
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        let readerView = WKWebView(frame: view.bounds, configuration: configuration)
        readerView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        readerView.scrollView.contentInsetAdjustmentBehavior = .never
        readerView.navigationDelegate = self
        view.insertSubview(readerView, at: 0)
        webView = readerView
        readerView.load(URLRequest(url: url, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 60))
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if navigationAction.request.url?.scheme == "cw" {
            decisionHandler(.cancel)
            dismiss(animated: true)
            return
        }
        decisionHandler(.allow)
    }

    @objc private func onPageChanged() {
        updatePageCount()
    }

    private func updatePageCount() {
        guard let doc = pdfView.document, let cur = pdfView.currentPage else {
            pageLabel.isHidden = true
            return
        }
        pageLabel.isHidden = false
        let curIdx = doc.index(for: cur) + 1
        let total = doc.pageCount
        pageLabel.text = " Trang \(curIdx) / \(total) "
    }

    @objc private func onShareTapped() {
        if let url = localPdfUrl {
            present(UIActivityViewController(activityItems: [url], applicationActivities: nil), animated: true)
            return
        }
        guard let remoteUrl = URL(string: urlString) else { return }
        navigationItem.rightBarButtonItem?.isEnabled = false
        var request = URLRequest(url: remoteUrl)
        if !LocalProxy.shared.token.isEmpty { request.setValue("Bearer " + LocalProxy.shared.token, forHTTPHeaderField: "Authorization") }
        URLSession.shared.downloadTask(with: request) { [weak self] temporaryUrl, _, _ in
            guard let self = self, let temporaryUrl = temporaryUrl else {
                DispatchQueue.main.async { self?.navigationItem.rightBarButtonItem?.isEnabled = true }
                return
            }
            let destination = FileManager.default.temporaryDirectory.appendingPathComponent(self.titleText.isEmpty ? "document.pdf" : self.titleText)
            try? FileManager.default.removeItem(at: destination)
            try? FileManager.default.copyItem(at: temporaryUrl, to: destination)
            DispatchQueue.main.async {
                self.navigationItem.rightBarButtonItem?.isEnabled = true
                self.localPdfUrl = destination
                self.present(UIActivityViewController(activityItems: [destination], applicationActivities: nil), animated: true)
            }
        }.resume()
    }

    @objc private func onCloseTapped() {
        webView?.stopLoading()
        dismiss(animated: true)
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
        webView?.stopLoading()
    }
}
