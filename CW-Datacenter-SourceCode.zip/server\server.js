'use strict';
const http = require('http');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const dgram = require('dgram');
const { execFile } = require('child_process');

const CONFIG_PATH = path.join(__dirname, 'config.json');
const SHARES_PATH = path.join(__dirname, 'shares.json');
const LOCKS_PATH = path.join(__dirname, 'locks.json');
const USERS_PATH = path.join(__dirname, 'users.json');
const RECENT_PATH = path.join(__dirname, 'recent.json');
const PUBLIC_DIR = path.join(__dirname, 'public');
const UPLOADS_DIRNAME = '.cw-uploads';
const TRASH_DIRNAME = '.cw-trash';
const TRASH_TTL = 30 * 24 * 60 * 60 * 1000;
const TOKEN_TTL = 7 * 24 * 60 * 60 * 1000;
const TEXT_SAVE_LIMIT = 5 * 1024 * 1024;
const JSON_BODY_LIMIT = 10 * 1024 * 1024;
const PART_TTL = 24 * 60 * 60 * 1000;
const THUMB_DIR = path.join(__dirname, '.cw-thumbs');

/* Không còn thư mục shared mặc định trong thư mục dự án.
   Nếu chưa cấu hình root → dùng thư mục "shared" trong thư mục người dùng của máy host.
   Khi client chọn ổ đồng bộ → root sẽ chuyển sang <ổ>\shared (xem /api/sync/activate). */
function defaultSharedRoot() {
  return path.join(os.homedir(), 'cw-datacenter', 'shared');
}

function loadConfig() {
  let cfg = null;
  let created = false;
  if (fs.existsSync(CONFIG_PATH)) {
    try { cfg = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8')); } catch { cfg = null; }
  }
  if (!cfg) {
    cfg = { port: 8080, adminUser: 'admin', password: 'admin', root: defaultSharedRoot() };
    created = true;
  }
  if (typeof cfg.port !== 'number') { cfg.port = 8080; created = true; }
  if (typeof cfg.password !== 'string' || !cfg.password) { cfg.password = 'admin'; created = true; }
  if (typeof cfg.adminUser !== 'string' || !cfg.adminUser) { cfg.adminUser = 'admin'; created = true; }
  if (typeof cfg.root !== 'string' || !cfg.root) { cfg.root = defaultSharedRoot(); created = true; }
  if (path.resolve(cfg.root).toLowerCase() === path.join(__dirname, '..', 'shared').toLowerCase()) {
    cfg.root = defaultSharedRoot();
    created = true;
  }
  if (!fs.existsSync(cfg.root)) {
    let ok = false;
    try { fs.mkdirSync(cfg.root, { recursive: true }); ok = fs.existsSync(cfg.root); } catch { ok = false; }
    if (!ok) {
      cfg.root = defaultSharedRoot();
      try { fs.mkdirSync(cfg.root, { recursive: true }); } catch {}
      created = true;
    }
  }
  if (cfg.syncEnabled == null) { cfg.syncEnabled = true; created = true; }
  if (created) fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2));
  return cfg;
}

const config = loadConfig();
function saveConfig() {
  try { fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2)); } catch {}
}

/* ---------- Storage pools (multi-drive) ---------- */
function normalizePools() {
  const mainAbs = path.resolve(config.root || 'D:\\DONG BO');
  if (!Array.isArray(config.pools)) config.pools = [];
  config.pools = config.pools.filter((p) => p && typeof p.path === 'string');
  config.pools = config.pools.filter((p) => p.id === 'main' || (fs.existsSync(p.path) && fs.statSync(p.path).isDirectory()));
  let main = config.pools.find((p) => p.id === 'main');
  if (!main) {
    main = { id: 'main', name: nameForPath(mainAbs), path: mainAbs };
    config.pools.unshift(main);
  }
  main.path = mainAbs;
  if (!main.name) main.name = nameForPath(mainAbs);

  // Auto-register Camera Pool (E:\) in pools list
  const camPath = config.cameraPool ? path.resolve(String(config.cameraPool)) : (fs.existsSync('E:\\') ? path.resolve('E:\\') : null);
  if (camPath && fs.existsSync(camPath)) {
    let camP = config.pools.find((p) => path.resolve(p.path).toLowerCase() === camPath.toLowerCase());
    if (!camP) {
      camP = { id: 'pool_camera', name: nameForPath(camPath), path: camPath, default: false };
      config.pools.push(camP);
    }
  }

  const seen = new Set();
  const prevDefaultId = (() => {
    const d = config.pools.find((p) => p.default && p.id !== 'main');
    return d ? d.id : null;
  })();
  config.pools = config.pools.filter((p) => {
    p.default = p.id === 'main';
    p.path = path.resolve(p.path);
    const key = p.path.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
  if (prevDefaultId && config.pools.some((p) => p.id === prevDefaultId)) {
    for (const p of config.pools) p.default = p.id === prevDefaultId;
  }
}
normalizePools();

function defaultPool() { return config.pools.find((p) => p.default) || config.pools[0]; }
function cameraPool() {
  if (config.cameraPool) {
    const p = getPool(config.cameraPool) || config.pools.find((x) => x.path.toLowerCase().startsWith(String(config.cameraPool).toLowerCase()));
    if (p) return p;
    if (typeof config.cameraPool === 'string' && fs.existsSync(config.cameraPool)) {
      return { id: 'camera_custom', name: nameForPath(config.cameraPool), path: path.resolve(config.cameraPool) };
    }
  }
  const ePool = config.pools.find((p) => /^[eE]:/i.test(p.path));
  if (ePool) return ePool;
  if (process.platform === 'win32') {
    try {
      if (fs.existsSync('E:\\') && fs.statSync('E:\\').isDirectory()) {
        let e = config.pools.find((p) => path.resolve(p.path).toLowerCase().startsWith('e:'));
        if (!e) {
          e = { id: 'pool_e', name: nameForPath('E:\\'), path: path.resolve('E:\\') };
          config.pools.push(e);
          try { fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2)); } catch {}
        }
        return e;
      }
    } catch {}
  }
  return defaultPool();
}
function getPool(id) {
  if (!id) return defaultPool();
  return config.pools.find((p) => p.id === String(id)) || null;
}
function poolRoot(pool) { return path.resolve((pool || defaultPool()).path); }
function upDirOfAbs(abs) { return path.join(path.resolve(String(abs)), UPLOADS_DIRNAME); }
function trashDirOfAbs(abs) { return path.join(path.resolve(String(abs)), TRASH_DIRNAME); }
function uploadsDirOf(poolId, req) {
  if (req != null) {
    const pool = poolCtx(req, poolId);
    if (pool) return upDirOfAbs(path.resolve(pool.path));
  }
  const abs = poolPathById(poolId);
  if (abs) return upDirOfAbs(abs);
  return path.join(poolRoot(getPool(poolId)), UPLOADS_DIRNAME);
}
function trashDirOf(poolId, req) {
  if (req != null) {
    const pool = poolCtx(req, poolId);
    if (pool) return trashDirOfAbs(path.resolve(pool.path));
  }
  const abs = poolPathById(poolId);
  if (abs) return trashDirOfAbs(abs);
  return path.join(poolRoot(getPool(poolId)), TRASH_DIRNAME);
}
function trashDirsForUser(req) {
  const name = req ? currentUserOf(req) : null;
  if (name && name !== 'admin') {
    const u = userObjOf(name);
    if (u) {
      const roots = scopeRootsOf(u);
      if (roots !== '*') {
        const set = new Set();
        for (const r of roots) set.add(trashDirOfAbs(path.resolve(poolOfAbs(r).path)));
        return [...set];
      }
    }
  }
  return config.pools.map((p) => trashDirOfAbs(path.resolve(p.path)));
}
function ensurePoolDirs(pool) {
  try {
    fs.mkdirSync(uploadsDirOf(pool.id), { recursive: true });
    fs.mkdirSync(trashDirOf(pool.id), { recursive: true });
  } catch {}
}
function ensureDirs() {
  for (const p of config.pools) ensurePoolDirs(p);
}
ensureDirs();
let uploadsDir = uploadsDirOf(defaultPool().id);
let trashDir = trashDirOf(defaultPool().id);

function poolOfAbs(abs) {
  let best = null;
  for (const p of config.pools) {
    if (!isWithin(abs, poolRoot(p))) continue;
    if (!best || poolRoot(p).length > poolRoot(best).length) best = p;
  }
  return best || defaultPool();
}
function poolOfAbsForUser(abs, req) {
  if (!req) return poolOfAbs(abs);
  const name = currentUserOf(req);
  if (!name || name === 'admin') return poolOfAbs(abs);
  let best = null;
  let bestLen = -1;
  for (const p of userPools(req)) {
    const r = path.resolve(p.path);
    if (!isWithin(abs, r)) continue;
    if (r.length > bestLen) { best = p; bestLen = r.length; }
  }
  return best || poolOfAbs(abs);
}
function poolIdParam(req, url, body) {
  return (url && url.searchParams.get('pool')) || (body && body.pool) || '';
}

/* ---------- Volume labels (tên ổ, ví dụ D: -> DATA) ---------- */
let volLabelCache = { at: 0, map: {} };
function volumeLabels() {
  const now = Date.now();
  if (volLabelCache.map && now - volLabelCache.at < 20000) return volLabelCache.map;
  const map = {};
  if (process.platform === 'win32') {
    try {
      const { execSync } = require('child_process');
      const cmd = 'powershell -NoProfile -Command "Get-Volume | Where-Object { $_.DriveLetter } | ForEach-Object { [string]$_.DriveLetter + \'|\' + [string]$_.FileSystemLabel }"';
      const out = execSync(cmd, { timeout: 5000, windowsHide: true }).toString();
      for (const line of out.split(/\r?\n/)) {
        const m = /^([A-Za-z])\|(.*)$/.exec(line.trim());
        if (m) map[m[1].toUpperCase()] = m[2].trim();
      }
    } catch {}
  }
  volLabelCache = { at: now, map };
  return map;
}
function driveDisplayName(letter) {
  const label = volumeLabels()[String(letter).toUpperCase()] || '';
  return label ? letter + ' (' + label + ')' : letter;
}

/* List physical drives / roots (Windows drive letters, or Unix mounts) */
function listAvailableDrives() {
  const out = [];
  const used = new Set(config.pools.map((p) => poolRoot(p).toLowerCase()));
  if (process.platform === 'win32') {
    const labels = volumeLabels();
    for (let c = 65; c <= 90; c++) {
      const letter = String.fromCharCode(c).toUpperCase();
      const drive = letter + ':\\';
      try {
        const st = fs.statSync(drive);
        if (!st.isDirectory()) continue;
        const label = labels[letter] || '';
        const info = { path: drive, name: letter + ':', label, displayName: label ? letter + ': ' + label : letter + ':', total: 0, free: 0, isPool: used.has(drive.toLowerCase()) };
        const pool = config.pools.find((p) => poolRoot(p).toLowerCase() === drive.toLowerCase());
        info.poolId = pool ? pool.id : null;
        out.push(info);
      } catch {}
    }
  } else {
    try {
      const mounts = fs.readFileSync('/proc/mounts', 'utf8').split('\n');
      const seen = new Set();
      for (const line of mounts) {
        const parts = line.split(/\s+/);
        const mp = parts[1];
        if (!mp || !mp.startsWith('/') || seen.has(mp)) continue;
        seen.add(mp);
        out.push({ path: mp, name: mp, isPool: used.has(mp.toLowerCase()) });
      }
    } catch {}
  }
  return out;
}
async function driveStats(items) {
  for (const d of items) {
    try {
      const st = await fsp.statfs(d.path);
      d.total = st.blocks * st.bsize;
      d.free = st.bavail * st.bsize;
    } catch {}
  }
  return items;
}

/* ---------- Users (roles: viewer / editor) ---------- */
let users = [];
function loadUsers() {
  try { users = fs.existsSync(USERS_PATH) ? JSON.parse(fs.readFileSync(USERS_PATH, 'utf8')) : []; }
  catch { users = []; }
}
function saveUsers() {
  try { fs.writeFileSync(USERS_PATH, JSON.stringify(users, null, 2)); } catch {}
}
loadUsers();

function hashPassword(pw, salt) {
  return crypto.scryptSync(String(pw), salt, 32).toString('hex');
}
function verifyUser(name, pw) {
  const u = users.find((x) => x.name.toLowerCase() === String(name || '').toLowerCase());
  if (!u) return null;
  let ok = false;
  try {
    ok = crypto.timingSafeEqual(Buffer.from(hashPassword(pw, u.salt), 'hex'), Buffer.from(u.hash, 'hex'));
  } catch { ok = false; }
  return ok ? u : null;
}
function isValidName(n) { return /^[\w][\w .-]{1,31}$/i.test(String(n || '')); }

/* Admin account name (config.adminUser, mặc định "admin") — mật khẩu là config.password */
function adminName() {
  const n = String(config.adminUser || '').trim();
  return isValidName(n) ? n : 'admin';
}

const TOKENS_PATH = path.join(__dirname, 'tokens.json');
const tokens = new Map();
function loadTokens() {
  try {
    if (fs.existsSync(TOKENS_PATH)) {
      const arr = JSON.parse(fs.readFileSync(TOKENS_PATH, 'utf8'));
      if (Array.isArray(arr)) {
        for (const [k, v] of arr) {
          if (v && v.expires > Date.now()) tokens.set(k, v);
        }
      }
    }
  } catch {}
}
function saveTokens() {
  try {
    const arr = Array.from(tokens.entries()).filter(([k, v]) => v && v.expires > Date.now());
    fs.writeFileSync(TOKENS_PATH, JSON.stringify(arr, null, 2));
  } catch {}
}
loadTokens();

const devices = new Map();
const activity = [];
const transfers = new Map();
const partUploads = new Map();
let loginFails = 0;
let lockUntil = 0;
const invite = { code: crypto.randomBytes(4).toString('hex'), created: Date.now(), ttl: 15 * 60 * 1000 };

/* ---------- Recent (persisted) ---------- */
let recent = [];
try { recent = fs.existsSync(RECENT_PATH) ? JSON.parse(fs.readFileSync(RECENT_PATH, 'utf8')) : []; } catch { recent = []; }
function saveRecent() {
  try { fs.writeFileSync(RECENT_PATH, JSON.stringify(recent.slice(0, 50), null, 2)); } catch {}
}
function logRecent(action, relPath, req, poolId) {
  recent.unshift({ time: new Date().toISOString(), action, path: relPath, pool: poolId || 'main', ip: req ? clientIp(req) : 'host' });
  if (recent.length > 50) recent = recent.slice(0, 50);
  saveRecent();
}

/* ---------- Shared links (persisted) ---------- */
let shares = [];
function loadShares() {
  try { shares = fs.existsSync(SHARES_PATH) ? JSON.parse(fs.readFileSync(SHARES_PATH, 'utf8')) : []; }
  catch { shares = []; }
}
function saveShares() {
  try { fs.writeFileSync(SHARES_PATH, JSON.stringify(shares, null, 2)); } catch {}
}
loadShares();

/* ---------- Locks (persisted, synchronized across host/client/android) ---------- */
let locks = [];
function loadLocks() {
  try { locks = fs.existsSync(LOCKS_PATH) ? JSON.parse(fs.readFileSync(LOCKS_PATH, 'utf8')) : []; }
  catch { locks = []; }
}
function saveLocks() {
  try { fs.writeFileSync(LOCKS_PATH, JSON.stringify(locks, null, 2)); } catch {}
}
loadLocks();

/* ---------- Safe directory & move helpers (fixes EPERM on Windows root drives & EXDEV) ---------- */
function isDriveRoot(p) {
  const resolved = path.resolve(String(p || ''));
  if (/^[A-Za-z]:[\\/]*$/.test(resolved)) return true;
  if (resolved === '/' || resolved === '\\' || resolved === path.dirname(resolved)) return true;
  return false;
}

async function ensureDir(dir) {
  if (!dir) return;
  const resolved = path.resolve(String(dir));
  if (isDriveRoot(resolved)) return;
  try {
    if (fs.existsSync(resolved)) return;
    await fsp.mkdir(resolved, { recursive: true });
  } catch (e) {
    if (e.code !== 'EEXIST' && e.code !== 'EPERM') throw e;
  }
}

async function safeMoveFile(src, dst) {
  await ensureDir(path.dirname(dst));
  try {
    await fsp.rename(src, dst);
  } catch (err) {
    if (err.code === 'EXDEV' || err.code === 'EPERM' || err.code === 'EBUSY') {
      await fsp.copyFile(src, dst);
      await fsp.unlink(src).catch(() => {});
    } else {
      throw err;
    }
  }
}

/* ---------- Trash (undo xoá, tự dọn sau 30 ngày) ---------- */
function findTrashDir(uuid, req) {
  for (const d of trashDirsForUser(req)) {
    try { if (fs.existsSync(path.join(d, uuid, 'meta.json'))) return d; } catch {}
  }
  return null;
}
function trashMetaPath(uuid, tdOverride) { return path.join(tdOverride || findTrashDir(uuid) || trashDir, uuid, 'meta.json'); }
function trashDataPath(uuid, tdOverride) { return path.join(tdOverride || findTrashDir(uuid) || trashDir, uuid, 'data'); }
async function trashList(req) {
  let ids = [];
  const out = [];
  for (const d of trashDirsForUser(req)) {
    try { ids = await fsp.readdir(d); } catch { continue; }
    for (const id of ids) {
      try {
        const meta = JSON.parse(await fsp.readFile(path.join(d, id, 'meta.json'), 'utf8'));
        let size = 0;
        try {
          const st = await fsp.stat(path.join(d, id, 'data'));
          if (st.isFile()) size = st.size;
          else { const s = await walkStats(path.join(d, id, 'data')); size = s.size; }
        } catch {}
        out.push({ id, rel: meta.rel, name: meta.name, type: meta.type, deletedAt: meta.deletedAt, size, pool: meta.pool || 'main' });
      } catch {}
    }
  }
  out.sort((a, b) => b.deletedAt.localeCompare(a.deletedAt));
  return out;
}
async function purgeExpiredTrash() {
  for (const item of await trashList()) {
    try {
      if (Date.now() - new Date(item.deletedAt).getTime() > TRASH_TTL) {
        const d = findTrashDir(item.id);
        if (d) await fsp.rm(path.join(d, item.id), { recursive: true, force: true });
      }
    } catch {}
  }
}
setInterval(purgeExpiredTrash, 60 * 60 * 1000);
setTimeout(purgeExpiredTrash, 3000);

function uniqueRestoreTarget(abs) {
  const dir = path.dirname(abs);
  const ext = path.extname(abs);
  const base = path.basename(abs, ext);
  let target = abs;
  let i = 1;
  while (fs.existsSync(target)) { target = path.join(dir, `${base} (restored ${i})${ext}`); i++; }
  return target;
}

async function moveToTrash(abs, req) {
  const pool = poolOfAbs(abs);
  const rel = relOf(abs);
  const st = await fsp.stat(abs);
  const uuid = crypto.randomBytes(8).toString('hex');
  const td = trashDirOfAbs(path.resolve(pool.path));
  await fsp.mkdir(path.join(td, uuid), { recursive: true });
  await fsp.rename(abs, path.join(td, uuid, 'data'));
  await fsp.writeFile(path.join(td, uuid, 'meta.json'), JSON.stringify({
    rel, name: path.basename(abs), type: st.isDirectory() ? 'dir' : 'file',
    deletedAt: new Date().toISOString(), pool: pool.id,
  }));
  return uuid;
}

/* ---------- Network counters ---------- */
const net = { rx: 0, tx: 0, rateRx: 0, rateTx: 0, histRx: [], histTx: [] };
setInterval(() => {
  net.rateRx = net.rx;
  net.rateTx = net.tx;
  net.histRx.push(net.rx);
  net.histTx.push(net.tx);
  if (net.histRx.length > 30) { net.histRx.shift(); net.histTx.shift(); }
  net.rx = 0;
  net.tx = 0;
}, 1000);

/* ---------- CPU sampling ---------- */
let cpuUsage = 0;
let prevIdle = 0;
let prevTotal = 0;
function sampleCpu() {
  let idle = 0, total = 0;
  for (const c of os.cpus()) {
    const t = c.times;
    idle += t.idle;
    total += t.user + t.nice + t.sys + t.idle + t.irq;
  }
  if (prevTotal) {
    const dTotal = total - prevTotal;
    const dIdle = idle - prevIdle;
    cpuUsage = dTotal ? Math.max(0, Math.min(100, Math.round((1 - dIdle / dTotal) * 100))) : 0;
  }
  prevIdle = idle;
  prevTotal = total;
}
setInterval(sampleCpu, 2000);
sampleCpu();

/* ---------- Tailscale detection ---------- */
let tsCache = { time: 0, data: { installed: false, running: false } };
function getTailscale(force) {
  return new Promise((resolve) => {
    if (!force && tsCache.time && Date.now() - tsCache.time < 30000) return resolve(tsCache.data);
    let settled = false;
    const done = (data) => { if (!settled) { settled = true; tsCache = { time: Date.now(), data }; resolve(data); } };
    const timer = setTimeout(() => done({ installed: true, running: false, reason: 'timeout' }), 5000);
    execFile('tailscale', ['status', '--json'], { timeout: 4500, windowsHide: true }, (err, stdout) => {
      clearTimeout(timer);
      if (err) {
        if (err.code === 'ENOENT') return done({ installed: false, running: false });
        return done({ installed: true, running: false, reason: String(err.message || '').slice(0, 120) });
      }
      try {
        const j = JSON.parse(stdout);
        const peers = Object.values(j.Peer || {})
          .filter((p) => p.Online || p.Active)
          .map((p) => ({ ip: (p.TailscaleIPs || [])[0] || '', name: (p.DNSName || '').replace(/\.$/, '') || p.HostName || 'peer' }));
        done({
          installed: true,
          running: true,
          tailnet: j.MagicDNSSuffix || (j.Self && j.Self.DNSName ? '.' + j.Self.DNSName.split('.').slice(-2).join('.') : 'tailnet'),
          selfOnline: !!(j.Self && j.Self.Online),
          selfIp: j.Self ? (j.Self.TailscaleIPs || [])[0] || '' : '',
          selfName: j.Self ? j.Self.HostName || '' : '',
          peers,
        });
      } catch { done({ installed: true, running: false, reason: 'parse error' }); }
    });
  });
}
function isTailnetIp(ip, ts) {
  if (!ip) return false;
  if (ts && ts.running) {
    if (ip === ts.selfIp) return true;
    if (ts.peers && ts.peers.some((p) => p.ip === ip)) return true;
  }
  return /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./.test(ip);
}

function clientIp(req) {
  return String(req.socket.remoteAddress || 'local').replace(/^::ffff:/, '');
}

async function connTypeOf(ip) {
  const ts = await getTailscale(false);
  return isTailnetIp(ip, ts) ? 'tailscale' : 'lan';
}

function actorOf(req) {
  if (!req) return 'server';
  if (isLocalHostReq(req)) return adminName();
  try {
    const info = tokenInfo(getToken(req));
    if (info) {
      if (info.user === 'invite') return 'khách';
      return String(info.user || 'admin');
    }
  } catch {}
  return 'khách';
}

/* ---------- Phạm vi ổ/thư mục theo tài khoản ---------- */
function currentUserOf(req) {
  try {
    const info = tokenInfo(getToken(req));
    if (info) return info.user === 'invite' ? 'invite' : String(info.user || 'admin');
  } catch {}
  return null;
}
function userObjOf(name) {
  return users.find((u) => u.name.toLowerCase() === String(name || '').toLowerCase()) || null;
}
function scopeEntryAbs(entry) {
  const s = String(entry == null ? '' : (typeof entry === 'string' ? entry : entry.path || '')).trim();
  if (!s || s === '*') return null;
  if (/^pool:/i.test(s)) {
    const p = getPool(s.slice(5));
    return p ? path.resolve(poolRoot(p)) : null;
  }
  if (/^path:/i.test(s)) return path.resolve(s.slice(5));
  return path.resolve(s);
}
function scopeRootsOf(user) {
  if (!user || (user.role !== 'viewer' && user.role !== 'editor')) return '*';
  const entries = Array.isArray(user.scope) ? user.scope : [];
  if (!entries.length || entries.includes('*')) return '*';
  const roots = [];
  for (const e of entries) {
    const abs = scopeEntryAbs(e);
    if (abs) roots.push(abs);
  }
  return roots.length ? roots : '*';
}

/* "Ổ ảo" — mỗi thư mục được chia sẻ của tài khoản giới hạn hoạt động như một ổ riêng.
   ID xác định (hash của đường dẫn) nên client gửi lại được giữa các request. */
const vPoolCache = new Map();
function virtualPool(absIn) {
  const abs = path.resolve(String(absIn));
  const id = 'sc-' + crypto.createHash('sha1').update(abs.toLowerCase()).digest('hex').slice(0, 10);
  const vp = { id, name: path.basename(abs) || abs, path: abs, virtual: true, default: false };
  vPoolCache.set(id, abs);
  return vp;
}
function userPools(req) {
  const name = currentUserOf(req);
  if (!name || name === 'admin') return config.pools;
  const u = userObjOf(name);
  if (!u) return config.pools;
  const roots = scopeRootsOf(u);
  if (roots === '*') return config.pools;
  const out = [];
  for (const abs of roots) {
    const real = config.pools.find((p) => path.resolve(p.path).toLowerCase() === abs.toLowerCase());
    out.push(real || virtualPool(abs));
  }
  return out.length ? out : config.pools;
}
function defaultPoolOf(req) {
  const list = userPools(req);
  return list.find((p) => p.default) || list[0] || defaultPool();
}
function poolCtx(req, poolId) {
  const id = String(poolId || '');
  if (req == null) {
    if (!id) return defaultPool();
    const real = config.pools.find((p) => p.id === id);
    if (real) return real;
    const vabs = vPoolCache.get(id);
    return vabs ? virtualPool(vabs) : null;
  }
  const list = userPools(req);
  if (!id) return list.find((p) => p.default) || list[0] || defaultPool();
  return list.find((p) => p.id === id) || null;
}
function poolPathById(id) {
  const p = getPool(id);
  if (p) return path.resolve(p.path);
  return vPoolCache.get(String(id || '')) || null;
}

function canAccess(req, abs) {
  const name = currentUserOf(req);
  if (!name || name === 'admin') return true;
  const u = userObjOf(name);
  if (!u) return true;
  const roots = scopeRootsOf(u);
  if (roots === '*') return true;
  return roots.some((r) => isWithin(String(abs), r));
}
function poolAllowed(req, poolId) {
  const name = currentUserOf(req);
  if (!name || name === 'admin') return true;
  const u = userObjOf(name);
  if (!u) return true;
  const id = String(poolId || '');
  if (id.startsWith('sc-')) return userPools(req).some((p) => p.id === id);
  const roots = scopeRootsOf(u);
  if (roots === '*') return true;
  const p = getPool(poolId);
  if (!p) return false;
  const r = path.resolve(poolRoot(p));
  return roots.some((root) => isWithin(r, root));
}
function scopedPools(req) {
  return userPools(req);
}
function checkScope(req, abs, poolId) {
  if (!canAccess(req, abs)) return { error: 'Tài khoản này không có quyền truy cập ổ/thư mục đó.' };
  if (poolId && !poolAllowed(req, poolId)) return { error: 'Tài khoản này không có quyền truy cập ổ đó.' };
  return null;
}
function parseScopeInput(arr) {
  if (!Array.isArray(arr)) return null;
  const out = [];
  for (const e of arr) {
    const s = String(e == null ? '' : e).trim();
    if (!s) continue;
    if (s === '*') return ['*'];
    if (/^pool:[\w-]+$/i.test(s)) {
      if (!getPool(s.slice(5))) return null;
      if (out.includes(s)) continue;
      out.push(s);
      continue;
    }
    if (/^path:/i.test(s)) {
      const abs = path.resolve(s.slice(5));
      const entry = 'path:' + abs;
      if (out.includes(entry)) continue;
      out.push(entry);
      continue;
    }
    return null;
  }
  return out.length ? out : ['*'];
}

function logActivity(action, label, req, userOverride, dedupeKey, dedupeMs) {
  const user = userOverride || actorOf(req);
  if (dedupeKey) {
    const key = user + '|' + dedupeKey;
    const now = Date.now();
    const last = activityDedup.get(key);
    const win = dedupeMs && dedupeMs > 0 ? dedupeMs : 15000;
    if (last && now - last < win) return;
    activityDedup.set(key, now);
    if (activityDedup.size > 400) {
      for (const [k, t] of activityDedup) { if (now - t > 5 * 60 * 1000) activityDedup.delete(k); }
    }
  }
  activity.unshift({ time: new Date().toISOString(), action, label, user, ip: req ? clientIp(req) : 'host' });
  if (activity.length > 100) activity.pop();
}
const activityDedup = new Map();

function guessDeviceName(ua) {
  ua = String(ua || '');
  if (ua.includes('Electron')) return 'Desktop Client';
  if (ua.includes('Edg/')) return 'Edge Browser';
  if (ua.includes('Firefox')) return 'Firefox Browser';
  if (ua.includes('Chrome')) return 'Chrome Browser';
  if (ua.includes('Safari')) return 'Safari Browser';
  return 'Unknown Device';
}

function touchDevice(req) {
  const t = getToken(req);
  if (!t) return;
  const d = devices.get(t);
  if (d) { d.lastSeen = Date.now(); d.ip = clientIp(req); }
}

function scheduleRemove(id) {
  setTimeout(() => transfers.delete(id), 60000);
}

/* ---------- ffmpeg / ffprobe detection (video audio transcode) ---------- */
const { spawn: spawnTool } = require('child_process');
function findTool(name) {
  const exe = process.platform === 'win32' ? name + '.exe' : name;
  const cands = [
    path.join(__dirname, 'ffmpeg', exe),
    path.join(__dirname, 'ffmpeg', 'bin', exe),
    path.join(__dirname, '..', '.tools', 'ffmpeg', exe),
    path.join(__dirname, '..', '.tools', 'ffmpeg', 'bin', exe),
  ];
  try { if (process.resourcesPath) cands.push(path.join(process.resourcesPath, 'ffmpeg', exe)); } catch {}
  for (const c of cands) { try { if (c && fs.existsSync(c)) return c; } catch {} }
  return null;
}
const FFMPEG_BIN = findTool('ffmpeg');
const FFPROBE_BIN = findTool('ffprobe');
function probeStreams(abs) {
  return new Promise((resolve, reject) => {
    execFile(FFPROBE_BIN, ['-v', 'error', '-print_format', 'json', '-show_streams', abs], { maxBuffer: 4 * 1024 * 1024, windowsHide: true }, (err, stdout) => {
      if (err) return reject(err);
      try { resolve(JSON.parse(stdout).streams || []); } catch (e) { reject(e); }
    });
  });
}
function probeViaFfmpeg(abs) {
  return new Promise((resolve) => {
    execFile(FFMPEG_BIN, ['-hide_banner', '-i', abs], { maxBuffer: 4 * 1024 * 1024, windowsHide: true }, (err, stdout, stderr) => {
      const streams = [];
      const text = String(stderr || '') + '\n' + String(stdout || '');
      const vm = text.match(/Stream #\d+:\d+(?:\[[^\]]*\])?(?:\([^)]*\))?: Video: (\w+)/);
      const am = text.match(/Stream #\d+:\d+(?:\[[^\]]*\])?(?:\([^)]*\))?: Audio: (\w+)/);
      if (vm) streams.push({ codec_type: 'video', codec_name: vm[1] });
      if (am) streams.push({ codec_type: 'audio', codec_name: am[1] });
      resolve(streams);
    });
  });
}
const NATIVE_VIDEO = new Set(['h264', 'hevc', 'h265', 'vp8', 'vp9', 'av1', 'mpeg4', 'mpeg2video', 'mjpeg']);
const NATIVE_AUDIO = new Set(['aac', 'mp3', 'opus', 'vorbis', 'flac', 'pcm_s16le', 'pcm_s24le', 'wav']);

function json(res, code, data) {
  const body = JSON.stringify(data);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) {
        reject(new Error('PAYLOAD_TOO_LARGE'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function readJsonBody(buf, limit) {
  let s = buf.toString('utf8');
  if (s.charCodeAt(0) === 0xfeff) s = s.slice(1);
  if (Buffer.byteLength(s, 'utf8') > limit) throw new Error('PAYLOAD_TOO_LARGE');
  return s ? JSON.parse(s) : {};
}

function safeResolve(rel, poolId, req) {
  let root = null;
  const isCam = (rel && /^[^\/]+\/Camera_\d+/i.test(rel)) || 
                (req && (req.headers['x-cw-type'] === 'camera' || 
                         req.headers['x-cw-client'] === 'mobile' || 
                         (req.url && /[?&]camera=1/.test(req.url))));

  if (isCam) {
    root = path.resolve(cameraPool().path);
  } else if (poolId) {
    if (req != null) {
      const pool = poolCtx(req, poolId);
      if (pool) root = path.resolve(pool.path);
    }
    if (!root) root = poolPathById(poolId);
  }

  if (!root) {
    root = path.resolve(defaultPool().path);
  }
  const clean = String(rel || '').replace(/\\/g, '/').replace(/^\/+/, '');
  const abs = path.resolve(root, clean);
  if (!isWithin(abs, root)) return null;
  return abs;
}

function isWithin(abs, root) {
  const a = path.resolve(String(abs)).toLowerCase();
  const r = path.resolve(String(root)).toLowerCase();
  if (a === r) return true;
  const sep = path.sep.toLowerCase();
  return a.startsWith(r.endsWith(sep) ? r : r + sep);
}

function nameForPath(p) {
  const resolved = path.resolve(String(p));
  const m = /^([A-Za-z]):[\\/]*$/.exec(resolved);
  if (m) {
    const letter = m[1].toUpperCase();
    const label = volumeLabels()[letter] || '';
    return label ? letter + ': ' + label : letter + ':';
  }
  const b = path.basename(p);
  if (b) return b;
  return 'Shared';
}
function refreshDriveNames() {
  let changed = false;
  for (const p of config.pools) {
    const m = /^([A-Za-z]):[\\/]*$/.exec(path.resolve(p.path));
    if (!m) continue;
    const want = nameForPath(p.path);
    if (want !== p.name && !/^\w+:$/.test(want)) { p.name = want; changed = true; }
  }
  if (changed) saveConfig();
}
refreshDriveNames();
setInterval(refreshDriveNames, 60 * 60 * 1000);

function relOf(abs) {
  const p = poolOfAbs(abs);
  const r = path.relative(poolRoot(p), abs).replace(/\\/g, '/');
  return r === '.' ? '' : r;
}
function relOfForUser(abs, req) {
  if (!req) return relOf(abs);
  const p = poolOfAbsForUser(abs, req);
  const r = path.relative(path.resolve(p.path), abs).replace(/\\/g, '/');
  return r === '.' ? '' : r;
}

function getToken(req) {
  const h = req.headers['authorization'] || '';
  if (h.startsWith('Bearer ')) return h.slice(7);
  const cookie = req.headers.cookie || '';
  const m = cookie.match(/(?:^|;\s*)dc_token=([^;]+)/);
  if (m) return m[1];
  try {
    const u = new URL(req.url, 'http://localhost');
    const q = u.searchParams.get('token');
    if (q) return q;
  } catch {}
  return null;
}

function tokenInfo(t) {
  const info = tokens.get(t || '');
  if (!info || typeof info !== 'object') { tokens.delete(t); return null; }
  if (info.expires < Date.now()) { tokens.delete(t); devices.delete(t); return null; }
  if (info.user && info.user !== 'admin' && info.user !== 'invite') {
    const u = users.find((x) => x.name.toLowerCase() === String(info.user).toLowerCase());
    if (!u) { tokens.delete(t); devices.delete(t); return null; }
    if (info.role !== u.role) {
      info.role = u.role;
      const d = devices.get(t);
      if (d) d.role = u.role;
    }
  }
  return info;
}
function isLocalHostReq(req) {
  if (!req) return false;
  const ip = clientIp(req);
  const isLocal = ip === '127.0.0.1' || ip === '::1' || ip === 'localhost' || ip === 'local' || ip === '::ffff:127.0.0.1';
  const ref = req.headers.referer || '';
  return isLocal && (ref.includes('host.html') || req.headers['x-host-console'] === '1' || String(req.headers['user-agent'] || '').includes('Electron'));
}

function isAuthed(req) {
  if (isLocalHostReq(req)) return true;
  return tokenInfo(getToken(req)) !== null;
}
function roleOf(req) {
  if (isLocalHostReq(req)) return 'admin';
  const info = tokenInfo(getToken(req));
  return info ? (info.role || 'admin') : '';
}
const ROLE_ORDER = { viewer: 1, editor: 2, admin: 3 };
function requireRole(req, res, minRole) {
  if (!isAuthed(req)) { json(res, 401, { error: 'Chưa đăng nhập.' }); return false; }
  const role = roleOf(req);
  if ((ROLE_ORDER[role] || 3) < (ROLE_ORDER[minRole] || 1)) {
    json(res, 403, { error: 'Tài khoản này không có quyền thực hiện thao tác đó.' });
    return false;
  }
  return true;
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
  '.pdf': 'application/pdf',
  '.mp4': 'video/mp4',
  '.mkv': 'video/x-matroska',
  '.webm': 'video/webm',
  '.mov': 'video/quicktime',
  '.m4v': 'video/x-m4v',
  '.avi': 'video/x-msvideo',
  '.3gp': 'video/3gpp',
  '.3gpp': 'video/3gpp',
  '.flv': 'video/x-flv',
  '.wmv': 'video/x-ms-wmv',
  '.mpg': 'video/mpeg',
  '.mpeg': 'video/mpeg',
  '.ts': 'video/mp2t',
  '.ogv': 'video/ogg',
  '.rm': 'application/vnd.rn-realmedia',
  '.rmvb': 'application/vnd.rn-realmedia',
  '.mp3': 'audio/mpeg',
  '.wav': 'audio/wav',
  '.ogg': 'audio/ogg',
  '.m4a': 'audio/mp4',
  '.aac': 'audio/aac',
  '.flac': 'audio/flac',
};

function serveStatic(req, res) {
  let urlPath = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  if (urlPath === '/') urlPath = '/index.html';
  if (urlPath === '/s' || urlPath === '/s/') urlPath = '/s.html';
  const abs = path.join(PUBLIC_DIR, path.normalize(urlPath).replace(/^([/\\])+/, ''));
  if (!abs.startsWith(PUBLIC_DIR)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.stat(abs, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(abs).toLowerCase()] || 'application/octet-stream',
      'Content-Length': st.size,
      'Cache-Control': 'no-store',
    });
    fs.createReadStream(abs).pipe(res);
  });
}

async function walkStats(dir) {
  let files = 0, folders = 0, size = 0;
  const stack = [dir];
  while (stack.length && files + folders < 50000) {
    const d = stack.pop();
    let entries;
    try { entries = await fsp.readdir(d, { withFileTypes: true }); } catch { continue; }
    for (const e of entries) {
      if (e.name === UPLOADS_DIRNAME) continue;
      const p = path.join(d, e.name);
      if (e.isDirectory()) { folders++; stack.push(p); }
      else {
        files++;
        try { size += (await fsp.stat(p)).size; } catch {}
      }
    }
  }
  return { files, folders, size };
}

/* ---------- Range-capable file streaming ---------- */
function parseRange(header, size) {
  const m = /^bytes=(\d*)-(\d*)$/.exec(String(header || '').trim());
  if (!m) return null;
  let start = m[1] === '' ? NaN : parseInt(m[1], 10);
  let end = m[2] === '' ? NaN : parseInt(m[2], 10);
  if (isNaN(start) && isNaN(end)) return null;
  if (isNaN(start)) { start = Math.max(0, size - end); end = size - 1; }
  if (isNaN(end)) end = size - 1;
  if (start > end || start >= size) return { invalid: true };
  end = Math.min(end, size - 1);
  return { start, end };
}

async function streamFile(req, res, abs, name, inline) {
  const st = await fsp.stat(abs);
  if (!st.isFile()) throw new Error('NOT_A_FILE');
  const mime = MIME[path.extname(abs).toLowerCase()] || 'application/octet-stream';
  const range = parseRange(req.headers.range, st.size);
  if (range && range.invalid) {
    res.writeHead(416, { 'Content-Range': `bytes */${st.size}` });
    return res.end();
  }
  const headers = {
    'Content-Type': inline ? mime : 'application/octet-stream',
    'Accept-Ranges': 'bytes',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Expose-Headers': 'Content-Range, Content-Length, Accept-Ranges',
  };
  if (!inline) headers['Content-Disposition'] = `attachment; filename*=UTF-8''${encodeURIComponent(name)}`;
  let stream;
  if (range) {
    headers['Content-Range'] = `bytes ${range.start}-${range.end}/${st.size}`;
    headers['Content-Length'] = range.end - range.start + 1;
    res.writeHead(206, headers);
    stream = fs.createReadStream(abs, { start: range.start, end: range.end });
  } else {
    headers['Content-Length'] = st.size;
    res.writeHead(200, headers);
    stream = fs.createReadStream(abs);
  }
  stream.on('data', (c) => { net.tx += c.length; });
  stream.pipe(res);
  return stream;
}

/* ---------- ZIP streaming (store, data descriptors) ---------- */
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32Update(crc, buf) {
  crc = crc ^ 0xffffffff;
  for (let i = 0; i < buf.length; i++) crc = CRC_TABLE[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

async function collectZipEntries(rootDir) {
  const out = [];
  const stack = [{ dir: rootDir, rel: '' }];
  while (stack.length && out.length < 2000) {
    const { dir, rel } = stack.pop();
    let entries;
    try { entries = await fsp.readdir(dir, { withFileTypes: true }); } catch { continue; }
    for (const e of entries) {
      if (e.name === UPLOADS_DIRNAME) continue;
      const p = path.join(dir, e.name);
      const r = rel ? rel + '/' + e.name : e.name;
      if (e.isDirectory()) stack.push({ dir: p, rel: r });
      else if (e.isFile()) out.push({ abs: p, rel: r });
    }
  }
  return out;
}

function writeOut(res, buf) {
  return new Promise((resolve, reject) => {
    const ok = res.write(buf, (err) => { if (err) reject(err); else if (ok || res.writableNeedDrain === false) resolve(); else res.once('drain', resolve); });
  });
}

async function streamZip(rootDir, res, baseName) {
  const entries = await collectZipEntries(rootDir);
  res.writeHead(200, {
    'Content-Type': 'application/zip',
    'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(baseName + '.zip')}`,
    'Cache-Control': 'no-store',
    'Transfer-Encoding': 'chunked',
  });
  const central = [];
  let aborted = false;
  res.on('close', () => { aborted = true; });
  try {
    for (const e of entries) {
      if (aborted) return;
      const nameBuf = Buffer.from(e.rel, 'utf8');
      const st = await fsp.stat(e.abs).catch(() => null);
      if (!st || !st.isFile()) continue;
      const localOffset = resBytes(res);
      const lh = Buffer.alloc(30);
      lh.writeUInt32LE(0x04034b50, 0);
      lh.writeUInt16LE(20, 4);
      lh.writeUInt16LE(0x0008, 6);
      lh.writeUInt16LE(0, 8);
      lh.writeUInt16LE(0, 10);
      lh.writeUInt16LE(0x21, 12);
      lh.writeUInt32LE(0, 14);
      lh.writeUInt32LE(0, 18);
      lh.writeUInt32LE(0, 22);
      lh.writeUInt16LE(nameBuf.length, 26);
      lh.writeUInt16LE(0, 28);
      await writeOut(res, Buffer.concat([lh, nameBuf]));
      let crc = 0;
      let size = 0;
      await new Promise((resolve, reject) => {
        const rs = fs.createReadStream(e.abs);
        rs.on('data', async (c) => {
          rs.pause();
          try {
            crc = crc32Update(crc, c);
            size += c.length;
            net.tx += c.length;
            await writeOut(res, c);
            if (!aborted) rs.resume(); else rs.destroy();
          } catch (er) { rs.destroy(); reject(er); }
        });
        rs.on('end', resolve);
        rs.on('error', reject);
        res.on('close', () => rs.destroy());
      });
      if (aborted) return;
      const dd = Buffer.alloc(16);
      dd.writeUInt32LE(0x08074b50, 0);
      dd.writeUInt32LE(crc >>> 0, 4);
      dd.writeUInt32LE(size >>> 0, 8);
      dd.writeUInt32LE(size >>> 0, 12);
      await writeOut(res, dd);
      central.push({ nameBuf, crc: crc >>> 0, size, localOffset });
    }
    const cdStart = resBytes(res);
    for (const c of central) {
      const cdh = Buffer.alloc(46);
      cdh.writeUInt32LE(0x02014b50, 0);
      cdh.writeUInt16LE(20, 4);
      cdh.writeUInt16LE(20, 6);
      cdh.writeUInt16LE(0x0008, 8);
      cdh.writeUInt16LE(0, 10);
      cdh.writeUInt16LE(0, 12);
      cdh.writeUInt16LE(0x21, 14);
      cdh.writeUInt32LE(c.crc, 16);
      cdh.writeUInt32LE(c.size, 20);
      cdh.writeUInt32LE(c.size, 24);
      cdh.writeUInt16LE(c.nameBuf.length, 28);
      cdh.writeUInt32LE(c.localOffset, 42);
      await writeOut(res, Buffer.concat([cdh, c.nameBuf]));
    }
    const cdSize = resBytes(res) - cdStart;
    const eocd = Buffer.alloc(22);
    eocd.writeUInt32LE(0x06054b50, 0);
    eocd.writeUInt16LE(central.length, 8);
    eocd.writeUInt16LE(central.length, 10);
    eocd.writeUInt32LE(cdSize, 12);
    eocd.writeUInt32LE(cdStart, 16);
    await writeOut(res, eocd);
    res.end();
  } catch {
    res.end();
  }
}

function resBytes(res) {
  if (typeof res._cwBytes === 'number') return res._cwBytes;
  res._cwBytes = 0;
  const orig = res.write.bind(res);
  res.write = function (chunk, ...a) {
    res._cwBytes += Buffer.isBuffer(chunk) ? chunk.length : Buffer.byteLength(chunk);
    return orig(chunk, ...a);
  };
  return 0;
}

/* ---------- Chunked uploads ---------- */
function cleanupStaleParts() {
  try {
    for (const [id, meta] of partUploads) {
      if (Date.now() - meta.lastActive > PART_TTL) {
        const upDir = meta.poolRoot ? upDirOfAbs(meta.poolRoot) : uploadsDirOf(meta.pool || 'main');
        partUploads.delete(id);
        fsp.rm(path.join(upDir, id + '.part'), { force: true }).catch(() => {});
        fsp.rm(path.join(upDir, id + '.meta'), { force: true }).catch(() => {});
      }
    }
  } catch {}
}
setInterval(cleanupStaleParts, 10 * 60 * 1000);
setTimeout(cleanupStaleParts, 5000);

function uniqueTarget(abs) {
  const dir = path.dirname(abs);
  const ext = path.extname(abs);
  const base = path.basename(abs, ext);
  let target = abs;
  let i = 1;
  while (fs.existsSync(target)) {
    target = path.join(dir, `${base} (${i})${ext}`);
    i++;
  }
  return target;
}

/* ---------- Copy/move jobs (có tiến độ % + tốc độ cho client) ---------- */
const copyJobs = new Map();
function makeCopyJob(mode, totalItems) {
  const id = crypto.randomBytes(6).toString('base64url');
  const job = { id, mode, status: 'running', done: 0, total: 0, doneItems: 0, totalItems, current: '', error: null, started: Date.now(), _copiedFiles: 0, _doneFileBytes: 0 };
  copyJobs.set(id, job);
  return job;
}
function scheduleJobClean(id, ms) {
  setTimeout(() => copyJobs.delete(id), ms || 10 * 60 * 1000);
}
async function statTreeBytes(abs, cap) {
  let total = 0, count = 0;
  const stack = [abs];
  while (stack.length && count < (cap || 20000)) {
    const d = stack.pop();
    let entries;
    try { entries = await fsp.readdir(d, { withFileTypes: true }); } catch { continue; }
    for (const e of entries) {
      if (e.name.startsWith('.cw-') || e.name === UPLOADS_DIRNAME) continue;
      const p = path.join(d, e.name);
      if (e.isDirectory()) stack.push(p);
      else if (e.isFile()) { try { total += (await fsp.stat(p)).size; count++; } catch {} }
    }
  }
  return total;
}
async function safeRename(src, dst) {
  for (let i = 0; i < 8; i++) {
    try {
      await fsp.rename(src, dst);
      return;
    } catch (e) {
      if (i === 7) throw e;
      await new Promise((r) => setTimeout(r, 100 * (i + 1)));
    }
  }
}

async function copyFileProgressed(src, dst, job) {
  await ensureDir(path.dirname(dst));
  const tmp = dst + '.cwtmp';
  const { pipeline } = require('stream/promises');
  const rs = fs.createReadStream(src);
  const ws = fs.createWriteStream(tmp);
  rs.on('data', (c) => { if (job) job.done += c.length; });
  await pipeline(rs, ws);
  await safeRename(tmp, dst);
}

async function safeUnlink(filePath) {
  for (let i = 0; i < 8; i++) {
    try {
      try { await fsp.chmod(filePath, 0o666); } catch {}
      await fsp.unlink(filePath);
      return;
    } catch (e) {
      if (e.code === 'ENOENT') return;
      if (i === 7) throw e;
      await new Promise((r) => setTimeout(r, 150 * (i + 1)));
    }
  }
}

async function safeRmTree(targetPath) {
  if (!fs.existsSync(targetPath)) return;
  let st = null;
  try { st = await fsp.stat(targetPath); } catch { return; }
  if (st.isFile()) {
    await safeUnlink(targetPath);
    return;
  }
  const entries = await fsp.readdir(targetPath, { withFileTypes: true }).catch(() => []);
  for (const e of entries) {
    const p = path.join(targetPath, e.name);
    if (e.isDirectory()) {
      await safeRmTree(p);
    } else {
      await safeUnlink(p);
    }
  }
  for (let i = 0; i < 8; i++) {
    try {
      await fsp.rmdir(targetPath);
      return;
    } catch (e) {
      if (e.code === 'ENOENT') return;
      if (i === 7) throw e;
      await new Promise((r) => setTimeout(r, 150 * (i + 1)));
    }
  }
}
async function copyDirProgressed(src, dst, job) {
  await ensureDir(dst);
  const entries = await fsp.readdir(src, { withFileTypes: true });
  for (const e of entries) {
    if (job._abort) throw new Error('Đã hủy');
    if (e.name === UPLOADS_DIRNAME || e.name.startsWith('.cw-')) continue;
    const s = path.join(src, e.name);
    const d = path.join(dst, e.name);
    job.current = e.name;
    if (e.isDirectory()) await copyDirProgressed(s, d, job);
    else {
      const st = await fsp.stat(s).catch(() => null);
      await copyFileProgressed(s, d, job);
      job._copiedFiles++;
      if (st) job._doneFileBytes += st.size;
    }
  }
}

/* ---------- Copy/move across storage drives ---------- */
async function copyRecursive(src, dst) {
  await ensureDir(dst);
  const entries = await fsp.readdir(src, { withFileTypes: true });
  for (const e of entries) {
    if (e.name === UPLOADS_DIRNAME || e.name.startsWith('.cw-')) continue;
    const s = path.join(src, e.name);
    const d = path.join(dst, e.name);
    if (e.isDirectory()) await copyRecursive(s, d);
    else await fsp.copyFile(s, d);
  }
}
function relOfInPool(abs, pool) {
  const r = path.relative(poolRoot(pool), abs).replace(/\\/g, '/');
  return r === '.' ? '' : r;
}

/* ---------- Dashboard ---------- */
async function buildDashboard(req) {
  const rootAbs = path.resolve(config.root);
  let total = 0, free = 0;
  try {
    const st = await fsp.statfs(rootAbs);
    total = st.blocks * st.bsize;
    free = st.bavail * st.bsize;
  } catch {}
  const files = await walkStats(rootAbs);
  const now = Date.now();
  const ts = await getTailscale(false);
  const devList = (await Promise.all([...devices.values()].map(async (d) => ({
    name: d.name, ip: d.ip, lastSeen: d.lastSeen, created: d.created,
    online: now - d.lastSeen < 15 * 60 * 1000,
    via: isTailnetIp(d.ip, ts) ? 'tailscale' : 'lan',
  })))).sort((a, b) => b.lastSeen - a.lastSeen);
  const trf = [...transfers.values()].sort((a, b) => b.started - a.started).slice(0, 12);
  return {
    host: os.hostname(),
    version: '1.0.0',
    root: rootAbs,
    storage: { total, free, used: total - free, usedPct: total ? Math.round(((total - free) / total) * 100) : 0 },
    pool: { ...files, capacity: total, usedPct: total ? Math.round((files.size / total) * 100) : 0 },
    network: { rateRx: net.rateRx, rateTx: net.rateTx, histRx: net.histRx, histTx: net.histTx },
    devices: devList,
    devicesOnline: devList.filter((d) => d.online).length,
    transfers: trf,
    activeTransfers: trf.filter((t) => t.status === 'active').length,
    transferRemaining: trf.reduce((s, t) => s + Math.max(0, (t.total || 0) - (t.done || 0)), 0),
    activity: activity.slice(0, 30),
    health: {
      cpu: cpuUsage,
      cpus: os.cpus()[0] ? os.cpus()[0].model.trim() : 'CPU',
      memPct: Math.round((1 - os.freemem() / os.totalmem()) * 100),
      memUsed: os.totalmem() - os.freemem(),
      memTotal: os.totalmem(),
      platform: `${os.type()} ${os.release()}`,
    },
    tailscale: { installed: ts.installed, running: ts.running, tailnet: ts.tailnet || '', selfIp: ts.selfIp || '', selfOnline: !!ts.selfOnline, reason: ts.reason || '' },
    shares: shares.map((s) => ({ ...s })),
    uptime: os.uptime(),
    invite: { code: invite.code, expiresInMs: Math.max(0, invite.created + invite.ttl - Date.now()) },
    lanIps: (() => {
      const all = Object.values(os.networkInterfaces()).flat().filter((n) => n && n.family === 'IPv4' && !n.internal).map((n) => n.address);
      const tsIps = tsCache.data && tsCache.data.selfIp ? [tsCache.data.selfIp] : [];
      const pref = all.filter((ip) => /^192\.168\.|^10\.|^172\.(1[6-9]|2\d|3[01])\./.test(ip));
      const rest = all.filter((ip) => !pref.includes(ip) && !tsIps.includes(ip));
      return [...pref, ...rest];
    })(),
    port: config.port,
  };
}

/* ---------- Share link helpers ---------- */
function shareAbs(s) {
  if (!s) return null;
  if (s.abs) {
    const a = path.resolve(String(s.abs));
    if (fs.existsSync(a)) return a;
    const p = poolOfAbs(a);
    if (isWithin(a, poolRoot(p))) return a;
    return null;
  }
  return safeResolve(s.rel, s.pool || '');
}
function shareValid(s) {
  if (!s) return false;
  if (s.expires && Date.now() > s.expires) return false;
  if (s.maxUses && s.uses >= s.maxUses) return false;
  return !!shareAbs(s);
}
function consumeShare(id) {
  const s = shares.find((x) => x.id === id);
  if (!s) return null;
  if (!shareValid(s)) return { expired: true };
  const abs = shareAbs(s);
  if (!abs || !fs.existsSync(abs)) return { gone: true };
  return { share: s, abs };
}

/* ---------- API ---------- */
async function handleApi(req, res, url) {
  const route = url.pathname;

  if (route === '/api/health') return json(res, 200, { ok: true, time: new Date().toISOString() });

  if (route === '/api/ping') {
    const ip = clientIp(req);
    const via = await connTypeOf(ip);
    return json(res, 200, {
      ok: true,
      app: 'cw-datacenter',
      host: os.hostname(),
      port: config.port,
      name: 'CW Datacenter',
      via,
      ip,
      t: Date.now(),
      time: Date.now(),
      adminUser: adminName()
    });
  }

  /* Public share endpoints */
  if (route === '/api/share/info' && req.method === 'GET') {
    const r = consumeShare(url.searchParams.get('id') || '');
    if (!r) return json(res, 404, { error: 'Link không tồn tại.' });
    if (r.expired) return json(res, 410, { error: 'Link đã hết hạn.' });
    if (r.gone) return json(res, 410, { error: 'Tệp không còn tồn tại.' });
    const st = await fsp.stat(r.abs);
    const info = { name: r.share.name || path.basename(r.abs), type: st.isDirectory() ? 'dir' : 'file', size: st.size, mtime: st.mtime.toISOString(), expires: r.share.expires, uses: r.share.uses, maxUses: r.share.maxUses };
    if (st.isDirectory()) {
      const sub = await walkStats(r.abs);
      info.size = sub.size;
      info.fileCount = sub.files;
    }
    return json(res, 200, info);
  }

  if (route === '/api/share/file' && req.method === 'GET') {
    const r = consumeShare(url.searchParams.get('id') || '');
    if (!r) return json(res, 404, { error: 'Link không tồn tại.' });
    if (r.expired) return json(res, 410, { error: 'Link đã hết hạn.' });
    if (r.gone) return json(res, 410, { error: 'Tệp không còn tồn tại.' });
    const st = await fsp.stat(r.abs);
    const isPreview = url.searchParams.get('preview') === '1';
    if (st.isDirectory()) {
      r.share.uses++;
      saveShares();
      logActivity('download', `đã tải xuống thư mục "${r.share.name}" (ZIP) qua link chia sẻ`, req);
      return streamZip(r.abs, res, r.share.name || 'shared');
    }
    if (!isPreview) {
      r.share.uses++;
      saveShares();
      logActivity('download', `đã tải xuống "${r.share.name}" qua link chia sẻ`, req);
    }
    await streamFile(req, res, r.abs, r.share.name || path.basename(r.abs), isPreview);
    return;
  }

  if (route === '/api/login' && req.method === 'POST') {
    if (Date.now() < lockUntil) return json(res, 429, { error: 'Quá nhiều lần thử, đợi 30 giây.' });
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const inviteOk = String(body.invite || '') && (Date.now() - invite.created < invite.ttl) && body.invite === invite.code;
    let authRole = null;
    let authUser = '';
    const uname = String(body.username || '').trim();
    const admName = adminName();
    const isHost = body.device === 'Host Console' || body.device === 'Host App' || !uname || (req.headers.referer && req.headers.referer.includes('host.html'));
    if (body.password === config.password) {
      if (isHost || (uname && uname.toLowerCase() === admName.toLowerCase())) {
        authRole = 'admin';
        authUser = admName;
      }
    }
    if (!authRole && uname && body.password) {
      const u = verifyUser(uname, body.password);
      if (u) { authRole = u.role; authUser = u.name; }
    }
    if (authRole || inviteOk) {
      loginFails = 0;
      const inviteRole = config.inviteRole === 'viewer' ? 'viewer' : 'editor';
      const token = crypto.randomBytes(32).toString('hex');
      const role = authRole || inviteRole;
      const who = inviteOk ? 'invite' : authUser;
      tokens.set(token, { expires: Date.now() + TOKEN_TTL, role, user: who });
      saveTokens();
      const name = String(body.device || '').slice(0, 60) || guessDeviceName(req.headers['user-agent']);
      devices.set(token, { name, ip: clientIp(req), created: Date.now(), lastSeen: Date.now(), role, user: who });
      if (!inviteOk && authUser.toLowerCase() !== admName.toLowerCase()) {
        const u = users.find((x) => x.name.toLowerCase() === authUser.toLowerCase());
        if (u) { u.lastLogin = new Date().toISOString(); saveUsers(); }
      }
      res.setHeader('Set-Cookie', `dc_token=${token}; Path=/; HttpOnly; Max-Age=${TOKEN_TTL / 1000}`);
      logActivity('login', `đã đăng nhập từ ${clientIp(req)}${inviteOk ? ' (mã mời)' : ''}`, req, who);
      return json(res, 200, { token, host: os.hostname(), root: relOf(path.resolve(config.root)), role, user: who });
    }
    loginFails++;
    if (loginFails >= 10) { lockUntil = Date.now() + 30000; loginFails = 0; }
    return json(res, 401, { error: 'Sai tên đăng nhập hoặc mật khẩu.' });
  }

  if (!isAuthed(req)) return json(res, 401, { error: 'Chưa đăng nhập.' });
  touchDevice(req);
  const ROLE = roleOf(req);

  if (route === '/api/logout' && req.method === 'POST') {
    const t = getToken(req);
    if (t) { tokens.delete(t); devices.delete(t); saveTokens(); }
    res.setHeader('Set-Cookie', 'dc_token=; Path=/; Max-Age=0');
    return json(res, 200, { ok: true });
  }

  if (route === '/api/me' && req.method === 'GET') {
    const info = tokenInfo(getToken(req));
    return json(res, 200, { ok: true, root: relOf(path.resolve(config.root)), host: os.hostname(), role: ROLE, user: info ? info.user : '' });
  }

  if (route === '/api/info' && req.method === 'GET') {
    const myPool = defaultPoolOf(req);
    return json(res, 200, {
      host: os.hostname(),
      root: relOfForUser(path.resolve(poolRoot(myPool)), req),
      storage: await (async () => {
        const rootAbs = poolRoot(myPool);
        let total = 0, free = 0;
        try {
          const st = await fsp.statfs(rootAbs);
          total = st.blocks * st.bsize;
          free = st.bavail * st.bsize;
        } catch {}
        return { total, free };
      })(),
      defaultPool: myPool.id,
    });
  }

  /* ---------- Pools (client: list available storage drives) ---------- */
  if (route === '/api/pools' && req.method === 'GET') {
    const out = [];
    const list = scopedPools(req);
    for (const p of list) {
      const rootAbs = path.resolve(p.path);
      let total = 0, free = 0;
      const online = fs.existsSync(rootAbs);
      try {
        const st = await fsp.statfs(rootAbs);
        total = st.blocks * st.bsize;
        free = st.bavail * st.bsize;
      } catch {}
      const m = /^([A-Za-z]):[\\/]*$/.exec(rootAbs);
      let name = p.name;
      if (m) {
        const label = volumeLabels()[m[1].toUpperCase()] || '';
        name = label ? m[1].toUpperCase() + ': ' + label : m[1].toUpperCase() + ':';
      }
      out.push({ id: p.id, name, root: rootAbs, isDefault: !!(p.default) || (p.virtual && !list.some((x) => x.default)), total, free, used: total - free, online });
      virtualPool(rootAbs);
    }
    return json(res, 200, { pools: out });
  }

  /* ---------- Drives / pool config (admin) ---------- */
  if (route === '/api/drives' && req.method === 'GET') {
    if (!requireRole(req, res, 'admin')) return;
    const drives = await driveStats(listAvailableDrives());
    const poolOut = [];
    for (const p of config.pools) {
      const m = /^([A-Za-z]):[\\/]*$/.exec(path.resolve(p.path));
      let name = p.name;
      if (m) {
        const label = volumeLabels()[m[1].toUpperCase()] || '';
        name = label ? m[1].toUpperCase() + ': ' + label : m[1].toUpperCase() + ':';
      }
      poolOut.push({ id: p.id, name, path: poolRoot(p), root: poolRoot(p), isDefault: !!p.default });
    }
    return json(res, 200, { drives, pools: poolOut });
  }

  /* Danh sách ổ trên máy host (client app dùng để chọn ổ đồng bộ) */
  if (route === '/api/host-drives' && req.method === 'GET') {
    const drives = await driveStats(listAvailableDrives());
    return json(res, 200, { drives, root: path.resolve(config.root) });
  }

  /* Client chọn ổ đồng bộ → thư mục shared nằm trên ổ đó: <ổ>\shared */
  if (route === '/api/sync/activate' && req.method === 'POST') {
    if (!requireRole(req, res, 'admin')) return;
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const drive = path.resolve(String(body.drive || ''));
    if (!drive || drive.length < 3) return json(res, 400, { error: 'Thiếu ổ cần chọn.' });
    let st;
    try { st = fs.statSync(drive); } catch { st = null; }
    if (!st || !st.isDirectory()) return json(res, 400, { error: 'Ổ trên máy host không tồn tại: ' + drive });
    const newRoot = path.resolve(drive, 'shared');
    const curRoot = path.resolve(config.root);
    if (newRoot.toLowerCase() !== curRoot.toLowerCase() && isWithin(newRoot, curRoot)) {
      return json(res, 400, { error: 'Không thể đặt thư mục shared bên trong thư mục đang chia sẻ.' });
    }
    try { fs.mkdirSync(newRoot, { recursive: true }); } catch { return json(res, 400, { error: 'Không tạo được thư mục shared trên ổ này (kiểm tra quyền ghi).' }); }
    if (newRoot.toLowerCase() !== curRoot.toLowerCase()) {
      const old = curRoot;
      config.root = newRoot;
      for (const p of config.pools || []) { if (p.id === 'main') p.path = newRoot; }
      saveConfig();
      normalizePools();
      ensureDirs();
      uploadsDir = uploadsDirOf(defaultPool().id);
      trashDir = trashDirOf(defaultPool().id);
      logActivity('edit', `đã chuyển thư mục chia sẻ từ "${old}" sang "${newRoot}"`, req);
    }
    return json(res, 200, { ok: true, root: newRoot });
  }

  if (route === '/api/pools/config' && req.method === 'POST') {
    if (!requireRole(req, res, 'admin')) return;
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const drives = Array.isArray(body.drives) ? body.drives : null;
    if (!drives) return json(res, 400, { error: 'Thiếu danh sách ổ.' });
    const mainAbs = path.resolve(config.root);

    const nextPools = [];
    const seen = new Set([mainAbs.toLowerCase()]);
    let defaultId = null;

    for (const d of drives) {
      if (!d || !d.path) continue;
      if (!d.enabled && d.id !== 'main') continue;
      let abs;
      try { abs = path.resolve(String(d.path)); } catch { continue; }
      if (d.id === 'main' || abs.toLowerCase() === mainAbs.toLowerCase()) {
        nextPools.push({ id: 'main', name: d.name || nameForPath(mainAbs), path: mainAbs });
        if (d.isDefault) defaultId = 'main';
        continue;
      }
      if (seen.has(abs.toLowerCase())) continue;
      seen.add(abs.toLowerCase());
      if (!fs.existsSync(abs) || !fs.statSync(abs).isDirectory()) {
        return json(res, 400, { error: 'Ổ/thư mục không tồn tại: ' + abs });
      }
      const pid = String(d.id && /^[\w-]+$/.test(d.id) ? d.id : crypto.randomBytes(6).toString('base64url'));
      nextPools.push({ id: pid, name: d.name || nameForPath(abs), path: abs });
      if (d.isDefault) defaultId = pid;
    }

    if (!nextPools.find((p) => p.id === 'main')) {
      nextPools.unshift({ id: 'main', name: nameForPath(mainAbs), path: mainAbs });
    }
    if (!defaultId) defaultId = 'main';
    if (!nextPools.find((p) => p.id === defaultId)) defaultId = 'main';
    for (const p of nextPools) p.default = p.id === defaultId;

    const ids = new Set(nextPools.map((p) => p.id));
    const removed = config.pools.filter((p) => !ids.has(p.id));

    config.pools = nextPools;
    saveConfig();
    normalizePools();
    for (const p of config.pools) ensurePoolDirs(p);
    uploadsDir = uploadsDirOf(defaultPool().id);
    trashDir = trashDirOf(defaultPool().id);

    for (const r of removed) {
      logActivity('edit', `đã bỏ chia sẻ ổ "${r.name}" (${poolRoot(r)})`, req);
    }
    logActivity('edit', `đã cập nhật ổ lưu trữ (${config.pools.length} ổ, mặc định: ${defaultId})`, req);
    return json(res, 200, { ok: true, pools: config.pools.map((p) => ({ id: p.id, name: p.name, path: poolRoot(p), isDefault: !!p.default })) });
  }

  if (route === '/api/files' && req.method === 'GET') {
    const rel = url.searchParams.get('path') || '';
    const pool = url.searchParams.get('pool') || '';
    const abs = safeResolve(rel, pool, req);
    if (!abs) return json(res, 400, { error: 'Đường dẫn không hợp lệ.' });
    const scopeErr = checkScope(req, abs, pool && String(pool));
    if (scopeErr) return json(res, 403, scopeErr);
    let entries;
    try {
      const st = await fsp.stat(abs);
      if (!st.isDirectory()) return json(res, 400, { error: 'Không phải thư mục.' });
      const raw = await fsp.readdir(abs, { withFileTypes: true });
      const filtered = raw.filter((e) => e.name !== UPLOADS_DIRNAME && !e.name.startsWith('.cw-'));
      const BATCH = 128;
      entries = [];
      for (let i = 0; i < filtered.length; i += BATCH) {
        const slice = filtered.slice(i, i + BATCH);
        const batchResults = await Promise.all(slice.map(async (e) => {
          try {
            const s = await fsp.stat(path.join(abs, e.name));
            return { name: e.name, type: e.isDirectory() ? 'dir' : 'file', size: e.isDirectory() ? 0 : s.size, mtime: s.mtime.toISOString() };
          } catch {
            return { name: e.name, type: e.isDirectory() ? 'dir' : 'file', size: 0, mtime: new Date().toISOString() };
          }
        }));
        entries.push(...batchResults);
      }
    } catch {
      return json(res, 404, { error: 'Không tìm thấy thư mục.' });
    }
    entries.sort((a, b) => (a.type === b.type ? a.name.localeCompare(b.name, 'vi') : a.type === 'dir' ? -1 : 1));
    const poolObj = poolOfAbsForUser(abs, req);
    const myRel = relOfForUser(abs, req);
    const parent = myRel === '' ? null : relOfForUser(path.dirname(abs), req);
    return json(res, 200, { path: myRel, parent, entries, pool: poolObj.id, poolName: poolObj.name });
  }

  /* ---------- Deep file list (dùng cho đồng bộ 2 chiều) ---------- */
  if (route === '/api/files/deep' && req.method === 'GET') {
    const rel = url.searchParams.get('path') || '';
    const abs = safeResolve(rel, url.searchParams.get('pool') || '', req);
    if (!abs) return json(res, 400, { error: 'Đường dẫn không hợp lệ.' });
    const scopeErr = checkScope(req, abs, url.searchParams.get('pool') || '');
    if (scopeErr) return json(res, 403, scopeErr);
    let st;
    try { st = await fsp.stat(abs); } catch { return json(res, 200, { files: [], exists: false }); }
    if (!st.isDirectory()) return json(res, 200, { files: [], exists: false });
    const out = [];
    const stack = [abs];
    while (stack.length && out.length < 10000) {
      const d = stack.pop();
      let entries;
      try { entries = await fsp.readdir(d, { withFileTypes: true }); } catch { continue; }
      for (const e of entries) {
        if (e.name.startsWith('.') || e.name === UPLOADS_DIRNAME || e.name === TRASH_DIRNAME) continue;
        if (/^(thumbs\.db|desktop\.ini)$/i.test(e.name)) continue;
        if (/\.(cwtmp|part|tmp|download|crdownload|partial)$/i.test(e.name)) continue;
        const p = path.join(d, e.name);
        if (e.isDirectory() && !e.isSymbolicLink()) stack.push(p);
        else if (e.isFile()) {
          let s;
          try { s = await fsp.stat(p); } catch { continue; }
          out.push({ rel: path.relative(abs, p).replace(/\\/g, '/'), size: s.size, mtime: s.mtime.getTime() });
        }
      }
    }
    return json(res, 200, { files: out, truncated: out.length >= 10000 });
  }

const gpuProbe = require('./gpu-probe.js');
gpuProbe.probeGpu(FFMPEG_BIN).then((g) => {
  console.log(`🎮 [GPU Probe] ${g.statusTitle} (${g.primaryGpuName}) · Backend: ${g.activeBackend}`);
}).catch(() => {});

const { Worker } = require('worker_threads');
class HeicWorkerPool {
  constructor(size = 1) {
    this.size = size;
    this.workers = [];
    this.freeWorkers = [];
    this.queue = [];
    this.taskId = 1;
    this.pending = new Map();
    this.workerPath = path.join(__dirname, 'heic-worker.js');
    this.init();
  }
  init() {
    if (!fs.existsSync(this.workerPath)) return;
    for (let i = 0; i < this.size; i++) {
      this.spawnOne();
    }
  }
  spawnOne() {
    if (!fs.existsSync(this.workerPath) || this.workers.length >= this.size) return;
    try {
      const w = new Worker(this.workerPath);
      w.on('message', (msg) => {
        const cb = this.pending.get(msg.id);
        if (cb) {
          this.pending.delete(msg.id);
          cb.resolve(msg.ok);
        }
        this.freeWorkers.push(w);
        this.drain();
      });
      w.on('error', (err) => {
        this.workers = this.workers.filter((x) => x !== w);
        this.freeWorkers = this.freeWorkers.filter((x) => x !== w);
        setTimeout(() => this.spawnOne(), 1000);
      });
      w.on('exit', () => {
        this.workers = this.workers.filter((x) => x !== w);
        this.freeWorkers = this.freeWorkers.filter((x) => x !== w);
        setTimeout(() => this.spawnOne(), 1000);
      });
      this.workers.push(w);
      this.freeWorkers.push(w);
      this.drain();
    } catch (e) {
      console.error('Failed to spawn HeicWorker:', e && e.message);
    }
  }
  convert(abs, tmp, isPreview, vf, ffmpegBin) {
    return new Promise((resolve) => {
      const id = this.taskId++;
      this.pending.set(id, { resolve });
      this.queue.push({ id, abs, tmp, isPreview, vf, ffmpegBin });
      this.drain();
    });
  }
  drain() {
    while (this.freeWorkers.length > 0 && this.queue.length > 0) {
      const w = this.freeWorkers.shift();
      const task = this.queue.shift();
      try {
        w.postMessage(task);
      } catch (e) {
        const cb = this.pending.get(task.id);
        if (cb) {
          this.pending.delete(task.id);
          cb.resolve(false);
        }
        this.freeWorkers.push(w);
      }
    }
  }
}
const heicPool = new HeicWorkerPool(1);

const thumbQueue = [];
let activeThumbJobs = 0;
const MAX_CONCURRENT_THUMBS = 2;
const inFlightThumbs = new Map();

function scheduleThumbJob(taskFn) {
  return new Promise((resolve, reject) => {
    thumbQueue.push({ taskFn, resolve, reject });
    drainThumbQueue();
  });
}

function drainThumbQueue() {
  while (activeThumbJobs < MAX_CONCURRENT_THUMBS && thumbQueue.length > 0) {
    activeThumbJobs++;
    const job = thumbQueue.shift();
    job.taskFn()
      .then(job.resolve, job.reject)
      .finally(() => {
        activeThumbJobs--;
        drainThumbQueue();
      });
  }
}

function extractExifJpegThumb(buf) {
  if (!buf || buf.length < 256) return null;
  if (buf[0] !== 0xFF || buf[1] !== 0xD8) return null;
  let pos = 2;
  while (pos < buf.length - 4) {
    if (buf[pos] !== 0xFF) break;
    const marker = buf[pos + 1];
    if (marker === 0xDA || marker === 0xD9) break;
    const len = buf.readUInt16BE(pos + 2);
    if (marker === 0xE1) {
      const app1 = buf.slice(pos + 4, pos + 2 + len);
      if (app1.slice(0, 4).toString('ascii') === 'Exif') {
        const tiff = app1.slice(6);
        if (tiff.length > 8) {
          const isLE = tiff[0] === 0x49 && tiff[1] === 0x49;
          const r16 = (o) => isLE ? tiff.readUInt16LE(o) : tiff.readUInt16BE(o);
          const r32 = (o) => isLE ? tiff.readUInt32LE(o) : tiff.readUInt32BE(o);
          try {
            const ifd0 = r32(4);
            const num0 = r16(ifd0);
            const nextIfd = ifd0 + 2 + num0 * 12;
            if (nextIfd + 4 <= tiff.length) {
              const ifd1 = r32(nextIfd);
              if (ifd1 > 0 && ifd1 < tiff.length - 2) {
                const num1 = r16(ifd1);
                let thumbOff = 0, thumbLen = 0;
                for (let i = 0; i < num1; i++) {
                  const tag = r16(ifd1 + 2 + i * 12);
                  if (tag === 0x0201) thumbOff = r32(ifd1 + 2 + i * 12 + 8);
                  else if (tag === 0x0202) thumbLen = r32(ifd1 + 2 + i * 12 + 8);
                }
                if (thumbOff > 0 && thumbLen > 0 && thumbOff + thumbLen <= tiff.length) {
                  const thumbBuf = tiff.slice(thumbOff, thumbOff + thumbLen);
                  if (thumbBuf[0] === 0xFF && thumbBuf[1] === 0xD8) return thumbBuf;
                }
              }
            }
          } catch (e) {}
        }
      }
    }
    pos += 2 + len;
  }
  return null;
}

  /* ---------- Thumbnail cho danh sách tệp (ảnh/video, cache đĩa) ---------- */
  if (route === '/api/thumb' && req.method === 'GET') {
    const rel = url.searchParams.get('path') || '';
    const poolId = url.searchParams.get('pool') || '';
    const abs = safeResolve(rel, poolId, req);
    if (!abs) return json(res, 400, { error: 'Đường dẫn không hợp lệ.' });
    {
      const scopeErr = checkScope(req, abs, poolId);
      if (scopeErr) return json(res, 403, scopeErr);
    }
    if (!fs.existsSync(abs)) return json(res, 404, { error: 'Không tìm thấy tệp.' });
    const st = await fsp.stat(abs);
    if (!st.isFile()) return json(res, 404, { error: 'Không tìm thấy tệp.' });
    const ext = path.extname(abs).toLowerCase();
    const isImg = /\.(png|jpe?g|gif|webp|bmp|avif|heic|heif)$/i.test(ext);
    const isVid = /\.(mp4|webm|mkv|mov|m4v|avi|3gp|flv|wmv|mpg|mpeg|ts|m2ts|mts|vob|ogv|rm|rmvb)$/i.test(ext);
    if (!isImg && !isVid) return json(res, 404, { error: 'Không có thumbnail.' });
    if (!FFMPEG_BIN) return json(res, 404, { error: 'Server chưa có ffmpeg.' });
    const key = crypto.createHash('sha1').update(abs + '|' + st.size + '|' + st.mtimeMs).digest('hex').slice(0, 20);
    const etag = '"' + key + '"';
    if (req.headers['if-none-match'] === etag) { res.writeHead(304); return res.end(); }
    try { await fsp.mkdir(THUMB_DIR, { recursive: true }); } catch {}
    const fp = path.join(THUMB_DIR, key + '.jpg');
    if (!fs.existsSync(fp)) {
      if (!inFlightThumbs.has(key)) {
        const p = scheduleThumbJob(async () => {
          if (fs.existsSync(fp)) return true;
          const tmp = fp + '.tmp-' + crypto.randomBytes(3).toString('hex');
          const vf = "scale='min(160,iw)':'min(160,ih)':force_original_aspect_ratio=decrease";
          const hwArgs = gpuProbe.getHwAccelArgs(gpuProbe.getCachedInfo());
          const mkArgs = (ss) => {
            const a = ['-hide_banner', '-loglevel', 'error', '-nostdin', '-y'];
            if (hwArgs && hwArgs.length) a.push(...hwArgs);
            if (ss != null) a.push('-ss', String(ss));
            a.push('-i', abs, '-frames:v', '1', '-vf', vf, '-q:v', '5', '-f', 'image2', tmp);
            return a;
          };
          const run = (args) => new Promise((resolve, reject) => {
            execFile(FFMPEG_BIN, args, { windowsHide: true, timeout: 10000 }, (err) => err ? reject(err) : resolve());
          });
          const isHeic = /\.(heic|heif)$/i.test(ext);
          try {
            if (isHeic) {
              const ok = await heicPool.convert(abs, tmp, false, vf, FFMPEG_BIN);
              if (!ok && !fs.existsSync(tmp) && FFMPEG_BIN) {
                try { await run(mkArgs(null)); } catch {}
              }
            } else if (isVid) {
              try { await run(mkArgs(1)); } catch {}
              if (!fs.existsSync(tmp)) { try { await run(mkArgs(null)); } catch {} }
            } else {
              // 1. Trích xuất EXIF thumbnail trực tiếp từ ảnh JPEG (0.05ms, 0% CPU)
              if (/\.(jpe?g)$/i.test(ext)) {
                try {
                  const headBuf = Buffer.alloc(Math.min(st.size, 160 * 1024));
                  const fd = fs.openSync(abs, 'r');
                  const bytesRead = fs.readSync(fd, headBuf, 0, headBuf.length, 0);
                  fs.closeSync(fd);
                  const jpegThumb = extractExifJpegThumb(headBuf.slice(0, bytesRead));
                  if (jpegThumb) {
                    await fsp.writeFile(tmp, jpegThumb);
                  }
                } catch (e) {}
              }
              // 2. Với ảnh JPG/PNG nhỏ (<250KB), copy trực tiếp làm thumbnail siêu nhanh trong 1ms
              if (!fs.existsSync(tmp) && st.size < 250 * 1024 && /\.(jpe?g|png|webp)$/i.test(ext)) {
                try { await fsp.copyFile(abs, tmp); } catch {}
              }
              if (!fs.existsSync(tmp) && FFMPEG_BIN) {
                await run(mkArgs(null));
              }
            }
          } catch {}
          if (fs.existsSync(tmp)) {
            try { await fsp.rename(tmp, fp); return true; } catch { return false; }
          }
          return false;
        }).finally(() => {
          inFlightThumbs.delete(key);
        });
        inFlightThumbs.set(key, p);
      }
      const ok = await inFlightThumbs.get(key);
      if (!ok && !fs.existsSync(fp)) return json(res, 404, { error: 'Không tạo được thumbnail.' });
      try {
        const entries = await fsp.readdir(THUMB_DIR);
        if (entries.length > 50000) {
          const stats = entries.map((n) => {
            try { return { n, m: fs.statSync(path.join(THUMB_DIR, n)).mtimeMs }; } catch { return null; }
          }).filter(Boolean);
          stats.sort((a, b) => a.m - b.m);
          for (const item of stats.slice(0, 5000)) {
            try { fs.unlinkSync(path.join(THUMB_DIR, item.n)); } catch {}
          }
        }
      } catch {}
    }
    const fst = await fsp.stat(fp);
    res.writeHead(200, {
      'Content-Type': 'image/jpeg',
      'Content-Length': fst.size,
      'Cache-Control': 'public, max-age=31536000, immutable',
      'ETag': etag,
    });
    const rs = fs.createReadStream(fp);
    rs.on('data', (c) => { net.tx += c.length; });
    rs.pipe(res);
    return rs;
  }

  /* ---------- Video xem trực tiếp (remux/transcode để MKV có tiếng) ---------- */
  if (route === '/api/video' && req.method === 'GET') {
    const rel = url.searchParams.get('path') || '';
    const abs = safeResolve(rel, url.searchParams.get('pool') || '', req);
    if (!abs) return json(res, 400, { error: 'Đường dẫn không hợp lệ.' });
    const scopeErr0 = checkScope(req, abs, url.searchParams.get('pool') || '');
    if (scopeErr0) return json(res, 403, scopeErr0);
    if (!fs.existsSync(abs)) return json(res, 404, { error: 'Không tìm thấy tệp.' });

    let streams = [];
    try { streams = FFPROBE_BIN ? await probeStreams(abs) : await probeViaFfmpeg(abs); } catch {}
    const vStream = streams.find((s) => s.codec_type === 'video');
    const aStream = streams.find((s) => s.codec_type === 'audio');
    const isApple = /iPhone|iPad|iPod|Macintosh|CFNetwork|Darwin|WebKit/i.test(req.headers['user-agent'] || '') || url.searchParams.get('ios') === '1';
    let vNative = !vStream || (isApple ? ['h264', 'hevc', 'h265'].includes(vStream.codec_name) : NATIVE_VIDEO.has(vStream.codec_name));
    let aNative = !aStream || (isApple ? ['aac', 'mp3', 'flac', 'alac'].includes(aStream.codec_name) : NATIVE_AUDIO.has(aStream.codec_name));
    const ext = path.extname(abs).toLowerCase();
    const isDirectClient = url.searchParams.get('raw') === '1';
    const directContainers = isApple ? ['.mp4', '.m4v', '.mov'] : ['.mp4', '.webm', '.m4v', '.mov', '.mkv', '.avi', '.ts', '.m2ts', '.mts', '.ogv', '.3gp', '.flv', '.wmv'];
    const webContainer = directContainers.includes(ext);

    const name = path.basename(abs);
    if (isDirectClient || (vNative && aNative && webContainer)) {
      const stream = await streamFile(req, res, abs, name, true);
      const isRangeV = !!req.headers.range;
      let got = 0;
      stream.on('data', (c) => { got += c.length; });
      res.once('close', () => {
        if ((!isRangeV && got > 0) || got > 256 * 1024) {
          logActivity('download', `đã xem "${name}"`, req, null, 'view|' + abs.toLowerCase(), 5 * 60 * 1000);
        }
      });
      return stream;
    }
    if (!FFMPEG_BIN) return json(res, 503, { error: 'Video này cần chuyển đổi âm thanh nhưng server chưa có ffmpeg.' });

    const startSec = parseFloat(url.searchParams.get('ss') || '0');
    const useWebm = !isApple && vStream && ['vp8', 'vp9', 'av1'].includes(vStream.codec_name);
    const args = [
      '-hide_banner', '-loglevel', 'error', '-nostdin',
      '-fflags', '+genpts+igndts+discardcorrupt',
      '-avoid_negative_ts', 'make_zero'
    ];
    if (startSec > 0) {
      args.push('-ss', String(startSec));
    }
    args.push(
      '-i', abs,
      '-map', '0:v:0?',
      '-map', '0:a:0?',
      '-sn', '-dn',
      '-max_muxing_queue_size', '2048'
    );
    if (vNative) {
      args.push('-c:v', 'copy');
    } else {
      args.push('-c:v', useWebm ? 'libvpx-vp9' : 'libx264', '-preset', 'veryfast', '-crf', '23', '-pix_fmt', 'yuv420p');
    }
    if (aNative) {
      args.push('-c:a', 'copy');
    } else {
      args.push('-c:a', useWebm ? 'libopus' : 'aac', '-b:a', '256k', '-ac', '2', '-af', 'aresample=async=1000:min_hard_comp=0.100000:first_pts=0');
    }
    if (useWebm) {
      args.push('-deadline', 'realtime', '-cpu-used', '5', '-f', 'webm', 'pipe:1');
    } else {
      args.push('-movflags', 'empty_moov+frag_keyframe+default_base_moof', '-f', 'mp4', 'pipe:1');
    }

    res.writeHead(200, {
      'Content-Type': useWebm ? 'video/webm' : 'video/mp4',
      'Cache-Control': 'no-store',
      'X-CW-Transcode': vNative ? 'audio' : 'full',
    });
    const proc = spawnTool(FFMPEG_BIN, args, { windowsHide: true });
    proc.on('error', () => { try { res.end(); } catch {} });
    proc.stdout.pipe(res);
    proc.stderr.resume();
    let transferred = 0;
    proc.stdout.on('data', (c) => { transferred += c.length; net.tx += c.length; });
    const cleanup = () => { try { proc.kill(); } catch {} };
    res.on('close', () => {
      cleanup();
      if (transferred > 256 * 1024) logActivity('download', `đã xem "${name}"`, req, null, 'view|' + abs.toLowerCase(), 5 * 60 * 1000);
    });
    proc.on('exit', () => { try { res.end(); } catch {} });
    return;
  }

  if (route === '/api/stats' && req.method === 'GET') {
    const stats = await walkStats(config.root);
    return json(res, 200, { ...stats, root: path.resolve(config.root) });
  }

  /* ---------- GPU / Hardware Acceleration Diagnostic & Config ---------- */
  if (route === '/api/gpu/status' && req.method === 'GET') {
    const refresh = url.searchParams.get('refresh') === '1';
    const info = await gpuProbe.probeGpu(FFMPEG_BIN, refresh);
    return json(res, 200, info);
  }

  if (route === '/api/gpu/mode' && req.method === 'POST') {
    let body;
    try { body = readJsonBody(await readBody(req, 4096), 4096); } catch { body = {}; }
    const newMode = gpuProbe.setGpuMode(body.mode);
    const info = await gpuProbe.probeGpu(FFMPEG_BIN, false);
    return json(res, 200, { ok: true, mode: newMode, info });
  }

  /* ---------- Thống kê dung lượng Cache ---------- */
  if (route === '/api/cache/info' && req.method === 'GET') {
    try {
      await fsp.mkdir(THUMB_DIR, { recursive: true });
      const files = await fsp.readdir(THUMB_DIR);
      let totalBytes = 0;
      for (const f of files) {
        try { totalBytes += fs.statSync(path.join(THUMB_DIR, f)).size; } catch {}
      }
      const mb = (totalBytes / (1024 * 1024)).toFixed(1);
      return json(res, 200, { ok: true, count: files.length, sizeBytes: totalBytes, sizeFormatted: mb + ' MB' });
    } catch (e) {
      return json(res, 500, { error: e.message });
    }
  }

  /* ---------- Xóa sạch bộ nhớ đệm Cache ---------- */
  if (route === '/api/cache/clear' && req.method === 'POST') {
    if (!isAdmin(req)) return json(res, 403, { error: 'Chỉ Admin mới có quyền xóa cache.' });
    try {
      await fsp.mkdir(THUMB_DIR, { recursive: true });
      const files = await fsp.readdir(THUMB_DIR);
      let deleted = 0;
      for (const f of files) {
        try { fs.unlinkSync(path.join(THUMB_DIR, f)); deleted++; } catch {}
      }
      return json(res, 200, { ok: true, deletedCount: deleted });
    } catch (e) {
      return json(res, 500, { error: e.message });
    }
  }

  if (route === '/api/dashboard' && req.method === 'GET') {

    if (!requireRole(req, res, "admin")) return;
    return json(res, 200, await buildDashboard(req));
  }

  /* ---------- Share management ---------- */
  if (route === '/api/share' && req.method === 'POST') {

    if (!requireRole(req, res, "editor")) return;
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const abs = safeResolve(body.path, body.pool, req);
    if (!abs) return json(res, 400, { error: 'Đường dẫn không hợp lệ.' });
    const sharePool = poolOfAbsForUser(abs, req);
    if (abs === path.resolve(sharePool.path)) return json(res, 400, { error: 'Đường dẫn không hợp lệ.' });
    {
      const scopeErr = checkScope(req, abs, '');
      if (scopeErr) return json(res, 403, scopeErr);
    }
    if (!fs.existsSync(abs)) return json(res, 404, { error: 'Không tìm thấy tệp/thư mục.' });
    const st = await fsp.stat(abs);
    const id = crypto.randomBytes(9).toString('base64url');
    const ttlMs = Number(body.ttlHours) > 0 ? Number(body.ttlHours) * 3600 * 1000 : 7 * 24 * 3600 * 1000;
    const maxUses = body.once ? 1 : Math.max(0, Number(body.maxUses) || 0);
    const share = {
      id, rel: relOfForUser(abs, req), pool: sharePool.id, abs,
      name: path.basename(abs),
      type: st.isDirectory() ? 'dir' : 'file',
      created: new Date().toISOString(),
      expires: Date.now() + ttlMs,
      maxUses, uses: 0,
    };
    shares.unshift(share);
    saveShares();
    logActivity('share', `đã tạo link chia sẻ "${share.name}"`, req);
    const ts = await getTailscale(false);
    const tsIp = (ts && ts.installed && ts.running && ts.selfIp) ? ts.selfIp : '';
    const shareUrl = tsIp ? `http://${tsIp}:${config.port}/s/?id=${encodeURIComponent(id)}` : '';
    return json(res, 200, { id, name: share.name, type: share.type, expires: share.expires, maxUses, shareUrl, tailscaleIp: tsIp });
  }

  if (route === '/api/shares' && req.method === 'GET') {
    return json(res, 200, { shares: shares.map((s) => ({ ...s, dead: !shareValid(s) })) });
  }

  if (route === '/api/invite' && req.method === 'POST') {

    if (!requireRole(req, res, "admin")) return;
    invite.code = crypto.randomBytes(4).toString('hex');
    invite.created = Date.now();
    logActivity('share', 'đã tạo mã mời kết nối điện thoại', req);
    return json(res, 200, { code: invite.code, expiresAt: invite.created + invite.ttl });
  }

  if (route === '/api/shares' && req.method === 'DELETE') {

    if (!requireRole(req, res, "editor")) return;
    const id = url.searchParams.get('id') || '';
    const i = shares.findIndex((s) => s.id === id);
    if (i < 0) return json(res, 404, { error: 'Link không tồn tại.' });
    const [removed] = shares.splice(i, 1);
    saveShares();
    logActivity('share', `đã thu hồi link chia sẻ "${removed.name}"`, req);
    return json(res, 200, { ok: true });
  }

  /* ---------- Direct Stream / File Upload ---------- */
  if ((route === '/api/upload/direct' || route === '/api/upload') && req.method === 'POST') {
    if (!requireRole(req, res, "editor")) return;
    const poolId = url.searchParams.get('pool') || '';
    let targetPath = url.searchParams.get('path') || '';
    const fileName = url.searchParams.get('name') || '';
    if (fileName && !targetPath.endsWith(fileName)) {
      targetPath = targetPath ? `${targetPath.replace(/\/+$/, '')}/${fileName}` : fileName;
    }
    if (!targetPath) return json(res, 400, { error: 'Thiếu đường dẫn đích (path).' });

    const abs = safeResolve(targetPath, poolId, req);
    if (!abs) return json(res, 400, { error: 'Đường dẫn không hợp lệ.' });
    const scopeErr = checkScope(req, abs, poolId);
    if (scopeErr) return json(res, 403, scopeErr);

    const dir = path.dirname(abs);
    try { fs.mkdirSync(dir, { recursive: true }); } catch (e) {
      return json(res, 500, { error: 'Không thể tạo thư mục: ' + e.message });
    }

    const tmpPath = abs + '.cwtmp_' + Date.now();
    const ws = fs.createWriteStream(tmpPath);

    req.pipe(ws);

    ws.on('finish', async () => {
      try {
        if (fs.existsSync(abs)) {
          try { fs.unlinkSync(abs); } catch {}
        }
        fs.renameSync(tmpPath, abs);
        const st = fs.statSync(abs);
        logActivity('upload', `đã tải lên "${path.basename(abs)}" (${fmtBytes(st.size)})`, req);
        return json(res, 200, { ok: true, name: path.basename(abs), size: st.size });
      } catch (err) {
        try { fs.unlinkSync(tmpPath); } catch {}
        return json(res, 500, { error: 'Lỗi ghi tệp: ' + err.message });
      }
    });

    ws.on('error', (err) => {
      try { fs.unlinkSync(tmpPath); } catch {}
      return json(res, 500, { error: 'Lỗi stream: ' + err.message });
    });

    req.on('error', (err) => {
      try { fs.unlinkSync(tmpPath); } catch {}
      ws.destroy();
      return json(res, 500, { error: 'Lỗi truyền tải: ' + err.message });
    });
    return;
  }

  /* ---------- Chunked upload ---------- */
  if (route === '/api/upload/init' && req.method === 'POST') {

    if (!requireRole(req, res, "editor")) return;
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const poolId = String(body.pool || '') || defaultPoolOf(req).id;
    const pool = poolCtx(req, poolId);
    if (!pool) return json(res, 400, { error: 'Ổ lưu trữ không tồn tại.' });
    if (!poolAllowed(req, poolId)) return json(res, 403, { error: 'Tài khoản này không có quyền ghi vào ổ đó.' });
    if (!fs.existsSync(poolRoot(pool))) return json(res, 400, { error: 'Ổ lưu trữ đang được rút ra.' });
    const abs = safeResolve(body.path, poolId, req);
    const size = Number(body.size) || 0;
    if (!abs || abs === poolRoot(pool)) return json(res, 400, { error: 'Đường dẫn không hợp lệ.' });
    const rel = relOfForUser(abs, req);
    const upDir = uploadsDirOf(poolId, req);
    for (const [id, meta] of partUploads) {
      if (meta.rel === rel && meta.size === size && (meta.pool || 'main') === poolId) {
        const st = await fsp.stat(path.join(upDir, id + '.part')).catch(() => null);
        if (st) {
          meta.lastActive = Date.now();
          return json(res, 200, { uploadId: id, offset: st.size, resumed: true });
        }
        partUploads.delete(id);
      }
    }
    const id = crypto.randomBytes(10).toString('hex');
    await fsp.mkdir(upDir, { recursive: true });
    await fsp.writeFile(path.join(upDir, id + '.part'), '');
    const meta = { id, rel, size, pool: poolId, poolRoot: path.resolve(pool.path), created: Date.now(), lastActive: Date.now(), name: path.basename(abs) };
    partUploads.set(id, meta);
    await fsp.writeFile(path.join(upDir, id + '.meta'), JSON.stringify(meta));
    const tr = { id, name: meta.name, dir: 'up', path: path.posix.dirname(rel), total: size, done: 0, started: Date.now(), status: 'active', pool: poolId };
    transfers.set(id, tr);
    return json(res, 200, { uploadId: id, offset: 0, pool: poolId });
  }

  if (route === '/api/upload/status' && req.method === 'GET') {
    const poolId = url.searchParams.get('pool') || defaultPoolOf(req).id;
    const abs0 = safeResolve(url.searchParams.get('path') || '', poolId, req);
    const rel = abs0 ? relOfForUser(abs0, req) : '';
    const size = Number(url.searchParams.get('size')) || 0;
    if (rel === '' && !url.searchParams.get('path')) return json(res, 400, { error: 'Thiếu path.' });
    const upDir = uploadsDirOf(poolId, req);
    for (const [id, meta] of partUploads) {
      if (meta.rel === rel && meta.size === size && (meta.pool || 'main') === poolId) {
        const st = await fsp.stat(path.join(upDir, id + '.part')).catch(() => null);
        if (st && st.size > 0) return json(res, 200, { uploadId: id, offset: st.size });
      }
    }
    return json(res, 200, { uploadId: null, offset: 0 });
  }

  if (route === '/api/upload/chunk' && req.method === 'POST') {

    if (!requireRole(req, res, "editor")) return;
    const id = url.searchParams.get('id') || '';
    const meta = partUploads.get(id);
    if (!meta) return json(res, 404, { error: 'Phiên upload không tồn tại (server có thể đã khởi động lại).' });
    const offset = Number(url.searchParams.get('offset')) || 0;
    const partPath = path.join(meta.poolRoot ? upDirOfAbs(meta.poolRoot) : uploadsDirOf(meta.pool || 'main'), id + '.part');
    const st = await fsp.stat(partPath).catch(() => null);
    if (!st) return json(res, 404, { error: 'Phiên upload không tồn tại.' });
    if (offset > st.size) return json(res, 409, { error: 'Offset không khớp.', serverOffset: st.size });
    let fd;
    try {
      fd = await fsp.open(partPath, 'r+');
      if (offset < st.size) await fd.truncate(offset);
      await new Promise((resolve, reject) => {
        const ws = fd.createWriteStream({ start: offset });
        let wrote = 0;
        req.on('data', (c) => {
          wrote += c.length;
          net.rx += c.length;
          const tr = transfers.get(id);
          if (tr) { tr.done += c.length; if (tr.done > tr.total) tr.done = tr.total; }
        });
        req.on('error', () => { ws.destroy(); reject(new Error('client disconnected')); });
        ws.on('error', reject);
        ws.on('finish', resolve);
        req.pipe(ws);
      });
      meta.lastActive = Date.now();
      const after = await fsp.stat(partPath);
      if (after.size > meta.size) {
        await fd.truncate(meta.size);
        after.size = meta.size;
      }
      return json(res, 200, { offset: after.size, done: after.size >= meta.size });
    } catch (e) {
      return json(res, 500, { error: 'Ghi chunk thất bại: ' + e.message });
    } finally {
      if (fd) await fd.close().catch(() => {});
    }
  }

  if (route === '/api/upload/complete' && req.method === 'POST') {

    if (!requireRole(req, res, "editor")) return;
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const id = String(body.uploadId || '');
    const meta = partUploads.get(id);
    if (!meta) return json(res, 404, { error: 'Phiên upload không tồn tại.' });
    const poolId = meta.pool || 'main';
    if (!poolAllowed(req, poolId)) return json(res, 403, { error: 'Tài khoản này không có quyền ghi vào ổ đó.' });
    const cUpDir = meta.poolRoot ? upDirOfAbs(meta.poolRoot) : uploadsDirOf(poolId, req);
    const partPath = path.join(cUpDir, id + '.part');
    const st = await fsp.stat(partPath).catch(() => null);
    if (!st) return json(res, 404, { error: 'Dữ liệu upload không còn.' });
    if (st.size < meta.size) return json(res, 409, { error: 'Chưa đủ dữ liệu.', serverOffset: st.size });
    const abs = meta.poolRoot ? path.resolve(meta.poolRoot, String(meta.rel || '').replace(/\\/g, '/').replace(/^\/+/, '')) : safeResolve(meta.rel, poolId, req);
    if (!abs) return json(res, 400, { error: 'Đường dẫn không hợp lệ.' });
    const scopeErrU = checkScope(req, abs, poolId);
    if (scopeErrU) return json(res, 403, scopeErrU);
    await ensureDir(path.dirname(abs));
    let target = abs;
    if (fs.existsSync(abs)) {
      const cur = await fsp.stat(abs).catch(() => null);
      if (cur && cur.isDirectory()) target = uniqueTarget(abs);
    }
    await safeMoveFile(partPath, target);
    await fsp.rm(path.join(cUpDir, id + '.meta'), { force: true }).catch(() => {});
    partUploads.delete(id);
    const tr = transfers.get(id);
    if (tr) { tr.status = 'done'; scheduleRemove(id); }
    const done = await fsp.stat(target);
    const dirRel = path.posix.dirname(meta.rel);
    logActivity('upload', `đã tải lên "${meta.name}" vào /${dirRel === '.' ? '' : dirRel}`, req);
    logRecent('upload', relOfForUser(target, req), req, poolId);
    return json(res, 200, { name: path.basename(target), size: done.size, mtime: done.mtime.toISOString(), rel: relOfForUser(target, req), pool: poolId });
  }

  if (route === '/api/upload/abort' && req.method === 'POST') {

    if (!requireRole(req, res, "editor")) return;
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const id = String(body.uploadId || '');
    const meta = partUploads.get(id);
    if (!meta) return json(res, 200, { ok: true });
    if (!poolAllowed(req, meta.pool || 'main')) return json(res, 403, { error: 'Tài khoản này không có quyền ghi vào ổ đó.' });
    const upDir = meta.poolRoot ? upDirOfAbs(meta.poolRoot) : uploadsDirOf(meta.pool || 'main', req);
    await fsp.rm(path.join(upDir, id + '.part'), { force: true }).catch(() => {});
    await fsp.rm(path.join(upDir, id + '.meta'), { force: true }).catch(() => {});
    partUploads.delete(id);
    const tr = transfers.get(id);
    if (tr) { tr.status = 'error'; scheduleRemove(id); }
    return json(res, 200, { ok: true });
  }

  /* ---------- Legacy single-file endpoints ---------- */
  if (route === '/api/file') {
    const rel = url.searchParams.get('path') || '';
    const poolId = url.searchParams.get('pool') || '';
    const abs = safeResolve(rel, poolId, req);
    if (!abs) return json(res, 400, { error: 'Đường dẫn không hợp lệ.' });
    {
      const scopeErr = checkScope(req, abs, poolId);
      if (scopeErr) return json(res, 403, scopeErr);
    }
    const p = poolOfAbsForUser(abs, req);
    if (abs === path.resolve(p.path)) return json(res, 400, { error: 'Không hợp lệ.' });

    if (req.method === 'GET') {
      let st;
      try { st = await fsp.stat(abs); } catch { return json(res, 404, { error: 'Không tìm thấy tệp.' }); }
      if (st.isDirectory()) {
        logActivity('download', `đã tải xuống thư mục "${path.basename(abs)}" (ZIP)`, req);
        logRecent('download', relOfForUser(abs, req), req, p.id);
        await streamZip(abs, res, path.basename(abs));
        return;
      }
      try {
        const isPreview = url.searchParams.get('preview') === '1';
        const name = path.basename(abs);
        const ext = path.extname(abs).toLowerCase();
        const isHeic = /\.(heic|heif)$/i.test(ext);
        if (isPreview && isHeic) {
          const prevKey = crypto.createHash('sha1').update('prev|' + abs + '|' + st.size + '|' + st.mtimeMs).digest('hex').slice(0, 20);
          try { await fsp.mkdir(THUMB_DIR, { recursive: true }); } catch {}
          const prevFp = path.join(THUMB_DIR, prevKey + '.jpg');
          if (!fs.existsSync(prevFp)) {
            const tmpPrev = prevFp + '.tmp-' + crypto.randomBytes(3).toString('hex');
            const ok = await heicPool.convert(abs, tmpPrev, true, null, null);
            if (ok && fs.existsSync(tmpPrev)) {
              try { await fsp.rename(tmpPrev, prevFp); } catch {}
            }
          }
          if (fs.existsSync(prevFp)) {
            const prevSt = await fsp.stat(prevFp);
            res.writeHead(200, {
              'Content-Type': 'image/jpeg',
              'Content-Length': prevSt.size,
              'Cache-Control': 'public, max-age=31536000, immutable',
              'ETag': '"' + prevKey + '"',
              'Accept-Ranges': 'bytes'
            });
            const rs = fs.createReadStream(prevFp);
            rs.pipe(res);
            return;
          }
        }
        const stream = await streamFile(req, res, abs, name, isPreview);
        const id = crypto.randomBytes(4).toString('hex');
        const isRange = !!req.headers.range;
        const tr = { id, name, dir: 'down', path: relOfForUser(abs, req), total: Number(res.getHeader('Content-Length')) || 0, done: 0, started: Date.now(), status: 'active', pool: p.id };
        transfers.set(id, tr);
        stream.on('data', (c) => { tr.done += c.length; });
        stream.on('end', () => {
          const meaningful = (!isRange && tr.done > 0) || tr.done > 256 * 1024;
          if (isPreview) {
            if (meaningful) logActivity('download', `đã xem "${name}"`, req, null, 'view|' + abs.toLowerCase(), 5 * 60 * 1000);
          } else {
            if (meaningful) {
              logActivity('download', `đã tải xuống "${name}"`, req, null, 'dl|' + abs.toLowerCase(), 60000);
              logRecent('download', relOfForUser(abs, req), req, p.id);
            }
          }
          scheduleRemove(id);
        });
        stream.on('error', () => { tr.status = 'error'; scheduleRemove(id); });
        res.on('close', () => { if (tr.status === 'active') { tr.status = 'done'; scheduleRemove(id); } });
      } catch {
        return json(res, 404, { error: 'Không tìm thấy tệp.' });
      }
      return;
    }

    if (req.method === 'PUT') {

      if (!requireRole(req, res, "editor")) return;
      const total = Number(req.headers['content-length'] || 0);
      const id = crypto.randomBytes(4).toString('hex');
      const tr = { id, name: path.basename(abs), dir: 'up', path: relOfForUser(abs, req), total, done: 0, started: Date.now(), status: 'active', pool: p.id };
      transfers.set(id, tr);
      await ensureDir(path.dirname(abs));
      const tmp = abs + '.cwtmp';
      try {
        await new Promise((resolve, reject) => {
          const ws = fs.createWriteStream(tmp);
          req.on('data', (c) => { tr.done += c.length; net.rx += c.length; });
          req.pipe(ws);
          ws.on('finish', resolve);
          ws.on('error', reject);
          req.on('error', () => { ws.destroy(); reject(new Error('stream')); });
        });
        await safeMoveFile(tmp, abs);
        tr.status = 'done';
        scheduleRemove(id);
        const dirRel = path.posix.dirname(relOfForUser(abs, req));
        logActivity('upload', `đã tải lên "${tr.name}" vào ${p.name}/ ${dirRel === '.' ? '' : dirRel}`, req);
        logRecent('upload', relOfForUser(abs, req), req, p.id);
        const st = await fsp.stat(abs);
        return json(res, 200, { name: tr.name, size: st.size, mtime: st.mtime.toISOString(), pool: p.id });
      } catch (e) {
        try { await fsp.unlink(tmp); } catch {}
        tr.status = 'error';
        scheduleRemove(id);
        return json(res, 500, { error: 'Lưu tệp thất bại: ' + e.message });
      }
    }

    if (req.method === 'DELETE') {

      if (!requireRole(req, res, "editor")) return;
      try {
        const trashId = await moveToTrash(abs, req);
        logActivity('delete', `đã xóa "${relOfForUser(abs, req)}" (chuyển vào thùng rác)`, req);
        return json(res, 200, { ok: true, trash: trashId });
      } catch {
        return json(res, 404, { error: 'Không tìm thấy tệp/thư mục.' });
      }
    }
    return json(res, 405, { error: 'Method not allowed' });
  }

  if (route === '/api/save' && req.method === 'POST') {

    if (!requireRole(req, res, "editor")) return;
    let body;
    try { body = readJsonBody(await readBody(req, JSON_BODY_LIMIT), JSON_BODY_LIMIT); }
    catch (e) { return json(res, String(e.message).includes('PAYLOAD') ? 413 : 400, { error: 'Dữ liệu không hợp lệ hoặc quá lớn.' }); }
    const abs = safeResolve(body.path, body.pool, req);
    if (!abs) return json(res, 400, { error: 'Đường dẫn không hợp lệ.' });
    {
      const scopeErr = checkScope(req, abs, body.pool || '');
      if (scopeErr) return json(res, 403, scopeErr);
    }
    const p = poolOfAbsForUser(abs, req);
    if (abs === path.resolve(p.path)) return json(res, 400, { error: 'Đường dẫn không hợp lệ.' });
    const content = String(body.content ?? '');
    if (Buffer.byteLength(content, 'utf8') > TEXT_SAVE_LIMIT) return json(res, 413, { error: 'Tệp quá lớn để sửa trực tiếp (tối đa 5MB).' });
    await ensureDir(path.dirname(abs));
    await fsp.writeFile(abs, content, 'utf8');
    logActivity('edit', `đã sửa tệp "${path.basename(abs)}"`, req);
    logRecent('edit', relOfForUser(abs, req), req, p.id);
    return json(res, 200, { ok: true });
  }

  if (route === '/api/rename' && req.method === 'POST') {

    if (!requireRole(req, res, "editor")) return;
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const abs = safeResolve(body.path, body.pool, req);
    const newName = String(body.newName || '').trim();
    if (!abs || !newName || /[\/\\]/.test(newName) || newName === '.' || newName === '..') {
      return json(res, 400, { error: 'Tên không hợp lệ.' });
    }
    {
      const scopeErr = checkScope(req, abs, body.pool || '');
      if (scopeErr) return json(res, 403, scopeErr);
    }
    const p = poolOfAbsForUser(abs, req);
    const target = path.join(path.dirname(abs), newName);
    if (!target.startsWith(path.resolve(p.path))) return json(res, 400, { error: 'Đường dẫn không hợp lệ.' });
    try {
      await fsp.rename(abs, target);
      logActivity('rename', `đã đổi tên "${path.basename(abs)}" thành "${newName}"`, req);
      return json(res, 200, { ok: true });
    } catch {
      return json(res, 409, { error: 'Không đổi tên được (có thể tên đã tồn tại).' });
    }
  }

  if (route === '/api/mkdir' && req.method === 'POST') {

    if (!requireRole(req, res, "editor")) return;
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const abs = safeResolve(body.path, body.pool, req);
    if (!abs) return json(res, 400, { error: 'Đường dẫn không hợp lệ.' });
    {
      const scopeErr = checkScope(req, abs, body.pool || '');
      if (scopeErr) return json(res, 403, scopeErr);
    }
    const p = poolOfAbsForUser(abs, req);
    try {
      const existed = fs.existsSync(abs);
      await ensureDir(abs);
      if (!existed) logActivity('mkdir', `đã tạo thư mục "${p.name}/ ${relOfForUser(abs, req)}"`, req);
      return json(res, 200, { ok: true });
    } catch {
      return json(res, 409, { error: 'Không tạo được thư mục.' });
    }
  }

  /* ---------- Copy/Move items (also across storage drives) + progress ---------- */
  if (route === '/api/move/progress' && req.method === 'GET') {
    const job = copyJobs.get(url.searchParams.get('id') || '');
    if (!job) return json(res, 404, { error: 'Không tìm thấy tiến trình.' });
    return json(res, 200, job);
  }
  if (route === '/api/move' && req.method === 'POST') {
    if (!requireRole(req, res, 'editor')) return;
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const items = Array.isArray(body.items) ? body.items : [];
    const destPoolId = String(body.toPool || '') || defaultPoolOf(req).id;
    const destPool = userPools(req).find((p) => p.id === destPoolId);
    const destRel = String(body.toPath || '').replace(/\\/g, '/').replace(/^\/+/, '');
    const mode = body.copy ? 'copy' : 'move';
    if (!destPool) return json(res, 400, { error: 'Ổ đích không tồn tại.' });
    if (!fs.existsSync(path.resolve(destPool.path))) return json(res, 400, { error: 'Ổ đích đang được rút ra.' });
    {
      const scopeErr = checkScope(req, path.resolve(destPool.path), destPool.id);
      if (scopeErr) return json(res, 403, scopeErr);
    }
    const destDir = path.resolve(path.resolve(destPool.path), destRel);
    if (!isWithin(destDir, path.resolve(destPool.path))) return json(res, 400, { error: 'Thư mục đích không hợp lệ.' });
    if (!items.length) return json(res, 400, { error: 'Chưa chọn mục nào.' });

    const resolved = [];
    for (const it of items) {
      const src = safeResolve(String(it.path || ''), it.pool || '', req);
      if (!src) return json(res, 400, { error: 'Đường dẫn nguồn không hợp lệ: ' + it.path });
      const srcPool = poolOfAbsForUser(src, req);
      if (src === path.resolve(srcPool.path)) return json(res, 400, { error: 'Không thể di chuyển gốc ổ.' });
      if (!fs.existsSync(src)) return json(res, 404, { error: 'Không tìm thấy: ' + it.path });
      const st = await fsp.stat(src);
      const sameDirMove = srcPool.id === destPool.id && destDir.toLowerCase() === path.dirname(src).toLowerCase();
      if (mode === 'move' && sameDirMove) continue;
      if (st.isDirectory() && (destDir.toLowerCase() === src.toLowerCase() || (destDir.toLowerCase() + path.sep).startsWith(src.toLowerCase() + path.sep))) {
        return json(res, 409, { error: 'Không thể dán thư mục "' + path.basename(src) + '" vào chính nó.' });
      }
      resolved.push({ src, srcPool, isDir: st.isDirectory(), base: path.basename(src), size: st.isFile() ? st.size : 0 });
    }
    if (!resolved.length) return json(res, 200, { ok: true, done: [], error: null });

    const job = makeCopyJob(mode, resolved.length);
    let totalBytes = 0;
    for (const r of resolved) totalBytes += r.isDir ? await statTreeBytes(r.src, 10000) : r.size;
    job.total = totalBytes;
    const done = [];
    const runWork = async () => {
      try {
        await ensureDir(destDir);
        for (const r of resolved) {
          job.current = r.base;
          const srcPool = r.srcPool;
          const destCheck = path.resolve(destDir, r.base);
          const target = uniqueTarget(destCheck);
          if (mode === 'move' && srcPool.id === destPool.id) {
            await fsp.rename(r.src, target);
            job.done += r.isDir ? await statTreeBytes(target, 10000) : r.size;
            job.doneItems++;
          } else if (mode === 'copy') {
            if (r.isDir) await copyDirProgressed(r.src, target, job);
            else await copyFileProgressed(r.src, target, job);
            job.doneItems++;
          } else {
            if (r.isDir) {
              await copyDirProgressed(r.src, target, job);
              await safeRmTree(r.src);
            } else {
              await copyFileProgressed(r.src, target, job);
              await safeUnlink(r.src);
            }
            job.doneItems++;
          }
          done.push({ name: r.base, pool: destPool.id, rel: relOfInPool(target, destPool) });
        }
        if (job.done < job.total) job.done = job.total;
        job.status = 'done';
        job.elapsed = Date.now() - job.started;
        scheduleJobClean(job.id);
        const verb = mode === 'copy' ? 'đã copy' : 'đã di chuyển';
        for (const d of done) logActivity('edit', `${verb} "${d.name}" đến ổ ${destPool.name}: ${d.rel || '/'}`, req);
      } catch (e) {
        job.status = 'error';
        job.error = e.message;
        job.elapsed = Date.now() - job.started;
        scheduleJobClean(job.id);
      }
    };
    runWork();
    return json(res, 200, { ok: true, jobId: job.id, total: items.length });
  }

  if (route === '/api/recent' && req.method === 'GET') {
    const poolFilter = url.searchParams.get('pool') || '';
    const seen = new Set();
    const out = [];
    for (const r of recent) {
      const key = (r.pool || 'main') + '|' + r.path;
      if (seen.has(key)) continue;
      seen.add(key);
      if (poolFilter && (r.pool || 'main') !== poolFilter) continue;
      if (!poolAllowed(req, r.pool || 'main')) continue;
      const abs = safeResolve(r.path, r.pool || '', req);
      if (!abs) continue;
      if (!canAccess(req, abs)) continue;
      const st = await fsp.stat(abs).catch(() => null);
      if (!st || st.isDirectory()) continue;
      out.push({ path: r.path, pool: r.pool || 'main', name: path.basename(abs), size: st.size, mtime: st.mtime.toISOString(), action: r.action, time: r.time });
      if (out.length >= 30) break;
    }
    return json(res, 200, { items: out });
  }

  if (route === '/api/trash' && req.method === 'GET') {
    const all = await trashList(req);
    const items = [];
    for (const it of all) {
      const abs = safeResolve(it.rel, it.pool || '', req);
      if (!abs || !canAccess(req, abs)) continue;
      items.push(it);
    }
    return json(res, 200, { items });
  }

  if (route === '/api/trash/restore' && req.method === 'POST') {

    if (!requireRole(req, res, "editor")) return;
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const id = String(body.id || '');
    if (!/^[0-9a-f]{16}$/.test(id)) return json(res, 400, { error: 'ID không hợp lệ.' });
    const td = findTrashDir(id, req);
    if (!td) return json(res, 404, { error: 'Không tìm thấy mục trong thùng rác.' });
    const metaPath = path.join(td, id, 'meta.json');
    const m = await fsp.readFile(metaPath, 'utf8').catch(() => null);
    if (!m) return json(res, 404, { error: 'Không tìm thấy mục trong thùng rác.' });
    const meta = JSON.parse(m);
    const poolId = meta.pool || 'main';
    let target = path.resolve(path.dirname(td), String(meta.rel || '').replace(/\\/g, '/').replace(/^\/+/, ''));
    {
      const scopeErr = checkScope(req, target, '');
      if (scopeErr) return json(res, 403, scopeErr);
    }
    target = uniqueRestoreTarget(target);
    await fsp.mkdir(path.dirname(target), { recursive: true });
    await fsp.rename(path.join(td, id, 'data'), target);
    await fsp.rm(path.join(td, id), { recursive: true, force: true });
    logActivity('restore', `đã khôi phục "${relOfForUser(target, req)}" từ thùng rác`, req);
    logRecent('restore', relOfForUser(target, req), req, poolId);
    return json(res, 200, { ok: true, rel: relOfForUser(target, req) });
  }

  if (route === '/api/trash/purge' && req.method === 'POST') {

    if (!requireRole(req, res, "editor")) return;
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const id = String(body.id || '');
    if (id) {
      if (!/^[0-9a-f]{16}$/.test(id)) return json(res, 400, { error: 'ID không hợp lệ.' });
      const td = findTrashDir(id, req);
      if (!td) return json(res, 404, { error: 'Không tìm thấy mục trong thùng rác.' });
      const metaRaw = await fsp.readFile(path.join(td, id, 'meta.json'), 'utf8').catch(() => null);
      if (metaRaw) {
        try {
          const meta = JSON.parse(metaRaw);
          const target = safeResolve(meta.rel, meta.pool || 'main', req);
          if (target) {
            const scopeErr = checkScope(req, target, meta.pool || 'main');
            if (scopeErr) return json(res, 403, scopeErr);
          }
        } catch {}
      }
      await fsp.rm(path.join(td, id), { recursive: true, force: true });
      logActivity('purge', `đã xóa vĩnh viễn 1 mục trong thùng rác`, req);
    } else {
      for (const d of trashDirsForUser(req)) {
        const pAbs = path.dirname(d);
        if (!canAccess(req, pAbs)) continue;
        await fsp.rm(d, { recursive: true, force: true }).catch(() => {});
        fs.mkdirSync(d, { recursive: true });
      }
      logActivity('purge', 'đã dọn sạch thùng rác trên mọi ổ', req);
    }
    return json(res, 200, { ok: true });
  }

  /* ---------- Users management (admin only) ---------- */
  if (route === '/api/users' && req.method === 'GET') {
    if (!requireRole(req, res, 'admin')) return;
    const now = Date.now();
    return json(res, 200, { users: users.map((u) => {
      const uname = u.name.toLowerCase();
      let sessions = 0;
      let online = false;
      for (const [t, info] of tokens) {
        if (info.expires >= now && String(info.user || '').toLowerCase() === uname) {
          sessions++;
          const d = devices.get(t);
          if (d && now - d.lastSeen < 15 * 60 * 1000) online = true;
        }
      }
      return { name: u.name, role: u.role, created: u.created, lastLogin: u.lastLogin || null, sessions, online, scope: Array.isArray(u.scope) ? u.scope : [] };
    }) });
  }

  if (route === '/api/users' && req.method === 'POST') {
    if (!requireRole(req, res, 'admin')) return;
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const name = String(body.name || '').trim();
    const password = String(body.password || '');
    const role = body.role === 'viewer' ? 'viewer' : 'editor';
    if (!isValidName(name)) return json(res, 400, { error: 'Tên không hợp lệ (2-32 ký tự chữ/số/dấu ._-).' });
    if (name.toLowerCase() === 'admin') return json(res, 400, { error: 'Không được dùng tên "admin".' });
    if (password.length < 4) return json(res, 400, { error: 'Mật khẩu tối thiểu 4 ký tự.' });
    if (users.some((u) => u.name.toLowerCase() === name.toLowerCase())) return json(res, 409, { error: 'Tên người dùng đã tồn tại.' });
    const scope = body.scope != null ? parseScopeInput(body.scope) : ['*'];
    if (scope === null) return json(res, 400, { error: 'Phạm vi ổ không hợp lệ.' });
    const salt = crypto.randomBytes(16).toString('hex');
    const user = { name, role, salt, hash: hashPassword(password, salt), created: new Date().toISOString(), lastLogin: null, scope };
    users.push(user);
    saveUsers();
    logActivity('login', `đã tạo tài khoản "${name}" (quyền ${role})`, req);
    return json(res, 200, { ok: true, name, role, scope });
  }

  if (route === '/api/users/update' && req.method === 'POST') {
    if (!requireRole(req, res, 'admin')) return;
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const u = users.find((x) => x.name.toLowerCase() === String(body.name || '').toLowerCase());
    if (!u) return json(res, 404, { error: 'Không tìm thấy người dùng.' });
    if (body.role) u.role = body.role === 'viewer' ? 'viewer' : 'editor';
    if (body.password) {
      if (String(body.password).length < 4) return json(res, 400, { error: 'Mật khẩu tối thiểu 4 ký tự.' });
      u.salt = crypto.randomBytes(16).toString('hex');
      u.hash = hashPassword(String(body.password), u.salt);
    }
    if (body.scope != null) {
      const scope = parseScopeInput(body.scope);
      if (scope === null) return json(res, 400, { error: 'Phạm vi ổ không hợp lệ.' });
      u.scope = scope;
    }
    saveUsers();
    const what = [body.role ? 'đổi quyền thành ' + u.role : '', body.password ? 'đặt lại mật khẩu' : '', body.scope != null ? 'cập nhật phạm vi ổ' : ''].filter(Boolean).join(' và ') || 'cập nhật';
    logActivity('login', `đã ${what} cho tài khoản "${u.name}"`, req);
    return json(res, 200, { ok: true, name: u.name, role: u.role, scope: u.scope });
  }

  if (route === '/api/users' && req.method === 'DELETE') {
    if (!requireRole(req, res, 'admin')) return;
    const name = String(url.searchParams.get('name') || '').toLowerCase();
    const i = users.findIndex((x) => x.name.toLowerCase() === name);
    if (i < 0) return json(res, 404, { error: 'Không tìm thấy người dùng.' });
    const [removed] = users.splice(i, 1);
    saveUsers();
    let killed = 0;
    for (const [t, info] of tokens) {
      if (typeof info === 'object' && info.expires >= Date.now() && String(info.user || '').toLowerCase() === name) { tokens.delete(t); devices.delete(t); killed++; }
    }
    logActivity('login', `đã xóa tài khoản "${removed.name}" (đăng xuất ${killed} thiết bị)`, req);
    return json(res, 200, { ok: true, sessionsRevoked: killed });
  }

  if (route === '/api/users/sessions' && req.method === 'DELETE') {
    if (!requireRole(req, res, 'admin')) return;
    const name = String(url.searchParams.get('name') || '').toLowerCase();
    if (!users.some((x) => x.name.toLowerCase() === name)) return json(res, 404, { error: 'Không tìm thấy người dùng.' });
    let killed = 0;
    for (const [t, info] of tokens) {
      if (typeof info === 'object' && info.expires >= Date.now() && String(info.user || '').toLowerCase() === name) {
        tokens.delete(t); devices.delete(t); killed++;
      }
    }
    logActivity('login', `đã đăng xuất mọi thiết bị của "${name}" (${killed} phiên)`, req);
    return json(res, 200, { ok: true, sessionsRevoked: killed });
  }

  /* ---------- Settings (admin only) ---------- */
  if (route === '/api/fs/browse' && req.method === 'GET') {
    if (!requireRole(req, res, 'admin')) return;
    const p = url.searchParams.get('path') || '';
    if (!p) {
      const drives = [];
      for (let c = 65; c <= 90; c++) {
        const drive = String.fromCharCode(c) + ':\\';
        try {
          const st = fs.statSync(drive);
          if (st.isDirectory()) drives.push({ name: String.fromCharCode(c) + ':', path: drive, type: 'dir' });
        } catch {}
      }
      return json(res, 200, { path: '', parent: null, drives: true, entries: drives });
    }
    const abs = path.resolve(p);
    if (!fs.existsSync(abs)) return json(res, 404, { error: 'Đường dẫn không tồn tại.' });
    let st;
    try { st = fs.statSync(abs); } catch { return json(res, 400, { error: 'Không đọc được đường dẫn.' }); }
    if (!st.isDirectory()) return json(res, 400, { error: 'Không phải thư mục.' });
    let entries = [];
    try {
      entries = fs.readdirSync(abs, { withFileTypes: true })
        .filter((e) => e.isDirectory() && !e.name.startsWith('.cw-'))
        .map((e) => ({ name: e.name, path: path.join(abs, e.name) }))
        .sort((a, b) => a.name.localeCompare(b.name, 'vi'));
    } catch { return json(res, 403, { error: 'Không có quyền đọc thư mục này.' }); }
    const rootAbs = path.resolve(config.root);
    const isShareRoot = abs.toLowerCase() === rootAbs.toLowerCase();
    return json(res, 200, {
      path: abs,
      parent: isShareRoot ? null : (path.dirname(abs) !== abs ? path.dirname(abs) : ''),
      drives: false,
      current: abs,
      entries,
    });
  }

  if (route === '/api/fs/browse' && req.method === 'POST') {
    if (!requireRole(req, res, 'admin')) return;
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const abs = path.resolve(String(body.path || ''));
    if (!abs || abs.length < 3) return json(res, 400, { error: 'Đường dẫn không hợp lệ.' });
    const rootAbs = path.resolve(config.root);
    if (abs.toLowerCase() === rootAbs.toLowerCase() || isWithin(abs, rootAbs)) {
      return json(res, 400, { error: 'Không thể tạo thư mục bên trong thư mục đang chia sẻ.' });
    }
    if (fs.existsSync(abs)) return json(res, 409, { error: 'Đã tồn tại.' });
    try { fs.mkdirSync(abs, { recursive: true }); } catch { return json(res, 400, { error: 'Không tạo được thư mục (kiểm tra quyền ghi).' }); }
    return json(res, 200, { ok: true, path: abs });
  }

  /* ---------- Lock management (synchronized across host/client/android) ---------- */
  if (route === '/api/locks' && req.method === 'GET') {
    return json(res, 200, { locks: locks.map((l) => ({ ...l })) });
  }

  if (route === '/api/locks' && req.method === 'POST') {
    if (!requireRole(req, res, 'editor')) return;
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const poolId = String(body.pool || 'main');
    const itemPath = String(body.path || '').replace(/\\/g, '/').replace(/^\/+|\/+$/g, '');
    const type = String(body.type || (itemPath ? 'file' : 'drive'));
    const name = String(body.name || (itemPath ? itemPath.split('/').pop() : 'Ổ đĩa'));
    const password = String(body.password || '');
    if (password.length < 3) return json(res, 400, { error: 'Mật khẩu khóa tối thiểu 3 ký tự.' });
    const hash = crypto.createHash('sha256').update(password, 'utf8').digest('hex');
    const who = actorOf(req);
    const existingIndex = locks.findIndex((l) => l.pool === poolId && l.path === itemPath && l.type === type);
    const now = new Date().toISOString();
    let lockObj;
    if (existingIndex >= 0) {
      locks[existingIndex].password = password;
      locks[existingIndex].hash = hash;
      locks[existingIndex].user = who;
      locks[existingIndex].updatedAt = now;
      locks[existingIndex].name = name;
      lockObj = locks[existingIndex];
      logActivity('edit', `đã đổi mật khẩu khóa "${name}"`, req);
    } else {
      const id = 'lk-' + crypto.randomBytes(6).toString('hex');
      lockObj = {
        id,
        pool: poolId,
        path: itemPath,
        type,
        name,
        password,
        hash,
        user: who,
        createdAt: now,
        updatedAt: now,
      };
      locks.unshift(lockObj);
      logActivity('edit', `đã đặt mật khẩu khóa "${name}"`, req);
    }
    saveLocks();
    return json(res, 200, { ok: true, lock: lockObj });
  }

  if (route === '/api/locks/update' && req.method === 'POST') {
    if (!requireRole(req, res, 'editor')) return;
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const id = String(body.id || '');
    const poolId = String(body.pool || '');
    const itemPath = String(body.path || '').replace(/\\/g, '/').replace(/^\/+|\/+$/g, '');
    const type = String(body.type || '');
    const password = String(body.password || '');
    if (password.length < 3) return json(res, 400, { error: 'Mật khẩu khóa tối thiểu 3 ký tự.' });
    let lockObj = null;
    if (id) {
      lockObj = locks.find((l) => l.id === id);
    } else if (poolId) {
      lockObj = locks.find((l) => l.pool === poolId && l.path === itemPath && (!type || l.type === type));
    }
    if (!lockObj) return json(res, 404, { error: 'Không tìm thấy mục khóa.' });
    lockObj.password = password;
    lockObj.hash = crypto.createHash('sha256').update(password, 'utf8').digest('hex');
    lockObj.updatedAt = new Date().toISOString();
    saveLocks();
    logActivity('edit', `đã sửa mật khẩu khóa "${lockObj.name}"`, req);
    return json(res, 200, { ok: true, lock: lockObj });
  }

  if (route === '/api/locks' && req.method === 'DELETE') {
    if (!requireRole(req, res, 'editor')) return;
    let body = {};
    try {
      const qId = url.searchParams.get('id');
      const qPool = url.searchParams.get('pool');
      const qPath = url.searchParams.get('path');
      const qType = url.searchParams.get('type');
      if (qId || qPool) {
        body = { id: qId, pool: qPool, path: qPath, type: qType };
      } else {
        body = readJsonBody(await readBody(req, 65536), 65536);
      }
    } catch {}
    const id = String(body.id || '');
    const poolId = String(body.pool || '');
    const itemPath = String(body.path || '').replace(/\\/g, '/').replace(/^\/+|\/+$/g, '');
    const type = String(body.type || '');
    let index = -1;
    if (id) {
      index = locks.findIndex((l) => l.id === id);
    } else if (poolId) {
      index = locks.findIndex((l) => l.pool === poolId && l.path === itemPath && (!type || l.type === type));
    }
    if (index < 0) return json(res, 404, { error: 'Không tìm thấy mục khóa.' });
    const [removed] = locks.splice(index, 1);
    saveLocks();
    logActivity('edit', `đã gỡ khóa "${removed.name}"`, req);
    return json(res, 200, { ok: true, removed });
  }

  if (route === '/api/locks/verify' && req.method === 'POST') {
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const poolId = String(body.pool || 'main');
    const itemPath = String(body.path || '').replace(/\\/g, '/').replace(/^\/+|\/+$/g, '');
    const type = String(body.type || (itemPath ? '' : 'drive'));
    const password = String(body.password || '');
    const lockObj = locks.find((l) => l.pool === poolId && l.path === itemPath && (!type || l.type === type));
    if (!lockObj) return json(res, 200, { ok: true, locked: false, verified: true });
    const hash = crypto.createHash('sha256').update(password, 'utf8').digest('hex');
    const match = lockObj.hash === hash || lockObj.password === password;
    if (match) {
      return json(res, 200, { ok: true, locked: true, verified: true, name: lockObj.name });
    }
    return json(res, 403, { ok: false, error: 'Mật khẩu không đúng.', verified: false });
  }

  if (route === '/api/settings' && req.method === 'GET') {
    if (!requireRole(req, res, 'admin')) return;
    const ts = await getTailscale(false);
    return json(res, 200, {
      host: os.hostname(),
      port: config.port,
      password: config.password,
      adminUser: adminName(),
      root: path.resolve(config.root),
      syncEnabled: config.syncEnabled !== false,
      cameraPool: config.cameraPool || (cameraPool() ? cameraPool().id : 'pool_e'),
      cameraPoolPath: cameraPool() ? cameraPool().path : '',
      pcSyncPool: defaultPool() ? defaultPool().id : 'main',
      pcSyncPoolPath: defaultPool() ? defaultPool().path : '',
      inviteRole: config.inviteRole === 'viewer' ? 'viewer' : 'editor',
      userCount: users.length,
      sessionCount: [...tokens.values()].filter((i) => typeof i === 'object' && i.expires >= Date.now()).length,
      tailscale: { installed: ts.installed, running: ts.running, selfIp: ts.selfIp || '', tailnet: ts.tailnet || '' },
      lanIps: Object.values(os.networkInterfaces()).flat().filter((n) => n && n.family === 'IPv4' && !n.internal).map((n) => n.address),
    });
  }

  if (route === '/api/settings' && req.method === 'POST') {
    if (!requireRole(req, res, 'admin')) return;
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    if (body.password != null && String(body.password).trim() !== '' && body.currentPassword != null && String(body.currentPassword).trim() !== '') {
      if (String(body.currentPassword) !== config.password) {
        return json(res, 403, { error: 'Mật khẩu hiện tại không đúng.' });
      }
    }
    const changes = [];
    if (body.cameraPool != null) {
      config.cameraPool = String(body.cameraPool);
      changes.push('cameraPool');
    }
    if (body.pcSyncPool != null) {
      const p = getPool(body.pcSyncPool);
      if (p) {
        for (const item of config.pools) item.default = item.id === p.id;
        config.root = p.path;
        changes.push('pcSyncPool');
      }
    }
    if (body.syncEnabled != null) {
      const se = !!body.syncEnabled;
      if (se !== (config.syncEnabled !== false)) {
        config.syncEnabled = se;
        changes.push('syncEnabled');
      }
    }
    if (body.password != null && String(body.password).trim() !== '') {
      const pw = String(body.password).trim();
      if (pw.length < 6) return json(res, 400, { error: 'Mật khẩu admin tối thiểu 6 ký tự.' });
      if (pw !== config.password) { config.password = pw; changes.push('password'); }
    }
    if (body.adminUser != null) {
      const n = String(body.adminUser).trim();
      if (n && n !== adminName()) {
        if (!isValidName(n)) return json(res, 400, { error: 'Tên tài khoản không hợp lệ (2-32 ký tự chữ/số, dấu ._-).' });
        if (n.toLowerCase() === 'invite') return json(res, 400, { error: 'Không được dùng tên "invite".' });
        if (users.some((u) => u.name.toLowerCase() === n.toLowerCase())) return json(res, 409, { error: 'Tên này trùng với tài khoản người dùng hiện có.' });
        config.adminUser = n;
        changes.push('adminUser');
      }
    }
    if (body.port != null) {
      const p = Number(body.port);
      if (!Number.isInteger(p) || p < 1 || p > 65535) return json(res, 400, { error: 'Cổng không hợp lệ (1-65535).' });
      if (p !== config.port) { config.port = p; changes.push('port'); }
    }
    if (body.root != null && String(body.root).trim() !== '') {
      const r = path.resolve(String(body.root).trim());
      if (!r || r.length < 3) return json(res, 400, { error: 'Đường dẫn không hợp lệ.' });
      if (fs.existsSync(r)) {
        if (!fs.statSync(r).isDirectory()) return json(res, 400, { error: 'Đường dẫn không phải thư mục.' });
      } else if (body.createRoot) {
        try { fs.mkdirSync(r, { recursive: true }); } catch { return json(res, 400, { error: 'Không tạo được thư mục. Kiểm tra quyền ghi.' }); }
      } else {
        return json(res, 400, { error: 'Thư mục không tồn tại. Tích "tạo nếu chưa có" để tạo mới.' });
      }
      if (r !== path.resolve(config.root)) { config.root = r; changes.push('root'); }
    }
    if (body.inviteRole != null) {
      const r = body.inviteRole === 'viewer' ? 'viewer' : 'editor';
      if (r !== (config.inviteRole === 'viewer' ? 'viewer' : 'editor')) { config.inviteRole = r; changes.push('inviteRole'); }
    }
    if (!changes.length) return json(res, 200, { ok: true, changed: [], message: 'Không có thay đổi nào cần lưu.', port: config.port, portChanged: false });
    saveConfig();
    if (changes.includes('root')) {
      normalizePools();
      ensureDirs();
      uploadsDir = uploadsDirOf(defaultPool().id);
      trashDir = trashDirOf(defaultPool().id);
    }
    if (changes.includes('port')) {
      setTimeout(() => {
        server.close(() => {
          server.listen(config.port, '0.0.0.0', () => {
                console.log('Server moved to port ' + config.port);
                logActivity('edit', 'đã chuyển máy chủ sang cổng ' + config.port, null, 'server');
          });
        });
        if (typeof server.closeAllConnections === 'function') server.closeAllConnections();
      }, 400);
    }
    logActivity('edit', 'đã thay đổi cài đặt server: ' + changes.join(', '), req);
    return json(res, 200, { ok: true, changed: changes, port: config.port, portChanged: changes.includes('port') });
  }

  /* ---------- Self-service password change ---------- */
  if (route === '/api/account/password' && req.method === 'POST') {
    let body;
    try { body = readJsonBody(await readBody(req, 65536), 65536); } catch { body = {}; }
    const info = tokenInfo(getToken(req));
    const oldPw = String(body.currentPassword || '');
    const newPw = String(body.newPassword || '');
    if (newPw.length < 4) return json(res, 400, { error: 'Mật khẩu mới tối thiểu 4 ký tự.' });
    if (info.role === 'admin' && info.user === 'admin') {
      if (oldPw !== config.password) return json(res, 403, { error: 'Mật khẩu hiện tại không đúng.' });
      if (newPw.length < 6) return json(res, 400, { error: 'Mật khẩu admin tối thiểu 6 ký tự.' });
      config.password = newPw;
      saveConfig();
      logActivity('edit', 'đã đổi mật khẩu admin', req);
      return json(res, 200, { ok: true });
    }
    const u = users.find((x) => x.name.toLowerCase() === String(info.user || '').toLowerCase());
    if (!u) return json(res, 404, { error: 'Không tìm thấy tài khoản.' });
    let ok = false;
    try {
      ok = crypto.timingSafeEqual(Buffer.from(hashPassword(oldPw, u.salt), 'hex'), Buffer.from(u.hash, 'hex'));
    } catch { ok = false; }
    if (!ok) return json(res, 403, { error: 'Mật khẩu hiện tại không đúng.' });
    u.salt = crypto.randomBytes(16).toString('hex');
    u.hash = hashPassword(newPw, u.salt);
    saveUsers();
    logActivity('edit', 'đã tự đổi mật khẩu tài khoản của mình', req);
    return json(res, 200, { ok: true });
  }

  return json(res, 404, { error: 'Không tìm thấy API.' });
}

const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS, HEAD');
  res.setHeader('Access-Control-Allow-Headers', 'Range, Authorization, Content-Type, Accept, Origin, User-Agent, X-Requested-With');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Range, Content-Length, Accept-Ranges, Content-Disposition, X-CW-Transcode');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }

  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (url.pathname.startsWith('/api/')) {
      await handleApi(req, res, url);
    } else {
      serveStatic(req, res);
    }
  } catch (e) {
    if (!res.headersSent) json(res, 500, { error: 'Lỗi máy chủ: ' + e.message });
    else res.end();
  }
});

function ensureHostFirewall(port) {
  if (process.platform !== 'win32') return;
  const p = Number(port) || 8080;
  const ps = `try { netsh advfirewall firewall add rule name="CW Datacenter Host (TCP ${p})" dir=in action=allow protocol=TCP localport=${p} enable=yes profile=any; netsh advfirewall firewall add rule name="CW Datacenter Discovery (UDP 46631)" dir=in action=allow protocol=UDP localport=46631 enable=yes profile=any } catch {}`;
  try {
    const { exec } = require('child_process');
    exec(`powershell -NoProfile -NonInteractive -WindowStyle Hidden -Command "${ps}"`, { windowsHide: true }, () => {});
  } catch {}
}

server.listen(config.port, '0.0.0.0', async () => {
  ensureHostFirewall(config.port);
  const nets = os.networkInterfaces();
  const ips = Object.values(nets).flat().filter((n) => n && n.family === 'IPv4' && !n.internal).map((n) => n.address);
  console.log('==============================================');
  console.log('  CW DATACENTER - Host Server v1.4.0');
  console.log('  Host            : ' + os.hostname());
  console.log('  Shared folder   : ' + path.resolve(config.root));
  console.log('  Admin account   : ' + adminName());
  console.log('  Password        : ' + config.password);
  console.log('  Host dashboard  : http://localhost:' + config.port + '/host.html');
  console.log('  Client (web)    : http://localhost:' + config.port);
  ips.forEach((ip) => console.log('  LAN client      : http://' + ip + ':' + config.port));
  const ts = await getTailscale(true);
  if (ts.installed && ts.running) {
    console.log('  Tailscale       : ON (' + (ts.selfIp || 'no IP') + (ts.tailnet ? ' ' + ts.tailnet : '') + ')');
    if (ts.selfIp) console.log('  Remote client   : http://' + ts.selfIp + ':' + config.port);
  } else if (ts.installed) {
    console.log('  Tailscale       : installed but not connected (' + (ts.reason || 'run tailscale up') + ')');
  } else {
    console.log('  Tailscale       : not installed (remote access unavailable)');
  }
  console.log('==============================================');
});

/* ---------- LAN auto-discovery (UDP broadcast "CW-DISCOVER") ---------- */
const DISCOVERY_PORT = 46631;
const discovery = dgram.createSocket({ type: 'udp4', reuseAddr: true });
discovery.on('message', (msg, rinfo) => {
  const text = String(msg).trim();
  if (text !== 'CW-DISCOVER') return;
  const reply = JSON.stringify({
    app: 'cw-datacenter',
    host: os.hostname(),
    port: config.port,
    name: 'CW Datacenter',
  });
  try { discovery.send(reply, rinfo.port, rinfo.address); } catch {}
});
discovery.on('error', (e) => {
  console.log('Discovery socket error: ' + e.message);
});
try {
  discovery.bind(DISCOVERY_PORT, '0.0.0.0');
} catch (e) {
  console.log('Discovery bind failed: ' + e.message);
}
