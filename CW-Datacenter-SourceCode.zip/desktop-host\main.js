'use strict';
const { app, BrowserWindow, ipcMain, Menu, shell, dialog, Tray, nativeImage, screen, session } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const http = require('http');
const crypto = require('crypto');

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();

const IS_PACKAGED = app.isPackaged;

function fileSame(a, b) {
  try { return fs.readFileSync(a).equals(fs.readFileSync(b)); } catch { return false; }
}

function syncServerFiles(dest) {
  const src = path.join(process.resourcesPath, 'server');
  fs.mkdirSync(dest, { recursive: true });
  const copyWalk = (s, d) => {
    fs.mkdirSync(d, { recursive: true });
    for (const e of fs.readdirSync(s, { withFileTypes: true })) {
      const sp = path.join(s, e.name);
      const dp = path.join(d, e.name);
      if (e.isDirectory()) copyWalk(sp, dp);
      else if (!fileSame(sp, dp)) fs.copyFileSync(sp, dp);
    }
  };
  copyWalk(src, dest);
  const cleanWalk = (s, d) => {
    let entries;
    try { entries = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      const sp = path.join(s, e.name);
      const dp = path.join(d, e.name);
      if (d === dest) continue;
      if (e.isDirectory()) {
        if (!fs.existsSync(sp)) fs.rmSync(dp, { recursive: true, force: true });
        else cleanWalk(sp, dp);
      } else if (!fs.existsSync(sp)) {
        try { fs.unlinkSync(dp); } catch {}
      }
    }
  };
  cleanWalk(src, dest);
}

function resolveServerDir() {
  if (!IS_PACKAGED) return path.join(__dirname, '..', 'server');
  const dest = path.join(app.getPath('userData'), 'server');
  syncServerFiles(dest);
  return dest;
}

const SERVER_DIR = resolveServerDir();
const SERVER_JS = path.join(SERVER_DIR, 'server.js');
const CONFIG_PATH = path.join(SERVER_DIR, 'config.json');

const TAB_JS = path.join(__dirname, 'host-tab', 'host-tab.js');
const TAB_CSS = path.join(__dirname, 'host-tab', 'host-app.css');

let win = null;
let tray = null;
let forceQuit = false;
let serverProc = null;
let serverState = 'stopped';

function send(channel, ...args) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, ...args);
}

function readPort() {
  try {
    const cfg = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
    return Number(cfg.port) || 8080;
  } catch { return 8080; }
}

function readConfig() {
  try { return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8')); } catch { return {}; }
}

function findNode() {
  if (IS_PACKAGED) return { cmd: process.execPath, asElectron: true };
  const candidates = [
    process.env.NODE_EXE,
    path.join(SERVER_DIR, '..', '.tools', 'node', 'node.exe'),
    path.join(SERVER_DIR, '..', '..', '.tools', 'node', 'node.exe'),
  ];
  for (const c of candidates) {
    if (c && fs.existsSync(c)) return { cmd: c, asElectron: false };
  }
  return { cmd: 'node', asElectron: false };
}

function defaultSharedRoot() {
  return path.join(require('os').homedir(), 'cw-datacenter', 'shared');
}

function ensureConfig() {
  if (fs.existsSync(CONFIG_PATH)) return;
  const cfg = {
    port: 8080,
    adminUser: 'admin',
    password: 'admin',
    root: defaultSharedRoot(),
  };
  fs.mkdirSync(cfg.root, { recursive: true });
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2));
}

function probe(port) {
  return new Promise((resolve) => {
    const req = http.get({ host: '127.0.0.1', port, path: '/api/health', timeout: 1500 }, (res) => {
      res.resume();
      resolve(res.statusCode === 200);
    });
    req.on('error', () => resolve(false));
    req.on('timeout', () => { req.destroy(); resolve(false); });
  });
}

function ensureFirewallRules(port) {
  if (process.platform !== 'win32') return;
  const p = Number(port) || 8080;
  const exe = process.execPath;
  const ps = `try { netsh advfirewall firewall add rule name="CW Datacenter Host" dir=in action=allow program="${exe}" enable=yes profile=any; netsh advfirewall firewall add rule name="CW Datacenter Host (TCP ${p})" dir=in action=allow protocol=TCP localport=${p} enable=yes profile=any; netsh advfirewall firewall add rule name="CW Datacenter Discovery (UDP 46631)" dir=in action=allow protocol=UDP localport=46631 enable=yes profile=any } catch {}`;
  try {
    const { exec } = require('child_process');
    exec(`powershell -NoProfile -NonInteractive -WindowStyle Hidden -Command "${ps}"`, { windowsHide: true }, () => {});
  } catch {}
}

async function startServer() {
  if (serverProc) return { ok: true, already: true };
  if (!fs.existsSync(SERVER_JS)) {
    send('host-log', 'err', 'Không tìm thấy server.js tại: ' + SERVER_JS);
    return { ok: false, error: 'Thiếu server.js' };
  }
  ensureConfig();
  const node = findNode();
  const port = readPort();
  ensureFirewallRules(port);

  const already = await probe(port);
  if (already) {
    serverState = 'external';
    send('host-state', 'external', port);
    send('host-log', 'info', `Port ${port} đã có CW Datacenter server đang chạy sẵn — dùng luôn.`);
    return { ok: true, port, external: true };
  }

  send('host-log', 'info', 'Đang khởi động server bằng: ' + node.cmd);
  const env = { ...process.env };
  if (node.asElectron) env.ELECTRON_RUN_AS_NODE = '1';
  const spawnArgs = ['--max-old-space-size=2048', SERVER_JS];
  serverProc = spawn(node.cmd, spawnArgs, {
    cwd: SERVER_DIR,
    env,
    windowsHide: true,
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  serverState = 'starting';
  send('host-state', 'starting', port);

  const stamp = () => new Date().toTimeString().slice(0, 8);
  serverProc.stdout.on('data', (d) => d.toString().split(/\r?\n/).filter(Boolean).forEach((l) => send('host-log', 'out', `[${stamp()}] ${l}`)));
  serverProc.stderr.on('data', (d) => d.toString().split(/\r?\n/).filter(Boolean).forEach((l) => send('host-log', 'err', l)));

  serverProc.on('error', (e) => {
    send('host-log', 'err', 'Không khởi động được node: ' + e.message);
    if (node.cmd === 'node') send('host-log', 'err', 'Gợi ý: cài Node.js hoặc set biến NODE_EXE trỏ tới node.exe.');
    serverState = 'stopped';
    serverProc = null;
    send('host-state', 'stopped', port);
  });

  serverProc.on('exit', (code, signal) => {
    const wasRunning = serverState === 'running' || serverState === 'starting';
    serverProc = null;
    serverState = 'stopped';
    send('host-state', 'stopped', port);
    if (wasRunning && !forceQuit) {
      send('host-log', 'warn', `Server dừng hoạt động (code=${code}${signal ? ', ' + signal : ''}). Đang tự động khởi động lại…`);
      setTimeout(() => {
        if (serverState === 'stopped' && !forceQuit) {
          startServer();
        }
      }, 1500);
    }
  });

  for (let i = 0; i < 30; i++) {
    await new Promise((r) => setTimeout(r, 500));
    if (!serverProc) break;
    if (await probe(readPort())) {
      serverState = 'running';
      send('host-state', 'running', readPort());
      send('host-log', 'ok', 'Server đã sẵn sàng trên port ' + readPort());
      return { ok: true, port: readPort() };
    }
  }
  return { ok: false, error: 'Server khởi động quá 15s không phản hồi.' };
}

function stopServer() {
  if (serverState === 'external') {
    send('host-log', 'warn', 'Server đang dùng là tiến trình bên ngoài — không thể tắt từ đây.');
    serverState = 'stopped';
    send('host-state', 'stopped', readPort());
    return { external: true };
  }
  if (serverProc) {
    send('host-log', 'info', 'Đang dừng server…');
    serverState = 'stopping';
    try { serverProc.kill(); } catch {}
    serverProc = null;
    setTimeout(() => { if (serverState === 'stopping') { serverState = 'stopped'; send('host-state', 'stopped', readPort()); } }, 1500);
  } else {
    serverState = 'stopped';
    send('host-state', 'stopped', readPort());
  }
  return { ok: true };
}

/* ---------- Gọi API của server với quyền admin ---------- */
function apiRequest(port, method, apiPath, body, token) {
  return new Promise((resolve, reject) => {
    const payload = body != null ? Buffer.from(JSON.stringify(body), 'utf8') : null;
    const headers = {};
    if (payload) { headers['Content-Type'] = 'application/json'; headers['Content-Length'] = payload.length; }
    if (token) headers['Authorization'] = 'Bearer ' + token;
    const req = http.request({ host: '127.0.0.1', port, path: apiPath, method, headers, timeout: 8000 }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        let data = null;
        try { data = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch {}
        resolve({ status: res.statusCode, data });
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Server không phản hồi (timeout).')); });
    if (payload) req.write(payload);
    req.end();
  });
}

let adminToken = null;
async function loginAdmin(username, password) {
  const r = await apiRequest(readPort(), 'POST', '/api/login', { username, password, device: 'Host App' });
  if (r.status !== 200 || !r.data || !r.data.token) {
    const err = r.data && r.data.error ? r.data.error : 'đăng nhập thất bại';
    throw new Error(err);
  }
  return r.data.token;
}

async function serverApi(method, apiPath, body) {
  const port = readPort();
  if (!(await probe(port))) throw new Error('Server chưa chạy — hãy bật server trước.');
  if (!adminToken) {
    const cfg = readConfig();
    adminToken = await loginAdmin(String(cfg.adminUser || 'admin'), String(cfg.password || ''));
  }
  let r = await apiRequest(port, method, apiPath, body, adminToken);
  if (r.status === 401) {
    const cfg = readConfig();
    adminToken = await loginAdmin(String(cfg.adminUser || 'admin'), String(cfg.password || ''));
    r = await apiRequest(port, method, apiPath, body, adminToken);
  }
  return r;
}

/* ---------- Cửa sổ ---------- */
function trayIcon() {
  try { return nativeImage.createFromPath(path.join(__dirname, 'tray.png')); } catch { return nativeImage.createEmpty(); }
}
function winIcon() {
  try { const img = nativeImage.createFromPath(path.join(__dirname, 'logo.png')); return img.isEmpty() ? nativeImage.createEmpty() : img; } catch { return nativeImage.createEmpty(); }
}

function injectHostTab() {
  if (!win || win.isDestroyed()) return;
  let u;
  try { u = new URL(win.webContents.getURL()); } catch { return; }
  if (u.protocol !== 'http:' || !/\/host\.html$/.test(u.pathname)) return;
  try { win.webContents.insertCSS(fs.readFileSync(TAB_CSS, 'utf8')); } catch {}
  let js = '';
  try { js = fs.readFileSync(TAB_JS, 'utf8'); } catch { return; }
  win.webContents.executeJavaScript(
    '(() => { if (window.__hostTabLoaded) return; window.__hostTabLoaded = true;' +
    ' const run = () => { try { (function(){' + js + '})(); } catch (e) { console.error(e); } };' +
    ' if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", run, { once: true }); else run(); })()'
  ).catch(() => {});
}

function showSplash() {
  if (!win || win.isDestroyed()) return;
  win.loadFile('index.html');
}

async function goApp() {
  const r = await startServer();
  if (!r || !r.ok) {
    send('host-fail', (r && r.error) || 'Không khởi động được server.');
    return;
  }
  const port = r.port || readPort();
  let ok = false;
  for (let i = 0; i < 20; i++) {
    if (await probe(port)) { ok = true; break; }
    await new Promise((res) => setTimeout(res, 1000));
  }
  if (!ok) {
    send('host-fail', 'Server khởi động nhưng không phản hồi trên port ' + port + '.');
    return;
  }
  send('host-ready', port);
  if (win && !win.isDestroyed()) {
    win.loadURL('http://localhost:' + port + '/host.html');
  }
}

function createWindow() {
  let wa = { width: 1400, height: 900 };
  try { wa = screen.getPrimaryDisplay().workAreaSize; } catch {}
  const w0 = wa.width >= 1200 ? Math.min(1400, wa.width - 48) : wa.width;
  const h0 = wa.height >= 800 ? Math.min(900, wa.height - 48) : wa.height;
  win = new BrowserWindow({
    width: w0,
    height: h0,
    minWidth: 1020,
    minHeight: 620,
    frame: false,
    backgroundColor: '#ffffff',
    autoHideMenuBar: true,
    icon: winIcon(),
    title: 'CW Datacenter — Host',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  });
  showSplash();

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('blob:')) return { action: 'allow' };
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });

  win.webContents.on('dom-ready', injectHostTab);
  win.webContents.on('did-finish-load', injectHostTab);
  win.webContents.on('did-fail-load', (_e, code, desc, url, isMain) => {
    if (!isMain) return;
    try {
      const u = new URL(url);
      if (u.protocol === 'http:') { showSplash(); send('host-fail', 'Không kết nối được server (' + desc + ').'); }
    } catch {}
  });

  win.on('close', (e) => {
    if (!forceQuit) {
      e.preventDefault();
      win.hide();
    }
  });
  win.on('closed', () => { win = null; });
  buildMenu();
  buildTray();
}

function buildTray() {
  if (!app.isReady()) return;
  const icon = trayIcon();
  if (!tray) {
    tray = new Tray(icon.isEmpty() ? nativeImage.createEmpty() : icon.resize({ width: 16, height: 16 }));
    tray.on('click', () => { if (win) { if (win.isVisible()) win.focus(); else win.show(); } });
  }
  const ctx = Menu.buildFromTemplate([
    { label: 'Mở cửa sổ Host', click: () => { if (win) { win.show(); win.focus(); } } },
    { type: 'separator' },
    { label: 'Bật server', click: () => goApp() },
    { label: 'Tắt server', click: () => { if (win) showSplash(); stopServer(); } },
    { type: 'separator' },
    {
      label: 'Thoát hẳn', click: () => {
        forceQuit = true;
        if (win) { try { win.close(); } catch {} }
        app.quit();
      },
    },
  ]);
  tray.setToolTip('CW Datacenter — Host đang chạy');
  tray.setContextMenu(ctx);
}

function buildMenu() {
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    {
      label: 'Server',
      submenu: [
        { label: 'Bật server', click: () => goApp() },
        { label: 'Tắt server', click: () => { if (win) showSplash(); stopServer(); } },
        { type: 'separator' },
        { role: 'toggleDevTools', label: 'DevTools' },
        { role: 'quit', label: 'Thoát' },
      ],
    },
    { label: 'Chỉnh sửa', role: 'editMenu' },
    { label: 'Xem', role: 'viewMenu' },
  ]));
}

/* ---------- IPC ---------- */
ipcMain.handle('ui-start', () => startServer());
ipcMain.handle('ui-stop', () => stopServer());
ipcMain.handle('ui-state', () => ({ state: serverState, port: readPort(), serverDir: SERVER_DIR }));
ipcMain.handle('ui-info', () => {
  const cfg = readConfig();
  const os = require('os');
  const ips = Object.values(os.networkInterfaces()).flat().filter((n) => n && n.family === 'IPv4' && !n.internal).map((n) => n.address);
  return { port: cfg.port || 8080, password: cfg.password || '', adminUser: cfg.adminUser || 'admin', root: cfg.root || '', host: os.hostname(), ips };
});
ipcMain.handle('ui-open-folder', (_e, customPath) => {
  const { execFile } = require('child_process');
  let target = customPath;
  if (!target) {
    try { target = readConfig().root || ''; } catch {}
  }
  if (!target) target = defaultSharedRoot();
  if (!fs.existsSync(target)) {
    try { fs.mkdirSync(target, { recursive: true }); } catch {}
  }
  if (fs.existsSync(target)) execFile('explorer', [target], { windowsHide: true }, () => {});
  return true;
});
ipcMain.handle('ui-pick-shared', async () => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Chọn Ổ đĩa hoặc Thư mục Đồng bộ PC Client',
    properties: ['openDirectory', 'createDirectory'],
  });
  if (r.canceled || !r.filePaths.length) return { canceled: true };
  const newRoot = r.filePaths[0];
  const cfg = readConfig();
  const oldRoot = cfg.root;
  cfg.root = newRoot;
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2));
  fs.mkdirSync(newRoot, { recursive: true });
  send('host-log', 'info', `Thư mục đồng bộ PC: ${oldRoot || '(trống)'} → ${newRoot}`);
  const wasExternal = serverState === 'external';
  if (serverProc) {
    send('host-log', 'info', 'Khởi động lại server để áp dụng…');
    try { serverProc.kill(); } catch {}
    serverProc = null;
  }
  serverState = 'stopped';
  await new Promise((res) => setTimeout(res, 800));
  if (!wasExternal) await startServer();
  else send('host-log', 'warn', 'Server bên ngoài đang chạy với thư mục cũ — hãy tắt tiến trình đó để áp dụng thư mục mới.');
  return { ok: true, root: newRoot };
});
ipcMain.handle('ui-pick-camera', async () => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Chọn Ổ đĩa hoặc Thư mục Sao lưu Camera / Di động',
    properties: ['openDirectory', 'createDirectory'],
  });
  if (r.canceled || !r.filePaths.length) return { canceled: true };
  const newCam = r.filePaths[0];
  const cfg = readConfig();
  cfg.cameraPool = newCam;
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2));
  fs.mkdirSync(newCam, { recursive: true });
  send('host-log', 'info', `Thư mục sao lưu Camera: ${newCam}`);
  return { ok: true, path: newCam };
});
ipcMain.handle('ui-credentials', async (_e, args) => {
  try {
    args = args || {};
    const cfg = readConfig();
    const curName = String(cfg.adminUser || 'admin');
    const curPw = String(args.currentPassword || '');
    const newName = String(args.username || '').trim();
    const newPw = String(args.newPassword || '');
    if (!curPw) return { error: 'Hãy nhập mật khẩu hiện tại.' };
    if (newName && !/^[\w][\w .-]{1,31}$/i.test(newName)) return { error: 'Tên tài khoản không hợp lệ (2-32 ký tự chữ/số, dấu ._-).' };
    const sameName = newName.toLowerCase() === curName.toLowerCase();
    if (sameName && !newPw) return { error: 'Không có thay đổi nào.' };
    if (newPw && newPw.length < 6) return { error: 'Mật khẩu mới tối thiểu 6 ký tự.' };
    const port = readPort();
    if (!(await probe(port))) return { error: 'Server chưa chạy — hãy bật server trước.' };
    try { await loginAdmin(curName, curPw); } catch { return { error: 'Mật khẩu hiện tại không đúng.' }; }
    const body = { currentPassword: curPw };
    if (!sameName) body.adminUser = newName;
    if (newPw) body.password = newPw;
    const r = await serverApi('POST', '/api/settings', body);
    if (r.status !== 200) return { error: (r.data && r.data.error) || 'Lưu thất bại.' };
    adminToken = null;
    const changed = (r.data && r.data.changed) || [];
    send('host-log', 'ok', 'Đã đổi thông tin đăng nhập server: ' + (changed.join(', ') || 'không đổi'));
    return { ok: true, changed, username: sameName ? curName : newName };
  } catch (e) { return { error: e.message }; }
});
ipcMain.handle('ui-drives-get', async () => {
  try {
    const r = await serverApi('GET', '/api/drives');
    if (r.status !== 200) return { error: (r.data && r.data.error) || 'Không đọc được danh sách ổ.' };
    return { drives: r.data.drives || [], pools: r.data.pools || [] };
  } catch (e) { return { error: e.message }; }
});
ipcMain.handle('ui-drives-set', async (_e, payload) => {
  try {
    const r = await serverApi('POST', '/api/pools/config', payload || {});
    if (r.status !== 200) return { error: (r.data && r.data.error) || 'Lưu thất bại.' };
    send('host-log', 'ok', 'Đã cập nhật ổ lưu trữ chia sẻ (' + ((r.data.pools || []).length) + ' ổ).');
    return { ok: true, pools: r.data.pools || [] };
  } catch (e) { return { error: e.message }; }
});
ipcMain.handle('ui-open-external', (_e, url) => {
  if (typeof url === 'string' && /^https?:/i.test(url)) shell.openExternal(url);
  return true;
});
ipcMain.handle('win-control', (_e, action) => {
  if (!win || win.isDestroyed()) return { ok: false };
  if (action === 'min') win.minimize();
  else if (action === 'max') { if (win.isMaximized()) win.unmaximize(); else win.maximize(); }
  else if (action === 'close') win.close();
  else return { ok: false };
  try { win.webContents.send('win-maximized', win.isMaximized()); } catch {}
  return { ok: true };
});
ipcMain.handle('show-splash', () => {
  if (win) showSplash();
  stopServer();
  return { ok: true };
});
ipcMain.handle('ui-splash-only', () => {
  if (win) showSplash();
  return { ok: true };
});
ipcMain.handle('ui-retry', () => goApp());
ipcMain.handle('ui-admin-password', () => {
  const cfg = readConfig();
  return { username: String(cfg.adminUser || 'admin'), password: String(cfg.password || '') };
});
ipcMain.handle('ui-autostart-get', () => {
  try { return { ok: true, on: !!app.getLoginItemSettings().openAtLogin }; } catch { return { ok: false, on: false }; }
});
ipcMain.handle('ui-autostart-set', (_e, on) => {
  try {
    if (on) app.setLoginItemSettings({ openAtLogin: true, args: ['--hidden'] });
    else app.setLoginItemSettings({ openAtLogin: false, args: [] });
    return { ok: true, on: !!on };
  } catch (e) { return { ok: false, error: e.message }; }
});

ipcMain.handle('ui-fix-firewall', async () => {
  if (process.platform !== 'win32') return { ok: true };
  const p = readPort();
  const exe = process.execPath;
  const os = require('os');
  const tempBat = path.join(os.tmpdir(), `cw_fix_fw_${Date.now()}.bat`);
  const batContent = `@echo off
chcp 65001 >nul
netsh advfirewall firewall delete rule name="CW Datacenter Host" >nul 2>&1
netsh advfirewall firewall delete rule name="CW Datacenter Host (TCP ${p})" >nul 2>&1
netsh advfirewall firewall delete rule name="CW Datacenter Discovery (UDP 46631)" >nul 2>&1
netsh advfirewall firewall delete rule name="CW Datacenter Host Outbound" >nul 2>&1
netsh advfirewall firewall delete rule program="${exe}" >nul 2>&1
netsh advfirewall firewall add rule name="CW Datacenter Host (TCP ${p})" dir=in action=allow protocol=TCP localport=${p} profile=any enable=yes
netsh advfirewall firewall add rule name="CW Datacenter Discovery (UDP 46631)" dir=in action=allow protocol=UDP localport=46631 profile=any enable=yes
netsh advfirewall firewall add rule name="CW Datacenter Host" dir=in action=allow program="${exe}" profile=any enable=yes
netsh advfirewall firewall add rule name="CW Datacenter Host Outbound" dir=out action=allow program="${exe}" profile=any enable=yes
netsh advfirewall firewall set rule group="Network Discovery" new enable=Yes >nul 2>&1
exit 0
`;
  try {
    fs.writeFileSync(tempBat, batContent, 'utf8');
    return new Promise((resolve) => {
      const psScript = `Start-Process -FilePath cmd.exe -ArgumentList '/c "${tempBat}"' -Verb RunAs -Wait`;
      require('child_process').execFile('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', psScript], (err) => {
        setTimeout(() => { try { fs.unlinkSync(tempBat); } catch {} }, 1000);
        if (err) {
          send('host-log', 'err', 'Lỗi cấp quyền Tường lửa: ' + err.message);
          resolve({ ok: false, error: err.message });
        } else {
          send('host-log', 'ok', `Đã mở Tường lửa cho Port TCP ${p} và UDP 46631.`);
          resolve({ ok: true, port: p });
        }
      });
    });
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

const startHidden = process.argv.includes('--hidden');
app.whenReady().then(() => {
  createWindow();
  if (startHidden && win) win.hide();
  goApp();
});

app.on('second-instance', () => {
  if (win) { win.show(); win.focus(); }
});
app.on('window-all-closed', () => {
  if (forceQuit || process.platform === 'darwin') {
    if (serverProc) { try { serverProc.kill(); } catch {} }
    if (process.platform !== 'darwin') app.quit();
  }
});
app.on('before-quit', () => { forceQuit = true; if (serverProc) { try { serverProc.kill(); } catch {} } });
