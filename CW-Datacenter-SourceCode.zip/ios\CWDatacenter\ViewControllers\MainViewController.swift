import UIKit
import WebKit
import Network
import AVKit
import AVFoundation
import Photos
import PhotosUI
import UniformTypeIdentifiers
import PDFKit

class FileDownloadDelegate: NSObject, URLSessionDownloadDelegate {
    let downloadId: String
    let key: String
    let destUrl: URL
    let onProgress: ([String: Any]) -> Void
    var startTime = Date()
    private var lastProgressTime: Date = .distantPast

    init(downloadId: String, key: String, destUrl: URL, onProgress: @escaping ([String: Any]) -> Void) {
        self.downloadId = downloadId
        self.key = key
        self.destUrl = destUrl
        self.onProgress = onProgress
        super.init()
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        let now = Date()
        if now.timeIntervalSince(lastProgressTime) >= 0.25 || (totalBytesExpectedToWrite > 0 && totalBytesWritten >= totalBytesExpectedToWrite) {
            lastProgressTime = now
            let elapsed = now.timeIntervalSince(startTime)
            let speed = elapsed > 0 ? Int64(Double(totalBytesWritten) / elapsed) : 0
            let total = totalBytesExpectedToWrite > 0 ? totalBytesExpectedToWrite : totalBytesWritten
            onProgress([
                "type": "transfer",
                "id": downloadId,
                "key": key,
                "status": "active",
                "done": totalBytesWritten,
                "total": total,
                "speed": speed
            ])
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        try? FileManager.default.removeItem(at: destUrl)
        try? FileManager.default.moveItem(at: location, to: destUrl)
        let size = (try? destUrl.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
        onProgress([
            "type": "transfer",
            "id": downloadId,
            "key": key,
            "status": "done",
            "done": size,
            "total": size,
            "path": destUrl.path
        ])
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let err = error {
            onProgress([
                "type": "transfer",
                "id": downloadId,
                "key": key,
                "status": "error",
                "err": err.localizedDescription
            ])
        }
    }
}

class MainViewController: UIViewController, WKNavigationDelegate, WKScriptMessageHandler, UIScrollViewDelegate, UIDocumentPickerDelegate, PHPickerViewControllerDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    private var webView: WKWebView!
    private var isLoaded = false
    private var netBrowser: NWBrowser?
    private var pendingPickerCbId: String?

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .default
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.94, green: 0.96, blue: 1.0, alpha: 1.0)
        triggerLocalNetworkPermission()
        setupWebView()
        setupGestures()
        loadLocalApp()
    }

    private func setupGestures() {
        let edgePan = UIScreenEdgePanGestureRecognizer(target: self, action: #selector(handleEdgePan(_:)))
        edgePan.edges = .left
        webView.addGestureRecognizer(edgePan)
    }

    @objc private func handleEdgePan(_ gesture: UIScreenEdgePanGestureRecognizer) {
        guard gesture.state == .ended else { return }
        let js = """
        (function() {
            if (typeof onHardwareBack === 'function') {
                onHardwareBack();
            } else if (typeof closePreviewModal === 'function' && document.getElementById('pvModal')?.classList.contains('show')) {
                closePreviewModal();
            } else if (typeof goDir === 'function' && typeof parentPath !== 'undefined' && parentPath !== null) {
                goDir(parentPath);
            }
        })();
        """
        webView.evaluateJavaScript(js, completionHandler: nil)
    }

    private func triggerLocalNetworkPermission() {
        let params = NWParameters()
        params.includePeerToPeer = true
        let descriptor = NWBrowser.Descriptor.bonjour(type: "_http._tcp", domain: nil)
        netBrowser = NWBrowser(for: descriptor, using: params)
        netBrowser?.stateUpdateHandler = { _ in }
        netBrowser?.start(queue: .main)
    }

    override func viewSafeAreaInsetsDidChange() {
        super.viewSafeAreaInsetsDidChange()
        pushSafeAreaInsets()
    }

    private func setupWebView() {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        let userContent = WKUserContentController()
        userContent.add(self, name: "DC")

        // Comprehensive JS bridge helper matching Android Bridge API
        let bridgeJs = """
        window.DC = window.DC || {};
        window.DC.call = function(method, id, args) {
            window.webkit.messageHandlers.DC.postMessage({ method: method, id: id, args: args });
        };
        window.DC.getMeta = function() {
            return JSON.stringify({
                device: "iPhone",
                manufacturer: "Apple",
                brand: "Apple",
                model: "iPhone",
                ios: "iOS",
                platform: "ios"
            });
        };
        window.DC.getInsets = function() {
            return "47,34";
        };
        window.DC.loadKV = function(k) {
            try { return localStorage.getItem("cw_kv_" + k); } catch(e) { return null; }
        };
        window.DC.saveKV = function(k, v) {
            try { localStorage.setItem("cw_kv_" + k, v); } catch(e) {}
        };
        window.DC.removeKV = function(k) {
            try { localStorage.removeItem("cw_kv_" + k); } catch(e) {}
        };
        window.DC.setCanGoBack = function(can) {};
        window.DC.setSession = function(url, tk) {
            window.DC.call('setSession', '', [url, tk]);
        };
        window.DC.proxyUrl = function(rel, pool, video) { return ''; };
        window.DC.thumbUrl = function(rel, pool) { return ''; };
        window.DC.localFsUrl = function(rel) { return ''; };
        window.DC.toast = function(msg) {
            if (typeof showUiToast === 'function') {
                showUiToast(msg);
            } else {
                console.log("[CW_TOAST]", msg);
            }
        };
        document.addEventListener('gesturestart', function(e) { e.preventDefault(); }, { passive: false });
        document.addEventListener('gesturechange', function(e) { e.preventDefault(); }, { passive: false });
        document.addEventListener('gestureend', function(e) { e.preventDefault(); }, { passive: false });
        document.addEventListener('dblclick', function(e) { e.preventDefault(); }, { passive: false });
        
        // Prevent viewport zoom when keyboard opens
        var styleEl = document.createElement('style');
        styleEl.innerHTML = 'input, select, textarea { font-size: 16px !important; } html, body { overflow: hidden !important; -webkit-text-size-adjust: 100% !important; }';
        document.head.appendChild(styleEl);
        """
        let script = WKUserScript(source: bridgeJs, injectionTime: .atDocumentStart, forMainFrameOnly: true)
        userContent.addUserScript(script)
        config.userContentController = userContent

        webView = WKWebView(frame: view.bounds, configuration: config)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        webView.navigationDelegate = self
        webView.scrollView.delegate = self
        webView.scrollView.bounces = false
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.bouncesZoom = false
        webView.scrollView.pinchGestureRecognizer?.isEnabled = false
        webView.scrollView.maximumZoomScale = 1.0
        webView.scrollView.minimumZoomScale = 1.0
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.isOpaque = false
        webView.backgroundColor = .clear
        view.addSubview(webView)
    }

    // MARK: - UIScrollViewDelegate (Strictly Disable Zoom & Keyboard Jumps)
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return nil
    }

    func scrollViewWillBeginZooming(_ scrollView: UIScrollView, with view: UIView?) {
        scrollView.pinchGestureRecognizer?.isEnabled = false
    }

    private func loadLocalApp() {
        if let webDir = Bundle.main.url(forResource: "Web", withExtension: nil) {
            let indexUrl = webDir.appendingPathComponent("index.html")
            webView.loadFileURL(indexUrl, allowingReadAccessTo: webDir)
        } else if let indexUrl = Bundle.main.url(forResource: "index", withExtension: "html") {
            webView.loadFileURL(indexUrl, allowingReadAccessTo: indexUrl.deletingLastPathComponent())
        }
    }

    private func pushSafeAreaInsets() {
        let insets = view.safeAreaInsets
        let top = Int(insets.top)
        let bottom = Int(insets.bottom)
        let js = "window.DC && DC._insets && DC._insets(\(top), \(bottom));"
        webView?.evaluateJavaScript(js, completionHandler: nil)
    }

    // MARK: - WKNavigationDelegate
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        isLoaded = true
        pushSafeAreaInsets()
    }

    // MARK: - WKScriptMessageHandler
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "DC", let body = message.body as? [String: Any] else { return }
        let method = body["method"] as? String ?? ""
        let cbId = body["id"] as? String ?? ""
        
        var args: [Any] = []
        if let arr = body["args"] as? [Any] {
            args = arr
        } else if let argsStr = body["args"] as? String {
            if let data = argsStr.data(using: .utf8), let parsed = try? JSONSerialization.jsonObject(with: data) as? [Any] {
                args = parsed
            } else if !argsStr.isEmpty {
                args = [argsStr]
            }
        }

        handleNativeCall(method: method, cbId: cbId, args: args)
    }

    private func handleNativeCall(method: String, cbId: String, args: [Any]) {
        switch method {
        case "invoke":
            let httpMethod = args.indices.contains(0) ? (args[0] as? String ?? "GET") : "GET"
            var urlString = args.indices.contains(1) ? (args[1] as? String ?? "") : ""
            let headersJson = args.indices.contains(2) ? (args[2] as? String ?? "{}") : "{}"
            let bodyStr = args.indices.contains(3) ? (args[3] as? String) : nil

            urlString = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
            if !urlString.starts(with: "http://") && !urlString.starts(with: "https://") {
                urlString = "http://" + urlString
            }

            guard let url = URL(string: urlString) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"URL không hợp lệ: \(urlString)\"}")
                return
            }

            var request = URLRequest(url: url, timeoutInterval: 15)
            request.httpMethod = httpMethod
            if let headersData = headersJson.data(using: .utf8),
               let headers = try? JSONSerialization.jsonObject(with: headersData) as? [String: String] {
                for (k, v) in headers {
                    request.setValue(v, forHTTPHeaderField: k)
                }
            }
            if let bodyStr = bodyStr, !bodyStr.isEmpty, httpMethod != "GET" && httpMethod != "HEAD" {
                if request.value(forHTTPHeaderField: "Content-Type") == nil {
                    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                }
                request.httpBody = bodyStr.data(using: .utf8)
            }

            let sessionConfig = URLSessionConfiguration.default
            sessionConfig.timeoutIntervalForRequest = 15
            sessionConfig.timeoutIntervalForResource = 30
            sessionConfig.requestCachePolicy = .reloadIgnoringLocalCacheData
            let session = URLSession(configuration: sessionConfig)

            session.dataTask(with: request) { [weak self] data, response, error in
                if let error = error {
                    let errMsg = error.localizedDescription
                    let payload: [String: Any] = [
                        "status": 0,
                        "text": "{\"error\":\"\(errMsg)\"}",
                        "err": errMsg
                    ]
                    if let resData = try? JSONSerialization.data(withJSONObject: payload),
                       let resJson = String(data: resData, encoding: .utf8) {
                        self?.callback(cbId: cbId, ok: false, json: resJson)
                    } else {
                        self?.callback(cbId: cbId, ok: false, json: "{\"err\":\"\(errMsg)\"}")
                    }
                    return
                }
                let status = (response as? HTTPURLResponse)?.statusCode ?? 200
                let text = data.flatMap { String(data: $0, encoding: .utf8) } ?? ""
                
                let payload: [String: Any] = [
                    "status": status,
                    "text": text
                ]
                if let resData = try? JSONSerialization.data(withJSONObject: payload),
                   let resJson = String(data: resData, encoding: .utf8) {
                    self?.callback(cbId: cbId, ok: true, json: resJson)
                } else {
                    self?.callback(cbId: cbId, ok: true, json: "{\"status\":\(status),\"text\":\"\"}")
                }
            }.resume()

        case "discover", "scanLan":
            performLanDiscovery { [weak self] hosts in
                let payload: [String: Any] = ["hosts": hosts]
                if let resData = try? JSONSerialization.data(withJSONObject: payload),
                   let resJson = String(data: resData, encoding: .utf8) {
                    self?.callback(cbId: cbId, ok: true, json: resJson)
                } else {
                    self?.callback(cbId: cbId, ok: true, json: "{\"hosts\":[]}")
                }
            }

        case "toast":
            let msg = args.first as? String ?? ""
            DispatchQueue.main.async { [weak self] in
                let alert = UIAlertController(title: nil, message: msg, preferredStyle: .alert)
                self?.present(alert, animated: true)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    alert.dismiss(animated: true)
                }
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "setSession":
            let baseUrl = args.indices.contains(0) ? (args[0] as? String ?? "") : ""
            let token = args.indices.contains(1) ? (args[1] as? String ?? "") : ""
            LocalProxy.shared.setAuth(baseUrl: baseUrl, token: token)
            UserDefaults.standard.set(baseUrl, forKey: "cw_base_url")
            UserDefaults.standard.set(token, forKey: "cw_token")
            callback(cbId: cbId, ok: true, json: "{}")

        case "proxyUrl":
            let rel = args.indices.contains(0) ? (args[0] as? String ?? "") : ""
            let pool = args.indices.contains(1) ? (args[1] as? String) : nil
            let isVideo = args.indices.contains(2) ? (args[2] as? Bool ?? false) : false
            let pUrl = LocalProxy.shared.urlFor(relEncoded: rel, poolEncoded: pool, video: isVideo)
            callback(cbId: cbId, ok: true, json: "\"\(pUrl)\"")

        case "thumbUrl":
            let rel = args.indices.contains(0) ? (args[0] as? String ?? "") : ""
            let pool = args.indices.contains(1) ? (args[1] as? String) : nil
            let tUrl = LocalProxy.shared.thumbUrl(relEncoded: rel, poolEncoded: pool)
            callback(cbId: cbId, ok: true, json: "\"\(tUrl)\"")

        case "getInsets":
            let insets = view.safeAreaInsets
            callback(cbId: cbId, ok: true, json: "\"\(Int(insets.top)),\(Int(insets.bottom))\"")

        case "localFsStatus":
            callback(cbId: cbId, ok: true, json: "{\"ok\":true,\"sdk\":17}")

        case "requestLocalFsAccess":
            callback(cbId: cbId, ok: true, json: "{\"ok\":true}")

        case "localFsInfo":
            let docs = localDocumentsDirectory
            var freeBytes: Int64 = 50 * 1024 * 1024 * 1024
            var totalBytes: Int64 = 128 * 1024 * 1024 * 1024
            if let values = try? docs.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey, .volumeTotalCapacityKey]) {
                freeBytes = values.volumeAvailableCapacityForImportantUsage ?? freeBytes
                totalBytes = Int64(values.volumeTotalCapacity ?? Int(totalBytes))
            }
            let payload: [String: Any] = [
                "free": freeBytes,
                "total": totalBytes,
                "rootPath": docs.path,
                "path": docs.path,
                "parentId": docs.path,
                "ok": true
            ]
            if let d = try? JSONSerialization.data(withJSONObject: payload), let j = String(data: d, encoding: .utf8) {
                callback(cbId: cbId, ok: true, json: j)
            } else {
                callback(cbId: cbId, ok: true, json: "{\"free\":50000000000,\"total\":128000000000,\"rootPath\":\"\(docs.path)\",\"path\":\"\(docs.path)\",\"parentId\":\"\(docs.path)\"}")
            }

        case "localFsList":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let reqPath = params["path"] as? String ?? ""
            let targetDir: URL
            if reqPath.isEmpty || reqPath.contains("/storage/emulated/0") {
                targetDir = localDocumentsDirectory
            } else if reqPath.starts(with: "/") {
                targetDir = URL(fileURLWithPath: reqPath)
            } else {
                targetDir = localDocumentsDirectory.appendingPathComponent(reqPath)
            }
            
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                guard let self = self else { return }
                var entries: [[String: Any]] = []
                let fileManager = FileManager.default
                if let items = try? fileManager.contentsOfDirectory(at: targetDir, includingPropertiesForKeys: [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey], options: [.skipsHiddenFiles]) {
                    for item in items {
                        let values = try? item.resourceValues(forKeys: [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey])
                        let isDir = values?.isDirectory ?? false
                        let size = Int64(values?.fileSize ?? 0)
                        let mtime = Int64((values?.contentModificationDate?.timeIntervalSince1970 ?? 0) * 1000)
                        entries.append([
                            "name": item.lastPathComponent,
                            "type": isDir ? "dir" : "file",
                            "dir": isDir,
                            "size": size,
                            "mtime": mtime,
                            "p": item.path,
                            "id": item.path,
                            "path": item.path,
                            "local": true
                        ])
                    }
                }
                let payload: [String: Any] = [
                    "path": targetDir.path,
                    "parentId": targetDir.path,
                    "entries": entries,
                    "ok": true
                ]
                if let d = try? JSONSerialization.data(withJSONObject: payload), let j = String(data: d, encoding: .utf8) {
                    self.callback(cbId: cbId, ok: true, json: j)
                } else {
                    self.callback(cbId: cbId, ok: true, json: "{\"entries\":[]}")
                }
            }

        case "localFsDeepList":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let reqPath = params["path"] as? String ?? ""
            let baseDir: URL
            if reqPath.isEmpty || reqPath.contains("/storage/emulated/0") {
                baseDir = localDocumentsDirectory
            } else if reqPath.starts(with: "/") {
                baseDir = URL(fileURLWithPath: reqPath)
            } else {
                baseDir = localDocumentsDirectory.appendingPathComponent(reqPath)
            }
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                guard let self = self else { return }
                var files: [[String: Any]] = []
                let fileManager = FileManager.default
                if let enumerator = fileManager.enumerator(at: baseDir, includingPropertiesForKeys: [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey], options: [.skipsHiddenFiles]) {
                    for case let fileUrl as URL in enumerator {
                        let values = try? fileUrl.resourceValues(forKeys: [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey])
                        if values?.isDirectory != true {
                            let rel = fileUrl.path.replacingOccurrences(of: baseDir.path + "/", with: "")
                            let size = Int64(values?.fileSize ?? 0)
                            let mtime = Int64((values?.contentModificationDate?.timeIntervalSince1970 ?? 0) * 1000)
                            files.append([
                                "name": fileUrl.lastPathComponent,
                                "rel": rel,
                                "p": fileUrl.path,
                                "size": size,
                                "mtime": mtime
                            ])
                        }
                    }
                }
                let payload: [String: Any] = ["files": files, "ok": true]
                if let d = try? JSONSerialization.data(withJSONObject: payload), let j = String(data: d, encoding: .utf8) {
                    self.callback(cbId: cbId, ok: true, json: j)
                } else {
                    self.callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
                }
            }

        case "openDownloads":
            let docs = localDocumentsDirectory
            DispatchQueue.main.async { [weak self] in
                let activityVc = UIActivityViewController(activityItems: [docs], applicationActivities: nil)
                if let popover = activityVc.popoverPresentationController {
                    popover.sourceView = self?.view
                    popover.sourceRect = CGRect(x: self?.view.bounds.midX ?? 0, y: self?.view.bounds.midY ?? 0, width: 0, height: 0)
                    popover.permittedArrowDirections = []
                }
                self?.present(activityVc, animated: true)
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "localFsMkdir":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let path = params["path"] as? String ?? ""
            let name = params["name"] as? String ?? "Thư mục mới"
            let parentDir = path.isEmpty ? localDocumentsDirectory : URL(fileURLWithPath: path)
            let newDir = parentDir.appendingPathComponent(name)
            try? FileManager.default.createDirectory(at: newDir, withIntermediateDirectories: true)
            callback(cbId: cbId, ok: true, json: "{}")

        case "localFsDelete":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let path = params["path"] as? String ?? ""
            if !path.isEmpty {
                try? FileManager.default.removeItem(atPath: path)
            }
            callback(cbId: cbId, ok: true, json: "{}")

        case "localFsMove":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let from = params["from"] as? String ?? ""
            let to = params["to"] as? String ?? ""
            if !from.isEmpty && !to.isEmpty {
                try? FileManager.default.moveItem(atPath: from, toPath: to)
            }
            callback(cbId: cbId, ok: true, json: "{}")

        case "playVideo":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            var urlString = params["url"] as? String ?? ""
            let name = params["name"] as? String ?? "Đang phát video"
            let rel = params["rel"] as? String ?? ""
            let pool = params["pool"] as? String ?? ""
            let startPos = params["startPos"] as? Int64 ?? -1
            var playlist: [[String: Any]] = []
            if let pl = params["playlist"] as? [[String: Any]] {
                playlist = pl
            } else if let plStr = params["playlist"] as? String, let plData = plStr.data(using: .utf8),
                      let parsed = (try? JSONSerialization.jsonObject(with: plData)) as? [[String: Any]] {
                playlist = parsed
            }

            let base = (params["baseUrl"] as? String ?? LocalProxy.shared.baseUrl).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            let token = params["token"] as? String ?? LocalProxy.shared.token
            if urlString.isEmpty && !rel.isEmpty {
                urlString = "\(base)/api/video?path=\(rel.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? rel)"
                if !pool.isEmpty { urlString += "&pool=\(pool)" }
            }
            if !token.isEmpty && !urlString.contains("token=") && !urlString.starts(with: "file:") {
                urlString += (urlString.contains("?") ? "&" : "?") + "token=\(token)"
            }
            if !urlString.contains("ios=") && !urlString.starts(with: "file:") {
                urlString += (urlString.contains("?") ? "&" : "?") + "ios=1"
            }

            guard let _ = URL(string: urlString) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"URL video không hợp lệ\"}")
                return
            }

            try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback, options: [])
            try? AVAudioSession.sharedInstance().setActive(true)

            DispatchQueue.main.async { [weak self] in
                let playerVc = PlayerViewController(url: urlString, name: name, playlist: playlist, startPos: startPos)
                playerVc.modalPresentationStyle = .fullScreen
                self?.present(playerVc, animated: true, completion: nil)
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "openPdf":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            var url = params["url"] as? String ?? ""
            let rel = params["rel"] as? String ?? ""
            let pool = params["pool"] as? String ?? ""
            let name = params["name"] as? String ?? "Tài liệu PDF"
            let localPath = params["path"] as? String ?? ""

            if url.isEmpty && !localPath.isEmpty {
                url = URL(fileURLWithPath: localPath).absoluteString
            } else if url.isEmpty && !rel.isEmpty {
                url = "\(LocalProxy.shared.baseUrl)/api/file?path=\(rel.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? rel)&preview=1"
                if !pool.isEmpty { url += "&pool=\(pool)" }
            }
            if !LocalProxy.shared.token.isEmpty && !url.contains("token=") && !url.starts(with: "file:") {
                url += (url.contains("?") ? "&" : "?") + "token=\(LocalProxy.shared.token)"
            }

            DispatchQueue.main.async { [weak self] in
                let pdfVc = PdfViewController(url: url, titleText: name)
                let nav = UINavigationController(rootViewController: pdfVc)
                nav.modalPresentationStyle = .fullScreen
                self?.present(nav, animated: true)
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "openPhoto":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            var playlist: [[String: Any]] = []
            if let pl = params["playlist"] as? [[String: Any]] {
                playlist = pl
            } else if let plStr = params["playlist"] as? String, let plData = plStr.data(using: .utf8),
                      let parsedPl = (try? JSONSerialization.jsonObject(with: plData)) as? [[String: Any]] {
                playlist = parsedPl
            } else {
                let url = params["url"] as? String ?? ""
                let name = params["name"] as? String ?? "Hình ảnh"
                let localPath = params["localPath"] as? String ?? ""
                playlist = [["name": name, "url": url, "localPath": localPath]]
            }
            let initialIndex = params["initialIndex"] as? Int ?? 0

            DispatchQueue.main.async { [weak self] in
                let imgVc = ImageViewController(playlist: playlist, initialIndex: initialIndex)
                imgVc.modalPresentationStyle = .fullScreen
                self?.present(imgVc, animated: true)
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "pickFiles":
            self.pendingPickerCbId = cbId
            DispatchQueue.main.async { [weak self] in
                let alert = UIAlertController(title: "Tải tệp lên", message: "Chọn nguồn tệp", preferredStyle: .actionSheet)
                alert.addAction(UIAlertAction(title: "📁 Chọn từ ứng dụng Tệp (Files)", style: .default) { _ in
                    let docPicker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType.item], asCopy: true)
                    docPicker.delegate = self
                    docPicker.allowsMultipleSelection = true
                    self?.present(docPicker, animated: true)
                })
                alert.addAction(UIAlertAction(title: "🖼️ Chọn từ Thư viện Ảnh / Video", style: .default) { _ in
                    var config = PHPickerConfiguration()
                    config.selectionLimit = 0 // unlimited
                    config.filter = .any(of: [.images, .videos])
                    let picker = PHPickerViewController(configuration: config)
                    picker.delegate = self
                    self?.present(picker, animated: true)
                })
                alert.addAction(UIAlertAction(title: "📷 Chụp ảnh / Quay video", style: .default) { _ in
                    guard UIImagePickerController.isSourceTypeAvailable(.camera) else {
                        self?.callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
                        return
                    }
                    let picker = UIImagePickerController()
                    picker.sourceType = .camera
                    picker.delegate = self
                    self?.present(picker, animated: true)
                })
                alert.addAction(UIAlertAction(title: "Hủy", style: .cancel) { _ in
                    self?.callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
                })
                if let popover = alert.popoverPresentationController {
                    popover.sourceView = self?.view
                    popover.sourceRect = CGRect(x: self?.view.bounds.midX ?? 0, y: self?.view.bounds.midY ?? 0, width: 0, height: 0)
                    popover.permittedArrowDirections = []
                }
                self?.present(alert, animated: true)
            }

        case "upload":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let baseUrl = (params["baseUrl"] as? String ?? LocalProxy.shared.baseUrl).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            let token = params["token"] as? String ?? LocalProxy.shared.token
            let pool = params["pool"] as? String ?? ""
            let relPath = params["path"] as? String ?? ""
            let name = params["name"] as? String ?? "file"
            let uriString = params["uri"] as? String ?? (params["file"] as? String ?? "")
            let defaultKey = relPath.contains(":") ? relPath : "up:\(relPath)"
            let transferKey = params["key"] as? String ?? defaultKey
            let uploadId = "ul-\(abs(relPath.hashValue))-\(Int(Date().timeIntervalSince1970))"

            var fileUrl: URL? = nil
            if uriString.starts(with: "file://"), let u = URL(string: uriString) {
                fileUrl = u
            } else if FileManager.default.fileExists(atPath: uriString) {
                fileUrl = URL(fileURLWithPath: uriString)
            } else if let u = URL(string: uriString), FileManager.default.fileExists(atPath: u.path) {
                fileUrl = u
            }

            guard let finalUrl = fileUrl else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Không tìm thấy tệp nguồn\"}")
                return
            }

            self.callback(cbId: cbId, ok: true, json: "{\"id\":\"\(uploadId)\",\"done\":false}")

            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                guard let self = self else { return }
                do {
                    let fileData = try Data(contentsOf: finalUrl)
                    let totalSize = Int64(fileData.count)

                    // 1. Init Upload
                    guard let initUrl = URL(string: "\(baseUrl)/api/upload/init") else { return }
                    var initReq = URLRequest(url: initUrl, timeoutInterval: 30)
                    initReq.httpMethod = "POST"
                    initReq.setValue("application/json", forHTTPHeaderField: "Content-Type")
                    if !token.isEmpty { initReq.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
                    let initPayload: [String: Any] = ["path": relPath, "pool": pool, "size": totalSize]
                    initReq.httpBody = try? JSONSerialization.data(withJSONObject: initPayload)

                    let sema = DispatchSemaphore(value: 0)
                    var serverUploadId = ""
                    var serverOffset: Int64 = 0
                    var initSuccess = false

                    let initTask = URLSession.shared.dataTask(with: initReq) { data, resp, err in
                        defer { sema.signal() }
                        if let d = data, let obj = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any] {
                            serverUploadId = obj["uploadId"] as? String ?? ""
                            serverOffset = Int64(obj["offset"] as? Int ?? 0)
                            initSuccess = !serverUploadId.isEmpty
                        }
                    }
                    initTask.resume()
                    sema.wait()

                    guard initSuccess else {
                        self.emitEvent([
                            "type": "transfer",
                            "id": uploadId,
                            "key": transferKey,
                            "status": "error",
                            "err": "Khởi tạo upload thất bại"
                        ])
                        return
                    }

                    // 2. Send Chunks
                    let chunkSize = 512 * 1024
                    var currentOffset = serverOffset
                    var uploadError: String? = nil
                    let startTime = Date()
                    var lastProgressTime = Date.distantPast

                    while currentOffset < totalSize {
                        let length = min(Int64(chunkSize), totalSize - currentOffset)
                        let chunk = fileData.subdata(in: Int(currentOffset)..<Int(currentOffset + length))

                        guard let chunkUrl = URL(string: "\(baseUrl)/api/upload/chunk?id=\(serverUploadId)&offset=\(currentOffset)") else { break }
                        var chunkReq = URLRequest(url: chunkUrl, timeoutInterval: 60)
                        chunkReq.httpMethod = "POST"
                        chunkReq.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
                        if !token.isEmpty { chunkReq.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
                        chunkReq.httpBody = chunk

                        let chunkSema = DispatchSemaphore(value: 0)
                        var chunkOk = false

                        let chunkTask = URLSession.shared.dataTask(with: chunkReq) { _, resp, err in
                            defer { chunkSema.signal() }
                            if let http = resp as? HTTPURLResponse, http.statusCode == 200 {
                                chunkOk = true
                            } else {
                                uploadError = err?.localizedDescription ?? "Lỗi gửi khối dữ liệu"
                            }
                        }
                        chunkTask.resume()
                        chunkSema.wait()

                        guard chunkOk else { break }
                        currentOffset += length

                        let now = Date()
                        if now.timeIntervalSince(lastProgressTime) >= 0.25 || currentOffset >= totalSize {
                            lastProgressTime = now
                            let elapsed = now.timeIntervalSince(startTime)
                            let speed = elapsed > 0 ? Int64(Double(currentOffset) / elapsed) : 0

                            self.emitEvent([
                                "type": "transfer",
                                "id": uploadId,
                                "key": transferKey,
                                "status": "active",
                                "done": currentOffset,
                                "total": totalSize,
                                "speed": speed
                            ])
                        }
                    }

                    // 3. Complete Upload
                    if currentOffset >= totalSize {
                        guard let compUrl = URL(string: "\(baseUrl)/api/upload/complete") else { return }
                        var compReq = URLRequest(url: compUrl, timeoutInterval: 30)
                        compReq.httpMethod = "POST"
                        compReq.setValue("application/json", forHTTPHeaderField: "Content-Type")
                        if !token.isEmpty { compReq.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
                        compReq.httpBody = try? JSONSerialization.data(withJSONObject: ["uploadId": serverUploadId])

                        let compSema = DispatchSemaphore(value: 0)
                        var compOk = false
                        let compTask = URLSession.shared.dataTask(with: compReq) { _, resp, _ in
                            defer { compSema.signal() }
                            if let http = resp as? HTTPURLResponse, http.statusCode == 200 {
                                compOk = true
                            }
                        }
                        compTask.resume()
                        compSema.wait()

                        if compOk {
                            self.emitEvent([
                                "type": "transfer",
                                "id": uploadId,
                                "key": transferKey,
                                "status": "done",
                                "done": totalSize,
                                "total": totalSize
                            ])
                            return
                        }
                    }

                    self.emitEvent([
                        "type": "transfer",
                        "id": uploadId,
                        "key": transferKey,
                        "status": "error",
                        "err": uploadError ?? "Hoàn tất upload thất bại"
                    ])

                } catch {
                    self.emitEvent([
                        "type": "transfer",
                        "id": uploadId,
                        "key": transferKey,
                        "status": "error",
                        "err": error.localizedDescription
                    ])
                }
            }

        case "download", "localFsDownload":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            var urlString = params["url"] as? String ?? ""
            let name = params["name"] as? String ?? "file"
            let rel = params["rel"] as? String ?? name
            let pool = params["pool"] as? String ?? ""
            let localSrcPath = params["p"] as? String ?? ""
            let downloadId = "dl-\(abs(name.hashValue))-\(Int(Date().timeIntervalSince1970))"

            if !localSrcPath.isEmpty && FileManager.default.fileExists(atPath: localSrcPath) {
                let destDir = self.localDocumentsDirectory
                let destFile = destDir.appendingPathComponent(name)
                try? FileManager.default.removeItem(at: destFile)
                try? FileManager.default.copyItem(atPath: localSrcPath, toPath: destFile.path)
                let total = (try? destFile.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
                self.callback(cbId: cbId, ok: true, json: "{\"id\":\"\(downloadId)\",\"done\":true,\"path\":\"\(destFile.path)\"}")
                self.emitEvent([
                    "type": "transfer",
                    "id": downloadId,
                    "key": "dl:\(rel):\(pool)",
                    "status": "done",
                    "done": total,
                    "total": total,
                    "path": destFile.path
                ])
                return
            }

            let base = LocalProxy.shared.baseUrl
            let token = LocalProxy.shared.token
            if urlString.isEmpty && !rel.isEmpty {
                urlString = "\(base)/api/file?path=\(rel.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? rel)&download=1"
                if !pool.isEmpty { urlString += "&pool=\(pool)" }
            }

            guard let url = URL(string: urlString) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"URL download không hợp lệ\"}")
                return
            }

            self.callback(cbId: cbId, ok: true, json: "{\"id\":\"\(downloadId)\"}")

            var request = URLRequest(url: url, timeoutInterval: 120)
            if !token.isEmpty {
                request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            }

            let destDir = self.localDocumentsDirectory
            let destFile = destDir.appendingPathComponent(name)

            let downloadDelegate = FileDownloadDelegate(downloadId: downloadId, key: "dl:\(rel):\(pool)", destUrl: destFile) { [weak self] event in
                self?.emitEvent(event)
            }
            let session = URLSession(configuration: .default, delegate: downloadDelegate, delegateQueue: nil)
            let task = session.downloadTask(with: request)
            task.resume()

        case "copyClipboard":
            let text = args.first as? String ?? ""
            UIPasteboard.general.string = text
            callback(cbId: cbId, ok: true, json: "{}")

        case "getVideoProgress":
            let key = args.first as? String ?? ""
            let pos = UserDefaults.standard.integer(forKey: "vpos_" + key)
            callback(cbId: cbId, ok: true, json: "{\"pos\":\(pos)}")

        case "clearVideoProgress":
            let key = args.first as? String ?? ""
            UserDefaults.standard.removeObject(forKey: "vpos_" + key)
            callback(cbId: cbId, ok: true, json: "{}")

        case "exitApp":
            UIControl().sendAction(#selector(NSXPCConnection.suspend), to: UIApplication.shared, for: nil)
            callback(cbId: cbId, ok: true, json: "{}")

        default:
            callback(cbId: cbId, ok: true, json: "{}")
        }
    }

    // MARK: - Local Documents Path
    private var localDocumentsDirectory: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let dir = docs.appendingPathComponent("CW-Datacenter")
        let fm = FileManager.default
        if !fm.fileExists(atPath: dir.path) {
            try? fm.createDirectory(at: dir, withIntermediateDirectories: true, attributes: nil)
        }
        for sub in ["Tải về", "Hình ảnh", "Tài liệu"] {
            let subDir = dir.appendingPathComponent(sub)
            if !fm.fileExists(atPath: subDir.path) {
                try? fm.createDirectory(at: subDir, withIntermediateDirectories: true, attributes: nil)
            }
        }
        return dir
    }

    private func emitEvent(_ obj: [String: Any]) {
        guard let data = try? JSONSerialization.data(withJSONObject: obj),
              let jsonStr = String(data: data, encoding: .utf8) else { return }
        DispatchQueue.main.async { [weak self] in
            if let jsData = try? JSONSerialization.data(withJSONObject: [jsonStr]),
               let jsStr = String(data: jsData, encoding: .utf8) {
                let inner = String(jsStr.dropFirst().dropLast())
                let js = "window.DC && DC._evt && DC._evt(\(inner));"
                self?.webView?.evaluateJavaScript(js, completionHandler: nil)
            }
        }
    }

    // MARK: - UIDocumentPickerDelegate
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let cbId = pendingPickerCbId else { return }
        pendingPickerCbId = nil
        var files: [[String: Any]] = []
        for url in urls {
            let start = url.startAccessingSecurityScopedResource()
            defer { if start { url.stopAccessingSecurityScopedResource() } }
            let size = (try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
            let tmpDst = FileManager.default.temporaryDirectory.appendingPathComponent(url.lastPathComponent)
            try? FileManager.default.removeItem(at: tmpDst)
            try? FileManager.default.copyItem(at: url, to: tmpDst)
            files.append([
                "name": url.lastPathComponent,
                "uri": tmpDst.path,
                "size": size
            ])
        }
        let payload: [String: Any] = ["files": files]
        if let d = try? JSONSerialization.data(withJSONObject: payload), let j = String(data: d, encoding: .utf8) {
            callback(cbId: cbId, ok: true, json: j)
        } else {
            callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
        }
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        guard let cbId = pendingPickerCbId else { return }
        pendingPickerCbId = nil
        callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
    }

    // MARK: - PHPickerViewControllerDelegate
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        guard let cbId = pendingPickerCbId else { return }
        pendingPickerCbId = nil
        guard !results.isEmpty else {
            callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
            return
        }

        let group = DispatchGroup()
        var files: [[String: Any]] = []
        let lock = NSLock()

        for result in results {
            group.enter()
            result.itemProvider.loadFileRepresentation(forTypeIdentifier: UTType.item.identifier) { url, error in
                defer { group.leave() }
                guard let srcUrl = url else { return }
                let filename = srcUrl.lastPathComponent
                let dst = FileManager.default.temporaryDirectory.appendingPathComponent(filename)
                try? FileManager.default.removeItem(at: dst)
                try? FileManager.default.copyItem(at: srcUrl, to: dst)
                let size = (try? dst.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
                lock.lock()
                files.append([
                    "name": filename,
                    "uri": dst.path,
                    "size": size
                ])
                lock.unlock()
            }
        }

        group.notify(queue: .main) { [weak self] in
            let payload: [String: Any] = ["files": files]
            if let d = try? JSONSerialization.data(withJSONObject: payload), let j = String(data: d, encoding: .utf8) {
                self?.callback(cbId: cbId, ok: true, json: j)
            } else {
                self?.callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
            }
        }
    }

    // MARK: - UIImagePickerControllerDelegate
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)
        guard let cbId = pendingPickerCbId else { return }
        pendingPickerCbId = nil

        if let img = info[.originalImage] as? UIImage, let data = img.jpegData(compressionQuality: 0.9) {
            let filename = "IMG_\(Int(Date().timeIntervalSince1970)).jpg"
            let dst = FileManager.default.temporaryDirectory.appendingPathComponent(filename)
            try? data.write(to: dst)
            let files: [[String: Any]] = [["name": filename, "uri": dst.path, "size": data.count]]
            let payload: [String: Any] = ["files": files]
            if let d = try? JSONSerialization.data(withJSONObject: payload), let j = String(data: d, encoding: .utf8) {
                callback(cbId: cbId, ok: true, json: j)
                return
            }
        }
        callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
        guard let cbId = pendingPickerCbId else { return }
        pendingPickerCbId = nil
        callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
    }

    private func parseJsonObject(_ obj: Any?) -> [String: Any]? {
        guard let str = obj as? String, let data = str.data(using: .utf8) else { return nil }
        return (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
    }

    private func callback(cbId: String, ok: Bool, json: String) {
        guard !cbId.isEmpty else { return }
        DispatchQueue.main.async { [weak self] in
            if let jsData = try? JSONSerialization.data(withJSONObject: [json]),
               let jsStr = String(data: jsData, encoding: .utf8) {
                let inner = String(jsStr.dropFirst().dropLast())
                let js = """
                (function() {
                    if (window.DC && typeof DC._cb === 'function') {
                        DC._cb('\(cbId)', \(ok), \(inner));
                    } else if (window.DC && typeof DC._cbObj === 'function') {
                        DC._cbObj({ id: '\(cbId)', ok: \(ok), data: \(json) });
                    }
                })();
                """
                self?.webView?.evaluateJavaScript(js, completionHandler: nil)
            }
        }
    }

    // MARK: - LAN Discovery
    private func performLanDiscovery(completion: @escaping ([[String: Any]]) -> Void) {
        var foundHosts: [[String: Any]] = []
        let lock = NSLock()
        
        var prefixes: Set<String> = []
        var broadcastAddrs: Set<String> = ["255.255.255.255"]
        
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        if getifaddrs(&ifaddr) == 0 {
            var ptr = ifaddr
            while ptr != nil {
                let flags = Int32(ptr!.pointee.ifa_flags)
                let addr = ptr!.pointee.ifa_addr.pointee
                if (flags & Int32(IFF_UP)) != 0 && (flags & Int32(IFF_LOOPBACK)) == 0 {
                    if addr.sa_family == UInt8(AF_INET) {
                        var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                        if getnameinfo(ptr!.pointee.ifa_addr, socklen_t(addr.sa_len), &hostname, socklen_t(hostname.count), nil, 0, NI_NUMERICHOST) == 0 {
                            let ip = String(cString: hostname)
                            if !ip.starts(with: "127.") && !ip.starts(with: "169.254.") {
                                let parts = ip.split(separator: ".")
                                if parts.count == 4 {
                                    let pref = "\(parts[0]).\(parts[1]).\(parts[2])."
                                    prefixes.insert(pref)
                                    broadcastAddrs.insert("\(pref)255")
                                }
                            }
                        }
                    }
                }
                ptr = ptr!.pointee.ifa_next
            }
            freeifaddrs(ifaddr)
        }
        
        if prefixes.isEmpty {
            prefixes.insert("192.168.1.")
            prefixes.insert("192.168.0.")
            prefixes.insert("192.168.2.")
            prefixes.insert("192.168.31.")
            prefixes.insert("172.20.10.")
            prefixes.insert("10.0.0.")
        }
        
        let group = DispatchGroup()
        
        // 1. UDP Broadcast Discovery to Port 46631
        group.enter()
        DispatchQueue.global(qos: .userInitiated).async {
            let sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)
            if sock >= 0 {
                var broadcastEnable: Int32 = 1
                setsockopt(sock, SOL_SOCKET, SO_BROADCAST, &broadcastEnable, socklen_t(MemoryLayout<Int32>.size))
                var tv = timeval(tv_sec: 0, tv_usec: 300000)
                setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))
                
                let msg = "CW-DISCOVER"
                if let msgData = msg.data(using: .utf8) {
                    msgData.withUnsafeBytes { rawBuffer in
                        for bAddr in broadcastAddrs {
                            var addr = sockaddr_in()
                            addr.sin_family = sa_family_t(AF_INET)
                            addr.sin_port = in_port_t(46631).bigEndian
                            addr.sin_addr.s_addr = inet_addr(bAddr)
                            
                            withUnsafePointer(to: &addr) { addrPtr in
                                addrPtr.withMemoryRebound(to: sockaddr.self, capacity: 1) { saPtr in
                                    _ = sendto(sock, rawBuffer.baseAddress, rawBuffer.count, 0, saPtr, socklen_t(MemoryLayout<sockaddr_in>.size))
                                }
                            }
                        }
                    }
                }
                
                var recvBuf = [UInt8](repeating: 0, count: 2048)
                var srcAddr = sockaddr_in()
                var srcLen = socklen_t(MemoryLayout<sockaddr_in>.size)
                
                let deadline = Date().addingTimeInterval(1.8)
                while Date() < deadline {
                    let bytesRead = withUnsafeMutablePointer(to: &srcAddr) { srcPtr in
                        srcPtr.withMemoryRebound(to: sockaddr.self, capacity: 1) { saPtr in
                            recvfrom(sock, &recvBuf, recvBuf.count, 0, saPtr, &srcLen)
                        }
                    }
                    if bytesRead > 0 {
                        let fromIp = String(cString: inet_ntoa(srcAddr.sin_addr))
                        if let data = String(bytes: recvBuf[0..<bytesRead], encoding: .utf8)?.data(using: .utf8),
                           let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] {
                            let hostName = (obj["name"] as? String) ?? (obj["host"] as? String) ?? fromIp
                            let port = (obj["port"] as? Int) ?? 8080
                            let hostObj: [String: Any] = [
                                "ip": fromIp,
                                "port": port,
                                "host": hostName,
                                "name": hostName,
                                "via": "lan"
                            ]
                            lock.lock()
                            if !foundHosts.contains(where: { ($0["ip"] as? String) == fromIp && ($0["port"] as? Int) == port }) {
                                foundHosts.append(hostObj)
                            }
                            lock.unlock()
                        }
                    }
                }
                close(sock)
            }
            group.leave()
        }
        
        // 2. Parallel HTTP Subnet Scanner
        let sessionConfig = URLSessionConfiguration.ephemeral
        sessionConfig.timeoutIntervalForRequest = 1.8
        sessionConfig.timeoutIntervalForResource = 1.8
        let scanSession = URLSession(configuration: sessionConfig)
        
        for prefix in prefixes {
            for i in 1...254 {
                let targetIp = "\(prefix)\(i)"
                for port in [8080, 8081] {
                    guard let url = URL(string: "http://\(targetIp):\(port)/api/ping") else { continue }
                    group.enter()
                    scanSession.dataTask(with: url) { data, response, error in
                        defer { group.leave() }
                        guard let data = data,
                              let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else { return }
                        
                        let isCwHost = (obj["app"] as? String == "cw-datacenter") ||
                                       (obj["ok"] as? Bool == true && (obj["via"] != nil || obj["host"] != nil || obj["version"] != nil))
                        guard isCwHost else { return }
                        
                        let hostName = (obj["name"] as? String) ?? (obj["host"] as? String) ?? targetIp
                        let p = (obj["port"] as? Int) ?? port
                        let hostObj: [String: Any] = [
                            "ip": targetIp,
                            "port": p,
                            "host": hostName,
                            "name": hostName,
                            "via": "lan"
                        ]
                        lock.lock()
                        if !foundHosts.contains(where: { ($0["ip"] as? String) == targetIp && ($0["port"] as? Int) == p }) {
                            foundHosts.append(hostObj)
                        }
                        lock.unlock()
                    }.resume()
                }
            }
        }
        
        group.notify(queue: .main) {
            completion(foundHosts)
        }
    }
}