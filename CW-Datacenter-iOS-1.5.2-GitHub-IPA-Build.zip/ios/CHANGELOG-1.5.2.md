# CW Datacenter iOS 1.5.2

## Sửa crash đồng bộ

- Sửa lỗi xác nhận từ bốn crash log: `Semaphore object deallocated while in use`.
- Thay producer/consumer dùng nhiều `DispatchSemaphore` bằng pipeline bất đồng bộ tuần tự một asset mỗi lần.
- Request init/chunk/complete chạy bằng callback của URLSession, không chặn thread bằng semaphore.
- Hủy đồng bộ an toàn: task mạng hoàn tất callback rồi mới giải phóng context và file tạm.
- LocalProxy không còn chờ semaphore; socket được đóng trong callback của URLSession.
- Khóa trạng thái chạy/tạm dừng và bảo đảm callback hoàn tất chỉ được gọi một lần.
- Giới hạn cập nhật tiến trình khoảng 3 lần/giây để tránh dồn lệnh render vào WKWebView.

## Trình phát nhạc

- Thêm trình phát nhạc native cho MP3, M4A, AAC, WAV và các định dạng AVPlayer hỗ trợ.
- Tự chuyển bài, quay lại bài trước, tua, phát/tạm dừng và điều khiển từ màn hình khóa.
- Mini player nằm riêng phía trên nội dung, không che thanh ổ đĩa; có nút X để dừng và đóng.
- Bật chế độ phát âm thanh nền để khóa màn hình vẫn nghe nhạc.
- Phát được nhạc trên Host và trong vùng “Thiết bị này” của app.

## Giao diện và video

- Thêm nút Back rõ ràng phía trước thanh địa chỉ/breadcrumb.
- Làm sạch giao diện video bằng SF Symbols, bỏ toàn bộ emoji ở các nút điều khiển.
- Giữ các thao tác tua 10 giây, tốc độ, tỷ lệ khung hình, khóa, âm lượng, độ sáng và xoay màn hình.

## Đồng bộ iOS

- Đưa tiến trình sao lưu thư viện ảnh/video vào tab Truyền tải, gồm tệp hiện tại, số tệp và trạng thái chạy/tạm dừng/lỗi.
- Bỏ riêng hàng “Thư mục đồng bộ (nguồn)” khỏi tab Đồng bộ trên iOS.
- Giảm bộ đệm PhotoKit xuống một asset và chunk upload xuống 512 KiB để tránh tăng bộ nhớ khi gặp video lớn.
- Khi iOS cảnh báo thiếu bộ nhớ hoặc hết thời gian chạy nền, app dừng an toàn và giữ tiến độ thay vì tiếp tục đến khi bị hệ thống đóng.
- Không bỏ qua file lỗi; lần chạy sau tiếp tục đúng tệp chưa hoàn tất.

## Phiên bản và phạm vi

- Marketing version: `1.5.2`
- Build: `10502`
- Web/native asset marker: `1.5.2`
- Không thay đổi Android Mobile, Tablet, TV hoặc Host trong source iOS này.
