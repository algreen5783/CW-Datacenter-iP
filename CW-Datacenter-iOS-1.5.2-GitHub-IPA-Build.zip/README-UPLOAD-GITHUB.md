# Cách dùng gói iOS 1.5.2 trên GitHub

## Cách 1: Giải nén rồi tải lên repository

Tải toàn bộ hai mục `.github` và `ios` lên thư mục gốc repository. Sau đó mở **Actions → Build CW Datacenter iOS 1.5.2 IPA → Run workflow**.

## Cách 2: Dùng workflow giải nén ZIP cũ

Nếu repository hiện tại của bạn tự tìm và giải nén file ZIP, chỉ cần tải file `CW-Datacenter-iOS-1.5.2-GitHub-IPA-Build.zip` lên. Bên trong ZIP đã có đúng thư mục `ios/`, nên bước kiểm tra `ls ios` sẽ không còn báo lỗi.

Artifact tạo ra là `CW-Datacenter-iOS-1.5.2-unsigned.ipa`; cần ký trước khi cài lên iPhone.
