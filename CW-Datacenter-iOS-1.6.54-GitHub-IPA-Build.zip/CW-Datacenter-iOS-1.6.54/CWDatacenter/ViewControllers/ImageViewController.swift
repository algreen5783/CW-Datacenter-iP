import UIKit
import Photos
import ImageIO

/// Memory-only cache shared by every page in one photo-viewer session.
/// It coalesces duplicate requests and is explicitly cleared when the viewer closes.
fileprivate final class PhotoViewerSessionCache {
    static var screenPixelLimit: Int {
        return min(2048, max(1280, Int(UIScreen.main.bounds.width * UIScreen.main.scale)))
    }

    static func displayURL(_ original: String) -> String {
        guard var url = URLComponents(string: original), url.path == "/api/file" else { return original }
        let rel = url.queryItems?.first(where: { $0.name == "path" })?.value ?? ""
        let ext = (rel as NSString).pathExtension.lowercased()
        var query = (url.queryItems ?? []).filter { !["preview", "screen"].contains($0.name) }
        if ["jpg", "jpeg", "png", "webp"].contains(ext) {
            query.append(URLQueryItem(name: "preview", value: "1"))
            query.append(URLQueryItem(name: "screen", value: String(screenPixelLimit)))
        }
        // HEIC stays original for native Image I/O decoding.
        url.queryItems = query
        return url.url?.absoluteString ?? original
    }

    static func originalURL(_ value: String) -> String {
        guard var url = URLComponents(string: value), url.path == "/api/file" else { return value }
        url.queryItems = (url.queryItems ?? []).filter { !["preview", "screen"].contains($0.name) }
        return url.url?.absoluteString ?? value
    }

    static func fallbackURL(_ value: String) -> String {
        guard var url = URLComponents(string: originalURL(value)), url.path == "/api/file" else { return value }
        url.queryItems = (url.queryItems ?? []) + [URLQueryItem(name: "preview", value: "1")]
        return url.url?.absoluteString ?? value
    }
    private struct InFlight {
        let task: URLSessionDataTask
        var completions: [(Data?) -> Void]
    }

    private let cache = NSCache<NSString, NSData>()
    private let lock = NSLock()
    private var inFlight: [String: InFlight] = [:]
    private let session: URLSession

    init() {
        let configuration = URLSessionConfiguration.default
        configuration.requestCachePolicy = .returnCacheDataElseLoad
        configuration.httpMaximumConnectionsPerHost = 8
        configuration.timeoutIntervalForRequest = 30
        configuration.timeoutIntervalForResource = 120
        configuration.urlCache = URLCache(memoryCapacity: 64 * 1024 * 1024, diskCapacity: 512 * 1024 * 1024)
        session = URLSession(configuration: configuration)
        cache.totalCostLimit = 256 * 1024 * 1024
        cache.countLimit = 17
    }

    func cachedData(for urlString: String) -> Data? {
        return cache.object(forKey: urlString as NSString) as Data?
    }

    func load(urlString: String, retryCount: Int = 2, completion: @escaping (Data?) -> Void) {
        if let data = cachedData(for: urlString) {
            completion(data)
            return
        }
        guard let url = URL(string: urlString) else {
            completion(nil)
            return
        }

        lock.lock()
        if var running = inFlight[urlString] {
            running.completions.append(completion)
            inFlight[urlString] = running
            lock.unlock()
            return
        }
        lock.unlock()

        let policy: NSURLRequest.CachePolicy = retryCount < 2 ? .reloadRevalidatingCacheData : .returnCacheDataElseLoad
        var request = URLRequest(url: url, cachePolicy: policy, timeoutInterval: 120)
        if !LocalProxy.shared.token.isEmpty && !url.isFileURL {
            request.setValue("Bearer " + LocalProxy.shared.token, forHTTPHeaderField: "Authorization")
        }

        var task: URLSessionDataTask!
        task = session.dataTask(with: request) { [weak self] data, response, error in
            guard let self = self else { return }
            let status = (response as? HTTPURLResponse)?.statusCode ?? 200
            let validData = (error == nil && (200...299).contains(status)) ? data : nil
            if let validData = validData {
                self.cache.setObject(validData as NSData, forKey: urlString as NSString, cost: validData.count)
            }
            self.lock.lock()
            let callbacks = self.inFlight.removeValue(forKey: urlString)?.completions ?? []
            self.lock.unlock()
            if validData == nil && retryCount > 0 {
                DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + (retryCount == 2 ? 0.25 : 0.8)) {
                    callbacks.forEach { callback in self.load(urlString: urlString, retryCount: retryCount - 1, completion: callback) }
                }
            } else {
                callbacks.forEach { $0(validData) }
            }
        }

        lock.lock()
        inFlight[urlString] = InFlight(task: task, completions: [completion])
        lock.unlock()
        task.resume()
    }

    func clear() {
        lock.lock()
        let tasks = inFlight.values.map { $0.task }
        inFlight.removeAll()
        lock.unlock()
        tasks.forEach { $0.cancel() }
        cache.removeAllObjects()
    }
}

class ImageViewController: UIViewController, UIPageViewControllerDataSource, UIPageViewControllerDelegate, UIGestureRecognizerDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    private var playlist: [[String: Any]]
    private var currentIndex: Int
    private var pageViewController: UIPageViewController!
    private let imageCache = PhotoViewerSessionCache()
    private let prefetchRadius = 8

    private let topBar = UIView()
    private let closeBtn = UIButton(type: .system)
    private let titleLabel = UILabel()
    private let counterLabel = UILabel()
    private let shareBtn = UIButton(type: .system)
    private var filmstrip: UICollectionView!
    private let bottomBar = UIVisualEffectView(effect: UIBlurEffect(style: .systemThinMaterialDark))
    private let favoriteBtn = UIButton(type: .system)
    private let downloadBtn = UIButton(type: .system)
    private let deleteBtn = UIButton(type: .system)
    private var controlsVisible = true
    private var controlsHideWorkItem: DispatchWorkItem?
    private var compactMediaConstraints: [NSLayoutConstraint] = []
    private var fullMediaConstraints: [NSLayoutConstraint] = []

    var onFavorite: (([String: Any], @escaping (Bool) -> Void) -> Void)?
    var onDownload: (([String: Any], @escaping (Bool, String?) -> Void) -> Void)?
    var onDelete: (([String: Any], @escaping (Bool, String?) -> Void) -> Void)?

    init(playlist: [[String: Any]], initialIndex: Int) {
        self.playlist = playlist.isEmpty ? [["name": "Hình ảnh", "url": ""]] : playlist
        self.currentIndex = max(0, min(initialIndex, playlist.count - 1))
        super.init(nibName: nil, bundle: nil)
    }

    convenience init(url: String, name: String) {
        self.init(playlist: [["name": name, "url": url]], initialIndex: 0)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override var prefersStatusBarHidden: Bool {
        return !controlsVisible
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        setupTopBar()
        setupBottomBar()
        setupFilmstrip()
        setupPageViewController()
        setupControlsGesture()
        updateHeaderInfo(for: currentIndex)
        prefetchImages(around: currentIndex)
        syncFilmstrip(animated: false)
    }

    private func setupControlsGesture() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(onViewerTapped))
        tap.cancelsTouchesInView = false
        tap.delegate = self
        view.addGestureRecognizer(tap)
    }

    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        var candidate: UIView? = touch.view
        while let current = candidate {
            if current is UIControl { return false }
            candidate = current.superview
        }
        return true
    }

    @objc private func onViewerTapped() {
        setControlsVisible(!controlsVisible)
    }

    private func showControlsTemporarily() {
        setControlsVisible(true)
    }

    private func setControlsVisible(_ visible: Bool) {
        controlsVisible = visible
        if !visible { controlsHideWorkItem?.cancel() }
        topBar.isUserInteractionEnabled = visible
        bottomBar.isUserInteractionEnabled = visible
        filmstrip.isUserInteractionEnabled = visible
        NSLayoutConstraint.deactivate(visible ? fullMediaConstraints : compactMediaConstraints)
        NSLayoutConstraint.activate(visible ? compactMediaConstraints : fullMediaConstraints)
        UIView.animate(withDuration: 0.24) {
            self.topBar.alpha = visible ? 1 : 0
            self.bottomBar.alpha = visible ? 1 : 0
            self.filmstrip.alpha = visible ? 1 : 0
            self.topBar.transform = visible ? .identity : CGAffineTransform(translationX: 0, y: -18)
            self.bottomBar.transform = visible ? .identity : CGAffineTransform(translationX: 0, y: 18)
            self.filmstrip.transform = visible ? .identity : CGAffineTransform(translationX: 0, y: 18)
            self.view.layoutIfNeeded()
            self.setNeedsStatusBarAppearanceUpdate()
        }
    }

    private func setupBottomBar() {
        bottomBar.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.layer.cornerRadius = 20
        bottomBar.clipsToBounds = true
        view.addSubview(bottomBar)

        configureActionButton(favoriteBtn, title: "Yêu thích", symbol: "heart", action: #selector(onFavoriteTapped))
        configureActionButton(downloadBtn, title: "Tải về", symbol: "arrow.down.to.line", action: #selector(onDownloadTapped))
        configureActionButton(shareBtn, title: "Chia sẻ", symbol: "square.and.arrow.up", action: #selector(onShareTapped))
        configureActionButton(deleteBtn, title: "Xóa", symbol: "trash", action: #selector(onDeleteTapped))
        deleteBtn.tintColor = .systemRed

        let stack = UIStackView(arrangedSubviews: [favoriteBtn, downloadBtn, shareBtn, deleteBtn])
        stack.axis = .horizontal
        stack.distribution = .fillEqually
        stack.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.contentView.addSubview(stack)

        NSLayoutConstraint.activate([
            bottomBar.leadingAnchor.constraint(greaterThanOrEqualTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 18),
            bottomBar.trailingAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -18),
            bottomBar.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            bottomBar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -12),
            bottomBar.widthAnchor.constraint(lessThanOrEqualToConstant: 430),
            bottomBar.heightAnchor.constraint(equalToConstant: 72),
            stack.leadingAnchor.constraint(equalTo: bottomBar.contentView.leadingAnchor, constant: 8),
            stack.trailingAnchor.constraint(equalTo: bottomBar.contentView.trailingAnchor, constant: -8),
            stack.topAnchor.constraint(equalTo: bottomBar.contentView.topAnchor, constant: 6),
            stack.bottomAnchor.constraint(equalTo: bottomBar.contentView.bottomAnchor, constant: -6)
        ])
    }

    private func setupFilmstrip() {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 5
        layout.minimumInteritemSpacing = 5
        layout.sectionInset = UIEdgeInsets(top: 2, left: 14, bottom: 2, right: 14)
        filmstrip = UICollectionView(frame: .zero, collectionViewLayout: layout)
        filmstrip.backgroundColor = .clear
        filmstrip.showsHorizontalScrollIndicator = false
        filmstrip.alwaysBounceHorizontal = true
        filmstrip.dataSource = self
        filmstrip.delegate = self
        filmstrip.register(PhotoFilmstripCell.self, forCellWithReuseIdentifier: PhotoFilmstripCell.reuseIdentifier)
        filmstrip.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(filmstrip)
        NSLayoutConstraint.activate([
            filmstrip.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            filmstrip.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            filmstrip.bottomAnchor.constraint(equalTo: bottomBar.topAnchor, constant: -8),
            filmstrip.heightAnchor.constraint(equalToConstant: 54)
        ])
    }

    private func configureActionButton(_ button: UIButton, title: String, symbol: String, action: Selector) {
        let image = UIImage(systemName: symbol)

        if #available(iOS 15.0, *) {
            var config = UIButton.Configuration.plain()
            config.image = image
            config.title = title
            config.imagePlacement = .top
            config.imagePadding = 5
            config.baseForegroundColor = .white
            config.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { incoming in
                var outgoing = incoming
                outgoing.font = UIFont.systemFont(ofSize: 12, weight: .medium)
                return outgoing
            }
            button.configuration = config
        } else {
            // UIButton.Configuration is only available from iOS 15. Keep the
            // image viewer usable on the app's iOS 14 deployment target.
            button.setImage(image, for: .normal)
            button.setTitle(title, for: .normal)
            button.setTitleColor(.white, for: .normal)
            button.titleLabel?.font = UIFont.systemFont(ofSize: 12, weight: .medium)
            button.titleLabel?.textAlignment = .center
            button.contentHorizontalAlignment = .center
            button.imageEdgeInsets = UIEdgeInsets(top: -18, left: 0, bottom: 0, right: -18)
            button.titleEdgeInsets = UIEdgeInsets(top: 26, left: -18, bottom: 0, right: 0)
        }

        button.tintColor = .white
        button.addTarget(self, action: action, for: .touchUpInside)
    }

    private func setupPageViewController() {
        pageViewController = UIPageViewController(
            transitionStyle: .scroll,
            navigationOrientation: .horizontal,
            options: [UIPageViewController.OptionsKey.interPageSpacing: 16]
        )
        pageViewController.dataSource = self
        pageViewController.delegate = self

        let initialVC = singlePhotoVC(for: currentIndex)
        pageViewController.setViewControllers([initialVC], direction: .forward, animated: false, completion: nil)

        addChild(pageViewController)
        view.insertSubview(pageViewController.view, at: 0)
        pageViewController.view.translatesAutoresizingMaskIntoConstraints = false
        compactMediaConstraints = [
            pageViewController.view.topAnchor.constraint(equalTo: topBar.bottomAnchor, constant: 8),
            pageViewController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 12),
            pageViewController.view.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -12),
            pageViewController.view.bottomAnchor.constraint(equalTo: filmstrip.topAnchor, constant: -8)
        ]
        fullMediaConstraints = [
            pageViewController.view.topAnchor.constraint(equalTo: view.topAnchor),
            pageViewController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            pageViewController.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            pageViewController.view.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ]
        NSLayoutConstraint.activate(compactMediaConstraints)
        pageViewController.didMove(toParent: self)
    }

    private func setupTopBar() {
        topBar.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        topBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(topBar)

        closeBtn.setImage(UIImage(systemName: "xmark"), for: .normal)
        closeBtn.tintColor = .systemBlue
        closeBtn.backgroundColor = UIColor.white.withAlphaComponent(0.10)
        closeBtn.layer.cornerRadius = 18
        closeBtn.addTarget(self, action: #selector(onCloseTapped), for: .touchUpInside)
        closeBtn.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(closeBtn)

        titleLabel.textColor = .white
        titleLabel.font = UIFont.systemFont(ofSize: 22, weight: .bold)
        titleLabel.textAlignment = .left
        titleLabel.lineBreakMode = .byTruncatingMiddle
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(titleLabel)

        counterLabel.textColor = UIColor.white.withAlphaComponent(0.8)
        counterLabel.font = UIFont.systemFont(ofSize: 13, weight: .regular)
        counterLabel.textAlignment = .left
        counterLabel.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(counterLabel)

        NSLayoutConstraint.activate([
            topBar.topAnchor.constraint(equalTo: view.topAnchor),
            topBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            topBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            topBar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 82),

            closeBtn.trailingAnchor.constraint(equalTo: topBar.trailingAnchor, constant: -14),
            closeBtn.bottomAnchor.constraint(equalTo: topBar.bottomAnchor, constant: -10),
            closeBtn.widthAnchor.constraint(equalToConstant: 36),
            closeBtn.heightAnchor.constraint(equalToConstant: 36),

            titleLabel.leadingAnchor.constraint(equalTo: topBar.leadingAnchor, constant: 24),
            titleLabel.topAnchor.constraint(equalTo: closeBtn.topAnchor, constant: -2),
            titleLabel.trailingAnchor.constraint(lessThanOrEqualTo: closeBtn.leadingAnchor, constant: -14),

            counterLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            counterLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 3),
            counterLabel.trailingAnchor.constraint(lessThanOrEqualTo: closeBtn.leadingAnchor, constant: -14)
        ])
    }

    private func updateHeaderInfo(for index: Int) {
        guard index >= 0 && index < playlist.count else { return }
        let item = playlist[index]
        let name = (item["name"] as? String) ?? "Hình ảnh"
        if let date = mediaDate(from: item["mtime"]) {
            let dateFormatter = DateFormatter()
            dateFormatter.locale = Locale(identifier: "vi_VN")
            dateFormatter.dateFormat = "'ngày' d 'tháng' M, yyyy"
            let timeFormatter = DateFormatter()
            timeFormatter.locale = Locale(identifier: "vi_VN")
            timeFormatter.dateFormat = "HH:mm"
            titleLabel.text = dateFormatter.string(from: date)
            counterLabel.text = "\(timeFormatter.string(from: date)) · \(name) · \(index + 1)/\(playlist.count)"
        } else {
            titleLabel.text = name
            counterLabel.text = "\(index + 1) / \(playlist.count)"
        }
        let isFavorite = item["favorite"] as? Bool ?? false
        let image = UIImage(systemName: isFavorite ? "heart.fill" : "heart")
        if #available(iOS 15.0, *) {
            var configuration = favoriteBtn.configuration
            configuration?.image = image
            favoriteBtn.configuration = configuration
        } else {
            favoriteBtn.setImage(image, for: .normal)
        }
        favoriteBtn.tintColor = isFavorite ? .systemPink : .white
    }

    private func mediaDate(from value: Any?) -> Date? {
        if let number = value as? NSNumber {
            let raw = number.doubleValue
            return Date(timeIntervalSince1970: raw > 10_000_000_000 ? raw / 1000 : raw)
        }
        guard let text = value as? String, !text.isEmpty else { return nil }
        if let raw = Double(text) { return Date(timeIntervalSince1970: raw > 10_000_000_000 ? raw / 1000 : raw) }
        let iso = ISO8601DateFormatter()
        if let date = iso.date(from: text) { return date }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        for format in ["yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss.SSSZ", "yyyy-MM-dd'T'HH:mm:ssZ"] {
            formatter.dateFormat = format
            if let date = formatter.date(from: text) { return date }
        }
        return nil
    }

    private func singlePhotoVC(for index: Int) -> SinglePhotoViewController {
        let item = playlist[index]
        let url = (item["url"] as? String) ?? ""
        let thumbUrl = (item["thumbUrl"] as? String) ?? ""
        let localPath = (item["localPath"] as? String) ?? ""
        return SinglePhotoViewController(index: index, urlString: url, thumbUrlString: thumbUrl, localPath: localPath, imageCache: imageCache)
    }

    private func prefetchImages(around index: Int) {
        guard !playlist.isEmpty else { return }
        let lower = max(0, index - prefetchRadius)
        let upper = min(playlist.count - 1, index + prefetchRadius)
        for candidate in lower...upper where candidate != index {
            let item = playlist[candidate]
            let localPath = item["localPath"] as? String ?? ""
            let thumb = item["thumbUrl"] as? String ?? ""
            if !thumb.isEmpty { imageCache.load(urlString: thumb) { _ in } }
            guard localPath.isEmpty, let url = item["url"] as? String, !url.isEmpty else { continue }
            imageCache.load(urlString: PhotoViewerSessionCache.displayURL(url)) { _ in }
        }
    }

    // MARK: - UIPageViewControllerDataSource
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let photoVC = viewController as? SinglePhotoViewController else { return nil }
        let prevIndex = photoVC.index - 1
        guard prevIndex >= 0 else { return nil }
        return singlePhotoVC(for: prevIndex)
    }

    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let photoVC = viewController as? SinglePhotoViewController else { return nil }
        let nextIndex = photoVC.index + 1
        guard nextIndex < playlist.count else { return nil }
        return singlePhotoVC(for: nextIndex)
    }

    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        if completed, let currentVC = pageViewController.viewControllers?.first as? SinglePhotoViewController {
            currentIndex = currentVC.index
            updateHeaderInfo(for: currentIndex)
            prefetchImages(around: currentIndex)
            syncFilmstrip(animated: true)
        }
    }

    // MARK: - Filmstrip
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return playlist.count
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 42, height: 50)
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PhotoFilmstripCell.reuseIdentifier, for: indexPath) as? PhotoFilmstripCell else {
            return UICollectionViewCell()
        }
        let item = playlist[indexPath.item]
        cell.prepare(index: indexPath.item, selected: indexPath.item == currentIndex)
        let localPath = item["localPath"] as? String ?? ""
        if !localPath.isEmpty, let image = UIImage(contentsOfFile: localPath) {
            cell.apply(image: image, index: indexPath.item)
            return cell
        }
        let thumb = item["thumbUrl"] as? String ?? ""
        guard !thumb.isEmpty else { return cell }
        imageCache.load(urlString: thumb) { [weak self, weak cell] data in
            if let data, let image = UIImage(data: data) {
                DispatchQueue.main.async { cell?.apply(image: image, index: indexPath.item) }
                return
            }
            guard let fallback = item["url"] as? String, !fallback.isEmpty else { return }
            self?.imageCache.load(urlString: PhotoViewerSessionCache.displayURL(fallback)) { [weak cell] fallbackData in
                guard let fallbackData, let image = UIImage(data: fallbackData) else { return }
                DispatchQueue.main.async { cell?.apply(image: image, index: indexPath.item) }
            }
        }
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard playlist.indices.contains(indexPath.item), indexPath.item != currentIndex else { return }
        let oldIndex = currentIndex
        currentIndex = indexPath.item
        let next = singlePhotoVC(for: currentIndex)
        pageViewController.setViewControllers([next], direction: currentIndex > oldIndex ? .forward : .reverse, animated: true)
        updateHeaderInfo(for: currentIndex)
        prefetchImages(around: currentIndex)
        syncFilmstrip(animated: true)
    }

    private func syncFilmstrip(animated: Bool) {
        guard filmstrip != nil, playlist.indices.contains(currentIndex) else { return }
        filmstrip.reloadData()
        DispatchQueue.main.async { [weak self] in
            guard let self, self.playlist.indices.contains(self.currentIndex) else { return }
            self.filmstrip.scrollToItem(at: IndexPath(item: self.currentIndex, section: 0), at: .centeredHorizontally, animated: animated)
        }
    }

    deinit {
        controlsHideWorkItem?.cancel()
        imageCache.clear()
    }

    @objc private func onShareTapped() {
        guard currentIndex >= 0 && currentIndex < playlist.count else { return }
        let item = playlist[currentIndex]
        let localPath = item["localPath"] as? String ?? ""
        if !localPath.isEmpty && FileManager.default.fileExists(atPath: localPath) {
            let fileUrl = URL(fileURLWithPath: localPath)
            let avc = UIActivityViewController(activityItems: [fileUrl], applicationActivities: nil)
            anchorSharePopover(avc)
            present(avc, animated: true)
            return
        }
        guard let urlStr = item["url"] as? String, let url = URL(string: urlStr) else { return }
        if let data = imageCache.cachedData(for: urlStr), let image = UIImage(data: data) {
            let avc = UIActivityViewController(activityItems: [image], applicationActivities: nil)
            anchorSharePopover(avc)
            present(avc, animated: true)
            return
        }
        var req = URLRequest(url: url)
        if !LocalProxy.shared.token.isEmpty && !url.isFileURL {
            req.setValue("Bearer " + LocalProxy.shared.token, forHTTPHeaderField: "Authorization")
        }
        URLSession.shared.dataTask(with: req) { [weak self] data, _, _ in
            guard let d = data, let img = UIImage(data: d) else { return }
            DispatchQueue.main.async {
                let avc = UIActivityViewController(activityItems: [img], applicationActivities: nil)
                self?.anchorSharePopover(avc)
                self?.present(avc, animated: true)
            }
        }.resume()
    }

    private func anchorSharePopover(_ controller: UIActivityViewController) {
        guard let popover = controller.popoverPresentationController else { return }
        popover.sourceView = shareBtn
        popover.sourceRect = shareBtn.bounds
    }

    @objc private func onFavoriteTapped() {
        guard playlist.indices.contains(currentIndex) else { return }
        let item = playlist[currentIndex]
        favoriteBtn.isEnabled = false
        onFavorite?(item) { [weak self] value in
            DispatchQueue.main.async {
                guard let self = self, self.playlist.indices.contains(self.currentIndex) else { return }
                self.playlist[self.currentIndex]["favorite"] = value
                self.favoriteBtn.isEnabled = true
                self.updateHeaderInfo(for: self.currentIndex)
                self.syncFilmstrip(animated: false)
            }
        }
    }

    @objc private func onDownloadTapped() {
        guard playlist.indices.contains(currentIndex) else { return }
        downloadBtn.isEnabled = false
        onDownload?(playlist[currentIndex]) { [weak self] ok, message in
            DispatchQueue.main.async {
                self?.downloadBtn.isEnabled = true
                self?.showResult(message ?? (ok ? "Đã lưu ảnh vào Thư viện ảnh." : "Không lưu được ảnh."), success: ok)
            }
        }
    }

    @objc private func onDeleteTapped() {
        guard playlist.indices.contains(currentIndex) else { return }
        let item = playlist[currentIndex]
        let name = item["name"] as? String ?? "ảnh này"
        let alert = UIAlertController(title: "Xóa \(name)?", message: "Ảnh sẽ được chuyển vào Thùng rác trên Host.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Hủy", style: .cancel))
        alert.addAction(UIAlertAction(title: "Xóa", style: .destructive) { [weak self] _ in
            guard let self = self else { return }
            self.deleteBtn.isEnabled = false
            self.onDelete?(item) { [weak self] ok, message in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    self.deleteBtn.isEnabled = true
                    guard ok else { self.showResult(message ?? "Không xóa được ảnh.", success: false); return }
                    self.playlist.remove(at: self.currentIndex)
                    if self.playlist.isEmpty { self.dismiss(animated: true); return }
                    self.currentIndex = min(self.currentIndex, self.playlist.count - 1)
                    let next = self.singlePhotoVC(for: self.currentIndex)
                    self.pageViewController.setViewControllers([next], direction: .forward, animated: true, completion: nil)
                    self.updateHeaderInfo(for: self.currentIndex)
                    self.prefetchImages(around: self.currentIndex)
                    self.syncFilmstrip(animated: true)
                    self.showResult(message ?? "Đã chuyển ảnh vào Thùng rác.", success: true)
                }
            }
        })
        present(alert, animated: true)
    }

    private func showResult(_ message: String, success: Bool) {
        let alert = UIAlertController(title: success ? "Hoàn tất" : "Có lỗi", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Đóng", style: .default))
        present(alert, animated: true)
    }

    @objc private func onCloseTapped() {
        imageCache.clear()
        dismiss(animated: true)
    }

}

fileprivate final class PhotoFilmstripCell: UICollectionViewCell {
    static let reuseIdentifier = "PhotoFilmstripCell"
    private let imageView = UIImageView()
    private let placeholder = UIImageView(image: UIImage(systemName: "photo"))
    fileprivate var representedIndex = -1

    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = UIColor.white.withAlphaComponent(0.08)
        contentView.layer.cornerRadius = 5
        contentView.layer.masksToBounds = true
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.translatesAutoresizingMaskIntoConstraints = false
        placeholder.contentMode = .scaleAspectFit
        placeholder.tintColor = UIColor.white.withAlphaComponent(0.42)
        placeholder.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(imageView)
        contentView.addSubview(placeholder)
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: contentView.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            imageView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            placeholder.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            placeholder.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            placeholder.widthAnchor.constraint(equalToConstant: 19),
            placeholder.heightAnchor.constraint(equalToConstant: 19)
        ])
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func prepareForReuse() {
        super.prepareForReuse()
        representedIndex = -1
        imageView.image = nil
        placeholder.isHidden = false
        contentView.layer.borderWidth = 0
    }

    fileprivate func prepare(index: Int, selected: Bool) {
        representedIndex = index
        imageView.image = nil
        placeholder.isHidden = false
        contentView.layer.borderColor = UIColor.white.cgColor
        contentView.layer.borderWidth = selected ? 2.5 : 0
    }

    fileprivate func apply(image: UIImage, index: Int) {
        guard representedIndex == index else { return }
        imageView.image = image
        placeholder.isHidden = true
    }
}

class SinglePhotoViewController: UIViewController, UIScrollViewDelegate {
    let index: Int
    let urlString: String
    let thumbUrlString: String
    let localPath: String
    private let imageCache: PhotoViewerSessionCache

    private var scrollView: UIScrollView!
    private var imageView: UIImageView!
    private var spinner: UIActivityIndicatorView!
    private let decodeQueue = DispatchQueue(label: "com.cw.datacenter.photo-decode", qos: .userInitiated)
    private var loadingOriginal = false
    private var originalLoaded = false

    fileprivate init(index: Int, urlString: String, thumbUrlString: String, localPath: String, imageCache: PhotoViewerSessionCache) {
        self.index = index
        self.urlString = urlString
        self.thumbUrlString = thumbUrlString
        self.localPath = localPath
        self.imageCache = imageCache
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear

        scrollView = UIScrollView(frame: view.bounds)
        scrollView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        scrollView.delegate = self
        scrollView.minimumZoomScale = 1.0
        scrollView.maximumZoomScale = 4.0
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        view.addSubview(scrollView)

        imageView = UIImageView(frame: scrollView.bounds)
        imageView.contentMode = .scaleAspectFit
        imageView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        imageView.isUserInteractionEnabled = true
        scrollView.addSubview(imageView)

        spinner = UIActivityIndicatorView(style: .large)
        spinner.color = .white
        spinner.center = view.center
        spinner.hidesWhenStopped = true
        view.addSubview(spinner)

        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(onDoubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        view.addGestureRecognizer(doubleTap)

        loadImage()
    }

    private func loadImage() {
        if !localPath.isEmpty && FileManager.default.fileExists(atPath: localPath) {
            if let img = UIImage(contentsOfFile: localPath) {
                imageView.image = img
                return
            }
        }
        guard URL(string: urlString) != nil else { return }
        spinner.startAnimating()

        // Show the cached 160 px preview immediately while the original image
        // is fetched in parallel, avoiding a blank wait over Tailscale.
        if !thumbUrlString.isEmpty {
            imageCache.load(urlString: thumbUrlString) { [weak self] data in
                guard let data = data, let preview = UIImage(data: data) else { return }
                DispatchQueue.main.async {
                    guard let self = self, self.imageView.image == nil else { return }
                    self.imageView.image = preview
                }
            }
        }

        let displayURL = PhotoViewerSessionCache.displayURL(urlString)
        loadDisplayImage(displayURL, allowFallback: true)
    }

    private func loadDisplayImage(_ url: String, allowFallback: Bool) {
        let pixelLimit = PhotoViewerSessionCache.screenPixelLimit
        imageCache.load(urlString: url) { [weak self] data in
            guard let self = self else { return }
            self.decodeQueue.async {
                let decoded = data.flatMap { LocalProxy.decodedImage($0, maxPixelSize: pixelLimit) }
                DispatchQueue.main.async {
                    if let decoded = decoded {
                        if !self.originalLoaded { self.imageView.image = UIImage(cgImage: decoded) }
                        self.spinner.stopAnimating()
                    } else if allowFallback {
                        self.loadDisplayImage(PhotoViewerSessionCache.fallbackURL(self.urlString), allowFallback: false)
                    } else {
                        self.spinner.stopAnimating()
                    }
                }
            }
        }
    }

    private func loadOriginalForZoom() {
        guard localPath.isEmpty, !originalLoaded, !loadingOriginal else { return }
        loadingOriginal = true
        imageCache.load(urlString: PhotoViewerSessionCache.originalURL(urlString)) { [weak self] data in
            guard let self = self else { return }
            self.decodeQueue.async {
                var decoded: CGImage?
                if let data = data, let source = CGImageSourceCreateWithData(data as CFData, nil),
                   let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any] {
                    let width = (properties[kCGImagePropertyPixelWidth] as? NSNumber)?.intValue ?? 0
                    let height = (properties[kCGImagePropertyPixelHeight] as? NSNumber)?.intValue ?? 0
                    if max(width, height) > 0 { decoded = LocalProxy.decodedImage(data, maxPixelSize: max(width, height)) }
                }
                DispatchQueue.main.async {
                    self.loadingOriginal = false
                    if let decoded = decoded {
                        self.originalLoaded = true
                        self.imageView.image = UIImage(cgImage: decoded)
                    }
                }
            }
        }
    }

    func scrollViewDidZoom(_ scrollView: UIScrollView) {
        if scrollView.zoomScale > 1.05 { loadOriginalForZoom() }
    }

    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return imageView
    }

    @objc private func onDoubleTap(_ gesture: UITapGestureRecognizer) {
        if scrollView.zoomScale > 1.0 {
            scrollView.setZoomScale(1.0, animated: true)
        } else {
            let point = gesture.location(in: imageView)
            let rect = CGRect(x: point.x - 60, y: point.y - 60, width: 120, height: 120)
            scrollView.zoom(to: rect, animated: true)
        }
    }
}
