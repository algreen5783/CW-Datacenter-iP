# Build CW Datacenter iOS 1.4.2 bằng GitHub Actions

Gói này dành cho trường hợp không có máy Mac. GitHub Actions sẽ dùng máy macOS có Xcode để build ứng dụng và xuất file IPA.

## Cách đưa source lên GitHub

1. Giải nén `CW-Datacenter-iOS-1.4.2-GitHub-IPA-Build.zip`.
2. Tạo một repository GitHub mới.
3. Đưa **toàn bộ nội dung bên trong thư mục đã giải nén** lên thư mục gốc của repository. Phải có đủ:
   - `.github/workflows/build-ipa.yml`
   - `CWDatacenter.xcodeproj`
   - `CWDatacenter`
4. Mở tab **Actions** của repository.
5. Chọn workflow **Build iOS IPA**.
6. Nhấn **Run workflow** rồi chờ job hoàn thành.
7. Mở lần chạy vừa xong, tải artifact `CW-Datacenter-iOS-1.4.2-unsigned-IPA`.

Workflow cũng tự chạy mỗi khi có commit mới vào nhánh `main` hoặc `master`.

## File nhận được

- `CW-Datacenter-iOS-1.4.2-unsigned.ipa`
- `CW-Datacenter-iOS-1.4.2-unsigned.ipa.sha256`

## Lưu ý về chữ ký Apple

IPA do workflow mặc định tạo ra là **IPA chưa ký**. Cách này không cần đưa Apple certificate, provisioning profile hoặc mật khẩu vào GitHub.

Muốn cài trên iPhone thông thường, IPA phải được ký bằng Apple ID/chứng chỉ phù hợp qua công cụ sideload hoặc một quy trình ký riêng. Không nên commit certificate hoặc mật khẩu vào repository. Nếu sau này thêm build có ký, chỉ lưu chúng trong GitHub Actions Secrets.

## Khi workflow báo lỗi

Mở lần chạy bị lỗi trong tab **Actions**, mở job **Build unsigned IPA**, rồi kiểm tra bước màu đỏ. Workflow đã bật chế độ dừng ngay khi lệnh build hoặc đóng gói IPA lỗi nên artifact không thể chứa một bản build hỏng.

