# CW Datacenter iOS 1.5.3 - GitHub IPA Build

Giải nén ZIP này vào thư mục gốc của repository GitHub. Repository sau khi tải lên phải có:

- `.github/workflows/build-ipa.yml`
- `ios/CWDatacenter.xcodeproj`
- `ios/CWDatacenter/`

Sau đó mở **Actions** → **Build CW Datacenter iOS 1.5.3 IPA** → **Run workflow**.

Artifact đầu ra: `CW-Datacenter-iOS-1.5.3-unsigned`.
