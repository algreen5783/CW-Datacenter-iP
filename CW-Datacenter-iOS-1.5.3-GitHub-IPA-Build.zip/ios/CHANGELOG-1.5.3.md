# CW Datacenter iOS 1.5.3

## Sửa lỗi

- Phát MP3/M4A trực tiếp từ Host bằng `AVPlayer` và header xác thực, không còn proxy giữ toàn bộ bài hát trong RAM.
- Quản lý observer của AVPlayer theo đúng player đã đăng ký, ngăn crash khi mở lại hoặc chuyển bài.
- Hiển thị lỗi phát nhạc ngay trên player và mini player.
- Đồng bộ Photos/iCloud thử lại tối đa ba lần và có đường đọc dự phòng cho ảnh/video.
- Một asset iCloud lỗi không còn làm dừng toàn bộ hàng đợi; ứng dụng tiếp tục đồng bộ các file còn lại và báo danh sách lỗi.
- Đối chiếu lại file đã có trên Host khi mở tab Đồng bộ.
- Lưu tên, đường dẫn và kích thước các mục đã đồng bộ để hiển thị danh sách gần đây.

## Nhật ký chẩn đoán

- Thêm tab `Nhật ký` với Làm mới, Xóa log và Gửi file log.
- Ghi lại lifecycle, cảnh báo RAM, lỗi JavaScript, HTTP, Photos/iCloud, upload và AVPlayer.
- Log xoay vòng để không tăng dung lượng vô hạn; token và mật khẩu được che tự động.

## Phiên bản

- Marketing version: `1.5.3`
- Build: `10503`
- Web/native asset marker: `1.5.3`
