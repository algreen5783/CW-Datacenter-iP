const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const player = fs.readFileSync(path.join(root, 'CWDatacenter', 'ViewControllers', 'PlayerViewController.swift'), 'utf8');
const main = fs.readFileSync(path.join(root, 'CWDatacenter', 'ViewControllers', 'MainViewController.swift'), 'utf8');

test('video playlist starts at the index supplied by the web UI', () => {
  assert.match(main, /let playlistIndex = params\["plIndex"\] as\? Int \?\? 0/);
  assert.match(main, /playlistIndex: playlistIndex/);
  assert.match(player, /private var currentPlaylistIndex: Int/);
  assert.match(player, /self\.currentPlaylistIndex = playlist\.indices\.contains\(playlistIndex\) \? playlistIndex : 0/);
});

test('horizontal swipes switch adjacent videos and no longer seek', () => {
  assert.match(player, /switchPlaylistItem\(offset: translation\.x > 0 \? 1 : -1\)/);
  assert.match(player, /let targetIndex = currentPlaylistIndex \+ offset/);
  assert.doesNotMatch(player, /initialSeekPos/);
  assert.doesNotMatch(player, /deltaSec = Double\(translation\.x/);
});

test('video swipe playlist excludes images and audio', () => {
  assert.match(fs.readFileSync(path.join(root, 'CWDatacenter', 'Resources', 'Web', 'app.js'), 'utf8'),
    /const videoList = \(previewList \|\| \[\]\)\.filter\(\(x\) => x && STREAM_VIDEO\.test/);
});

test('switching videos preserves play or pause state', () => {
  assert.match(player, /let shouldAutoPlay = isPlaying/);
  assert.match(player, /if shouldAutoPlay \{[\s\S]*?player\?\.play\(\)[\s\S]*?\} else \{[\s\S]*?player\?\.pause\(\)/);
  assert.match(player, /isPlaying = shouldAutoPlay/);
});
