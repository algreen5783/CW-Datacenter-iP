const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'CWDatacenter/Resources/Web/app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'CWDatacenter/Resources/Web/index.html'), 'utf8');
const proxy = fs.readFileSync(path.join(root, 'CWDatacenter/Network/LocalProxy.swift'), 'utf8');

test('overview scans only the device Images and Videos part folders', () => {
  assert.match(app, /\/api\/files\/deep\?path=/);
  assert.match(app, /&camera=1&pool=/);
  assert.match(app, /\^images\?\$\/i/);
  assert.match(app, /\^videos\?\$\/i/);
  assert.match(app, /\^images\?_\\d\+\$\/i/);
  assert.match(app, /\^videos\?_\\d\+\$\/i/);
  assert.match(app, /overviewGalleryMapLimit\(partFolders, 4/);
});

test('overview hides configured locked paths and opens media directly', () => {
  assert.match(app, /overviewPathIsConfiguredProtected\(rel, poolId\)/);
  assert.match(app, /launchMobileVideo\(item/);
  assert.match(app, /callNative\('openPhoto'/);
});

test('overview index and thumbnails persist locally for the next login', () => {
  assert.match(app, /iosOverviewGallery:v1:/);
  assert.match(app, /saveOverviewGalleryCache/);
  assert.match(app, /mediaThumbUrl\(item, 160\)/);
  assert.match(app, /loading="lazy"/);
  assert.match(proxy, /applicationSupportDirectory/);
  assert.match(proxy, /thumbnail_cache/);
  assert.match(proxy, /cachedThumbnail\(key:/);
  assert.match(proxy, /Cache-Control: public, max-age=31536000, immutable/);
});

test('overview prefetches every new thumbnail in a bounded persistent background queue', () => {
  assert.match(app, /thumbReadyRev/);
  assert.match(app, /warmOverviewGalleryThumbnails/);
  assert.match(app, /Promise\.all\(\[worker\(\), worker\(\), worker\(\)\]\)/);
  assert.match(app, /overviewThumbWarmComplete/);
  assert.match(app, /if \(overviewThumbWarmComplete\) return/);
  assert.match(app, /fetch\(requestUrl, \{ cache: attempt \? 'no-store' : 'force-cache'/);
  assert.match(app, /setTimeout\(\(\) => controller\.abort\(\), 20000\)/);
  assert.match(app, /data-overview-thumb=/);
  assert.match(app, /resetOverviewThumbnailWarmState\(\)/);
});

test('overview removes the title and host controls while keeping search and centered icon controls', () => {
  assert.match(html, /<symbol id="i-play"/);
  assert.doesNotMatch(html, /<h1>Tổng quan<\/h1>/);
  assert.doesNotMatch(html, /id="overviewGalleryHost"/);
  assert.doesNotMatch(html, /id="overviewSwitchHost"/);
  assert.match(html, /\.photos-search\{[^}]*margin-top:0/);
  assert.match(html, /\.photos-refresh\{[^}]*display:grid;place-items:center;line-height:0/);
  assert.match(html, /\.photos-video-badge svg\{[^}]*width:14px;[^}]*height:14px;[^}]*margin:auto/);
  assert.match(app, /iconSvg\('i-play', 'svg-14'\)/);
});

test('overview provides search, type filters and incremental rendering', () => {
  assert.match(html, /id="overviewGallerySearch"/);
  assert.match(html, /data-gallery-filter="favorite"/);
  assert.match(app, /overviewGalleryRenderLimit \+= 120/);
  assert.match(app, /IntersectionObserver/);
});
