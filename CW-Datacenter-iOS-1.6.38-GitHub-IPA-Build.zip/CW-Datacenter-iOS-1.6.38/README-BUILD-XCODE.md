# Build CW Datacenter iOS 1.6.38 (10638)

## Sửa lỗi Tailscale / ATS

Bản này thêm ngoại lệ HTTP riêng cho dải `100.64.0.0/10` trong Info.plist của app, sửa thông báo lỗi kết nối và giữ nguyên bundle ID. Không sửa Host, Android hay client desktop.

## Build IPA bằng GitHub Actions

1. Upload **CW-Datacenter-iOS-1.6.38-GitHub-IPA-Build.zip** vào thư mục gốc repository. Không đổi tên ZIP và không dùng ZIP bản cũ cho lần build này.
2. Cập nhật file **.github/workflows/build-ipa.yml** bằng workflow đi kèm 1.6.38. Nếu chỉ upload workflow vào thư mục gốc, GitHub sẽ không chạy nó.
3. Mở **Actions → Build CW Datacenter iOS 1.6.38 IPA → Run workflow** trên nhánh vừa cập nhật.
4. Chờ toàn bộ job thành công rồi tải artifact **CW-Datacenter-iOS-1.6.38-unsigned**.
5. Trong artifact có **CW-Datacenter-iOS-1.6.38-unsigned.ipa** và mã SHA-256. IPA chưa ký, cần ký bằng phương thức bạn đang dùng trước khi cài.

Nếu dùng source giải nén thay ZIP, mở `CWDatacenter.xcodeproj` trên Mac, chọn scheme CWDatacenter, cấu hình signing của bạn và build bằng Xcode. Deployment target giữ nguyên iOS 14.

## Kiểm tra tự động

Workflow kiểm tra cả source lẫn Info.plist **bên trong app đã build**, yêu cầu đúng phiên bản `1.6.38` / `10638` và có ngoại lệ HTTP cho Tailscale. Nếu thiếu ngoại lệ hoặc dùng nhầm source cũ, job phải dừng, không xuất IPA.

Các bước có thể chạy tại thư mục source:

```sh
python3 tests/check-tailscale-config.py
node --check CWDatacenter/Resources/Web/app.js
node --test tests/network-bridge.test.cjs
```

Trên Mac chạy thêm kiểm tra mã Swift phân loại lỗi:

```sh
xcrun swiftc CWDatacenter/Network/HostConnectionDiagnostics.swift tests/main.swift -o /tmp/cw-host-network-tests
/tmp/cw-host-network-tests
```

Workflow vẫn giữ build tuần tự, xuất nhật ký và xcresult trong artifact **CW-Datacenter-iOS-build-diagnostics** khi lỗi build.

## Kiểm tra trên iPhone sau khi cài

- Kiểm tra app hiển thị phiên bản **1.6.38**. Không cần cài lại Host.
- Bật Tailscale, chọn Host `100.66.66.66`, cổng `8080`: trạng thái phải chuyển Trực tuyến.
- Đăng nhập bằng tài khoản đang dùng; thử cả thông báo khi nhập sai mật khẩu.
- Mở danh sách tệp, thumbnail, ảnh, video, PDF và thử tải một tệp nhỏ qua cùng IP Tailscale.
- Thử kết nối qua IP LAN như trước; thử ngắt mạng để kiểm tra thông báo không đánh đồng với lỗi ATS.

## Giới hạn xác minh

Gói này được sửa và kiểm tra cấu hình/JavaScript trên Windows. Chưa biên dịch Xcode, chưa tạo IPA và chưa chạy trên iPhone trong phiên làm việc này. Kiểm tra Swift và Info.plist của app đã biên dịch sẽ chạy khi bạn chạy workflow trên Mac/GitHub Actions.

Ngoại lệ mới áp dụng cho **IP Tailscale IPv4** trong dải đã nêu. Không mở rộng HTTP ra mọi website, không vô hiệu hóa xác minh chứng chỉ HTTPS và không thay đổi cơ chế video/download.
