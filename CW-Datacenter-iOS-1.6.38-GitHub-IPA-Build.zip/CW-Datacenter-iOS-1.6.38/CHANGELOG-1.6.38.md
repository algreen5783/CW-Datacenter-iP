# CW Datacenter iOS 1.6.38

- Vuốt ngang trong trình phát video chuyển sang video liền kề trong danh sách thay vì tua thời gian.
- Vuốt sang phải mở video bên phải; vuốt sang trái mở video bên trái.
- Thao tác hoạt động cả khi video đang phát hoặc tạm dừng và giữ nguyên trạng thái đó khi chuyển video.
- Bổ sung xử lý giới hạn đầu/cuối danh sách để không thoát hoặc tua nhầm video.
