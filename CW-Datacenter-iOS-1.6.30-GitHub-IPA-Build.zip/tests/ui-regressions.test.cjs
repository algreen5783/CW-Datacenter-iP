const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'CWDatacenter/Resources/Web/app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'CWDatacenter/Resources/Web/index.html'), 'utf8');
const player = fs.readFileSync(path.join(root, 'CWDatacenter/ViewControllers/PlayerViewController.swift'), 'utf8');
const pdf = fs.readFileSync(path.join(root, 'CWDatacenter/ViewControllers/PdfViewController.swift'), 'utf8');
const main = fs.readFileSync(path.join(root, 'CWDatacenter/ViewControllers/MainViewController.swift'), 'utf8');

test('overview carousel keeps identity and updates progress in place', () => {
  assert.match(app, /function renderOverviewContinue\(videos\)/);
  assert.match(app, /identity !== overviewContinueIdentity/);
  assert.match(app, /nextRail\.scrollLeft = oldScroll/);
});

test('overview adds account-scoped quick folders and recent files', () => {
  assert.match(app, /iosOverviewQuickFolders:v2:/);
  assert.match(app, /iosOverviewRecentFiles:v1:/);
  assert.match(app, /overviewPathIsConfiguredProtected\(item\.rel/);
  assert.match(html, /id="overviewQuickFolders"/);
  assert.match(html, /id="overviewRecentFiles"/);
});

test('bottom navigation exposes favorites and moves transfers to More', () => {
  assert.match(html, /data-target="favorites"/);
  assert.doesNotMatch(html, /data-target="transfers"[^\n]*<div>Truyền tải<\/div>/);
  assert.match(app, /sheetItem\(body, 'Truyền tải'/);
});

test('photo favorite uses an exported web bridge', () => {
  assert.match(app, /window\.CWPhotoFavoriteToggle = function/);
  assert.match(main, /window\.CWPhotoFavoriteToggle/);
});

test('video gestures do not swallow control touches and labels are compact', () => {
  assert.match(player, /UIGestureRecognizerDelegate/);
  assert.match(player, /cancelsTouchesInView = false/);
  assert.match(player, /title: "Danh\.\.\."/);
});

test('PDF web content is pinned to the safe area', () => {
  assert.match(pdf, /streamView\.topAnchor\.constraint\(equalTo: view\.safeAreaLayoutGuide\.topAnchor\)/);
  assert.match(pdf, /readerView\.topAnchor\.constraint\(equalTo: view\.safeAreaLayoutGuide\.topAnchor\)/);
});

test('transfer progress updates without rebuilding the full list', () => {
  assert.match(app, /function updateTransferCardProgress\(t\)/);
  assert.match(app, /structuralChange \|\| !updateTransferCardProgress\(found\)/);
});

test('trash has media thumbnails and per-item permanent delete', () => {
  assert.match(app, /cacheTrashThumbnail/);
  assert.match(app, /trash-delete-one/);
  assert.match(app, /api\('\/api\/trash\/purge', 'POST', \{ id: it\.id \}\)/);
});
