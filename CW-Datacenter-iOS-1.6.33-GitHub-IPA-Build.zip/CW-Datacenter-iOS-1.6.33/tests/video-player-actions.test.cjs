const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const player = fs.readFileSync(path.join(root, 'CWDatacenter', 'ViewControllers', 'PlayerViewController.swift'), 'utf8');
const main = fs.readFileSync(path.join(root, 'CWDatacenter', 'ViewControllers', 'MainViewController.swift'), 'utf8');
const web = fs.readFileSync(path.join(root, 'CWDatacenter', 'Resources', 'Web', 'app.js'), 'utf8');

test('video toolbar contains only the four requested actions', () => {
  assert.match(player, /UIStackView\(arrangedSubviews: \[downloadBtn, favoriteBtn, shareBtn, deleteBtn\]\)/);
  assert.match(player, /title: "Tải về", symbol: "arrow\.down\.to\.line"/);
  assert.match(player, /title: "Yêu thích", symbol: isFavorite \? "heart\.fill" : "heart"/);
  assert.match(player, /title: "Chia sẻ", symbol: "square\.and\.arrow\.up"/);
  assert.match(player, /title: "Xóa", symbol: "trash"/);
  for (const oldButton of ['lockBtn', 'speedBtn', 'subtitleBtn', 'aspectBtn', 'playlistBtn']) {
    assert.doesNotMatch(player, new RegExp(`configureToolButton\\(${oldButton}`));
  }
});

test('player actions are wired to native storage, favorites, share sheet and host delete', () => {
  assert.match(player, /var onDownload:/);
  assert.match(player, /var onFavorite:/);
  assert.match(player, /var onPrepareShare:/);
  assert.match(player, /var onDelete:/);
  assert.match(player, /UIActivityViewController\(activityItems: \[localUrl\]/);
  assert.match(player, /title: "Xóa video\?"/);
  assert.match(main, /playerVc\.onDownload =/);
  assert.match(main, /playerVc\.onFavorite =/);
  assert.match(main, /playerVc\.onPrepareShare =/);
  assert.match(main, /playerVc\.onDelete =/);
  assert.match(main, /request\.httpMethod = "DELETE"/);
  assert.match(main, /runResumableDownload\(/);
});

test('favorites and deletion synchronize back to the web UI', () => {
  assert.match(web, /window\.CWVideoFavoriteToggle = function/);
  assert.match(web, /window\.CWVideoDeleted = function/);
  assert.match(web, /favorite: favs\.some/);
  assert.match(web, /kvSet\(kFavs\(\), favs\)/);
  assert.match(player, /if !wasDeleted \{ saveCurrentPosition\(\) \}/);
});
