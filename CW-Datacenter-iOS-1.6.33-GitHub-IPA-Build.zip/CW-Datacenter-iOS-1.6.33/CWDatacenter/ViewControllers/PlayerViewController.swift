import UIKit
import AVFoundation

class PlayerViewController: UIViewController, UIGestureRecognizerDelegate {

    private var videoUrl: String
    private var videoName: String
    private var playlist: [[String: Any]]
    private var explicitStartPos: Int64
    private var subtitleCandidates: [[String: String]]
    private var watchBaseUrl: String
    private var watchToken: String
    private var videoRel: String
    private var videoPool: String
    private var videoSize: Int64
    private var lastWatchProgressSentAt = Date.distantPast

    var onFavorite: (([String: Any], @escaping (Bool) -> Void) -> Void)?
    var onDownload: (([String: Any], @escaping (Bool, String?) -> Void) -> Void)?
    var onPrepareShare: (([String: Any], @escaping (URL?, String?) -> Void) -> Void)?
    var onDelete: (([String: Any], @escaping (Bool, String?) -> Void) -> Void)?

    private var player: AVPlayer?
    private var playerLayer: AVPlayerLayer?
    private var timeObserverToken: Any?

    private var isPlaying = false
    private var controlsVisible = true
    private var isFavorite = false
    private var actionInProgress = false
    private var wasDeleted = false

    // UI Elements
    private let topBar = UIView()
    private let titleLabel = UILabel()
    private let closeBtn = UIButton(type: .system)
    private let toolBar = UIVisualEffectView(effect: UIBlurEffect(style: .systemThinMaterialDark))
    private let downloadBtn = UIButton(type: .system)
    private let favoriteBtn = UIButton(type: .system)
    private let shareBtn = UIButton(type: .system)
    private let deleteBtn = UIButton(type: .system)

    private let centerControls = UIView()
    private let playPauseBtn = UIButton(type: .custom)
    private let rewindBtn = UIButton(type: .custom)
    private let forwardBtn = UIButton(type: .custom)

    private let bottomBar = UIView()
    private let currentTimeLabel = UILabel()
    private let durationLabel = UILabel()
    private let seekSlider = UISlider()
    private let muteBtn = UIButton(type: .system)

    private let toastLabel = UILabel()
    private let subtitleLabel = UILabel()
    private var subtitleCues: [(start: Double, end: Double, text: String)] = []
    private var subtitleOffset: Double = 0
    private var subtitleTextSize: CGFloat = 22
    private var subtitleName = ""

    private var hideTimer: Timer?
    private var isSeeking = false

    init(url: String, name: String?, playlist: [[String: Any]], startPos: Int64,
         subtitleCandidates: [[String: String]] = [], baseUrl: String = "", token: String = "",
         rel: String = "", pool: String = "", size: Int64 = 0, favorite: Bool = false) {
        self.videoUrl = url
        self.videoName = name ?? "Đang phát video"
        self.playlist = playlist
        self.explicitStartPos = startPos
        self.subtitleCandidates = subtitleCandidates
        self.watchBaseUrl = baseUrl.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        self.watchToken = token
        self.videoRel = rel
        self.videoPool = pool.isEmpty ? "main" : pool
        self.videoSize = size
        self.isFavorite = favorite
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override var prefersStatusBarHidden: Bool {
        return !controlsVisible
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .allButUpsideDown
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        setupPlayer()
        setupUI()
        setupGestures()
        autoLoadMatchingSubtitle()

        showControls()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        playerLayer?.frame = view.bounds
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if !wasDeleted { saveCurrentPosition() }
        cleanupPlayer()
    }

    // MARK: - Player Setup
    private func setupPlayer() {
        guard let url = URL(string: videoUrl) else { return }
        let asset = AVURLAsset(url: url)
        let playerItem = AVPlayerItem(asset: asset)

        player = AVPlayer(playerItem: playerItem)
        playerLayer = AVPlayerLayer(player: player)
        playerLayer?.videoGravity = .resizeAspect
        playerLayer?.frame = view.bounds
        if let layer = playerLayer {
            view.layer.addSublayer(layer)
        }

        // Time observer
        let interval = CMTime(seconds: 0.5, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        timeObserverToken = player?.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            self?.onTimeUpdate(time: time)
        }

        // Resume position
        let posKey = "vpos_" + (videoName.isEmpty ? String(videoUrl.hashValue) : videoName)
        if explicitStartPos == 0 {
            UserDefaults.standard.removeObject(forKey: posKey)
            showToast("Phát lại từ đầu")
        } else if explicitStartPos > 0 {
            let targetTime = CMTime(seconds: Double(explicitStartPos) / 1000.0, preferredTimescale: 600)
            player?.seek(to: targetTime, toleranceBefore: .zero, toleranceAfter: .zero)
            showToast("Đang phát tiếp từ \(formatTime(seconds: Double(explicitStartPos) / 1000.0))")
        } else {
            let savedPos = UserDefaults.standard.integer(forKey: posKey)
            if savedPos > 5000 {
                let targetTime = CMTime(seconds: Double(savedPos) / 1000.0, preferredTimescale: 600)
                player?.seek(to: targetTime, toleranceBefore: .zero, toleranceAfter: .zero)
                showToast("Đang phát tiếp từ \(formatTime(seconds: Double(savedPos) / 1000.0))")
            }
            fetchRemoteWatchProgress()
        }

        player?.play()
        isPlaying = true
        updatePlayPauseButton()
    }

    private func cleanupPlayer() {
        if let token = timeObserverToken {
            player?.removeTimeObserver(token)
            timeObserverToken = nil
        }
        player?.pause()
        player = nil
        playerLayer?.removeFromSuperlayer()
    }

    private func saveCurrentPosition() {
        guard let p = player else { return }
        let sec = CMTimeGetSeconds(p.currentTime())
        if sec > 3 && !sec.isNaN && !sec.isInfinite {
            let posKey = "vpos_" + (videoName.isEmpty ? String(videoUrl.hashValue) : videoName)
            let durationSec = p.currentItem.map { CMTimeGetSeconds($0.duration) } ?? 0
            let completed = durationSec.isFinite && durationSec > 0 && (sec >= durationSec - 5 || sec * 100 >= durationSec * 95)
            if completed { UserDefaults.standard.removeObject(forKey: posKey) }
            else { UserDefaults.standard.set(Int(sec * 1000), forKey: posKey) }
            sendRemoteWatchProgress(positionMs: Int64(sec * 1000),
                                    durationMs: durationSec.isFinite && durationSec > 0 ? Int64(durationSec * 1000) : 0,
                                    completed: completed)
        }
    }

    private func watchProgressURL(query: Bool) -> URL? {
        guard !watchBaseUrl.isEmpty, !watchToken.isEmpty, !videoRel.isEmpty else { return nil }
        guard var components = URLComponents(string: watchBaseUrl + "/api/watch-progress") else { return nil }
        if query {
            components.queryItems = [
                URLQueryItem(name: "pool", value: videoPool.isEmpty ? "main" : videoPool),
                URLQueryItem(name: "path", value: videoRel)
            ]
        }
        return components.url
    }

    private func authorizedRequest(url: URL, method: String) -> URLRequest {
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.timeoutInterval = 10
        request.setValue("Bearer \(watchToken)", forHTTPHeaderField: "Authorization")
        return request
    }

    private func fetchRemoteWatchProgress() {
        guard let url = watchProgressURL(query: true) else { return }
        let requestedRel = videoRel
        URLSession.shared.dataTask(with: authorizedRequest(url: url, method: "GET")) { [weak self] data, response, _ in
            guard let self, let http = response as? HTTPURLResponse, http.statusCode == 200,
                  let data,
                  let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let item = root["item"] as? [String: Any] else { return }
            let remotePos = (item["positionMs"] as? NSNumber)?.int64Value ?? 0
            DispatchQueue.main.async {
                guard self.videoRel == requestedRel, self.explicitStartPos < 0,
                      let player = self.player else { return }
                let current = CMTimeGetSeconds(player.currentTime()) * 1000
                if remotePos > 3000 && current < 5000 && abs(Double(remotePos) - current) > 3000 {
                    player.seek(to: CMTime(seconds: Double(remotePos) / 1000, preferredTimescale: 600),
                                toleranceBefore: .zero, toleranceAfter: .zero)
                    self.showToast("Đồng bộ xem tiếp từ \(self.formatTime(seconds: Double(remotePos) / 1000))")
                }
            }
        }.resume()
    }

    private func watchDeviceId() -> String {
        let key = "cw_watch_device_id"
        if let value = UserDefaults.standard.string(forKey: key), !value.isEmpty { return value }
        let value = UUID().uuidString
        UserDefaults.standard.set(value, forKey: key)
        return value
    }

    private func sendRemoteWatchProgress(positionMs: Int64, durationMs: Int64, completed: Bool) {
        guard let url = watchProgressURL(query: false) else { return }
        let payload: [String: Any] = [
            "pool": videoPool.isEmpty ? "main" : videoPool,
            "size": videoSize,
            "path": videoRel,
            "name": videoName,
            "positionMs": max(0, positionMs),
            "durationMs": max(0, durationMs),
            "completed": completed,
            "deviceId": watchDeviceId(),
            "deviceName": UIDevice.current.name
        ]
        guard let body = try? JSONSerialization.data(withJSONObject: payload) else { return }
        var request = authorizedRequest(url: url, method: "PUT")
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.httpBody = body
        URLSession.shared.dataTask(with: request).resume()
        lastWatchProgressSentAt = Date()
    }

    // MARK: - UI Setup
    private func setupUI() {
        setupTopBar()
        setupCenterControls()
        setupBottomBar()
        setupToolBar()
        setupSubtitleOverlay()
        setupToast()
    }

    private func setupTopBar() {
        topBar.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        topBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(topBar)

        closeBtn.setImage(UIImage(systemName: "chevron.left"), for: .normal)
        closeBtn.setTitleColor(.white, for: .normal)
        closeBtn.tintColor = .white
        closeBtn.addTarget(self, action: #selector(onCloseTapped), for: .touchUpInside)
        closeBtn.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(closeBtn)

        titleLabel.text = videoName
        titleLabel.textColor = .white
        titleLabel.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(titleLabel)

        NSLayoutConstraint.activate([
            topBar.topAnchor.constraint(equalTo: view.topAnchor),
            topBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            topBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            topBar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 50),

            closeBtn.leadingAnchor.constraint(equalTo: topBar.leadingAnchor, constant: 16),
            closeBtn.bottomAnchor.constraint(equalTo: topBar.bottomAnchor, constant: -8),
            closeBtn.widthAnchor.constraint(equalToConstant: 36),
            closeBtn.heightAnchor.constraint(equalToConstant: 36),

            titleLabel.leadingAnchor.constraint(equalTo: closeBtn.trailingAnchor, constant: 12),
            titleLabel.centerYAnchor.constraint(equalTo: closeBtn.centerYAnchor),
            titleLabel.trailingAnchor.constraint(equalTo: topBar.trailingAnchor, constant: -16)
        ])
    }

    private func setupSubtitleOverlay() {
        subtitleLabel.textColor = .white
        subtitleLabel.font = UIFont.systemFont(ofSize: subtitleTextSize, weight: .semibold)
        subtitleLabel.textAlignment = .center
        subtitleLabel.numberOfLines = 4
        subtitleLabel.backgroundColor = UIColor.black.withAlphaComponent(0.58)
        subtitleLabel.layer.cornerRadius = 6
        subtitleLabel.layer.masksToBounds = true
        subtitleLabel.isHidden = true
        subtitleLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(subtitleLabel)
        NSLayoutConstraint.activate([
            subtitleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            subtitleLabel.leadingAnchor.constraint(greaterThanOrEqualTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 24),
            subtitleLabel.trailingAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -24),
            subtitleLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -150)
        ])
    }

    private func setupCenterControls() {
        centerControls.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(centerControls)

        // Rewind
        rewindBtn.setImage(UIImage(systemName: "gobackward.10"), for: .normal)
        rewindBtn.setTitleColor(.white, for: .normal)
        rewindBtn.tintColor = .white
        rewindBtn.backgroundColor = UIColor.black.withAlphaComponent(0.55)
        rewindBtn.layer.cornerRadius = 28
        rewindBtn.layer.borderWidth = 1
        rewindBtn.layer.borderColor = UIColor.white.withAlphaComponent(0.2).cgColor
        rewindBtn.addTarget(self, action: #selector(onRewindTapped), for: .touchUpInside)
        rewindBtn.translatesAutoresizingMaskIntoConstraints = false
        centerControls.addSubview(rewindBtn)

        // Play/Pause
        playPauseBtn.setImage(UIImage(systemName: "pause.fill"), for: .normal)
        playPauseBtn.setTitleColor(.white, for: .normal)
        playPauseBtn.tintColor = .white
        playPauseBtn.setPreferredSymbolConfiguration(UIImage.SymbolConfiguration(pointSize: 28, weight: .bold), forImageIn: .normal)
        playPauseBtn.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        playPauseBtn.layer.cornerRadius = 38
        playPauseBtn.layer.borderWidth = 1
        playPauseBtn.layer.borderColor = UIColor.white.withAlphaComponent(0.25).cgColor
        playPauseBtn.addTarget(self, action: #selector(onPlayPauseTapped), for: .touchUpInside)
        playPauseBtn.translatesAutoresizingMaskIntoConstraints = false
        centerControls.addSubview(playPauseBtn)

        // Forward
        forwardBtn.setImage(UIImage(systemName: "goforward.10"), for: .normal)
        forwardBtn.setTitleColor(.white, for: .normal)
        forwardBtn.tintColor = .white
        forwardBtn.backgroundColor = UIColor.black.withAlphaComponent(0.55)
        forwardBtn.layer.cornerRadius = 28
        forwardBtn.layer.borderWidth = 1
        forwardBtn.layer.borderColor = UIColor.white.withAlphaComponent(0.2).cgColor
        forwardBtn.addTarget(self, action: #selector(onForwardTapped), for: .touchUpInside)
        forwardBtn.translatesAutoresizingMaskIntoConstraints = false
        centerControls.addSubview(forwardBtn)

        NSLayoutConstraint.activate([
            centerControls.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            centerControls.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            centerControls.heightAnchor.constraint(equalToConstant: 80),

            playPauseBtn.centerXAnchor.constraint(equalTo: centerControls.centerXAnchor),
            playPauseBtn.centerYAnchor.constraint(equalTo: centerControls.centerYAnchor),
            playPauseBtn.widthAnchor.constraint(equalToConstant: 76),
            playPauseBtn.heightAnchor.constraint(equalToConstant: 76),

            rewindBtn.trailingAnchor.constraint(equalTo: playPauseBtn.leadingAnchor, constant: -28),
            rewindBtn.centerYAnchor.constraint(equalTo: centerControls.centerYAnchor),
            rewindBtn.widthAnchor.constraint(equalToConstant: 76),
            rewindBtn.heightAnchor.constraint(equalToConstant: 56),

            forwardBtn.leadingAnchor.constraint(equalTo: playPauseBtn.trailingAnchor, constant: 28),
            forwardBtn.centerYAnchor.constraint(equalTo: centerControls.centerYAnchor),
            forwardBtn.widthAnchor.constraint(equalToConstant: 76),
            forwardBtn.heightAnchor.constraint(equalToConstant: 56)
        ])
    }

    private func setupBottomBar() {
        bottomBar.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        bottomBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bottomBar)

        currentTimeLabel.text = "00:00"
        currentTimeLabel.textColor = .white
        currentTimeLabel.font = UIFont.monospacedDigitSystemFont(ofSize: 13, weight: .regular)
        currentTimeLabel.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.addSubview(currentTimeLabel)

        durationLabel.text = "--:--"
        durationLabel.textColor = UIColor.white.withAlphaComponent(0.7)
        durationLabel.font = UIFont.monospacedDigitSystemFont(ofSize: 13, weight: .regular)
        durationLabel.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.addSubview(durationLabel)

        seekSlider.minimumTrackTintColor = UIColor(red: 1.0, green: 0.22, blue: 0.36, alpha: 1.0)
        seekSlider.maximumTrackTintColor = UIColor.white.withAlphaComponent(0.25)
        seekSlider.addTarget(self, action: #selector(onSliderChanged), for: .valueChanged)
        seekSlider.addTarget(self, action: #selector(onSliderTouchDown), for: .touchDown)
        seekSlider.addTarget(self, action: #selector(onSliderTouchUp), for: [.touchUpInside, .touchUpOutside, .touchCancel])
        seekSlider.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.addSubview(seekSlider)

        muteBtn.setImage(UIImage(systemName: "speaker.wave.2.fill"), for: .normal)
        muteBtn.tintColor = .white
        muteBtn.addTarget(self, action: #selector(onMuteTapped), for: .touchUpInside)
        muteBtn.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.addSubview(muteBtn)

        NSLayoutConstraint.activate([
            bottomBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bottomBar.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            bottomBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -56),

            currentTimeLabel.leadingAnchor.constraint(equalTo: bottomBar.leadingAnchor, constant: 16),
            currentTimeLabel.topAnchor.constraint(equalTo: bottomBar.topAnchor, constant: 14),

            seekSlider.leadingAnchor.constraint(equalTo: currentTimeLabel.trailingAnchor, constant: 10),
            seekSlider.trailingAnchor.constraint(equalTo: durationLabel.leadingAnchor, constant: -10),
            seekSlider.centerYAnchor.constraint(equalTo: currentTimeLabel.centerYAnchor),

            durationLabel.trailingAnchor.constraint(equalTo: muteBtn.leadingAnchor, constant: -14),
            durationLabel.centerYAnchor.constraint(equalTo: currentTimeLabel.centerYAnchor),

            muteBtn.trailingAnchor.constraint(equalTo: bottomBar.trailingAnchor, constant: -16),
            muteBtn.centerYAnchor.constraint(equalTo: currentTimeLabel.centerYAnchor),
            muteBtn.widthAnchor.constraint(equalToConstant: 32)
        ])
    }

    private func setupToolBar() {
        toolBar.layer.cornerRadius = 18
        toolBar.clipsToBounds = true
        toolBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(toolBar)

        configureToolButton(downloadBtn, title: "Tải về", symbol: "arrow.down.to.line", action: #selector(onDownloadTapped))
        configureToolButton(favoriteBtn, title: "Yêu thích", symbol: isFavorite ? "heart.fill" : "heart", action: #selector(onFavoriteTapped))
        configureToolButton(shareBtn, title: "Chia sẻ", symbol: "square.and.arrow.up", action: #selector(onShareTapped))
        configureToolButton(deleteBtn, title: "Xóa", symbol: "trash", action: #selector(onDeleteTapped))
        setToolButtonColor(deleteBtn, .systemRed)

        let stack = UIStackView(arrangedSubviews: [downloadBtn, favoriteBtn, shareBtn, deleteBtn])
        stack.axis = .horizontal
        stack.distribution = .fillEqually
        stack.translatesAutoresizingMaskIntoConstraints = false
        toolBar.contentView.addSubview(stack)

        NSLayoutConstraint.activate([
            toolBar.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 12),
            toolBar.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -12),
            toolBar.bottomAnchor.constraint(equalTo: bottomBar.topAnchor, constant: -10),
            toolBar.heightAnchor.constraint(equalToConstant: 68),
            stack.leadingAnchor.constraint(equalTo: toolBar.contentView.leadingAnchor, constant: 4),
            stack.trailingAnchor.constraint(equalTo: toolBar.contentView.trailingAnchor, constant: -4),
            stack.topAnchor.constraint(equalTo: toolBar.contentView.topAnchor, constant: 4),
            stack.bottomAnchor.constraint(equalTo: toolBar.contentView.bottomAnchor, constant: -4)
        ])
    }

    private func configureToolButton(_ button: UIButton, title: String, symbol: String, action: Selector) {
        button.tintColor = .white
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 9.5, weight: .medium)
        button.titleLabel?.numberOfLines = 1
        button.titleLabel?.lineBreakMode = .byTruncatingTail
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        button.titleLabel?.minimumScaleFactor = 0.78
        if #available(iOS 15.0, *) {
            var config = UIButton.Configuration.plain()
            config.image = UIImage(systemName: symbol)
            config.title = title
            config.imagePlacement = .top
            config.imagePadding = 4
            config.titleLineBreakMode = .byTruncatingTail
            config.baseForegroundColor = .white
            button.configuration = config
        } else {
            button.setImage(UIImage(systemName: symbol), for: .normal)
            button.setTitle(title, for: .normal)
        }
        button.addTarget(self, action: action, for: .touchUpInside)
    }

    private func updateToolTitle(_ button: UIButton, _ title: String) {
        if #available(iOS 15.0, *) {
            var config = button.configuration
            config?.title = title
            button.configuration = config
        } else {
            button.setTitle(title, for: .normal)
        }
    }

    private func setToolButtonColor(_ button: UIButton, _ color: UIColor) {
        button.tintColor = color
        button.setTitleColor(color, for: .normal)
        if #available(iOS 15.0, *) {
            var config = button.configuration
            config?.baseForegroundColor = color
            button.configuration = config
        }
    }

    private func setActionButtonsEnabled(_ enabled: Bool) {
        [downloadBtn, favoriteBtn, shareBtn, deleteBtn].forEach {
            $0.isEnabled = enabled
            $0.alpha = enabled ? 1 : 0.55
        }
    }

    private func updateFavoriteButton() {
        let image = UIImage(systemName: isFavorite ? "heart.fill" : "heart")
        if #available(iOS 15.0, *) {
            var config = favoriteBtn.configuration
            config?.image = image
            favoriteBtn.configuration = config
        } else {
            favoriteBtn.setImage(image, for: .normal)
        }
        setToolButtonColor(favoriteBtn, isFavorite ? .systemPink : .white)
    }

    private func setupToast() {
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        toastLabel.textColor = .white
        toastLabel.font = UIFont.systemFont(ofSize: 13.5, weight: .medium)
        toastLabel.textAlignment = .center
        toastLabel.layer.cornerRadius = 18
        toastLabel.layer.masksToBounds = true
        toastLabel.layer.borderWidth = 1
        toastLabel.layer.borderColor = UIColor.white.withAlphaComponent(0.2).cgColor
        toastLabel.alpha = 0
        toastLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(toastLabel)

        NSLayoutConstraint.activate([
            toastLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            toastLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 60),
            toastLabel.heightAnchor.constraint(equalToConstant: 36),
            toastLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 140)
        ])
    }

    private var initialPanLocation: CGPoint = .zero
    private var panMode: Int = 0 // 1: brightness (left), 2: volume (right), 3: seek (horizontal)
    private var initialSeekPos: Double = 0

    private func setupGestures() {
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(onSurfaceTapped))
        singleTap.numberOfTapsRequired = 1
        singleTap.cancelsTouchesInView = false
        singleTap.delegate = self

        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(onDoubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        doubleTap.cancelsTouchesInView = false
        doubleTap.delegate = self
        singleTap.require(toFail: doubleTap)

        view.addGestureRecognizer(singleTap)
        view.addGestureRecognizer(doubleTap)

        let pan = UIPanGestureRecognizer(target: self, action: #selector(onPanGesture(_:)))
        pan.cancelsTouchesInView = false
        pan.delegate = self
        view.addGestureRecognizer(pan)
    }

    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        var node: UIView? = touch.view
        while let current = node {
            if current is UIControl || current === centerControls || current === topBar || current === bottomBar || current === toolBar.contentView {
                return false
            }
            node = current.superview
        }
        return true
    }

    @objc private func onDoubleTap(_ gesture: UITapGestureRecognizer) {
        let point = gesture.location(in: view)
        let isLeft = point.x < (view.bounds.width / 2)
        if isLeft {
            skip(seconds: -10)
        } else {
            skip(seconds: 10)
        }
    }

    @objc private func onPanGesture(_ gesture: UIPanGestureRecognizer) {
        let point = gesture.location(in: view)
        let translation = gesture.translation(in: view)

        switch gesture.state {
        case .began:
            initialPanLocation = point
            if abs(translation.x) > abs(translation.y) {
                panMode = 3 // Seek
                initialSeekPos = player != nil ? CMTimeGetSeconds(player!.currentTime()) : 0
            } else {
                panMode = point.x < (view.bounds.width / 2) ? 1 : 2 // 1: Brightness, 2: Volume
            }
        case .changed:
            if panMode == 1 {
                // Brightness
                let delta = -translation.y / view.bounds.height
                let cur = UIScreen.main.brightness
                UIScreen.main.brightness = max(0, min(1.0, cur + (delta * 0.05)))
                showToast("Độ sáng: \(Int(UIScreen.main.brightness * 100))%")
            } else if panMode == 2 {
                // Volume
                let delta = Float(-translation.y / view.bounds.height)
                let cur = player?.volume ?? 1.0
                player?.volume = max(0, min(1.0, cur + (delta * 0.05)))
                showToast("Âm lượng: \(Int((player?.volume ?? 1.0) * 100))%")
            } else if panMode == 3 {
                // Seek
                guard let dur = player?.currentItem?.duration else { return }
                let total = CMTimeGetSeconds(dur)
                if !total.isNaN && total > 0 {
                    let deltaSec = Double(translation.x / view.bounds.width) * 90.0 // +/- 90s max per swipe
                    let target = max(0, min(total, initialSeekPos + deltaSec))
                    currentTimeLabel.text = formatTime(seconds: target)
                    showToast("\(formatTime(seconds: target)) / \(formatTime(seconds: total))")
                }
            }
        case .ended, .cancelled:
            if panMode == 3 {
                guard let dur = player?.currentItem?.duration else { return }
                let total = CMTimeGetSeconds(dur)
                if !total.isNaN && total > 0 {
                    let deltaSec = Double(translation.x / view.bounds.width) * 90.0
                    let target = max(0, min(total, initialSeekPos + deltaSec))
                    let cmTarget = CMTime(seconds: target, preferredTimescale: 600)
                    player?.seek(to: cmTarget, toleranceBefore: .zero, toleranceAfter: .zero)
                }
            }
            panMode = 0
            scheduleHide()
        default: break
        }
    }

    // MARK: - Actions
    @objc private func onSurfaceTapped() {
        if controlsVisible {
            hideControls()
        } else {
            showControls()
        }
    }

    @objc private func onPlayPauseTapped() {
        guard let p = player else { return }
        if isPlaying {
            p.pause()
            isPlaying = false
            showToast("Đã tạm dừng")
        } else {
            p.play()
            isPlaying = true
            showToast("Đang phát")
        }
        updatePlayPauseButton()
        scheduleHide()
    }

    @objc private func onRewindTapped() {
        skip(seconds: -10)
    }

    @objc private func onForwardTapped() {
        skip(seconds: 10)
    }

    private func skip(seconds: Double) {
        guard let p = player else { return }
        let current = CMTimeGetSeconds(p.currentTime())
        var target = current + seconds
        if let dur = p.currentItem?.duration {
            let total = CMTimeGetSeconds(dur)
            if !total.isNaN && total > 0 {
                target = max(0, min(total, target))
            }
        }
        target = max(0, target)
        let cmTarget = CMTime(seconds: target, preferredTimescale: 600)
        p.seek(to: cmTarget, toleranceBefore: .zero, toleranceAfter: .zero)
        showToast(seconds > 0 ? "Tiến 10 giây" : "Lùi 10 giây")
        showControls()
    }

    @objc private func onSliderTouchDown() {
        isSeeking = true
        hideTimer?.invalidate()
    }

    @objc private func onSliderChanged() {
        guard let dur = player?.currentItem?.duration else { return }
        let total = CMTimeGetSeconds(dur)
        guard !total.isNaN && total > 0 else { return }
        let current = Double(seekSlider.value) * total
        currentTimeLabel.text = formatTime(seconds: current)
    }

    @objc private func onSliderTouchUp() {
        isSeeking = false
        guard let p = player, let dur = p.currentItem?.duration else { return }
        let total = CMTimeGetSeconds(dur)
        guard !total.isNaN && total > 0 else { return }
        let target = Double(seekSlider.value) * total
        let cmTarget = CMTime(seconds: target, preferredTimescale: 600)
        p.seek(to: cmTarget, toleranceBefore: .zero, toleranceAfter: .zero)
        scheduleHide()
    }

    private var currentVideoItem: [String: Any] {
        [
            "name": videoName,
            "url": videoUrl,
            "baseUrl": watchBaseUrl,
            "token": watchToken,
            "rel": videoRel,
            "pool": videoPool.isEmpty ? "main" : videoPool,
            "size": videoSize,
            "type": "file",
            "favorite": isFavorite
        ]
    }

    @objc private func onDownloadTapped() {
        guard !actionInProgress else { return }
        guard let action = onDownload else { showToast("Không thể tải video này"); return }
        actionInProgress = true
        setActionButtonsEnabled(false)
        updateToolTitle(downloadBtn, "Đang tải…")
        showToast("Đang tải video về máy…")
        action(currentVideoItem) { [weak self] ok, message in
            DispatchQueue.main.async {
                guard let self else { return }
                self.actionInProgress = false
                self.setActionButtonsEnabled(true)
                self.updateToolTitle(self.downloadBtn, "Tải về")
                self.showToast(message ?? (ok ? "Đã tải video về máy" : "Không tải được video"))
                self.scheduleHide()
            }
        }
    }

    @objc private func onFavoriteTapped() {
        guard !actionInProgress else { return }
        guard let action = onFavorite else { showToast("Không thể cập nhật yêu thích"); return }
        action(currentVideoItem) { [weak self] enabled in
            DispatchQueue.main.async {
                guard let self else { return }
                self.isFavorite = enabled
                self.updateFavoriteButton()
                self.showToast(enabled ? "Đã thêm vào yêu thích" : "Đã bỏ yêu thích")
                self.scheduleHide()
            }
        }
    }

    @objc private func onShareTapped() {
        guard !actionInProgress else { return }
        guard let action = onPrepareShare else { showToast("Không thể chia sẻ video này"); return }
        actionInProgress = true
        setActionButtonsEnabled(false)
        updateToolTitle(shareBtn, "Đang tải…")
        showToast("Đang chuẩn bị video để chia sẻ…")
        action(currentVideoItem) { [weak self] localUrl, message in
            DispatchQueue.main.async {
                guard let self else { return }
                self.actionInProgress = false
                self.setActionButtonsEnabled(true)
                self.updateToolTitle(self.shareBtn, "Chia sẻ")
                guard let localUrl else {
                    self.showToast(message ?? "Không chuẩn bị được video")
                    return
                }
                let controller = UIActivityViewController(activityItems: [localUrl], applicationActivities: nil)
                if let popover = controller.popoverPresentationController {
                    popover.sourceView = self.shareBtn
                    popover.sourceRect = self.shareBtn.bounds
                }
                self.present(controller, animated: true)
            }
        }
    }

    @objc private func onDeleteTapped() {
        guard !actionInProgress else { return }
        guard onDelete != nil else { showToast("Không thể xóa video này"); return }
        let alert = UIAlertController(
            title: "Xóa video?",
            message: "Video \"\(videoName)\" sẽ được chuyển vào Thùng rác của Host.",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "Hủy", style: .cancel))
        alert.addAction(UIAlertAction(title: "Xóa", style: .destructive) { [weak self] _ in
            guard let self, let onDelete = self.onDelete else { return }
            self.actionInProgress = true
            self.setActionButtonsEnabled(false)
            self.showToast("Đang xóa video…")
            onDelete(self.currentVideoItem) { [weak self] ok, message in
                DispatchQueue.main.async {
                    guard let self else { return }
                    self.actionInProgress = false
                    self.setActionButtonsEnabled(true)
                    guard ok else {
                        self.showToast(message ?? "Không xóa được video")
                        return
                    }
                    self.wasDeleted = true
                    self.player?.pause()
                    self.dismiss(animated: true)
                }
            }
        })
        present(alert, animated: true)
    }

    @objc private func onMuteTapped() {
        guard let p = player else { return }
        p.isMuted = !p.isMuted
        muteBtn.setImage(UIImage(systemName: p.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill"), for: .normal)
        showToast(p.isMuted ? "Đã tắt tiếng" : "Đã bật tiếng")
        scheduleHide()
    }

    private func playPlaylistItem(_ index: Int) {
        guard playlist.indices.contains(index), let nextUrl = playlist[index]["url"] as? String, let url = URL(string: nextUrl) else { return }
        saveCurrentPosition()
        videoUrl = nextUrl
        videoName = playlist[index]["name"] as? String ?? "Đang phát video"
        videoRel = playlist[index]["rel"] as? String ?? ""
        videoPool = (playlist[index]["pool"] as? String).flatMap { $0.isEmpty ? nil : $0 } ?? "main"
        videoSize = (playlist[index]["size"] as? NSNumber)?.int64Value ?? 0
        explicitStartPos = -1
        titleLabel.text = videoName
        subtitleCues.removeAll()
        subtitleName = ""
        subtitleLabel.isHidden = true
        let item = AVPlayerItem(asset: AVURLAsset(url: url))
        player?.replaceCurrentItem(with: item)
        let posKey = "vpos_" + (videoName.isEmpty ? String(videoUrl.hashValue) : videoName)
        let savedPos = UserDefaults.standard.integer(forKey: posKey)
        if savedPos > 5000 {
            player?.seek(to: CMTime(seconds: Double(savedPos) / 1000, preferredTimescale: 600),
                         toleranceBefore: .zero, toleranceAfter: .zero)
        }
        fetchRemoteWatchProgress()
        player?.play()
        isPlaying = true
        updatePlayPauseButton()
        autoLoadMatchingSubtitle()
        showToast("Đang phát \(videoName)")
        showControls()
    }

    private func autoLoadMatchingSubtitle() {
        let base = (videoName as NSString).deletingPathExtension.lowercased()
        if let candidate = subtitleCandidates.first(where: { (($0["name"] ?? "") as NSString).deletingPathExtension.lowercased() == base }),
           let name = candidate["name"], let url = candidate["url"] {
            loadSubtitle(name: name, urlString: url)
        }
    }

    private func loadSubtitle(name: String, urlString: String) {
        guard let url = URL(string: urlString) else { showToast("Địa chỉ phụ đề không hợp lệ"); return }
        URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let self else { return }
            let text = data.flatMap { String(data: $0, encoding: .utf8) ?? String(data: $0, encoding: .unicode) }
            DispatchQueue.main.async {
                guard error == nil, let text else { self.showToast("Không tải được phụ đề"); return }
                let parsed = self.parseSubtitle(text)
                guard !parsed.isEmpty else { self.showToast("Phụ đề không có dòng hợp lệ"); return }
                self.subtitleCues = parsed
                self.subtitleName = name
                self.subtitleOffset = 0
                self.showToast("Đã thêm phụ đề \(name)")
            }
        }.resume()
    }

    private func parseSubtitle(_ raw: String) -> [(start: Double, end: Double, text: String)] {
        let normalized = raw.replacingOccurrences(of: "\r\n", with: "\n").replacingOccurrences(of: "\r", with: "\n")
        let blocks = normalized.components(separatedBy: "\n\n")
        var cues: [(Double, Double, String)] = []
        for block in blocks {
            let lines = block.components(separatedBy: "\n").filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
            guard let timingIndex = lines.firstIndex(where: { $0.contains("-->") }) else { continue }
            let times = lines[timingIndex].components(separatedBy: "-->")
            guard times.count == 2, let start = subtitleTime(times[0]), let end = subtitleTime(times[1]) else { continue }
            let value = lines.dropFirst(timingIndex + 1).joined(separator: "\n")
                .replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
                .trimmingCharacters(in: .whitespacesAndNewlines)
            if !value.isEmpty { cues.append((start, end, value)) }
        }
        return cues
    }

    private func subtitleTime(_ value: String) -> Double? {
        let clean = value.trimmingCharacters(in: .whitespaces).components(separatedBy: .whitespaces).first ?? value
        let parts = clean.replacingOccurrences(of: ",", with: ".").split(separator: ":").compactMap { Double($0) }
        if parts.count == 3 { return parts[0] * 3600 + parts[1] * 60 + parts[2] }
        if parts.count == 2 { return parts[0] * 60 + parts[1] }
        return nil
    }

    @objc private func onCloseTapped() {
        dismiss(animated: true)
    }

    // MARK: - Helpers
    private func onTimeUpdate(time: CMTime) {
        guard !isSeeking, let p = player else { return }
        let current = CMTimeGetSeconds(time)
        if Date().timeIntervalSince(lastWatchProgressSentAt) >= 15 { saveCurrentPosition() }
        currentTimeLabel.text = formatTime(seconds: current)
        if subtitleCues.isEmpty { subtitleLabel.isHidden = true }
        else {
            let adjusted = current - subtitleOffset
            if let cue = subtitleCues.first(where: { adjusted >= $0.start && adjusted <= $0.end }) { subtitleLabel.text = "  \(cue.text)  "; subtitleLabel.isHidden = false }
            else { subtitleLabel.isHidden = true }
        }

        if let dur = p.currentItem?.duration {
            let total = CMTimeGetSeconds(dur)
            if !total.isNaN && total > 0 {
                durationLabel.text = formatTime(seconds: total)
                seekSlider.value = Float(current / total)
                if current >= total - 0.35 {
                    isPlaying = false
                    updatePlayPauseButton()
                }
            }
        }
    }

    private func updatePlayPauseButton() {
        playPauseBtn.setImage(UIImage(systemName: isPlaying ? "pause.fill" : "play.fill"), for: .normal)
    }

    private func showControls() {
        controlsVisible = true
        topBar.isHidden = false
        bottomBar.isHidden = false
        centerControls.isHidden = false
        toolBar.isHidden = false
        UIView.animate(withDuration: 0.2) {
            self.topBar.alpha = 1
            self.bottomBar.alpha = 1
            self.centerControls.alpha = 1
            self.toolBar.alpha = 1
            self.setNeedsStatusBarAppearanceUpdate()
        }
        scheduleHide()
    }

    private func hideControls() {
        controlsVisible = false
        UIView.animate(withDuration: 0.2, animations: {
            self.topBar.alpha = 0
            self.bottomBar.alpha = 0
            self.centerControls.alpha = 0
            self.toolBar.alpha = 0
            self.setNeedsStatusBarAppearanceUpdate()
        }) { _ in
            if !self.controlsVisible {
                self.topBar.isHidden = true
                self.bottomBar.isHidden = true
                self.centerControls.isHidden = true
                self.toolBar.isHidden = true
            }
        }
    }

    private func scheduleHide() {
        hideTimer?.invalidate()
        hideTimer = Timer.scheduledTimer(withTimeInterval: 3.5, repeats: false) { [weak self] _ in
            self?.hideControls()
        }
    }

    private func showToast(_ text: String) {
        toastLabel.text = "  \(text)  "
        toastLabel.sizeToFit()
        UIView.animate(withDuration: 0.2) {
            self.toastLabel.alpha = 1
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) {
            UIView.animate(withDuration: 0.3) {
                self.toastLabel.alpha = 0
            }
        }
    }

    private func formatTime(seconds: Double) -> String {
        guard !seconds.isNaN && !seconds.isInfinite else { return "00:00" }
        let total = Int(seconds)
        let h = total / 3600
        let m = (total % 3600) / 60
        let s = total % 60
        if h > 0 {
            return String(format: "%d:%02d:%02d", h, m, s)
        }
        return String(format: "%02d:%02d", m, s)
    }
}
