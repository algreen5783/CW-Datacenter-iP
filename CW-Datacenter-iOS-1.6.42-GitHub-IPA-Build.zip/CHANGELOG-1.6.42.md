# CW Datacenter iOS 1.6.42 (10642)

- Detect inherited password locks through folders nested at any depth.
- Verify every unlock with Host 1.5.46 and prompt separately for nested locks with different passwords.
- Normalize lock paths across slash style and letter case and invalidate stale unlock sessions after password changes.
- Center the Overview scroll-to-top arrow inside its circular button.
- Show five compact photo/video thumbnails per row on Overview.
- Start videos directly with byte-range streaming, including adjacent playlist items.
- Increase thumbnail warm-up concurrency and shorten retry delays while keeping the persistent on-device cache.
- Show a cached 160 px preview immediately, then replace it with the full-resolution image in the background.
