const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'CWDatacenter/Resources/Web/index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'CWDatacenter/Resources/Web/app.js'), 'utf8');

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

assert(html.includes('id="overviewScrollTop"'), 'missing overview scroll-to-top button');
assert(html.includes('id="overviewFastScroll"'), 'missing overview fast-scroll control');
assert(html.includes('role="scrollbar"'), 'fast-scroll accessibility role missing');
assert(html.includes('bottom:calc(96px + var(--sab))'), 'scroll-to-top button does not respect bottom safe area');
assert(html.includes('bottom:calc(98px + var(--sab))'), 'fast-scroll control does not stay above bottom navigation');
assert(js.includes('function setupOverviewFastScroll()'), 'overview scroll controller missing');
assert(js.includes('const IDLE_HIDE_MS = 2000;'), 'controls do not use the requested two-second idle timeout');
assert(js.includes("scroller.scrollTo({ top: 0, behavior: 'smooth' })"), 'scroll-to-top action missing');
assert(js.includes("fastScroll.addEventListener('pointerdown'"), 'fast-scroll drag start missing');
assert(js.includes("fastScroll.addEventListener('pointermove'"), 'fast-scroll dragging missing');
assert(js.includes("fastScroll.addEventListener('pointerup'"), 'fast-scroll drag completion missing');
assert(js.includes("fastScroll.classList.add('dragging', 'show')"), 'fast-scroll is not kept visible while dragging');

console.log('iOS 1.6.42 overview fast-scroll checks passed.');
