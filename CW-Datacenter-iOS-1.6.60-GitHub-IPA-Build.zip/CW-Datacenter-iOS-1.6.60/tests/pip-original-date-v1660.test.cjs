const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const player = fs.readFileSync(path.join(root, 'CWDatacenter/ViewControllers/PlayerViewController.swift'), 'utf8');
const image = fs.readFileSync(path.join(root, 'CWDatacenter/ViewControllers/ImageViewController.swift'), 'utf8');
const app = fs.readFileSync(path.join(root, 'CWDatacenter/Resources/Web/app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'CWDatacenter/Resources/Web/index.html'), 'utf8');

assert(player.includes('import AVKit'));
assert(player.includes('AVPictureInPictureControllerDelegate'));
assert(player.includes('canStartPictureInPictureAutomaticallyFromInline = true'));
assert(player.includes('setCategory(.playback, mode: .moviePlayback'));
assert.match(app, /item\.captureDate \|\| item\.dateTaken[\s\S]*item\.sourceCreatedAt/);
assert.match(app, /item\.sourceModifiedAt \|\| item\.mtime/);
assert(app.includes("return name.slice(0, headLength) + '…' + extension"));
assert(html.includes('text-overflow:ellipsis'));
assert(image.includes('config.title = nil'));
assert(image.includes('button.accessibilityLabel = title'));

console.log('PASS iOS 1.6.60 PiP, original capture date, compact title and icon-only photo actions');
