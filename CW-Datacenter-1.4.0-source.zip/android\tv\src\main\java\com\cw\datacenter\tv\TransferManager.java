package com.cw.datacenter.tv;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.os.PowerManager;
import android.provider.DocumentsContract;
import android.provider.MediaStore;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

public class TransferManager {

    private static final int CHUNK = 4 * 1024 * 1024;

    private static volatile TransferManager INSTANCE;

    private final Context ctx;
    private final List<Consumer<String>> sinks = new ArrayList<>();
    private final ExecutorService executor = Executors.newFixedThreadPool(4);
    private final Map<String, Handle> handles = new HashMap<>();
    private final Map<String, String> dedupUp = new HashMap<>();
    private final Map<String, String> dedupDown = new HashMap<>();
    private final Map<String, Long> recentlyDoneUp = new HashMap<>();
    private final Map<String, String> lastStatus = new HashMap<>();
    private final LocalProxy proxy = new LocalProxy();
    private int activeCount = 0;
    private PowerManager.WakeLock wakeLock;
    private long wakeAt = 0;

    private static class Handle {
        volatile boolean cancel;
        volatile HttpURLConnection conn;
    }

    static TransferManager get(Context appCtx) {
        if (INSTANCE == null) {
            synchronized (TransferManager.class) {
                if (INSTANCE == null) INSTANCE = new TransferManager(appCtx.getApplicationContext());
            }
        }
        return INSTANCE;
    }

    private TransferManager(Context ctx) {
        this.ctx = ctx;
        PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
        if (pm != null) this.wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "cw:datacenter-transfers");
        this.proxy.setResolver(ctx.getContentResolver());
        this.proxy.start();
    }

    LocalProxy proxy() { return proxy; }

    void addSink(Consumer<String> sink) {
        synchronized (sinks) {
            if (!sinks.contains(sink)) sinks.add(sink);
        }
    }

    void removeSink(Consumer<String> sink) {
        synchronized (sinks) { sinks.remove(sink); }
    }

    int activeCount() {
        synchronized (this) { return activeCount; }
    }

    boolean hasActive() {
        return activeCount() > 0;
    }

    String describeActive() {
        synchronized (this) {
            if (activeCount <= 0) return "";
            String one = lastStatus.isEmpty() ? null : lastStatus.values().iterator().next();
            if (activeCount == 1 && one != null) return one;
            if (one != null) return one + " (+" + (activeCount - 1) + ")";
            return "Đang truyền tải " + activeCount + " mục…";
        }
    }

    private void activeInc() {
        boolean wasIdle;
        synchronized (this) { wasIdle = activeCount == 0; activeCount++; }
        if (wasIdle) syncService();
        keepWake();
    }

    private void activeDec() {
        boolean nowIdle;
        synchronized (this) { activeCount = Math.max(0, activeCount - 1); nowIdle = activeCount == 0; }
        if (nowIdle) {
            releaseWake();
            syncService();
        }
    }

    private void syncService() {
        try { TransferService.sync(ctx, activeCount()); } catch (Exception ignored) {}
    }

    private void keepWake() {
        try {
            if (wakeLock != null && activeCount() > 0) {
                long now = System.currentTimeMillis();
                if (!wakeLock.isHeld() || now - wakeAt > 60L * 60 * 1000) {
                    if (wakeLock.isHeld()) wakeLock.release();
                    wakeLock.acquire(2L * 60 * 60 * 1000);
                    wakeAt = now;
                }
            }
        } catch (Exception ignored) {}
    }

    private void releaseWake() {
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) {}
    }

    JSONObject startDownload(JSONObject spec) throws Exception {
        String url = spec.getString("url");
        String name = spec.optString("name", "download");
        String headersJson = spec.optString("headers", "");
        String destTreeUri = spec.optString("destTreeUri", "");
        String destSub = spec.optString("destSub", "");
        String destPath = spec.optString("destPath", "");
        boolean syncDest = spec.optBoolean("sync", false);
        synchronized (handles) {
            String existing = dedupDown.get(url);
            if (existing != null && handles.containsKey(existing)) {
                JSONObject r = new JSONObject();
                r.put("ok", true);
                r.put("id", existing);
                r.put("resumed", true);
                return r;
            }
        }
        String id = "dl-" + Math.abs((url + name).hashCode()) + "-" + System.currentTimeMillis() / 1000;
        Handle h = new Handle();
        synchronized (handles) {
            handles.put(id, h);
            dedupDown.put(url, id);
        }
        activeInc();
        executor.execute(() -> runDownload(h, id, url, name, headersJson, destTreeUri, destSub, destPath, syncDest));
        JSONObject r = new JSONObject();
        r.put("ok", true);
        r.put("id", id);
        return r;
    }

    private void runDownload(Handle h, String id, String url, String name, String headersJson, String destTreeUri, String destSub, String destPath, boolean syncDest) {
        File dir = new File(ctx.getFilesDir(), "downloads");
        dir.mkdirs();
        File target = new File(dir, safeName(name));
        File part = new File(dir, safeName(name) + ".part");
        long offset = 0;
        try {
            if (part.exists()) offset = part.length();
            long total = offset;
            InputStream is;
            if (url.startsWith("content://")) {
                if (offset > 0) { offset = 0; part.delete(); }
                Uri src = Uri.parse(url);
                is = ctx.getContentResolver().openInputStream(src);
                if (is == null) { fail(id, "down", name, "Không mở được tệp nguồn"); return; }
            } else if (url.startsWith("file:")) {
                if (offset > 0) { offset = 0; part.delete(); }
                java.io.File src = new java.io.File(java.net.URI.create(url));
                is = new FileInputStream(src);
            } else {
                HttpURLConnection conn = open(url, headersJson, h);
                if (offset > 0) conn.setRequestProperty("Range", "bytes=" + offset + "-");
                h.conn = conn;
                int status = conn.getResponseCode();
                if ((offset > 0 && status == 200) || status >= 400) {
                    if (status >= 400) {
                        fail(id, "down", name, "HTTP " + status + ": " + readErr(conn));
                        return;
                    }
                    offset = 0;
                    part.delete();
                }
                String cl = conn.getHeaderField("Content-Length");
                if (cl != null) {
                    try { total = offset + Long.parseLong(cl); } catch (Exception ignored) {}
                }
                is = conn.getInputStream();
            }
            FileOutputStream fos = new FileOutputStream(part, offset > 0);
            byte[] buf = new byte[1024 * 1024];
            long done = offset, lastEmit = System.currentTimeMillis(), bytesSince = 0;
            int n;
            while ((n = is.read(buf)) > 0) {
                if (h.cancel) {
                    fos.close();
                    emit(id, "down", name, "paused", done, total, 0, null);
                    return;
                }
                fos.write(buf, 0, n);
                done += n;
                bytesSince += n;
                long now = System.currentTimeMillis();
                if (now - lastEmit > 400) {
                    long speed = bytesSince * 1000 / Math.max(1, now - lastEmit);
                    bytesSince = 0;
                    lastEmit = now;
                    emit(id, "down", name, "active", done, total, speed, null);
                }
            }
            fos.close();
            is.close();
            if (!part.renameTo(target)) {
                copyStream(part, target);
                part.delete();
            }
            exportToLocation(target, destTreeUri, destSub, destPath, syncDest);
            emit(id, "down", name, "done", done, total, 0, target.getAbsolutePath());
        } catch (Exception e) {
            if (!h.cancel) fail(id, "down", name, String.valueOf(e.getMessage()));
        } finally {
            if (h.conn != null) h.conn.disconnect();
            synchronized (handles) {
                handles.remove(id);
                dedupDown.remove(url);
            }
            activeDec();
        }
    }

    private HttpURLConnection open(String url, String headersJson, Handle h) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(8000);
        conn.setReadTimeout(30000);
        if (headersJson != null && !headersJson.isEmpty()) {
            JSONObject hs = new JSONObject(headersJson);
            for (Iterator<String> it = hs.keys(); it.hasNext(); ) {
                String k = it.next();
                conn.setRequestProperty(k, hs.optString(k));
            }
        }
        return conn;
    }

    private Uri exportToDownloads(File f, boolean subCw) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, f.getName());
                cv.put(MediaStore.Downloads.SIZE, f.length());
                if (subCw) cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + File.separator + "CW-Datacenter");
                Uri uri = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) return Uri.fromFile(f);
                OutputStream os = ctx.getContentResolver().openOutputStream(uri);
                copyStream(f, os);
                os.close();
                return uri;
            } else {
                File pub = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (subCw) pub = new File(pub, "CW-Datacenter");
                pub.mkdirs();
                File dst = new File(pub, f.getName());
                if (dst.exists()) dst.delete();
                copyStream(f, dst);
                return Uri.fromFile(dst);
            }
        } catch (Exception e) {
            return Uri.fromFile(f);
        }
    }

    private Uri exportToLocation(File f, String destTreeUri, String destSub, String destPath, boolean cwDefault) {
        if (destPath != null && !destPath.trim().isEmpty()) {
            try {
                File dir = new File(destPath);
                if (destSub != null && !destSub.trim().isEmpty()) {
                    for (String seg : destSub.replace('\\', '/').split("/")) {
                        String s = seg.trim();
                        if (s.isEmpty() || s.equals(".")) continue;
                        dir = new File(dir, s);
                    }
                }
                if (!dir.isDirectory()) dir.mkdirs();
                if (dir.isDirectory()) {
                    java.util.List<String> srcs = new ArrayList<>();
                    srcs.add(f.getAbsolutePath());
                    LocalFiles.moveItems(srcs, dir.getAbsolutePath(), false);
                    return Uri.fromFile(new File(dir, f.getName()));
                }
            } catch (Exception ignored) {}
            return exportToDownloads(f, cwDefault);
        }
        if (destTreeUri == null || destTreeUri.trim().isEmpty()) {
            return exportToDownloads(f, cwDefault);
        }
        try {
            ContentResolver cr = ctx.getContentResolver();
            Uri tree = Uri.parse(destTreeUri);
            Uri dir = ensureTreeSubDirs(cr, tree, destSub);
            if (dir == null) return exportToDownloads(f, cwDefault);
            Uri doc = findChildDoc(cr, dir, f.getName());
            if (doc != null) {
                try { DocumentsContract.deleteDocument(cr, doc); } catch (Exception ignored) {}
                doc = null;
            }
            doc = DocumentsContract.createDocument(cr, dir, guessMime(f.getName()), f.getName());
            if (doc == null) return exportToDownloads(f, cwDefault);
            OutputStream os = cr.openOutputStream(doc, "wt");
            copyStream(f, os);
            os.close();
            return doc;
        } catch (Exception e) {
            return exportToDownloads(f, cwDefault);
        }
    }

    private Uri ensureTreeSubDirs(ContentResolver cr, Uri tree, String destSub) {
        try {
            Uri dir = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
            if (destSub == null || destSub.trim().isEmpty()) return dir;
            String[] segs = destSub.replace('\\', '/').split("/");
            for (String seg : segs) {
                String s = seg.trim();
                if (s.isEmpty() || s.equals(".")) continue;
                Uri child = findChildDoc(cr, dir, s);
                if (child == null) {
                    child = DocumentsContract.createDocument(cr, dir, DocumentsContract.Document.MIME_TYPE_DIR, s);
                }
                if (child == null) return null;
                dir = child;
            }
            return dir;
        } catch (Exception e) {
            return null;
        }
    }

    private Uri findChildDoc(ContentResolver cr, Uri dirUri, String name) {
        try {
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(dirUri, DocumentsContract.getDocumentId(dirUri));
            try (Cursor c = cr.query(children,
                    new String[]{ DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME },
                    null, null, null)) {
                if (c != null) {
                    while (c.moveToNext()) {
                        if (name.equals(c.getString(1))) {
                            return DocumentsContract.buildDocumentUriUsingTree(dirUri, c.getString(0));
                        }
                    }
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void copyStream(File src, File dst) throws Exception {
        copyStream(src, new FileOutputStream(dst));
    }

    private void copyStream(File src, OutputStream os) throws Exception {
        FileInputStream fis = new FileInputStream(src);
        byte[] buf = new byte[256 * 1024];
        int n;
        while ((n = fis.read(buf)) > 0) os.write(buf, 0, n);
        fis.close();
        if (os instanceof FileOutputStream) os.close();
        else os.flush();
    }

    JSONObject startUpload(JSONObject spec) throws Exception {
        String baseUrl = spec.getString("baseUrl");
        String token = spec.getString("token");
        String poolId = spec.optString("pool", "main");
        String path = spec.getString("path");
        String name = spec.getString("name");
        String file = spec.optString("file", "");
        Uri uri0 = null;
        String uriKey;
        if (file != null && !file.isEmpty()) {
            uriKey = "file:" + file;
        } else {
            uri0 = Uri.parse(spec.getString("uri"));
            uriKey = String.valueOf(uri0);
        }
        final Uri uri = uri0;
        String headersJson = spec.optString("headers", "");
        String dedupKey = poolId + "\u0000" + path + "\u0000" + uriKey;
        synchronized (handles) {
            Long doneTs = recentlyDoneUp.get(dedupKey);
            long now = System.currentTimeMillis();
            if (doneTs != null && now - doneTs < 10L * 60 * 1000) {
                JSONObject r = new JSONObject();
                r.put("ok", true);
                r.put("done", true);
                return r;
            }
            String existing = dedupUp.get(dedupKey);
            if (existing != null && handles.containsKey(existing)) {
                JSONObject r = new JSONObject();
                r.put("ok", true);
                r.put("id", existing);
                r.put("resumed", true);
                return r;
            }
        }
        String id = "ul-" + Math.abs((path + uriKey).hashCode()) + "-" + System.currentTimeMillis() / 1000;
        Handle h = new Handle();
        synchronized (handles) {
            handles.put(id, h);
            dedupUp.put(dedupKey, id);
        }
        activeInc();
        executor.execute(() -> runUpload(h, id, dedupKey, baseUrl, token, poolId, path, name, uri, file, headersJson));
        JSONObject r = new JSONObject();
        r.put("ok", true);
        r.put("id", id);
        return r;
    }

    private static class UpState {
        String uploadId;
        long offset;
        UpState(String uploadId, long offset) { this.uploadId = uploadId; this.offset = offset; }
    }

    private static class ChunkReader {
        volatile Thread t;
        final AtomicBoolean done = new AtomicBoolean(false);
        ChunkReader(Thread t) { this.t = t; }
        void setThread(Thread t) { this.t = t; }
        void stop() { if (t != null) t.interrupt(); }
    }

    private ChunkReader spawnChunkReader(final FileChannel ch, final long size, final long startOffset,
                                         final ArrayBlockingQueue<byte[]> q, final Handle h) {
        final ChunkReader r = new ChunkReader(null);
        Thread t = new Thread(() -> {
            long off = startOffset;
            try {
                while (off < size && !h.cancel) {
                    int want = (int) Math.min(CHUNK, size - off);
                    byte[] data = new byte[want];
                    ByteBuffer bb = ByteBuffer.wrap(data);
                    while (bb.hasRemaining()) {
                        int n = ch.read(bb, off + bb.position());
                        if (n < 0) break;
                    }
                    int got = bb.position();
                    if (got <= 0) break;
                    if (got < want) data = Arrays.copyOf(data, got);
                    while (!q.offer(data, 300, TimeUnit.MILLISECONDS)) {
                        if (h.cancel) return;
                    }
                    off += got;
                }
            } catch (InterruptedException ignored) {
            } catch (Exception ignored) {
            } finally {
                r.done.set(true);
            }
        }, "cw-upload-read");
        t.setDaemon(true);
        r.setThread(t);
        t.start();
        return r;
    }

    private void runUpload(Handle h, String id, String dedupKey, String baseUrl, String token, String poolId, String rel, String name, Uri uri, String file, String extraHeaders) {
        FileInputStream fis = null;
        FileChannel ch = null;
        ChunkReader reader = null;
        ParcelFileDescriptor pfd = null;
        try {
            if (file != null && !file.isEmpty()) {
                pfd = ParcelFileDescriptor.open(new File(file), ParcelFileDescriptor.MODE_READ_ONLY);
            } else if (uri != null) {
                pfd = ctx.getContentResolver().openFileDescriptor(uri, "r");
            }
            if (pfd == null) { fail(id, "up", name, "Không mở được tệp."); return; }
            fis = new FileInputStream(pfd.getFileDescriptor());
            ch = fis.getChannel();
            final long size = ch.size();

            JSONObject initBody = new JSONObject();
            initBody.put("pool", poolId);
            initBody.put("path", rel);
            initBody.put("size", size);
            JSONObject init = postJson(baseUrl + "/api/upload/init", token, initBody.toString(), h);
            if (init == null) { fail(id, "up", name, "Không khởi tạo được upload."); return; }
            UpState st = new UpState(init.optString("uploadId"), init.optLong("offset", 0));

            emit(id, "up", name, "active", st.offset, size, 0, null);
            long lastEmit = System.currentTimeMillis(), bytesSince = 0;

            final ArrayBlockingQueue<byte[]> q = new ArrayBlockingQueue<>(3);
            final FileChannel fch = ch;
            reader = spawnChunkReader(fch, size, st.offset, q, h);

            while (st.offset < size) {
                if (h.cancel) {
                    reader.stop();
                    emit(id, "up", name, "paused", st.offset, size, 0, null);
                    return;
                }
                byte[] data = q.poll(250, TimeUnit.MILLISECONDS);
                if (data == null) {
                    if (reader.done.get() && q.isEmpty()) {
                        if (st.offset >= size) break;
                        fail(id, "up", name, "Không đọc được dữ liệu tệp.");
                        return;
                    }
                    continue;
                }
                boolean recovered = false;
                boolean ok = false;
                int attempt = 0;
                while (attempt < 4 && !h.cancel) {
                    attempt++;
                    HttpURLConnection conn = null;
                    try {
                        conn = (HttpURLConnection) new URL(baseUrl + "/api/upload/chunk?id=" + st.uploadId + "&offset=" + st.offset).openConnection();
                        conn.setRequestMethod("POST");
                        conn.setRequestProperty("Authorization", "Bearer " + token);
                        conn.setRequestProperty("Content-Type", "application/octet-stream");
                        conn.setConnectTimeout(8000);
                        conn.setReadTimeout(60000);
                        conn.setDoOutput(true);
                        conn.setFixedLengthStreamingMode(data.length);
                        h.conn = conn;
                        OutputStream os = conn.getOutputStream();
                        os.write(data);
                        os.flush();
                        os.close();
                        int status = conn.getResponseCode();
                        String text = readBody(conn, status);
                        if (status == 200) {
                            JSONObject o = new JSONObject(text);
                            st.offset = o.optLong("offset", st.offset + data.length);
                            ok = true;
                            break;
                        }
                        if (status == 409 || status == 404) {
                            reader.stop();
                            q.clear();
                            UpState st2 = recoverUploadSession(baseUrl, token, poolId, rel, size, initBody, h);
                            if (st2 == null) { fail(id, "up", name, "Server khởi động lại, thử lại thất bại."); return; }
                            st = st2;
                            reader = spawnChunkReader(fch, size, st.offset, q, h);
                            recovered = true;
                            break;
                        }
                        fail(id, "up", name, "HTTP " + status + ": " + text);
                        return;
                    } catch (Exception e) {
                        if (attempt >= 4) { fail(id, "up", name, "Mất kết nối khi tải lên."); return; }
                        try { Thread.sleep(400L * attempt); } catch (InterruptedException ignored) {}
                    }
                }
                if (h.cancel) {
                    reader.stop();
                    emit(id, "up", name, "paused", st.offset, size, 0, null);
                    return;
                }
                if (recovered) continue;
                if (!ok) { fail(id, "up", name, "Mất kết nối khi tải lên."); return; }
                bytesSince += data.length;
                long now = System.currentTimeMillis();
                if (now - lastEmit > 400) {
                    long speed = bytesSince * 1000 / Math.max(1, now - lastEmit);
                    bytesSince = 0;
                    lastEmit = now;
                    emit(id, "up", name, "active", st.offset, size, speed, null);
                }
                keepWake();
            }

            JSONObject doneBody = new JSONObject();
            doneBody.put("uploadId", st.uploadId);
            JSONObject done = postJson(baseUrl + "/api/upload/complete", token, doneBody.toString(), h);
            if (done == null) { fail(id, "up", name, "Hoàn tất upload thất bại."); return; }
            emit(id, "up", name, "done", size, size, 0, done.optString("rel", rel));
            synchronized (handles) { recentlyDoneUp.put(dedupKey, System.currentTimeMillis()); }
        } catch (Exception e) {
            if (!h.cancel) fail(id, "up", name, String.valueOf(e.getMessage()));
        } finally {
            if (reader != null) reader.stop();
            try { if (ch != null) ch.close(); } catch (Exception ignored) {}
            try { if (fis != null) fis.close(); } catch (Exception ignored) {}
            try { if (pfd != null) pfd.close(); } catch (Exception ignored) {}
            synchronized (handles) {
                handles.remove(id);
                dedupUp.remove(dedupKey);
            }
            activeDec();
        }
    }

    private UpState recoverUploadSession(String baseUrl, String token, String poolId, String rel, long size, JSONObject initBody, Handle h) {
        try {
            JSONObject stJson = getJson(baseUrl + "/api/upload/status?path=" + java.net.URLEncoder.encode(rel, "UTF-8") + "&pool=" + java.net.URLEncoder.encode(poolId, "UTF-8") + "&size=" + size, token, h);
            if (stJson != null && stJson.optString("uploadId") != null && !stJson.isNull("uploadId") && !"".equals(stJson.optString("uploadId"))) {
                return new UpState(stJson.optString("uploadId"), stJson.optLong("offset", 0));
            }
            JSONObject init = postJson(baseUrl + "/api/upload/init", token, initBody.toString(), h);
            if (init == null) return null;
            return new UpState(init.optString("uploadId"), init.optLong("offset", 0));
        } catch (Exception e) {
            return null;
        }
    }

    private JSONObject postJson(String url, String token, String body, Handle h) {
        try {
            HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Authorization", "Bearer " + token);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(20000);
            conn.setDoOutput(true);
            byte[] data = body.getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(data.length);
            h.conn = conn;
            OutputStream os = conn.getOutputStream();
            os.write(data);
            os.flush();
            os.close();
            int status = conn.getResponseCode();
            String text = readBody(conn, status);
            if (status < 200 || status >= 300) return null;
            return new JSONObject(text);
        } catch (Exception e) {
            return null;
        }
    }

    private JSONObject getJson(String url, String token, Handle h) {
        try {
            HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setRequestProperty("Authorization", "Bearer " + token);
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(20000);
            h.conn = conn;
            int status = conn.getResponseCode();
            String text = readBody(conn, status);
            if (status < 200 || status >= 300) return null;
            return new JSONObject(text);
        } catch (Exception e) {
            return null;
        }
    }

    void cancel(String id) {
        Handle h;
        synchronized (handles) { h = handles.get(id); }
        if (h == null) return;
        h.cancel = true;
        if (h.conn != null) h.conn.disconnect();
    }

    void cancelAll() {
        List<Handle> all;
        synchronized (handles) { all = new ArrayList<>(handles.values()); }
        for (Handle h : all) {
            h.cancel = true;
            if (h.conn != null) h.conn.disconnect();
        }
    }

    private void emit(String id, String dir, String name, String status, long done, long total, long speed, String path) {
        try {
            JSONObject e = new JSONObject();
            e.put("type", "transfer");
            e.put("id", id);
            e.put("dir", dir);
            e.put("name", name);
            e.put("status", status);
            e.put("done", done);
            e.put("total", total);
            e.put("speed", speed);
            if (path != null) e.put("path", path);
            String json = e.toString();
            synchronized (this) {
                if ("active".equals(status)) {
                    int pc = total > 0 ? (int) (done * 100 / total) : 0;
                    lastStatus.put(id, ("up".equals(dir) ? "Đang tải lên \"" : "Đang tải xuống \"") + name + "\" · " + pc + "%");
                } else if ("done".equals(status) || "error".equals(status) || "paused".equals(status)) {
                    lastStatus.remove(id);
                }
            }
            List<Consumer<String>> copy;
            synchronized (sinks) { copy = new ArrayList<>(sinks); }
            for (Consumer<String> s : copy) {
                try { s.accept(json); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    private void fail(String id, String dir, String name, String err) {
        emitError(id, dir, name, err == null ? "Lỗi mạng" : err);
    }

    private void emitError(String id, String dir, String name, String err) {
        try {
            JSONObject e = new JSONObject();
            e.put("type", "transfer");
            e.put("id", id);
            e.put("dir", dir);
            e.put("name", name);
            e.put("status", "error");
            e.put("err", err);
            String json = e.toString();
            synchronized (this) { lastStatus.remove(id); }
            List<Consumer<String>> copy;
            synchronized (sinks) { copy = new ArrayList<>(sinks); }
            for (Consumer<String> s : copy) {
                try { s.accept(json); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    private String readBody(HttpURLConnection conn, int status) throws Exception {
        InputStream is = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (is == null) return "";
        byte[] b = readAll(is);
        return new String(b, StandardCharsets.UTF_8);
    }

    private String readErr(HttpURLConnection conn) {
        try { return readBody(conn, 500); } catch (Exception e) { return ""; }
    }

    private static byte[] readAll(InputStream is) throws Exception {
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
        is.close();
        return bos.toByteArray();
    }

    private static String safeName(String name) {
        String n = name.replace('\\', '_').replace('/', '_').replace(':', '_');
        if (n.isEmpty()) n = "file";
        return n;
    }

    static String guessMime(String nameOrPath) {
        String n = nameOrPath == null ? "" : nameOrPath.toLowerCase();
        int i = n.lastIndexOf('.');
        String ext = i >= 0 ? n.substring(i) : "";
        switch (ext) {
            case ".pdf": return "application/pdf";
            case ".mp4": case ".m4v": return "video/mp4";
            case ".mkv": return "video/x-matroska";
            case ".webm": return "video/webm";
            case ".mov": return "video/quicktime";
            case ".avi": return "video/x-msvideo";
            case ".3gp": case ".3gpp": return "video/3gpp";
            case ".3g2": return "video/3gpp2";
            case ".flv": return "video/x-flv";
            case ".wmv": return "video/x-ms-wmv";
            case ".mpg": case ".mpeg": return "video/mpeg";
            case ".ts": case ".m2ts": case ".mts": return "video/mp2t";
            case ".ogv": return "video/ogg";
            case ".vob": return "video/x-ms-vob";
            case ".rm": case ".rmvb": return "application/vnd.rn-realmedia-vbr";
            case ".mp3": return "audio/mpeg";
            case ".m4a": return "audio/mp4";
            case ".wav": return "audio/wav";
            case ".flac": return "audio/flac";
            case ".ogg": return "audio/ogg";
            case ".aac": return "audio/aac";
            case ".png": return "image/png";
            case ".jpg": case ".jpeg": return "image/jpeg";
            case ".gif": return "image/gif";
            case ".webp": return "image/webp";
            case ".bmp": return "image/bmp";
            case ".avif": return "image/avif";
            case ".svg": return "image/svg+xml";
            case ".txt": case ".md": case ".log": return "text/plain";
            case ".html": return "text/html";
            case ".zip": return "application/zip";
            default: return "application/octet-stream";
        }
    }
}

