﻿@echo off
chcp 65001 >nul
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Dang yeu cau quyen Administrator de mo Tuong lua...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process '%~dpnx0' -Verb RunAs"
    exit /b
)

echo =======================================================
echo   DANG MO TUONG LUA WINDOWS CHO CW DATACENTER
echo =======================================================
echo.

set PORT=8080
if not "%1"=="" set PORT=%1

echo [1/4] Xoa cac quy tac Tuong lua cu...
netsh advfirewall firewall delete rule name="CW Datacenter Host" >nul 2>&1
netsh advfirewall firewall delete rule name="CW Datacenter Host (TCP 8080)" >nul 2>&1
netsh advfirewall firewall delete rule name="CW Datacenter Host (TCP %PORT%)" >nul 2>&1
netsh advfirewall firewall delete rule name="CW Datacenter Discovery (UDP 46631)" >nul 2>&1
netsh advfirewall firewall delete rule name="CW Datacenter Host Outbound" >nul 2>&1

echo [2/4] Mo cong TCP %PORT% (cho phep tat ca may LAN ket noi)...
netsh advfirewall firewall add rule name="CW Datacenter Host (TCP %PORT%)" dir=in action=allow protocol=TCP localport=%PORT% profile=any enable=yes

echo [3/4] Mo cong UDP 46631 (tu dong do tim may chu trong LAN/Wifi)...
netsh advfirewall firewall add rule name="CW Datacenter Discovery (UDP 46631)" dir=in action=allow protocol=UDP localport=46631 profile=any enable=yes

echo [4/4] Bat tinh nang Do tim mang (Network Discovery)...
netsh advfirewall firewall set rule group="Network Discovery" new enable=Yes >nul 2>&1
netsh advfirewall firewall set rule group="Dò tìm Mạng" new enable=Yes >nul 2>&1

echo.
echo =======================================================
echo   DA MO TUONG LUA WINDOWS THANH CONG!
echo   Cac thiet bi khac da co the ket noi toi may chu.
echo =======================================================
echo.
timeout /t 4
