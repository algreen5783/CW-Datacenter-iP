@echo off
title Home Datacenter - Desktop Client
cd /d "%~dp0desktop"
if not exist "node_modules\electron" (
  echo [!] Electron chua duoc cai. Dang cai dat lan dau (mat 1-3 phut)...
  set PATH=%~dp0.tools\node;%PATH%
  call npm install --no-fund --no-audit
  if errorlevel 1 (
    echo [LOI] Cai dat Electron that bai. Kiem tra ket noi mang.
    pause
    exit /b 1
  )
)
start "" "node_modules\.bin\electron.cmd" .
