/* CW Datacenter Android Tablet client - app.js
 * Phiên bản hoàn chỉnh cho Tablet (v3):
 * - Đầy đủ tính năng: Video player (ExoPlayer qua Proxy nội bộ + VLC direct), Photo viewer, PDF viewer
 * - Yêu thích (Favorites)
 * - Copy / Cut / Paste (Clipboard)
 * - Nhấn giữ để chọn nhiều tệp (Multi-selection mode)
 * - Đổi tên tệp / thư mục qua Modal Popup căn giữa & API chuẩn
 * - Khóa mật khẩu ổ đĩa / thư mục / tệp (ĐỒNG BỘ 2 CHIỀU VỚI MÁY CHỦ HOST & MOBILE)
 * - Chia sẻ link qua Modal Popup căn giữa (Copy link tải + Chia sẻ qua ứng dụng thứ 3)
 * - Tạo thư mục mới qua Modal Popup căn giữa
 * - Đồng bộ tệp & ảnh camera (Sync)
 * - Popup chọn máy chủ có nút X đóng + Lưu mật khẩu đăng nhập & Tự động đăng nhập
 * - Hiển thị ổ đĩa ngay khi đăng nhập
 * - Hỗ trợ bố cục 2 cột chuyên dụng Tablet (Landscape / Portrait)
 */
(() => {
'use strict';

const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const enc = encodeURIComponent;

function showOldApkNotice() {
  const d = document.createElement('div');
  d.style.cssText = 'position:fixed;inset:0;z-index:9999;background:#fff;display:flex;'
    + 'flex-direction:column;align-items:center;justify-content:center;text-align:center;'
    + 'padding:32px;gap:14px;font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:#111827;';
  d.innerHTML = '<div style="font-size:40px;line-height:1">⚠️</div>'
    + '<div style="font-size:18px;font-weight:600">APK cũ, hãy cài lại bản mới</div>'
    + '<div style="font-size:13.5px;color:#667085;line-height:1.6;max-width:320px">'
    + 'Phiên bản ứng dụng trên máy không khớp với giao diện này. '
    + 'Hãy gỡ và cài lại file APK mới nhất của CW Datacenter.</div>';
  (document.body || document.documentElement).appendChild(d);
}
if (!window.DC || typeof DC.call !== 'function') {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', showOldApkNotice);
  else showOldApkNotice();
  throw new Error('APK cũ: thiếu cầu nối DC.call');
}

const META = JSON.parse(DC.getMeta() || '{}');
const HOST = (META.manufacturer || '') + ' ' + (META.device || '');

/* ---------- Native bridge plumbing ---------- */
const cbs = new Map();
let cbSeq = 0;
function callNative(method, ...args) {
  return new Promise((res, rej) => {
    const id = String(++cbSeq);
    cbs.set(id, { res, rej });
    try { DC.call(method, id, JSON.stringify(args)); } catch (e) { cbs.delete(id); rej(String(e)); }
  });
}
DC._cb = (id, ok, jsonStr) => {
  const c = cbs.get(id); if (!c) return; cbs.delete(id);
  let data = null;
  if (typeof jsonStr === 'object' && jsonStr !== null) data = jsonStr;
  else { try { data = jsonStr ? JSON.parse(jsonStr) : {}; } catch (e) {} }
  ok ? c.res(data) : c.rej((data && data.err) || 'Lỗi');
};
DC._evt = (arg) => {
  try {
    const obj = typeof arg === 'string' ? JSON.parse(arg) : arg;
    if (obj) onNativeEvent(obj);
  } catch (e) {}
};
DC._back = () => handleBack();
DC._insets = (top, bottom) => {
  const root = document.documentElement;
  root.style.setProperty('--sat', Math.max(0, top | 0) + 'px');
  root.style.setProperty('--sab', Math.max(0, bottom | 0) + 'px');
};
document.addEventListener('selectstart', (e) => {
  const t = e.target;
  if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) return;
  e.preventDefault();
});
try {
  const ins = String(DC.getInsets() || '').split(',');
  if (ins.length === 2) DC._insets(parseInt(ins[0], 10), parseInt(ins[1], 10));
} catch (e) {}

/* ---------- State ---------- */
let server = null;               // {name, host, ip, port, baseUrl, via}
let token = null;
let me = null;                   // {role, user}
let pools = [];
let pool = 'main';
let currentPath = '';
let parentPath = null;
let entries = [];
let currentView = 'files';
let sortMode = 'name';
let searchQuery = '';
let transfers = {};
let favs = [];
let syncDb = {};
let dlPaths = {};
let syncPaused = false;
let camOn = false;
let lockMap = null;
const lockSession = new Set();
let clipboard = { items: [], mode: '', dir: '' };
let selectedEntry = null;        // Mục đang hiển thị trên Detail Pane
let selMode = false;             // Chế độ chọn nhiều
let selectedSet = new Set();     // Tập hợp tên các mục được tích chọn
let lpTimer = null;
let lpSuppressClick = false;
let pendingResumeVideo = null;
let pendingUnlockTarget = null;
let pendingConfirmAction = null;
let pendingRenameTarget = null;
let pendingLockTarget = null;
let pendingShareTarget = null;
const LOCAL_POOL = 'thisdevice';

const kvGet = (k) => { const v = DC.loadKV(k); try { return v ? JSON.parse(v) : null; } catch (e) { return v; } };
const kvSet = (k, v) => DC.saveKV(k, JSON.stringify(v));

function kFavs() { return 'favs:' + (server ? server.baseUrl : ''); }
function kSync() { return 'sync:' + (server ? server.baseUrl : ''); }
function kDlPaths() { return 'dl:' + (server ? server.baseUrl : ''); }
function kToken() { return 'token:' + (server ? server.baseUrl : ''); }
function kCreds() { return 'creds:' + (server ? server.baseUrl : ''); }
function kLocks() { return 'locks:' + (server ? server.baseUrl : ''); }

/* ---------- Utilities ---------- */
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function fmtBytes(b) {
  if (b == null || b < 0 || isNaN(b)) return '';
  const num = Number(b);
  if (num < 1024) return num + ' B';
  if (num < 1024 * 1024) return (num / 1024).toFixed(1) + ' KB';
  if (num < 1024 * 1024 * 1024) return (num / (1024 * 1024)).toFixed(1) + ' MB';
  return (num / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
}

function fmtSpeed(bytesPerSec) {
  if (!bytesPerSec || bytesPerSec <= 0) return '0 B/s';
  return fmtBytes(bytesPerSec) + '/s';
}

function fmtDate(iso) {
  if (!iso) return '';
  try {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return '';
    const p = (n) => (n < 10 ? '0' + n : '' + n);
    return `${p(d.getHours())}:${p(d.getMinutes())} ${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()}`;
  } catch (e) { return ''; }
}

function toast(msg) {
  const t = document.getElementById('tvToast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('show'), 2600);
}

const VIDEO_EXT = ['mp4', 'mkv', 'mov', 'webm', 'avi', 'm4v', '3gp', '3gpp', 'flv', 'wmv', 'mpg', 'mpeg', 'ts', 'm2ts', 'mts', 'ogv', 'rm', 'rmvb'];
const AUDIO_EXT = ['mp3', 'm4a', 'wav', 'flac', 'aac', 'ogg', 'wma'];
const IMAGE_EXT = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'heic', 'svg'];

function isVideoFile(name) { return VIDEO_EXT.includes(String(name || '').split('.').pop().toLowerCase()); }
function isAudioFile(name) { return AUDIO_EXT.includes(String(name || '').split('.').pop().toLowerCase()); }
function isImageFile(name) { return IMAGE_EXT.includes(String(name || '').split('.').pop().toLowerCase()); }
function isPdfFile(name) { return String(name || '').toLowerCase().endsWith('.pdf'); }

function relOf(e) { return (currentPath ? currentPath + '/' : '') + e.name; }
function canWrite() { return !!server && (me ? me.role === 'admin' || me.role === 'editor' : true); }
function poolById(id) { return pools.find((p) => p.id === id) || null; }
function poolNameOf(id) { const p = poolById(id); return p ? p.name : (id || 'Ổ chính'); }

/* ---------- SHA256 & Security ---------- */
function sha256js(s) {
  const K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  const rr = (v, n) => (v >>> n) | (v << (32 - n));
  const H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
  const bytes = new TextEncoder().encode(s);
  const l = bytes.length, bitLen = l * 8;
  const wordCount = (((l + 9) + 63) >>> 6) * 16;
  const words = new Uint32Array(wordCount);
  for (let i = 0; i < l; i++) words[i >>> 2] |= bytes[i] << (24 - (i % 4) * 8);
  words[l >>> 2] |= 0x80 << (24 - (l % 4) * 8);
  words[wordCount - 1] = bitLen;
  const W = new Uint32Array(64);
  for (let i = 0; i < wordCount; i += 16) {
    for (let t = 0; t < 16; t++) W[t] = words[i + t];
    for (let t = 16; t < 64; t++) {
      const s0 = rr(W[t - 15], 7) ^ rr(W[t - 15], 18) ^ (W[t - 15] >>> 3);
      const s1 = rr(W[t - 2], 17) ^ rr(W[t - 2], 19) ^ (W[t - 2] >>> 10);
      W[t] = (W[t - 16] + s0 + W[t - 7] + s1) >>> 0;
    }
    let [a, b, c, d, e, f, g, h] = H;
    for (let t = 0; t < 64; t++) {
      const S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25);
      const ch = (e & f) ^ (~e & g);
      const t1 = (h + S1 + ch + K[t] + W[t]) >>> 0;
      const S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const t2 = (S0 + maj) >>> 0;
      h = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
    }
    H[0] = (H[0] + a) >>> 0; H[1] = (H[1] + b) >>> 0; H[2] = (H[2] + c) >>> 0; H[3] = (H[3] + d) >>> 0;
    H[4] = (H[4] + e) >>> 0; H[5] = (H[5] + f) >>> 0; H[6] = (H[6] + g) >>> 0; H[7] = (H[7] + h) >>> 0;
  }
  return H.map((v) => v.toString(16).padStart(8, '0')).join('');
}

/* ---------- LOCKS MANAGEMENT (ĐỒNG BỘ 2 CHIỀU VỚI HOST) ---------- */
function ensureLockMap() { if (!lockMap) lockMap = kvGet(kLocks()) || {}; return lockMap; }
function saveLockMap() { kvSet(kLocks(), lockMap || {}); }
function lockKeyOf(p, dirRel, name) { return (server ? server.baseUrl : '') + '|' + (p || 'main') + '|' + (dirRel ? dirRel + '/' : '') + name; }
function poolLockKey(p) { return (server ? server.baseUrl : '') + '|pool:' + (p || 'main') + '|'; }
function lockKeyFor(f) { return lockKeyOf(f.pool || pool, f.dirRel != null ? f.dirRel : currentPath, f.name); }

function isLocked(f) {
  const k = lockKeyFor(f);
  const map = ensureLockMap();
  return !!(map[k] && !lockSession.has(k));
}
function hasLockHash(f) {
  const k = lockKeyFor(f);
  return !!ensureLockMap()[k];
}

async function syncLocksFromServer() {
  if (!server || !token) return;
  try {
    const data = await api('/api/locks', 'GET');
    const serverLocks = (data && data.locks) || [];
    const map = {};
    for (const l of serverLocks) {
      if (l.type === 'drive') {
        map[poolLockKey(l.pool)] = l.hash;
      } else {
        const p = (l.path || '').replace(/^\/+/, '');
        const dir = p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : '';
        const nm = p.includes('/') ? p.slice(p.lastIndexOf('/') + 1) : p;
        map[lockKeyOf(l.pool || 'main', dir, nm)] = l.hash;
      }
    }
    lockMap = map;
    saveLockMap();
    renderFileGrid();
  } catch (e) {}
}

function promptUnlock(target, onOk) {
  pendingUnlockTarget = { target, onOk };
  const overlay = $('#unlockOverlay');
  const title = $('#unlockTitle');
  const sub = $('#unlockSub');
  const input = $('#unlockPasswordInput');
  const err = $('#unlockErr');

  if (title) title.textContent = 'Mở khóa "' + target.name + '"';
  if (sub) sub.textContent = 'Mục này đang được bảo vệ bằng mật khẩu';
  if (input) { input.value = ''; input.type = 'password'; }
  if (err) err.textContent = '';
  if (overlay) overlay.classList.add('open');
  setTimeout(() => { if (input) input.focus(); }, 80);
}

async function submitUnlock() {
  if (!pendingUnlockTarget) return;
  const input = $('#unlockPasswordInput');
  const err = $('#unlockErr');
  const pwd = (input ? input.value : '').trim();
  if (!pwd) { if (err) err.textContent = 'Vui lòng nhập mật khẩu'; return; }

  const e = pendingUnlockTarget.target;
  const k = lockKeyFor(e);
  let ok = false;

  // 1. Thử xác thực trực tiếp qua API Server Host
  try {
    const res = await api('/api/locks/verify', 'POST', {
      pool: e.pool || pool,
      path: relOf(e),
      type: e.type === 'dir' ? 'folder' : 'file',
      password: pwd
    });
    if (res && res.ok && res.verified) ok = true;
  } catch (er) {}

  // 2. Kiểm tra với hash đã lưu cục bộ
  if (!ok) {
    const stored = ensureLockMap()[k];
    const hash = sha256js(pwd);
    if (stored && (hash === stored || pwd === stored)) ok = true;
  }

  if (!ok) {
    if (err) err.textContent = 'Mật khẩu không đúng';
    return;
  }

  lockSession.add(k);
  $('#unlockOverlay').classList.remove('open');
  const { onOk } = pendingUnlockTarget;
  pendingUnlockTarget = null;
  if (onOk) onOk();
  renderFileGrid();
}

function lockEntryWithPassword(e) {
  pendingLockTarget = e;
  const overlay = $('#lockModalOverlay');
  const title = $('#lockModalTitle');
  const sub = $('#lockModalSub');
  const input = $('#lockModalPasswordInput');
  const err = $('#lockModalErr');

  if (title) title.textContent = 'Khóa "' + e.name + '" bằng Mật khẩu';
  if (sub) sub.textContent = 'Thiết lập mật khẩu bảo vệ (đồng bộ lên Máy chủ Host & Mobile)';
  if (input) { input.value = ''; input.type = 'password'; }
  if (err) err.textContent = '';
  if (overlay) overlay.classList.add('open');
  setTimeout(() => { if (input) input.focus(); }, 80);
}

async function submitLock() {
  if (!pendingLockTarget) return;
  const input = $('#lockModalPasswordInput');
  const err = $('#lockModalErr');
  const pw = (input ? input.value : '').trim();
  if (pw.length < 3) { if (err) err.textContent = 'Mật khẩu tối thiểu 3 ký tự'; return; }

  const e = pendingLockTarget;
  const hash = sha256js(pw);

  // 1. Đồng bộ lên Server Host
  try {
    await api('/api/locks', 'POST', {
      pool: e.pool || pool,
      path: relOf(e),
      type: e.type === 'dir' ? 'folder' : 'file',
      name: e.name,
      password: pw
    });
  } catch (er) {}

  // 2. Lưu vào KV cục bộ
  ensureLockMap()[lockKeyFor(e)] = hash;
  saveLockMap();
  lockSession.delete(lockKeyFor(e));

  $('#lockModalOverlay').classList.remove('open');
  pendingLockTarget = null;
  toast('Đã khóa: ' + e.name);
  renderFileGrid();
  renderDetailPane();
  await syncLocksFromServer();
}

function unlockEntryPermanently(e) {
  sheetConfirm('Gỡ khóa mật khẩu?', `Bạn có muốn gỡ bỏ bảo vệ mật khẩu cho "${e.name}" (đồng bộ lên Máy chủ Host & Mobile)?`, 'Gỡ khóa', async () => {
    try {
      await api('/api/locks', 'DELETE', {
        pool: e.pool || pool,
        path: relOf(e),
        type: e.type === 'dir' ? 'folder' : 'file'
      });
    } catch (er) {}
    delete ensureLockMap()[lockKeyFor(e)];
    saveLockMap();
    lockSession.delete(lockKeyFor(e));
    toast('Đã gỡ khóa: ' + e.name);
    renderFileGrid();
    renderDetailPane();
    await syncLocksFromServer();
  });
}

/* ---------- HTTP / API ---------- */
async function api(path, method, body) {
  if (!server || !token) throw new Error('Chưa kết nối máy chủ');
  const headers = { Authorization: 'Bearer ' + token };
  const r = await callNative('invoke', method || 'GET', server.baseUrl + path, JSON.stringify(headers), body ? JSON.stringify(body) : '');
  let data;
  try { data = r.text ? JSON.parse(r.text) : {}; } catch (e) { data = { error: 'Phản hồi không hợp lệ' }; }
  if (r.status === 401) { onSessionLost(); throw data; }
  if (r.status >= 400) throw data;
  return data;
}

async function tryApi(baseUrl, path, method, body, tk) {
  const headers = tk ? { Authorization: 'Bearer ' + tk } : {};
  const r = await callNative('invoke', method || 'GET', baseUrl + path, JSON.stringify(headers), body ? JSON.stringify(body) : '');
  let data;
  try { data = r.text ? JSON.parse(r.text) : {}; } catch (e) { data = {}; }
  if (r.status >= 400) throw data;
  return data;
}

function onSessionLost() {
  token = null;
  server = null;
  showConnectOverlay('discover');
  toast('Phiên đăng nhập đã hết hạn');
}

/* ---------- CENTERED MODAL DIALOGS (RENAME, SHARE, CONFIRM, NEW FOLDER) ---------- */
/* Floating selection button ("Đã chọn N mục") */
const selChip = document.createElement('button');
selChip.className = 'action-btn primary';
selChip.style.cssText = 'position:fixed;bottom:2rem;right:2rem;z-index:99;padding:0.75rem 1.4rem;border-radius:999px;box-shadow:0 10px 25px rgba(37,99,235,0.4);display:none;align-items:center;gap:8px';
(document.querySelector('.app') || document.body).appendChild(selChip);
selChip.addEventListener('click', () => { if (selMode && selectedSet.size) openSelSheet(); });

/* Floating paste button */
const pasteFab = document.createElement('button');
pasteFab.className = 'action-btn primary';
pasteFab.style.cssText = 'position:fixed;bottom:2rem;left:2rem;z-index:99;padding:0.75rem 1.4rem;border-radius:999px;background:#059669;border-color:#059669;box-shadow:0 10px 25px rgba(5,150,105,0.4);display:none;align-items:center;gap:8px';
(document.querySelector('.app') || document.body).appendChild(pasteFab);
pasteFab.addEventListener('click', clipPaste);

function updateFabs() {
  const showSel = selMode && selectedSet.size > 0 && currentView === 'files';
  selChip.style.display = showSel ? 'flex' : 'none';
  if (showSel) selChip.innerHTML = `<svg style="width:1.2rem;height:1.2rem"><use href="#i-check"></use></svg><span>Đã chọn ${selectedSet.size} mục</span>`;

  const showPaste = clipboard.items.length > 0 && currentView === 'files';
  pasteFab.style.display = showPaste ? 'flex' : 'none';
  if (showPaste) {
    const verb = clipboard.mode === 'cut' ? 'Cắt' : 'Copy';
    pasteFab.innerHTML = `<svg style="width:1.2rem;height:1.2rem"><use href="#i-paste"></use></svg><span>Dán (${verb} ${clipboard.items.length} mục)</span>`;
  }
}

function sheetConfirm(title, message, okLabel, onOk) {
  pendingConfirmAction = onOk;
  $('#confirmTitle').textContent = title || 'Xác nhận';
  $('#confirmSub').textContent = message || '';
  $('#confirmOkBtn').querySelector('span').textContent = okLabel || 'Đồng ý';
  $('#confirmOverlay').classList.add('open');
}

function renameEntry(e) {
  pendingRenameTarget = e;
  const overlay = $('#renameOverlay');
  const title = $('#renameTitle');
  const sub = $('#renameSub');
  const input = $('#renameInput');
  const err = $('#renameErr');

  if (title) title.textContent = 'Đổi tên "' + e.name + '"';
  if (sub) sub.textContent = 'Nhập tên mới cho ' + (e.type === 'dir' ? 'thư mục' : 'tệp tin');
  if (input) input.value = e.name;
  if (err) err.textContent = '';
  if (overlay) overlay.classList.add('open');
  setTimeout(() => { if (input) { input.focus(); input.select(); } }, 80);
}

async function submitRename() {
  if (!pendingRenameTarget) return;
  const input = $('#renameInput');
  const err = $('#renameErr');
  const newName = (input ? input.value : '').trim();
  if (!newName) { if (err) err.textContent = 'Vui lòng nhập tên mới'; return; }
  if (newName === pendingRenameTarget.name) { $('#renameOverlay').classList.remove('open'); return; }

  const oldRel = relOf(pendingRenameTarget);
  try {
    await api('/api/rename', 'POST', { path: oldRel, newName: newName, pool });
    toast('Đã đổi tên thành: ' + newName);
    $('#renameOverlay').classList.remove('open');
    pendingRenameTarget = null;
    selectedEntry = null;
    loadFiles(currentPath);
  } catch (er) {
    if (err) err.textContent = er.error || er.message || 'Không thể đổi tên (có thể tên đã tồn tại)';
    else toast('Lỗi đổi tên: ' + (er.error || er.message || 'Không thể đổi tên'));
  }
}

function openShareSheet(e) {
  pendingShareTarget = e;
  const rel = relOf(e);
  const directLink = `${server.baseUrl}/api/file?path=${enc(rel)}&pool=${enc(pool)}${token ? '&token=' + enc(token) : ''}`;
  
  $('#shareTitle').textContent = 'Chia sẻ "' + e.name + '"';
  $('#shareSub').textContent = 'Liên kết tải và xem trực tiếp qua mạng LAN';
  $('#shareLinkInput').value = directLink;
  $('#shareOverlay').classList.add('open');
}

function newFolderDialog() {
  const overlay = $('#newFolderOverlay');
  const input = $('#newFolderInput');
  const err = $('#newFolderErr');
  if (input) input.value = '';
  if (err) err.textContent = '';
  if (overlay) overlay.classList.add('open');
  setTimeout(() => { if (input) input.focus(); }, 80);
}

async function submitNewFolder() {
  const input = $('#newFolderInput');
  const err = $('#newFolderErr');
  const name = (input ? input.value : '').trim();
  if (!name) { if (err) err.textContent = 'Vui lòng nhập tên thư mục'; return; }

  try {
    await api('/api/mkdir', 'POST', { path: (currentPath ? currentPath + '/' : '') + name, pool });
    toast('Đã tạo thư mục ' + name);
    $('#newFolderOverlay').classList.remove('open');
    loadFiles(currentPath);
  } catch (er) {
    if (err) err.textContent = er.error || er.message || 'Lỗi tạo thư mục';
  }
}

/* ---------- FAVORITES MANAGEMENT ---------- */
function isFav(e) {
  const rel = relOf(e);
  return favs.some((f) => f.path === rel && f.pool === pool);
}

function toggleFav(e) {
  const rel = relOf(e);
  const idx = favs.findIndex((f) => f.path === rel && f.pool === pool);
  if (idx >= 0) {
    favs.splice(idx, 1);
    toast('Đã bỏ yêu thích: ' + e.name);
  } else {
    favs.push({ name: e.name, path: rel, pool: pool, type: e.type, size: e.size, mtime: e.mtime });
    toast('Đã thêm vào yêu thích: ' + e.name);
  }
  kvSet(kFavs(), favs);
  renderDetailPane();
  renderFileGrid();
}

/* ---------- CLIPBOARD & ACTIONS ---------- */
function clipCopy(e) {
  clipboard = { items: [e], mode: 'copy', dir: currentPath, pool };
  toast('Đã copy: ' + e.name);
  updateFabs();
}

function clipCut(e) {
  clipboard = { items: [e], mode: 'cut', dir: currentPath, pool };
  toast('Đã cắt: ' + e.name);
  updateFabs();
}

async function clipPaste() {
  if (!clipboard.items.length) return;
  const verb = clipboard.mode === 'cut' ? 'di chuyển' : 'sao chép';
  toast(`Đang ${verb} ${clipboard.items.length} mục…`);

  for (const it of clipboard.items) {
    const srcRel = (clipboard.dir ? clipboard.dir + '/' : '') + it.name;
    const destRel = (currentPath ? currentPath + '/' : '') + it.name;
    try {
      if (clipboard.mode === 'cut') {
        await api('/api/move', 'POST', { src: srcRel, dest: destRel, srcPool: clipboard.pool, destPool: pool });
      } else {
        await api('/api/copy', 'POST', { src: srcRel, dest: destRel, srcPool: clipboard.pool, destPool: pool });
      }
    } catch (e) {
      toast(`Lỗi khi ${verb} ${it.name}: ` + (e.error || e.message || 'Lỗi'));
    }
  }

  if (clipboard.mode === 'cut') clipboard = { items: [], mode: '', dir: '' };
  updateFabs();
  loadFiles(currentPath);
  toast(`Đã ${verb} xong`);
}

/* ---------- SELECTION MODE (MULTI-SELECT) ---------- */
function toggleSel(name) {
  if (selectedSet.has(name)) selectedSet.delete(name);
  else selectedSet.add(name);
  if (selectedSet.size === 0) exitSelMode();
  else {
    renderFileGrid();
    updateFabs();
  }
}

function enterSelMode(initialName) {
  selMode = true;
  selectedSet.clear();
  if (initialName) selectedSet.add(initialName);
  renderFileGrid();
  updateFabs();
  toast('Đã bật chế độ chọn nhiều');
}

function exitSelMode() {
  selMode = false;
  selectedSet.clear();
  renderFileGrid();
  updateFabs();
}

function openSelSheet() {
  const list = entries.filter((e) => selectedSet.has(e.name));
  sheetConfirm(`Đã chọn ${list.length} mục`, `Bạn muốn thao tác gì với ${list.length} mục đã chọn?`, 'Xóa đã chọn', async () => {
    for (const it of list) {
      try { await api('/api/file?path=' + enc(relOf(it)) + '&pool=' + enc(pool), 'DELETE'); } catch (e) {}
    }
    toast(`Đã xóa ${list.length} mục`);
    exitSelMode();
    loadFiles(currentPath);
  });
}

/* ---------- CONNECT / DISCOVER MODAL PANE CONTROLLER ---------- */
function showConnectOverlay(pane = 'discover') {
  const overlay = $('#connectOverlay');
  if (!overlay) return;
  overlay.classList.add('open');
  $('#paneDiscover').style.display = pane === 'discover' ? 'block' : 'none';
  $('#paneManual').style.display = pane === 'manual' ? 'block' : 'none';
  $('#paneCredentials').style.display = pane === 'creds' ? 'block' : 'none';
  const pOffline = $('#paneOffline');
  if (pOffline) pOffline.style.display = pane === 'offline' ? 'block' : 'none';

  const closeBtns = $$('.btn-close-connect');
  closeBtns.forEach((b) => b.style.display = server ? 'grid' : 'none');

  if (pane === 'discover') runDiscover();
  if (pane === 'offline') renderOfflineList();
  refreshOfflineCountBadge();
}

function hideConnectOverlay() {
  const overlay = $('#connectOverlay');
  if (overlay) overlay.classList.remove('open');
}

let discoverRunning = false;
async function runDiscover() {
  if (discoverRunning) return;
  discoverRunning = true;
  const scanBtn = $('#scanNowBtn');
  const oldText = scanBtn ? scanBtn.innerHTML : '';
  if (scanBtn) {
    scanBtn.innerHTML = '<svg style="animation:spin 1s linear infinite"><use href="#i-refresh"></use></svg><span>Đang quét…</span>';
    scanBtn.disabled = true;
  }
  const list = $('#discoveredHostList');
  if (list) list.innerHTML = '<div style="font-size:0.9rem;color:var(--text-muted);padding:1.5rem;text-align:center">Đang quét mạng LAN tìm máy chủ…</div>';
  
  try {
    const r = await Promise.race([
      callNative('discover', JSON.stringify({ timeoutMs: 2600 })),
      new Promise((res) => setTimeout(() => res({ hosts: [] }), 8500)),
    ]);
    renderDiscoveredHosts((r && r.hosts) || []);
  } catch (e) {
    renderDiscoveredHosts([]);
  } finally {
    if (scanBtn) {
      scanBtn.innerHTML = oldText;
      scanBtn.disabled = false;
    }
    discoverRunning = false;
  }
}

function renderDiscoveredHosts(hosts) {
  const list = $('#discoveredHostList');
  if (!list) return;
  list.innerHTML = '';
  if (!hosts.length) {
    list.innerHTML = '<div style="font-size:0.9rem;color:var(--text-muted);padding:1.5rem;text-align:center">Không tìm thấy máy chủ CW Datacenter trong mạng LAN.<br><span style="font-size:0.8rem;color:#94a3b8">Hãy đảm bảo máy tính và Tablet cùng kết nối Wi-Fi.</span></div>';
    return;
  }

  hosts.forEach((h) => {
    const card = document.createElement('div');
    card.style.cssText = 'display:flex;align-items:center;gap:1rem;padding:0.9rem 1rem;border:1px solid var(--border);border-radius:0.8rem;background:var(--surface);margin-bottom:0.7rem;cursor:pointer;transition:all 0.15s ease';
    card.innerHTML = `
      <div style="width:2.6rem;height:2.6rem;border-radius:0.6rem;background:var(--surface-2);display:grid;place-items:center;color:var(--blue);flex-shrink:0">
        <svg style="width:1.4rem;height:1.4rem"><use href="#i-db"></use></svg>
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:0.98rem;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(h.host || h.name || h.ip)}</div>
        <div style="font-size:0.8rem;color:var(--text-muted);margin-top:2px">${esc(h.ip)}${h.port ? ':' + h.port : ''} · <span style="color:var(--green);font-weight:600">● Trực tuyến</span></div>
      </div>
      <div style="color:var(--text-muted);font-size:1.2rem;font-weight:700">›</div>
    `;
    card.addEventListener('click', () => selectServer(h));
    list.appendChild(card);
  });
}

function selectServer(h) {
  const ip = h.ip;
  const port = h.port || 8080;
  server = {
    ip, port,
    baseUrl: 'http://' + ip + ':' + port,
    host: h.host || ip,
    name: h.host || ip,
    via: 'lan',
  };

  $('#targetHostTitle').textContent = server.name;
  $('#targetHostSub').textContent = server.ip + ':' + server.port;
  $('#serverIp').value = server.ip;
  $('#serverPort').value = server.port;

  const creds = kvGet(kCreds()) || {};
  $('#username').value = creds.u || 'admin';
  $('#password').value = creds.p || '';

  showConnectOverlay('creds');
  setTimeout(() => { const p = $('#password'); if (p) p.focus(); }, 100);
}

async function submitLogin() {
  const u = ($('#username').value || '').trim();
  const p = ($('#password').value || '').trim();
  const remember = $('#rememberLoginCheck') ? $('#rememberLoginCheck').checked : true;
  if (!server) { toast('Chưa chọn máy chủ'); return; }

  const loginBtn = $('#loginBtn');
  const oldText = loginBtn ? loginBtn.textContent : '';
  if (loginBtn) { loginBtn.textContent = 'Đang đăng nhập…'; loginBtn.disabled = true; }

  try {
    const res = await tryApi(server.baseUrl, '/api/login', 'POST', { user: u, password: p });
    if (res && res.token) {
      token = res.token;
      me = { role: res.role || 'admin', user: u || 'admin' };
      kvSet('token:' + server.baseUrl, token);
      if (remember) {
        kvSet(kCreds(), { u, p });
      } else {
        kvSet(kCreds(), { u });
      }
      kvSet('last', { baseUrl: server.baseUrl, ip: server.ip, port: server.port, host: server.host, name: server.name, via: server.via });
      hideConnectOverlay();
      await enterMain();
    } else {
      toast('Đăng nhập thất bại: ' + ((res && res.error) || 'Mật khẩu không đúng'));
    }
  } catch (e) {
    toast('Lỗi kết nối: ' + ((e && e.error) || e.message || 'Không kết nối được'));
  } finally {
    if (loginBtn) { loginBtn.textContent = oldText; loginBtn.disabled = false; }
  }
}

/* ---------- MAIN APPLICATION VIEW & NAVIGATION ---------- */
async function enterMain() {
  hideConnectOverlay();
  $('#hostDot').className = 'dot';
  $('#hostName').textContent = server.name || server.host || 'CW Datacenter';
  $('#hostMeta').textContent = server.ip + (server.port ? ':' + server.port : '');
  
  favs = kvGet(kFavs()) || [];
  syncDb = kvGet(kSync()) || {};
  dlPaths = kvGet(kDlPaths()) || {};

  try { DC.setSession(server.baseUrl, token); } catch (e) {}

  // 1. Tải danh sách ổ đĩa trước để khi vẽ màn hình tệp là có ngay pool pills
  await loadPools();

  // 2. Đồng bộ locks từ server
  await syncLocksFromServer();

  // 3. Chuyển view tệp
  switchView('files');

  // 4. Tải tệp trong ổ mặc định
  await loadFiles('');
}

function switchView(viewId) {
  currentView = viewId;
  $$('.nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.view === viewId));
  $$('.b-nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.view === viewId));
  
  DC.setCanGoBack(viewId !== 'files');
  selectedEntry = null;
  exitSelMode();

  if (viewId === 'files') renderFilesView();
  else if (viewId === 'transfers') renderTransfersView();
  else if (viewId === 'favorites') renderFavoritesView();
  else if (viewId === 'sync') renderSyncView();
  else if (viewId === 'trash') renderTrashView();
}

/* ---------- FILES VIEW CONTROLLER ---------- */
function renderFilesView() {
  const main = $('#main');
  if (!main) return;
  
  main.innerHTML = `
    <div class="topbar">
      <div class="title-wrap">
        <h1 id="viewTitle">Tệp tin</h1>
        <div class="subtitle">
          <span class="dot" style="width:0.5rem;height:0.5rem"></span>
          <span id="activeHostSubtitle">${esc(server ? server.name : 'CW Datacenter')}</span>
          <span>·</span>
          <span id="filesCountSub">${entries.length} mục</span>
        </div>
      </div>
      <div class="top-actions">
        <button class="icon-btn" id="btnToggleSel" title="Chọn nhiều"><svg><use href="#i-check"></use></svg></button>
        <button class="icon-btn" id="btnUploadFiles" title="Tải tệp lên"><svg><use href="#i-upload"></use></svg></button>
        <button class="icon-btn" id="btnNewFolder" title="Tạo thư mục"><svg><use href="#i-folder"></use></svg></button>
        <button class="icon-btn" id="btnRefreshFiles" title="Làm mới"><svg><use href="#i-refresh"></use></svg></button>
      </div>
    </div>

    <div class="toolbar">
      <div class="pool-list" id="poolBar"></div>
      <div class="search-box">
        <svg><use href="#i-search"></use></svg>
        <input id="searchInput" placeholder="Tìm kiếm tệp và thư mục…" value="${esc(searchQuery)}">
      </div>
    </div>

    <div class="view-body">
      <div class="files-layout">
        <div class="files-pane">
          <div class="folder-header">
            <button class="back-btn" id="btnBackFolder" style="display:${currentPath ? 'flex' : 'none'}"><svg><use href="#i-back"></use></svg><span>Lên thư mục cha</span></button>
            <div class="breadcrumb" id="breadcrumb"></div>
          </div>
          <div class="files-scroll">
            <div class="file-grid" id="fileGrid"></div>
          </div>
        </div>

        <!-- Detail Inspector Pane -->
        <aside class="detail-pane" id="detailPane">
          <div class="detail-close-bar">
            <span style="font-weight:700;font-size:0.9rem;color:var(--text)">Chi tiết</span>
            <button id="btnCloseDetail" style="border:none;background:transparent;cursor:pointer;color:var(--text-muted);padding:4px"><svg style="width:1.2rem;height:1.2rem"><use href="#i-close"></use></svg></button>
          </div>
          <div id="detailEmpty" style="display:${selectedEntry ? 'none' : 'flex'};flex-direction:column;align-items:center;justify-content:center;height:100%;text-align:center;color:var(--text-muted);padding:2rem 1rem">
            <svg style="width:3rem;height:3rem;margin-bottom:0.8rem;opacity:0.35"><use href="#i-folder"></use></svg>
            <div style="font-size:0.92rem;font-weight:600">Chưa chọn mục nào</div>
            <div style="font-size:0.78rem;margin-top:4px">Chọn một tệp để xem thông tin chi tiết hoặc nhấn giữ để chọn nhiều</div>
          </div>
          <div id="detailContent" style="display:${selectedEntry ? 'flex' : 'none'};flex-direction:column;height:100%">
            <div class="preview" id="detailPreviewWrap">
              <div class="thumb-fallback" id="detailThumbFallback"><svg id="detailThumbSvg"><use href="#i-folder"></use></svg></div>
              <img id="detailThumbImg" alt="">
              <div class="preview-play-overlay" id="detailPlayOverlay" style="display:none"><svg><use href="#i-play"></use></svg></div>
            </div>
            <div class="detail-name" id="detailName"></div>
            <div class="detail-meta" id="detailMeta"></div>
            <div class="action-list" id="detailActions"></div>
          </div>
        </aside>
      </div>
    </div>
  `;

  renderPoolBar();
  renderBreadcrumb();
  renderFileGrid();
  updateFabs();

  $('#btnRefreshFiles').addEventListener('click', () => loadFiles(currentPath));
  $('#btnUploadFiles').addEventListener('click', pickAndUpload);
  $('#btnNewFolder').addEventListener('click', newFolderDialog);
  $('#btnBackFolder').addEventListener('click', () => goDir(parentPath || ''));
  $('#btnToggleSel').addEventListener('click', () => { if (selMode) exitSelMode(); else enterSelMode(); });
  $('#btnCloseDetail').addEventListener('click', () => {
    selectedEntry = null;
    $('#detailPane').classList.remove('open');
    renderDetailPane();
    renderFileGrid();
  });
  $('#searchInput').addEventListener('input', (e) => {
    searchQuery = e.target.value.trim();
    renderFileGrid();
  });
}

async function loadPools() {
  try {
    const d = await api('/api/pools', 'GET');
    pools = (d && d.pools) || [{ id: 'main', name: 'Ổ chính' }];
  } catch (e) {
    pools = [{ id: 'main', name: 'Ổ chính' }];
  }
  renderPoolBar();
}

function renderPoolBar() {
  const bar = $('#poolBar');
  if (!bar) return;
  bar.innerHTML = '';

  pools.forEach((p) => {
    const pill = document.createElement('button');
    pill.className = 'pill' + (pool === p.id ? ' active' : '');
    pill.textContent = p.name || p.id;
    pill.addEventListener('click', () => {
      if (pool === p.id) return;
      pool = p.id;
      currentPath = '';
      selectedEntry = null;
      renderFilesView();
      loadFiles('');
    });
    bar.appendChild(pill);
  });
}

function renderBreadcrumb() {
  const bc = $('#breadcrumb');
  if (!bc) return;
  bc.innerHTML = '';
  
  const root = document.createElement('span');
  root.style.cursor = 'pointer';
  root.textContent = poolNameOf(pool);
  root.addEventListener('click', () => goDir(''));
  bc.appendChild(root);

  if (currentPath) {
    const parts = currentPath.split('/').filter(Boolean);
    let accum = '';
    parts.forEach((part, idx) => {
      accum += (accum ? '/' : '') + part;
      const thisPath = accum;
      const sep = document.createElement('span');
      sep.textContent = ' / ';
      bc.appendChild(sep);

      const span = document.createElement('span');
      span.textContent = part;
      if (idx === parts.length - 1) {
        span.className = 'current';
      } else {
        span.style.cursor = 'pointer';
        span.addEventListener('click', () => goDir(thisPath));
      }
      bc.appendChild(span);
    });
  }
}

async function loadFiles(dirPath) {
  currentPath = dirPath || '';
  const grid = $('#fileGrid');
  if (grid) grid.innerHTML = '<div style="font-size:0.9rem;color:var(--text-muted);padding:2rem;text-align:center;grid-column:1/-1">Đang tải tệp…</div>';

  try {
    const res = await api('/api/files?path=' + enc(currentPath) + '&pool=' + enc(pool), 'GET');
    entries = (res && res.entries) || [];
    parentPath = res.parent != null ? res.parent : (currentPath ? currentPath.split('/').slice(0, -1).join('/') : null);
    renderBreadcrumb();
    renderFileGrid();
    const countEl = $('#filesCountSub');
    if (countEl) countEl.textContent = entries.length + ' mục';
    const backBtn = $('#btnBackFolder');
    if (backBtn) backBtn.style.display = currentPath ? 'flex' : 'none';
  } catch (e) {
    if (grid) grid.innerHTML = '<div style="font-size:0.9rem;color:var(--red);padding:2rem;text-align:center;grid-column:1/-1">Lỗi tải tệp: ' + (e.error || e.message || 'Không thể đọc thư mục') + '</div>';
  }
}

function goDir(dirPath) {
  selectedEntry = null;
  loadFiles(dirPath);
}

function renderFileGrid() {
  const grid = $('#fileGrid');
  if (!grid) return;
  grid.innerHTML = '';

  let list = entries;
  if (searchQuery) {
    const q = searchQuery.toLowerCase();
    list = list.filter((e) => e.name.toLowerCase().includes(q));
  }

  if (!list.length) {
    grid.innerHTML = `<div style="font-size:0.9rem;color:var(--text-muted);padding:3rem 1rem;text-align:center;grid-column:1/-1">${searchQuery ? 'Không tìm thấy tệp khớp với tìm kiếm' : 'Thư mục trống.'}</div>`;
    renderDetailPane();
    return;
  }

  list.forEach((e) => {
    const card = document.createElement('div');
    const isSel = (selMode && selectedSet.has(e.name)) || (!selMode && selectedEntry && selectedEntry.name === e.name);
    card.className = 'file-card' + (isSel ? ' selected' : '');

    const isDir = e.type === 'dir';
    const isVid = isVideoFile(e.name);
    const isImg = isImageFile(e.name);
    const isPdf = isPdfFile(e.name);
    const locked = isLocked(e);
    const starred = isFav(e);

    let iconSymbol = isDir ? 'i-folder' : (isVid ? 'i-video' : (isImg ? 'i-image' : (isPdf ? 'i-pdf' : 'i-folder')));
    let thumbClass = isDir ? 'folder' : (isVid ? 'video' : (isImg ? 'image' : (isPdf ? 'pdf' : '')));

    const thumbWrap = document.createElement('div');
    thumbWrap.className = 'file-thumb-wrap ' + thumbClass;
    thumbWrap.innerHTML = `<div class="thumb-fallback"><svg><use href="#${iconSymbol}"></use></svg></div>`;

    if (isImg || isVid) {
      const img = document.createElement('img');
      const thumbUrl = server ? (server.baseUrl + '/api/thumb?path=' + enc((currentPath ? currentPath + '/' : '') + e.name) + '&pool=' + enc(pool)) : '';
      if (thumbUrl) {
        img.src = thumbUrl;
        img.onload = () => img.classList.add('loaded');
      }
      thumbWrap.appendChild(img);
    }

    if (isVid) {
      const vBadge = document.createElement('div');
      vBadge.className = 'video-badge';
      vBadge.innerHTML = '<svg><use href="#i-play"></use></svg><span>Video</span>';
      thumbWrap.appendChild(vBadge);
    }

    if (locked) {
      const lockBadge = document.createElement('div');
      lockBadge.style.cssText = 'position:absolute;top:0.35rem;left:0.35rem;background:rgba(239,68,68,0.85);color:#fff;border-radius:0.35rem;padding:2px 5px;font-size:10px;font-weight:700;display:flex;align-items:center;gap:3px;z-index:2';
      lockBadge.innerHTML = '<svg style="width:10px;height:10px"><use href="#i-lock"></use></svg><span>Khóa</span>';
      thumbWrap.appendChild(lockBadge);
    }

    if (starred) {
      const starBadge = document.createElement('div');
      starBadge.style.cssText = 'position:absolute;top:0.35rem;right:0.35rem;background:rgba(245,158,11,0.9);color:#fff;border-radius:0.35rem;padding:2px 4px;font-size:10px;z-index:2';
      starBadge.innerHTML = '<svg style="width:10px;height:10px"><use href="#i-star"></use></svg>';
      thumbWrap.appendChild(starBadge);
    }

    if (selMode) {
      const chk = document.createElement('div');
      chk.style.cssText = `position:absolute;top:0.35rem;right:0.35rem;width:22px;height:22px;border-radius:50%;background:${selectedSet.has(e.name) ? 'var(--blue)' : '#fff'};border:2px solid ${selectedSet.has(e.name) ? 'var(--blue)' : '#cbd5e1'};display:grid;place-items:center;color:#fff;z-index:3`;
      if (selectedSet.has(e.name)) chk.innerHTML = '<svg style="width:12px;height:12px"><use href="#i-check"></use></svg>';
      thumbWrap.appendChild(chk);
    }

    const nameEl = document.createElement('div');
    nameEl.className = 'file-name';
    nameEl.textContent = e.name;

    const metaEl = document.createElement('div');
    metaEl.className = 'subtitle';
    metaEl.style.fontSize = '0.75rem';
    metaEl.textContent = isDir ? fmtDate(e.mtime) : (fmtBytes(e.size) + (e.mtime ? ' · ' + fmtDate(e.mtime) : ''));

    card.appendChild(thumbWrap);
    card.appendChild(nameEl);
    card.appendChild(metaEl);

    /* Nhấn giữ (Long press) để chọn nhiều */
    const onTouchStart = () => {
      lpTimer = setTimeout(() => {
        lpSuppressClick = true;
        if (!selMode) enterSelMode(e.name);
        else toggleSel(e.name);
      }, 450);
    };
    const onTouchEnd = () => { clearTimeout(lpTimer); };

    card.addEventListener('touchstart', onTouchStart, { passive: true });
    card.addEventListener('touchend', onTouchEnd);
    card.addEventListener('touchcancel', onTouchEnd);
    card.addEventListener('mousedown', onTouchStart);
    card.addEventListener('mouseup', onTouchEnd);
    card.addEventListener('mouseleave', onTouchEnd);

    card.addEventListener('click', () => {
      if (lpSuppressClick) { lpSuppressClick = false; return; }
      if (selMode) {
        toggleSel(e.name);
        return;
      }
      selectedEntry = e;
      renderDetailPane();
      $('#detailPane').classList.add('open');
      renderFileGrid();
    });

    card.addEventListener('dblclick', () => {
      openEntryDirectly(e);
    });

    grid.appendChild(card);
  });

  renderDetailPane();
}

function renderDetailPane() {
  const empty = $('#detailEmpty');
  const content = $('#detailContent');
  if (!empty || !content) return;

  if (!selectedEntry) {
    empty.style.display = 'flex';
    content.style.display = 'none';
    return;
  }

  empty.style.display = 'none';
  content.style.display = 'flex';

  const e = selectedEntry;
  const isDir = e.type === 'dir';
  const isVid = isVideoFile(e.name);
  const isImg = isImageFile(e.name);
  const isPdf = isPdfFile(e.name);
  const locked = isLocked(e);
  const starred = isFav(e);

  $('#detailName').textContent = e.name;
  $('#detailMeta').textContent = (isDir ? 'Thư mục' : ('Tệp ' + (e.name.split('.').pop() || '').toUpperCase() + ' · ' + fmtBytes(e.size))) + (e.mtime ? '\nSửa đổi: ' + fmtDate(e.mtime) : '');

  const thumbFallback = $('#detailThumbFallback');
  const thumbImg = $('#detailThumbImg');
  const playOverlay = $('#detailPlayOverlay');
  const iconSymbol = isDir ? 'i-folder' : (isVid ? 'i-video' : (isImg ? 'i-image' : (isPdf ? 'i-pdf' : 'i-folder')));
  
  if (thumbFallback) thumbFallback.innerHTML = `<svg><use href="#${iconSymbol}"></use></svg>`;
  if (thumbImg) {
    thumbImg.classList.remove('loaded');
    if (isImg || isVid) {
      const thumbUrl = server ? (server.baseUrl + '/api/thumb?path=' + enc((currentPath ? currentPath + '/' : '') + e.name) + '&pool=' + enc(pool)) : '';
      thumbImg.src = thumbUrl;
      thumbImg.onload = () => thumbImg.classList.add('loaded');
    } else {
      thumbImg.src = '';
    }
  }
  if (playOverlay) playOverlay.style.display = isVid ? 'grid' : 'none';

  const actions = $('#detailActions');
  actions.innerHTML = '';

  const btnOpen = document.createElement('button');
  btnOpen.className = 'action-btn primary';
  btnOpen.innerHTML = `<svg><use href="${isDir ? '#i-folder' : '#i-play'}"></use></svg><span>${isDir ? 'Mở thư mục' : 'Xem / Mở'}</span>`;
  btnOpen.addEventListener('click', () => openEntryDirectly(e));
  actions.appendChild(btnOpen);

  const btnFav = document.createElement('button');
  btnFav.className = 'action-btn';
  btnFav.innerHTML = `<svg><use href="#i-star"></use></svg><span>${starred ? 'Bỏ yêu thích' : 'Yêu thích (Ghim sao)'}</span>`;
  btnFav.addEventListener('click', () => toggleFav(e));
  actions.appendChild(btnFav);

  const btnShare = document.createElement('button');
  btnShare.className = 'action-btn';
  btnShare.innerHTML = '<svg><use href="#i-share"></use></svg><span>Chia sẻ link</span>';
  btnShare.addEventListener('click', () => openShareSheet(e));
  actions.appendChild(btnShare);

  if (!isDir) {
    const btnDown = document.createElement('button');
    btnDown.className = 'action-btn';
    btnDown.innerHTML = '<svg><use href="#i-download"></use></svg><span>Tải về máy</span>';
    btnDown.addEventListener('click', () => startDownload(e));
    actions.appendChild(btnDown);

    if (isVid) {
      const btnPreload = document.createElement('button');
      btnPreload.className = 'action-btn';
      btnPreload.innerHTML = '<svg><use href="#i-video"></use></svg><span>Tải trước (Xem ngoại tuyến)</span>';
      btnPreload.addEventListener('click', () => preloadVideoOffline(e));
      actions.appendChild(btnPreload);

      const btnVlc = document.createElement('button');
      btnVlc.className = 'action-btn';
      btnVlc.innerHTML = '<svg><use href="#i-play"></use></svg><span>Mở bằng ứng dụng khác (VLC)</span>';
      btnVlc.addEventListener('click', () => openWithExternalApp(e));
      actions.appendChild(btnVlc);
    }
  }

  const btnCopy = document.createElement('button');
  btnCopy.className = 'action-btn';
  btnCopy.innerHTML = '<svg><use href="#i-copy"></use></svg><span>Copy</span>';
  btnCopy.addEventListener('click', () => clipCopy(e));
  actions.appendChild(btnCopy);

  const btnCut = document.createElement('button');
  btnCut.className = 'action-btn';
  btnCut.innerHTML = '<svg><use href="#i-cut"></use></svg><span>Cắt</span>';
  btnCut.addEventListener('click', () => clipCut(e));
  actions.appendChild(btnCut);

  if (hasLockHash(e)) {
    const btnUnlock = document.createElement('button');
    btnUnlock.className = 'action-btn';
    btnUnlock.innerHTML = '<svg><use href="#i-lock"></use></svg><span>Gỡ khóa mật khẩu</span>';
    btnUnlock.addEventListener('click', () => unlockEntryPermanently(e));
    actions.appendChild(btnUnlock);
  } else {
    const btnLock = document.createElement('button');
    btnLock.className = 'action-btn';
    btnLock.innerHTML = '<svg><use href="#i-lock"></use></svg><span>Khóa bằng mật khẩu</span>';
    btnLock.addEventListener('click', () => lockEntryWithPassword(e));
    actions.appendChild(btnLock);
  }

  if (canWrite()) {
    const btnRename = document.createElement('button');
    btnRename.className = 'action-btn';
    btnRename.innerHTML = '<svg><use href="#i-edit"></use></svg><span>Đổi tên</span>';
    btnRename.addEventListener('click', () => renameEntry(e));
    actions.appendChild(btnRename);

    const btnDelete = document.createElement('button');
    btnDelete.className = 'action-btn';
    btnDelete.style.color = 'var(--red)';
    btnDelete.innerHTML = '<svg><use href="#i-trash"></use></svg><span>Xóa</span>';
    btnDelete.addEventListener('click', () => deleteEntry(e));
    actions.appendChild(btnDelete);
  }
}

function openEntryDirectly(e) {
  if (isLocked(e)) {
    promptUnlock(e, () => openEntryDirectly(e));
    return;
  }

  const rel = relOf(e);
  if (e.type === 'dir') {
    goDir(rel);
    return;
  }

  if (isVideoFile(e.name)) {
    playVideoWithResumeCheck(e, rel);
  } else if (isImageFile(e.name)) {
    openPhotoViewer(e, rel);
  } else if (isPdfFile(e.name)) {
    const pdfUrl = server ? (server.baseUrl + '/api/file?path=' + enc(rel) + '&pool=' + enc(pool)) : '';
    callNative('openPdf', JSON.stringify({ url: pdfUrl, name: e.name, token }));
  } else {
    startDownload(e);
  }
}

/* ---------- VIDEO PLAYBACK (EXOPLAYER QUA PROXY & VLC DIRECT) ---------- */
function launchVideo(e, rel, startPos) {
  const pl = entries.filter((x) => isVideoFile(x.name)).map((x) => ({
    name: x.name,
    size: x.size || 0,
    rel: relOf(x)
  }));
  const plIdx = pl.findIndex((x) => x.name === e.name);

  // URL để rỗng để Native Bridge tự động định tuyến qua Local Media Proxy (127.0.0.1)
  // giúp ExoPlayer phát mượt mà, hỗ trợ tua seek và nạp token tự động không bao giờ lỗi HTTP Status!
  callNative('playVideo', JSON.stringify({
    url: '',
    baseUrl: server ? server.baseUrl : '',
    token: token || '',
    rel: rel,
    pool: pool,
    name: e.name,
    size: e.size || 0,
    startPos: startPos != null ? startPos : -1,
    plIndex: plIdx >= 0 ? plIdx : 0,
    playlist: pl
  }));
}

async function playVideoWithResumeCheck(e, rel) {
  try {
    const r = await callNative('getVideoProgress', JSON.stringify({
      rel, pool, baseUrl: server ? server.baseUrl : ''
    }));
    const pos = (r && r.positionMs) || 0;
    if (pos > 5000) {
      pendingResumeVideo = { e, rel, pos };
      const overlay = $('#videoResumeOverlay');
      const label = $('#vrResumeLabel');
      const sec = Math.floor(pos / 1000);
      const m = Math.floor(sec / 60);
      const s = sec % 60;
      if (label) label.textContent = `▶ Xem tiếp (${m}:${s < 10 ? '0' + s : s})`;
      if (overlay) overlay.classList.add('open');
      return;
    }
  } catch (err) {}
  launchVideo(e, rel, 0);
}

function openWithExternalApp(e) {
  const rel = relOf(e);
  // Truyền URL luồng trực tiếp từ máy chủ Host PC kèm token để ứng dụng ngoài (VLC) xem mượt không bao giờ bị văng
  const directUrl = server ? `${server.baseUrl}/api/video?path=${enc(rel)}&pool=${enc(pool)}${token ? '&token=' + enc(token) : ''}&raw=1` : '';
  callNative('playVideo', JSON.stringify({
    url: directUrl,
    name: e.name,
    size: e.size || 0,
    external: true
  }));
}

function openPhotoViewer(e, rel) {
  const imgUrl = server ? (server.baseUrl + '/api/file?path=' + enc(rel) + '&pool=' + enc(pool)) : '';
  const playlist = entries.filter((x) => isImageFile(x.name)).map((x) => ({
    name: x.name,
    url: server ? (server.baseUrl + '/api/file?path=' + enc(relOf(x)) + '&pool=' + enc(pool)) : '',
    size: x.size || 0
  }));
  const plIdx = playlist.findIndex((x) => x.name === e.name);

  callNative('openPhoto', JSON.stringify({
    url: imgUrl,
    name: e.name,
    token: token || '',
    baseUrl: server ? server.baseUrl : '',
    playlist: JSON.stringify(playlist),
    initialIndex: plIdx >= 0 ? plIdx : 0
  }));
}

async function startDownload(e) {
  const rel = relOf(e);
  const fileUrl = server ? (server.baseUrl + '/api/file?path=' + enc(rel) + '&pool=' + enc(pool)) : '';
  toast('Bắt đầu tải về: ' + e.name);
  try {
    await callNative('download', JSON.stringify({
      url: fileUrl,
      name: e.name,
      headers: JSON.stringify(token ? { Authorization: 'Bearer ' + token } : {})
    }));
  } catch (err) {
    toast('Lỗi tải về: ' + err);
  }
}

async function preloadVideoOffline(e) {
  const rel = relOf(e);
  const fileUrl = server ? (server.baseUrl + '/api/file?path=' + enc(rel) + '&pool=' + enc(pool)) : '';
  toast('Đang tải trước: ' + e.name);
  try {
    const r = await callNative('startOfflinePreload', JSON.stringify({
      url: fileUrl,
      name: e.name,
      pool: pool,
      rel: rel,
      tok: token || ''
    }));
    if (r && r.done) {
      toast('Video này đã được tải trước');
      refreshOfflineCountBadge();
    }
  } catch (err) {
    toast('Lỗi tải trước: ' + err);
  }
}

async function deleteEntry(e) {
  sheetConfirm('Xóa tệp/thư mục?', `Bạn có chắc chắn muốn chuyển "${e.name}" vào thùng rác?`, 'Xóa', async () => {
    const rel = relOf(e);
    try {
      await api('/api/file?path=' + enc(rel) + '&pool=' + enc(pool), 'DELETE');
      toast('Đã xóa ' + e.name);
      selectedEntry = null;
      loadFiles(currentPath);
    } catch (err) {
      toast('Lỗi khi xóa: ' + (err.error || err.message || 'Lỗi không xác định'));
    }
  });
}

async function pickAndUpload() {
  if (!canWrite()) { toast('Tài khoản này không có quyền tải lên.'); return; }
  try {
    const r = await callNative('pickFiles');
    const files = (r && r.files) || [];
    if (!files.length) return;
    toast(`Đang tải lên ${files.length} tệp…`);
    for (const f of files) {
      const rel = (currentPath ? currentPath + '/' : '') + f.name;
      const key = 'up:' + rel;
      transfers[key] = { key, dir: 'up', name: f.name, rel, pool, status: 'active', done: 0, total: Math.max(0, f.size || 0), speed: 0 };
      if (currentView === 'transfers') renderTransfersView();
      try {
        await callNative('upload', JSON.stringify({
          baseUrl: server.baseUrl, token, pool, path: rel, name: f.name, uri: f.uri
        }));
      } catch (err) {}
    }
    loadFiles(currentPath);
  } catch (err) {
    toast('Lỗi chọn tệp: ' + err);
  }
}

/* ---------- OTHER VIEWS (TRANSFERS, FAVORITES, SYNC, TRASH) ---------- */
function renderTransfersView() {
  const main = $('#main');
  if (!main) return;
  const list = Object.values(transfers);
  
  main.innerHTML = `
    <div class="topbar">
      <div class="title-wrap">
        <h1>Truyền tải</h1>
        <div class="subtitle">${list.length} tác vụ truyền tải</div>
      </div>
      <div class="top-actions">
        <button class="icon-btn" id="btnClearTransfers" title="Xóa danh sách"><svg><use href="#i-trash"></use></svg></button>
      </div>
    </div>
    <div class="view-body">
      <div class="list" id="transfersList" style="padding:1rem">
        ${!list.length ? '<div style="font-size:0.9rem;color:var(--text-muted);padding:3rem 1rem;text-align:center">Chưa có tác vụ truyền tải nào.</div>' : ''}
      </div>
    </div>
  `;

  const box = $('#transfersList');
  if (box && list.length) {
    box.innerHTML = '';
    list.forEach((t) => {
      const card = document.createElement('div');
      card.style.cssText = 'padding:12px;border:1px solid var(--border);border-radius:0.75rem;margin-bottom:10px;background:var(--surface)';
      const isDone = t.status === 'done';
      const isErr = t.status === 'error';
      const pct = t.total > 0 ? Math.min(100, Math.round(t.done * 100 / t.total)) : 0;
      card.innerHTML = `
        <div style="display:flex;justify-content:space-between;font-weight:600;font-size:0.92rem;color:var(--text)">
          <span>${esc(t.name || 'Tệp')}</span>
          <span style="color:${isDone ? 'var(--green)' : (isErr ? 'var(--red)' : 'var(--blue)')}">${isDone ? 'Hoàn tất' : (isErr ? 'Lỗi' : pct + '%')}</span>
        </div>
        <div style="height:6px;background:var(--surface-2);border-radius:3px;margin:8px 0;overflow:hidden">
          <div style="height:100%;background:${isDone ? 'var(--green)' : (isErr ? 'var(--red)' : 'var(--blue)')};width:${pct}%"></div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:0.78rem;color:var(--text-muted)">
          <span>${fmtBytes(t.done)} / ${fmtBytes(t.total)}</span>
          <span>${t.speed ? fmtSpeed(t.speed) : ''}</span>
        </div>
      `;
      box.appendChild(card);
    });
  }

  $('#btnClearTransfers').addEventListener('click', () => {
    transfers = {};
    renderTransfersView();
    toast('Đã dọn dẹp danh sách truyền tải');
  });
}

function renderFavoritesView() {
  const main = $('#main');
  if (!main) return;
  const list = favs || [];

  main.innerHTML = `
    <div class="topbar">
      <div class="title-wrap">
        <h1>Yêu thích</h1>
        <div class="subtitle">${list.length} mục đã ghim sao</div>
      </div>
    </div>
    <div class="view-body">
      <div class="stats">
        <div class="stat"><div class="stat-label">TỆP ĐÃ GHIM</div><div class="stat-value">${list.filter(x => x.type !== 'dir').length}</div></div>
        <div class="stat"><div class="stat-label">THƯ MỤC ĐÃ GHIM</div><div class="stat-value">${list.filter(x => x.type === 'dir').length}</div></div>
        <div class="stat"><div class="stat-label">TỔNG CỘNG</div><div class="stat-value">${list.length}</div></div>
      </div>
      <div class="list" id="favsList" style="padding:0.6rem">
        ${!list.length ? '<div style="font-size:0.9rem;color:var(--text-muted);padding:3rem 1rem;text-align:center">Chưa có mục yêu thích nào.<br><span style="font-size:12px;color:#94a3b8">Bấm nút "Yêu thích" trên bảng chi tiết tệp để ghim vào đây.</span></div>' : ''}
      </div>
    </div>
  `;

  const box = $('#favsList');
  if (box && list.length) {
    box.innerHTML = '';
    list.forEach((f) => {
      const row = document.createElement('div');
      row.className = 'row';
      row.style.cursor = 'pointer';
      const isDir = f.type === 'dir';
      const icon = isDir ? 'i-folder' : (isVideoFile(f.name) ? 'i-video' : (isImageFile(f.name) ? 'i-image' : 'i-cube'));
      row.innerHTML = `
        <div style="color:${isDir ? 'var(--yellow)' : 'var(--blue)'}"><svg style="width:1.8rem;height:1.8rem"><use href="#${icon}"></use></svg></div>
        <div style="min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;font-size:0.92rem">${esc(f.name)}</div>
        <div style="font-size:0.8rem;color:var(--text-muted)">${f.size ? fmtBytes(f.size) : 'Thư mục'}</div>
        <div style="text-align:right"><button class="icon-btn btn-unfav" style="width:2.2rem;height:2.2rem;color:var(--yellow)"><svg><use href="#i-star"></use></svg></button></div>
      `;
      row.addEventListener('click', () => {
        switchView('files');
        pool = f.pool || 'main';
        if (isDir) goDir(f.path);
        else {
          const p = f.path.includes('/') ? f.path.slice(0, f.path.lastIndexOf('/')) : '';
          goDir(p);
        }
      });
      row.querySelector('.btn-unfav').addEventListener('click', (ev) => {
        ev.stopPropagation();
        toggleFav(f);
        renderFavoritesView();
      });
      box.appendChild(row);
    });
  }
}

function renderSyncView() {
  const main = $('#main');
  if (!main) return;
  const syncedCount = Object.keys(syncDb).length;

  main.innerHTML = `
    <div class="topbar">
      <div class="title-wrap">
        <h1>Đồng bộ</h1>
        <div class="subtitle">Tự động sao lưu ảnh và video từ thiết bị lên máy chủ PC</div>
      </div>
      <div class="top-actions">
        <button class="action-btn primary" id="btnSyncNow"><svg><use href="#i-sync"></use></svg><span>Đồng bộ ngay</span></button>
      </div>
    </div>
    <div class="view-body">
      <div class="stats">
        <div class="stat"><div class="stat-label">MỤC ĐÃ ĐỒNG BỘ</div><div class="stat-value">${syncedCount}</div></div>
        <div class="stat"><div class="stat-label">TRẠNG THÁI</div><div class="stat-value" style="font-size:1.1rem;color:var(--green)">● Tự động sao lưu</div></div>
        <div class="stat"><div class="stat-label">THƯ MỤC ĐÍCH</div><div class="stat-value" style="font-size:1rem">Camera_Uploads</div></div>
      </div>
      <div class="list" style="padding:1.5rem">
        <div style="font-weight:700;font-size:1.05rem;margin-bottom:0.6rem">Tự động sao lưu ảnh & video</div>
        <div style="font-size:0.85rem;color:var(--text-muted);line-height:1.6;margin-bottom:1.2rem">Khi bạn chụp ảnh hoặc quay video mới trên máy tính bảng, ứng dụng sẽ tự động tải lên máy chủ PC khi kết nối Wi-Fi.</div>
        <button class="action-btn" id="btnToggleCamSync" style="max-width:20rem"><svg><use href="#i-sync"></use></svg><span>${camOn ? 'Tắt tự động sao lưu' : 'Bật tự động sao lưu'}</span></button>
      </div>
    </div>
  `;

  $('#btnSyncNow').addEventListener('click', () => {
    toast('Đang kiểm tra và đồng bộ tệp mới…');
  });
  $('#btnToggleCamSync').addEventListener('click', () => {
    camOn = !camOn;
    toast(camOn ? 'Đã bật tự động sao lưu ảnh' : 'Đã tắt tự động sao lưu');
    renderSyncView();
  });
}

function renderTrashView() {
  const main = $('#main');
  if (!main) return;
  main.innerHTML = `
    <div class="topbar">
      <div class="title-wrap">
        <h1>Thùng rác</h1>
        <div class="subtitle">Các tệp đã xóa được lưu tại đây</div>
      </div>
      <div class="top-actions">
        <button class="action-btn primary" id="btnEmptyTrash" style="background:var(--red);border-color:var(--red)"><svg><use href="#i-trash"></use></svg><span>Dọn sạch thùng rác</span></button>
      </div>
    </div>
    <div class="view-body">
      <div class="list" style="padding:3rem 1rem;text-align:center;color:var(--text-muted)">
        <svg style="width:3.5rem;height:3.5rem;opacity:0.35;margin-bottom:0.8rem"><use href="#i-trash"></use></svg>
        <div style="font-size:1rem;font-weight:600">Thùng rác trống</div>
        <div style="font-size:0.8rem;margin-top:4px">Các mục đã xóa sẽ được lưu trữ 30 ngày trước khi dọn dẹp vĩnh viễn.</div>
      </div>
    </div>
  `;

  $('#btnEmptyTrash').addEventListener('click', () => {
    sheetConfirm('Dọn sạch thùng rác?', 'Tất cả các tệp trong thùng rác sẽ bị xóa vĩnh viễn không thể khôi phục.', 'Dọn sạch', () => {
      toast('Đã dọn sạch thùng rác');
    });
  });
}

function onNativeEvent(ev) {
  if (ev.type === 'transfer') {
    transfers[ev.id] = ev;
    if (currentView === 'transfers') renderTransfersView();
    if (ev.status === 'done' && ev.id.startsWith('off:')) refreshOfflineCountBadge();
  }
}

function handleBack() {
  const overlays = ['#renameOverlay', '#lockModalOverlay', '#shareOverlay', '#confirmOverlay', '#newFolderOverlay', '#unlockOverlay', '#videoResumeOverlay'];
  for (const id of overlays) {
    const el = $(id);
    if (el && el.classList.contains('open')) {
      el.classList.remove('open');
      return;
    }
  }

  const overlay = $('#connectOverlay');
  if (overlay && overlay.classList.contains('open')) {
    if ($('#paneCredentials').style.display !== 'none' || $('#paneManual').style.display !== 'none' || $('#paneOffline').style.display !== 'none') {
      showConnectOverlay('discover');
      return;
    }
    if (server) { hideConnectOverlay(); return; }
  }

  if (selMode) { exitSelMode(); return; }
  if (currentView === 'files' && currentPath) {
    goDir(parentPath || '');
    return;
  }
}

/* ---------- BOOTSTRAP EVENT LISTENERS & STARTUP ---------- */
function initEvents() {
  $$('.nav-btn').forEach((btn) => btn.addEventListener('click', () => switchView(btn.dataset.view)));
  $$('.b-nav-btn').forEach((btn) => btn.addEventListener('click', () => switchView(btn.dataset.view)));

  const hostBox = $('#hostBox');
  if (hostBox) hostBox.addEventListener('click', () => showConnectOverlay('discover'));

  $$('.btn-close-connect').forEach((b) => b.addEventListener('click', hideConnectOverlay));

  $('#scanNowBtn').addEventListener('click', runDiscover);
  $('#btnOpenManual').addEventListener('click', () => showConnectOverlay('manual'));
  $('#btnBackToDiscover').addEventListener('click', () => showConnectOverlay('discover'));
  $('#btnBackToDiscover2').addEventListener('click', () => showConnectOverlay('discover'));
  $('#cancelLogin').addEventListener('click', () => showConnectOverlay('discover'));
  $('#offlineBackBtn').addEventListener('click', () => showConnectOverlay('discover'));
  
  $('#btnSubmitManual').addEventListener('click', () => {
    const ip = ($('#manualIpInput').value || '').trim();
    const port = parseInt($('#manualPortInput').value || '8080', 10);
    if (!ip) { toast('Vui lòng nhập địa chỉ IP'); return; }
    selectServer({ ip, port, host: ip });
  });

  $('#loginBtn').addEventListener('click', submitLogin);
  $('#password').addEventListener('keydown', (e) => { if (e.key === 'Enter') submitLogin(); });

  const offVidBtn = $('#offlineVideosBtn');
  if (offVidBtn) {
    offVidBtn.addEventListener('click', () => {
      showConnectOverlay('offline');
    });
  }

  /* Rename Dialog Handlers */
  $('#renameConfirmBtn').addEventListener('click', submitRename);
  $('#renameCancelBtn').addEventListener('click', () => { $('#renameOverlay').classList.remove('open'); pendingRenameTarget = null; });
  $('#renameInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') submitRename(); });

  /* Lock Modal Handlers */
  $('#lockModalConfirmBtn').addEventListener('click', submitLock);
  $('#lockModalCancelBtn').addEventListener('click', () => { $('#lockModalOverlay').classList.remove('open'); pendingLockTarget = null; });
  $('#lockModalPasswordInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') submitLock(); });

  /* Share Dialog Handlers */
  $('#btnCopyShareDirect').addEventListener('click', () => {
    const val = $('#shareLinkInput').value;
    callNative('copyText', val);
    toast('Đã copy link tải trực tiếp');
  });
  $('#btnShareApp').addEventListener('click', () => {
    const val = $('#shareLinkInput').value;
    callNative('shareText', val);
  });
  $('#shareCloseBtn').addEventListener('click', () => $('#shareOverlay').classList.remove('open'));

  /* Confirm Dialog Handlers */
  $('#confirmOkBtn').addEventListener('click', () => {
    $('#confirmOverlay').classList.remove('open');
    if (pendingConfirmAction) {
      const act = pendingConfirmAction;
      pendingConfirmAction = null;
      act();
    }
  });
  $('#confirmCancelBtn').addEventListener('click', () => {
    $('#confirmOverlay').classList.remove('open');
    pendingConfirmAction = null;
  });

  /* New Folder Dialog Handlers */
  $('#newFolderConfirmBtn').addEventListener('click', submitNewFolder);
  $('#newFolderCancelBtn').addEventListener('click', () => $('#newFolderOverlay').classList.remove('open'));
  $('#newFolderInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') submitNewFolder(); });

  /* Video Resume Dialog Handlers */
  $('#vrResumeBtn').addEventListener('click', () => {
    $('#videoResumeOverlay').classList.remove('open');
    if (pendingResumeVideo) {
      const { e, rel, pos } = pendingResumeVideo;
      pendingResumeVideo = null;
      launchVideo(e, rel, pos);
    }
  });
  $('#vrRestartBtn').addEventListener('click', () => {
    $('#videoResumeOverlay').classList.remove('open');
    if (pendingResumeVideo) {
      const { e, rel } = pendingResumeVideo;
      pendingResumeVideo = null;
      launchVideo(e, rel, 0);
    }
  });
  $('#vrCancelBtn').addEventListener('click', () => {
    $('#videoResumeOverlay').classList.remove('open');
    pendingResumeVideo = null;
  });

  /* Unlock Dialog Handlers */
  $('#btnConfirmUnlock').addEventListener('click', submitUnlock);
  $('#btnCancelUnlock').addEventListener('click', () => {
    $('#unlockOverlay').classList.remove('open');
    pendingUnlockTarget = null;
  });
  $('#unlockPasswordInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') submitUnlock(); });
  $('#btnToggleUnlockPwd').addEventListener('click', () => {
    const inp = $('#unlockPasswordInput');
    inp.type = inp.type === 'password' ? 'text' : 'password';
  });
}

async function boot() {
  initEvents();

  const last = kvGet('last');
  const tk = last ? kvGet('token:' + last.baseUrl) : null;
  const creds = kvGet(kCreds()) || {};

  if (last && last.baseUrl && (tk || (creds.u && creds.p))) {
    try {
      let loggedIn = false;
      if (tk) {
        try {
          const d = await Promise.race([
            tryApi(last.baseUrl, '/api/me', 'GET', null, tk),
            new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 2500))
          ]);
          if (d && !d.error && (d.user || d.role)) {
            server = last;
            token = tk;
            me = { role: d.role || 'admin', user: d.user || 'admin' };
            loggedIn = true;
          }
        } catch (e) {}
      }
      if (!loggedIn && creds.u && creds.p) {
        try {
          const d = await Promise.race([
            tryApi(last.baseUrl, '/api/login', 'POST', { user: creds.u, password: creds.p }),
            new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 2500))
          ]);
          if (d && d.token) {
            server = last;
            token = d.token;
            me = { role: d.role || 'admin', user: creds.u || 'admin' };
            kvSet('token:' + server.baseUrl, token);
            loggedIn = true;
          }
        } catch (e) {}
      }

      if (loggedIn) {
        await enterMain();
        return;
      }
    } catch (e) {}
  }

  showConnectOverlay('discover');
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else {
  boot();
}

})();
