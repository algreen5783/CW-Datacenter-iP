/* CW Datacenter Tablet - app.js
 * Tối ưu hóa cho máy tính bảng Android (Tablet):
 * - Hỗ trợ đầy đủ Xoay ngang (Landscape) và Xoay dọc (Portrait).
 * - Cảm ứng đa điểm, chạm, vuốt, chạm giữ (Long press) để đánh dấu yêu thích ⭐.
 * - Master-Detail ở chế độ ngang, Bottom Sheet ở chế độ dọc.
 * - Tích hợp đầy đủ Native Bridge: Phát Video (nhớ vị trí phát), Xem Ảnh vuốt chạm, Đọc PDF, Tải xuống, Quét LAN.
 */
(() => {
  'use strict';

  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const enc = encodeURIComponent;
  const esc = (s) => String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  /* ---------- Adaptive Responsive Scaling & Orientation System ---------- */
  function adjustTabletOrientationAndScale() {
    const w = window.innerWidth || document.documentElement.clientWidth || 1280;
    const h = window.innerHeight || document.documentElement.clientHeight || 800;
    const isPortrait = h > w;

    document.body.classList.toggle('portrait', isPortrait);
    document.body.classList.toggle('landscape', !isPortrait);

    // Adaptive font-size based on smallest dimension
    const minDim = Math.min(w, h);
    const scale = Math.min(Math.max(minDim / 768, 0.8), 1.6);
    document.documentElement.style.fontSize = (15 * scale) + 'px';
  }

  window.addEventListener('resize', adjustTabletOrientationAndScale);
  window.addEventListener('orientationchange', () => setTimeout(adjustTabletOrientationAndScale, 120));
  adjustTabletOrientationAndScale();

  function ico(id, cls = '') {
    return `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true"><use href="#${id}"></use></svg>`;
  }

  function fmtBytes(bytes) {
    if (bytes == null || isNaN(bytes) || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  }

  function fmtTime(ms) {
    if (!ms || ms <= 0) return '00:00';
    let s = Math.floor(ms / 1000);
    const h = Math.floor(s / 3600);
    s %= 3600;
    const m = Math.floor(s / 60);
    const ss = s % 60;
    if (h > 0) {
      return `${h}:${m < 10 ? '0' : ''}${m}:${ss < 10 ? '0' : ''}${ss}`;
    }
    return `${m < 10 ? '0' : ''}${m}:${ss < 10 ? '0' : ''}${ss}`;
  }

  function timeAgo(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    const diff = Math.floor((Date.now() - d.getTime()) / 1000);
    if (diff < 60) return 'vừa xong';
    if (diff < 3600) return Math.floor(diff / 60) + ' phút trước';
    if (diff < 86400) return Math.floor(diff / 3600) + ' giờ trước';
    return Math.floor(diff / 86400) + ' ngày trước';
  }

  function shortenName(name, maxLen = 28) {
    if (!name || name.length <= maxLen) return name || '';
    const dotIdx = name.lastIndexOf('.');
    if (dotIdx > 0 && name.length - dotIdx <= 8) {
      const ext = name.slice(dotIdx);
      const base = name.slice(0, dotIdx);
      const avail = maxLen - ext.length - 2;
      if (avail > 3) {
        return base.slice(0, avail) + '…' + ext;
      }
    }
    return name.slice(0, maxLen - 1) + '…';
  }

  const STREAM_IMG = /\.(png|jpe?g|gif|webp|bmp|avif|svg|heic|heif)$/i;
  const STREAM_VIDEO = /\.(mp4|webm|mkv|mov|m4v|avi|3gp|3gpp|flv|wmv|mpg|mpeg|ts|m2ts|mts|vob|ogv|rm|rmvb)$/i;
  const STREAM_AUDIO = /\.(mp3|wav|ogg|m4a|flac|aac)$/i;
  const STREAM_PDF = /\.pdf$/i;

  function fileTypeInfo(name, isDir) {
    if (isDir) return { type: 'folder', icon: 'i-folder', label: 'Thư mục' };
    if (STREAM_VIDEO.test(name)) return { type: 'video', icon: 'i-video', label: 'Video' };
    if (STREAM_IMG.test(name)) return { type: 'image', icon: 'i-image', label: 'Ảnh' };
    if (STREAM_PDF.test(name)) return { type: 'pdf', icon: 'i-pdf', label: 'Tài liệu PDF' };
    if (STREAM_AUDIO.test(name)) return { type: 'audio', icon: 'i-play', label: 'Âm thanh' };
    return { type: 'file', icon: 'i-folder', label: 'Tệp tin' };
  }

  function showToast(msg, duration = 2800) {
    const el = document.getElementById('tvToast');
    if (!el) return;
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(el._timer);
    el._timer = setTimeout(() => el.classList.remove('show'), duration);
  }

  /* ---------- Native Bridge Plumbing ---------- */
  const cbs = new Map();
  let cbSeq = 0;

  function callNative(method, ...args) {
    return new Promise((res, rej) => {
      const id = String(++cbSeq);
      cbs.set(id, { res, rej });
      try {
        if (window.DC && typeof window.DC.call === 'function') {
          window.DC.call(method, id, JSON.stringify(args));
        } else {
          setTimeout(() => {
            cbs.delete(id);
            res(null);
          }, 100);
        }
      } catch (e) {
        cbs.delete(id);
        rej(e);
      }
    });
  }

  window.DC = window.DC || {};
  window.DC._cb = (id, ok, jsonStr) => {
    const c = cbs.get(String(id));
    if (!c) return;
    cbs.delete(String(id));
    let data = null;
    try { data = jsonStr ? JSON.parse(jsonStr) : {}; } catch (e) { data = { text: jsonStr }; }
    if (ok) c.res(data);
    else c.rej(new Error((data && (data.err || data.error)) || 'Lỗi xử lý'));
  };

  window.DC._evt = (jsonStr) => {
    try {
      const ev = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
      if (ev && ev.type === 'transfer') onTransferUpdate(ev);
    } catch (e) {}
  };

  function kvGet(k) {
    try {
      const v = localStorage.getItem(k);
      return v ? JSON.parse(v) : null;
    } catch (e) { return null; }
  }
  function kvSet(k, v) {
    try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {}
  }

  let META = {};
  try { if (window.DC && typeof window.DC.getMeta === 'function') META = JSON.parse(DC.getMeta()); } catch (e) {}

  function phoneName() {
    let n = String(META.device || META.manufacturer || 'Tablet').trim();
    n = n.replace(/[/\\?%*:|"<>]/g, '_');
    return n.slice(0, 40) || 'Tablet';
  }

  /* ---------- App State ---------- */
  let server = kvGet('tablet_server') || null;
  let token = kvGet('tablet_token') || '';
  let currentUser = kvGet('tablet_user') || null;
  let isViewer = currentUser && currentUser.role === 'viewer';
  let pools = [];
  let currentPool = '';
  let currentPath = '';
  let currentView = 'files';
  let entries = [];
  let selectedIndex = 0;
  let folderStack = [];
  let favorites = kvGet('tablet_favs') || [];
  let transfers = {};
  let searchQuery = '';
  let isPortraitDetailOpen = false;

  let syncUpQueue = [];
  let syncUpBusy = false;
  let syncPaused = false;
  let syncDbUp = kvGet('tablet_sync_db_up') || {};
  let camOn = kvGet('tablet_cam_sync') !== false;
  let syncSrcPath = kvGet('tablet_sync_src') || '';

  function saveSyncDbUp() { kvSet('tablet_sync_db_up', syncDbUp); }

  /* ---------- HTTP API via Native Bridge ---------- */
  async function api(path, method = 'GET', body = null) {
    if (!server || !server.baseUrl) throw new Error('Chưa kết nối máy chủ');
    const url = server.baseUrl + path;
    const headers = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = 'Bearer ' + token;

    const r = await callNative('invoke', method, url, JSON.stringify(headers), body ? JSON.stringify(body) : '');
    if (!r) throw new Error('Không nhận được phản hồi từ hệ thống');
    let data = {};
    try { data = r.text ? JSON.parse(r.text) : {}; } catch (e) { data = { text: r.text }; }
    if (r.status >= 400) {
      throw new Error(data.error || data.message || ('Lỗi máy chủ (HTTP ' + r.status + ')'));
    }
    return data;
  }

  /* ---------- Thumbnail URL Generator ---------- */
  function getThumbUrl(rel, pool, isVideo) {
    if (!server || !server.baseUrl) return '';
    try {
      if (window.DC && typeof window.DC.thumbUrl === 'function') {
        const u = window.DC.thumbUrl(enc(rel), pool ? enc(pool) : '');
        if (u) return u;
      }
    } catch (e) {}
    if (isVideo) {
      return `${server.baseUrl}/api/thumb?path=${enc(rel)}${pool ? '&pool=' + enc(pool) : ''}`;
    }
    return `${server.baseUrl}/api/file?path=${enc(rel)}${pool ? '&pool=' + enc(pool) : ''}&preview=1`;
  }

  /* ---------- Server Discovery & Login Logic ---------- */
  let isScanning = false;
  async function runLanDiscovery() {
    if (isScanning) return;
    isScanning = true;
    const hostListEl = document.getElementById('discoveredHostList');
    if (hostListEl) {
      hostListEl.innerHTML = '<div style="font-size:0.9rem;color:var(--text-muted);padding:1.5rem;text-align:center">Đang quét mạng LAN tìm máy chủ CW Datacenter…</div>';
    }

    try {
      const r = await callNative('discover', JSON.stringify({ timeoutMs: 2800 }));
      const hosts = (r && r.hosts) || [];
      renderDiscoveredHosts(hosts);
    } catch (e) {
      renderDiscoveredHosts([]);
    } finally {
      isScanning = false;
    }
  }

  function renderDiscoveredHosts(hosts) {
    const hostListEl = document.getElementById('discoveredHostList');
    if (!hostListEl) return;
    if (!hosts.length) {
      hostListEl.innerHTML = `
        <div style="padding:1.5rem 1rem;text-align:center;color:var(--text-muted);font-size:0.9rem;line-height:1.6">
          Chưa tìm thấy máy chủ tự động.<br>
          Hãy chắc chắn Host đang bật, hoặc bấm "Nhập IP Thủ công" bên dưới.
        </div>`;
      return;
    }

    hostListEl.innerHTML = hosts.map((h, i) => `
      <button class="scan-item" data-host-idx="${i}">
        <div class="scan-item-icon">${ico('i-db')}</div>
        <div style="flex:1;min-width:0;text-align:left">
          <div style="font-weight:700;font-size:1rem;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(h.host || h.name || h.ip)}</div>
          <div style="font-size:0.82rem;color:var(--text-muted);margin-top:0.2rem">${esc(h.ip)}${h.port && h.port !== 8080 ? ' :' + h.port : ''} · <span style="color:var(--green);font-weight:600">● Trực tuyến</span></div>
        </div>
        <div class="pill active" style="height:2.2rem;padding:0 1.1rem;font-size:0.85rem">Kết nối</div>
      </button>`).join('');

    hostListEl.querySelectorAll('.scan-item').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = Number(btn.dataset.hostIdx);
        const h = hosts[idx];
        if (h) selectHostForLogin(h);
      });
    });
  }

  function selectHostForLogin(h) {
    const ip = h.ip;
    const port = h.port || 8080;
    const name = h.host || h.name || ip;
    document.getElementById('targetHostTitle').textContent = name;
    document.getElementById('targetHostSub').textContent = `${ip}:${port} · LAN · Trực tuyến`;
    document.getElementById('serverIp').value = ip;
    document.getElementById('serverPort').value = port;

    showLoginPane('credentials');
  }

  function showLoginPane(pane) {
    document.getElementById('paneDiscover').style.display = pane === 'discover' ? 'block' : 'none';
    document.getElementById('paneCredentials').style.display = pane === 'credentials' ? 'block' : 'none';
    document.getElementById('paneManual').style.display = pane === 'manual' ? 'block' : 'none';

    setTimeout(() => {
      if (pane === 'credentials') {
        const u = document.getElementById('username');
        if (u) { u.focus(); callNative('showKeyboard'); }
      } else if (pane === 'manual') {
        const m = document.getElementById('manualIpInput');
        if (m) { m.focus(); callNative('showKeyboard'); }
      }
    }, 100);
  }

  async function doLogin(ip, port, user, pass) {
    if (!ip) {
      showToast('Vui lòng nhập địa chỉ IP');
      return;
    }
    const cleanIp = ip.trim();
    const cleanPort = parseInt(port, 10) || 8080;
    const baseUrl = `http://${cleanIp}:${cleanPort}`;

    showToast('Đang kết nối tới ' + baseUrl + '…');
    try {
      const res = await callNative('invoke', 'POST', baseUrl + '/api/login', JSON.stringify({ 'Content-Type': 'application/json' }), JSON.stringify({
        username: user || '',
        password: pass || '',
        device: 'Android Tablet'
      }));

      if (!res) throw new Error('Không thể gửi yêu cầu kết nối');
      let data = {};
      try { data = res.text ? JSON.parse(res.text) : {}; } catch (e) {}

      if (res.status >= 400 || !data.token) {
        throw new Error(data.error || data.message || ('Lỗi đăng nhập (HTTP ' + res.status + ')'));
      }

      token = data.token;
      currentUser = data.user || { username: user, role: data.role || 'user' };
      isViewer = (currentUser.role === 'viewer');
      kvSet('tablet_user', currentUser);

      server = {
        ip: cleanIp,
        port: cleanPort,
        baseUrl: baseUrl,
        host: data.host || cleanIp,
        name: data.name || cleanIp,
        via: cleanIp.startsWith('100.') ? 'tailscale' : 'lan'
      };

      kvSet('tablet_token', token);
      kvSet('tablet_server', server);

      try {
        if (window.DC && typeof window.DC.setSession === 'function') {
          window.DC.setSession(baseUrl, token);
        }
      } catch (e) {}

      applyUserRoleUI();
      updateHostUI(true, server.name, `${server.ip} · ${server.via === 'tailscale' ? 'Tailscale' : 'LAN'}`);
      closeLoginDialog();
      showToast('Đã kết nối thành công tới ' + server.name);

      await loadPools();
      await loadFiles('');
    } catch (err) {
      showToast('Lỗi kết nối: ' + err.message);
    }
  }

  function applyUserRoleUI() {
    const trashBtn = document.getElementById('navTrashBtn');
    const bTrashBtn = document.getElementById('bNavTrashBtn');
    if (trashBtn) trashBtn.style.display = isViewer ? 'none' : 'flex';
    if (bTrashBtn) bTrashBtn.style.display = isViewer ? 'none' : 'flex';
  }

  function updateHostUI(online, name, meta) {
    const dot = document.getElementById('hostDot');
    const nameEl = document.getElementById('hostName');
    const metaEl = document.getElementById('hostMeta');
    if (dot) dot.classList.toggle('offline', !online);
    if (nameEl) nameEl.textContent = name || 'CW-DATACENTER';
    if (metaEl) metaEl.textContent = meta || '';
  }

  function openLoginDialog() {
    const overlay = document.getElementById('connectOverlay');
    if (overlay) overlay.classList.add('open');
    showLoginPane('discover');
    runLanDiscovery();
  }

  function closeLoginDialog() {
    callNative('hideKeyboard');
    const overlay = document.getElementById('connectOverlay');
    if (overlay) overlay.classList.remove('open');
  }

  /* ---------- Server Lock Synchronization ---------- */
  let serverLocks = [];
  const lockSession = new Set();

  async function syncLocksFromServer() {
    if (!server || !token) return;
    try {
      const d = await api('/api/locks');
      serverLocks = (d && d.locks) || [];
      if (currentView === 'files') renderFiles();
    } catch (e) {
      serverLocks = [];
    }
  }

  function poolLockKey(pId) { return 'pool:' + (pId || 'main'); }
  function itemLockKey(pId, path) { return 'item:' + (pId || 'main') + ':' + (path || '').replace(/^\/+/, ''); }

  function isPoolLocked(pId) {
    if (!pId) return false;
    const l = serverLocks.find(x => x.pool === pId && (x.type === 'drive' || !x.path));
    if (!l) return false;
    return !lockSession.has(poolLockKey(pId));
  }

  function isItemLocked(item) {
    if (!item) return false;
    if (isPoolLocked(currentPool)) return true;
    const rel = relOf(item).replace(/^\/+/, '');
    const l = serverLocks.find(x => x.pool === currentPool && x.path === rel);
    if (!l) return false;
    return !lockSession.has(itemLockKey(currentPool, rel));
  }

  let activeUnlockTarget = null;
  let activeUnlockCallback = null;

  function promptUnlockDialog(target, onUnlock) {
    activeUnlockTarget = target;
    activeUnlockCallback = onUnlock;

    const overlay = document.getElementById('unlockOverlay');
    const titleEl = document.getElementById('unlockTitle');
    const subEl = document.getElementById('unlockSub');
    const input = document.getElementById('unlockPasswordInput');
    const errEl = document.getElementById('unlockErr');

    if (titleEl) titleEl.textContent = 'Mở khóa: ' + (target.name || 'Mục bảo vệ');
    if (subEl) subEl.textContent = target.isPool ? 'Ổ đĩa này đang bị khóa — nhập mật khẩu để truy cập.' : 'Mục này đang bị khóa — nhập mật khẩu để mở.';
    if (input) input.value = '';
    if (errEl) errEl.textContent = '';
    if (overlay) overlay.classList.add('open');
    setTimeout(() => { if (input) input.focus(); }, 120);
  }

  function closeUnlockDialog() {
    const overlay = document.getElementById('unlockOverlay');
    if (overlay) overlay.classList.remove('open');
    activeUnlockTarget = null;
    activeUnlockCallback = null;
  }

  async function submitUnlock() {
    if (!activeUnlockTarget) return;
    const input = document.getElementById('unlockPasswordInput');
    const errEl = document.getElementById('unlockErr');
    const pwd = input ? input.value.trim() : '';
    if (!pwd) {
      if (errEl) errEl.textContent = 'Vui lòng nhập mật khẩu';
      return;
    }

    try {
      const target = activeUnlockTarget;
      const res = await api('/api/locks/verify', 'POST', {
        pool: target.poolId || currentPool,
        path: target.path || '',
        type: target.isPool ? 'drive' : (target.isDir ? 'folder' : 'file'),
        password: pwd
      });

      if (res && res.ok) {
        if (target.isPool) lockSession.add(poolLockKey(target.poolId));
        else lockSession.add(itemLockKey(target.poolId || currentPool, target.path));

        closeUnlockDialog();
        showToast('🔓 Đã mở khóa thành công!');
        if (activeUnlockCallback) activeUnlockCallback();
        renderFiles();
      } else {
        if (errEl) errEl.textContent = 'Mật khẩu không chính xác!';
        if (input) { input.value = ''; input.focus(); }
      }
    } catch (e) {
      if (errEl) errEl.textContent = 'Lỗi xác thực: ' + (e.message || 'Mật khẩu sai');
    }
  }

  /* ---------- Storage Pools & Navigation ---------- */
  async function loadPools() {
    try {
      const d = await api('/api/pools');
      const all = d.pools || [];
      pools = all.filter(p => p.id !== 'shared' && !/^(shared|dùng chung|đã chia sẻ)$/i.test(p.name));
      if (!currentPool && pools.length > 0) {
        const def = pools.find(p => p.isDefault) || pools[0];
        currentPool = def.id;
      }
      await syncLocksFromServer();
    } catch (e) {
      pools = [{ id: 'main', name: 'Dữ liệu', free: 0, total: 0 }];
      currentPool = 'main';
    }
  }

  async function loadFiles(path = '') {
    currentPath = path;
    try {
      const pParam = currentPool ? '&pool=' + enc(currentPool) : '';
      const d = await api('/api/files?path=' + enc(path) + pParam);
      entries = d.entries || [];
    } catch (e) {
      showToast('Lỗi tải tệp: ' + e.message);
      entries = [];
    }
    selectedIndex = 0;
    renderFiles();
  }

  /* ---------- View Renderers ---------- */
  const main = document.getElementById('main');

  function topBarHtml(title, subtitle) {
    const isOnline = !!server;
    return `
      <div class="topbar">
        <div class="title-wrap">
          <h1>${title}</h1>
          <div class="subtitle"><span class="dot ${isOnline ? '' : 'offline'}"></span><span>${subtitle}</span></div>
        </div>
        <div class="top-actions">
          <button class="icon-btn" id="connectBtn" title="Kết nối máy chủ">${ico('i-db')}</button>
          <button class="icon-btn" id="refreshBtn" title="Làm mới">${ico('i-refresh')}</button>
        </div>
      </div>`;
  }

  function renderPoolBar() {
    let pills = [];
    const isSyncActive = currentPath === phoneName() || currentPath.startsWith(phoneName() + '/');
    pills.push(`<button class="pill ${isSyncActive ? 'active' : ''}" data-pool="sync_folder">${ico('i-sync')} Đồng bộ (${esc(phoneName())})</button>`);
    if (pools.length) {
      pools.forEach(p => {
        const isActive = p.id === currentPool && !isSyncActive;
        const freeStr = p.free ? ` · ${fmtBytes(p.free)} trống` : '';
        const locked = isPoolLocked(p.id);
        const lockIcon = locked ? `🔒 ` : '';
        pills.push(`<button class="pill ${isActive ? 'active' : ''} ${locked ? 'locked' : ''}" data-pool="${esc(p.id)}">${lockIcon}${esc(p.name)}${freeStr}</button>`);
      });
    }
    return pills.join('');
  }

  function relOf(item) {
    return (currentPath ? currentPath + '/' : '') + item.name;
  }

  function poolNameOf(id) {
    const p = pools.find(x => x.id === id);
    return p ? p.name : (id || 'Dữ liệu');
  }

  function isFavorited(item) {
    const rel = relOf(item);
    return favorites.some(f => f.rel === rel && f.pool === currentPool);
  }

  function toggleFavorite(item) {
    if (!item) return;
    const rel = relOf(item);
    const idx = favorites.findIndex(f => f.rel === rel && f.pool === currentPool);
    if (idx >= 0) {
      favorites.splice(idx, 1);
      showToast('⭐ Đã bỏ yêu thích: ' + item.name);
    } else {
      favorites.unshift({
        name: item.name,
        rel: rel,
        pool: currentPool,
        type: item.type,
        size: item.size || 0,
        mtime: item.mtime || ''
      });
      showToast('⭐ Đã thêm vào yêu thích: ' + item.name);
    }
    kvSet('tablet_favs', favorites);
    renderFiles();
  }

  function detailPaneHtml(i) {
    const item = entries[i];
    if (!item) {
      return `
        <div class="detail-close-bar">
          <span style="font-weight:700;font-size:0.9rem">Chi tiết mục</span>
          <button class="icon-btn" id="btnCloseDetailSheet" style="width:2.2rem;height:2.2rem">${ico('i-close')}</button>
        </div>
        <div style="padding:2rem;text-align:center;color:var(--text-muted);font-size:0.95rem">Chọn một tệp hoặc thư mục để xem chi tiết.</div>`;
    }

    const info = fileTypeInfo(item.name, item.type === 'dir');
    const isFolder = item.type === 'dir';
    const openLabel = isFolder ? 'Mở thư mục' : (info.type === 'video' || info.type === 'image' || info.type === 'pdf' || info.type === 'audio' ? 'Xem trực tiếp' : 'Mở tệp');
    const openIcon = isFolder ? 'i-folder' : 'i-play';

    const isFav = isFavorited(item);
    const favLabel = isFav ? 'Bỏ yêu thích' : 'Thêm yêu thích';

    const rel = relOf(item);
    let thumbUrl = '';
    if (info.type === 'image') thumbUrl = getThumbUrl(rel, currentPool, false);
    else if (info.type === 'video') thumbUrl = getThumbUrl(rel, currentPool, true);

    const previewContent = `
      <div class="thumb-fallback">${ico(info.icon)}</div>
      ${thumbUrl ? `<img src="${thumbUrl}" alt="${esc(item.name)}" onload="this.classList.add('loaded')" onerror="this.remove()" />` : ''}
      ${info.type === 'video' ? `<div class="preview-play-overlay">${ico('i-play')}</div>` : ''}`;

    return `
      <div class="detail-close-bar">
        <span style="font-weight:700;font-size:0.9rem">Chi tiết mục</span>
        <button class="icon-btn" id="btnCloseDetailSheet" style="width:2.2rem;height:2.2rem">${ico('i-close')}</button>
      </div>
      <div class="section-label" style="display:none">CHI TIẾT</div>
      <div class="preview">${previewContent}</div>
      <div class="detail-name" title="${esc(item.name)}">${esc(item.name)}</div>
      <div class="detail-meta">
        ${info.label} ${item.size ? ' · ' + fmtBytes(item.size) : ''}<br>
        ${item.mtime ? 'Đã sửa: ' + timeAgo(item.mtime) + '<br>' : ''}
        Máy chủ: <b>${esc(server ? server.name : 'CW Datacenter')}</b> · Ổ: <b>${esc(poolNameOf(currentPool))}</b>
      </div>
      <div class="action-list">
        <button class="action-btn primary" id="btnDetailOpen" data-open-idx="${i}">
          ${ico(openIcon)}<span>${openLabel}</span>
        </button>
        ${!isFolder ? `
          <button class="action-btn" id="btnDetailDownload" data-action="download">
            ${ico('i-download')}<span>Tải xuống</span>
          </button>
        ` : ''}
        <button class="action-btn" id="btnDetailFav" data-action="fav">
          ${ico('i-star')}<span>${favLabel}</span>
        </button>
        ${!isViewer ? `
          <button class="action-btn" id="btnDetailTrash" data-action="trash">
            ${ico('i-trash')}<span>Xóa vào thùng rác</span>
          </button>
        ` : ''}
      </div>`;
  }

  function renderFiles() {
    let list = entries;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      list = list.filter(e => e.name.toLowerCase().includes(q));
    }

    const cardsHtml = list.length ? list.map((f, i) => {
      const info = fileTypeInfo(f.name, f.type === 'dir');
      const isFav = isFavorited(f);
      const isSel = i === selectedIndex;
      const rel = relOf(f);

      let thumbUrl = '';
      if (info.type === 'image') thumbUrl = getThumbUrl(rel, currentPool, false);
      else if (info.type === 'video') thumbUrl = getThumbUrl(rel, currentPool, true);

      const displayName = shortenName(f.name, 28);

      return `
        <div class="file-card ${isSel ? 'selected' : ''}" data-idx="${i}" title="${esc(f.name)}">
          ${isFav ? '<span class="star">★</span>' : ''}
          <div class="file-thumb-wrap ${info.type}">
            <div class="thumb-fallback">${ico(info.icon)}</div>
            ${thumbUrl ? `<img src="${thumbUrl}" loading="lazy" onload="this.classList.add('loaded')" onerror="this.remove()" />` : ''}
            ${info.type === 'video' ? `<div class="video-badge">${ico('i-play')} <span>Video</span></div>` : ''}
          </div>
          <div class="file-name" title="${esc(f.name)}">${esc(displayName)}</div>
          <div class="file-meta">${f.type === 'dir' ? 'Thư mục' : fmtBytes(f.size)}</div>
        </div>`;
    }).join('') : `<div style="grid-column:1/-1;padding:3rem 1rem;text-align:center;color:var(--text-muted);font-size:1.05rem">Thư mục trống.</div>`;

    const breadcrumbs = folderStack.length ? `
      <div class="folder-header">
        <button class="back-btn" id="folderBack">${ico('i-back')}<span>Quay lại</span></button>
        <div class="breadcrumb">
          <span>${esc(server ? server.name : 'CW Datacenter')}</span><span>/</span>
          ${folderStack.map((x, idx) => `<span class="${idx === folderStack.length - 1 ? 'current' : ''}">${esc(x.name)}</span>${idx < folderStack.length - 1 ? '<span>/</span>' : ''}`).join('')}
        </div>
      </div>` : '';

    const pathText = folderStack.length
      ? `${esc(server ? server.name : 'CW Datacenter')} / ${folderStack.map(x => esc(x.name)).join(' / ')}`
      : `${esc(server ? server.name : 'CW Datacenter')} / ${esc(poolNameOf(currentPool))}`;

    main.innerHTML = `
      ${topBarHtml('Tệp', server ? 'Đã kết nối tới ' + server.name : 'Chưa kết nối máy chủ')}
      <div class="toolbar">
        <div class="pool-list">${renderPoolBar()}</div>
        <div class="search-box" id="searchWrap">
          ${ico('i-search')}
          <input type="text" id="searchInput" placeholder="Tìm kiếm tệp và thư mục…" value="${esc(searchQuery)}">
        </div>
      </div>
      <section class="view-body">
        <div class="files-layout">
          <div class="files-pane">
            ${breadcrumbs}
            <div class="section-label">${pathText}</div>
            <div class="files-scroll" id="filesScroll">
              <div class="file-grid" id="fileGrid">${cardsHtml}</div>
            </div>
          </div>
          <aside class="detail-pane ${isPortraitDetailOpen ? 'open' : ''}" id="detailPane">${detailPaneHtml(selectedIndex)}</aside>
        </div>
      </section>`;

    bindCommonEvents();
    bindFilesEvents();
    bindInputKeyboardEvents();
  }

  function bindInputKeyboardEvents() {
    document.querySelectorAll('input').forEach(inp => {
      inp.addEventListener('focus', () => {
        callNative('showKeyboard');
      });
      inp.addEventListener('click', () => {
        inp.focus();
        callNative('showKeyboard');
      });
    });
  }

  function bindCommonEvents() {
    const connBtn = document.getElementById('connectBtn');
    if (connBtn) connBtn.addEventListener('click', openLoginDialog);

    const refBtn = document.getElementById('refreshBtn');
    if (refBtn) refBtn.addEventListener('click', () => {
      showToast('Đang làm mới…');
      if (currentView === 'files') loadFiles(currentPath);
      else if (currentView === 'transfers') renderTransfers();
      else if (currentView === 'favorites') renderFavorites();
      else if (currentView === 'trash') loadTrash();
    });

    const hostBox = document.getElementById('hostBox');
    if (hostBox) hostBox.addEventListener('click', openLoginDialog);
  }

  function bindFilesEvents() {
    const poolBtns = document.querySelectorAll('.pool-list .pill');
    poolBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const pid = btn.dataset.pool;
        if (pid === 'sync_folder') {
          const def = pools.find(p => p.isDefault) || pools[0] || { id: 'main' };
          currentPool = def.id;
          folderStack = [{ name: phoneName(), path: phoneName() }];
          loadFiles(phoneName());
          return;
        }
        if (isPoolLocked(pid)) {
          const targetPool = pools.find(x => x.id === pid) || { id: pid, name: pid };
          promptUnlockDialog({ name: targetPool.name, poolId: pid, isPool: true }, () => {
            currentPool = pid;
            folderStack = [];
            loadFiles('');
          });
          return;
        }
        if (pid === currentPool && folderStack.length === 0) return;
        currentPool = pid;
        folderStack = [];
        loadFiles('');
      });
    });

    const backBtn = document.getElementById('folderBack');
    if (backBtn) backBtn.addEventListener('click', goBackFolder);

    const cards = document.querySelectorAll('.file-card');
    cards.forEach(card => {
      let touchTimer = null;
      let longPressed = false;
      let lastTapTime = 0;

      // Touch / mouse long-press to Favorite
      const startPress = () => {
        longPressed = false;
        touchTimer = setTimeout(() => {
          longPressed = true;
          const idx = Number(card.dataset.idx);
          toggleFavorite(entries[idx]);
        }, 500);
      };
      const cancelPress = () => {
        if (touchTimer) clearTimeout(touchTimer);
      };

      card.addEventListener('mousedown', startPress);
      card.addEventListener('mouseup', (e) => {
        cancelPress();
        if (longPressed) e.preventDefault();
      });
      card.addEventListener('touchstart', startPress, { passive: true });
      card.addEventListener('touchend', cancelPress);
      card.addEventListener('touchcancel', cancelPress);

      card.addEventListener('click', (e) => {
        if (longPressed) {
          longPressed = false;
          return;
        }
        const idx = Number(card.dataset.idx);
        const now = Date.now();
        const isDoubleTap = (now - lastTapTime < 350);
        lastTapTime = now;

        if (isDoubleTap || (document.body.classList.contains('landscape') && idx === selectedIndex)) {
          openItem(idx);
        } else {
          selectCard(idx);
          if (document.body.classList.contains('portrait')) {
            openPortraitDetailSheet();
          }
        }
      });
    });

    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        searchQuery = e.target.value;
        renderFiles();
      });
    }

    bindDetailEvents();
  }

  function openPortraitDetailSheet() {
    isPortraitDetailOpen = true;
    const dPane = document.getElementById('detailPane');
    if (dPane) dPane.classList.add('open');
  }

  function closePortraitDetailSheet() {
    isPortraitDetailOpen = false;
    const dPane = document.getElementById('detailPane');
    if (dPane) dPane.classList.remove('open');
  }

  function selectCard(idx) {
    selectedIndex = idx;
    document.querySelectorAll('.file-card').forEach((c, i) => {
      c.classList.toggle('selected', i === idx);
    });
    const dPane = document.getElementById('detailPane');
    if (dPane) dPane.innerHTML = detailPaneHtml(idx);
    bindDetailEvents();
  }

  function bindDetailEvents() {
    const closeBtn = document.getElementById('btnCloseDetailSheet');
    if (closeBtn) closeBtn.addEventListener('click', closePortraitDetailSheet);

    const openBtn = document.getElementById('btnDetailOpen');
    if (openBtn) {
      openBtn.addEventListener('click', () => {
        openItem(Number(openBtn.dataset.openIdx));
      });
    }

    const favBtn = document.getElementById('btnDetailFav');
    if (favBtn) {
      favBtn.addEventListener('click', () => {
        const item = entries[selectedIndex];
        if (item) toggleFavorite(item);
      });
    }

    const dlBtn = document.getElementById('btnDetailDownload');
    if (dlBtn) {
      dlBtn.addEventListener('click', () => {
        const item = entries[selectedIndex];
        if (item) startDownload(item);
      });
    }

    const trashBtn = document.getElementById('btnDetailTrash');
    if (trashBtn) {
      trashBtn.addEventListener('click', async () => {
        const item = entries[selectedIndex];
        if (!item) return;
        try {
          await api('/api/file?path=' + enc(relOf(item)) + '&pool=' + enc(currentPool), 'DELETE');
          showToast('Đã chuyển vào thùng rác: ' + item.name);
          closePortraitDetailSheet();
          loadFiles(currentPath);
        } catch (e) {
          showToast('Lỗi xóa: ' + e.message);
        }
      });
    }
  }

  /* ---------- Video Resume Choice Logic ---------- */
  let pendingVideoItem = null;
  let pendingVideoPlaylist = null;
  let pendingVideoIndex = 0;
  let pendingVideoPos = 0;

  function promptVideoResume(item, pos, playlist, plIndex) {
    pendingVideoItem = item;
    pendingVideoPlaylist = playlist;
    pendingVideoIndex = plIndex;
    pendingVideoPos = pos;

    const overlay = document.getElementById('videoResumeOverlay');
    const titleEl = document.getElementById('vrTitle');
    const subEl = document.getElementById('vrSub');
    const resumeLabel = document.getElementById('vrResumeLabel');

    if (titleEl) titleEl.textContent = shortenName(item.name, 30);
    if (subEl) subEl.innerHTML = `Bạn đã xem video này đến <b>${fmtTime(pos)}</b>.<br>Bạn muốn xem tiếp hay phát lại từ đầu?`;
    if (resumeLabel) resumeLabel.textContent = `▶ Xem tiếp (từ ${fmtTime(pos)})`;

    if (overlay) overlay.classList.add('open');
  }

  function closeVideoResume() {
    const overlay = document.getElementById('videoResumeOverlay');
    if (overlay) overlay.classList.remove('open');
    pendingVideoItem = null;
  }

  document.getElementById('vrResumeBtn').addEventListener('click', () => {
    if (!pendingVideoItem) return;
    const item = pendingVideoItem;
    const playlist = pendingVideoPlaylist;
    const plIndex = pendingVideoIndex;
    const pos = pendingVideoPos;
    closeVideoResume();
    launchVideo(item, playlist, plIndex, pos);
  });

  document.getElementById('vrRestartBtn').addEventListener('click', () => {
    if (!pendingVideoItem) return;
    const item = pendingVideoItem;
    const playlist = pendingVideoPlaylist;
    const plIndex = pendingVideoIndex;
    closeVideoResume();
    launchVideo(item, playlist, plIndex, 0);
  });

  document.getElementById('vrCancelBtn').addEventListener('click', closeVideoResume);

  function launchVideo(item, playlist, plIndex, startPos) {
    const rel = relOf(item);
    callNative('playVideo', JSON.stringify({
      rel,
      pool: currentPool,
      name: item.name,
      size: item.size || 0,
      startPos: startPos != null ? startPos : -1,
      plIndex: plIndex >= 0 ? plIndex : 0,
      playlist: (playlist && playlist.length > 1) ? playlist : undefined
    })).catch(err => showToast('Lỗi mở video: ' + err.message));
  }

  /* ---------- File Opening & Media Launchers ---------- */
  async function openItem(idx) {
    const item = entries[idx];
    if (!item) return;

    if (isItemLocked(item)) {
      const rel = relOf(item);
      promptUnlockDialog({ name: item.name, poolId: currentPool, path: rel, isPool: false, isDir: item.type === 'dir' }, () => {
        openItem(idx);
      });
      return;
    }

    if (item.type === 'dir') {
      folderStack.push({
        name: item.name,
        path: currentPath
      });
      const nextPath = (currentPath ? currentPath + '/' : '') + item.name;
      loadFiles(nextPath);
      return;
    }

    const rel = relOf(item);
    const info = fileTypeInfo(item.name, false);

    if (info.type === 'video') {
      const videoList = entries.filter(e => e.type !== 'dir' && STREAM_VIDEO.test(e.name));
      const plIdx = videoList.findIndex(x => x.name === item.name);
      const playlist = videoList.map(v => {
        const vRel = (currentPath ? currentPath + '/' : '') + v.name;
        const vUrl = `${server.baseUrl}/api/video?path=${enc(vRel)}&pool=${enc(currentPool)}`;
        return { name: v.name, url: vUrl, size: v.size || 0 };
      });

      // Check if there is saved progress > 5 seconds
      try {
        const directUrl = `${server.baseUrl}/api/video?path=${enc(rel)}&pool=${enc(currentPool)}`;
        const r = await callNative('getVideoProgress', JSON.stringify({ name: item.name, url: directUrl }));
        if (r && r.pos > 5000) {
          promptVideoResume(item, r.pos, playlist, plIdx);
          return;
        }
      } catch (e) {}

      launchVideo(item, playlist, plIdx, -1);
      return;
    }

    if (info.type === 'image') {
      const imgList = entries.filter(e => e.type !== 'dir' && STREAM_IMG.test(e.name));
      let initialIndex = imgList.findIndex(x => x.name === item.name);
      if (initialIndex < 0) initialIndex = 0;

      const playlist = imgList.map(x => {
        const xRel = (currentPath ? currentPath + '/' : '') + x.name;
        const directUrl = `${server.baseUrl}/api/file?path=${enc(xRel)}&pool=${enc(currentPool)}`;
        return {
          name: x.name,
          url: directUrl,
          size: x.size || 0,
          rel: xRel,
          pool: currentPool,
          mtime: x.mtime || ''
        };
      });

      const directUrl = `${server.baseUrl}/api/file?path=${enc(rel)}&pool=${enc(currentPool)}`;
      callNative('openPhoto', JSON.stringify({
        url: directUrl,
        name: item.name,
        token: token,
        playlist: JSON.stringify(playlist),
        initialIndex: initialIndex,
        baseUrl: server.baseUrl,
        pool: currentPool
      })).catch(err => showToast('Lỗi mở ảnh: ' + err.message));
      return;
    }

    if (info.type === 'pdf') {
      callNative('openPdf', JSON.stringify({
        rel,
        pool: currentPool,
        name: item.name,
        size: item.size || 0
      })).catch(err => showToast('Lỗi mở PDF: ' + err.message));
      return;
    }

    startDownload(item);
  }

  function goBackFolder() {
    if (!folderStack.length) return false;
    const prev = folderStack.pop();
    loadFiles(prev.path || '');
    return true;
  }

  function startDownload(item) {
    const rel = relOf(item);
    const url = `${server.baseUrl}/api/file?path=${enc(rel)}&pool=${enc(currentPool)}`;
    const spec = {
      url,
      name: item.name,
      headers: JSON.stringify(token ? { Authorization: 'Bearer ' + token } : {}),
      sync: false
    };
    showToast('Bắt đầu tải xuống: ' + item.name);
    callNative('download', JSON.stringify(spec)).catch(e => showToast('Lỗi tải xuống: ' + e.message));
  }

  /* ---------- Transfers View ---------- */
  function onTransferUpdate(ev) {
    if (!ev || !ev.id) return;
    transfers[ev.id] = ev;
    bumpSyncUpIfMatch(ev);
    if (currentView === 'transfers') renderTransfers();
    else if (currentView === 'sync') renderSync();
  }

  function renderTransfers() {
    const list = Object.values(transfers);
    const active = list.filter(t => t.status === 'active');
    const done = list.filter(t => t.status === 'done');
    const speedTotal = active.reduce((a, b) => a + (b.speed || 0), 0);

    const rowsHtml = list.length ? list.map(t => {
      const pc = t.total ? Math.floor((t.done || 0) * 100 / t.total) : 0;
      const isDone = t.status === 'done';
      return `
        <div class="row">
          <div class="row-icon">${ico(t.dir === 'up' ? 'i-sync' : 'i-download')}</div>
          <div style="min-width:0">
            <div class="row-name">${esc(t.name || 'Tệp')}</div>
            <div class="progress"><span style="width:${isDone ? 100 : pc}%"></span></div>
            <div class="row-meta">${fmtBytes(t.done || 0)} / ${fmtBytes(t.total || 0)} · ${isDone ? 'Hoàn tất' : (t.status === 'error' ? 'Lỗi' : 'Đang truyền')}</div>
          </div>
          <div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${t.speed ? fmtBytes(t.speed) + '/s' : '—'}</div>
          <div style="color:var(--green);text-align:right">${isDone ? '✓ Hoàn tất' : pc + '%'}</div>
        </div>`;
    }).join('') : `<div style="padding:3rem 1rem;text-align:center;color:var(--text-muted);font-size:1rem">Không có truyền tải nào đang chạy.</div>`;

    main.innerHTML = `
      ${topBarHtml('Truyền tải', 'Theo dõi tải xuống và tải lên')}
      <section class="view-body">
        <div class="stats">
          <div class="stat"><div class="stat-label">ĐANG CHẠY</div><div class="stat-value">${active.length}</div></div>
          <div class="stat"><div class="stat-label">HOÀN TẤT</div><div class="stat-value">${done.length}</div></div>
          <div class="stat"><div class="stat-label">TỐC ĐỘ HIỆN TẠI</div><div class="stat-value">${fmtBytes(speedTotal)}/s</div></div>
        </div>
        <div class="section-label">DANH SÁCH TRUYỀN TẢI</div>
        <div class="list">${rowsHtml}</div>
      </section>`;

    bindCommonEvents();
  }

  /* ---------- Favorites View ---------- */
  function renderFavorites() {
    const rowsHtml = favorites.length ? favorites.map((f, i) => {
      const info = fileTypeInfo(f.name, f.type === 'dir');
      return `
        <div class="row" data-fav-idx="${i}">
          <div class="row-icon">${ico(info.icon)}</div>
          <div style="min-width:0">
            <div class="row-name">${esc(f.name)}</div>
            <div class="row-meta">${esc(f.pool || 'Dữ liệu')} / ${esc(f.rel || '')}</div>
          </div>
          <div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${f.size ? fmtBytes(f.size) : 'Thư mục'}</div>
          <div style="color:#f59e0b;text-align:right">★ Đã ghim</div>
        </div>`;
    }).join('') : `<div style="padding:3rem 1rem;text-align:center;color:var(--text-muted);font-size:1rem">Chưa có mục nào trong danh sách yêu thích.</div>`;

    main.innerHTML = `
      ${topBarHtml('Yêu thích', 'Truy cập nhanh các mục đã đánh dấu')}
      <section class="view-body">
        <div class="stats">
          <div class="stat"><div class="stat-label">TỆP ĐÃ GHIM</div><div class="stat-value">${favorites.filter(x => x.type !== 'dir').length}</div></div>
          <div class="stat"><div class="stat-label">THƯ MỤC ĐÃ GHIM</div><div class="stat-value">${favorites.filter(x => x.type === 'dir').length}</div></div>
          <div class="stat"><div class="stat-label">TỔNG MỤC</div><div class="stat-value">${favorites.length}</div></div>
        </div>
        <div class="section-label">TRUY CẬP NHANH</div>
        <div class="list">${rowsHtml}</div>
      </section>`;

    bindCommonEvents();

    document.querySelectorAll('.row[data-fav-idx]').forEach(btn => {
      btn.addEventListener('click', () => {
        const f = favorites[Number(btn.dataset.favIdx)];
        if (!f) return;
        currentPool = f.pool || currentPool;
        if (f.type === 'dir') {
          currentView = 'files';
          updateNavState();
          folderStack = [];
          loadFiles(f.rel);
        } else {
          const info = fileTypeInfo(f.name, false);
          if (info.type === 'video') {
            callNative('playVideo', JSON.stringify({
              rel: f.rel,
              pool: f.pool,
              name: f.name,
              size: f.size || 0
            }));
          } else if (info.type === 'image') {
            const directUrl = `${server.baseUrl}/api/file?path=${enc(f.rel)}&pool=${enc(f.pool)}`;
            callNative('openPhoto', JSON.stringify({
              url: directUrl,
              name: f.name,
              token: token,
              baseUrl: server.baseUrl,
              pool: f.pool
            }));
          }
        }
      });
    });
  }

  /* ---------- Trash View ---------- */
  let trashItems = [];
  async function loadTrash() {
    if (isViewer) {
      trashItems = [];
      renderTrash();
      return;
    }
    try {
      const d = await api('/api/trash');
      trashItems = d.items || [];
    } catch (e) {
      trashItems = [];
    }
    renderTrash();
  }

  function renderTrash() {
    const totalSize = trashItems.reduce((a, b) => a + (b.size || 0), 0);
    const rowsHtml = trashItems.length ? trashItems.map((it, i) => {
      const info = fileTypeInfo(it.name, it.type === 'dir');
      return `
        <div class="row" data-trash-id="${esc(it.id)}">
          <div class="row-icon">${ico(info.icon)}</div>
          <div style="min-width:0">
            <div class="row-name">${esc(it.name)}</div>
            <div class="row-meta">${esc(it.name)} · Đã xóa ${timeAgo(it.deletedAt)}</div>
          </div>
          <div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${it.size ? fmtBytes(it.size) : 'Thư mục'}</div>
          <div style="color:var(--blue);text-align:right">Khôi phục ↺</div>
        </div>`;
    }).join('') : `<div style="padding:3rem 1rem;text-align:center;color:var(--text-muted);font-size:1rem">${isViewer ? 'Bạn không có quyền truy cập Thùng rác.' : 'Thùng rác đang trống.'}</div>`;

    main.innerHTML = `
      ${topBarHtml('Thùng rác', 'Các mục đã xóa trong 30 ngày')}
      <section class="view-body">
        <div class="stats">
          <div class="stat"><div class="stat-label">TỔNG SỐ MỤC</div><div class="stat-value">${trashItems.length}</div></div>
          <div class="stat"><div class="stat-label">DUNG LƯỢNG</div><div class="stat-value">${fmtBytes(totalSize)}</div></div>
          <div class="stat"><div class="stat-label">TỰ ĐỘNG DỌN DẸP</div><div class="stat-value">30 ngày</div></div>
        </div>
        <div class="section-label">MỤC ĐÃ XÓA GẦN ĐÂY</div>
        <div class="list">${rowsHtml}</div>
        ${!isViewer ? `
          <div class="action-list" style="flex-direction:row;margin-top:1rem">
            <button class="action-btn" id="btnPurgeTrash" style="width:auto;padding:0 1.2rem"><span>Dọn sạch thùng rác</span></button>
          </div>
        ` : ''}
      </section>`;

    bindCommonEvents();

    document.querySelectorAll('.row[data-trash-id]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id = btn.dataset.trashId;
        try {
          await api('/api/trash/restore', 'POST', { id });
          showToast('Đã khôi phục thành công!');
          loadTrash();
        } catch (e) {
          showToast('Lỗi khôi phục: ' + e.message);
        }
      });
    });

    const purgeBtn = document.getElementById('btnPurgeTrash');
    if (purgeBtn) {
      purgeBtn.addEventListener('click', async () => {
        try {
          await api('/api/trash/purge', 'POST', {});
          showToast('Đã dọn sạch thùng rác');
          loadTrash();
        } catch (e) {
          showToast('Lỗi dọn rác: ' + e.message);
        }
      });
    }
  }

  /* ---------- Sync View (Tablet) ---------- */
  async function syncNow() {
    if (!server || !token) { showToast('Chưa kết nối máy chủ'); return; }
    try {
      const st = await callNative('localFsStatus', '');
      if (!st || !st.ok) {
        await callNative('requestLocalFsAccess', '');
        showToast('Vui lòng cấp quyền truy cập bộ nhớ thiết bị.');
        return;
      }
      const defPool = pools.find(p => p.isDefault) || pools[0] || { id: 'main' };
      const rootInfo = await callNative('localFsInfo', '');
      const rootPath = (rootInfo && rootInfo.rootPath) || '/storage/emulated/0';
      const scanDir = syncSrcPath || (rootPath + '/DCIM/Camera');
      
      showToast('Đang quét và so khớp dữ liệu với máy chủ…');
      const d = await callNative('localFsDeepList', JSON.stringify({ path: scanDir, limit: 10000 }));
      const files = (d && d.files) || [];
      if (!files.length) { showToast('Thư mục đồng bộ đang trống.'); return; }

      const phoneFolder = phoneName();
      const isCam = scanDir.endsWith('Camera');
      const destFolderOnHost = isCam ? (phoneFolder + '/Camera') : phoneFolder;

      // Quét đối chiếu danh sách file đang có sẵn trên Host
      let hostFiles = [];
      try {
        const hRes = await api('/api/files/deep?path=' + enc(destFolderOnHost) + '&pool=' + enc(defPool.id));
        hostFiles = (hRes && hRes.files) || [];
      } catch (e) {
        hostFiles = [];
      }
      const hostMap = new Map();
      hostFiles.forEach(hf => {
        if (hf && hf.rel) hostMap.set(hf.rel.replace(/\\/g, '/').toLowerCase(), hf);
      });

      let skipped = 0;
      let fresh = 0;
      files.forEach(f => {
        const rel = isCam ? ('Camera/' + f.rel) : f.rel;
        if (syncUpQueue.some(q => q.rel === rel)) return;
        const exist = hostMap.get(f.rel.toLowerCase());
        if (exist && (exist.size === f.size || Math.abs(exist.size - (f.size || 0)) < 50)) {
          syncDbUp[rel] = { size: f.size || exist.size, mtime: f.mtime || exist.mtime || 0 };
          skipped++;
          return;
        }
        const cur = syncDbUp[rel];
        if (cur && cur.size === f.size && (cur.mtime === f.mtime || Math.abs((cur.mtime || 0) - (f.mtime || 0)) < 5000 || (!f.mtime && cur.size > 0))) return;
        syncUpQueue.push({ p: f.p, rel, size: f.size || 0, mtime: f.mtime || 0, pool: defPool.id, phoneFolder, sharePrefix: '' });
        fresh++;
      });
      saveSyncDbUp();

      if (!fresh) {
        if (skipped > 0) {
          showToast('Tất cả ' + skipped + ' tệp đã có sẵn trên máy chủ (đã bỏ qua, không tải lại).');
        } else {
          showToast('Mọi tệp đã được đồng bộ đầy đủ lên máy chủ.');
        }
        if (currentView === 'sync') renderSync();
        return;
      }
      syncPaused = false;
      if (skipped > 0) {
        showToast('Đã bỏ qua ' + skipped + ' tệp có sẵn. Đang gửi ' + fresh + ' tệp mới lên máy chủ…');
      } else {
        showToast('Bắt đầu đồng bộ ' + fresh + ' tệp lên máy chủ…');
      }
      runSyncUpQueue();
      if (currentView === 'sync') renderSync();
    } catch (e) {
      showToast('Lỗi đồng bộ: ' + (e.message || e));
    }
  }

  function runSyncUpQueue() {
    if (syncUpBusy || syncPaused) return;
    const next = syncUpQueue[0];
    if (!next) { if (currentView === 'sync') renderSync(); return; }
    syncUpBusy = true;
    const key = 'up:sync:' + next.rel + ':' + (next.pool || '');
    const relFull = next.phoneFolder + '/' + next.rel;
    const nm = next.rel.split('/').pop();
    transfers[key] = { key, dir: 'up', name: nm, rel: relFull, pool: next.pool, status: 'active', done: 0, total: next.size || 0, speed: 0, spec: { file: next.p, syncUp: true } };
    callNative('upload', JSON.stringify({ baseUrl: server.baseUrl, token, pool: next.pool, path: relFull, name: nm, file: next.p }))
      .then(res => { if (transfers[key]) transfers[key].id = res.id; })
      .catch(() => {
        if (transfers[key]) transfers[key].status = 'error';
        syncUpBusy = false;
        syncUpQueue.shift();
        setTimeout(runSyncUpQueue, 600);
      });
  }

  function bumpSyncUpIfMatch(t) {
    if (!t || !t.spec || !t.spec.syncUp) return false;
    const q = syncUpQueue[0];
    if (q && t.key === 'up:sync:' + q.rel + ':' + (q.pool || '')) {
      if (t.status === 'done' || t.status === 'error') {
        if (t.status === 'done') {
          syncDbUp[q.rel] = { size: q.size || t.total, mtime: q.mtime || 0 };
          saveSyncDbUp();
        }
        syncUpQueue.shift();
        syncUpBusy = false;
        setTimeout(runSyncUpQueue, 300);
        return true;
      }
    }
    return false;
  }

  function renderSync() {
    const syncedCount = Object.keys(syncDbUp).length;
    const queueCount = syncUpQueue.length;
    const phoneFolder = phoneName();

    const rowsHtml = `
      <div class="row" id="btnSyncFolderRow" style="cursor:pointer">
        <div class="row-icon">${ico('i-folder')}</div>
        <div style="min-width:0">
          <div class="row-name">Thư mục máy chủ</div>
          <div class="row-meta">Lưu trực tiếp tại: <b>${esc(phoneFolder)}/</b> trên ổ đĩa mặc định của Host</div>
        </div>
        <div class="action-btn" style="width:auto;padding:0.4rem 0.9rem;font-size:0.85rem">Mở trên Host ➜</div>
      </div>
      <div class="row">
        <div class="row-icon">${ico('i-cloud')}</div>
        <div style="min-width:0">
          <div class="row-name">Sao lưu ảnh Camera</div>
          <div class="row-meta">Tự động đẩy DCIM/Camera lên thư mục <b>${esc(phoneFolder)}/Camera</b></div>
        </div>
        <div class="pill ${camOn ? 'active' : ''}" id="btnToggleCamSync" style="cursor:pointer">${camOn ? 'BẬT' : 'TẮT'}</div>
      </div>
      <div class="row">
        <div class="row-icon">${ico('i-sync')}</div>
        <div style="min-width:0">
          <div class="row-name">Nguồn đồng bộ thiết bị</div>
          <div class="row-meta">${syncSrcPath ? esc(syncSrcPath) : 'Mặc định (DCIM/Camera)'}</div>
        </div>
        <div class="pill active" id="btnSelectSyncSrc" style="cursor:pointer">Chọn thư mục</div>
      </div>`;

    main.innerHTML = `
      ${topBarHtml('Đồng bộ', 'Đồng bộ 1 chiều từ máy tính bảng lên máy chủ')}
      <section class="view-body">
        <div class="stats">
          <div class="stat"><div class="stat-label">ĐÃ ĐỒNG BỘ</div><div class="stat-value">${syncedCount}</div></div>
          <div class="stat"><div class="stat-label">HÀNG ĐỢI</div><div class="stat-value">${queueCount}</div></div>
          <div class="stat"><div class="stat-label">TRẠNG THÁI</div><div class="stat-value" style="color:var(--green)">${syncPaused ? 'Tạm dừng' : (syncUpBusy ? 'Đang chạy' : 'Sẵn sàng')}</div></div>
        </div>
        <div class="section-label">TỔNG QUAN ĐỒNG BỘ</div>
        <div class="list">${rowsHtml}</div>
        <div class="action-list" style="flex-direction:row;margin-top:1.2rem;gap:0.8rem">
          <button class="action-btn primary" id="btnSyncNow" style="flex:1">${ico('i-sync')}<span>Đồng bộ ngay</span></button>
          <button class="action-btn" id="btnPauseSync" style="flex:1"><span>${syncPaused ? 'Tiếp tục' : 'Tạm dừng'}</span></button>
        </div>
      </section>`;

    bindCommonEvents();

    const folderRow = document.getElementById('btnSyncFolderRow');
    if (folderRow) {
      folderRow.addEventListener('click', () => {
        const def = pools.find(p => p.isDefault) || pools[0] || { id: 'main' };
        currentPool = def.id;
        currentView = 'files';
        updateNavState();
        folderStack = [{ name: phoneFolder, path: phoneFolder }];
        loadFiles(phoneFolder);
      });
    }

    const camBtn = document.getElementById('btnToggleCamSync');
    if (camBtn) {
      camBtn.addEventListener('click', () => {
        camOn = !camOn;
        kvSet('tablet_cam_sync', camOn);
        showToast(camOn ? 'Đã bật sao lưu ảnh Camera' : 'Đã tắt sao lưu');
        renderSync();
      });
    }

    const srcBtn = document.getElementById('btnSelectSyncSrc');
    if (srcBtn) {
      srcBtn.addEventListener('click', async () => {
        try {
          const res = await callNative('pickFolder', '');
          if (res && res.path) {
            syncSrcPath = res.path;
            kvSet('tablet_sync_src', syncSrcPath);
            showToast('Đã chọn: ' + syncSrcPath);
            renderSync();
          }
        } catch (e) {}
      });
    }

    const startBtn = document.getElementById('btnSyncNow');
    if (startBtn) startBtn.addEventListener('click', syncNow);

    const pauseBtn = document.getElementById('btnPauseSync');
    if (pauseBtn) {
      pauseBtn.addEventListener('click', () => {
        syncPaused = !syncPaused;
        if (!syncPaused && syncUpQueue.length > 0) runSyncUpQueue();
        showToast(syncPaused ? 'Đã tạm dừng đồng bộ' : 'Tiếp tục đồng bộ');
        renderSync();
      });
    }
  }

  /* ---------- Sidebar & Bottom Navigation Synchronization ---------- */
  const navBtns = document.querySelectorAll('.nav-btn, .b-nav-btn');
  navBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const v = btn.dataset.view;
      if (v === currentView) return;
      currentView = v;
      updateNavState();
      if (v === 'files') renderFiles();
      else if (v === 'transfers') renderTransfers();
      else if (v === 'sync') renderSync();
      else if (v === 'favorites') renderFavorites();
      else if (v === 'trash') loadTrash();
    });
  });

  function updateNavState() {
    navBtns.forEach(b => {
      b.classList.toggle('active', b.dataset.view === currentView);
    });
  }

  /* ---------- Connect Dialog & Form Events ---------- */
  document.getElementById('cancelLogin').addEventListener('click', closeLoginDialog);
  document.getElementById('scanNowBtn').addEventListener('click', runLanDiscovery);
  document.getElementById('btnOpenManual').addEventListener('click', () => showLoginPane('manual'));
  document.getElementById('btnBackToDiscover').addEventListener('click', () => showLoginPane('discover'));
  document.getElementById('btnBackToDiscover2').addEventListener('click', () => showLoginPane('discover'));

  document.getElementById('btnSubmitManual').addEventListener('click', () => {
    const ip = document.getElementById('manualIpInput').value.trim();
    const port = parseInt(document.getElementById('manualPortInput').value.trim(), 10) || 8080;
    if (!ip) {
      showToast('Vui lòng nhập địa chỉ IP');
      return;
    }
    document.getElementById('targetHostTitle').textContent = ip;
    document.getElementById('targetHostSub').textContent = `${ip}:${port} · ${ip.startsWith('100.') ? 'Tailscale' : 'LAN'}`;
    document.getElementById('serverIp').value = ip;
    document.getElementById('serverPort').value = port;
    showLoginPane('credentials');
  });

  document.getElementById('loginBtn').addEventListener('click', () => {
    const ip = document.getElementById('serverIp').value.trim();
    const port = document.getElementById('serverPort').value.trim();
    const u = document.getElementById('username').value.trim();
    const p = document.getElementById('password').value || '';
    if (!u) {
      showToast('Vui lòng nhập tên đăng nhập');
      document.getElementById('username').focus();
      return;
    }
    doLogin(ip, port, u, p);
  });

  const cancelUnlockBtn = document.getElementById('btnCancelUnlock');
  if (cancelUnlockBtn) cancelUnlockBtn.addEventListener('click', closeUnlockDialog);

  const confirmUnlockBtn = document.getElementById('btnConfirmUnlock');
  if (confirmUnlockBtn) confirmUnlockBtn.addEventListener('click', submitUnlock);

  const unlockInput = document.getElementById('unlockPasswordInput');
  if (unlockInput) {
    unlockInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') submitUnlock();
    });
  }

  const toggleUnlockEye = document.getElementById('btnToggleUnlockPwd');
  if (toggleUnlockEye && unlockInput) {
    toggleUnlockEye.addEventListener('click', () => {
      const isPwd = unlockInput.type === 'password';
      unlockInput.type = isPwd ? 'text' : 'password';
      toggleUnlockEye.textContent = isPwd ? '🔒' : '👁️';
    });
  }

  bindInputKeyboardEvents();

  /* ---------- Back Key Listener (Native or Android System Back) ---------- */
  window.onDpad = (dir) => {
    if (dir === 'back') {
      const unlockOverlay = document.getElementById('unlockOverlay');
      const connOverlay = document.getElementById('connectOverlay');
      const vrOverlay = document.getElementById('videoResumeOverlay');
      if (unlockOverlay && unlockOverlay.classList.contains('open')) {
        closeUnlockDialog();
        return;
      }
      if (vrOverlay && vrOverlay.classList.contains('open')) {
        closeVideoResume();
        return;
      }
      if (connOverlay && connOverlay.classList.contains('open')) {
        closeLoginDialog();
        return;
      }
      if (isPortraitDetailOpen) {
        closePortraitDetailSheet();
        return;
      }
      if (currentView === 'files' && folderStack.length > 0) {
        goBackFolder();
        return;
      }
      if (currentView !== 'files') {
        currentView = 'files';
        updateNavState();
        renderFiles();
        return;
      }
      callNative('exitApp');
    }
  };

  /* ---------- Boot Sequence ---------- */
  async function boot() {
    adjustTabletOrientationAndScale();
    applyUserRoleUI();
    if (server && server.baseUrl && token) {
      updateHostUI(true, server.name, `${server.ip} · ${server.via === 'tailscale' ? 'Tailscale' : 'LAN'}`);
      try {
        const me = await api('/api/me');
        if (me && me.user) {
          currentUser = me.user;
          isViewer = (currentUser.role === 'viewer');
          kvSet('tablet_user', currentUser);
          applyUserRoleUI();
        }
        await loadPools();
        await loadFiles('');
        return;
      } catch (e) {}
    }
    openLoginDialog();
  }

  boot();
})();
