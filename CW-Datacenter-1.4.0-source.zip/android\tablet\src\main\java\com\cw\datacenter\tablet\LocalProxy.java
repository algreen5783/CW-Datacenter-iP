package com.cw.datacenter.tablet;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.content.ContentResolver;
import android.net.Uri;

public class LocalProxy {

    private static final Pattern RANGE_RE = Pattern.compile("bytes=(\\d*)-(\\d*)");
    private static final Pattern CONTENT_RANGE_RE = Pattern.compile("bytes\\s+(\\d+)-(\\d+)/");

    private volatile String baseUrl;
    private volatile String token;
    private volatile ContentResolver resolver;
    private volatile File cacheDir;
    private ServerSocket serverSocket;
    private ExecutorService pool = Executors.newCachedThreadPool();
    private volatile int port = 0;
    private volatile boolean started = false;

    private static final long MAX_SESSION_CACHE_BYTES = 15L * 1024L * 1024L * 1024L; // 15 GB

    void setResolver(ContentResolver r) { this.resolver = r; }
    void setCacheDir(File dir) {
        this.cacheDir = dir;
        cleanSessionCache(dir);
    }

    public void cleanSessionCache() {
        cleanSessionCache(this.cacheDir);
    }

    public static void cleanSessionCache(File cacheDir) {
        if (cacheDir == null) return;
        try {
            File dir = new File(cacheDir, "session_media");
            if (dir.exists() && dir.isDirectory()) {
                File[] files = dir.listFiles();
                if (files != null) {
                    for (File f : files) {
                        try { f.delete(); } catch (Exception ignored) {}
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private static synchronized void trimSessionCache(File sessionDir, long incomingBytes) {
        if (sessionDir == null || !sessionDir.exists()) return;
        File[] files = sessionDir.listFiles();
        if (files == null || files.length == 0) return;

        long total = incomingBytes;
        for (File f : files) {
            if (f.isFile()) total += f.length();
        }

        if (total <= MAX_SESSION_CACHE_BYTES) return;

        java.util.Arrays.sort(files, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));

        for (File f : files) {
            if (total <= MAX_SESSION_CACHE_BYTES) break;
            long len = f.length();
            if (f.delete()) {
                total -= len;
            }
        }
    }

    private void serveCachedSessionFile(String method, File file, Map<String, String> headers, OutputStream out, String forceMime) throws IOException {
        long fileLen = file.length();
        String range = headers.get("range");
        String ct = (forceMime != null && !forceMime.isEmpty()) ? forceMime : LocalFiles.guessMimeByName(file.getName(), "application/octet-stream");

        if (range != null) {
            Matcher m = RANGE_RE.matcher(range);
            if (m.find()) {
                long start = 0;
                long end = fileLen - 1;
                String startStr = m.group(1);
                String endStr = m.group(2);

                if (startStr != null && !startStr.isEmpty()) {
                    try { start = Long.parseLong(startStr); } catch (Exception ignored) {}
                }
                if (endStr != null && !endStr.isEmpty()) {
                    try { end = Long.parseLong(endStr); } catch (Exception ignored) {}
                }

                if (start >= fileLen) {
                    writeRaw(out, "HTTP/1.1 416 Range Not Satisfiable\r\n"
                            + "Content-Range: bytes */" + fileLen + "\r\n"
                            + "Content-Length: 0\r\n"
                            + "Connection: close\r\n\r\n");
                    return;
                }

                if (end >= fileLen) end = fileLen - 1;
                long sendLen = end - start + 1;

                StringBuilder resp = new StringBuilder();
                resp.append("HTTP/1.1 206 Partial Content\r\n")
                    .append("Content-Type: ").append(ct).append("\r\n")
                    .append("Content-Range: bytes ").append(start).append("-").append(end).append("/").append(fileLen).append("\r\n")
                    .append("Content-Length: ").append(sendLen).append("\r\n")
                    .append("Accept-Ranges: bytes\r\n")
                    .append("Access-Control-Allow-Origin: *\r\n")
                    .append("Connection: close\r\n\r\n");
                writeRaw(out, resp.toString());

                if (!"HEAD".equals(method)) {
                    try (java.io.RandomAccessFile raf = new java.io.RandomAccessFile(file, "r")) {
                        raf.seek(start);
                        byte[] buf = new byte[64 * 1024];
                        long remaining = sendLen;
                        while (remaining > 0) {
                            int toRead = (int) Math.min(buf.length, remaining);
                            int n = raf.read(buf, 0, toRead);
                            if (n <= 0) break;
                            out.write(buf, 0, n);
                            remaining -= n;
                        }
                        out.flush();
                    }
                }
                return;
            }
        }

        StringBuilder resp = new StringBuilder();
        resp.append("HTTP/1.1 200 OK\r\n")
            .append("Content-Type: ").append(ct).append("\r\n")
            .append("Content-Length: ").append(fileLen).append("\r\n")
            .append("Accept-Ranges: bytes\r\n")
            .append("Access-Control-Allow-Origin: *\r\n")
            .append("Connection: close\r\n\r\n");
        writeRaw(out, resp.toString());

        if (!"HEAD".equals(method)) {
            try (InputStream fis = new FileInputStream(file)) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = fis.read(buf)) > 0) {
                    out.write(buf, 0, n);
                }
                out.flush();
            }
        }
    }

    private static String md5(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] d = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return String.valueOf(s.hashCode());
        }
    }

    void start() {
        tryStart();
    }

    private void tryStart() {
        synchronized (this) {
            if (started) return;
            started = true;
            if (pool.isShutdown()) pool = Executors.newCachedThreadPool();
        }
        try {
            InetAddress bind;
            try {
                bind = InetAddress.getByName("127.0.0.1");
            } catch (Exception e) {
                bind = InetAddress.getLoopbackAddress();
            }
            final ServerSocket ss = new ServerSocket(0, 64, bind);
            final int p = ss.getLocalPort();
            serverSocket = ss;
            port = p;
            Thread t = new Thread(this::acceptLoop, "cw-proxy-accept");
            t.setDaemon(true);
            t.start();
            Thread checker = new Thread(() -> {
                if (selfCheck(p)) return;
                try { ss.close(); } catch (IOException ignored) {}
                if (serverSocket == ss) {
                    serverSocket = null;
                    port = 0;
                    synchronized (LocalProxy.this) { started = false; }
                }
            }, "cw-proxy-check");
            checker.setDaemon(true);
            checker.start();
        } catch (IOException e) {
            synchronized (this) { started = false; }
            port = 0;
        }
    }

    private boolean selfCheck(int p) {
        try (Socket s = new Socket("127.0.0.1", p)) {
            s.setSoTimeout(1500);
            s.getOutputStream().write("GET / HTTP/1.1\r\n\r\n".getBytes(StandardCharsets.US_ASCII));
            s.getOutputStream().flush();
            return s.getInputStream().read() != -1;
        } catch (IOException e) {
            return false;
        }
    }

    void stop() {
        ServerSocket ss;
        synchronized (this) {
            ss = serverSocket;
            serverSocket = null;
            port = 0;
            started = false;
        }
        try { if (ss != null) ss.close(); } catch (IOException ignored) {}
        pool.shutdownNow();
    }

    int port() { return port; }

    String urlFor(String relEncoded, String poolEncoded, boolean video) {
        if (port == 0) return "";
        StringBuilder sb = new StringBuilder("http://127.0.0.1:").append(port).append("/play?path=").append(relEncoded);
        if (poolEncoded != null && !poolEncoded.isEmpty()) sb.append("&pool=").append(poolEncoded);
        if (video) sb.append("&video=1");
        return sb.toString();
    }

    String thumbUrl(String relEncoded, String poolEncoded) {
        if (port == 0) return "";
        StringBuilder sb = new StringBuilder("http://127.0.0.1:").append(port).append("/play?path=").append(relEncoded).append("&thumb=1");
        if (poolEncoded != null && !poolEncoded.isEmpty()) sb.append("&pool=").append(poolEncoded);
        return sb.toString();
    }

    void setAuth(String baseUrl, String token) {
        this.baseUrl = baseUrl;
        this.token = token;
        if (!started) tryStart();
    }

    private void acceptLoop() {
        while (true) {
            Socket s;
            try { s = serverSocket.accept(); } catch (IOException e) { return; }
            try { s.setTcpNoDelay(true); } catch (IOException ignored) {}
            pool.execute(() -> handle(s));
        }
    }

    private void handle(Socket s) {
        try {
            s.setSoTimeout(180000);
            InputStream in = s.getInputStream();
            OutputStream out = s.getOutputStream();
            String line = readLine(in);
            if (line == null || line.isEmpty()) return;
            String[] parts = line.split(" ");
            if (parts.length < 2) return;
            String method = parts[0].toUpperCase(Locale.ROOT);
            String target = parts[1];
            Map<String, String> headers = new HashMap<>();
            String h;
            while ((h = readLine(in)) != null && !h.isEmpty()) {
                int idx = h.indexOf(':');
                if (idx > 0) headers.put(h.substring(0, idx).trim().toLowerCase(Locale.ROOT), h.substring(idx + 1).trim());
            }
            if ("OPTIONS".equals(method)) { writeOptions(out); return; }
            if ("GET".equals(method) || "HEAD".equals(method)) { serve(method, target, headers, out); return; }
            writeError(out, 405, "Method Not Allowed");
        } catch (Exception ignored) {
        } finally {
            try { s.close(); } catch (IOException ignored) {}
        }
    }

    private void writeOptions(OutputStream out) throws IOException {
        writeRaw(out, "HTTP/1.1 204 No Content\r\n"
                + "Access-Control-Allow-Origin: *\r\n"
                + "Access-Control-Allow-Headers: Content-Type, Range, Authorization\r\n"
                + "Access-Control-Allow-Methods: GET, HEAD, OPTIONS\r\n"
                + "Access-Control-Max-Age: 86400\r\n"
                + "Connection: close\r\n\r\n");
    }

    private void serve(String method, String target, Map<String, String> headers, OutputStream out) throws IOException {
        int q = target.indexOf('?');
        String qsStr = q >= 0 ? target.substring(q + 1) : "";
        String pathPart = q >= 0 ? target.substring(0, q) : target;
        if (pathPart.equals("/doc")) { serveLocal(method, qsStr, headers, out); return; }
        if (pathPart.equals("/f")) { serveFs(method, qsStr, headers, out); return; }

        String u = this.baseUrl;
        if (u == null || u.isEmpty()) { writeError(out, 503, "Chưa kết nối máy chủ"); return; }

        Map<String, String> qs = parseQuery(qsStr);
        String rel = qs.get("path");
        if (rel == null || rel.isEmpty()) rel = qs.get("file");
        if (rel == null || rel.isEmpty()) { writeError(out, 404, "Not found"); return; }
        boolean video = "1".equals(qs.get("video"));
        boolean thumb = "1".equals(qs.get("thumb"));
        String poolParam = qs.get("pool");
        String ssParam = qs.get("ss");

        StringBuilder up = new StringBuilder(u);
        String encRel = "";
        try { encRel = URLEncoder.encode(rel, "UTF-8"); } catch (Exception ignored) { encRel = rel; }
        if (video) {
            up.append("/api/video?raw=1&path=").append(encRel);
            if (ssParam != null && !ssParam.isEmpty()) up.append("&ss=").append(ssParam);
        } else if (thumb) {
            up.append("/api/thumb?path=").append(encRel);
        } else {
            up.append("/api/file?path=").append(encRel).append("&preview=1");
        }
        if (poolParam != null && !poolParam.isEmpty()) {
            String encPool = poolParam;
            try { encPool = URLEncoder.encode(poolParam, "UTF-8"); } catch (Exception ignored) {}
            up.append("&pool=").append(encPool);
        }
        String upstream = up.toString();

        if (thumb && cacheDir != null) {
            String cacheKey = md5((poolParam != null ? poolParam : "main") + ":" + rel);
            File cachedFile = new File(cacheDir, "thumbs/" + cacheKey + ".jpg");
            if (cachedFile.exists() && cachedFile.length() > 0) {
                try (InputStream fis = new FileInputStream(cachedFile)) {
                    StringBuilder resp = new StringBuilder();
                    resp.append("HTTP/1.1 200 OK\r\n")
                        .append("Content-Type: image/jpeg\r\n")
                        .append("Content-Length: ").append(cachedFile.length()).append("\r\n")
                        .append("Cache-Control: public, max-age=31536000, immutable\r\n")
                        .append("Access-Control-Allow-Origin: *\r\n")
                        .append("Connection: close\r\n\r\n");
                    writeRaw(out, resp.toString());
                    pipe(method, fis, out);
                    return;
                } catch (Exception ignored) {}
            }
        }

        // 0. Check Persistent Offline Media (Preloaded Videos)
        if (!thumb && cacheDir != null) {
            String offKey = md5((poolParam != null ? poolParam : "main") + ":" + rel + (video ? ":vid" : ":full"));
            File filesDir = cacheDir.getParentFile() != null ? new File(cacheDir.getParentFile(), "files") : null;
            File offDir = filesDir != null ? new File(filesDir, "offline_media") : null;
            if (offDir != null && offDir.exists()) {
                File offFile = new File(offDir, offKey + (video ? ".mp4" : ".dat"));
                if (offFile.exists() && offFile.length() > 0) {
                    serveCachedSessionFile(method, offFile, headers, out, video ? "video/mp4" : null);
                    return;
                }
            }
        }

        // 1. Check Session Media Cache (Videos & Photos)
        if (!thumb && cacheDir != null) {
            String sessionKey = md5((poolParam != null ? poolParam : "main") + ":" + rel + (video ? ":vid" : ":full"));
            File sessionDir = new File(cacheDir, "session_media");
            File sessionCachedFile = new File(sessionDir, sessionKey + (video ? ".mp4" : ".dat"));
            if (!sessionCachedFile.exists()) {
                sessionCachedFile = new File(sessionDir, sessionKey + ".dat");
            }
            if (sessionCachedFile.exists() && sessionCachedFile.length() > 0) {
                sessionCachedFile.setLastModified(System.currentTimeMillis());
                serveCachedSessionFile(method, sessionCachedFile, headers, out, video ? "video/mp4" : null);
                return;
            }
        }

        String tk = this.token;
        String range = headers.get("range");
        long reqStart = parseRangeStart(range);

        HttpURLConnection conn = open(upstream, tk, range);
        int status;
        try {
            status = conn.getResponseCode();
        } catch (IOException e) {
            conn.disconnect();
            writeError(out, 502, "Không kết nối được server");
            return;
        }

        try {
            if (status == 416) {
                String cr = conn.getHeaderField("Content-Range");
                StringBuilder r = new StringBuilder();
                r.append("HTTP/1.1 416 Range Not Satisfiable\r\n");
                if (cr != null) r.append("Content-Range: ").append(cr).append("\r\n");
                r.append("Access-Control-Allow-Origin: *\r\n")
                 .append("Content-Length: 0\r\n")
                 .append("Connection: close\r\n\r\n");
                writeRaw(out, r.toString());
                return;
            }

            if (status >= 400) {
                String msg = readErr(conn);
                writeError(out, status, msg == null || msg.isEmpty() ? ("Lỗi HTTP " + status) : msg);
                return;
            }

            String ct = conn.getContentType();
            if (ct == null) ct = "application/octet-stream";

            if (status == 206) {
                String cr = conn.getHeaderField("Content-Range");
                String cl = conn.getHeaderField("Content-Length");
                if (cl == null) cl = contentLengthOf(cr);
                StringBuilder resp = new StringBuilder();
                resp.append("HTTP/1.1 206 Partial Content\r\n")
                    .append("Content-Type: ").append(ct).append("\r\n");
                if (cr != null) resp.append("Content-Range: ").append(cr).append("\r\n");
                if (cl != null) resp.append("Content-Length: ").append(cl).append("\r\n");
                resp.append("Accept-Ranges: bytes\r\n")
                    .append("Access-Control-Allow-Origin: *\r\n")
                    .append("Connection: close\r\n\r\n");
                writeRaw(out, resp.toString());
                pipe(method, conn.getInputStream(), out);
                return;
            }

            InputStream is = conn.getInputStream();
            if (reqStart > 0) {
                long skipped = 0;
                byte[] skip = new byte[256 * 1024];
                int n;
                while (skipped < reqStart
                        && (n = is.read(skip, 0, (int) Math.min(skip.length, reqStart - skipped))) > 0) skipped += n;
                if (skipped < reqStart) { writeError(out, 416, "Không tua được vị trí này"); return; }

                long total = -1;
                String totalLen = conn.getHeaderField("Content-Length");
                if (totalLen != null) {
                    try { total = Long.parseLong(totalLen.trim()); } catch (NumberFormatException ignored) {}
                }
                if (total > reqStart) {
                    StringBuilder r2 = new StringBuilder();
                    r2.append("HTTP/1.1 206 Partial Content\r\n")
                      .append("Content-Type: ").append(ct).append("\r\n")
                      .append("Content-Range: bytes ").append(reqStart).append('-').append(total - 1).append('/').append(total).append("\r\n")
                      .append("Content-Length: ").append(total - reqStart).append("\r\n")
                      .append("Accept-Ranges: bytes\r\n")
                      .append("Access-Control-Allow-Origin: *\r\n")
                      .append("Connection: close\r\n\r\n");
                    writeRaw(out, r2.toString());
                } else {
                    writeRaw(out, "HTTP/1.1 200 OK\r\n"
                            + "Content-Type: " + ct + "\r\n"
                            + "Access-Control-Allow-Origin: *\r\n"
                            + "Connection: close\r\n\r\n");
                }
                pipe(method, is, out);
            } else {
                if (thumb && cacheDir != null) {
                    String cacheKey = md5((poolParam != null ? poolParam : "main") + ":" + rel);
                    File thumbFolder = new File(cacheDir, "thumbs");
                    if (!thumbFolder.exists()) thumbFolder.mkdirs();
                    File cachedFile = new File(thumbFolder, cacheKey + ".jpg");
                    File tmpFile = new File(thumbFolder, cacheKey + ".tmp-" + System.currentTimeMillis());

                    String lenH = conn.getHeaderField("Content-Length");
                    StringBuilder resp = new StringBuilder();
                    resp.append("HTTP/1.1 200 OK\r\n")
                        .append("Content-Type: image/jpeg\r\n");
                    if (lenH != null) resp.append("Content-Length: ").append(lenH).append("\r\n");
                    resp.append("Cache-Control: public, max-age=31536000, immutable\r\n")
                        .append("Access-Control-Allow-Origin: *\r\n")
                        .append("Connection: close\r\n\r\n");
                    writeRaw(out, resp.toString());

                    try (FileOutputStream fos = new FileOutputStream(tmpFile)) {
                        byte[] buf = new byte[64 * 1024];
                        int n;
                        while ((n = is.read(buf)) > 0) {
                            if (!"HEAD".equals(method)) out.write(buf, 0, n);
                            fos.write(buf, 0, n);
                        }
                        out.flush();
                        fos.flush();
                    } catch (Exception ignored) {}
                    tmpFile.renameTo(cachedFile);
                    return;
                }

                // Full Video or Photo streaming from byte 0 -> cache into session_media!
                if (!thumb && cacheDir != null) {
                    String sessionKey = md5((poolParam != null ? poolParam : "main") + ":" + rel + (video ? ":vid" : ":full"));
                    File sessionDir = new File(cacheDir, "session_media");
                    if (!sessionDir.exists()) sessionDir.mkdirs();
                    File cachedFile = new File(sessionDir, sessionKey + ".dat");
                    File tmpFile = new File(sessionDir, sessionKey + ".tmp-" + System.currentTimeMillis());

                    trimSessionCache(sessionDir, 0);

                    String lenH = conn.getHeaderField("Content-Length");
                    long expectedLen = -1;
                    if (lenH != null) {
                        try { expectedLen = Long.parseLong(lenH.trim()); } catch (Exception ignored) {}
                    }

                    StringBuilder resp = new StringBuilder();
                    resp.append("HTTP/1.1 200 OK\r\n")
                        .append("Content-Type: ").append(ct).append("\r\n");
                    if (lenH != null) resp.append("Content-Length: ").append(lenH).append("\r\n");
                    resp.append("Accept-Ranges: bytes\r\n")
                        .append("Access-Control-Allow-Origin: *\r\n")
                        .append("Connection: close\r\n\r\n");
                    writeRaw(out, resp.toString());

                    boolean completed = false;
                    long bytesWritten = 0;
                    try (FileOutputStream fos = new FileOutputStream(tmpFile)) {
                        byte[] buf = new byte[64 * 1024];
                        int n;
                        while ((n = is.read(buf)) > 0) {
                            if (!"HEAD".equals(method)) {
                                out.write(buf, 0, n);
                            }
                            fos.write(buf, 0, n);
                            bytesWritten += n;
                        }
                        out.flush();
                        fos.flush();
                        if (expectedLen <= 0 || bytesWritten >= expectedLen) {
                            completed = true;
                        }
                    } catch (Exception ignored) {}

                    if (completed && tmpFile.exists() && tmpFile.length() > 0) {
                        tmpFile.renameTo(cachedFile);
                        trimSessionCache(sessionDir, cachedFile.length());
                    } else {
                        try { tmpFile.delete(); } catch (Exception ignored) {}
                    }
                    return;
                }

                String lenH = conn.getHeaderField("Content-Length");
                StringBuilder resp = new StringBuilder();
                resp.append("HTTP/1.1 200 OK\r\n")
                    .append("Content-Type: ").append(ct).append("\r\n");
                if (lenH != null) resp.append("Content-Length: ").append(lenH).append("\r\n");
                resp.append("Accept-Ranges: bytes\r\n")
                    .append("Access-Control-Allow-Origin: *\r\n")
                    .append("Connection: close\r\n\r\n");
                writeRaw(out, resp.toString());
                pipe(method, is, out);
            }
            pipe(method, is, out);
        } finally {
            conn.disconnect();
        }
    }

    private void serveLocal(String method, String segStr, Map<String, String> headers, OutputStream out) throws IOException {
        ContentResolver cr = this.resolver;
        if (cr == null) { writeError(out, 503, "SAF chưa sẵn sàng"); return; }
        try {
            String treeEnc = "", idEnc = "", nameEnc = "", mime = "";
            for (String kv : segStr.split("&")) {
                int i = kv.indexOf('=');
                if (i <= 0) continue;
                String k = kv.substring(0, i);
                String v = java.net.URLDecoder.decode(kv.substring(i + 1), "UTF-8");
                if (k.equals("tree")) treeEnc = v;
                else if (k.equals("id")) idEnc = v;
                else if (k.equals("name")) nameEnc = v;
                else if (k.equals("mime")) mime = v;
            }
            if (treeEnc.isEmpty() || idEnc.isEmpty()) { writeError(out, 404, "Not found"); return; }
            Uri tree = Uri.parse(treeEnc);
            Uri docUri = LocalFiles.childUri(tree, idEnc);

            String ct = mime;
            long size = -1;
            try (android.database.Cursor c = cr.query(docUri, new String[]{
                    android.provider.DocumentsContract.Document.COLUMN_SIZE,
                    android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE }, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    if (!c.isNull(0)) size = c.getLong(0);
                    String qm = c.getString(1);
                    if (qm != null && !qm.isEmpty()) ct = qm;
                }
            } catch (Exception ignored) {}
            if (ct == null || ct.isEmpty() || android.provider.DocumentsContract.Document.MIME_TYPE_DIR.equals(ct)) {
                ct = LocalFiles.guessMimeByName(nameEnc, null);
            }

            boolean isThumb = segStr.contains("thumb=1");
            if (isThumb && docUri != null) {
                try {
                    android.graphics.Bitmap bmp = null;
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q && cr != null) {
                        try {
                            bmp = cr.loadThumbnail(docUri, new android.util.Size(160, 160), null);
                        } catch (Throwable ignored) {}
                    }
                    if (bmp != null) {
                        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                        bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 75, baos);
                        bmp.recycle();
                        byte[] thumbBytes = baos.toByteArray();
                        writeRaw(out, "HTTP/1.1 200 OK\r\n"
                                + "Content-Type: image/jpeg\r\n"
                                + "Content-Length: " + thumbBytes.length + "\r\n"
                                + "Cache-Control: private, max-age=604800\r\n"
                                + "Access-Control-Allow-Origin: *\r\n"
                                + "Connection: close\r\n\r\n");
                        out.write(thumbBytes);
                        out.flush();
                        return;
                    }
                } catch (Throwable ignored) {}
            }

            final InputStream fis;
            try { fis = cr.openInputStream(docUri); }
            catch (Exception e) { writeError(out, 404, "Không mở được tệp"); return; }
            if (fis == null) { writeError(out, 404, "Không mở được tệp"); return; }

            if (size < 0) { try { size = fis.available(); } catch (Exception ignored) {} }

            String range = headers.get("range");
            long reqStart = -1, reqEnd = -1;
            if (range != null) {
                Matcher m = RANGE_RE.matcher(range);
                if (m.find()) {
                    String a = m.group(1), b = m.group(2);
                    if (!a.isEmpty() && b.isEmpty()) reqStart = Long.parseLong(a);
                    else if (!a.isEmpty() && !b.isEmpty()) { reqStart = Long.parseLong(a); reqEnd = Long.parseLong(b); }
                    else if (a.isEmpty() && !b.isEmpty()) { long suffix = Long.parseLong(b); if (size >= 0) reqStart = Math.max(0, size - suffix); }
                }
            }
            if (size >= 0) {
                if ((reqStart > 0 && reqStart >= size) || (reqEnd >= size)) {
                    writeRaw(out, "HTTP/1.1 416 Range Not Satisfiable\r\n"
                            + "Content-Range: bytes */" + size + "\r\n"
                            + "Access-Control-Allow-Origin: *\r\nContent-Length: 0\r\nConnection: close\r\n\r\n");
                    fis.close();
                    return;
                }
                if (reqStart > 0) {
                    long skipped = 0;
                    while (skipped < reqStart) {
                        long s = fis.skip(reqStart - skipped);
                        if (s <= 0) break;
                        skipped += s;
                    }
                    if (skipped < reqStart) { writeError(out, 416, "Không tua được vị trí này"); fis.close(); return; }
                }
                long end = reqEnd >= 0 ? Math.min(reqEnd, size - 1) : size - 1;
                long len = end - reqStart + 1;
                StringBuilder resp = new StringBuilder();
                if (reqStart > 0 || reqEnd >= 0 || (range != null)) {
                    resp.append("HTTP/1.1 206 Partial Content\r\n")
                        .append("Content-Range: bytes ").append(Math.max(0, reqStart)).append('-').append(end).append('/').append(size).append("\r\n")
                        .append("Content-Length: ").append(len).append("\r\n");
                } else {
                    resp.append("HTTP/1.1 200 OK\r\n")
                        .append("Content-Length: ").append(size).append("\r\n");
                }
                resp.append("Content-Type: ").append(ct).append("\r\n")
                    .append("Accept-Ranges: bytes\r\n")
                    .append("Access-Control-Allow-Origin: *\r\n")
                    .append("Connection: close\r\n\r\n");
                writeRaw(out, resp.toString());
                if (!"HEAD".equals(method)) {
                    byte[] buf = new byte[128 * 1024];
                    long remaining = len;
                    int n;
                    while (remaining > 0 && (n = fis.read(buf, 0, (int) Math.min(buf.length, remaining))) > 0) {
                        out.write(buf, 0, n);
                        out.flush();
                        remaining -= n;
                    }
                }
                fis.close();
                return;
            }

            writeRaw(out, "HTTP/1.1 200 OK\r\n"
                    + "Content-Type: " + ct + "\r\n"
                    + "Accept-Ranges: bytes\r\n"
                    + "Access-Control-Allow-Origin: *\r\n"
                    + "Connection: close\r\n\r\n");
            if (!"HEAD".equals(method)) {
                byte[] buf = new byte[128 * 1024];
                int n;
                while ((n = fis.read(buf)) > 0) { out.write(buf, 0, n); out.flush(); }
            }
            fis.close();
        } catch (Exception e) {
            writeError(out, 500, "Lỗi đọc tệp");
        }
    }

    private void serveFs(String method, String qsStr, Map<String, String> headers, OutputStream out) throws IOException {
        String path = "";
        String mime = "";
        for (String kv : qsStr.split("&")) {
            int i = kv.indexOf('=');
            if (i <= 0) continue;
            String k = kv.substring(0, i);
            if (k.equals("p")) path = java.net.URLDecoder.decode(kv.substring(i + 1), "UTF-8");
            else if (k.equals("mime")) mime = java.net.URLDecoder.decode(kv.substring(i + 1), "UTF-8");
        }
        if (path.isEmpty()) { writeError(out, 404, "Not found"); return; }
        java.io.File f = new java.io.File(path);
        if (!f.isFile()) { writeError(out, 404, "Không tìm thấy tệp"); return; }
        String ct = (mime == null || mime.isEmpty()) ? LocalFiles.guessMimeByName(f.getName(), null) : mime;
        long size = f.length();

        boolean isThumb = qsStr.contains("thumb=1");
        if (isThumb) {
            String nameLower = f.getName().toLowerCase();
            boolean isImg = nameLower.endsWith(".jpg") || nameLower.endsWith(".jpeg") || nameLower.endsWith(".png")
                    || nameLower.endsWith(".webp") || nameLower.endsWith(".heic") || nameLower.endsWith(".heif")
                    || nameLower.endsWith(".bmp") || nameLower.endsWith(".avif");
            boolean isVid = nameLower.endsWith(".mp4") || nameLower.endsWith(".mkv") || nameLower.endsWith(".mov")
                    || nameLower.endsWith(".3gp") || nameLower.endsWith(".webm") || nameLower.endsWith(".avi");
            if (isImg || isVid) {
                try {
                    android.graphics.Bitmap bmp = null;
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        try {
                            if (isImg) {
                                bmp = android.media.ThumbnailUtils.createImageThumbnail(f, new android.util.Size(160, 160), null);
                            } else {
                                bmp = android.media.ThumbnailUtils.createVideoThumbnail(f, new android.util.Size(160, 160), null);
                            }
                        } catch (Throwable ignored) {}
                    }
                    if (bmp == null && isImg) {
                        android.graphics.BitmapFactory.Options opts = new android.graphics.BitmapFactory.Options();
                        opts.inJustDecodeBounds = true;
                        android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), opts);
                        int sample = 1;
                        int maxDim = Math.max(opts.outWidth, opts.outHeight);
                        while (maxDim / sample > 240) sample *= 2;
                        opts.inJustDecodeBounds = false;
                        opts.inSampleSize = Math.max(1, sample);
                        bmp = android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), opts);
                    }
                    if (bmp != null) {
                        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                        bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 75, baos);
                        bmp.recycle();
                        byte[] thumbBytes = baos.toByteArray();
                        writeRaw(out, "HTTP/1.1 200 OK\r\n"
                                + "Content-Type: image/jpeg\r\n"
                                + "Content-Length: " + thumbBytes.length + "\r\n"
                                + "Cache-Control: private, max-age=604800\r\n"
                                + "Access-Control-Allow-Origin: *\r\n"
                                + "Connection: close\r\n\r\n");
                        out.write(thumbBytes);
                        out.flush();
                        return;
                    }
                } catch (Throwable ignored) {}
            }
        }

        java.io.RandomAccessFile raf;
        try { raf = new java.io.RandomAccessFile(f, "r"); } catch (Exception e) { writeError(out, 404, "Không mở được tệp"); return; }

        long reqStart = -1, reqEnd = -1;
        String range = headers.get("range");
        if (range != null) {
            Matcher m = RANGE_RE.matcher(range);
            if (m.find()) {
                String a = m.group(1), b = m.group(2);
                if (!a.isEmpty() && b.isEmpty()) reqStart = Long.parseLong(a);
                else if (!a.isEmpty() && !b.isEmpty()) { reqStart = Long.parseLong(a); reqEnd = Long.parseLong(b); }
                else if (a.isEmpty() && !b.isEmpty()) { long suffix = Long.parseLong(b); reqStart = Math.max(0, size - suffix); }
            }
        }
        if ((reqStart > 0 && reqStart >= size) || (reqEnd >= size && size > 0)) {
            writeRaw(out, "HTTP/1.1 416 Range Not Satisfiable\r\n"
                    + "Content-Range: bytes */" + size + "\r\n"
                    + "Access-Control-Allow-Origin: *\r\nContent-Length: 0\r\nConnection: close\r\n\r\n");
            raf.close();
            return;
        }
        long start = Math.max(0, reqStart);
        long end = reqEnd >= 0 ? Math.min(reqEnd, size - 1) : size - 1;
        long len = end - start + 1;
        StringBuilder resp = new StringBuilder();
        if (range != null && reqStart >= 0) {
            resp.append("HTTP/1.1 206 Partial Content\r\n")
                .append("Content-Range: bytes ").append(start).append('-').append(end).append('/').append(size).append("\r\n")
                .append("Content-Length: ").append(len).append("\r\n");
        } else {
            resp.append("HTTP/1.1 200 OK\r\n")
                .append("Content-Length: ").append(size).append("\r\n");
            start = 0; len = size;
        }
        resp.append("Content-Type: ").append(ct).append("\r\n")
            .append("Accept-Ranges: bytes\r\n")
            .append("Access-Control-Allow-Origin: *\r\n")
            .append("Connection: close\r\n\r\n");
        writeRaw(out, resp.toString());
        try {
            if (!"HEAD".equals(method)) {
                raf.seek(start);
                byte[] buf = new byte[256 * 1024];
                long remaining = len;
                while (remaining > 0) {
                    int n = raf.read(buf, 0, (int) Math.min(buf.length, remaining));
                    if (n < 0) break;
                    out.write(buf, 0, n);
                    out.flush();
                    remaining -= n;
                }
            }
        } finally {
            raf.close();
        }
    }

    private void pipe(String method, InputStream is, OutputStream out) throws IOException {
        if ("HEAD".equals(method)) return;
        byte[] buf = new byte[128 * 1024];
        int n;
        while ((n = is.read(buf)) > 0) {
            out.write(buf, 0, n);
            out.flush();
        }
    }

    private HttpURLConnection open(String url, String tk, String range) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setInstanceFollowRedirects(true);
        conn.setUseCaches(false);
        conn.setConnectTimeout(8000);
        conn.setReadTimeout(180000);
        if (tk != null && !tk.isEmpty()) conn.setRequestProperty("Authorization", "Bearer " + tk);
        if (range != null) conn.setRequestProperty("Range", range);
        return conn;
    }

    private static long parseRangeStart(String range) {
        if (range == null) return -1;
        Matcher m = RANGE_RE.matcher(range);
        if (m.find() && !m.group(1).isEmpty()) {
            try { return Long.parseLong(m.group(1)); } catch (NumberFormatException ignored) {}
        }
        return -1;
    }

    private static String contentLengthOf(String cr) {
        if (cr == null) return null;
        Matcher m = CONTENT_RANGE_RE.matcher(cr);
        if (!m.find()) return null;
        try {
            return String.valueOf(Long.parseLong(m.group(2)) - Long.parseLong(m.group(1)) + 1);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private String readErr(HttpURLConnection conn) {
        try {
            InputStream is = conn.getErrorStream();
            if (is == null) return "";
            byte[] buf = new byte[2048];
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            int n;
            while ((n = is.read(buf)) > 0) { bos.write(buf, 0, n); if (bos.size() > 4096) break; }
            String s = new String(bos.toByteArray(), StandardCharsets.UTF_8);
            try {
                org.json.JSONObject o = new org.json.JSONObject(s);
                if (o.has("error")) return o.optString("error");
            } catch (Exception ignored) {}
            return s.trim();
        } catch (Exception e) {
            return "";
        }
    }

    private void writeError(OutputStream out, int status, String msg) {
        try {
            byte[] body = msg.getBytes(StandardCharsets.UTF_8);
            writeRaw(out, "HTTP/1.1 " + status + " " + reason(status) + "\r\n"
                    + "Content-Type: text/plain; charset=utf-8\r\n"
                    + "Content-Length: " + body.length + "\r\n"
                    + "Access-Control-Allow-Origin: *\r\n"
                    + "Connection: close\r\n\r\n");
            out.write(body);
            out.flush();
        } catch (IOException ignored) {}
    }

    private void writeRaw(OutputStream out, String s) throws IOException {
        out.write(s.getBytes(StandardCharsets.ISO_8859_1));
        out.flush();
    }

    private static String reason(int status) {
        switch (status) {
            case 200: return "OK";
            case 206: return "Partial Content";
            case 204: return "No Content";
            case 401: return "Unauthorized";
            case 403: return "Forbidden";
            case 404: return "Not Found";
            case 405: return "Method Not Allowed";
            case 416: return "Range Not Satisfiable";
            case 502: return "Bad Gateway";
            case 503: return "Service Unavailable";
            default: return status < 400 ? "OK" : "Error";
        }
    }

    private static Map<String, String> parseQuery(String q) {
        Map<String, String> m = new HashMap<>();
        if (q == null || q.isEmpty()) return m;
        for (String kv : q.split("&")) {
            int i = kv.indexOf('=');
            if (i > 0) {
                String k = kv.substring(0, i);
                String rawV = kv.substring(i + 1);
                try {
                    m.put(k, URLDecoder.decode(rawV, "UTF-8"));
                } catch (Exception e) {
                    m.put(k, rawV);
                }
            }
        }
        return m;
    }

    private static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') return sb.toString();
            if (c == '\r') continue;
            sb.append((char) c);
            if (sb.length() > 8192) break;
        }
        return sb.length() == 0 && c == -1 ? null : sb.toString();
    }
}
