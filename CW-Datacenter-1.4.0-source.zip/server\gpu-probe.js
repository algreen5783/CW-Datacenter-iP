const { execFile, exec } = require('child_process');
const fs = require('fs');

let cachedGpuInfo = null;
let currentMode = 'auto'; // 'auto' | 'gpu' | 'cpu'

function getGpuControllerInfo() {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') {
      return resolve([]);
    }
    exec('wmic path win32_VideoController get name,driverversion,adapterram /format:list', { timeout: 3000, windowsHide: true }, (err, stdout) => {
      if (err || !stdout) {
        // Fallback to powershell
        exec('powershell -NoProfile -Command "Get-CimInstance Win32_VideoController | Select-Object -Property Name, DriverVersion | ConvertTo-Json"', { timeout: 3000, windowsHide: true }, (pErr, pOut) => {
          if (pErr || !pOut) return resolve([]);
          try {
            const parsed = JSON.parse(pOut);
            const arr = Array.isArray(parsed) ? parsed : [parsed];
            return resolve(arr.map((x) => ({ name: x.Name || '', driver: x.DriverVersion || '' })));
          } catch {
            return resolve([]);
          }
        });
        return;
      }
      const controllers = [];
      let current = {};
      const lines = stdout.split(/\r?\n/);
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed) {
          if (current.name) {
            controllers.push(current);
            current = {};
          }
          continue;
        }
        const eqIdx = trimmed.indexOf('=');
        if (eqIdx > 0) {
          const k = trimmed.slice(0, eqIdx).toLowerCase();
          const v = trimmed.slice(eqIdx + 1).trim();
          if (k === 'name') current.name = v;
          else if (k === 'driverversion') current.driver = v;
        }
      }
      if (current.name) controllers.push(current);
      resolve(controllers);
    });
  });
}

function testFfmpegHwDevice(ffmpegBin, deviceType) {
  return new Promise((resolve) => {
    if (!ffmpegBin || !fs.existsSync(ffmpegBin)) return resolve(false);
    const args = ['-hide_banner', '-loglevel', 'error', '-init_hw_device', `${deviceType}=hw_test`, '-f', 'lavfi', '-i', 'nullsrc', '-frames:v', '1', '-f', 'null', '-'];
    execFile(ffmpegBin, args, { timeout: 2500, windowsHide: true }, (err) => {
      resolve(!err);
    });
  });
}

async function probeGpu(ffmpegBin, forceRefresh = false) {
  if (cachedGpuInfo && !forceRefresh) return cachedGpuInfo;

  const controllers = await getGpuControllerInfo();
  const names = controllers.map((c) => c.name).filter(Boolean);
  const primaryGpuName = names.join(', ') || 'Không xác định / Máy ảo';

  const hasNvidia = names.some((n) => /nvidia|geforce|quadro|rtx|gtx/i.test(n));
  const hasIntel = names.some((n) => /intel/i.test(n));
  const hasAmd = names.some((n) => /amd|radeon/i.test(n));

  // Thử các backend theo thứ tự ưu tiên
  const [d3d11Ok, qsvOk, cudaOk, dxva2Ok] = await Promise.all([
    testFfmpegHwDevice(ffmpegBin, 'd3d11va'),
    testFfmpegHwDevice(ffmpegBin, 'qsv'),
    testFfmpegHwDevice(ffmpegBin, 'cuda'),
    testFfmpegHwDevice(ffmpegBin, 'dxva2')
  ]);

  let activeBackend = 'cpu';
  let h264Hw = false;
  let hevcHw = false;
  let statusType = 'ok'; // 'ok' | 'warning' | 'info'
  let statusTitle = '';
  let statusMessage = '';
  let adviceLink = '';

  // Nhận diện khả năng phần cứng
  if (cudaOk) {
    activeBackend = 'cuda';
    h264Hw = true;
    // Kiểm tra HEVC trên card Nvidia
    hevcHw = !names.some((n) => /gt\s*7[0-9]{2}|gt\s*6[0-9]{2}|gtx\s*750(?!\s*ti)|gts|gt\s*2[0-9]{2}/i.test(n));
    statusType = 'ok';
    statusTitle = 'NVIDIA CUDA / NVDEC';
    statusMessage = 'Đã kích hoạt tăng tốc phần cứng NVIDIA CUDA. GPU sẽ giải mã và xử lý video/ảnh siêu nhanh.';
  } else if (qsvOk) {
    activeBackend = 'qsv';
    h264Hw = true;
    // Intel QuickSync Gen 6+ (HD 500 series trở lên) hỗ trợ HEVC
    hevcHw = names.some((n) => /hd\s*(graphics\s*)?(5[0-9]{2}|6[0-9]{2})|uhd|iris|arc/i.test(n));
    statusType = 'ok';
    statusTitle = 'Intel QuickSync (QSV)';
    statusMessage = 'Đã kích hoạt Intel QuickSync. Nhân đồ họa tích hợp của CPU Intel sẽ gánh toàn bộ xử lý video/ảnh.';
  } else if (d3d11Ok || dxva2Ok) {
    activeBackend = d3d11Ok ? 'd3d11va' : 'dxva2';
    h264Hw = true;
    hevcHw = names.some((n) => /hd\s*(graphics\s*)?(5[0-9]{2}|6[0-9]{2})|uhd|iris|arc|gtx\s*(9[5-9][0-9]|1[0-9]{3}|2[0-9]{3}|3[0-9]{3}|4[0-9]{3})|rtx|rx\s*[4-9][0-9]{2}/i.test(n));
    statusType = 'ok';
    statusTitle = d3d11Ok ? 'DirectX 11 (D3D11VA)' : 'DirectX (DXVA2)';
    statusMessage = 'Đã kích hoạt tăng tốc phần cứng chuẩn Windows DirectX. GPU sẽ tự động hỗ trợ giải mã video.';
  } else if (hasNvidia && !cudaOk) {
    statusType = 'warning';
    statusTitle = 'Phát hiện card NVIDIA nhưng chưa có Driver CUDA';
    statusMessage = 'Hệ thống nhận diện được card NVIDIA nhưng thiếu driver tương thích. Vui lòng cài NVIDIA Driver chính thức để bật tăng tốc GPU.';
    adviceLink = 'https://www.nvidia.com/Download/index.aspx';
  } else {
    statusType = 'info';
    statusTitle = 'Chế độ CPU tối ưu';
    statusMessage = 'Không tìm thấy bộ xử lý đồ họa tương thích. Hệ thống đang sử dụng CPU với cơ chế trích xuất EXIF siêu tốc tiết kiệm điện năng.';
  }

  cachedGpuInfo = {
    controllers,
    primaryGpuName,
    hasNvidia,
    hasIntel,
    hasAmd,
    d3d11Ok,
    qsvOk,
    cudaOk,
    dxva2Ok,
    activeBackend,
    h264Hw,
    hevcHw,
    statusType,
    statusTitle,
    statusMessage,
    adviceLink,
    currentMode,
    timestamp: Date.now()
  };

  return cachedGpuInfo;
}

function getHwAccelArgs(gpuInfo) {
  if (!gpuInfo) return [];
  const mode = currentMode || 'auto';
  if (mode === 'cpu') return [];
  if (mode === 'cuda' && gpuInfo.cudaOk) return ['-hwaccel', 'cuda'];
  if (mode === 'qsv' && gpuInfo.qsvOk) return ['-hwaccel', 'qsv'];
  if (mode === 'd3d11va' && (gpuInfo.d3d11Ok || gpuInfo.dxva2Ok)) return ['-hwaccel', gpuInfo.d3d11Ok ? 'd3d11va' : 'dxva2'];

  // Chế độ 'auto'
  if (gpuInfo.activeBackend === 'cuda') return ['-hwaccel', 'cuda'];
  if (gpuInfo.activeBackend === 'qsv') return ['-hwaccel', 'qsv'];
  if (gpuInfo.activeBackend === 'd3d11va') return ['-hwaccel', 'd3d11va'];
  if (gpuInfo.activeBackend === 'dxva2') return ['-hwaccel', 'dxva2'];
  return [];
}

function setGpuMode(mode) {
  currentMode = mode || 'auto';
  if (cachedGpuInfo) cachedGpuInfo.currentMode = currentMode;
  return currentMode;
}

function getGpuMode() {
  return currentMode;
}

module.exports = {
  probeGpu,
  getHwAccelArgs,
  setGpuMode,
  getGpuMode,
  getCachedInfo: () => cachedGpuInfo
};
