'use strict';
const { app, BrowserWindow, ipcMain, Menu, shell, dialog, Tray, nativeImage, screen } = require('electron');
const path = require('path');
const http = require('http');
const https = require('https');
const dgram = require('dgram');
const fs = require('fs');
const { makeEngine } = require('./sync-engine');

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();

app.on('second-instance', () => {
  if (win) { win.show(); win.focus(); }
});

let win = null;
let tray = null;
let forceQuit = false;
const LAST_URL_FILE = path.join(app.getPath('userData'), 'last-url.json');
const HOSTS_FILE = path.join(app.getPath('userData'), 'hosts.json');

function loadHosts() {
  try {
    const arr = JSON.parse(fs.readFileSync(HOSTS_FILE, 'utf8'));
    return Array.isArray(arr) ? arr.filter((h) => h && h.ip) : [];
  } catch { return []; }
}
function saveHosts(list) {
  try { fs.writeFileSync(HOSTS_FILE, JSON.stringify(list, null, 2)); } catch {}
}

function saveLastUrl(url) {
  try { fs.writeFileSync(LAST_URL_FILE, JSON.stringify({ url })); } catch {}
}
function loadLastUrl() {
  try { return JSON.parse(fs.readFileSync(LAST_URL_FILE, 'utf8')).url || ''; } catch { return ''; }
}

/* ---------- Auth token (do renderer nạp sau khi đăng nhập) ---------- */
let serverOrigin = '';
/* ---------- Sync engine (đồng bộ thư mục local -> host) ---------- */
const syncEngine = makeEngine({
  syncFile: path.join(app.getPath('userData'), 'sync.json'),
  notify: () => {
    if (win && !win.isDestroyed()) { try { win.webContents.send('sync-update', null); } catch {} }
    buildTray();
  },
});

ipcMain.handle('set-token', (_e, token, origin) => {
  serverOrigin = String(origin || '').replace(/\/$/, '');
  syncEngine.setAuth(token, origin);
  return { ok: true };
});

ipcMain.handle('win-control', (_e, action) => {
  if (!win || win.isDestroyed()) return { ok: false };
  if (action === 'min') win.minimize();
  else if (action === 'max') { if (win.isMaximized()) win.unmaximize(); else win.maximize(); }
  else if (action === 'close') win.close(); else return { ok: false };
  try { win.webContents.send('win-maximized', win.isMaximized()); } catch {}
  return { ok: true };
});

ipcMain.handle('sync-pick', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Chọn thư mục đồng bộ', properties: ['openDirectory', 'createDirectory'] });
  if (r.canceled || !r.filePaths.length) return { ok: false };
  return { ok: true, path: r.filePaths[0] };
});
ipcMain.handle('sync-add', (_e, opts) => syncEngine.add(opts));
ipcMain.handle('sync-list', () => syncEngine.listPublic());
ipcMain.handle('sync-now', (_e, id) => {
  const cfg = syncEngine._cfgs().find((c) => c.id === id);
  if (cfg) syncEngine.syncOne(cfg, true);
  return { ok: true };
});
ipcMain.handle('sync-toggle', (_e, id, on) => syncEngine.toggle(id, on));
ipcMain.handle('sync-remove', (_e, id) => syncEngine.remove(id));
ipcMain.on('sync-open', (_e, id) => {
  const cfg = syncEngine._cfgs().find((c) => c.id === id);
  if (cfg) shell.openPath(cfg.local);
});

/* ---------- Window + tray (chạy ngầm) ---------- */
function trayIcon() {
  try { return nativeImage.createFromPath(path.join(__dirname, 'tray.png')); } catch { return nativeImage.createEmpty(); }
}
function winIcon() {
  try { const img = nativeImage.createFromPath(path.join(__dirname, 'logo.png')); return img.isEmpty() ? nativeImage.createEmpty() : img; } catch { return nativeImage.createEmpty(); }
}

function createWindow() {
  createWindow.dlSeq = createWindow.dlSeq || 0;
  let wa = { width: 1280, height: 860 };
  try { wa = screen.getPrimaryDisplay().workAreaSize; } catch {}
  const w0 = wa.width >= 1400 ? 1400 : wa.width;
  const h0 = wa.height >= 900 ? 900 : wa.height;
  win = new BrowserWindow({
    width: w0,
    height: h0,
    minWidth: 760,
    minHeight: 520,
    frame: false,
    backgroundColor: '#ffffff',
    autoHideMenuBar: true,
    icon: winIcon(),
    title: 'CW Datacenter',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  win.loadFile('connect.html');

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('blob:')) return { action: 'allow' };
    shell.openExternal(url);
    return { action: 'deny' };
  });

  const dlItems = new Map();
  win.webContents.session.on('will-download', (_e, item) => {
    const seq = ++createWindow.dlSeq;
    dlItems.set(seq, item);
    try {
      const base = item.getFilename() || 'download';
      let target = path.join(app.getPath('downloads'), base);
      const ext = path.extname(base);
      const stem = path.basename(base, ext);
      let i = 1;
      while (fs.existsSync(target)) { target = path.join(app.getPath('downloads'), stem + ' (' + i + ')' + ext); i++; }
      item.setSavePath(target);
    } catch {}
    const send = () => {
      if (!win || win.isDestroyed()) return;
      try {
        win.webContents.send('dl-progress', {
          seq,
          name: item.getFilename(),
          state: item.getState(),
          received: item.getReceivedBytes(),
          total: item.getTotalBytes(),
          path: item.getSavePath && item.getSavePath(),
        });
      } catch {}
    };
    item.on('updated', send);
    item.once('done', () => { dlItems.delete(seq); send(); });
  });
  ipcMain.on('dl-cancel', (_e, seq) => {
    const it = dlItems.get(seq);
    if (it) { try { it.cancel(); } catch {} dlItems.delete(seq); }
  });

  win.on('close', (e) => {
    if (!forceQuit) {
      e.preventDefault();
      win.hide();
    }
  });
  win.on('app-command', (e, cmd) => {
    if (cmd === 'browser-backward' || cmd === 'browser-forward') {
      e.preventDefault();
      try { win.webContents.send('mouse-nav', cmd === 'browser-backward' ? 'back' : 'forward'); } catch {}
    }
  });
  const sendMaxState = () => {
    if (!win || win.isDestroyed()) return;
    try { win.webContents.send('win-maximized', win.isMaximized()); } catch {}
  };
  win.on('maximize', sendMaxState);
  win.on('unmaximize', sendMaxState);
  win.on('closed', () => { win = null; });

  buildMenu();
  buildTray();
}

function buildTray() {
  if (!app.isReady()) return;
  const icon = trayIcon();
  if (!tray) {
    tray = new Tray(icon.isEmpty() ? nativeImage.createEmpty() : icon.resize({ width: 16, height: 16 }));
    tray.on('double-click', () => { if (win) { win.show(); win.focus(); } });
    tray.on('click', () => { if (win) { win.show(); win.focus(); } });
  }
  const all = syncEngine._cfgs();
  const syncing = all.some((c) => c.status === 'busy');
  const errs = all.filter((c) => c.status === 'err');
  const tmpl = [
    { label: 'Mở CW Datacenter', click: () => { if (win) { win.show(); win.focus(); } } },
    { label: 'Màn hình kết nối', click: () => { if (win) { win.show(); win.focus(); win.loadFile('connect.html'); } } },
    { type: 'separator' },
    { label: '⟳ Đồng bộ tất cả ngay', click: () => { for (const c of all) { if (c.enabled !== false) syncEngine.syncOne(c, true); } } },
    { label: syncing ? 'Đang đồng bộ…' : 'Đồng bộ: ' + (all.length ? all.filter((c) => c.enabled !== false).length + '/' + all.length + ' đang bật' : 'chưa cấu hình'), enabled: false },
    ...(errs.length ? [{ label: '⚠ ' + errs[0].error.slice(0, 60), enabled: false }] : []),
    { type: 'separator' },
    {
      label: 'Thoát hẳn', click: () => {
        forceQuit = true;
        if (win) try { win.close(); } catch {}
        app.quit();
      },
    },
  ];
  tray.setToolTip('CW Datacenter' + (serverOrigin ? ' — ' + serverOrigin : ''));
  tray.setContextMenu(Menu.buildFromTemplate(tmpl));
}

function buildMenu() {
  const menu = Menu.buildFromTemplate([
    {
      label: 'Kết nối',
      submenu: [
        { label: '🏠 Màn hình kết nối', click: () => win && win.loadFile('connect.html') },
        { type: 'separator' },
        { role: 'reload', label: 'Tải lại' },
        { role: 'toggleDevTools', label: 'DevTools' },
        { type: 'separator' },
        { label: 'Thu về khay hệ thống', click: () => win && win.hide() },
        { role: 'quit', label: 'Thoát hẳn', click: () => { forceQuit = true; } },
      ],
    },
    { label: 'Chỉnh sửa', role: 'editMenu' },
    { label: 'Xem', role: 'viewMenu' },
  ]);
  Menu.setApplicationMenu(menu);
}

function checkServer(url) {
  let probeUrl = url.replace(/\/$/, '') + '/api/health';
  try {
    const u = new URL(probeUrl);
    if (u.hostname === 'localhost' || u.hostname === '[::1]') u.hostname = '127.0.0.1';
    probeUrl = u.toString();
  } catch {}
  return new Promise((resolve) => {
    const mod = probeUrl.startsWith('https') ? https : http;
    const req = mod.get(probeUrl, { timeout: 4000, family: 4 }, (res) => {
      res.resume();
      resolve(res.statusCode === 200);
    });
    req.on('error', () => resolve(false));
    req.on('timeout', () => { req.destroy(); resolve(false); });
  });
}

ipcMain.handle('connect', async (_e, urlRaw) => {
  let url = String(urlRaw || '').trim();
  if (!url) return { ok: false, error: 'Nhập địa chỉ máy chủ.' };
  if (!/^https?:\/\//i.test(url)) url = 'http://' + url;
  try { new URL(url); } catch { return { ok: false, error: 'Địa chỉ không hợp lệ.' }; }
  const ok = await checkServer(url);
  if (!ok) return { ok: false, error: 'Không kết nối được tới ' + url + '. Server đã chạy chưa?' };
  saveLastUrl(url.replace(/\/$/, ''));
  try {
    const u = new URL(url);
    const hosts = loadHosts();
    const ip = u.hostname, port = Number(u.port) || (u.protocol === 'https:' ? 443 : 80);
    const exist = hosts.find((h) => h.ip === ip && Number(h.port) === Number(port));
    if (!exist) {
      hosts.unshift({ ip, port, name: '', added: Date.now() });
      saveHosts(hosts.slice(0, 20));
    } else if (!exist.added) { exist.added = Date.now(); saveHosts(hosts); }
  } catch {}
  await win.loadURL(url);
  try { win.webContents.clearHistory(); } catch {}
  return { ok: true };
});

ipcMain.handle('hosts-list', () => loadHosts());
ipcMain.handle('hosts-save', (_e, h) => {
  if (!h || !h.ip) return { ok: false };
  const hosts = loadHosts();
  const ip = String(h.ip).trim(), port = Number(h.port) || 8080;
  const i = hosts.findIndex((x) => x.ip === ip && Number(x.port) === Number(port));
  if (i >= 0) {
    if (h.name) hosts[i].name = String(h.name);
    hosts[i].added = Date.now();
  } else {
    hosts.unshift({ ip, port, name: String(h.name || ''), added: Date.now() });
  }
  saveHosts(hosts.slice(0, 20));
  return { ok: true, hosts };
});
ipcMain.handle('hosts-remove', (_e, key) => {
  let ip = String(key || ''), port = 8080;
  if (ip.includes(':')) { const parts = ip.split(':'); ip = parts[0]; port = Number(parts[1]) || 8080; }
  const hosts = loadHosts().filter((h) => !(h.ip === ip && Number(h.port) === Number(port)));
  saveHosts(hosts);
  return { ok: true, hosts };
});
ipcMain.handle('disconnect', async () => {
  if (!win || win.isDestroyed()) return { ok: false };
  try { await win.loadFile('connect.html'); win.webContents.clearHistory(); } catch {}
  return { ok: true };
});

function udpDiscover(timeoutMs) {
  return new Promise((resolve) => {
    const found = new Map();
    let settled = false;
    const done = () => { if (!settled) { settled = true; try { sock.close(); } catch {} resolve([...found.values()]); } };
    let sock;
    try { sock = dgram.createSocket({ type: 'udp4', reuseAddr: true }); } catch { return resolve([]); }
    sock.on('message', (msg, rinfo) => {
      try {
        const j = JSON.parse(String(msg));
        if (j.app !== 'cw-datacenter') return;
        const port = j.port || 8080;
        const key = rinfo.address + ':' + port;
        const url = 'http://' + rinfo.address + ':' + port;
        if (!found.has(key)) {
          found.set(key, { host: j.host || rinfo.address, ip: rinfo.address, port, url, name: j.name || 'CW Datacenter' });
        }
      } catch {}
    });
    sock.on('error', () => done());
    sock.bind(0, '0.0.0.0', () => {
      try { sock.setBroadcast(true); } catch {}
      const msg = Buffer.from('CW-DISCOVER');
      try { sock.send(msg, 0, msg.length, 46631, '255.255.255.255'); } catch {}
      const ifaces = require('os').networkInterfaces();
      for (const list of Object.values(ifaces)) {
        for (const n of list || []) {
          if (n.family === 'IPv4' && !n.internal && /^(\d+\.\d+\.\d+\.\d+)$/.test(n.address)) {
            const parts = n.address.split('.').slice(0, 3);
            const selfLast = parseInt(n.address.split('.')[3], 10);
            for (let i = 1; i <= 254; i++) {
              if (i !== selfLast) {
                try { sock.send(msg, 0, msg.length, 46631, parts[0] + '.' + parts[1] + '.' + parts[2] + '.' + i); } catch {}
              }
            }
          }
        }
      }
    });
    setTimeout(done, timeoutMs);
  });
}

function httpProbeSubnet(port) {
  return new Promise((resolve) => {
    const list = [];
    const ifaces = require('os').networkInterfaces();
    const subnets = [];
    for (const ifaceList of Object.values(ifaces)) {
      for (const n of ifaceList || []) {
        if (n.family === 'IPv4' && !n.internal && /^(\d+\.\d+\.\d+\.\d+)$/.test(n.address)) {
          const parts = n.address.split('.').slice(0, 3);
          const selfLast = parseInt(n.address.split('.')[3], 10);
          subnets.push({ prefix: parts.join('.'), self: selfLast });
        }
      }
    }
    if (!subnets.length) return resolve([]);
    let pending = 0;
    const checkIp = (ip) => {
      pending++;
      const req = http.get('http://' + ip + ':' + port + '/api/ping', { timeout: 800 }, (res) => {
        let buf = '';
        res.on('data', (c) => buf += c);
        res.on('end', () => {
          try {
            const j = JSON.parse(buf);
            if (j.app === 'cw-datacenter' || j.ok) {
              list.push({ host: j.host || ip, ip, port: j.port || port, url: 'http://' + ip + ':' + (j.port || port), name: j.name || 'CW Datacenter' });
            }
          } catch {}
          pending--;
          if (pending <= 0) resolve(list);
        });
      });
      req.on('error', () => { pending--; if (pending <= 0) resolve(list); });
      req.on('timeout', () => { req.destroy(); pending--; if (pending <= 0) resolve(list); });
    };

    for (const sub of subnets) {
      for (let i = 1; i <= 254; i++) {
        if (i !== sub.self) checkIp(sub.prefix + '.' + i);
      }
    }
    setTimeout(() => resolve(list), 1500);
  });
}

ipcMain.handle('discover', async () => {
  const [udpHosts, httpHosts] = await Promise.all([
    udpDiscover(1800),
    httpProbeSubnet(8080)
  ]);
  const merged = new Map();
  for (const h of [...udpHosts, ...httpHosts]) {
    const key = h.ip + ':' + h.port;
    if (!merged.has(key)) merged.set(key, h);
  }
  const out = [];
  for (const h of merged.values()) {
    h.ok = await checkServer(h.url);
    h.same = false;
    out.push(h);
  }
  out.sort((a, b) => Number(b.ok) - Number(a.ok));
  return { hosts: out };
});

ipcMain.handle('last-url', () => loadLastUrl());

ipcMain.handle('autostart-get', () => {
  try { return { ok: true, on: !!app.getLoginItemSettings().openAtLogin }; } catch { return { ok: false, on: false }; }
});
ipcMain.handle('autostart-set', (_e, on) => {
  try {
    if (on) app.setLoginItemSettings({ openAtLogin: true, args: ['--hidden'] });
    else app.setLoginItemSettings({ openAtLogin: false, args: [] });
    return { ok: true, on: !!on };
  } catch (e) { return { ok: false, error: e.message }; }
});

const startHidden = process.argv.includes('--hidden');
app.whenReady().then(() => {
  createWindow();
  if (startHidden && win) win.hide();
});
app.on('window-all-closed', () => { if (forceQuit && process.platform !== 'darwin') app.quit(); });
app.on('before-quit', () => { forceQuit = true; });
