package com.cw.datacenter.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.load.model.LazyHeaders;
import com.github.chrisbanes.photoview.PhotoView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PhotoViewerActivity extends Activity {

    public static final String EXTRA_URL = "extra_url";
    public static final String EXTRA_NAME = "extra_name";
    public static final String EXTRA_TOKEN = "extra_token";
    public static final String EXTRA_LOCAL_PATH = "extra_local_path";
    public static final String EXTRA_PLAYLIST = "extra_playlist";
    public static final String EXTRA_INITIAL_INDEX = "extra_initial_index";
    public static final String EXTRA_BASE_URL = "extra_base_url";

    public static class PhotoItem {
        public String name;
        public String url;
        public String thumbUrl;
        public String localPath;
        public String rel;
        public String pool;
        public long size;
        public boolean local;

        public static PhotoItem fromJson(JSONObject o) {
            PhotoItem it = new PhotoItem();
            it.name = o.optString("name", "");
            it.url = o.optString("url", "");
            it.thumbUrl = o.optString("thumbUrl", "");
            it.localPath = o.optString("localPath", "");
            it.rel = o.optString("rel", "");
            it.pool = o.optString("pool", "");
            it.size = o.optLong("size", 0);
            it.local = o.optBoolean("local", false);
            return it;
        }
    }

    private static volatile List<PhotoItem> sPendingItems = null;
    private static volatile int sPendingIndex = -1;

    public static void setPendingItems(List<PhotoItem> list, int index) {
        sPendingItems = list;
        sPendingIndex = index;
    }

    public static List<PhotoItem> popPendingItems() {
        List<PhotoItem> l = sPendingItems;
        sPendingItems = null;
        return l;
    }

    public static int popPendingIndex() {
        int idx = sPendingIndex;
        sPendingIndex = -1;
        return idx;
    }

    private final List<PhotoItem> items = new ArrayList<>();
    private int currentIndex = 0;
    private String token;
    private String baseUrl;
    private SharedPreferences prefs;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newCachedThreadPool();

    private FrameLayout root;
    private ViewPager2 viewPager;
    private PhotoAdapter adapter;
    private LinearLayout topBar;
    private LinearLayout bottomBar;
    private TextView titleView;
    private TextView counterView;
    private ImageButton favBtn;
    private ImageButton downloadBtn;
    private ImageButton shareBtn;
    private ImageButton deleteBtn;
    private boolean controlsVisible = true;

    private int dp(int v) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("cw-datacenter", Context.MODE_PRIVATE);
        token = getIntent().getStringExtra(EXTRA_TOKEN);
        if (token == null || token.isEmpty()) {
            token = prefs.getString("player_token", "");
        }
        baseUrl = getIntent().getStringExtra(EXTRA_BASE_URL);
        if (baseUrl == null || baseUrl.isEmpty()) {
            baseUrl = prefs.getString("base_url", "");
        }

        parseItems();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);

        buildViewPager();
        buildTopBar();
        buildBottomBar();

        updateUiForCurrentPage();
    }

    private void parseItems() {
        List<PhotoItem> pending = popPendingItems();
        if (pending != null && !pending.isEmpty()) {
            items.clear();
            items.addAll(pending);
            currentIndex = popPendingIndex();
            if (currentIndex < 0 || currentIndex >= items.size()) currentIndex = 0;
            return;
        }

        String playlistJson = getIntent().getStringExtra(EXTRA_PLAYLIST);
        currentIndex = getIntent().getIntExtra(EXTRA_INITIAL_INDEX, 0);

        if (playlistJson != null && !playlistJson.isEmpty()) {
            try {
                JSONArray arr = new JSONArray(playlistJson);
                for (int i = 0; i < arr.length(); i++) {
                    items.add(PhotoItem.fromJson(arr.getJSONObject(i)));
                }
            } catch (Exception ignored) {}
        }

        if (items.isEmpty()) {
            PhotoItem single = new PhotoItem();
            single.url = getIntent().getStringExtra(EXTRA_URL);
            single.name = getIntent().getStringExtra(EXTRA_NAME);
            single.localPath = getIntent().getStringExtra(EXTRA_LOCAL_PATH);
            single.local = single.localPath != null && !single.localPath.isEmpty();
            items.add(single);
        }

        if (currentIndex < 0 || currentIndex >= items.size()) {
            currentIndex = 0;
        }
    }

    private void buildViewPager() {
        viewPager = new ViewPager2(this);
        viewPager.setOrientation(ViewPager2.ORIENTATION_HORIZONTAL);
        adapter = new PhotoAdapter();
        viewPager.setAdapter(adapter);
        viewPager.setCurrentItem(currentIndex, false);

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                currentIndex = position;
                updateUiForCurrentPage();
            }
        });

        FrameLayout.LayoutParams vpLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        root.addView(viewPager, vpLp);
    }

    private void buildTopBar() {
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(16), dp(36), dp(16), dp(14));

        GradientDrawable bg = new GradientDrawable();
        bg.setGradientType(GradientDrawable.LINEAR_GRADIENT);
        bg.setColors(new int[]{ 0xCC000000, 0x00000000 });
        topBar.setBackground(bg);

        ImageButton back = new ImageButton(this);
        back.setBackgroundResource(R.drawable.pl_icon_btn_bg);
        back.setImageResource(R.drawable.ic_pl_back);
        back.setColorFilter(Color.WHITE);
        back.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        back.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(dp(42), dp(42));
        topBar.addView(back, bLp);

        LinearLayout textCol = new LinearLayout(this);
        textCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tcLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tcLp.leftMargin = dp(14);
        tcLp.rightMargin = dp(14);

        titleView = new TextView(this);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        titleView.setSingleLine(true);
        titleView.setShadowLayer(8, 0, 2, 0x99000000);
        textCol.addView(titleView);

        counterView = new TextView(this);
        counterView.setTextColor(0xBBFFFFFF);
        counterView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        counterView.setSingleLine(true);
        counterView.setShadowLayer(6, 0, 1, 0x99000000);
        textCol.addView(counterView);

        topBar.addView(textCol, tcLp);

        ImageButton castBtn = new ImageButton(this);
        castBtn.setBackgroundResource(R.drawable.pl_icon_btn_bg);
        castBtn.setImageResource(R.drawable.ic_pl_cast);
        castBtn.setColorFilter(Color.WHITE);
        castBtn.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        castBtn.setContentDescription("Truyền lên TV");
        castBtn.setOnClickListener(v -> showCastDialog());
        LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(dp(42), dp(42));
        topBar.addView(castBtn, cLp);

        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP);
        root.addView(topBar, topLp);
    }

    private void buildBottomBar() {
        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER);
        bottomBar.setPadding(dp(20), dp(16), dp(20), dp(28));

        GradientDrawable bg = new GradientDrawable();
        bg.setGradientType(GradientDrawable.LINEAR_GRADIENT);
        bg.setColors(new int[]{ 0x00000000, 0xCC000000 });
        bottomBar.setBackground(bg);

        // Nút Yêu thích
        favBtn = createActionButton(R.drawable.ic_photo_heart_off, "Yêu thích", v -> toggleFavoriteCurrent());
        bottomBar.addView(favBtn);

        addBottomSpacer();

        // Nút Tải về
        downloadBtn = createActionButton(R.drawable.ic_photo_download, "Tải về", v -> downloadCurrent());
        bottomBar.addView(downloadBtn);

        addBottomSpacer();

        // Nút Chia sẻ (ở giữa Tải về và Xóa)
        shareBtn = createActionButton(R.drawable.ic_photo_share, "Chia sẻ", v -> shareCurrent());
        bottomBar.addView(shareBtn);

        addBottomSpacer();

        // Nút Xóa ảnh
        deleteBtn = createActionButton(R.drawable.ic_photo_trash, "Xóa ảnh", v -> confirmDeleteCurrent());
        bottomBar.addView(deleteBtn);

        FrameLayout.LayoutParams botLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        root.addView(bottomBar, botLp);
    }

    private void addBottomSpacer() {
        View space = new View(this);
        LinearLayout.LayoutParams spLp = new LinearLayout.LayoutParams(dp(48), dp(1));
        bottomBar.addView(space, spLp);
    }

    private ImageButton createActionButton(int iconRes, String desc, View.OnClickListener onClick) {
        ImageButton btn = new ImageButton(this);
        btn.setBackgroundResource(R.drawable.pl_icon_btn_bg);
        btn.setImageResource(iconRes);
        btn.setColorFilter(Color.WHITE);
        btn.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        btn.setContentDescription(desc);
        btn.setOnClickListener(onClick);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(48), dp(48));
        btn.setLayoutParams(lp);
        return btn;
    }

    private void toggleControls() {
        controlsVisible = !controlsVisible;
        float alpha = controlsVisible ? 1f : 0f;

        topBar.animate()
                .alpha(alpha)
                .translationY(controlsVisible ? 0 : -dp(20))
                .setDuration(200)
                .withEndAction(() -> topBar.setVisibility(controlsVisible ? View.VISIBLE : View.INVISIBLE))
                .start();

        bottomBar.animate()
                .alpha(alpha)
                .translationY(controlsVisible ? 0 : dp(20))
                .setDuration(200)
                .withEndAction(() -> bottomBar.setVisibility(controlsVisible ? View.VISIBLE : View.INVISIBLE))
                .start();

        if (controlsVisible) {
            topBar.setVisibility(View.VISIBLE);
            bottomBar.setVisibility(View.VISIBLE);
        }
    }

    private void updateUiForCurrentPage() {
        if (items.isEmpty() || currentIndex < 0 || currentIndex >= items.size()) return;
        PhotoItem it = items.get(currentIndex);

        titleView.setText(it.name != null && !it.name.isEmpty() ? it.name : "Xem ảnh");
        counterView.setText((currentIndex + 1) + " / " + items.size());

        boolean isFav = isFavorited(it);
        favBtn.setImageResource(isFav ? R.drawable.ic_photo_heart_on : R.drawable.ic_photo_heart_off);
        if (isFav) {
            favBtn.setColorFilter(0xFFFF3B30);
        } else {
            favBtn.setColorFilter(Color.WHITE);
        }
    }

    /* ---------- FAVORITES SYNC ---------- */
    private String favKey() {
        String base = baseUrl != null && !baseUrl.isEmpty() ? baseUrl : prefs.getString("base_url", "");
        return "dc_kv_favs:" + base;
    }

    private JSONArray getFavList() {
        String json = prefs.getString(favKey(), "[]");
        try {
            return new JSONArray(json);
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private boolean isFavorited(PhotoItem it) {
        JSONArray arr = getFavList();
        String matchRel = it.rel != null && !it.rel.isEmpty() ? it.rel : it.name;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String r = o.optString("rel", "");
            String n = o.optString("name", "");
            String p = o.optString("_p", "");
            if (it.local) {
                if (it.localPath != null && it.localPath.equals(p)) return true;
                if (it.name != null && it.name.equals(n)) return true;
            } else {
                if (!r.isEmpty() && r.equals(matchRel)) return true;
                if (!n.isEmpty() && n.equals(it.name)) return true;
            }
        }
        return false;
    }

    private void toggleFavoriteCurrent() {
        if (items.isEmpty() || currentIndex < 0 || currentIndex >= items.size()) return;
        PhotoItem it = items.get(currentIndex);
        JSONArray arr = getFavList();
        JSONArray nextArr = new JSONArray();
        boolean found = false;
        String matchRel = it.rel != null && !it.rel.isEmpty() ? it.rel : it.name;

        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String r = o.optString("rel", "");
            String n = o.optString("name", "");
            String p = o.optString("_p", "");
            boolean matches = it.local
                    ? (it.localPath != null && it.localPath.equals(p)) || (it.name != null && it.name.equals(n))
                    : (!r.isEmpty() && r.equals(matchRel)) || (!n.isEmpty() && n.equals(it.name));

            if (matches) {
                found = true;
            } else {
                nextArr.put(o);
            }
        }

        if (!found) {
            JSONObject obj = new JSONObject();
            try {
                obj.put("name", it.name);
                obj.put("type", "file");
                obj.put("size", it.size);
                if (it.local) {
                    obj.put("local", true);
                    obj.put("_p", it.localPath != null ? it.localPath : "");
                    obj.put("rel", "local:" + (it.localPath != null ? it.localPath : ""));
                } else {
                    obj.put("rel", it.rel != null && !it.rel.isEmpty() ? it.rel : it.name);
                    obj.put("pool", it.pool != null && !it.pool.isEmpty() ? it.pool : "main");
                }
                nextArr.put(obj);
            } catch (Exception ignored) {}
            Toast.makeText(this, "Đã thêm vào mục yêu thích", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Đã bỏ yêu thích", Toast.LENGTH_SHORT).show();
        }

        prefs.edit().putString(favKey(), nextArr.toString()).apply();
        updateUiForCurrentPage();
    }

    /* ---------- DOWNLOAD ---------- */
    private void downloadCurrent() {
        if (items.isEmpty() || currentIndex < 0 || currentIndex >= items.size()) return;
        PhotoItem it = items.get(currentIndex);

        if (it.local) {
            Toast.makeText(this, "Ảnh đã có sẵn trên thiết bị", Toast.LENGTH_SHORT).show();
            return;
        }

        if (it.url == null || it.url.isEmpty()) {
            Toast.makeText(this, "Không có đường dẫn tải ảnh", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Đang tải ảnh về máy…", Toast.LENGTH_SHORT).show();

        executor.execute(() -> {
            try {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "CW-Datacenter");
                if (!dir.exists()) dir.mkdirs();

                String fileName = it.name != null && !it.name.isEmpty() ? it.name : "photo_" + System.currentTimeMillis() + ".jpg";
                File destFile = new File(dir, fileName);

                String downloadUrlStr = (it.url != null) ? it.url.replace("&preview=1", "").replace("?preview=1&", "?").replace("?preview=1", "") : "";
                URL u = new URL(downloadUrlStr);
                HttpURLConnection conn = (HttpURLConnection) u.openConnection();
                if (token != null && !token.isEmpty()) {
                    conn.setRequestProperty("Authorization", "Bearer " + token);
                }
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                conn.connect();

                if (conn.getResponseCode() >= 200 && conn.getResponseCode() < 300) {
                    try (InputStream is = conn.getInputStream(); FileOutputStream fos = new FileOutputStream(destFile)) {
                        byte[] buf = new byte[32768];
                        int r;
                        while ((r = is.read(buf)) != -1) {
                            fos.write(buf, 0, r);
                        }
                        fos.flush();
                    }

                    MediaScannerConnection.scanFile(PhotoViewerActivity.this,
                            new String[]{ destFile.getAbsolutePath() }, null, null);

                    mainHandler.post(() -> Toast.makeText(PhotoViewerActivity.this,
                            "Đã lưu vào Download/CW-Datacenter/" + fileName, Toast.LENGTH_LONG).show());
                } else {
                    int respCode = conn.getResponseCode();
                    mainHandler.post(() -> Toast.makeText(PhotoViewerActivity.this,
                            "Tải thất bại (mã " + respCode + ")", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                mainHandler.post(() -> Toast.makeText(PhotoViewerActivity.this,
                        "Lỗi tải ảnh: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }

    /* ---------- SHARE PHOTO ---------- */
    private void shareCurrent() {
        if (items.isEmpty() || currentIndex < 0 || currentIndex >= items.size()) return;
        PhotoItem it = items.get(currentIndex);

        if (it.local && it.localPath != null && !it.localPath.isEmpty()) {
            File f = new File(it.localPath);
            if (f.exists() && f.isFile()) {
                launchShareIntent(f, it.name);
                return;
            }
        }

        // Kiểm tra xem ảnh đã có sẵn trong Session Cache chưa để chia sẻ tức thì không cần tải lại
        String rel = it.rel != null && !it.rel.isEmpty() ? it.rel : it.name;
        String pool = it.pool != null && !it.pool.isEmpty() ? it.pool : "main";
        if (rel != null && !rel.isEmpty()) {
            String sessionKey = md5(pool + ":" + rel + ":full");
            File sessionFile = new File(new File(getCacheDir(), "session_media"), sessionKey + ".dat");
            if (sessionFile.exists() && sessionFile.length() > 0) {
                launchShareIntent(sessionFile, it.name);
                return;
            }
        }

        if (it.url == null || it.url.isEmpty()) {
            Toast.makeText(this, "Không có đường dẫn chia sẻ ảnh", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Đang chuẩn bị chia sẻ ảnh…", Toast.LENGTH_SHORT).show();

        executor.execute(() -> {
            try {
                File cacheDir = new File(getCacheDir(), "shared_photos");
                if (!cacheDir.exists()) cacheDir.mkdirs();

                String fileName = it.name != null && !it.name.isEmpty() ? it.name : "photo_" + System.currentTimeMillis() + ".jpg";
                File destFile = new File(cacheDir, fileName);

                URL u = new URL(it.url);
                HttpURLConnection conn = (HttpURLConnection) u.openConnection();
                if (token != null && !token.isEmpty()) {
                    conn.setRequestProperty("Authorization", "Bearer " + token);
                }
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                conn.connect();

                if (conn.getResponseCode() >= 200 && conn.getResponseCode() < 300) {
                    try (InputStream is = conn.getInputStream(); FileOutputStream fos = new FileOutputStream(destFile)) {
                        byte[] buf = new byte[32768];
                        int r;
                        while ((r = is.read(buf)) != -1) {
                            fos.write(buf, 0, r);
                        }
                        fos.flush();
                    }
                    mainHandler.post(() -> launchShareIntent(destFile, fileName));
                } else {
                    int respCode = conn.getResponseCode();
                    mainHandler.post(() -> Toast.makeText(PhotoViewerActivity.this,
                            "Không thể tải ảnh để chia sẻ (mã " + respCode + ")", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                mainHandler.post(() -> Toast.makeText(PhotoViewerActivity.this,
                        "Lỗi chia sẻ: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void launchShareIntent(File file, String name) {
        try {
            Uri contentUri = StreamProvider.uriFor(this, file);
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            int idx = name != null ? name.lastIndexOf('.') : -1;
            String ext = idx >= 0 ? name.substring(idx + 1).toLowerCase() : "";
            String mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
            if (mime == null || mime.isEmpty()) mime = "image/*";
            shareIntent.setType(mime);
            shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, name != null ? name : "Hình ảnh");
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(shareIntent, "Chia sẻ 1 hình ảnh"));
        } catch (Exception e) {
            Toast.makeText(this, "Lỗi mở trình chia sẻ: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private static String md5(String s) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            byte[] d = md.digest(s.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return String.valueOf(s.hashCode());
        }
    }

    /* ---------- DLNA SMART TV CAST ---------- */
    private void showCastDialog() {
        if (items.isEmpty() || currentIndex < 0 || currentIndex >= items.size()) return;
        PhotoItem it = items.get(currentIndex);
        AlertDialog.Builder b = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
        b.setTitle("Truyền lên Smart TV");
        b.setMessage("Đang quét Smart TV trong mạng Wi-Fi…");
        b.setNegativeButton("Đóng", null);
        AlertDialog dlg = b.create();
        dlg.show();

        DlnaManager.discoverDevices(this, 3500, new DlnaManager.DiscoveryCallback() {
            @Override
            public void onDeviceFound(DlnaManager.DlnaDevice device) {}

            @Override
            public void onDiscoveryFinished(List<DlnaManager.DlnaDevice> devices) {
                if (isFinishing() || isDestroyed()) return;
                dlg.dismiss();
                if (devices.isEmpty()) {
                    Toast.makeText(PhotoViewerActivity.this, "Không tìm thấy Smart TV nào trong mạng", Toast.LENGTH_SHORT).show();
                    return;
                }
                String[] names = new String[devices.size()];
                for (int i = 0; i < devices.size(); i++) {
                    names[i] = "📺 " + devices.get(i).name;
                }
                new AlertDialog.Builder(PhotoViewerActivity.this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setTitle("Chọn TV để hiển thị ảnh")
                        .setItems(names, (d, which) -> {
                            DlnaManager.DlnaDevice dev = devices.get(which);
                            Toast.makeText(PhotoViewerActivity.this, "Đang truyền ảnh tới " + dev.name, Toast.LENGTH_SHORT).show();
                            String castUrl = it.url;
                            if (castUrl != null && castUrl.contains("127.0.0.1")) {
                                String base = baseUrl != null && !baseUrl.isEmpty() ? baseUrl : prefs.getString("base_url", "");
                                if (!base.isEmpty()) castUrl = castUrl.replaceFirst("http://127\\.0\\.0\\.1:\\d+", base);
                            }
                            DlnaManager.playMedia(dev, castUrl, it.name, "image/jpeg", new DlnaManager.ActionCallback() {
                                @Override
                                public void onSuccess() {
                                    Toast.makeText(PhotoViewerActivity.this, "Đang hiển thị trên " + dev.name, Toast.LENGTH_SHORT).show();
                                }

                                @Override
                                public void onError(String error) {
                                    Toast.makeText(PhotoViewerActivity.this, "Không thể truyền ảnh tới TV: " + error, Toast.LENGTH_SHORT).show();
                                }
                            });
                        })
                        .setNegativeButton("Hủy", null)
                        .show();
            }
        });
    }

    /* ---------- DELETE PHOTO ---------- */
    private void confirmDeleteCurrent() {
        if (items.isEmpty() || currentIndex < 0 || currentIndex >= items.size()) return;
        PhotoItem it = items.get(currentIndex);

        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Xóa ảnh")
                .setMessage("Bạn có chắc chắn muốn xóa ảnh \"" + (it.name != null ? it.name : "") + "\" không?")
                .setNegativeButton("Hủy", null)
                .setPositiveButton("Xóa", (dialog, which) -> executeDelete(it))
                .show();
    }

    private void executeDelete(PhotoItem it) {
        if (it.local) {
            executor.execute(() -> {
                boolean ok = false;
                if (it.localPath != null && !it.localPath.isEmpty()) {
                    File f = new File(it.localPath);
                    if (f.exists()) ok = f.delete();
                }
                final boolean success = ok;
                mainHandler.post(() -> {
                    if (success) {
                        onItemDeleted(it, "Đã xóa ảnh khỏi thiết bị");
                    } else {
                        Toast.makeText(PhotoViewerActivity.this, "Không thể xóa tệp này", Toast.LENGTH_SHORT).show();
                    }
                });
            });
        } else {
            executor.execute(() -> {
                try {
                    String base = baseUrl != null && !baseUrl.isEmpty() ? baseUrl : prefs.getString("base_url", "");
                    String pathParam = URLEncoder.encode(it.rel != null ? it.rel : it.name, "UTF-8");
                    String poolParam = URLEncoder.encode(it.pool != null ? it.pool : "main", "UTF-8");
                    URL deleteUrl = new URL(base + "/api/file?path=" + pathParam + "&pool=" + poolParam);

                    HttpURLConnection conn = (HttpURLConnection) deleteUrl.openConnection();
                    conn.setRequestMethod("DELETE");
                    if (token != null && !token.isEmpty()) {
                        conn.setRequestProperty("Authorization", "Bearer " + token);
                    }
                    conn.setConnectTimeout(10000);
                    conn.setReadTimeout(15000);
                    conn.connect();

                    int code = conn.getResponseCode();
                    if (code >= 200 && code < 300) {
                        mainHandler.post(() -> onItemDeleted(it, "Đã chuyển ảnh vào thùng rác"));
                    } else {
                        mainHandler.post(() -> Toast.makeText(PhotoViewerActivity.this, "Xóa thất bại (mã " + code + ")", Toast.LENGTH_SHORT).show());
                    }
                } catch (Exception e) {
                    mainHandler.post(() -> Toast.makeText(PhotoViewerActivity.this, "Lỗi xóa ảnh: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                }
            });
        }
    }

    private void onItemDeleted(PhotoItem it, String successToast) {
        Toast.makeText(this, successToast, Toast.LENGTH_SHORT).show();

        // Gỡ khỏi favorites nếu có
        if (isFavorited(it)) {
            toggleFavoriteCurrent();
        }

        int removedIndex = currentIndex;
        items.remove(removedIndex);

        if (items.isEmpty()) {
            finish();
            return;
        }

        adapter.notifyItemRemoved(removedIndex);
        if (currentIndex >= items.size()) {
            currentIndex = items.size() - 1;
        }
        viewPager.setCurrentItem(currentIndex, false);
        updateUiForCurrentPage();
    }

    /* ---------- RECYCLER ADAPTER FOR VIEWPAGER2 ---------- */
    private class PhotoAdapter extends RecyclerView.Adapter<PhotoViewHolder> {
        @NonNull
        @Override
        public PhotoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            FrameLayout itemRoot = new FrameLayout(PhotoViewerActivity.this);
            itemRoot.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            PhotoView photoView = new PhotoView(PhotoViewerActivity.this);
            photoView.setMaximumScale(8.0f);
            photoView.setMediumScale(3.0f);
            photoView.setMinimumScale(1.0f);
            itemRoot.addView(photoView, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            ProgressBar spinner = new ProgressBar(PhotoViewerActivity.this);
            spinner.setIndeterminate(true);
            FrameLayout.LayoutParams spLp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
            itemRoot.addView(spinner, spLp);

            return new PhotoViewHolder(itemRoot, photoView, spinner);
        }

        @Override
        public void onBindViewHolder(@NonNull PhotoViewHolder holder, int position) {
            PhotoItem it = items.get(position);
            holder.bind(it);
        }

        @Override
        public int getItemCount() {
            return items.size();
        }
    }

    private class PhotoViewHolder extends RecyclerView.ViewHolder {
        private final PhotoView photoView;
        private final ProgressBar spinner;

        public PhotoViewHolder(@NonNull View itemView, PhotoView photoView, ProgressBar spinner) {
            super(itemView);
            this.photoView = photoView;
            this.spinner = spinner;

            this.photoView.setOnPhotoTapListener((view, x, y) -> toggleControls());
            this.photoView.setOnViewTapListener((view, x, y) -> toggleControls());

            this.photoView.setOnScaleChangeListener((scaleFactor, focusX, focusY) -> {
                boolean isZoomed = this.photoView.getScale() > 1.05f;
                viewPager.setUserInputEnabled(!isZoomed);
            });
        }

        public void bind(PhotoItem it) {
            spinner.setVisibility(View.VISIBLE);
            photoView.setScale(1.0f, false);

            com.bumptech.glide.request.RequestListener<android.graphics.drawable.Drawable> listener =
                    new com.bumptech.glide.request.RequestListener<android.graphics.drawable.Drawable>() {
                @Override
                public boolean onLoadFailed(com.bumptech.glide.load.engine.GlideException e, Object model,
                                            com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> target,
                                            boolean isFirstResource) {
                    spinner.setVisibility(View.GONE);
                    return false;
                }

                @Override
                public boolean onResourceReady(android.graphics.drawable.Drawable resource, Object model,
                                               com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> target,
                                               com.bumptech.glide.load.DataSource dataSource, boolean isFirstResource) {
                    spinner.setVisibility(View.GONE);
                    return false;
                }
            };

            if (it.localPath != null && !it.localPath.isEmpty()) {
                Glide.with(PhotoViewerActivity.this)
                        .load(it.localPath.startsWith("content://") || it.localPath.startsWith("file://")
                                ? Uri.parse(it.localPath) : new File(it.localPath))
                        .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                        .listener(listener)
                        .into(photoView);
            } else if (it.url != null && !it.url.isEmpty()) {
                GlideUrl glideUrl = (token != null && !token.isEmpty())
                        ? new GlideUrl(it.url, new LazyHeaders.Builder().addHeader("Authorization", "Bearer " + token).build())
                        : new GlideUrl(it.url);

                if (it.thumbUrl != null && !it.thumbUrl.isEmpty()) {
                    GlideUrl thumbGlideUrl = (token != null && !token.isEmpty())
                            ? new GlideUrl(it.thumbUrl, new LazyHeaders.Builder().addHeader("Authorization", "Bearer " + token).build())
                            : new GlideUrl(it.thumbUrl);

                    Glide.with(PhotoViewerActivity.this)
                            .load(glideUrl)
                            .thumbnail(Glide.with(PhotoViewerActivity.this).load(thumbGlideUrl).diskCacheStrategy(DiskCacheStrategy.ALL))
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(false)
                            .listener(listener)
                            .into(photoView);
                } else {
                    Glide.with(PhotoViewerActivity.this)
                            .load(glideUrl)
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(false)
                            .listener(listener)
                            .into(photoView);
                }
            } else {
                spinner.setVisibility(View.GONE);
            }
        }
    }
}
