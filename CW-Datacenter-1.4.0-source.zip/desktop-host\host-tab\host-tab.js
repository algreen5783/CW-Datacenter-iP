'use strict';
if (window.top !== window) { return; }
if (!window.host || window.__hostTabInit) { return; }
window.__hostTabInit = true;

/* Cửa sổ frameless: kéo bằng titlebar, nút − □ × điều khiển cửa sổ Electron */
document.body.classList.add('dc-app');
(function bindWinButtons() {
  const makeActions = (parent) => {
    let el = parent.querySelector('.window-actions');
    if (!el) {
      el = document.createElement('div');
      el.className = 'window-actions';
      el.innerHTML = '<button title="Thu nhỏ">−</button><button title="Phóng to">□</button><button title="Đóng">×</button>';
      parent.appendChild(el);
    }
    const btns = el.querySelectorAll('button');
    if (btns[0]) btns[0].addEventListener('click', () => window.host.winControl('min'));
    if (btns[1]) btns[1].addEventListener('click', () => window.host.winControl('max'));
    if (btns[2]) btns[2].addEventListener('click', () => window.host.winControl('close'));
  };
  const appBar = document.querySelector('#page-app > .window-titlebar');
  if (appBar) makeActions(appBar);
  if (window.host.onWinMaximized) {
    window.host.onWinMaximized((m) => {
      document.querySelectorAll('.window-actions button').forEach((b) => {
        if (b.title.toLowerCase().indexOf('phóng') === 0) b.textContent = m ? '❐' : '□';
      });
    });
  }
})();

function escH(s) { return String(s === null || s === undefined ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
const STATE_LABEL = { stopped: 'Đã tắt', starting: 'Đang khởi động…', running: 'Đang chạy', stopping: 'Đang dừng…', external: 'Đang chạy (tiến trình ngoài)' };

/* ---------- Panel máy chủ ngay trong tab Bảng điều khiển ---------- */
(function injectDashPanel() {
  const dash = document.getElementById('view-dashboard');
  if (!dash || dash.querySelector('#dash-srv-panel')) return;
  const head = dash.querySelector('.page-head');
  const panel = document.createElement('section');
  panel.className = 'card panel srv-dash-panel';
  panel.id = 'dash-srv-panel';
  panel.style.cssText = 'padding:16px 18px;margin:0 0 18px';
  panel.innerHTML = ''
    + '<div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-bottom:8px">'
    + '<h3 style="margin:0;min-width:120px;display:flex;align-items:center;gap:8px"><svg class="ic svg-18"><use href="#i-hserver"/></svg> Máy chủ cục bộ</h3>'
    + '<div class="srv-state"><span class="dot stopped cw-srv-dot"></span><span class="cw-srv-state-label">Đã tắt</span></div>'
    + '<button class="btn primary cw-srv-start" style="height:36px"><svg class="ic svg-16"><use href="#i-power"/></svg> Bật server</button>'
    + '<button class="btn danger cw-srv-stop" style="height:36px"><svg class="ic svg-16"><use href="#i-stop"/></svg> Tắt server</button>'
    + '<button class="btn cw-srv-folder" style="height:36px"><svg class="ic svg-16"><use href="#i-folder-open"/></svg> Mở thư mục</button>'
    + '<button class="btn cw-srv-firewall" style="height:36px;border-color:#bbf7d0;color:#15803d;background:#f0fdf4" title="Tự động mở cổng Tường lửa Windows"><svg class="ic svg-16"><use href="#i-lock"/></svg> 🛡️ Fix Tường lửa</button>'
    + '<span class="spacer" style="margin-left:auto"></span>'
    + '</div>'
    + '<div class="muted" style="font-size:13px;margin:2px 0 7px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:6px">'
    + '<span>Địa chỉ LAN — máy khác trong mạng truy cập qua:</span>'
    + '<span class="cw-gpu-dash-badge" style="font-size:12px;font-weight:600;color:#15803d;background:#f0fdf4;padding:2px 8px;border-radius:6px;border:1px solid #bbf7d0">🎮 GPU: Tự động</span>'
    + '</div>'
    + '<div class="cw-lan-chips">—</div>';
  const anchor = head ? head.nextElementSibling : dash.firstChild;
  dash.insertBefore(panel, anchor);

  const startBtn = panel.querySelector('.cw-srv-start');
  const stopBtn = panel.querySelector('.cw-srv-stop');
  const fwBtn = panel.querySelector('.cw-srv-firewall');
  startBtn.addEventListener('click', () => {
    startBtn.disabled = true;
    window.host.start().then(() => refreshInfo());
  });
  stopBtn.addEventListener('click', () => {
    window.host.stop().then(() => refreshInfo());
  });
  if (fwBtn) {
    fwBtn.addEventListener('click', async () => {
      fwBtn.disabled = true;
      const oldHtml = fwBtn.innerHTML;
      fwBtn.innerHTML = '<svg class="ic svg-16"><use href="#i-refresh"/></svg> Đang mở UAC…';
      if (typeof toast === 'function') toast('Đang yêu cầu quyền Administrator (UAC). Vui lòng chọn "Yes" nếu xuất hiện thông báo…', 'info');
      try {
        if (window.host && window.host.fixFirewall) {
          const r = await window.host.fixFirewall();
          if (r && r.ok) {
            if (typeof toast === 'function') toast('✅ Đã mở quyền Tường lửa Windows (Port ' + (r.port || 8080) + ', UDP 46631) thành công!');
            else alert('Đã cấp quyền Tường lửa Windows thành công!');
          } else {
            if (typeof toast === 'function') toast('Chưa cấp được quyền Tường lửa: ' + ((r && r.error) || 'bạn đã từ chối quyền UAC.'), 'err');
          }
        }
      } catch (e) {
        if (typeof toast === 'function') toast('Lỗi: ' + e.message, 'err');
      } finally {
        fwBtn.innerHTML = oldHtml;
        fwBtn.disabled = false;
      }
    });
  }
  panel.querySelector('.cw-srv-folder').addEventListener('click', () => window.host.openFolder());
  panel.querySelector('.cw-lan-chips').addEventListener('click', (e) => {
    const a = e.target.closest && e.target.closest('a[data-url]');
    if (a) { e.preventDefault(); window.host.openExternal(a.dataset.url); }
  });
})();

/* ---------- Trạng thái server ---------- */
function setState(state, port) {
  document.querySelectorAll('.cw-srv-dot').forEach((el) => { el.className = 'dot cw-srv-dot ' + (state || 'stopped'); });
  document.querySelectorAll('.cw-srv-state-label').forEach((el) => { el.textContent = STATE_LABEL[state] || state || 'Đã tắt'; });
  const busy = state === 'running' || state === 'starting' || state === 'external';
  document.querySelectorAll('.cw-srv-start').forEach((el) => { el.disabled = busy; });
  document.querySelectorAll('.cw-srv-stop').forEach((el) => { el.disabled = state === 'stopped' || state === 'external' || state === 'stopping'; });
}
window.host.onState((state) => setState(state));

async function refreshInfo() {
  try {
    const s = await window.host.state();
    setState(s.state, s.port);
  } catch {}
  try {
    const info = await window.host.info();
    const chipsHtml = (info.ips || []).map((ip) => {
      const clientUrl = 'http://' + ip + ':' + info.port;
      return '<a data-url="' + clientUrl + '" style="display:inline-flex;align-items:center;gap:6px;padding:3px 10px;border-radius:99px;font-size:12px;font-weight:600;border:1px solid #a9cdff;color:var(--blue);background:#eff6ff;margin:0 8px 4px 0;text-decoration:none">'
        + '<svg class="ic svg-12"><use href="#i-lan"/></svg> ' + ip + ':' + info.port + '</a>';
    }).join('') || '<span class="muted">Chưa có địa chỉ LAN</span>';
    document.querySelectorAll('.cw-lan-chips').forEach((el) => { el.innerHTML = chipsHtml; });
  } catch {}
  try {
    const s = await window.host.state();
    if (s.state === 'running' || s.state === 'external') {
      const info = await window.host.info();
      const gpuRes = await fetch('http://localhost:' + (info.port || 8080) + '/api/gpu/status').then((r) => r.json());
      if (gpuRes && gpuRes.statusTitle) {
        document.querySelectorAll('.cw-gpu-dash-badge').forEach((el) => {
          el.textContent = '🎮 GPU: ' + gpuRes.statusTitle;
        });
      }
    }
  } catch {}
}
refreshInfo();
