@echo off
title Home Datacenter - HOST SERVER
cd /d "%~dp0"
set PATH=%~dp0.tools\node;%PATH%
set NODE_EXE=%~dp0.tools\node\node.exe
if not exist "%NODE_EXE%" (
  echo [LOI] Khong tim thay Node.js tai .tools\node\node.exe
  pause
  exit /b 1
)
echo Dang khoi dong Home Datacenter Server...
"%NODE_EXE%" server\server.js
echo.
echo Server da dung. Nhan phim bat ky de thoat.
pause >nul
