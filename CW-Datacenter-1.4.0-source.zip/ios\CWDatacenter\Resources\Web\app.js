/* CW Datacenter Android client - app.js
 * Điều khiển toàn bộ UI MVP (index.html) và gọi server qua native bridge `DC`.
 * UX giữ đúng bản HTML: Discover -> Sign in -> Trust -> Tabs (Files/Truyền tải/Yêu thích/Đồng bộ/Thùng rác).
 */
(() => {
'use strict';

const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const enc = encodeURIComponent;

/* Kiểm tra phiên bản APK ngay khi khởi động: bản mới phải có DC.call (cầu nối gom 1 mối).
 * APK cũ không có DC.call -> hiện thông báo rõ thay vì một lỗi khó hiểu. */
function showOldApkNotice() {
  const d = document.createElement('div');
  d.style.cssText = 'position:fixed;inset:0;z-index:9999;background:#fff;display:flex;'
    + 'flex-direction:column;align-items:center;justify-content:center;text-align:center;'
    + 'padding:32px;gap:14px;font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:#111827;';
  d.innerHTML = '<div style="font-size:40px;line-height:1">⚠️</div>'
    + '<div style="font-size:18px;font-weight:600">APK cũ, hãy cài lại bản mới</div>'
    + '<div style="font-size:13.5px;color:#667085;line-height:1.6;max-width:320px">'
    + 'Phiên bản ứng dụng trên máy không khớp với giao diện này. '
    + 'Hãy gỡ và cài lại file APK mới nhất của CW Datacenter.</div>';
  (document.body || document.documentElement).appendChild(d);
}
if (!window.DC || typeof DC.call !== 'function') {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', showOldApkNotice);
  else showOldApkNotice();
  throw new Error('APK cũ: thiếu cầu nối DC.call');
}

const META = JSON.parse(DC.getMeta() || '{}');
const HOST = (META.manufacturer || '') + ' ' + (META.device || '');

/* ---------- Native bridge plumbing ---------- */
const cbs = new Map();
let cbSeq = 0;
function callNative(method, ...args) {
  return new Promise((res, rej) => {
    const id = String(++cbSeq);
    cbs.set(id, { res, rej });
    try { DC.call(method, id, JSON.stringify(args)); } catch (e) { cbs.delete(id); rej(String(e)); }
  });
}
DC._cb = (id, ok, jsonStr) => {
  const c = cbs.get(id); if (!c) return; cbs.delete(id);
  let data = null;
  if (typeof jsonStr === 'object' && jsonStr !== null) {
    data = jsonStr;
  } else {
    try { data = jsonStr ? JSON.parse(jsonStr) : {}; } catch (e) {}
  }
  ok ? c.res(data) : c.rej((data && data.err) || 'Lỗi');
};
DC._cbObj = (obj) => {
  if (obj && obj.id) {
    DC._cb(obj.id, obj.ok, obj.data);
  }
};
DC._evt = (arg) => {
  try {
    const obj = typeof arg === 'string' ? JSON.parse(arg) : arg;
    if (obj) onNativeEvent(obj);
  } catch (e) {}
};
DC._back = () => handleBack();
DC._insets = (top, bottom) => {
  const root = document.documentElement;
  root.style.setProperty('--sat', Math.max(0, top | 0) + 'px');
  root.style.setProperty('--sab', Math.max(0, bottom | 0) + 'px');
};
document.addEventListener('selectstart', (e) => {
  const t = e.target;
  if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) return;
  e.preventDefault();
});
try {
  const ins = String(DC.getInsets() || '').split(',');
  if (ins.length === 2) DC._insets(parseInt(ins[0], 10), parseInt(ins[1], 10));
} catch (e) {}

/* ---------- State ---------- */
let server = null;               // {name, host, ip, port, baseUrl, via}
let token = null;
let me = null;                   // {role, user}
let pools = [];
let pool = 'main';
let currentPath = '';
let parentPath = null;
let entries = [];
let currentView = 'discover';
let sortMode = 'name';
let searchQuery = '';
let transfers = {};              // key -> {key,id,dir,name,rel,status,done,total,speed,err,path,pool,spec}
let favs = [];
let syncDb = {};                 // rel -> {size, mtime}
let dlPaths = {};                // rel -> local path (downloaded)
let syncPaused = false;
let camOn = false;
let rememberDevice = true;
let lockMap = null;
let lockBans = null;
const lockSession = new Set();
let clipboard = { items: [], mode: '', dir: '' };   // {path,pool,local,dir,size}[] + mode 'copy'|'cut'
let syncDest = null;                                 // {localPath, name} — thư mục trên máy lưu file tải về
let syncSrc = null;                                  // {path, name} — thư mục trên máy đồng bộ 1 chiều lên host
let syncDbUp = {};                                   // rel -> {size, mtime} — tệp thiết bị đã đẩy lên host
let syncUpQueue = [];
let syncUpBusy = false;
let syncUpWatchdog = null;
let phoneFolderOk = false;
let lpSuppressClick = false; // chặn click ngay sau khi nhấn giữ thành công (tránh bỏ chọn luôn)
const LOCAL_POOL = 'thisdevice';
let localDrive = null;                               // {treeUri, name} — gốc bộ nhớ của thiết bị (do người dùng chọn)
let localNav = [];                                   // [{path,name}] — stack thư mục local đang duyệt
let localFree = '';                                  // dung lượng trống ổ thiết bị (hiển thị như các ổ chia sẻ)
let localRootPath = '';                              // đường dẫn gốc bộ nhớ trong (/storage/emulated/0)

const kvGet = (k) => { const v = DC.loadKV(k); try { return v ? JSON.parse(v) : null; } catch (e) { return v; } };
const kvSet = (k, v) => DC.saveKV(k, JSON.stringify(v));

function kFavs() { return 'favs:' + (server ? server.baseUrl : ''); }
function kSync() { return 'sync:' + (server ? server.baseUrl : ''); }
function kDlPaths() { return 'dl:' + (server ? server.baseUrl : ''); }
function kToken() { return 'token:' + (server ? server.baseUrl : ''); }
function kCreds() { return 'creds:' + (server ? server.baseUrl : ''); }
function kTrust() { return 'trust:' + (server ? server.baseUrl : '') + ':' + ((me && me.user) || ''); }
function kLocks() { return 'locks:' + (server ? server.baseUrl : ''); }
function kLockBans() { return 'lockban:' + (server ? server.baseUrl : ''); }
function kPending() { return 'pending:' + (server ? server.baseUrl : ''); }
function kLocalDrive() { return 'localDrive:' + (server ? server.baseUrl : ''); }
function kSyncSrc() { return 'syncSrc:' + (server ? server.baseUrl : ''); }
function kSyncDbUp() { return 'syncUp:' + (server ? server.baseUrl : ''); }

/* ---------- Helpers ---------- */
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function fmtBytes(b) {
  if (b == null || b < 0) return '';
  if (b < 1024) return b + ' B';
  if (b < 1024 * 1024) return (b / 1024).toFixed(0) + ' KB';
  if (b < 1024 * 1024 * 1024) return (b / 1024 / 1024).toFixed(1) + ' MB';
  return (b / 1024 / 1024 / 1024).toFixed(2) + ' GB';
}
function fmtDate(iso) {
  try {
    const d = new Date(iso);
    const p = (n) => (n < 10 ? '0' + n : '' + n);
    return p(d.getDate()) + '/' + p(d.getMonth() + 1) + '/' + d.getFullYear() + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  } catch (e) { return ''; }
}
function fmtAgo(iso) {
  const t = Date.now() - new Date(iso).getTime();
  if (t < 60000) return 'vừa xong';
  if (t < 3600000) return Math.floor(t / 60000) + ' phút trước';
  if (t < 86400000) return Math.floor(t / 3600000) + ' giờ trước';
  const d = Math.floor(t / 86400000);
  return d === 1 ? 'hôm qua' : d + ' ngày trước';
}
function fmtEta(total, done, speed) {
  if (!speed || speed <= 0 || done >= total) return '';
  let s = Math.round((total - done) / speed);
  const m = Math.floor(s / 60); s %= 60;
  if (m > 0) return m + ' phút ' + s + ' giây';
  return s + ' giây';
}
const VIDEO_EXT = ['mp4', 'mkv', 'mov', 'webm', 'avi', 'm4v', '3gp', '3gpp', 'flv', 'wmv', 'mpg', 'mpeg', 'ts', 'm2ts', 'mts', 'ogv', 'rm', 'rmvb', 'm4a', 'mp3', 'wav', 'flac'];
function fileIcon(name) {
  const ext = String(name || '').split('.').pop().toLowerCase();
  if (VIDEO_EXT.includes(ext)) return { sym: 'i-video', color: 'var(--purple)' };
  if (ext === 'pdf') return { sym: 'i-pdf', color: 'var(--red)' };
  if (['onnx', 'pt', 'pth', 'bin', 'safetensors', 'gguf', 'model', 'h5'].includes(ext)) return { sym: 'i-cube', color: 'var(--cyan)' };
  return { sym: 'i-cube', color: 'var(--muted)' };
}
function iconSvg(sym, cls) { return '<svg class="' + (cls || 'svg-24') + '"><use href="#' + sym + '"/></svg>'; }

function relOf(e) { return e._rel || (currentPath ? currentPath + '/' : '') + e.name; }
function dirRelOf(rel) { return String(rel || '').includes('/') ? String(rel).slice(0, String(rel).lastIndexOf('/')) : ''; }
function isReader() { return !!me; }
function canWrite() { return me && me.role !== 'viewer'; }
function errText(e) { return (e && (e.error || e.err)) || String(e) || 'Lỗi'; }
function isLocalMode() { return pool === LOCAL_POOL; }

/* ========== LOCKS (port từ web client: khóa bằng mật khẩu, lưu client-side) ========== */
function sha256js(s) {
  const K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  const rr = (v, n) => (v >>> n) | (v << (32 - n));
  const H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
  const bytes = new TextEncoder().encode(s);
  const l = bytes.length, bitLen = l * 8;
  const buf = new Uint8Array(((l + 9 + 63) >> 6) << 6);
  buf.set(bytes); buf[l] = 0x80;
  const dv = new DataView(buf.buffer);
  dv.setUint32(buf.length - 8, Math.floor(bitLen / 0x100000000), false);
  dv.setUint32(buf.length - 4, bitLen >>> 0, false);
  const w = new Uint32Array(64);
  for (let i = 0; i < buf.length; i += 64) {
    for (let j = 0; j < 16; j++) w[j] = dv.getUint32(i + j * 4, false);
    for (let j = 16; j < 64; j++) {
      const s0 = rr(w[j - 15], 7) ^ rr(w[j - 15], 18) ^ (w[j - 15] >>> 3);
      const s1 = rr(w[j - 2], 17) ^ rr(w[j - 2], 19) ^ (w[j - 2] >>> 10);
      w[j] = (w[j - 16] + s0 + w[j - 7] + s1) >>> 0;
    }
    let a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
    for (let j = 0; j < 64; j++) {
      const S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25);
      const ch = (e & f) ^ (~e & g);
      const t1 = (h + S1 + ch + K[j] + w[j]) >>> 0;
      const S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const t2 = (S0 + maj) >>> 0;
      h = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
    }
    H[0] = (H[0] + a) >>> 0; H[1] = (H[1] + b) >>> 0; H[2] = (H[2] + c) >>> 0; H[3] = (H[3] + d) >>> 0;
    H[4] = (H[4] + e) >>> 0; H[5] = (H[5] + f) >>> 0; H[6] = (H[6] + g) >>> 0; H[7] = (H[7] + h) >>> 0;
  }
  return H.map((v) => v.toString(16).padStart(8, '0')).join('');
}

function ensureLockMap() { if (!lockMap) lockMap = kvGet(kLocks()) || {}; return lockMap; }
function ensureLockBans() { if (!lockBans) lockBans = kvGet(kLockBans()) || {}; return lockBans; }
function saveLockMap() { kvSet(kLocks(), lockMap || {}); }
function saveLockBans() { kvSet(kLockBans(), lockBans || {}); }
async function syncLocksFromServer() {
  if (isLocalMode() || !server) return;
  try {
    const data = await api('/api/locks', 'GET');
    const serverLocks = (data && data.locks) || [];
    const map = {};
    for (const l of serverLocks) {
      if (l.type === 'drive') {
        map[poolLockKey(l.pool)] = l.hash;
      } else {
        const p = (l.path || '').replace(/^\/+/, '');
        const dir = p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : '';
        const nm = p.includes('/') ? p.slice(p.lastIndexOf('/') + 1) : p;
        map[lockKeyOf(l.pool || 'main', dir, nm)] = l.hash;
      }
    }
    lockMap = map;
    saveLockMap();
    updateLockUI();
  } catch {}
}
function poolById(id) { return pools.find((p) => p.id === id) || null; }
function poolNameOf(id) { const p = poolById(id); return p ? p.name : (id || 'Ổ mặc định'); }
function lockKeyOf(p, dirRel, name) { return (server ? server.baseUrl : '') + '|' + (p || 'main') + '|' + (dirRel ? dirRel + '/' : '') + name; }
function poolLockKey(p) { return (server ? server.baseUrl : '') + '|pool:' + (p || 'main') + '|'; }
function lockKeyFor(f) { return lockKeyOf(f.pool || pool, f.dirRel != null ? f.dirRel : currentPath, f.name); }
function poolTargetOf(p) { return { kind: 'pool', name: poolNameOf(p), pool: p, _lockKey: poolLockKey(p) }; }
function hasPoolLock(p) { return !!ensureLockMap()[poolLockKey(p)]; }
function isPoolLocked(p) { return !!p && hasPoolLock(p) && !lockSession.has(poolLockKey(p)); }

function findLockedAncestor(p, dirRel) {
  const map = ensureLockMap();
  const parts = dirRel ? String(dirRel).split('/').filter(Boolean) : [];
  for (let i = 1; i <= parts.length; i++) {
    const parentDir = parts.slice(0, i - 1).join('/');
    const key = lockKeyOf(p, parentDir, parts[i - 1]);
    if (map[key] && !lockSession.has(key)) {
      return { kind: 'folder', name: parts[i - 1], type: 'dir', rel: (parentDir ? parentDir + '/' : '') + parts[i - 1], dirRel: parentDir, pool: p, _lockKey: key };
    }
  }
  return null;
}

function resolveLockTarget(f) {
  if (!f) return null;
  const p = f.pool || pool;
  const map = ensureLockMap();
  const pk = poolLockKey(p);
  if (map[pk] && !lockSession.has(pk)) return poolTargetOf(p);
  const anc = findLockedAncestor(p, f.dirRel != null ? f.dirRel : currentPath);
  if (anc) return anc;
  if (f.name && map[lockKeyFor(f)] && !lockSession.has(lockKeyFor(f))) return f;
  return null;
}

function entryLocked(f) { return !!ensureLockMap()[lockKeyFor(f)] && !lockSession.has(lockKeyFor(f)); }

function lockBanInfo(key) {
  const e = ensureLockBans()[key];
  if (e && e.until && Date.now() < e.until) return { fails: e.fails || 0, until: e.until };
  return { fails: 0, until: 0 };
}
function recordLockFail(key) {
  const m = ensureLockBans();
  let e = m[key];
  if (!e || (e.until && Date.now() >= e.until)) e = { fails: 0, until: 0 };
  e.fails = (e.fails || 0) + 1;
  if (e.fails >= 5) { e.until = Date.now() + 8 * 60 * 60 * 1000; e.fails = 0; }
  m[key] = e;
  saveLockBans();
  return e;
}
function clearLockBan(key) { delete ensureLockBans()[key]; saveLockBans(); }
function fmtLockDur(ms) {
  const s = Math.max(1, Math.round(ms / 1000));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  if (h) return h + ' giờ ' + m + ' phút';
  if (m) return m + ' phút ' + sec + ' giây';
  return sec + ' giây';
}

function unlockSheet(t, onOk) {
  const key = t._lockKey || lockKeyFor(t);
  openSheet('Mở khóa "' + t.name + '"', (body) => {
    const hint = document.createElement('div');
    hint.style.cssText = 'font-size:12.5px;color:#667085;line-height:1.6;margin-bottom:12px';
    hint.textContent = t.kind === 'pool' ? 'Ổ đĩa này đang bị khóa — nhập đúng mật khẩu khóa để dùng.'
      : (t.kind === 'folder' ? 'Thư mục "' + t.name + '" đang bị khóa — nhập đúng mật khẩu khóa để mở các tệp bên trong.' : 'Nhập đúng mật khẩu khóa đã đặt để mở.');
    body.appendChild(hint);
    const wrap = document.createElement('div');
    wrap.className = 'field';
    wrap.innerHTML = '<div class="input-wrap">' + iconSvg('i-lock', 'svg-20') + '<input type="password" placeholder="Mật khẩu khóa"></div>';
    body.appendChild(wrap);
    const input = wrap.querySelector('input');
    const errEl = document.createElement('div');
    errEl.style.cssText = 'color:var(--red);font-size:12.5px;margin:2px 2px 8px;min-height:16px';
    body.appendChild(errEl);
    setTimeout(() => input.focus(), 120);
    const row = document.createElement('div');
    row.className = 'row-btn';
    row.innerHTML = '<button class="btn secondary">Hủy</button><button class="btn primary">Xác nhận</button>';
    row.children[0].addEventListener('click', closeSheet);
    row.children[1].addEventListener('click', async () => {
      const ban = lockBanInfo(key);
      if (ban.until > Date.now()) { errEl.textContent = 'Đã sai quá 5 lần — mở lại sau ' + fmtLockDur(ban.until - Date.now()); return; }
      const v = input.value;
      if (!v) return;
      const stored = ensureLockMap()[key];
      const poolMode = t.kind === 'pool';
      const poolId = t.pool || pool;
      const itemRel = poolMode ? '' : (t.dirRel ? t.dirRel + '/' : '') + t.name;
      const itemType = poolMode ? 'drive' : (t.type === 'dir' ? 'folder' : 'file');

      let isOk = false;
      const h = sha256js(v);
      if (stored && h === stored) {
        isOk = true;
      } else {
        try {
          const vRes = await api('/api/locks/verify', 'POST', {
            pool: poolId,
            path: itemRel,
            type: itemType,
            password: v
          });
          if (vRes && vRes.ok) isOk = true;
        } catch {}
      }

      if (isOk) {
        clearLockBan(key);
        lockSession.add(key);
        closeSheet();
        DC.toast('Đã mở khóa "' + t.name + '" — có hiệu lực đến khi đóng app');
        updateLockUI();
        onOk && onOk();
      } else {
        const e = recordLockFail(key);
        input.value = '';
        if (e.until && Date.now() < e.until) errEl.textContent = 'Đã sai quá 5 lần — không thể mở trong 8 giờ. Mở lại sau ' + fmtLockDur(e.until - Date.now());
        else errEl.textContent = 'Mật khẩu không đúng (' + (e.fails || 0) + '/5 lần). Còn sai thêm ' + (5 - (e.fails || 0)) + ' lần sẽ khóa 8 giờ.';
        input.focus();
      }
    });
    body.appendChild(row);
    const ban0 = lockBanInfo(key);
    if (ban0.until > Date.now()) errEl.textContent = 'Đã sai quá 5 lần — mở lại sau ' + fmtLockDur(ban0.until - Date.now());
    else if (ban0.fails > 0) errEl.textContent = 'Đã nhập sai ' + ban0.fails + '/5 lần.';
  });
}

function lockSheet(t, onDone) {
  const key = t._lockKey || lockKeyFor(t);
  const poolMode = t.kind === 'pool';
  openSheet('Khóa "' + t.name + '"', (body) => {
    const hint = document.createElement('div');
    hint.style.cssText = 'font-size:12.5px;color:#667085;line-height:1.6;margin-bottom:12px';
    hint.textContent = poolMode ? 'Khóa toàn bộ ổ đĩa này — mọi tệp và thư mục bên trong đều yêu cầu mật khẩu để mở trên cả PC và điện thoại.'
      : 'Mật khẩu khóa sẽ được lưu trên máy chủ và đồng bộ với cả PC và điện thoại.';
    body.appendChild(hint);
    const wrap = document.createElement('div');
    wrap.className = 'field';
    wrap.innerHTML = '<div class="input-wrap">' + iconSvg('i-lock', 'svg-20') + '<input type="password" placeholder="Mật khẩu khóa (tối thiểu 3 ký tự)"></div>';
    body.appendChild(wrap);
    const input = wrap.querySelector('input');
    const note = document.createElement('div');
    note.style.cssText = 'color:#98a2b3;font-size:12px;margin:4px 2px 10px';
    note.textContent = 'Mật khẩu đồng bộ trên tất cả thiết bị kết nối tới host.';
    body.appendChild(note);
    setTimeout(() => input.focus(), 120);
    const row = document.createElement('div');
    row.className = 'row-btn';
    row.innerHTML = '<button class="btn secondary">Hủy</button><button class="btn primary">Xác nhận</button>';
    row.children[0].addEventListener('click', closeSheet);
    row.children[1].addEventListener('click', async () => {
      if (input.value.length < 3) { note.textContent = '✕ Mật khẩu khóa cần tối thiểu 3 ký tự.'; note.style.color = 'var(--red)'; return; }
      const poolId = t.pool || pool;
      const itemRel = poolMode ? '' : (t.dirRel ? t.dirRel + '/' : '') + t.name;
      const itemType = poolMode ? 'drive' : (t.type === 'dir' ? 'folder' : 'file');
      try {
        await api('/api/locks', 'POST', {
          pool: poolId,
          path: itemRel,
          type: itemType,
          name: t.name,
          password: input.value
        });
      } catch {}
      await syncLocksFromServer();
      closeSheet();
      DC.toast('Đã khóa "' + t.name + '"');
      updateLockUI();
      onDone && onDone();
    });
    body.appendChild(row);
  });
}

function removeLock(t, onDone) {
  sheetConfirm('Gỡ khóa "' + t.name + '"', 'Gỡ bỏ mật khẩu khóa — ai cũng có thể mở mục này mà không cần mật khẩu.', 'Gỡ khóa', async () => {
    const poolMode = t.kind === 'pool';
    const poolId = t.pool || pool;
    const itemRel = poolMode ? '' : (t.dirRel ? t.dirRel + '/' : '') + t.name;
    const itemType = poolMode ? 'drive' : (t.type === 'dir' ? 'folder' : 'file');
    try {
      await api('/api/locks', 'DELETE', {
        pool: poolId,
        path: itemRel,
        type: itemType
      });
    } catch {}
    await syncLocksFromServer();
    DC.toast('Đã gỡ khóa "' + t.name + '"');
    updateLockUI();
    onDone && onDone();
  });
}

function requireUnlocked(f, fn) {
  const t = resolveLockTarget(f);
  if (!t) { fn(); return; }
  DC.toast((t.kind === 'pool' ? 'Ổ đĩa "' + t.name + '"' : '"' + t.name + '"') + ' đang bị khóa — hãy mở khóa trước.');
  unlockSheet(t, fn);
}

/* ========== POOL BAR (chọn ổ đĩa) ========== */
function isSharedPool(p) {
  if (!p) return false;
  const id = String(typeof p === 'string' ? p : (p.id || '')).trim().toLowerCase();
  const nm = String(typeof p === 'string' ? '' : (p.name || '')).trim().toLowerCase();
  return id === 'shared' || nm === 'shared' || id.startsWith('shared_') || nm.startsWith('shared') || /^(shared|dùng chung|đã chia sẻ)$/i.test(nm) || /^(shared|dùng chung|đã chia sẻ)$/i.test(id);
}

function renderPoolBar() {
  const bar = $('#poolBar');
  if (!bar) return;
  if (!server) { bar.style.display = 'none'; return; }
  bar.innerHTML = '';
  bar.style.display = '';
  const isSyncActive = !isLocalMode() && (currentPath === phoneName() || currentPath.startsWith(phoneName() + '/'));
  const mkPill = (cfg) => {
    const b = document.createElement('button');
    let isActive = false;
    if (cfg.id === 'sync_device_folder') {
      isActive = isSyncActive;
    } else if (cfg.id === LOCAL_POOL) {
      isActive = isLocalMode();
    } else {
      isActive = !isSyncActive && !isLocalMode() && cfg.id === pool;
    }
    b.className = 'pool-pill' + (isActive ? ' active' : '') + (cfg.offline ? ' offline' : '');
    b.innerHTML = cfg.html;
    b.addEventListener('click', cfg.onClick);
    bar.appendChild(b);
  };
  mkPill({
    id: LOCAL_POOL,
    html: iconSvg('i-phone', 'svg-18') + '<span>Thiết bị này</span>' + (localFree ? '<span class="pf">' + esc(localFree) + '</span>' : ''),
    onClick: () => switchPool(LOCAL_POOL),
  });
  mkPill({
    id: 'sync_device_folder',
    html: iconSvg('i-sync', 'svg-18') + '<span>Đồng bộ (' + esc(phoneName()) + ')</span>',
    onClick: async () => {
      const hp = await hostPool();
      if (!hp) { DC.toast('Chưa kết nối máy chủ.'); return; }
      if (pool !== hp.id) {
        pool = hp.id;
      }
      goDir(phoneName());
    }
  });
  const rawList = pools && pools.length ? pools : (pool && pool !== LOCAL_POOL ? [{ id: pool, name: poolNameOf(pool), online: true }] : []);
  const list = rawList.filter(p => !isSharedPool(p));
  if (isSharedPool(pool) && list.length) {
    pool = list[0].id;
  }
  list.forEach((p) => {
    const free = p.free != null ? 'trống ' + fmtBytes(p.free) : '';
    mkPill({
      id: p.id,
      offline: p.online === false,
      html: (isPoolLocked(p.id) ? iconSvg('i-lock', 'svg-18') : iconSvg('i-server', 'svg-18')) + '<span>' + esc(p.name) + '</span>' + (free ? '<span class="pf">' + esc(free) + '</span>' : ''),
      onClick: () => {
        if (p.online === false) { DC.toast('Ổ "' + p.name + '" đang không khả dụng trên máy chủ.'); return; }
        if (isPoolLocked(p.id)) { unlockSheet(poolTargetOf(p.id), () => switchPool(p.id)); return; }
        switchPool(p.id);
      },
    });
  });
}

function refreshLocalFree() {
  callNative('localFsInfo', '').then((r) => {
    if (r && r.rootPath && !localRootPath) localRootPath = r.rootPath;
    if (r && r.free != null) {
      localFree = 'trống ' + fmtBytes(r.free);
      renderPoolBar();
    }
  }).catch(() => {});
}

async function ensureLocalFsAccess() {
  try {
    const st = await callNative('localFsStatus', '');
    if (st && st.ok) {
      localDrive = { fs: true, name: 'Thiết bị này' };
      kvSet(kLocalDrive(), localDrive);
      refreshLocalFree();
      return true;
    }
    await callNative('requestLocalFsAccess', '');
    DC.toast('Sau khi cấp quyền, quay lại đây và bấm "Thiết bị này" lần nữa.');
    return false;
  } catch (e) {
    DC.toast(errText(e));
    return false;
  }
}

function pollLocalFsAfterResume() {
  if (pool !== LOCAL_POOL || (localDrive && localDrive.fs)) return;
  callNative('localFsStatus', '').then((st) => {
    if (st && st.ok) {
      localDrive = { fs: true, name: 'Thiết bị này' };
      kvSet(kLocalDrive(), localDrive);
      refreshLocalFree();
      if (pool === LOCAL_POOL) loadLocalFiles();
    }
  }).catch(() => {});
}
function refreshFavsAfterResume() {
  favs = kvGet(kFavs()) || [];
  if (currentView === 'favorites') renderFavorites();
}
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    pollLocalFsAfterResume();
    refreshFavsAfterResume();
  }
});
window.addEventListener('focus', refreshFavsAfterResume);

function switchPool(id) {
  if (id === pool) return;
  pool = id;
  if (pool === LOCAL_POOL) localNav = [];
  exitSelMode();
  updateFabVisibility();
  renderPoolBar();
  loadFiles('');
}

function renderLockedPoolState() {
  const list = $('#files .file-list');
  list.innerHTML = '';
  const d = document.createElement('div');
  d.className = 'empty';
  d.style.paddingTop = '60px';
  d.innerHTML = '<div style="color:var(--blue)">' + iconSvg('i-lock', 'svg-38') + '</div><div style="margin-top:14px">Ổ đĩa "' + esc(poolNameOf(pool)) + '" đang bị khóa.</div>';
  const btn = document.createElement('button');
  btn.className = 'btn primary';
  btn.style.cssText = 'width:auto;padding:0 22px;margin:18px auto 0;display:block';
  btn.textContent = 'Mở khóa bằng mật khẩu';
  btn.addEventListener('click', () => unlockSheet(poolTargetOf(pool), () => loadFiles('')));
  d.appendChild(btn);
  list.appendChild(d);
  const bc = $('#files .breadcrumb');
  if (bc) bc.innerHTML = '<span class="root">' + esc(server ? server.name : 'CW Datacenter') + '</span><span>›</span><span class="now">Ổ đĩa đang khóa</span>';
}

function updateLockUI() {
  renderPoolBar();
  if (currentView === 'files') {
    if (isPoolLocked(pool)) renderLockedPoolState();
    else renderFiles();
  }
}

/* ========== PREVIEW (xem trực tiếp trong app, stream từ server) ========== */
const STREAM_IMG = /\.(png|jpe?g|gif|webp|bmp|avif|svg|heic|heif)$/i;
const STREAM_VIDEO = /\.(mp4|webm|mkv|mov|m4v|avi|3gp|3gpp|flv|wmv|mpg|mpeg|ts|m2ts|mts|vob|ogv|rm|rmvb)$/i;
const STREAM_AUDIO = /\.(mp3|wav|ogg|m4a|flac|aac)$/i;
const STREAM_PDF = /\.pdf$/i;
const STREAM_TEXT = /\.(txt|md|log|json|csv|tsv|xml|yml|yaml|ini|srt|vtt|js|css|html|c|cpp|h|py|sh|bat)$/i;
function isPreviewable(name) { return STREAM_IMG.test(name) || STREAM_VIDEO.test(name) || STREAM_AUDIO.test(name) || STREAM_PDF.test(name) || STREAM_TEXT.test(name); }

function ePool(e) { return (e && e.pool) ? e.pool : pool; }

function fileApiUrl(rel, extra, poolId) {
  const p = poolId != null ? poolId : pool;
  return server.baseUrl + '/api/file?path=' + enc(rel) + (extra || '') + (p && p !== LOCAL_POOL ? '&pool=' + enc(p) : '');
}

function mediaProxyUrl(rel, video, poolId) {
  const p = poolId != null ? poolId : pool;
  try {
    const u = DC.proxyUrl(enc(rel), p && p !== LOCAL_POOL ? enc(p) : '', video);
    if (u) return u;
  } catch (e) {}
  return video
    ? (server.baseUrl + '/api/video?path=' + enc(rel) + (p && p !== LOCAL_POOL ? '&pool=' + enc(p) : ''))
    : fileApiUrl(rel, '&preview=1', p);
}

function localDocUrl(e) {
  if (!e || !e._p) return '';
  try {
    return String(DC.localFsUrl(JSON.stringify({ p: e._p, mime: e._mime || '' })) || '');
  } catch (err) { return ''; }
}

function localSpec(e) {
  return { p: e._p, name: e.name || '', mime: e._mime || '' };
}


let previewEntry = null;
let previewList = [];
let previewIdx = -1;

function isMediaEntry(name) { return STREAM_IMG.test(name) || STREAM_VIDEO.test(name) || STREAM_AUDIO.test(name); }

function previewMediaList() {
  return displayEntries().filter((e) => e.type === 'file' && isMediaEntry(e.name));
}

function updatePvNav() {
  const prevBtn = $('#pvPrev');
  const nextBtn = $('#pvNext');
  const has = previewList.length > 1 && isMediaEntry(previewEntry ? previewEntry.name : '');
  prevBtn.disabled = !(has && previewIdx > 0);
  nextBtn.disabled = !(has && previewIdx < previewList.length - 1);
}

function fmtTime(ms) {
  if (!ms || ms <= 0) return '00:00';
  let s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  s %= 3600;
  const m = Math.floor(s / 60);
  const ss = s % 60;
  if (h > 0) {
    return `${h}:${m < 10 ? '0' : ''}${m}:${ss < 10 ? '0' : ''}${ss}`;
  }
  return `${m < 10 ? '0' : ''}${m}:${ss < 10 ? '0' : ''}${ss}`;
}

let pendingResumeVideo = null;

function showVideoResumePrompt(e, rel, p, plIdx, playlist, pos) {
  pendingResumeVideo = { e, rel, p, plIdx, playlist, pos };
  const modal = $('#videoResumeModal');
  if (!modal) {
    launchMobileVideo(e, rel, p, plIdx, playlist, -1);
    return;
  }
  $('#vrTitle').textContent = e.name;
  $('#vrSub').innerHTML = `Bạn đã xem video này đến <b>${fmtTime(pos)}</b>.<br>Bạn muốn xem tiếp hay phát lại từ đầu?`;
  $('#vrResumeLabel').textContent = `▶ Xem tiếp (từ ${fmtTime(pos)})`;
  modal.style.display = 'flex';
}

function closeVideoResumeModal() {
  const modal = $('#videoResumeModal');
  if (modal) modal.style.display = 'none';
  pendingResumeVideo = null;
}

function openVideoPlayer(initialFile, allSiblings, startPosSec) {
  const vidSiblings = (allSiblings && allSiblings.length ? allSiblings : [initialFile]).filter((x) => STREAM_VIDEO.test(x.name));
  if (!vidSiblings.length) vidSiblings.push(initialFile);
  let curIndex = vidSiblings.findIndex((x) => x.name === initialFile.name);
  if (curIndex < 0) curIndex = 0;
  let curFile = vidSiblings[curIndex];
  let curPool = ePool(curFile);

  const container = document.createElement('div');
  container.className = 'cw-player';
  container.id = 'cwPlayer';
  container.innerHTML = `
    <div class="cw-surface">
      <video id="cwVideo" playsinline webkit-playsinline preload="auto"></video>
      <div class="cw-ripple-jump left" id="cwRippleLeft">10s ⏪</div>
      <div class="cw-ripple-jump right" id="cwRippleRight">⏩ 10s</div>
    </div>

    <!-- Topbar -->
    <div class="cw-topbar">
      <button class="cw-btn-icon" id="cwBack" title="Quay lại">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none"><path d="M15 18l-6-6 6-6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
      <div class="cw-title" id="cwTitle" title="${curFile.name}">${curFile.name}</div>
      <div class="cw-top-actions">
        <button class="cw-btn-icon" id="cwFav" title="Thêm vào yêu thích">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
        </button>
        <button class="cw-btn-icon" id="cwCast" title="Truyền phát Smart TV">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M3 18c1.66 0 3 1.34 3 3M3 14c3.87 0 7 3.13 7 7M3 10c6.08 0 11 4.92 11 11M5 4h13a3 3 0 0 1 3 3v10" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>
        </button>
        <button class="cw-btn-icon" id="cwSub" title="Phụ đề">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="14" rx="2.5" stroke="currentColor" stroke-width="1.9"/><path d="M10 10a2 2 0 1 0 0 4M17 10h-2v4h2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
        </button>
        <button class="cw-btn-icon" id="cwMore" title="Tùy chọn khác">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="12" cy="19" r="1.8"/></svg>
        </button>
      </div>
    </div>

    <!-- Center Controls -->
    <div class="cw-center">
      <button class="cw-round-btn" id="cwRew10" title="Lùi 10 giây">
        <div class="cw-skip-wrap">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M11 6v12l-8-6 8-6Zm9 0v12l-8-6 8-6Z"/></svg>
          <span>10</span>
        </div>
      </button>
      <button class="cw-round-btn main" id="cwPlay" title="Phát / Tạm dừng">
        <div class="cw-pause-bars" id="cwPauseIcon"><span></span><span></span></div>
        <div class="cw-play-triangle hidden" id="cwPlayIcon"></div>
      </button>
      <button class="cw-round-btn" id="cwFwd10" title="Tiến 10 giây">
        <div class="cw-skip-wrap">
          <span>10</span>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M13 6v12l8-6-8-6ZM4 6v12l8-6-8-6Z"/></svg>
        </div>
      </button>
    </div>

    <!-- Left Unlock Button -->
    <button class="cw-unlock" id="cwUnlock" title="Mở khóa điều khiển">
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none"><rect x="5" y="10" width="14" height="10" rx="2" stroke="currentColor" stroke-width="2"/><path d="M8 10V7a4 4 0 0 1 7.5-2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
    </button>

    <!-- Bottom Controls -->
    <div class="cw-bottom">
      <div class="cw-timeline-row">
        <div class="cw-time" id="cwCurTime">00:00</div>
        <div class="cw-track" id="cwTrack">
          <div class="cw-track-bg">
            <div class="cw-track-buf" id="cwTrackBuf"></div>
            <div class="cw-track-fill" id="cwTrackFill"></div>
          </div>
          <div class="cw-thumb" id="cwThumb"></div>
          <div class="cw-time-hover" id="cwTimeHover">00:00</div>
        </div>
        <div class="cw-time" id="cwTotalTime">00:00</div>
        <div style="display:flex;align-items:center;gap:4px">
          <button class="cw-btn-icon" id="cwPip" title="Thu nhỏ (Picture-in-Picture)">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="16" rx="2.5" stroke="currentColor" stroke-width="1.8"/><rect x="11" y="11" width="8" height="6" rx="1.5" fill="currentColor"/></svg>
          </button>
          <button class="cw-btn-icon" id="cwFull" title="Toàn màn hình">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M8 3H4a1 1 0 0 0-1 1v4M16 3h4a1 1 0 0 1 1 1v4M8 21H4a1 1 0 0 1-1-1v-4M16 21h4a1 1 0 0 0 1-1v-4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
          </button>
        </div>
      </div>

      <!-- Action 6-Button Panel -->
      <div class="cw-action-panel">
        <button class="cw-action-btn" id="cwActLock" title="Khóa màn hình">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="5" y="10" width="14" height="10" rx="2" stroke="currentColor" stroke-width="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
          <span>Khóa</span>
        </button>
        <button class="cw-action-btn" id="cwActSpeed" title="Tốc độ">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M4 16a8 8 0 1 1 16 0" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M12 12l4-4M7 15h.01M17 15h.01M12 6h.01" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>
          <span id="cwSpeedLabel">Tốc độ</span>
        </button>
        <button class="cw-action-btn" id="cwActRepeat" title="Lặp lại">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M17 2l3 3-3 3M20 5H8a4 4 0 0 0-4 4v1M7 22l-3-3 3-3M4 19h12a4 4 0 0 0 4-4v-1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
          <span id="cwRepeatLabel">Lặp lại</span>
        </button>
        <button class="cw-action-btn" id="cwActPlaylist" title="Danh sách">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M9 6h11M9 12h11M9 18h11M4 6h.01M4 12h.01M4 18h.01" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>
          <span>Danh sách</span>
        </button>
        <button class="cw-action-btn" id="cwActRotate" title="Tỉ lệ">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="7.2" y="4.2" width="9.6" height="15.6" rx="2.2" stroke="currentColor" stroke-width="1.9"/><path d="M4.5 9.2A8 8 0 0 1 7.8 4.8" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/><path d="M4.2 5.8l.3 3.4 3.3-.4" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/><path d="M19.5 14.8a8 8 0 0 1-3.3 4.4" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/><path d="M19.8 18.2l-.3-3.4-3.3.4" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>
          <span id="cwFitActionLabel">Tỉ lệ</span>
        </button>
        <button class="cw-action-btn" id="cwActSettings" title="Cài đặt">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z" stroke="currentColor" stroke-width="2"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.1V21h-4v-.09A1.7 1.7 0 0 0 8.6 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.1-.4H3v-4h.09A1.7 1.7 0 0 0 4.6 8.6a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-.6 1.7 1.7 0 0 0 .4-1.1V3h4v.09A1.7 1.7 0 0 0 15.4 4.6a1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 19.4 9c.19.36.5.67.86.86.34.18.73.28 1.14.28h.1v4h-.09c-.83 0-1.59.45-2.01 1.18Z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>
          <span>Cài đặt</span>
        </button>
      </div>
    </div>

    <div class="cw-toast" id="cwPlayerToast"></div>

    <!-- Sheet 1: Playlist Sheet -->
    <div class="cw-sheet" id="cwPlaylistSheet">
      <h3>
        <span>Danh sách phát (${vidSiblings.length})</span>
        <button class="modal-close" style="color:#fff;background:none;border:none;cursor:pointer;font-size:18px" onclick="this.closest('.cw-sheet').classList.remove('show')">✕</button>
      </h3>
      <div id="cwPlaylistItems" style="max-height:240px;overflow-y:auto;display:flex;flex-direction:column;gap:4px"></div>
    </div>

    <!-- Sheet 2: Settings Sheet -->
    <div class="cw-sheet" id="cwSettingsSheet">
      <h3>
        <span>Cài đặt trình phát</span>
        <button class="modal-close" style="color:#fff;background:none;border:none;cursor:pointer;font-size:18px" onclick="this.closest('.cw-sheet').classList.remove('show')">✕</button>
      </h3>
      <div class="cw-sheet-row" id="cwOptFit"><span>Tỉ lệ khung hình</span><span class="cw-sheet-sub" id="cwFitLabel">Vừa khung (Contain)</span></div>
      <div class="cw-sheet-row" id="cwOptSpeed"><span>Tốc độ phát</span><span class="cw-sheet-sub" id="cwSpeedSub">1.0×</span></div>
      <div class="cw-sheet-row" id="cwOptRepeat"><span>Lặp lại video</span><span class="cw-sheet-sub" id="cwRepeatSub">Tắt</span></div>
      <div class="cw-sheet-row" id="cwOptAutoplay"><span>Tự động phát tiếp</span><span class="cw-sheet-sub" id="cwAutoplaySub">Bật</span></div>
      <div class="cw-sheet-row" id="cwOptResume"><span>Nhớ vị trí phát</span><span class="cw-sheet-sub" id="cwResumeSub">Bật</span></div>
    </div>

    <!-- Sheet 3: Subtitles Sheet -->
    <div class="cw-sheet" id="cwSubSheet">
      <h3>
        <span>Phụ đề</span>
        <button class="modal-close" style="color:#fff;background:none;border:none;cursor:pointer;font-size:18px" onclick="this.closest('.cw-sheet').classList.remove('show')">✕</button>
      </h3>
      <div class="cw-sheet-row" id="cwSubToggle"><span>Trạng thái</span><span class="cw-sheet-sub" id="cwSubToggleSub">Tắt</span></div>
      <div class="cw-sheet-row" id="cwSubPick"><span>Tải tệp phụ đề (.srt, .vtt)</span><span class="cw-sheet-sub">Chọn</span></div>
      <input type="file" id="cwSubFileInput" accept=".srt,.vtt" hidden>
    </div>

    <!-- Sheet 4: Cast Sheet -->
    <div class="cw-sheet" id="cwCastSheet">
      <h3>
        <span>Truyền phát Smart TV (DLNA / Cast)</span>
        <button class="modal-close" style="color:#fff;background:none;border:none;cursor:pointer;font-size:18px" onclick="this.closest('.cw-sheet').classList.remove('show')">✕</button>
      </h3>
      <div style="font-size:12px;color:rgba(255,255,255,.7);margin-bottom:8px">Đang quét Smart TV trong mạng WiFi…</div>
      <div id="cwCastDeviceList" style="display:flex;flex-direction:column;gap:6px">
        <div class="cw-sheet-row" id="cwCastLocal"><span>Thiết bị này (Phát tại chỗ)</span><span class="cw-sheet-sub" style="color:#22c55e">Đang phát</span></div>
      </div>
    </div>

    <!-- Sheet 5: More Options Sheet -->
    <div class="cw-sheet" id="cwMoreSheet">
      <h3>
        <span>Tùy chọn khác</span>
        <button class="modal-close" style="color:#fff;background:none;border:none;cursor:pointer;font-size:18px" onclick="this.closest('.cw-sheet').classList.remove('show')">✕</button>
      </h3>
      <div class="cw-sheet-row" id="cwMoreDl"><span>Tải về video này</span><span class="cw-sheet-sub">Lưu máy</span></div>
      <div class="cw-sheet-row" id="cwMoreSnap"><span>Chụp ảnh màn hình</span><span class="cw-sheet-sub">Ảnh</span></div>
      <div class="cw-sheet-row" id="cwMoreInfo"><span>Thông tin chi tiết</span><span class="cw-sheet-sub" id="cwInfoSub">Xem</span></div>
    </div>
  `;
  document.body.appendChild(container);

  const video = container.querySelector('#cwVideo');
  const titleEl = container.querySelector('#cwTitle');
  const curTimeEl = container.querySelector('#cwCurTime');
  const totalTimeEl = container.querySelector('#cwTotalTime');
  const trackEl = container.querySelector('#cwTrack');
  const trackBufEl = container.querySelector('#cwTrackBuf');
  const trackFillEl = container.querySelector('#cwTrackFill');
  const thumbEl = container.querySelector('#cwThumb');
  const playBtn = container.querySelector('#cwPlay');
  const pauseIcon = container.querySelector('#cwPauseIcon');
  const playIcon = container.querySelector('#cwPlayIcon');
  const toastEl = container.querySelector('#cwPlayerToast');
  const speedLabel = container.querySelector('#cwSpeedLabel');
  const repeatBtn = container.querySelector('#cwActRepeat');
  const repeatLabel = container.querySelector('#cwRepeatLabel');
  const favBtn = container.querySelector('#cwFav');
  const rippleLeft = container.querySelector('#cwRippleLeft');
  const rippleRight = container.querySelector('#cwRippleRight');

  const speeds = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];
  let speedIdx = 2; // 1.0x
  const fitModes = ['fit-contain', 'fit-cover', 'fit-fill', 'fit-16-9', 'fit-4-3'];
  const fitLabels = ['Vừa khung (Contain)', 'Lấp đầy (Cover)', 'Kéo giãn (Fill)', '16:9', '4:3'];
  let fitIdx = 0;
  let isLocked = false;
  let hideTimer = null;
  let toastTimer = null;
  let repeatMode = 0;
  let autoplayNext = true;
  let resumePlayback = true;

  function showToast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2200);
  }

  function triggerRipple(isLeft) {
    const el = isLeft ? rippleLeft : rippleRight;
    if (!el) return;
    el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), 400);
  }

  function fmtTime(sec) {
    if (!sec || isNaN(sec) || !isFinite(sec)) return '00:00';
    sec = Math.round(sec);
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    if (h > 0) return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  function updateTimeline() {
    if (!video.duration) return;
    const pct = Math.max(0, Math.min(100, (video.currentTime / video.duration) * 100));
    trackFillEl.style.width = pct + '%';
    thumbEl.style.left = pct + '%';
    curTimeEl.textContent = fmtTime(video.currentTime);

    if (video.buffered && video.buffered.length) {
      try {
        const bufEnd = video.buffered.end(video.buffered.length - 1);
        const bufPct = Math.max(0, Math.min(100, (bufEnd / video.duration) * 100));
        trackBufEl.style.width = bufPct + '%';
      } catch {}
    }

    if (resumePlayback && video.currentTime > 5 && (video.duration - video.currentTime > 10)) {
      try {
        localStorage.setItem('cw_resume_' + curFile.name, String(Math.round(video.currentTime)));
      } catch {}
    }
  }

  function showControls() {
    container.classList.remove('controls-hidden');
    clearTimeout(hideTimer);
    if (!video.paused && !isLocked) {
      hideTimer = setTimeout(() => {
        if (!video.paused && !isLocked) {
          closeAllSheets();
          container.classList.add('controls-hidden');
        }
      }, 2600);
    }
  }

  function closeAllSheets() {
    container.querySelectorAll('.cw-sheet').forEach((s) => s.classList.remove('show'));
  }

  function toggleSheet(id) {
    const s = container.querySelector('#' + id);
    if (!s) return;
    const isShowing = s.classList.contains('show');
    closeAllSheets();
    if (!isShowing) s.classList.add('show');
    showControls();
  }

  function updateFavUI() {
    try {
      const favs = JSON.parse(localStorage.getItem('cw_fav_videos') || '[]');
      const isFav = favs.includes(curFile.name);
      if (favBtn) {
        favBtn.classList.toggle('is-fav', isFav);
        favBtn.title = isFav ? 'Đã yêu thích' : 'Thêm vào yêu thích';
      }
    } catch {}
  }

  function setVideoSource(f, startFrom) {
    curFile = f;
    curPool = ePool(f);
    const rel = relOf(f);
    titleEl.textContent = f.name;
    titleEl.title = f.name;
    updateFavUI();

    if (startFrom != null && startFrom > 0) {
      pendingStartPos = startFrom > 5000 ? startFrom / 1000 : startFrom;
    } else if (resumePlayback) {
      try {
        const savedSec = Number(localStorage.getItem('cw_resume_' + f.name) || 0);
        if (savedSec > 10) pendingStartPos = savedSec;
      } catch {}
    }

    if (f._local) {
      video.src = localDocUrl(f) || '';
    } else {
      const qs = (curPool && curPool !== LOCAL_POOL ? '&pool=' + enc(curPool) : '') + (token ? '&token=' + enc(token) : '') + '&ios=1';
      video.src = server ? `${server.baseUrl}/api/video?path=${enc(rel)}${qs}` : '';
      video.onerror = () => {
        console.error('Video error on /api/video, trying direct /api/file fallback');
        video.src = server ? `${server.baseUrl}/api/file?path=${enc(rel)}&preview=1${qs}` : '';
        video.load();
        video.play().catch(() => {});
      };
    }
    video.load();
    video.play().catch((err) => {
      console.log('Video play promise caught:', err);
    });
    renderPlaylistItems();
  }

  function renderPlaylistItems() {
    const box = container.querySelector('#cwPlaylistItems');
    if (!box) return;
    box.innerHTML = vidSiblings.map((v, i) => {
      const isCur = v.name === curFile.name;
      return `<div class="cw-sheet-row${isCur ? ' active' : ''}" data-idx="${i}">
        <span style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:260px">${v.name}</span>
        <span class="cw-sheet-sub">${v.size ? fmtBytes(v.size) : ''}</span>
      </div>`;
    }).join('');

    box.querySelectorAll('.cw-sheet-row').forEach((r) => {
      r.onclick = () => {
        const idx = Number(r.dataset.idx);
        if (vidSiblings[idx]) {
          setVideoSource(vidSiblings[idx]);
          closeAllSheets();
        }
      };
    });
  }

  function togglePlay() {
    if (video.paused) {
      video.play();
      showToast('Đang phát');
    } else {
      video.pause();
      showToast('Đã tạm dừng');
    }
  }

  function skip(delta) {
    video.currentTime = Math.max(0, Math.min(video.duration || 0, video.currentTime + delta));
    updateTimeline();
    triggerRipple(delta < 0);
    showToast(delta > 0 ? 'Tiến 10 giây' : 'Lùi 10 giây');
  }

  video.addEventListener('timeupdate', updateTimeline);
  video.addEventListener('progress', updateTimeline);
  video.addEventListener('loadedmetadata', () => {
    totalTimeEl.textContent = fmtTime(video.duration);
    updateTimeline();
    const infoSub = container.querySelector('#cwInfoSub');
    if (infoSub && video.videoWidth) {
      infoSub.textContent = `${video.videoWidth}×${video.videoHeight} · ${fmtTime(video.duration)}`;
    }
    if (pendingStartPos > 5 && pendingStartPos < (video.duration || 999999) - 5) {
      try {
        video.currentTime = pendingStartPos;
        showToast(`Tiếp tục phát từ ${fmtTime(pendingStartPos)}`);
      } catch {}
      pendingStartPos = 0;
    }
  });
  video.addEventListener('play', () => {
    pauseIcon.classList.remove('hidden');
    playIcon.classList.add('hidden');
    showControls();
  });
  video.addEventListener('pause', () => {
    pauseIcon.classList.add('hidden');
    playIcon.classList.remove('hidden');
    container.classList.remove('controls-hidden');
    clearTimeout(hideTimer);
  });
  video.addEventListener('ended', () => {
    if (repeatMode === 1) {
      video.currentTime = 0;
      video.play().catch(() => {});
    } else if (autoplayNext || repeatMode === 2) {
      curIndex = (curIndex + 1) % vidSiblings.length;
      setVideoSource(vidSiblings[curIndex]);
    }
  });

  playBtn.onclick = togglePlay;
  container.querySelector('#cwRew10').onclick = () => skip(-10);
  container.querySelector('#cwFwd10').onclick = () => skip(10);

  favBtn.onclick = () => {
    try {
      let favs = JSON.parse(localStorage.getItem('cw_fav_videos') || '[]');
      const isFav = favs.includes(curFile.name);
      if (isFav) {
        favs = favs.filter((x) => x !== curFile.name);
        showToast('Đã xóa khỏi yêu thích');
      } else {
        favs.push(curFile.name);
        showToast('Đã thêm vào yêu thích');
      }
      localStorage.setItem('cw_fav_videos', JSON.stringify(favs));
      updateFavUI();
    } catch {}
  };

  let dragging = false;
  function seekToEvent(e) {
    const rect = trackEl.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const pos = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    if (video.duration) video.currentTime = pos * video.duration;
    updateTimeline();
  }
  trackEl.addEventListener('touchstart', (e) => { dragging = true; seekToEvent(e); }, { passive: true });
  trackEl.addEventListener('touchmove', (e) => { if (dragging) seekToEvent(e); }, { passive: true });
  trackEl.addEventListener('touchend', () => { dragging = false; });
  trackEl.addEventListener('mousedown', (e) => { dragging = true; seekToEvent(e); });
  window.addEventListener('mousemove', (e) => { if (dragging) seekToEvent(e); });
  window.addEventListener('mouseup', () => { dragging = false; });

  container.querySelector('#cwBack').onclick = () => closePlayer();
  container.querySelector('#cwCast').onclick = () => toggleSheet('cwCastSheet');
  container.querySelector('#cwSub').onclick = () => toggleSheet('cwSubSheet');
  container.querySelector('#cwMore').onclick = () => toggleSheet('cwMoreSheet');

  const pipBtn = container.querySelector('#cwPip');
  if (pipBtn) {
    pipBtn.onclick = async () => {
      try {
        if (video.webkitSetPresentationMode) {
          video.webkitSetPresentationMode(video.webkitPresentationMode === 'picture-in-picture' ? 'inline' : 'picture-in-picture');
        } else if (document.pictureInPictureElement) {
          await document.exitPictureInPicture();
        } else if (document.pictureInPictureEnabled) {
          await video.requestPictureInPicture();
        }
      } catch (e) { showToast('Không hỗ trợ PiP'); }
    };
  }

  const fullBtn = container.querySelector('#cwFull');
  fullBtn.onclick = () => {
    if (video.webkitEnterFullscreen) {
      video.webkitEnterFullscreen();
    } else if (!document.fullscreenElement) {
      container.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  container.querySelector('#cwActLock').onclick = () => {
    isLocked = true;
    container.classList.add('locked');
    closeAllSheets();
    showToast('Đã khóa màn hình (Chạm ổ khóa bên trái để mở)');
  };
  container.querySelector('#cwUnlock').onclick = () => {
    isLocked = false;
    container.classList.remove('locked');
    showControls();
    showToast('Đã mở khóa');
  };

  const speedBtn = container.querySelector('#cwActSpeed');
  speedBtn.onclick = () => {
    speedIdx = (speedIdx + 1) % speeds.length;
    const v = speeds[speedIdx];
    video.playbackRate = v;
    speedLabel.textContent = v === 1 ? 'Tốc độ' : `${v}×`;
    container.querySelector('#cwSpeedSub').textContent = `${v}×`;
    showToast(`Tốc độ: ${v}×`);
  };

  repeatBtn.onclick = () => {
    repeatMode = (repeatMode + 1) % 3;
    const labels = ['Tắt', 'Lặp 1 video', 'Lặp toàn bộ'];
    repeatLabel.textContent = repeatMode === 0 ? 'Lặp lại' : repeatMode === 1 ? 'Lặp 1' : 'Lặp tất cả';
    repeatBtn.classList.toggle('active', repeatMode !== 0);
    container.querySelector('#cwRepeatSub').textContent = labels[repeatMode];
    showToast(`Lặp lại: ${labels[repeatMode]}`);
  };

  container.querySelector('#cwActPlaylist').onclick = () => toggleSheet('cwPlaylistSheet');
  container.querySelector('#cwActSettings').onclick = () => toggleSheet('cwSettingsSheet');

  const fitBtn = container.querySelector('#cwActRotate');
  fitBtn.onclick = () => {
    fitIdx = (fitIdx + 1) % fitModes.length;
    video.className = fitModes[fitIdx];
    container.querySelector('#cwFitLabel').textContent = fitLabels[fitIdx];
    container.querySelector('#cwFitActionLabel').textContent = fitIdx === 0 ? 'Tỉ lệ' : fitLabels[fitIdx].split(' ')[0];
    showToast(`Tỉ lệ: ${fitLabels[fitIdx]}`);
  };

  container.querySelector('#cwOptFit').onclick = () => fitBtn.click();
  container.querySelector('#cwOptSpeed').onclick = () => speedBtn.click();
  container.querySelector('#cwOptRepeat').onclick = () => repeatBtn.click();
  container.querySelector('#cwOptAutoplay').onclick = () => {
    autoplayNext = !autoplayNext;
    container.querySelector('#cwAutoplaySub').textContent = autoplayNext ? 'Bật' : 'Tắt';
    showToast(`Tự động phát tiếp: ${autoplayNext ? 'BẬT' : 'TẮT'}`);
  };
  container.querySelector('#cwOptResume').onclick = () => {
    resumePlayback = !resumePlayback;
    container.querySelector('#cwResumeSub').textContent = resumePlayback ? 'Bật' : 'Tắt';
    showToast(`Nhớ vị trí phát: ${resumePlayback ? 'BẬT' : 'TẮT'}`);
  };

  const subToggleRow = container.querySelector('#cwSubToggle');
  const subToggleSub = container.querySelector('#cwSubToggleSub');
  const subFileInput = container.querySelector('#cwSubFileInput');
  let subsActive = false;

  subToggleRow.onclick = () => {
    subsActive = !subsActive;
    subToggleSub.textContent = subsActive ? 'Bật' : 'Tắt';
    for (let i = 0; i < video.textTracks.length; i++) {
      video.textTracks[i].mode = subsActive ? 'showing' : 'hidden';
    }
    showToast(`Phụ đề: ${subsActive ? 'BẬT' : 'TẮT'}`);
  };

  container.querySelector('#cwSubPick').onclick = () => subFileInput.click();
  subFileInput.onchange = (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    const track = document.createElement('track');
    track.kind = 'subtitles';
    track.label = file.name;
    track.srclang = 'vi';
    track.src = url;
    track.default = true;
    video.appendChild(track);
    subsActive = true;
    subToggleSub.textContent = file.name;
    showToast('Đã nạp phụ đề: ' + file.name);
    closeAllSheets();
  };

  container.querySelector('#cwMoreDl').onclick = () => {
    downloadFile(curFile);
    closeAllSheets();
  };
  container.querySelector('#cwMoreSnap').onclick = () => {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 1280;
      canvas.height = video.videoHeight || 720;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const a = document.createElement('a');
      a.download = `snapshot_${curFile.name}_${Math.round(video.currentTime)}s.jpg`;
      a.href = canvas.toDataURL('image/jpeg', 0.92);
      a.click();
      showToast('Đã lưu ảnh chụp');
    } catch { showToast('Không thể chụp ảnh'); }
    closeAllSheets();
  };
  container.querySelector('#cwMoreInfo').onclick = () => {
    showToast(`${curFile.name} (${video.videoWidth || 0}×${video.videoHeight || 0}, ${fmtTime(video.duration)})`);
  };

  container.addEventListener('mousemove', showControls);
  let lastTouchTime = 0;
  container.addEventListener('click', (e) => {
    if (e.target === container || e.target.closest('.cw-surface')) {
      const now = Date.now();
      const rect = container.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const pctX = clickX / rect.width;

      if (now - lastTouchTime < 300) {
        if (pctX < 0.35) skip(-10);
        else if (pctX > 0.65) skip(10);
        else fullBtn.click();
      } else {
        if (container.classList.contains('controls-hidden')) showControls();
        else togglePlay();
      }
      lastTouchTime = now;
    }
  });

  function closePlayer() {
    clearTimeout(hideTimer);
    clearTimeout(toastTimer);
    video.pause();
    container.remove();
  }

  setVideoSource(initialFile, startPosSec);
  showControls();
}

function launchMobileVideo(e, rel, p, plIdx, playlist, startPos) {
  openVideoPlayer(e, displayEntries().filter((x) => STREAM_VIDEO.test(x.name)), startPos);
}

function openPreview(e) {
  if (e && e._local) { openLocalPreview(e); return; }
  const rel = relOf(e);
  const name = e.name;
  const p = ePool(e);
  previewEntry = e;
  previewList = previewMediaList();
  previewIdx = previewList.findIndex((x) => x.name === e.name);
  if (previewIdx < 0) { previewList = [e]; previewIdx = 0; }
  if (STREAM_VIDEO.test(name)) {
    const savedSec = Number(localStorage.getItem('cw_resume_' + e.name) || 0);
    if (savedSec > 10) {
      showVideoResumePrompt(e, rel, p, 0, null, savedSec * 1000);
    } else {
      launchMobileVideo(e, rel, p, 0, null, -1);
    }
    return;
  }
  if (STREAM_PDF.test(name)) { openNativePdf(e, rel, p); return; }
  if (STREAM_IMG.test(name)) {
    const imageList = displayEntries().filter((x) => x.type === 'file' && STREAM_IMG.test(x.name));
    let rawIdx = imageList.findIndex((x) => x.name === e.name);
    if (rawIdx < 0) rawIdx = 0;
    const windowSize = 80;
    const startIdx = Math.max(0, rawIdx - 40);
    const endIdx = Math.min(imageList.length, startIdx + windowSize);
    const slice = imageList.slice(startIdx, endIdx);
    const adjustedIdx = rawIdx - startIdx;
    const playlist = slice.map((x) => {
      const xp = ePool(x);
      const xRel = relOf(x);
      const directUrl = server ? (server.baseUrl + '/api/file?path=' + enc(xRel) + '&pool=' + enc(xp) + '&preview=1') : '';
      const thumbUrl = server ? (server.baseUrl + '/api/thumb?path=' + enc(xRel) + '&pool=' + enc(xp)) : '';
      return {
        name: x.name,
        url: directUrl,
        thumbUrl: thumbUrl,
        size: x.size || 0,
        rel: xRel,
        pool: xp,
        mtime: x.mtime || ''
      };
    });
    const directUrl = server ? (server.baseUrl + '/api/file?path=' + enc(rel) + '&pool=' + enc(p) + '&preview=1') : '';
    const thumbUrl = server ? (server.baseUrl + '/api/thumb?path=' + enc(rel) + '&pool=' + enc(p)) : '';
    callNative('openPhoto', JSON.stringify({
      url: directUrl,
      thumbUrl,
      name,
      token,
      playlist,
      initialIndex: adjustedIdx,
      baseUrl: server ? server.baseUrl : '',
      pool: p
    })).catch((er) => DC.toast(errText(er)));
    return;
  }
  const modal = $('#pvModal');
  const stage = $('#pvStage');
  $('#pvTitle').textContent = name + (e.size ? ' · ' + fmtBytes(e.size) : '');
  stage.innerHTML = '<div class="pv-loading">Đang tải…</div>';
  modal.classList.add('show');
  updatePvNav();
  if (STREAM_AUDIO.test(name)) {
    const a = document.createElement('audio');
    a.controls = true; a.autoplay = true;
    let aTried = 0;
    a.onerror = () => {
      aTried++;
      if (aTried === 1 && a.src.indexOf('http://127.0.0.1') === 0) { a.src = fileApiUrl(rel, '&preview=1', p); a.load(); a.play().catch(() => {}); }
      else { stage.innerHTML = '<div class="pv-err">Không phát được tệp âm thanh.</div>'; }
    };
    a.src = mediaProxyUrl(rel, false, p);
    stage.innerHTML = ''; stage.appendChild(a);
    return;
  }
  if (STREAM_PDF.test(name)) { localOpenWith(e); return; }
  if (STREAM_TEXT.test(name)) { renderText(stage, rel, p); return; }
  stage.innerHTML = '<div class="pv-err">Loại tệp này chưa hỗ trợ xem trực tiếp.</div>';
}

function openLocalPreview(e) {
  const name = e.name;
  previewEntry = e;
  previewList = [e]; previewIdx = 0;
  if (STREAM_VIDEO.test(name)) {
    openVideoPlayer(e, displayEntries().filter((x) => STREAM_VIDEO.test(x.name)), -1);
    return;
  }
  if (STREAM_PDF.test(name)) { openNativePdfLocal(e); return; }
  if (STREAM_IMG.test(name)) {
    const imageList = displayEntries().filter((x) => x.type === 'file' && STREAM_IMG.test(x.name));
    let rawIdx = imageList.findIndex((x) => x.name === e.name);
    if (rawIdx < 0) rawIdx = 0;
    const windowSize = 80;
    const startIdx = Math.max(0, rawIdx - 40);
    const endIdx = Math.min(imageList.length, startIdx + windowSize);
    const slice = imageList.slice(startIdx, endIdx);
    const adjustedIdx = rawIdx - startIdx;
    const playlist = slice.map((x) => ({
      name: x.name,
      localPath: x._p || '',
      url: localDocUrl(x) || '',
      size: x.size || 0,
      local: true
    }));
    callNative('openPhoto', JSON.stringify({
      localPath: e._p || '',
      url: localDocUrl(e) || '',
      name,
      playlist,
      initialIndex: adjustedIdx,
      baseUrl: server ? server.baseUrl : ''
    })).catch((er) => DC.toast(errText(er)));
    return;
  }
  const modal = $('#pvModal');
  const stage = $('#pvStage');
  $('#pvTitle').textContent = name + (e.size ? ' · ' + fmtBytes(e.size) : '');
  stage.innerHTML = '<div class="pv-loading">Đang tải…</div>';
  modal.classList.add('show');
  updatePvNav();
  const url = localDocUrl(e);
  if (!url) { stage.innerHTML = '<div class="pv-err">Không mở được tệp này.</div>'; return; }
  if (STREAM_AUDIO.test(name)) {
    const a = document.createElement('audio');
    a.controls = true; a.autoplay = true;
    a.onerror = () => { stage.innerHTML = '<div class="pv-err">Không phát được tệp âm thanh.</div>'; };
    a.src = url;
    stage.innerHTML = ''; stage.appendChild(a);
    return;
  }
  if (STREAM_PDF.test(name)) { localOpenWith(e); return; }
  if (STREAM_TEXT.test(name)) { renderLocalText(stage, url); return; }
  stage.innerHTML = '<div class="pv-err">Loại tệp này chưa hỗ trợ xem trực tiếp.</div>';
}

/* Mở PDF bằng trình đọc AndroidPdfViewer trong app (không tải về máy).
 * - PDF trên server: đọc qua proxy cục bộ (url) — PdfViewerActivity tự tải vào cache 1 lần.
 * - PDF trên bộ nhớ máy ("Thiết bị này"): mở thẳng bằng đường dẫn/uri. */
function openNativePdf(e, rel, poolId) {
  const p = poolId != null ? poolId : ePool(e);
  const spec = { rel, pool: p && p !== LOCAL_POOL ? p : '', name: e.name, size: e.size || 0 };
  callNative('openPdf', JSON.stringify(spec)).catch((er) => {
    DC.toast('Không mở được PDF: ' + errText(er));
    openOrFetch(e);
  });
}
function openNativePdfLocal(e) {
  const spec = { name: e.name };
  if (e._p) spec.path = e._p;
  callNative('openPdf', JSON.stringify(spec)).catch((er) => {
    DC.toast('Không mở được PDF: ' + errText(er));
    localOpenWith(e);
  });
}

async function renderText(stage, rel, poolId) {
  const p = poolId != null ? poolId : pool;
  try {
    const r = await callNative('invoke', 'GET', fileApiUrl(rel, '&preview=1', p), JSON.stringify(token ? { Authorization: 'Bearer ' + token } : {}), '');
    if (!stage.isConnected || !$('#pvModal').classList.contains('show')) return;
    if (r.status >= 400) throw r;
    let text = r.text || '';
    if (text.length > 512 * 1024) text = text.slice(0, 512 * 1024) + '\n\n…(tệp lớn, đã cắt bớt)…';
    const pre = document.createElement('pre');
    pre.textContent = text || '(tệp trống)';
    stage.innerHTML = '';
    stage.appendChild(pre);
  } catch (e) {
    stage.innerHTML = '<div class="pv-err">Không đọc được tệp này.</div>';
  }
}

async function renderLocalText(stage, url) {
  try {
    const resp = await fetch(url);
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    let text = await resp.text();
    if (text.length > 512 * 1024) text = text.slice(0, 512 * 1024) + '\n\n…(tệp lớn, đã cắt bớt)…';
    const pre = document.createElement('pre');
    pre.textContent = text || '(tệp trống)';
    stage.innerHTML = '';
    stage.appendChild(pre);
  } catch (e) {
    stage.innerHTML = '<div class="pv-err">Không đọc được tệp này.</div>';
  }
}

function pvNav(delta) {
  if (!isMediaEntry(previewEntry ? previewEntry.name : '')) return;
  const idx = previewIdx + delta;
  if (idx < 0 || idx >= previewList.length) return;
  openPreview(previewList[idx]);
}

function pvSetupSwipe() {
  const stage = $('#pvStage');
  let sx = 0, sy = 0, st = 0, swiping = false;
  stage.addEventListener('touchstart', (ev) => {
    if ((ev.touches && ev.touches.length !== 1)) return;
    const t = (ev.touches && ev.touches[0]) || ev;
    sx = t.clientX; sy = t.clientY; st = Date.now(); swiping = true;
  }, { passive: true });
  stage.addEventListener('touchend', (ev) => {
    if (!swiping) return;
    swiping = false;
    const t = (ev.changedTouches && ev.changedTouches[0]) || ev;
    const dx = t.clientX - sx, dy = t.clientY - sy, dt = Date.now() - st;
    if (Math.abs(dx) > 48 && Math.abs(dy) < Math.abs(dx) * 0.8 && dt < 700) {
      if (dx < 0) pvNav(1); else pvNav(-1);
    }
  }, { passive: true });
  $('#pvPrev').addEventListener('click', () => pvNav(-1));
  $('#pvNext').addEventListener('click', () => pvNav(1));
}
pvSetupSwipe();

function closePreview() {
  const stage = $('#pvStage');
  if (stage) {
    stage.querySelectorAll('video, audio').forEach((m) => { try { m.pause(); } catch (e) {} m.removeAttribute('src'); try { m.load(); } catch (e) {} });
    stage.innerHTML = '';
  }
  previewEntry = null;
  previewList = []; previewIdx = -1;
  updatePvNav();
  $('#pvModal').classList.remove('show');
}
$('#pvMore').addEventListener('click', () => {
  const e = previewEntry;
  if (!e) return;
  openFileSheet(e);
});
$('#pvDl').addEventListener('click', () => {
  const e = previewEntry;
  closePreview();
  if (e) {
    if (e._local) { localDownloadEntry(e); }
    else startDownloadFor(e);
  }
});
const pvCloseBtn = $('#pvClose');
if (pvCloseBtn) {
  pvCloseBtn.addEventListener('click', () => closePreview());
}

/* ---------- API ---------- */
async function api(path, method, body) {
  const headers = token ? { Authorization: 'Bearer ' + token } : {};
  const r = await callNative('invoke', method || 'GET', server.baseUrl + path, JSON.stringify(headers), body ? JSON.stringify(body) : '');
  let data;
  try { data = r.text ? JSON.parse(r.text) : {}; } catch (e) { data = { error: 'Phản hồi không hợp lệ (HTTP ' + r.status + ')' }; }
  if (r.status === 401 && token) { onSessionLost(); throw data; }
  if (r.status >= 400) throw data;
  return data;
}

async function tryApi(baseUrl, path, method, body, tk) {
  const headers = tk ? { Authorization: 'Bearer ' + tk } : {};
  const r = await callNative('invoke', method || 'GET', baseUrl + path, JSON.stringify(headers), body ? JSON.stringify(body) : '');
  let data;
  try { data = r.text ? JSON.parse(r.text) : {}; } catch (e) { data = {}; }
  if (r.status >= 400) throw data;
  return data;
}

/* ---------- Views ---------- */
const views = $$('.view');
const bottomNav = $('#bottomNav');
function go(id) {
  currentView = id;
  views.forEach((v) => v.classList.toggle('active', v.id === id));
  const main = ['files', 'transfers', 'favorites', 'sync', 'trash'].includes(id);
  bottomNav.style.display = main ? 'grid' : 'none';
  DC.setCanGoBack(id !== 'discover');
  if (id !== 'files') exitSelMode();
  if (typeof updatePasteFab === 'function') updatePasteFab();
}

$$('.nav-btn').forEach((btn) => btn.addEventListener('click', () => {
  $$('.nav-btn').forEach((b) => b.classList.toggle('active', b === btn));
  go(btn.dataset.target);
  if (btn.dataset.target === 'files') loadFiles(currentPath);
  if (btn.dataset.target === 'transfers') renderTransfers();
  if (btn.dataset.target === 'favorites') renderFavorites();
  if (btn.dataset.target === 'sync') renderSync();
  if (btn.dataset.target === 'trash') loadTrash();
}));

function handleBack() {
  if (sheetModal.classList.contains('show')) { closeSheet(); return; }
  if (selMode) { exitSelMode(); return; }
  if ($('#pvModal').classList.contains('show')) { closePreview(); return; }
  if (currentView === 'signin') { go('discover'); return; }
  if (currentView === 'trust') { go('signin'); return; }
  if (currentView !== 'files' && ['transfers', 'favorites', 'sync', 'trash'].includes(currentView)) {
    $$('.nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.target === 'files'));
    go('files');
    return;
  }
  if (currentView === 'files' && isLocalMode()) {
    if (goLocalBack()) return;
    DC.setCanGoBack(false); DC.toast('Nhấn Back lần nữa để thoát');
    return;
  }
  if (currentView === 'files' && currentPath) { goDir(parentPath || ''); return; }
  if (currentView === 'files') { DC.setCanGoBack(false); DC.toast('Nhấn Back lần nữa để thoát'); }
}

/* ---------- Bottom sheet ---------- */
const sheetModal = document.createElement('div');
sheetModal.className = 'modal';
sheetModal.innerHTML = '<div class="sheet"><div class="handle"></div><h3 id="asTitle"></h3><div id="asBody"></div></div>';
document.querySelector('.app-shell').appendChild(sheetModal);
const style = document.createElement('style');
style.textContent = '.as-item{padding:14px 4px;border-bottom:1px solid var(--line-soft);font-size:14.5px;color:#1f2937;cursor:pointer;display:flex;align-items:center;gap:10px}'
  + '.as-item:last-child{border-bottom:0}.as-item.danger{color:var(--red)}'
  + '.dot.offline{background:#f97316!important}'
  + '.empty{padding:26px 12px;text-align:center;color:#98a2b3;font-size:13px;line-height:1.6}'
  + '.pill.gray{background:#f5f7fa;color:#667085}.pill.yellow{background:#fff8e6;color:#b45309}'
  + '.conn-info{color:#98a2b3;font-size:11px;margin-left:auto}';
document.head.appendChild(style);

function openSheet(title, build) {
  $('#asTitle').textContent = title || '';
  const body = $('#asBody');
  body.innerHTML = '';
  build(body);
  sheetModal.classList.add('show');
  if (typeof updateSelFab === 'function') updateSelFab();
  if (typeof updatePasteFab === 'function') updatePasteFab();
}
function closeSheet() { sheetModal.classList.remove('show'); if (typeof updateSelFab === 'function') updateSelFab(); if (typeof updatePasteFab === 'function') updatePasteFab(); }
sheetModal.addEventListener('click', (e) => { if (e.target === sheetModal) closeSheet(); });

/* Nút nổi "Đã chọn N mục": khi đang ở chế độ chọn nhiều mà bảng thao tác đã đóng,
 * bấm vào để mở lại bảng thay vì phải nhấn giữ lại từ đầu. */
const selChip = document.createElement('button');
selChip.className = 'sel-fab';
document.querySelector('.app-shell').appendChild(selChip);
selChip.addEventListener('click', () => { if (selMode && selectedSet.size) openSelSheet(); });
function updateSelFab() {
  const show = selMode && selectedSet.size > 0 && currentView === 'files' && !sheetModal.classList.contains('show');
  selChip.style.display = show ? 'flex' : 'none';
  if (show) {
    selChip.textContent = 'Đã chọn ' + selectedSet.size + ' mục';
    selChip.style.left = '';
    selChip.style.right = '';
    /* Nếu nút Paste đang hiện thì đẩy nút "Đã chọn N mục" lên trên cho khỏi chồng. */
    const pasteVisible = typeof clipboard !== 'undefined' && clipboard.items.length > 0;
    selChip.style.bottom = pasteVisible ? 'calc(144px + var(--sab,env(safe-area-inset-bottom,0px)))' : '';
  }
}

function sheetItem(parent, label, opts) {
  const d = document.createElement('div');
  d.className = 'as-item' + (opts && opts.danger ? ' danger' : '') + (opts && opts.active ? ' active' : '');
  let content = (opts && opts.icon ? iconSvg(opts.icon, 'svg-20') : '');
  content += '<div style="flex:1;min-width:0"><div style="font-weight:500;display:flex;align-items:center;justify-content:space-between">' + esc(label);
  if (opts && opts.badge) {
    content += '<span class="pill ' + (opts.badgeClass || 'blue') + '" style="font-size:11px;padding:3px 8px;margin-left:6px">' + esc(opts.badge) + '</span>';
  }
  content += '</div>';
  if (opts && opts.sub) {
    content += '<div style="font-size:11.5px;color:#667085;margin-top:2px">' + esc(opts.sub) + '</div>';
  }
  content += '</div>';
  if (opts && opts.active) {
    content += '<div style="color:var(--blue);font-weight:bold;font-size:15px;margin-left:8px">✓</div>';
  }
  d.innerHTML = content;
  d.addEventListener('click', () => { closeSheet(); opts && opts.onClick && opts.onClick(); });
  parent.appendChild(d);
  return d;
}

function sheetPrompt(title, placeholder, value, onOk) {
  openSheet(title, (body) => {
    const wrap = document.createElement('div');
    wrap.className = 'field';
    wrap.innerHTML = '<div class="input-wrap"><input placeholder="' + esc(placeholder) + '"></div>';
    body.appendChild(wrap);
    const input = wrap.querySelector('input');
    input.value = value || '';
    setTimeout(() => input.focus(), 60);
    const row = document.createElement('div');
    row.className = 'row-btn';
    row.innerHTML = '<button class="btn secondary">Hủy</button><button class="btn primary">OK</button>';
    row.children[0].addEventListener('click', closeSheet);
    row.children[1].addEventListener('click', () => {
      const v = input.value.trim();
      if (!v) { DC.toast('Vui lòng nhập giá trị'); return; }
      closeSheet();
      onOk(v);
    });
    body.appendChild(row);
  });
}

function sheetConfirm(title, message, okLabel, onOk) {
  openSheet(title, (body) => {
    const p = document.createElement('div');
    p.style.cssText = 'font-size:13.5px;color:#475467;line-height:1.6;margin-bottom:6px';
    p.textContent = message;
    body.appendChild(p);
    const row = document.createElement('div');
    row.className = 'row-btn';
    row.innerHTML = '<button class="btn secondary">Hủy</button><button class="btn primary">' + esc(okLabel) + '</button>';
    row.children[0].addEventListener('click', closeSheet);
    row.children[1].addEventListener('click', () => { closeSheet(); onOk(); });
    body.appendChild(row);
  });
}

/* ---------- DISCOVER ---------- */
let discoverRunning = false;
async function runDiscover() {
  if (discoverRunning) return;
  discoverRunning = true;
  const scanBtn = $('#scanBtn');
  const oldText = scanBtn.innerHTML;
  scanBtn.textContent = 'Đang quét mạng...';
  scanBtn.disabled = true;
  try {
    const r = await Promise.race([
      callNative('discover', JSON.stringify({ timeoutMs: 2600 })),
      new Promise((res) => setTimeout(() => res({ hosts: [] }), 8500)),
    ]);
    renderHosts((r && r.hosts) || []);
  } catch (e) {
    renderHosts([]);
  } finally {
    scanBtn.innerHTML = oldText;
    scanBtn.disabled = false;
    discoverRunning = false;
  }
}

function renderHosts(hosts) {
  const list = $('#discover .host-list');
  list.innerHTML = '';
  if (!hosts.length) {
    const d = document.createElement('div');
    d.className = 'empty';
    d.textContent = 'Không tìm thấy máy chủ CW Datacenter trên mạng.\nHãy chắc chắn Host đang chạy, rồi bấm Quét lại hoặc Kết nối thủ công.';
    d.style.whiteSpace = 'pre-line';
    list.appendChild(d);
    return;
  }
  hosts.forEach((h) => {
    const card = document.createElement('div');
    card.className = 'host-card';
    card.innerHTML =
      '<div class="host-icon">' + iconSvg('i-server', 'svg-26') + '</div>' +
      '<div><div class="host-name">' + esc(h.host || h.ip) + '</div>' +
      '<div class="host-meta">' + esc(h.ip) + (h.port && h.port !== 8080 ? ' :' + h.port : '') + '</div>' +
      '<div class="host-badges"><span class="badge online">● Trực tuyến</span><span class="badge lan">LAN · ' + esc(h.name || 'CW Datacenter') + '</span></div></div>' +
      '<div style="color:#98a2b3">' + iconSvg('i-chevron-right', 'svg-22') + '</div>';
    card.addEventListener('click', () => selectServer(h));
    list.appendChild(card);
  });
}

function selectServer(h) {
  const ip = h.ip;
  const port = h.port || 8080;
  server = {
    ip, port,
    baseUrl: 'http://' + ip + ':' + port,
    host: h.host || ip,
    name: h.host || ip,
    via: 'lan',
  };
  $('#signHost').textContent = server.name;
  $('#signIp').textContent = server.ip;
  const creds = kvGet(kCreds()) || {};
  $('#userInput').value = creds.u || '';
  $('#passInput').value = '';
  go('signin');
  probeSignin();
}

async function probeSignin() {
  try {
    const r = await tryApi(server.baseUrl, '/api/ping', 'GET');
    server.via = r.via || 'lan';
  } catch (e) {}
  const p = $('#signin .server-summary p');
  if (p) p.innerHTML = '<span id="signIp">' + esc(server.ip) + '</span> · ' + (server.via === 'tailscale' ? 'Tailscale' : 'LAN') + ' · <span style="color:var(--green)">● Trực tuyến</span>';
}

$('#scanBtn').addEventListener('click', runDiscover);
$('#manualBtn').addEventListener('click', () => $('#manualModal').classList.add('show'));
$('#closeManual').addEventListener('click', () => $('#manualModal').classList.remove('show'));
$('#manualModal').addEventListener('click', (e) => { if (e.target === $('#manualModal')) $('#manualModal').classList.remove('show'); });
$('#manualConnect').addEventListener('click', () => {
  const host = $('#manualHost').value.trim();
  if (!host) { DC.toast('Nhập địa chỉ máy chủ'); return; }
  const portInput = $$('#manualModal .input-wrap input')[1];
  const port = parseInt(portInput && portInput.value, 10) || 8080;
  $('#manualModal').classList.remove('show');
  selectServer({ ip: host, port, host: host, name: 'CW Datacenter' });
});

/* ---------- SIGN IN ---------- */
$('#eyeBtn').addEventListener('click', () => {
  const i = $('#passInput');
  i.type = i.type === 'password' ? 'text' : 'password';
});
$('#rememberBox').addEventListener('click', () => {
  rememberDevice = !rememberDevice;
  $('#rememberBox').classList.toggle('checked', rememberDevice);
  $('#rememberBox').textContent = rememberDevice ? '✓' : '';
});
$('#signin .text-btn').addEventListener('click', () => DC.toast('Liên hệ người quản trị máy chủ để đặt lại mật khẩu.'));

$('#signinBtn').addEventListener('click', async () => {
  const username = $('#userInput').value.trim();
  const password = $('#passInput').value;
  const btn = $('#signinBtn');
  const old = btn.textContent;
  btn.disabled = true; btn.textContent = 'Đang đăng nhập...';
  try {
    const data = await api('/api/login', 'POST', { username, password, device: HOST + ' (Android)' });
    token = data.token;
    me = { role: data.role || 'admin', user: data.user || username || 'admin' };
    kvSet(kToken(), token);
    DC.saveKV(kCreds(), JSON.stringify({ u: username }));
    fillTrust();
    rememberLast();
    if (DC.loadKV(kTrust()) === '1') { enterMain(); }
    else { go('trust'); }
  } catch (e) {
    DC.toast(errText(e));
  } finally {
    btn.disabled = false; btn.textContent = old;
  }
});

function fillTrust() {
  if (!server || !me) return;
  $('#trustHost').textContent = server.name;
  $('#trustHost2').textContent = server.name;
  $('#trustUser').textContent = me.user;
  const ipEl = $('#trustIp'); if (ipEl) ipEl.textContent = META.ip || '';
  const connEl = $('#trustConn'); if (connEl) connEl.textContent = server.via === 'tailscale' ? 'Tailscale' : 'LAN';
  const devEl = $('#trustDeviceInfo'); if (devEl) devEl.textContent = 'Android ' + (META.android || '') + ' · Ứng dụng CW';
}

/* ---------- TRUST ---------- */
$('#trustBtn').addEventListener('click', () => {
  DC.saveKV(kTrust(), '1');
  enterMain();
});
$('#trust .back').addEventListener('click', () => go('signin'));
$('#trust .row-btn .btn.secondary').addEventListener('click', () => go('signin'));
$('#signin .back').addEventListener('click', () => go('discover'));

/* Quét tự động ảnh camera mới -> đối chiếu host và đẩy lên (1 chiều). */
let autoSyncTimer = null;
let autoSyncRunning = false;
async function autoSyncCheck() {
  if (!server || !token || autoSyncRunning || syncPaused) return;
  if (!camOn) return;
  autoSyncRunning = true;
  try {
    if (typeof syncCameraNow === 'function') {
      await syncCameraNow(true);
    }
  } catch (e) {}
  autoSyncRunning = false;
}
function startAutoSync() {
  if (autoSyncTimer) clearInterval(autoSyncTimer);
  autoSyncTimer = setInterval(autoSyncCheck, 30000);
}

function enterMain() {
  $$('.activeHost').forEach((el) => el.textContent = server.name);
  favs = kvGet(kFavs()) || [];
  syncDb = kvGet(kSync()) || {};
  dlPaths = kvGet(kDlPaths()) || {};
  camOn = !!kvGet('cam:' + server.baseUrl);
  localDrive = kvGet(kLocalDrive()) || null;
  loadSyncDest();
  try { DC.setSession(server.baseUrl, token); } catch (e) {}
  $$('.nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.target === 'files'));
  go('files');
  applyFabPos();
  updateFabVisibility();
  loadPools().then(async () => {
    const hp = await hostPool();
    if (hp) {
      pool = hp.id;
      currentPath = phoneName();
      renderPoolBar();
      loadFiles(currentPath);
    } else {
      loadFiles('');
    }
  });
  startKeepAlive();
  restorePending();
  startAutoSync();
}

function onSessionLost() {
  token = null;
  try { DC.setSession('', ''); } catch (e) {}
  DC.removeKV(kToken());
  DC.toast('Phiên đăng nhập đã hết hạn');
  go('signin');
  $('#passInput').value = '';
}

/* ---------- KEEP ALIVE ---------- */
let keepAliveTimer = null;
function startKeepAlive() {
  if (keepAliveTimer) clearInterval(keepAliveTimer);
  keepAliveTimer = setInterval(async () => {
    if (!token || !server) return;
    try {
      await Promise.race([
        api('/api/health'),
        new Promise((_, rej) => setTimeout(() => rej('timeout'), 4000)),
      ]);
      setConn(true);
    } catch (e) { setConn(false); }
  }, 12000);
}
function setConn(ok) {
  $$('.connected .dot').forEach((d) => d.classList.toggle('offline', !ok));
  $$('.connected').forEach((c) => {
    const host = server ? server.name : '';
    c.innerHTML = '';
    const dot = document.createElement('span'); dot.className = 'dot' + (ok ? '' : ' offline');
    c.appendChild(dot);
    c.appendChild(document.createTextNode(ok ? 'Đã kết nối tới ' : 'Mất kết nối · '));
    const b = document.createElement('span'); b.className = 'activeHost'; b.textContent = host;
    c.appendChild(b);
  });
}

/* ---------- FILES ---------- */
async function loadPools() {
  try {
    const d = await api('/api/pools');
    const all = d.pools || [];
    pools = all.filter(p => !isSharedPool(p));
    const prev = pool;
    if (prev && !isSharedPool(prev) && pools.some((p) => p.id === prev && p.online)) pool = prev;
    else {
      const def = pools.find((p) => p.isDefault && p.online) || pools.find((p) => p.online) || pools[0];
      pool = def ? def.id : (pools.length ? pools[0].id : LOCAL_POOL);
    }
  } catch (e) { pools = []; pool = LOCAL_POOL; }
  renderPoolBar();
}

async function loadFiles(path, force) {
  renderPoolBar();
  if (isLocalMode()) { loadLocalFiles(); return; }
  await syncLocksFromServer();
  if (isPoolLocked(pool)) { renderLockedPoolState(); DC.setCanGoBack(false); return; }
  try {
    const d = await api('/api/files?path=' + enc(path || '') + (pool ? '&pool=' + enc(pool) : ''));
    currentPath = d.path || '';
    parentPath = d.parent == null ? null : d.parent;
    entries = d.entries || [];
    renderCrumb();
    renderFiles();
    DC.setCanGoBack(currentPath !== '');
  } catch (e) {
    entries = [];
    renderFiles();
    DC.toast(errText(e));
  }
}

async function loadLocalFiles() {
  const list = $('#files .file-list');
  if (!localDrive || !localDrive.fs) {
    const ok = await ensureLocalFsAccess();
    if (!ok) { renderLocalNoAccess(); return; }
  } else {
    refreshLocalFree();
  }
  const cur = localNav.length ? localNav[localNav.length - 1].path : '';
  list.innerHTML = '<div class="empty">Đang tải…</div>';
  try {
    const r = await callNative('localFsList', JSON.stringify({ path: cur }));
    if (!localNav.length && r.parentId) localNav = [{ path: r.parentId, name: 'Bộ nhớ trong' }];
    entries = ((r && r.entries) || []).map((e) => ({
      name: e.name,
      type: (e.dir || e.type === 'dir') ? 'dir' : 'file',
      size: e.size || 0,
      mtime: e.mtime ? new Date(e.mtime).toISOString() : '',
      _local: true, _fs: true, _p: e.id || e.p || e.path || '', _mime: e.mime || '',
    }));
    renderLocalCrumb();
    renderFiles();
    DC.setCanGoBack(localNav.length > 1);
  } catch (e) {
    entries = [];
    renderLocalNoAccess();
    DC.toast(errText(e));
  }
}

function renderLocalNoAccess() {
  const list = $('#files .file-list');
  const d = document.createElement('div');
  d.className = 'empty';
  d.style.paddingTop = '60px';
  d.innerHTML = '<div style="color:var(--blue)">' + iconSvg('i-phone', 'svg-38') + '</div>'
    + '<div style="margin-top:14px">Để xem các file/folder trên thiết bị, hãy cấp quyền truy cập.<br>Trên iPhone: thư mục được lưu trong Ứng dụng Tệp.</div>';
  const btn = document.createElement('button');
  btn.className = 'btn primary';
  btn.style.cssText = 'width:auto;padding:0 22px;margin:18px auto 0;display:block';
  btn.textContent = 'Cấp quyền truy cập';
  btn.addEventListener('click', async () => {
    const ok = await ensureLocalFsAccess();
    if (ok) loadLocalFiles();
  });
  d.appendChild(btn);
  list.innerHTML = '';
  list.appendChild(d);
  renderLocalCrumb();
}

function goLocalDir(id) {
  const e = entries.find((x) => x._p === id);
  localNav.push({ path: id, name: e ? e.name : id });
  loadLocalFiles();
}

function goLocalBack() {
  if (localNav.length > 1) { localNav.pop(); loadLocalFiles(); return true; }
  return false;
}

function updateBackBtn(show) {
  const btn = document.getElementById('bcBackBtn');
  if (btn) {
    btn.classList.toggle('show', !!show);
    btn.onclick = () => goParentDir();
  }
  const headBtn = document.getElementById('iosHeadBackBtn');
  if (headBtn) {
    headBtn.style.display = show ? 'inline-flex' : 'none';
    headBtn.onclick = () => goParentDir();
  }
}

function goParentDir() {
  if (isLocalMode()) {
    goLocalBack();
  } else if (currentPath) {
    const idx = currentPath.lastIndexOf('/');
    goDir(idx >= 0 ? currentPath.substring(0, idx) : '');
  }
}

function renderLocalCrumb() {
  const trail = document.getElementById('bcTrail') || $('#files .breadcrumb');
  trail.innerHTML = '';
  const rootName = 'Thiết bị này';
  const isRootOnly = localNav.length <= 1;
  updateBackBtn(!isRootOnly);

  const root = document.createElement('span');
  root.className = isRootOnly ? 'now' : 'root';
  root.textContent = rootName;
  if (!isRootOnly) root.addEventListener('click', () => { localNav = localNav.slice(0, 1); loadLocalFiles(); });
  trail.appendChild(root);

  localNav.slice(1).forEach((seg, i) => {
    const sep = document.createElement('span'); sep.textContent = '›'; trail.appendChild(sep);
    const s = document.createElement('span');
    const isLast = i === localNav.length - 2;
    s.className = isLast ? 'now' : 'root';
    s.textContent = seg.name;
    if (!isLast) { const p = seg.path; s.addEventListener('click', () => { localNav = localNav.slice(0, i + 2); loadLocalFiles(); }); }
    trail.appendChild(s);
  });
}

function goDir(path) {
  loadFiles(path || '');
}

function renderCrumb() {
  const trail = document.getElementById('bcTrail') || $('#files .breadcrumb');
  trail.innerHTML = '';
  const parts = currentPath ? currentPath.split('/') : [];
  updateBackBtn(parts.length > 0);

  const root = document.createElement('span');
  root.className = parts.length ? 'root' : 'now';
  root.textContent = server ? server.name : 'CW Datacenter';
  if (parts.length) root.addEventListener('click', () => goDir(''));
  trail.appendChild(root);

  let acc = '';
  parts.forEach((seg, i) => {
    acc += (i ? '/' : '') + seg;
    const sep = document.createElement('span'); sep.textContent = '›'; trail.appendChild(sep);
    const s = document.createElement('span');
    const isLast = i === parts.length - 1;
    s.className = isLast ? 'now' : 'root';
    s.textContent = seg;
    if (!isLast) { const p = acc; s.addEventListener('click', () => goDir(p)); }
    trail.appendChild(s);
  });
}

function transferFor(rel) {
  for (const k in transfers) {
    const t = transfers[k];
    if (t.rel === rel && (t.status === 'active' || t.status === 'paused')) return t;
  }
  return null;
}

function statusCell(e) {
  if (e._local) return '<span style="color:#b6bec9">—</span>';
  const rel = relOf(e);
  const t = transferFor(rel);
  if (t && t.total > 0) {
    const pc = Math.floor(t.done * 100 / t.total);
    return '<span class="status progress">◔ ' + pc + '%</span>';
  }
  if (e.type === 'file' && (syncDb[rel] || dlPaths[rel])) {
    return '<span style="color:var(--green);display:inline-flex;vertical-align:middle">' + iconSvg('i-check-circle', 'svg-18') + '</span> Đã đồng bộ';
  }
  return '<span style="color:#b6bec9">—</span>';
}

function displayEntries() {
  let shown = entries.slice();
  if (searchQuery) {
    const q = searchQuery.toLowerCase();
    shown = shown.filter((e) => e.name.toLowerCase().includes(q));
  }
  shown.sort((a, b) => {
    // Luôn ưu tiên thư mục hiển thị trước tệp tin
    if (a.type === 'dir' && b.type !== 'dir') return -1;
    if (a.type !== 'dir' && b.type === 'dir') return 1;

    switch (sortMode) {
      case 'media_img': {
        const isA = STREAM_IMG.test(a.name) ? 1 : (STREAM_VIDEO.test(a.name) ? 2 : 3);
        const isB = STREAM_IMG.test(b.name) ? 1 : (STREAM_VIDEO.test(b.name) ? 2 : 3);
        if (isA !== isB) return isA - isB;
        const ta = a.mtime ? new Date(a.mtime).getTime() : 0;
        const tb = b.mtime ? new Date(b.mtime).getTime() : 0;
        return tb - ta;
      }
      case 'media_vid': {
        const isA = STREAM_VIDEO.test(a.name) ? 1 : (STREAM_IMG.test(a.name) ? 2 : 3);
        const isB = STREAM_VIDEO.test(b.name) ? 1 : (STREAM_IMG.test(b.name) ? 2 : 3);
        if (isA !== isB) return isA - isB;
        const ta = a.mtime ? new Date(a.mtime).getTime() : 0;
        const tb = b.mtime ? new Date(b.mtime).getTime() : 0;
        return tb - ta;
      }
      case 'name_desc':
        return b.name.localeCompare(a.name, 'vi', { numeric: true, sensitivity: 'base' });
      case 'name_asc':
      case 'name':
        return a.name.localeCompare(b.name, 'vi', { numeric: true, sensitivity: 'base' });
      case 'size_asc':
        return (a.size || 0) - (b.size || 0);
      case 'size_desc':
      case 'size':
        return (b.size || 0) - (a.size || 0);
      case 'time_asc': {
        const ta = a.mtime ? new Date(a.mtime).getTime() : 0;
        const tb = b.mtime ? new Date(b.mtime).getTime() : 0;
        return ta - tb;
      }
      case 'time_desc':
      case 'time': {
        const ta = a.mtime ? new Date(a.mtime).getTime() : 0;
        const tb = b.mtime ? new Date(b.mtime).getTime() : 0;
        return tb - ta;
      }
      default:
        return a.name.localeCompare(b.name, 'vi', { numeric: true, sensitivity: 'base' });
    }
  });
  return shown;
}

function openSortSheet() {
  openSheet('Sắp xếp theo', (body) => {
    // 1. Tên (A-Z / Z-A)
    const isNameActive = sortMode === 'name_asc' || sortMode === 'name_desc' || sortMode === 'name';
    const isNameAsc = sortMode === 'name_asc' || sortMode === 'name';
    const nameSub = isNameActive 
      ? (isNameAsc ? 'Đang chọn: A → Z (Nhấn để đổi sang Z → A)' : 'Đang chọn: Z → A (Nhấn để đổi sang A → Z)')
      : 'Sắp xếp theo thứ tự bảng chữ cái';
    const nameBadge = isNameActive ? (isNameAsc ? 'A → Z' : 'Z → A') : '';
    
    sheetItem(body, 'Tên tệp (A-Z / Z-A)', {
      icon: 'i-sort',
      sub: nameSub,
      badge: nameBadge,
      badgeClass: 'blue',
      active: isNameActive,
      onClick: () => {
        if (sortMode === 'name_asc' || sortMode === 'name') {
          sortMode = 'name_desc';
          DC.toast('Sắp xếp: Tên (Z → A)');
        } else {
          sortMode = 'name_asc';
          DC.toast('Sắp xếp: Tên (A → Z)');
        }
        renderFiles();
      }
    });

    // 2. Dung lượng (Nhỏ -> Lớn / Lớn -> Nhỏ)
    const isSizeActive = sortMode === 'size_asc' || sortMode === 'size_desc';
    const isSizeAsc = sortMode === 'size_asc';
    const sizeSub = isSizeActive
      ? (isSizeAsc ? 'Đang chọn: Nhỏ → Lớn (Nhấn để đổi sang Lớn → Nhỏ)' : 'Đang chọn: Lớn → Nhỏ (Nhấn để đổi sang Nhỏ → Lớn)')
      : 'Sắp xếp theo kích thước dung lượng';
    const sizeBadge = isSizeActive ? (isSizeAsc ? 'Nhỏ → Lớn' : 'Lớn → Nhỏ') : '';

    sheetItem(body, 'Dung lượng (Nhỏ ↔ Lớn)', {
      icon: 'i-cube',
      sub: sizeSub,
      badge: sizeBadge,
      badgeClass: 'blue',
      active: isSizeActive,
      onClick: () => {
        if (sortMode === 'size_asc') {
          sortMode = 'size_desc';
          DC.toast('Sắp xếp: Dung lượng (Lớn → Nhỏ)');
        } else {
          sortMode = 'size_asc';
          DC.toast('Sắp xếp: Dung lượng (Nhỏ → Lớn)');
        }
        renderFiles();
      }
    });

    // 3. Ngày tháng (Gần nhất -> Xa nhất / Xa nhất -> Gần nhất)
    const isTimeActive = sortMode === 'time_desc' || sortMode === 'time_asc' || sortMode === 'time';
    const isTimeDesc = sortMode === 'time_desc' || sortMode === 'time';
    const timeSub = isTimeActive
      ? (isTimeDesc ? 'Đang chọn: Gần nhất → Xa nhất (Nhấn để đổi sang Xa nhất → Gần nhất)' : 'Đang chọn: Xa nhất → Gần nhất (Nhấn để đổi sang Gần nhất → Xa nhất)')
      : 'Sắp xếp theo ngày tạo / chỉnh sửa';
    const timeBadge = isTimeActive ? (isTimeDesc ? 'Gần nhất' : 'Xa nhất') : '';

    sheetItem(body, 'Ngày tháng (Mới ↔ Cũ)', {
      icon: 'i-sync',
      sub: timeSub,
      badge: timeBadge,
      badgeClass: 'blue',
      active: isTimeActive,
      onClick: () => {
        if (sortMode === 'time_desc' || sortMode === 'time') {
          sortMode = 'time_asc';
          DC.toast('Sắp xếp: Ngày tạo (Xa nhất → Gần nhất)');
        } else {
          sortMode = 'time_desc';
          DC.toast('Sắp xếp: Ngày tạo (Gần nhất → Xa nhất)');
        }
        renderFiles();
      }
    });

    // 4. Ảnh / Video (Ưu tiên Ảnh ↔ Ưu tiên Video)
    const isMediaActive = sortMode === 'media_img' || sortMode === 'media_vid';
    const isMediaImg = sortMode === 'media_img';
    const mediaSub = isMediaActive
      ? (isMediaImg ? 'Đang chọn: Ưu tiên Ảnh (Nhấn để đổi sang Ưu tiên Video)' : 'Đang chọn: Ưu tiên Video (Nhấn để đổi sang Ưu tiên Ảnh)')
      : 'Sắp xếp phân loại ưu tiên Ảnh hoặc Video lên đầu';
    const mediaBadge = isMediaActive ? (isMediaImg ? 'Ưu tiên Ảnh' : 'Ưu tiên Video') : '';

    sheetItem(body, 'Ảnh / Video (Ảnh ↔ Video)', {
      icon: 'i-video',
      sub: mediaSub,
      badge: mediaBadge,
      badgeClass: 'blue',
      active: isMediaActive,
      onClick: () => {
        if (sortMode === 'media_img') {
          sortMode = 'media_vid';
          DC.toast('🎬 Sắp xếp: Ưu tiên Video');
        } else {
          sortMode = 'media_img';
          DC.toast('🖼️ Sắp xếp: Ưu tiên Ảnh');
        }
        renderFiles();
      }
    });
  });
}

let thumbObserver = null;
function getThumbObserver() {
  if (!thumbObserver && typeof IntersectionObserver !== 'undefined') {
    thumbObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const target = entry.target;
          thumbObserver.unobserve(target);
          if (target.dataset.thumbSrc) {
            target.src = target.dataset.thumbSrc;
            delete target.dataset.thumbSrc;
          }
        }
      });
    }, { rootMargin: '250px 0px' });
  }
  return thumbObserver;
}

function isThumbable(name) { return /\.(png|jpe?g|gif|webp|bmp|avif|heic|heif|mp4|webm|mkv|mov|m4v|avi|3gp|3gpp|flv|wmv|mpg|mpeg|ts|m2ts|mts|vob|ogv|rm|rmvb)$/i.test(name); }

function makeRowIcon(e) {
  const isDir = e.type === 'dir';
  const thumbBase = e._local ? localDocUrl(e) : '';
  const isThumbOK = e._local ? !!thumbBase : true;
  if (!isDir && isThumbable(e.name) && isThumbOK) {
    const rel = relOf(e);
    const wrap = document.createElement('div');
    wrap.style.cssText = 'width:40px;height:40px;display:flex;align-items:center;justify-content:center;overflow:hidden;border-radius:9px;contain:strict;flex-shrink:0';
    const fallback = () => {
      const icon = fileIcon(e.name);
      wrap.innerHTML = '<div style="color:' + icon.color + '">' + iconSvg(icon.sym) + '</div>';
    };
    if (!STREAM_IMG.test(e.name) && STREAM_VIDEO.test(e.name)) {
      if (e._local) { fallback(); return wrap; }
      const img = document.createElement('img');
      img.className = 'file-thumb';
      img.loading = 'lazy';
      img.decoding = 'async';
      img.onerror = fallback;
      let targetSrc = '';
      try { targetSrc = DC.thumbUrl ? DC.thumbUrl(enc(rel), pool ? enc(pool) : '') : ''; } catch (err) {}
      if (!targetSrc && server) {
        targetSrc = server.baseUrl + '/api/thumb?path=' + enc(rel) + (pool ? '&pool=' + enc(pool) : '');
      }
      if (!targetSrc) {
        fallback();
      } else {
        const obs = getThumbObserver();
        if (obs) {
          img.dataset.thumbSrc = targetSrc;
          obs.observe(img);
        } else {
          img.src = targetSrc;
        }
        wrap.appendChild(img);
      }
      return wrap;
    }
    if (e._local) {
      const img = document.createElement('img');
      img.className = 'file-thumb';
      img.loading = 'lazy';
      img.decoding = 'async';
      img.onerror = fallback;
      img.src = thumbBase + (thumbBase.includes('?') ? '&thumb=1' : '?thumb=1');
      wrap.appendChild(img);
      return wrap;
    }

    const img = document.createElement('img');
    img.className = 'file-thumb';
    img.loading = 'lazy';
    img.decoding = 'async';
    img.onerror = fallback;
    let targetSrc = '';
    try { targetSrc = DC.thumbUrl ? DC.thumbUrl(enc(rel), pool ? enc(pool) : '') : ''; } catch (err) {}
    if (!targetSrc && server) {
      targetSrc = server.baseUrl + '/api/thumb?path=' + enc(rel) + (pool ? '&pool=' + enc(pool) : '');
    }
    if (!targetSrc) {
      fallback();
    } else {
      const obs = getThumbObserver();
      if (obs) {
        img.dataset.thumbSrc = targetSrc;
        obs.observe(img);
      } else {
        img.src = targetSrc;
      }
      wrap.appendChild(img);
    }
    return wrap;
  }
  const icon = isDir ? { sym: 'i-folder', color: 'var(--yellow)' } : fileIcon(e.name);
  const d = document.createElement('div');
  d.style.cssText = 'color:' + icon.color + ';display:flex;align-items:center;justify-content:center;width:40px;height:40px;flex-shrink:0';
  d.innerHTML = iconSvg(icon.sym, 'svg-24');
  return d;
}

function updateSelBar() {
  /* Thanh chọn đen đã bỏ — hành động nằm trong bảng (sheet) mở sau khi nhấn giữ. */
}

function selectedEntries() {
  return displayEntries().filter((e) => selectedSet.has(e.name));
}

let currentRenderedCount = 0;
const RENDER_CHUNK = 60;
let fileListObserver = null;

function renderFileRow(e) {
  const isDir = e.type === 'dir';
  const meta = isDir ? fmtDate(e.mtime) : ((e.size ? fmtBytes(e.size) : '') + (e.size ? ' · ' : '') + fmtDate(e.mtime));
  const locked = e._local ? false : entryLocked(e);
  const row = document.createElement('div');
  row.className = 'file-row' + (selMode && selectedSet.has(e.name) ? ' checked' : '');
  row.dataset.name = e.name;
  row.innerHTML =
    '<div class="row-ico"><div class="row-check">✓</div></div>' +
    '<div><div class="file-name">' + esc(e.name) + (locked ? '<span class="lock-ico">' + iconSvg('i-lock', 'svg-18') + '</span>' : '') + '</div><div class="meta">' + esc(meta) + '</div></div>' +
    '<div class="status">' + statusCell(e) + '</div>' +
    '<div style="color:#98a2b3;font-size:18px" class="more">⋮</div>';
  row.querySelector('.row-ico').prepend(makeRowIcon(e));
  row.addEventListener('click', () => onRowClick(e, row));
  const more = row.querySelector('.more');
  more.addEventListener('click', (ev) => { ev.stopPropagation(); openFileSheet(e); });
  return row;
}

function appendNextFileChunk(list, shown) {
  if (currentRenderedCount >= shown.length) return;
  const frag = document.createDocumentFragment();
  const nextSlice = shown.slice(currentRenderedCount, currentRenderedCount + RENDER_CHUNK);
  nextSlice.forEach((e) => {
    frag.appendChild(renderFileRow(e));
  });
  currentRenderedCount += nextSlice.length;

  const sentinel = list.querySelector('#fileListSentinel');
  if (sentinel) {
    list.insertBefore(frag, sentinel);
    if (currentRenderedCount >= shown.length) {
      sentinel.remove();
    }
  } else {
    list.appendChild(frag);
  }
}

function renderFiles() {
  const list = $('#files .file-list');
  list.innerHTML = '';
  currentRenderedCount = 0;
  if (fileListObserver) {
    fileListObserver.disconnect();
    fileListObserver = null;
  }
  let shown = displayEntries();
  if (!shown.length) {
    const d = document.createElement('div');
    d.className = 'empty';
    d.textContent = searchQuery ? 'Không có kết quả cho "' + searchQuery + '"'
      : isLocalMode() ? 'Thư mục trống.'
      : 'Thư mục trống. Bấm nút xanh để tải tệp lên.';
    list.appendChild(d);
    return;
  }

  const initialCount = Math.min(shown.length, RENDER_CHUNK);
  const frag = document.createDocumentFragment();
  for (let i = 0; i < initialCount; i++) {
    frag.appendChild(renderFileRow(shown[i]));
  }
  currentRenderedCount = initialCount;

  if (shown.length > initialCount) {
    const sentinel = document.createElement('div');
    sentinel.id = 'fileListSentinel';
    sentinel.style.cssText = 'height:60px;display:flex;align-items:center;justify-content:center;color:#98a2b3;font-size:12px';
    sentinel.textContent = 'Đang tải thêm…';
    frag.appendChild(sentinel);
    list.appendChild(frag);

    fileListObserver = new IntersectionObserver((entries) => {
      if (entries[0] && entries[0].isIntersecting) {
        appendNextFileChunk(list, shown);
      }
    }, {
      root: list,
      rootMargin: '400px'
    });
    fileListObserver.observe(sentinel);
  } else {
    list.appendChild(frag);
  }
}

function onRowClick(e, row) {
  if (lpSuppressClick) return;
  if (selMode) { toggleSelect(e.name); return; }
  if (e._local) { onLocalRowClick(e); return; }
  if (e.type === 'dir') { requireUnlocked(e, () => goDir(relOf(e))); return; }
  if (isPreviewable(e.name)) { requireUnlocked(e, () => openPreview(e)); return; }
  requireUnlocked(e, () => openFileSheet(e));
}

function onLocalRowClick(e) {
  if (e.type === 'dir') { goLocalDir(e._p); return; }
  if (isPreviewable(e.name)) { openPreview(e); return; }
  localOpenWith(e);
}

function localOpenWith(e) {
  callNative('localFsOpen', JSON.stringify(localSpec(e)))
    .catch((er) => DC.toast(errText(er)));
}

function openFileSheet(e) {
  if (e && e._local) { localFileSheet(e); return; }
  const rel = relOf(e);
  const favIdx = favs.findIndex((f) => f.rel === rel);
  if (entryLocked(e)) {
    openSheet(e.name, (body) => {
      sheetItem(body, 'Mở khóa bằng mật khẩu', { icon: 'i-lock', onClick: () =>
        unlockSheet(e, () => (e.type === 'dir' ? goDir(rel) : openFileSheet(e))) });
    });
    return;
  }
  openSheet(e.name, (body) => {
    if (isPreviewable(e.name)) sheetItem(body, 'Xem trực tiếp', { icon: 'i-monitor', onClick: () => openPreview(e) });
    sheetItem(body, 'Chia sẻ link', { icon: 'i-upload', onClick: () => { closeSheet(); openShareSheet(e); } });
    sheetItem(body, 'Tải xuống', { icon: 'i-upload', onClick: () => { closeSheet(); startDownload(e); } });
    sheetItem(body, 'Tải về & mở bằng ứng dụng khác', { icon: 'i-monitor', onClick: () => openOrFetch(e) });
    if (canWrite()) {
      sheetItem(body, 'Copy', { icon: 'i-copy', onClick: () => clipCopy(e) });
      sheetItem(body, 'Cut', { icon: 'i-cut', onClick: () => clipCut(e) });
      if (clipboard.items.length) sheetItem(body, 'Dán vào đây (' + clipboard.items.length + ' mục)', { icon: 'i-paste', onClick: () => { closeSheet(); clipPaste(); } });
      sheetItem(body, 'Đổi tên', { icon: 'i-settings', onClick: () =>
        sheetPrompt('Đổi tên', 'Tên mới', e.name, async (name) => {
          try { await api('/api/rename', 'POST', { path: rel, newName: name, pool }); DC.toast('Đã đổi tên'); loadFiles(currentPath); }
          catch (er) { DC.toast(errText(er)); }
        }) });
      sheetItem(body, 'Thư mục mới', { icon: 'i-folder', onClick: () => newFolderHere() });
    }
    sheetItem(body, favIdx >= 0 ? 'Bỏ yêu thích' : 'Thêm yêu thích', { icon: 'i-star', onClick: () => toggleFav(e) });
    if (ensureLockMap()[lockKeyFor(e)]) {
      sheetItem(body, 'Gỡ mật khẩu khóa', { danger: true, icon: 'i-trash', onClick: () => removeLock(e) });
    } else {
      sheetItem(body, 'Khóa bằng mật khẩu', { icon: 'i-lock', onClick: () => lockSheet(e) });
    }
    if (canWrite()) {
      sheetItem(body, 'Xóa (vào thùng rác)', { danger: true, icon: 'i-trash', onClick: () =>
        sheetConfirm('Xóa ' + (e.type === 'dir' ? 'thư mục' : 'tệp'), '"' + e.name + '" sẽ được chuyển vào Thùng rác.', 'Xóa', async () => {
          try { await api('/api/file?path=' + enc(rel) + '&pool=' + enc(pool), 'DELETE'); DC.toast('Đã chuyển vào thùng rác'); loadFiles(currentPath); }
          catch (er) { DC.toast(errText(er)); }
        }) });
    }
  });
}

async function copyToClipboard(text) {
  try {
    const res = await callNative('copyClipboard', text);
    if (res && res.ok) return true;
  } catch (e) {}
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    document.execCommand('copy');
    ta.remove();
    return true;
  } catch (e) {}
  return false;
}

async function openShareSheet(entry) {
  const items = Array.isArray(entry) ? entry : [entry];
  if (!items.length) return;
  openSheet(items.length > 1 ? 'Chia sẻ ' + items.length + ' mục' : 'Chia sẻ "' + items[0].name + '"', async (body) => {
    const hint = document.createElement('div');
    hint.style.cssText = 'font-size:12px;color:#98a2b3;margin:-8px 0 12px;line-height:1.5';
    hint.textContent = 'Người nhận có thể tải trực tiếp qua trình duyệt không cần mật khẩu.';
    body.appendChild(hint);

    const outWrap = document.createElement('div');
    outWrap.style.cssText = 'display:flex;flex-direction:column;gap:8px;margin-bottom:12px';
    outWrap.innerHTML = '<div style="font-size:13px;color:#667085;padding:8px 0">Đang tạo link…</div>';
    body.appendChild(outWrap);

    try {
      const links = [];
      for (const it of items) {
        const p = ePool(it);
        const rel = relOf(it);
        const r = await api('/api/share', 'POST', { path: rel, pool: p, ttlHours: 24 });
        const linkUrl = r.shareUrl || (server ? server.baseUrl + '/s/?id=' + encodeURIComponent(r.id) : '');
        links.push({ name: it.name, url: linkUrl });
      }

      outWrap.innerHTML = '';
      links.forEach((l) => {
        const row = document.createElement('div');
        row.style.cssText = 'display:flex;align-items:center;gap:8px;background:#f5f7fa;padding:8px 12px;border-radius:10px';
        row.innerHTML = '<input type="text" readonly style="flex:1;background:transparent;border:0;font-size:12px;color:#344054" value="' + esc(l.url) + '"><button class="btn" style="height:32px;padding:0 12px;font-size:12px;background:var(--blue);color:#fff;border:0;border-radius:8px">Copy</button>';
        const b = row.querySelector('button');
        b.addEventListener('click', async () => {
          await copyToClipboard(l.url);
          b.textContent = 'Đã copy ✓';
          setTimeout(() => { b.textContent = 'Copy'; }, 1500);
        });
        outWrap.appendChild(row);
      });

      if (links.length > 1) {
        const copyAllBtn = document.createElement('button');
        copyAllBtn.className = 'btn';
        copyAllBtn.style.cssText = 'width:100%;height:38px;margin-top:4px;font-size:13px;background:#111827;color:#fff;border-radius:10px;border:0';
        copyAllBtn.textContent = 'Copy tất cả ' + links.length + ' link';
        copyAllBtn.addEventListener('click', async () => {
          await copyToClipboard(links.map((l) => l.url).join('\n'));
          copyAllBtn.textContent = 'Đã copy tất cả ✓';
          setTimeout(() => { copyAllBtn.textContent = 'Copy tất cả ' + links.length + ' link'; }, 1500);
        });
        outWrap.appendChild(copyAllBtn);
      }
    } catch (e) {
      outWrap.innerHTML = '<div style="color:var(--red);font-size:13px">Lỗi tạo link: ' + esc(errText(e)) + '</div>';
    }
  });
}

function localFileSheet(e) {
  openSheet(e.name, (body) => {
    if (isPreviewable(e.name)) sheetItem(body, 'Xem trực tiếp', { icon: 'i-monitor', onClick: () => openPreview(e) });
    sheetItem(body, 'Mở bằng ứng dụng khác', { icon: 'i-monitor', onClick: () => localOpenWith(e) });
    sheetItem(body, 'Tải về (lưu bản sao)', { icon: 'i-download', onClick: () => { closeSheet(); localDownloadEntry(e); } });
    if (canWrite()) {
      sheetItem(body, 'Copy', { icon: 'i-copy', onClick: () => clipCopy(e) });
      sheetItem(body, 'Cut', { icon: 'i-cut', onClick: () => clipCut(e) });
      if (clipboard.items.length) sheetItem(body, 'Dán vào đây (' + clipboard.items.length + ' mục)', { icon: 'i-paste', onClick: () => { closeSheet(); clipPaste(); } });
    }
    sheetItem(body, 'Thêm yêu thích', { icon: 'i-star', onClick: () => toggleFav(e) });
    sheetItem(body, 'Xóa khỏi thiết bị', { danger: true, icon: 'i-trash', onClick: () => localDeleteEntries([e]) });
  });
}

async function localDeleteEntries(entries) {
  const paths = entries.map((e) => e._p || e.path || e.rel).filter(Boolean);
  if (!paths.length) return;
  sheetConfirm('Xóa ' + paths.length + ' mục', 'Bạn có chắc chắn muốn xóa vĩnh viễn ' + paths.length + ' mục này khỏi thiết bị không?', 'Xóa vĩnh viễn', async () => {
    try {
      const res = await callNative('localFsDelete', JSON.stringify({ items: paths }));
      if (res && res.ok) {
        DC.toast('Đã xóa ' + (res.done || paths.length) + ' mục khỏi thiết bị');
      } else {
        DC.toast('Xóa thất bại');
      }
    } catch (e) {
      DC.toast('Lỗi xóa: ' + (e.message || e));
    }
    loadLocalFiles();
  });
}

function localDeleteSelected() {
  const entries = selectedEntries();
  if (!entries.length) return;
  localDeleteEntries(entries);
  exitSelMode();
}

async function newFolderHere() {
  if (isLocalMode()) {
    sheetPrompt('Thư mục mới', 'Tên thư mục', '', async (name) => {
      if (!name || !name.trim()) return;
      try {
        const curLocal = localNav.length ? localNav[localNav.length - 1].path : (localRootPath || '');
        const r = await callNative('localFsMkdir', JSON.stringify({ parent: curLocal, name: name.trim() }));
        if (r && r.ok) {
          DC.toast('Đã tạo thư mục');
          loadLocalFiles();
        } else {
          DC.toast('Tạo thư mục thất bại' + (r && r.err ? ': ' + r.err : ''));
        }
      } catch (er) { DC.toast(errText(er)); }
    });
    return;
  }
  if (isPoolLocked(pool)) { unlockSheet(poolTargetOf(pool), () => newFolderHere()); return; }
  sheetPrompt('Thư mục mới', 'Tên thư mục', '', async (name) => {
    if (!name || !name.trim()) return;
    try {
      await api('/api/mkdir', 'POST', { path: (currentPath ? currentPath + '/' : '') + name.trim(), pool });
      DC.toast('Đã tạo thư mục');
      loadFiles(currentPath);
    } catch (er) { DC.toast(errText(er)); }
  });
}

function toggleFav(e) {
  if (e && e._local) {
    const keyId = e._p || e._id;
    const lrel = 'local:' + keyId;
    const i = favs.findIndex((f) => f.rel === lrel);
    if (i >= 0) { favs.splice(i, 1); DC.toast('Đã bỏ yêu thích'); }
    else {
      favs.unshift({ rel: lrel, name: e.name, type: e.type, local: true, _p: e._p || '', _mime: e._mime || '', size: e.size || 0 });
      DC.toast('Đã thêm vào yêu thích');
    }
    kvSet(kFavs(), favs);
    renderFiles();
    return;
  }
  const rel = relOf(e);
  const i = favs.findIndex((f) => f.rel === rel);
  if (i >= 0) { favs.splice(i, 1); DC.toast('Đã bỏ yêu thích'); }
  else {
    favs.unshift({ rel, name: e.name, type: e.type, pool, size: e.size || 0 });
    DC.toast('Đã thêm vào yêu thích');
  }
  kvSet(kFavs(), favs);
  renderFiles();
}

/* ---------- COPY / CUT / PASTE (giống app PC) ---------- */
let selMode = false;
const selectedSet = new Set();

/* Nút nổi "Paste (N mục)": hiện sau khi copy/cut, bấm vào để dán tại thư mục hiện tại
 * (giống nút "Đã chọn N mục"), áp dụng cho cả ổ máy chủ lẫn ổ "Thiết bị này",
 * và cho phép dán chéo giữa 2 ổ. */
const pasteFab = document.createElement('button');
pasteFab.className = 'paste-fab';
document.querySelector('.app-shell').appendChild(pasteFab);
pasteFab.addEventListener('click', () => { if (clipboard.items.length) clipPaste(); });

const pasteProgBox = document.createElement('div');
pasteProgBox.className = 'paste-progress-box';
pasteProgBox.innerHTML = '<div class="pb-text"><span class="pb-title">Đang dán…</span><span class="pb-pct">0%</span></div><div class="pb-bar"><div class="pb-fill"></div></div>';
document.querySelector('.app-shell').appendChild(pasteProgBox);

let pasteInProgress = false;

function updatePasteFab() {
  if (pasteInProgress) return;
  const show = clipboard.items.length > 0 && currentView === 'files' && !sheetModal.classList.contains('show');
  pasteFab.style.display = show ? 'flex' : 'none';
  if (show) {
    const verb = clipboard.mode === 'cut' ? 'Cắt' : 'Copy';
    pasteFab.innerHTML = '<svg><use href="#i-paste"/></svg><span>Paste (' + verb + ' ' + clipboard.items.length + ' mục)</span>';
  }
}

function showPasteProgress(title, pct) {
  pasteInProgress = true;
  pasteFab.style.display = 'none';
  pasteProgBox.style.display = 'flex';
  pasteProgBox.querySelector('.pb-title').textContent = title;
  pasteProgBox.querySelector('.pb-pct').textContent = Math.round(pct) + '%';
  pasteProgBox.querySelector('.pb-fill').style.width = Math.max(0, Math.min(100, pct)) + '%';
}

function hidePasteProgress(successMsg, isError) {
  if (successMsg) {
    pasteProgBox.querySelector('.pb-title').textContent = successMsg;
    pasteProgBox.querySelector('.pb-pct').textContent = isError ? '✕' : '✓';
    pasteProgBox.querySelector('.pb-fill').style.width = '100%';
    pasteProgBox.querySelector('.pb-fill').style.background = isError ? 'var(--red)' : 'var(--green)';
    setTimeout(() => {
      pasteProgBox.style.display = 'none';
      pasteProgBox.querySelector('.pb-fill').style.background = 'var(--blue)';
      pasteInProgress = false;
      updatePasteFab();
    }, isError ? 1800 : 700);
  } else {
    pasteProgBox.style.display = 'none';
    pasteInProgress = false;
    updatePasteFab();
  }
}

function clipLabel() {
  if (!clipboard.items.length) return '';
  const n = clipboard.items.length;
  return (clipboard.mode === 'copy' ? 'Đã copy ' : 'Đã cut ') + n + ' mục';
}
function clipSetList(items, mode, label) {
  clipboard = { items, mode, dir: currentPath, local: isLocalMode() };
  DC.toast(label);
  updateSelBar();
  updatePasteFab();
}
function clipCopy(e) {
  if (e && e._local) {
    clipSetList([{ p: e._p, dir: isLocalMode() ? localDirPath() : '', local: true, name: e.name }], 'copy', 'Đã copy "' + e.name + '"');
    return;
  }
  clipSetList([{ path: relOf(e), pool, type: e.type }], 'copy', 'Đã copy "' + e.name + '"');
}
function clipCut(e) {
  if (e && e._local) {
    clipSetList([{ p: e._p, dir: isLocalMode() ? localDirPath() : '', local: true, name: e.name }], 'cut', 'Đã cắt "' + e.name + '"');
    return;
  }
  clipSetList([{ path: relOf(e), pool, type: e.type }], 'cut', 'Đã cắt "' + e.name + '"');
}
function clipCopyMulti() {
  if (!selectedSet.size) return;
  if (isLocalMode()) {
    const items = selectedEntries().map((e) => ({ p: e._p, dir: localDirPath(), local: true, name: e.name }));
    clipSetList(items, 'copy', 'Đã copy ' + items.length + ' mục');
    exitSelMode();
    return;
  }
  const items = selectedEntries().map((e) => ({ path: relOf(e), pool, type: e.type }));
  clipSetList(items, 'copy', 'Đã copy ' + items.length + ' mục');
  exitSelMode();
}
function clipCutMulti() {
  if (!selectedSet.size) return;
  if (isLocalMode()) {
    const items = selectedEntries().map((e) => ({ p: e._p, dir: localDirPath(), local: true, name: e.name }));
    clipSetList(items, 'cut', 'Đã cắt ' + items.length + ' mục');
    exitSelMode();
    return;
  }
  const items = selectedEntries().map((e) => ({ path: relOf(e), pool, type: e.type }));
  clipSetList(items, 'cut', 'Đã cắt ' + items.length + ' mục');
  exitSelMode();
}
function localDirPath() {
  return localNav.length ? localNav[localNav.length - 1].path : localRootPath;
}

function enterSelMode(name) {
  if (isPoolLocked(pool)) return;
  if (currentView !== 'files') return;
  selMode = true;
  selectedSet.clear();
  if (name) selectedSet.add(name);
  document.body.classList.add('selmode');
  $$('#files .file-row').forEach((r) => {
    r.classList.toggle('checked', selectedSet.has(r.dataset.name));
  });
  updateSelBar();
  updatePoolBarSelection();
  updateSelFab();
}
function exitSelMode(forceRender) {
  if (!selMode && !forceRender) return;
  selMode = false;
  selectedSet.clear();
  document.body.classList.remove('selmode');
  $$('#files .file-row').forEach((r) => r.classList.remove('checked'));
  updateSelBar();
  updatePoolBarSelection();
  updateSelFab();
}
function toggleSelect(name) {
  if (selectedSet.has(name)) selectedSet.delete(name);
  else selectedSet.add(name);
  if (!selectedSet.size) { exitSelMode(); return; }
  const r = $(`#files .file-row[data-name="${CSS.escape(name)}"]`);
  if (r) r.classList.toggle('checked', selectedSet.has(name));
  updateSelBar();
  updateSelFab();
}

/* ---------- BẢNG CHỌN NHIỀU (sheet hiện sau khi nhấn giữ) ---------- */
function selCountLabel() {
  const names = [];
  displayEntries().forEach((e) => { if (selectedSet.has(e.name) && names.length < 2) names.push(e.name); });
  if (!names.length) return '0 mục';
  return names.join(', ') + (selectedSet.size > 1 ? '… (' + selectedSet.size + ' mục)' : '');
}

function openSelSheet() {
  if (!selMode) return;
  const local = isLocalMode();
  const multi = selectedSet.size > 0;
  openSheet('Đã chọn ' + selectedSet.size + ' mục', (body) => {
    const sub = document.createElement('div');
    sub.style.cssText = 'font-size:12px;color:#98a2b3;margin:-8px 0 10px;line-height:1.5';
    sub.textContent = selCountLabel();
    body.appendChild(sub);
    const item = (label, icon, danger, canRun, run) => {
      const d = sheetItem(body, label, { icon, danger, onClick: () => { if (!canRun) { openSelSheet(); return; } run(); } });
      if (!canRun) { d.style.opacity = '.38'; }
      return d;
    };
    if (local) {
      item('Tải về thiết bị', 'i-download', false, multi, () => {
        const files = selectedEntries().filter((e) => e.type === 'file');
        files.forEach((e) => localDownloadEntry(e));
        DC.toast(files.length === 1 ? 'Đang tải về "' + files[0].name + '"' : 'Đang tải về ' + files.length + ' tệp');
        exitSelMode();
      });
      item('Thêm yêu thích', 'i-star', false, multi, () => {
        selAddFavs();
        exitSelMode();
      });
      item('Mở bằng ứng dụng khác', 'i-monitor', false, multi && selectedEntries().filter((e) => e.type === 'file').length === 1, () => {
        const f = selectedEntries().find((e) => e.type === 'file');
        exitSelMode();
        if (f) localOpenWith(f);
      });
      item('Copy', 'i-copy', false, true, () => { clipCopyMulti(); });
      item('Cut', 'i-cut', false, true, () => { clipCutMulti(); });
      item('Dán vào đây (' + clipboard.items.length + ')', 'i-paste', false, clipboard.items.length > 0, () => { exitSelMode(); clipPaste(); });
      item('Chọn tất cả (' + displayEntries().length + ')', 'i-check-circle', false, true, () => {
        displayEntries().forEach((e) => selectedSet.add(e.name));
        renderFiles();
        openSelSheet();
      });
      item('Xóa khỏi thiết bị', 'i-trash', true, multi, () => localDeleteSelected());
    } else {
      item('Tải về', 'i-download', false, multi, () => {
        const files = selectedEntries().filter((e) => e.type === 'file');
        files.forEach((e) => startDownloadFor(e));
        DC.toast(files.length === 1 ? 'Đang tải về "' + files[0].name + '"' : 'Đang tải về ' + files.length + ' tệp');
        exitSelMode();
      });
      item('Chia sẻ link', 'i-upload', false, multi, () => {
        const sel = selectedEntries();
        exitSelMode();
        openShareSheet(sel);
      });
      item('Thêm yêu thích', 'i-star', false, multi, () => {
        selAddFavs();
        exitSelMode();
      });
      item('Khóa bằng mật khẩu', 'i-lock', false, multi, () => selLockAll());
      if (canWrite()) {
        item('Copy', 'i-copy', false, true, () => { clipCopyMulti(); });
        item('Cut', 'i-cut', false, true, () => { clipCutMulti(); });
        item('Dán vào đây (' + clipboard.items.length + ')', 'i-paste', false, clipboard.items.length > 0, () => { exitSelMode(); clipPaste(); });
      }
      item('Chọn tất cả (' + displayEntries().length + ')', 'i-check-circle', false, true, () => {
        displayEntries().forEach((e) => selectedSet.add(e.name));
        renderFiles();
        openSelSheet();
      });
      item('Xóa (vào thùng rác)', 'i-trash', true, multi && canWrite(), () => selDeleteAll());
    }
    sheetItem(body, 'Bỏ chọn', { onClick: () => exitSelMode() });
  });
}

function selAddFavs() {
  const list = selectedEntries();
  let added = 0;
  list.forEach((e) => {
    const rel = e._local ? 'local:' + e._p : relOf(e);
    if (favs.findIndex((f) => f.rel === rel) < 0) {
      if (e._local) favs.unshift({ rel, name: e.name, type: e.type, local: true, _p: e._p || '', _mime: e._mime || '', size: e.size || 0 });
      else favs.unshift({ rel, name: e.name, type: e.type, pool: ePool(e), size: e.size || 0 });
      added++;
    }
  });
  kvSet(kFavs(), favs);
  DC.toast(added ? 'Đã thêm ' + added + ' mục vào yêu thích' : 'Các mục này đã ở trong yêu thích');
}

function selDeleteAll() {
  const list = selectedEntries();
  if (!list.length) return;
  sheetConfirm('Xóa ' + list.length + ' mục', 'Các mục được chọn sẽ chuyển vào Thùng rác.', 'Xóa', async () => {
    let ok = 0, fail = 0;
    for (const e of list) {
      try {
        await api('/api/file?path=' + enc(relOf(e)) + '&pool=' + enc(ePool(e)), 'DELETE');
        ok++;
      } catch (er) { fail++; }
    }
    DC.toast(fail ? 'Đã xóa ' + ok + ' mục, lỗi ' + fail + ' mục' : 'Đã chuyển ' + ok + ' mục vào thùng rác');
    exitSelMode();
    loadFiles(currentPath);
  });
}

function selLockAll() {
  const list = selectedEntries();
  if (!list.length) return;
  openSheet('Khóa ' + list.length + ' mục bằng mật khẩu', (body) => {
    const wrap = document.createElement('div');
    wrap.className = 'field';
    wrap.innerHTML = '<div class="input-wrap">' + iconSvg('i-lock', 'svg-20') + '<input type="password" placeholder="Mật khẩu khóa (tối thiểu 3 ký tự)"></div>';
    body.appendChild(wrap);
    const input = wrap.querySelector('input');
    const note = document.createElement('div');
    note.style.cssText = 'color:#98a2b3;font-size:12px;margin:4px 2px 10px';
    note.textContent = 'Mật khẩu khóa chỉ có hiệu lực trên thiết bị này.';
    body.appendChild(note);
    setTimeout(() => input.focus(), 120);
    const row = document.createElement('div');
    row.className = 'row-btn';
    row.innerHTML = '<button class="btn secondary">Hủy</button><button class="btn primary">Khóa tất cả</button>';
    row.children[0].addEventListener('click', closeSheet);
    row.children[1].addEventListener('click', async () => {
      if (input.value.length < 3) { note.textContent = '✕ Mật khẩu khóa cần tối thiểu 3 ký tự.'; note.style.color = 'var(--red)'; return; }
      const pw = input.value;
      const hash = sha256js(pw);
      list.forEach((e) => ensureLockMap()[lockKeyFor(e)] = hash);
      saveLockMap();
      for (const e of list) {
        if (!e._local) {
          try {
            await api('/api/locks', 'POST', {
              pool: e.pool || pool,
              path: relOf(e),
              type: e.type === 'dir' ? 'folder' : 'file',
              name: e.name,
              password: pw
            });
          } catch {}
        }
      }
      await syncLocksFromServer();
      closeSheet();
      DC.toast('Đã khóa ' + list.length + ' mục');
      exitSelMode();
      updateLockUI();
    });
    body.appendChild(row);
  });
}
async function clipPaste() {
  if (!clipboard.items.length || !clipboard.mode) { DC.toast('Chưa có mục nào được copy/cut.'); return; }
  if (isLocalMode()) { await clipPasteLocal(); return; }
  if (!canWrite()) { DC.toast('Tài khoản này không có quyền dán.'); return; }
  await clipPasteRemote();
}

/* Dán vào thư mục hiện tại của ổ "Thiết bị này" (hỗ trợ nguồn từ máy LAN). */
async function clipPasteLocal() {
  const to = localDirPath();
  if (!to) { DC.toast('Không xác định được thư mục hiện tại.'); return; }
  try {
    const st = await callNative('localFsStatus', '');
    if (!st || !st.ok) { DC.toast('Chưa có quyền truy cập bộ nhớ máy.'); return; }
  } catch (er) { DC.toast('Chưa có quyền truy cập bộ nhớ máy.'); return; }
  const isCopy = clipboard.mode === 'copy';
  const items = clipboard.items.slice();
  const n = items.length;
  showPasteProgress('Đang dán 0/' + n + ' mục…', 5);
  let doneCount = 0, hasFail = false;
  const cutRemoteItems = [];
  for (let i = 0; i < items.length; i++) {
    const it = items[i];
    showPasteProgress('Đang dán ' + (i + 1) + '/' + n + ' mục…', Math.round(((i + 1) / n) * 90));
    try {
      if (it.local || it.p) {
        const r = await callNative('localFsMove', JSON.stringify({ items: [it.p], to, cut: !isCopy }));
        if (r && r.failed > 0) hasFail = true; else doneCount++;
      } else {
        /* Nguồn từ máy LAN: tải từng mục (file/folder đệ quy) về thư mục hiện tại.
         * Chế độ cut: sau khi tải xong mới xóa nguồn ở máy chủ. */
        const srcPool = it.pool || pool;
        const rel = it.path || '';
        let ok = false;
        if (it.type === 'dir') {
          try {
            const d = await api('/api/files/deep?path=' + enc(rel) + '&pool=' + enc(srcPool));
            const baseName = rel.split('/').pop();
            const files = (d && d.files) || [];
            let allDone = true;
            for (const f of files) {
              const relF = rel + '/' + f.rel;
              const dir = f.rel.includes('/') ? f.rel.slice(0, f.rel.lastIndexOf('/')) : '';
              const sub = baseName + (dir ? '/' + dir : '');
              const r = await dlSubToLocal(relF, f.rel.split('/').pop(), srcPool, to, sub);
              if (!r) allDone = false;
            }
            ok = allDone || !files.length;
          } catch (er) { ok = false; }
        } else {
          ok = await dlSubToLocal(rel, rel.split('/').pop(), srcPool, to, '');
        }
        if (ok) { doneCount++; if (!isCopy) cutRemoteItems.push(it); }
        else hasFail = true;
      }
    } catch (er) { hasFail = true; }
  }
  if (!isCopy && cutRemoteItems.length) {
    for (const it of cutRemoteItems) {
      try { await api('/api/file?path=' + enc(it.path) + '&pool=' + enc(it.pool || pool), 'DELETE'); } catch (er) {}
    }
  }
  clipboard = { items: [], mode: '', dir: '' };
  loadLocalFiles();
  if (hasFail) {
    hidePasteProgress('Dán xong ' + doneCount + '/' + n + ' mục (có lỗi)', true);
  } else {
    hidePasteProgress('Đã dán thành công ' + n + ' mục', false);
  }
}

/* Tải 1 tệp từ máy chủ về thư mục cục bộ (không làm phiền UI truyền tải). */
async function dlToLocal(rel, name, srcPool, destPath) {
  return dlSubToLocal(rel, name, srcPool, destPath, '');
}

/* Tải 1 tệp về thư mục cục bộ, kèm thư mục con (giữ cấu trúc khi dán thư mục). */
async function dlSubToLocal(rel, name, srcPool, destPath, sub) {
  try {
    const url = server.baseUrl + '/api/file?path=' + enc(rel) + (srcPool && srcPool !== LOCAL_POOL ? '&pool=' + enc(srcPool) : '');
    const spec = { url, name, headers: JSON.stringify(token ? { Authorization: 'Bearer ' + token } : {}), destPath, sync: false };
    if (sub) spec.destSub = sub.replace(/^\/+/, '');
    const key = 'dl:' + (srcPool || pool) + ':paste:' + rel;
    const res = await callNative('download', JSON.stringify(spec));
    if (!res || !res.id) return false;
    transfers[key] = { key, dir: 'down', name, rel, pool: srcPool || pool, status: 'active', done: 0, total: 0, speed: 0, spec };
    transfers[key].id = res.id;
    savePendingDls();
    return await new Promise((resolve) => {
      const check = () => {
        const t = transfers[key];
        if (t && t.status === 'done') { resolve(true); return; }
        if (t && (t.status === 'error' || t.status === 'paused')) { resolve(false); return; }
        setTimeout(check, 400);
      };
      check();
    });
  } catch (e) { return false; }
}

async function clipPasteRemote() {
  if (entryLockedDir(currentPath)) { DC.toast('Thư mục đang bị khóa.'); return; }
  const isCopy = clipboard.mode === 'copy';
  const items = clipboard.items.slice();
  const n = items.length;
  showPasteProgress('Đang dán 0/' + n + ' mục…', 5);

  /* Nếu trong clipboard có mục nguồn từ "Thiết bị này" -> tải từng mục lên máy host trước */
  const localItems = items.filter((it) => it.local || it.p);
  const remoteItems = items.filter((it) => !(it.local || it.p)).map((it) => ({ path: it.path, pool: it.pool }));
  let uploadedLocal = 0, failedLocal = 0;
  for (let i = 0; i < localItems.length; i++) {
    const it = localItems[i];
    showPasteProgress('Đang tải lên (' + (i + 1) + '/' + localItems.length + ')…', Math.round(((i + 1) / localItems.length) * 50));
    try {
      const ok = await uploadLocalItemToHost(it, !isCopy ? [it] : null, 0);
      if (ok) uploadedLocal++; else failedLocal++;
    } catch (er) { failedLocal++; }
  }
  if (remoteItems.length) {
    try {
      const r = await api('/api/move', 'POST', { items: remoteItems, toPool: pool, toPath: currentPath, copy: isCopy });
      if (r.jobId) {
        clipboard = { items: [], mode: '', dir: '' };
        watchPasteJob(r.jobId, remoteItems.length, isCopy);
        return;
      }
    } catch (er) {
      hidePasteProgress('Dán thất bại: ' + errText(er), true);
      return;
    }
  }
  clipboard = { items: [], mode: '', dir: '' };
  loadFiles(currentPath);
  if (failedLocal) {
    hidePasteProgress('Dán xong với ' + (uploadedLocal + remoteItems.length) + ' mục (có lỗi)', true);
  } else {
    hidePasteProgress('Đã dán thành công ' + n + ' mục', false);
  }
}

/* Upload 1 mục (file/folder đệ quy) từ "Thiết bị này" lên thư mục hiện tại của ổ host.
 * Với folder: liệt kê đệ quy rồi upload từng tệp giữ nguyên cấu trúc con.
 * cutAfter != null nghĩa là chế độ cut: upload xong thì xóa nguồn cục bộ. */
async function uploadLocalItemToHost(it, cutAfter, depth) {
  if (depth > 8) return false;
  try {
    const deep = await callNative('localFsDeepList', JSON.stringify({ path: it.p, limit: 10000 }));
    const files = (deep && deep.files) || [];
    if (!files.length) return false;
    let allOk = true;
    for (const f of files) {
      const relName = f.rel || f.name;
      const rel = (currentPath ? currentPath + '/' : '') + relName;
      const ok = await uploadOneLocalToHost(f.p, rel);
      if (!ok) allOk = false;
    }
    if (allOk && cutAfter) {
      const dels = cutAfter.map((x) => x.p);
      if (dels.length) callNative('localFsDelete', JSON.stringify({ items: dels })).catch(() => {});
    }
    return true;
  } catch (e) { return false; }
}

/* Upload 1 tệp cục bộ lên máy host qua cầu nối upload (resume/chunk). */
function uploadOneLocalToHost(p, rel) {
  const name = rel.split('/').pop();
  const key = 'up:' + rel;
  return callNative('upload', JSON.stringify({ baseUrl: server.baseUrl, token, pool, path: rel, name, file: p }))
    .then(async (res) => {
      if (!res || !res.id) return !!(res && res.done);
      if (!transfers[key]) {
        transfers[key] = { key, dir: 'up', name, rel, pool, status: 'active', done: 0, total: 0, speed: 0, spec: { file: p } };
      }
      transfers[key].id = res.id;
      savePendingUps();
      return new Promise((resolve) => {
        const check = () => {
          const t = transfers[key];
          if (t && t.status === 'done') { resolve(true); return; }
          if (t && t.status === 'error') { resolve(false); return; }
          setTimeout(check, 400);
        };
        check();
      });
    })
    .catch(() => false);
}
function entryLockedDir(dirPath) {
  if (!dirPath) return isPoolLocked(pool);
  const i = dirPath.lastIndexOf('/');
  const name = i >= 0 ? dirPath.slice(i + 1) : dirPath;
  const parent = i >= 0 ? dirPath.slice(0, i) : '';
  return !!ensureLockMap()[lockKeyOf(pool, parent, name)] && !lockSession.has(lockKeyOf(pool, parent, name));
}
async function watchPasteJob(jobId, count, isCopy) {
  const tick = async () => {
    try {
      const j = await api('/api/move/progress?id=' + enc(jobId));
      const done = j.doneItems || 0;
      showPasteProgress('Đang dán (' + done + '/' + count + ')…', Math.round((done / Math.max(1, count)) * 100));
      const st = j.status;
      if (st === 'error') {
        hidePasteProgress('Dán bị lỗi: ' + (j.error || 'lỗi máy chủ'), true);
        DC.toast('Dán bị lỗi: ' + (j.error || 'lỗi máy chủ'));
        loadFiles(currentPath);
        return;
      }
      if (st === 'done') {
        hidePasteProgress('Đã dán thành công ' + count + ' mục', false);
        loadFiles(currentPath);
        return;
      }
      setTimeout(tick, 600);
    } catch (e) {
      hidePasteProgress('Dán xong', false);
      loadFiles(currentPath);
    }
  };
  setTimeout(tick, 600);
}

function setupRowLongPress() {
  const list = $('#files .file-list');
  let timer = null;
  let startX = 0, startY = 0, pendingName = null;
  let longDone = false;
  const LONG_MS = 2000;      // Giữ 2 giây để tích chọn theo yêu cầu người dùng
  const MOVE_TOL = 6;        // Di chuyển > 6px là hủy ngay lập tức (không vô tình chọn khi vuốt/cuộn)
  const doSelect = (name) => {
    if (navigator.vibrate) { try { navigator.vibrate(35); } catch (e2) {} }
    lpSuppressClick = true;  // chặn click sinh ra ngay sau khi nhả ngón tay
    setTimeout(() => { lpSuppressClick = false; }, 600);
    if (selMode) toggleSelect(name);
    else enterSelMode(name);
  };
  const fire = () => {
    if (pendingName == null) return;
    const name = pendingName;
    pendingName = null;
    timer = null;
    if (longDone) return;
    longDone = true;
    doSelect(name);
  };
  const clear = () => { if (timer) clearTimeout(timer); timer = null; pendingName = null; };
  list.addEventListener('touchstart', (ev) => {
    longDone = false;
    const row = ev.target.closest && ev.target.closest('.file-row');
    if (!row || !row.dataset.name) { clear(); return; }
    const isMore = ev.target.closest && ev.target.closest('.more');
    if (isMore) { clear(); return; }
    pendingName = row.dataset.name;
    startX = (ev.touches[0] || {}).clientX || 0;
    startY = (ev.touches[0] || {}).clientY || 0;
    if (timer) clearTimeout(timer);
    timer = setTimeout(fire, LONG_MS);
  }, { passive: true });
  list.addEventListener('touchmove', (ev) => {
    if (!timer) return;
    const t = ev.touches[0] || {};
    if (Math.abs((t.clientX || 0) - startX) > MOVE_TOL || Math.abs((t.clientY || 0) - startY) > MOVE_TOL) {
      clear();
    }
  }, { passive: true });
  list.addEventListener('touchend', clear, { passive: true });
  list.addEventListener('touchcancel', clear, { passive: true });
  list.addEventListener('contextmenu', (ev) => {
    // Chặn contextmenu mặc định 500ms của Android WebView để tránh tự chọn khi lướt chậm
    ev.preventDefault();
  });
}
setupRowLongPress();

function setupScrollTop() {
  const btn = $('#scrollTopFab');
  const fileList = $('#files .file-list');
  if (!btn || !fileList) return;
  fileList.addEventListener('scroll', () => {
    if (fileList.scrollTop > 200) {
      btn.classList.add('show');
    } else {
      btn.classList.remove('show');
    }
  }, { passive: true });
  btn.addEventListener('click', () => {
    try {
      fileList.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (e) {
      fileList.scrollTop = 0;
    }
  });
}
setupScrollTop();
$('#searchInput').addEventListener('input', (e) => {
  searchQuery = e.target.value.trim();
  renderFiles();
});
const sortMediaTrigger = $('#sortMediaBtn');
if (sortMediaTrigger) {
  sortMediaTrigger.addEventListener('click', (e) => {
    e.stopPropagation();
    if (sortMode === 'media_img') {
      sortMode = 'media_vid';
      DC.toast('🎬 Sắp xếp: Ưu tiên Video');
    } else {
      sortMode = 'media_img';
      DC.toast('🖼️ Sắp xếp: Ưu tiên Ảnh');
    }
    renderFiles();
  });
}
const sortTrigger = $('#sortBtn') || $('#files .search > span:last-child');
if (sortTrigger) {
  sortTrigger.addEventListener('click', openSortSheet);
}

function updatePoolBarSelection() {
  // Giữ nguyên thanh tab ổ đĩa khi chọn nhiều để danh sách tệp không bị giật nảy vị trí
}

/* ---------- SELECTION: hành động giờ nằm trong bảng (sheet) — xem openSelSheet() ---------- */

/* ---------- FILES HEAD MENU / FAB ---------- */
$('#files .head-more').addEventListener('click', () => {
  openSheet(server ? server.name : '', (body) => {
    if (!isLocalMode()) {
      sheetItem(body, 'Thư mục mới', { icon: 'i-folder', onClick: newFolderHere });
      sheetItem(body, 'Tải tệp lên', { icon: 'i-upload', onClick: pickAndUpload });
      if (clipboard.items.length && canWrite()) sheetItem(body, 'Dán vào đây (' + clipboard.items.length + ' mục)', { icon: 'i-paste', onClick: () => { closeSheet(); clipPaste(); } });
      const pt = poolTargetOf(pool);
      if (isPoolLocked(pool)) sheetItem(body, 'Mở khóa ổ "' + poolNameOf(pool) + '"', { icon: 'i-lock', onClick: () => unlockSheet(pt, () => loadFiles('')) });
      else if (hasPoolLock(pool)) sheetItem(body, 'Gỡ khóa ổ "' + poolNameOf(pool) + '"', { icon: 'i-lock', onClick: () => removeLock(pt) });
      else sheetItem(body, 'Khóa ổ "' + poolNameOf(pool) + '" bằng mật khẩu', { icon: 'i-lock', onClick: () => lockSheet(pt) });
    } else {
      sheetItem(body, 'Cấp quyền lại cho thiết bị', { icon: 'i-phone', onClick: () => { closeSheet(); ensureLocalFsAccess().then((ok) => { if (ok) { localNav = []; loadLocalFiles(); } }); } });
    }
    sheetItem(body, 'Đổi máy chủ', { icon: 'i-server', onClick: switchServer });
    sheetItem(body, 'Làm mới', { icon: 'i-sync', onClick: () => { closeSheet(); if (isLocalMode()) loadLocalFiles(); else loadFiles(currentPath); DC.toast('Đã làm mới danh sách'); } });
    sheetItem(body, 'Xóa bộ nhớ đệm (Cache)', { icon: 'i-trash', onClick: clearAppCacheMobile });
    sheetItem(body, 'Ngắt kết nối', { icon: 'i-power', onClick: disconnectServer });
    sheetItem(body, 'Đăng xuất', { danger: true, icon: 'i-lock', onClick: logout });
  });
});

async function clearAppCacheMobile() {
  closeSheet();
  try {
    await callNative('clearCache', '');
  } catch (e) {}
  DC.toast('✅ Đã dọn sạch bộ nhớ đệm trên thiết bị!');
}

$('#powerBtn').addEventListener('click', disconnectServer);
const bcBackBtn = document.getElementById('bcBackBtn');
if (bcBackBtn) {
  bcBackBtn.addEventListener('click', () => {
    if (isLocalMode()) {
      goLocalBack();
    } else if (currentPath) {
      goDir(parentPath || '');
    }
  });
}

/* FAB: vừa là nút tải lên, vừa cầm-kéo được */
const fabEl = $('.fab');
let fabDrag = null;
let fabSuppressClick = false;
fabEl.addEventListener('pointerdown', (ev) => {
  if (ev.button !== 0 && ev.pointerType === 'mouse') return;
  const shell = document.querySelector('.app-shell');
  const rect = fabEl.getBoundingClientRect();
  fabDrag = { id: ev.pointerId, x: ev.clientX, y: ev.clientY, ox: ev.clientX - rect.left, oy: ev.clientY - rect.top, moved: false };
  try { fabEl.setPointerCapture(ev.pointerId); } catch (e) {}
});
fabEl.addEventListener('pointermove', (ev) => {
  if (!fabDrag || ev.pointerId !== fabDrag.id) return;
  if (!fabDrag.moved && Math.abs(ev.clientX - fabDrag.x) < 9 && Math.abs(ev.clientY - fabDrag.y) < 9) return;
  fabDrag.moved = true;
  const sr = document.querySelector('.app-shell').getBoundingClientRect();
  const w = fabEl.offsetWidth, h = fabEl.offsetHeight;
  let nx = Math.max(8, Math.min(ev.clientX - sr.left - fabDrag.ox, sr.width - w - 8));
  let ny = Math.max(8, Math.min(ev.clientY - sr.top - fabDrag.oy, sr.height - h - 8));
  fabEl.style.left = nx + 'px';
  fabEl.style.top = ny + 'px';
  fabEl.style.right = 'auto';
  fabEl.style.bottom = 'auto';
});
fabEl.addEventListener('pointerup', (ev) => {
  if (!fabDrag || ev.pointerId !== fabDrag.id) return;
  const moved = fabDrag.moved;
  fabDrag = null;
  try { fabEl.releasePointerCapture(ev.pointerId); } catch (e) {}
  if (moved) {
    fabSuppressClick = true;
    const sr = document.querySelector('.app-shell').getBoundingClientRect();
    const fr = fabEl.getBoundingClientRect();
    kvSet('fabpos:' + (server ? server.baseUrl : ''), { x: fr.left - sr.left, y: fr.top - sr.top });
  }
});
fabEl.addEventListener('pointercancel', () => { fabDrag = null; });
fabEl.addEventListener('click', () => {
  if (fabSuppressClick) { fabSuppressClick = false; return; }
  openFabSheet();
});

function openFabSheet() {
  const local = isLocalMode();
  openSheet('Thêm mới', (body) => {
    if (!local) {
      sheetItem(body, 'Tải tệp lên', { icon: 'i-upload', onClick: () => { closeSheet(); pickAndUpload(); } });
      sheetItem(body, 'Tạo thư mục mới', { icon: 'i-folder', onClick: () => { closeSheet(); newFolderHere(); } });
    } else {
      sheetItem(body, 'Tạo thư mục mới', { icon: 'i-folder', onClick: () => { closeSheet(); newFolderHere(); } });
    }
  });
}

function applyFabPos() {
  const pos = kvGet('fabpos:' + (server ? server.baseUrl : ''));
  if (!pos) return;
  const shell = document.querySelector('.app-shell');
  const x = Math.max(8, Math.min(pos.x, shell.clientWidth - 66));
  const y = Math.max(8, Math.min(pos.y, shell.clientHeight - 66));
  fabEl.style.left = x + 'px';
  fabEl.style.top = y + 'px';
  fabEl.style.right = 'auto';
  fabEl.style.bottom = 'auto';
}

function updateFabVisibility() {
  fabEl.style.display = (currentView === 'files') ? '' : 'none';
}

/* Ngắt kết nối: giữ đăng nhập (token + tin cậy), chỉ quay lại màn hình chọn host */
function disconnectServer() {
  try { DC.setSession('', ''); } catch (e) {}
  stopKeepAlive();
  go('discover');
  runDiscover();
}

function switchServer() {
  sheetConfirm('Đổi máy chủ', 'Ngắt kết nối khỏi ' + (server ? server.name : '') + ' và quay lại màn hình chọn máy chủ?', 'Đổi máy chủ', async () => {
    try { if (token) await api('/api/logout', 'POST'); } catch (e) {}
    token = null; me = null;
    DC.removeKV(kToken());
    if (server) DC.removeKV(kTrust());
    server = null;
    stopKeepAlive();
    go('discover');
    runDiscover();
  });
}
function stopKeepAlive() { if (keepAliveTimer) { clearInterval(keepAliveTimer); keepAliveTimer = null; } }

function logout() {
  sheetConfirm('Đăng xuất', 'Đăng xuất khỏi ' + (server ? server.name : '') + '?', 'Đăng xuất', async () => {
    try { if (token) await api('/api/logout', 'POST'); } catch (e) {}
    token = null; me = null;
    try { DC.setSession('', ''); } catch (e) {}
    DC.removeKV(kToken());
    DC.removeKV(kTrust());
    go('signin');
    $('#passInput').value = '';
  });
}

/* ---------- UPLOAD ---------- */
async function pickAndUpload() {
  if (isLocalMode()) { DC.toast('Đang xem ổ "Thiết bị này" — hãy chọn một ổ của máy chủ để tải lên.'); return; }
  if (isPoolLocked(pool)) { unlockSheet(poolTargetOf(pool), () => pickAndUpload()); return; }
  if (!canWrite()) { DC.toast('Tài khoản này không có quyền tải lên.'); return; }
  try {
    const r = await callNative('pickFiles');
    const files = (r && r.files) || [];
    if (!files.length) return;
    for (const f of files) {
      const rel = (currentPath ? currentPath + '/' : '') + f.name;
      const key = 'up:' + rel;
      transfers[key] = { key, dir: 'up', name: f.name, rel, pool, status: 'active', done: 0, total: Math.max(0, f.size || 0), speed: 0, spec: { uri: f.uri } };
      renderFiles();
      try {
        const res = await callNative('upload', JSON.stringify({
          baseUrl: server.baseUrl, token, pool, path: rel, name: f.name, uri: f.uri,
        }));
        if (res && res.done) {
          transfers[key].status = 'done';
          transfers[key].done = transfers[key].total;
          removePendingUp(rel);
          savePendingUps();
        } else {
          transfers[key].id = res.id;
          savePendingUps();
        }
      } catch (e) {
        transfers[key].status = 'error';
        removePendingUp(rel); savePendingUps();
        DC.toast('Tải lên "' + f.name + '" thất bại');
      }
    }
    DC.toast(files.length === 1 ? 'Bắt đầu tải lên "' + files[0].name + '"' : 'Bắt đầu tải lên ' + files.length + ' tệp');
  } catch (e) {}
}

/* ---------- DOWNLOAD ---------- */
function startDownloadFor(e, openWhenDone) {
  const rel = relOf(e);
  const p = ePool(e);
  const key = 'dl:' + p + ':' + rel;
  const url = server.baseUrl + '/api/file?path=' + enc(rel) + (p && p !== LOCAL_POOL ? '&pool=' + enc(p) : '');
  const spec = Object.assign({ url, name: e.name, headers: JSON.stringify({ Authorization: 'Bearer ' + token }) }, destSpecFor(rel, false));
  transfers[key] = {
    key, dir: 'down', name: e.name, rel, pool: p,
    status: 'active', done: 0, total: e.size || 0, speed: 0,
    openWhenDone: !!openWhenDone,
    spec,
    createdAt: Date.now()
  };
  renderFiles();
  callNative('download', JSON.stringify(spec))
    .then((res) => { transfers[key].id = res.id; savePendingDls(); })
    .catch((e2) => { transfers[key].status = 'error'; transfers[key].finishedAt = Date.now(); DC.toast('Tải xuống thất bại: ' + errText(e2)); });
}

function startDownload(e, openWhenDone) {
  if (e && e._local) { localDownloadEntry(e, openWhenDone); return; }
  startDownloadFor(e, openWhenDone);
}

function localDownloadEntry(e, openWhenDone) {
  if (!e || !e._p) { DC.toast('Không tải được tệp này.'); return; }
  const key = 'dl:local:' + e._p;
  const spec = Object.assign({ p: e._p, name: e.name, local: true, sync: true, openWhenDone: !!openWhenDone }, destSpecFor('local/' + e.name, false));
  delete spec.destSub;
  transfers[key] = {
    key, dir: 'down', name: e.name, rel: 'local:' + e._p, pool: LOCAL_POOL,
    status: 'active', done: 0, total: e.size || 0, speed: 0,
    openWhenDone: !!openWhenDone,
    spec,
    createdAt: Date.now()
  };
  renderFiles();
  callNative('localFsDownload', JSON.stringify(spec))
    .then((res) => { transfers[key].id = res.id; savePendingDls(); })
    .catch((e2) => { transfers[key].status = 'error'; transfers[key].finishedAt = Date.now(); DC.toast('Tải xuống thất bại: ' + errText(e2)); });
}

function openOrFetch(e) {
  const rel = relOf(e);
  if (STREAM_PDF.test(e.name)) {
    const p = dlPaths[rel];
    if (p) { callNative('openPdf', JSON.stringify({ path: p, name: e.name })).catch(() => callNative('openFile', JSON.stringify({ path: p }))); return; }
    openNativePdf(e, rel, ePool(e));
    return;
  }
  const p = dlPaths[rel];
  if (p) { callNative('openFile', JSON.stringify({ path: p })); return; }
  DC.toast('Đang tải "' + e.name + '" về máy để mở...');
  startDownload(e, true);
}

/* ---------- NATIVE EVENTS ---------- */
function onNativeEvent(ev) {
  if (ev && ev.type === 'transfer') {
    let found = transfers[ev.id] || null;
    if (!found) {
      for (const k in transfers) if (transfers[k].id === ev.id) { found = transfers[k]; break; }
    }
    if (!found && syncUpQueue.length) {
      const q0 = syncUpQueue[0];
      const k0 = 'up:sync:' + q0.rel + ':' + (q0.pool || '');
      if (transfers[k0]) {
        found = transfers[k0];
        found.id = ev.id;
      }
    }
    if (!found) return;
    if (ev.status === 'done') {
      found.status = 'done';
      found.finishedAt = Date.now();
      found.done = ev.total || found.done;
      found.total = ev.total || found.total;
      if (found.dir === 'up') {
        DC.toast('Đã tải lên "' + found.name + '"');
        if (currentView === 'files') loadFiles(currentPath);
      } else {
        const destTxt = found.spec && found.spec.destPath ? 'vào "' + (found.spec.destPath.split('/').pop() || 'thư mục đã chọn') + '"' : 'vào Downloads';
        DC.toast('Đã tải xuống "' + found.name + '" ' + destTxt);
        if (ev.path) {
          dlPaths[found.rel] = ev.path;
          kvSet(kDlPaths(), dlPaths);
          if (!syncDb[found.rel]) { syncDb[found.rel] = { size: found.total, mtime: Date.now() }; kvSet(kSync(), syncDb); }
        }
        if (found.openWhenDone && ev.path) callNative('openFile', JSON.stringify({ path: ev.path }));
      }
      if (found.dir === 'up') { removePendingUp(found.rel); } else { removePendingDl(found.rel || (found.spec && found.spec.url)); }
      savePendingUps(); savePendingDls();
      bumpSyncQueueIfMatch(found);
    } else if (ev.status === 'error') {
      found.status = 'error';
      found.finishedAt = Date.now();
      found.err = ev.err || 'Lỗi mạng';
      DC.toast(found.dir === 'up' ? 'Tải lên "' + found.name + '" bị lỗi' : 'Tải xuống "' + found.name + '" bị lỗi');
      if (found.dir === 'up') { removePendingUp(found.rel); } else { removePendingDl(found.rel || (found.spec && found.spec.url)); }
      savePendingUps(); savePendingDls();
      bumpSyncQueueIfMatch(found);
    } else if (ev.status === 'paused') {
      found.status = 'paused';
      savePendingUps(); savePendingDls();
    } else {
      found.status = ev.status;
      found.done = ev.done;
      if (ev.total) found.total = ev.total;
      if (ev.speed) found.speed = ev.speed;
    }
    if (currentView === 'transfers') renderTransfers();
    if (currentView === 'files') renderFiles();
    if (currentView === 'sync') renderSync();
  }
}

function bumpSyncQueueIfMatch(t) {
  if (bumpSyncUpIfMatch(t)) return;
}

/* ---------- TRUYỀN TẢI CHẠY NGẦM: lưu hàng chờ để tự nối lại khi mở lại app ---------- */
let restoreDone = false;
let restoreToast = false;

function savePendingUps() {
  if (!server) return;
  const list = Object.values(transfers)
    .filter((t) => t.dir === 'up' && (t.status === 'active' || t.status === 'paused') && t.spec && (t.spec.uri || t.spec.file) && !(t.spec && t.spec.syncUp))
    .map((t) => ({ rel: t.rel, name: t.name, pool: t.pool || 'main', uri: t.spec.uri || '', file: t.spec.file || '', size: t.total || 0 }));
  kvSet(kPending() + ':up', list);
}

function savePendingDls() {
  if (!server) return;
  const list = Object.values(transfers)
    .filter((t) => t.dir === 'down' && (t.status === 'active' || t.status === 'paused') && t.spec && (t.spec.url || t.spec.local))
    .map((t) => ({ url: t.spec.url || '', name: t.name, headers: t.spec.headers || '', destTreeUri: t.spec.destTreeUri || '', destSub: t.spec.destSub || '', destPath: t.spec.destPath || '', rel: t.rel || '', size: t.total || 0, local: !!t.spec.local, tree: t.spec.tree || '', id: t.spec.id || '', mime: t.spec.mime || '' }));
  kvSet(kPending() + ':dl', list);
}

function removePendingUp(rel) {
  const list = kvGet(kPending() + ':up') || [];
  kvSet(kPending() + ':up', list.filter((x) => x.rel !== rel));
}

function removePendingDl(relOrUrl) {
  const list = kvGet(kPending() + ':dl') || [];
  kvSet(kPending() + ':dl', list.filter((x) => x.rel !== relOrUrl && x.url !== relOrUrl));
}

function restorePending() {
  if (restoreDone || !server || !token) return;
  restoreDone = true;
  const ups = kvGet(kPending() + ':up') || [];
  const dls = kvGet(kPending() + ':dl') || [];
  let n = 0;
  ups.forEach((x) => {
    if (transfers['up:' + x.rel]) return;
    const key = 'up:' + x.rel;
    transfers[key] = { key, dir: 'up', name: x.name, rel: x.rel, pool: x.pool, status: 'active', done: 0, total: x.size || 0, speed: 0, spec: { uri: x.uri || '', file: x.file || '' }, createdAt: Date.now() };
    n++;
  });
  dls.forEach((x) => {
    const rel = x.rel || x.url;
    if (transfers['dl:' + rel]) return;
    const key = 'dl:' + rel;
    const spec = x.local
      ? { local: true, tree: x.tree || '', id: x.id || '', name: x.name, mime: x.mime || '', destTreeUri: x.destTreeUri || '', destSub: x.destSub || '', destPath: x.destPath || '', sync: !!x.destTreeUri, resumeRestore: true }
      : { url: x.url, name: x.name, headers: JSON.stringify(token ? { Authorization: 'Bearer ' + token } : {}), destTreeUri: x.destTreeUri || '', destSub: x.destSub || '', destPath: x.destPath || '', resumeRestore: true };
    transfers[key] = { key, dir: 'down', name: x.name, rel, pool: '', status: 'active', done: 0, total: x.size || 0, speed: 0, spec, createdAt: Date.now() };
    (x.local ? callNative('localDownload', JSON.stringify(spec)) : callNative('download', JSON.stringify(spec)))
      .then((res) => { transfers[key].id = res.id; })
      .catch(() => { transfers[key].status = 'error'; transfers[key].finishedAt = Date.now(); removePendingDl(rel); savePendingDls(); });
    n++;
  });
  if (ups.length) {
    let i = 0;
    const next = () => {
      if (i >= ups.length) { if (currentView === 'files') renderFiles(); if (currentView === 'transfers') renderTransfers(); return; }
      const x = ups[i++];
      callNative('upload', JSON.stringify({ baseUrl: server.baseUrl, token, pool: x.pool, path: x.rel, name: x.name, uri: x.uri || '', file: x.file || '' }))
        .then((res) => {
          if (res && res.done) { removePendingUp(x.rel); savePendingUps(); delete transfers['up:' + x.rel]; }
          else if (res && res.id) { transfers['up:' + x.rel].id = res.id; }
          else { transfers['up:' + x.rel].status = 'error'; transfers['up:' + x.rel].finishedAt = Date.now(); }
          setTimeout(next, 120);
        })
        .catch(() => { transfers['up:' + x.rel].status = 'error'; transfers['up:' + x.rel].finishedAt = Date.now(); removePendingUp(x.rel); savePendingUps(); setTimeout(next, 120); });
    };
    next();
  }
  if (n && !restoreToast) {
    restoreToast = true;
    DC.toast('Đang tiếp tục ' + n + ' truyền tải chạy ngầm');
  }
  if (currentView === 'files') renderFiles();
  if (currentView === 'transfers') renderTransfers();
}

/* ---------- TRANSFERS VIEW ---------- */
function transferGroups() {
  const ups = [], downs = [], done = [];
  Object.values(transfers).forEach((t) => {
    if (t.status === 'done' || t.status === 'error') done.push(t);
    else if (t.dir === 'up') ups.push(t);
    else downs.push(t);
  });
  done.sort((a, b) => (b.finishedAt || b.createdAt || 0) - (a.finishedAt || a.createdAt || 0));
  return { ups, downs, done };
}

function transferCard(t) {
  const icon = t.dir === 'up' ? fileIcon(t.name) : fileIcon(t.name);
  const pc = t.total ? Math.floor(t.done * 100 / t.total) : 0;
  const isDone = t.status === 'done';
  const active = t.status === 'active';
  const paused = t.status === 'paused';
  const dlDir = t.pool === LOCAL_POOL ? 'từ thiết bị này' : dirPart(t.rel);
  const sub = t.dir === 'up'
    ? (isDone ? 'Đã tải lên ' + dirPart(t.rel) : active ? 'Đang tải lên ' + dirPart(t.rel) : paused ? 'Đang tạm dừng · ' + dirPart(t.rel) : 'Bị lỗi · ' + (t.err || ''))
    : (isDone ? 'Đã tải xuống vào máy' : active ? 'Đang tải xuống ' + dlDir : paused ? 'Đang tạm dừng' : 'Bị lỗi · ' + (t.err || ''));
  const foot = isDone
    ? '<span>' + fmtBytes(t.total) + '</span><span>100%</span><span' + (t.status !== 'error' ? ' style="color:var(--blue)"' : '') + '>' + (t.status === 'error' ? 'Lỗi' : 'Bấm để mở →') + '</span>'
    : '<span>' + fmtBytes(t.done) + (t.total ? ' / ' + fmtBytes(t.total) : '') + '</span><span>' + pc + '%</span><span>' + (active ? fmtEta(t.total, t.done, t.speed) || '...' : paused ? 'Đã dừng' : '') + '</span>';
  const btn = isDone
    ? '<div class="pause" style="color:var(--green)">✓</div>'
    : (active ? '<div class="pause" data-act="pause">Ⅱ</div>' : paused ? '<div class="pause" data-act="resume">▶</div>' : '<div class="pause" style="color:var(--red)">!</div>');
  return '<div class="transfer-card' + (t.status === 'done' ? ' done' : '') + '" data-key="' + enc(t.key) + '"><div class="transfer-top"><div style="color:' + icon.color + '">' + iconSvg(icon.sym) + '</div>'
    + '<div><div class="transfer-file">' + esc(t.name) + '</div><div class="transfer-sub">' + esc(sub) + '</div></div>'
    + btn + '</div>'
    + '<div class="progressbar' + (isDone ? ' green' : '') + '"><span style="width:' + (t.status === 'error' ? 100 : pc) + '%"></span></div>'
    + '<div class="transfer-foot">' + foot + '</div></div>';
}

function dirPart(rel) {
  const i = rel.lastIndexOf('/');
  return i >= 0 ? '/' + rel.slice(0, i) : '/';
}

function allTransferCardsHtml() {
  const g = transferGroups();
  let html = '';
  const upsActive = g.ups.filter((t) => t.status !== 'paused');
  const downsActive = g.downs.filter((t) => t.status !== 'paused');
  const pausedAll = [].concat(g.ups, g.downs).filter((t) => t.status === 'paused');
  if (!upsActive.length && !downsActive.length && !pausedAll.length) {
    html = '<div class="empty">Không có truyền tải nào đang chạy.<br>Tải lên bằng nút ＋ ở màn hình Tệp, hoặc chọn "Tải xuống" từ menu của tệp.</div>';
  } else {
    if (upsActive.length) html += '<div class="group-title">Đang tải lên (' + upsActive.length + ')</div>' + upsActive.map(transferCard).join('');
    if (downsActive.length) html += '<div class="group-title">Đang tải xuống (' + downsActive.length + ')</div>' + downsActive.map(transferCard).join('');
    if (pausedAll.length) html += '<div class="group-title">Đang tạm dừng (' + pausedAll.length + ')</div>' + pausedAll.map(transferCard).join('');
  }
  return html;
}

function renderTransfers() {
  const box = $('#transfers .transfer-scroll');
  const tabActive = $$('#transfers .tab')[0].classList.contains('active');
  const g = transferGroups();
  box.innerHTML = tabActive ? allTransferCardsHtml()
    : (g.done.length ? '<div class="group-title">Đã hoàn tất (' + g.done.length + ')</div>' + g.done.map(transferCard).join('')
      : '<div class="empty">Chưa có truyền tải nào hoàn tất.</div>');
  $$('#transfers .transfer-card .pause[data-act]').forEach((b) => {
    b.addEventListener('click', (ev) => {
      ev.stopPropagation();
      const key = decodeURIComponent(b.closest('.transfer-card').dataset.key);
      const t = transfers[key];
      if (!t) return;
      if (b.dataset.act === 'pause') pauseTransfer(t);
      else resumeTransfer(t);
    });
  });
  $$('#transfers .transfer-card.done').forEach((card) => {
    card.addEventListener('click', () => {
      const key = decodeURIComponent(card.dataset.key);
      const t = transfers[key];
      if (t) openTransfer(t);
    });
  });
}

function openTransfer(t) {
  if (!t) return;
  if (t.dir === 'down') {
    const p = dlPaths[t.rel];
    if (p) { callNative('openFile', JSON.stringify({ path: p })); return; }
    DC.toast('Không tìm thấy bản đã tải về trên máy.');
    return;
  }
  if (t.dir === 'up') {
    if (!t.rel || isPoolLocked(t.pool)) {
      if (t.pool && hasPoolLock(t.pool)) { unlockSheet(poolTargetOf(t.pool), () => openTransfer(t)); return; }
      DC.toast('Không mở được file này.');
      return;
    }
    openEntryByRel(t.pool || 'main', t.rel);
  }
}

async function openEntryByRel(p, rel) {
  const prevPool = pool;
  try {
    const dir = dirPart(rel).slice(1);
    const d = await api('/api/files?path=' + enc(dir) + (p && p !== LOCAL_POOL ? '&pool=' + enc(p) : ''));
    const name = rel.split('/').pop();
    const e = (d.entries || []).find((x) => x.name === name);
    if (e) {
      requireUnlocked({ name: e.name, dirRel: dir, pool: p }, () => openPreviewWithRel(e, dir, p, rel));
    } else {
      DC.toast('Không tìm thấy file trên máy chủ.');
    }
  } catch (err) {
    DC.toast(errText(err));
  }
}

function openPreviewWithRel(e, dirRel, p, fullRel) {
  e.dirRel = dirRel;
  e.pool = p;
  if (fullRel != null) e._rel = fullRel;
  openPreview(e);
}

$$('#transfers .tab').forEach((tab) => tab.addEventListener('click', () => {
  $$('#transfers .tab').forEach((t) => t.classList.remove('active'));
  tab.classList.add('active');
  renderTransfers();
}));

function pauseTransfer(t) {
  if (!t.id) return;
  callNative('cancel', t.id).catch(() => {});
  t.status = 'paused';
  savePendingUps(); savePendingDls();
  renderTransfers();
  renderFiles();
}

function resumeTransfer(t) {
  if (t.dir === 'up') {
    t.status = 'active';
    callNative('upload', JSON.stringify({ baseUrl: server.baseUrl, token, pool: t.pool, path: t.rel, name: t.name, uri: (t.spec && t.spec.uri) || '', file: (t.spec && t.spec.file) || '' }))
      .then((res) => { t.id = res.id; savePendingUps(); }).catch((e) => { t.status = 'error'; renderTransfers(); });
  } else {
    t.status = 'active';
    if (t.spec && t.spec.local) {
      callNative('localDownload', JSON.stringify(t.spec))
        .then((res) => { t.id = res.id; savePendingDls(); }).catch((e) => { t.status = 'error'; renderTransfers(); });
    } else {
      callNative('download', JSON.stringify(t.spec))
        .then((res) => { t.id = res.id; savePendingDls(); }).catch((e) => { t.status = 'error'; renderTransfers(); });
    }
  }
  renderTransfers();
}

/* ---------- FAVORITES ---------- */
function renderFavorites() {
  favs = kvGet(kFavs()) || [];
  const files = favs.filter((f) => f.type === 'file');
  const dirs = favs.filter((f) => f.type === 'dir');
  const stats = $$('#favorites .stat-value');
  if (stats[0]) stats[0].textContent = String(files.length);
  if (stats[1]) stats[1].textContent = String(dirs.length);
  const list = $('#favorites .list-card');
  list.innerHTML = '';
  if (!favs.length) {
    list.innerHTML = '<div class="empty">Chưa có mục yêu thích nào.<br>Trong màn hình Tệp, bấm ⋮ của tệp/thư mục rồi chọn "Thêm yêu thích".</div>';
    return;
  }
  favs.forEach((f) => {
    const icon = f.type === 'dir' ? { sym: 'i-folder', color: 'var(--yellow)' } : fileIcon(f.name);
    const meta = f.type === 'dir' ? 'Thư mục ghim' : 'Tệp yêu thích' + (f.size ? ' · ' + fmtBytes(f.size) : '');
    const locked = (f.local || f.type === 'dir') ? false : entryLocked({ name: f.name, dirRel: dirPart(f.rel).slice(1), pool: f.pool });
    const row = document.createElement('div');
    row.className = 'favorite-row';
    row.innerHTML =
      '<div style="color:' + icon.color + '">' + iconSvg(icon.sym) + '</div>' +
      '<div><div class="card-title">' + esc(f.name) + '</div><div class="meta2">' + esc(meta) + '</div></div>' +
      (locked ? '<div style="color:var(--blue);display:flex">' + iconSvg('i-lock', 'svg-20') + '</div>' : '<div class="pill blue">Đã thích</div>');
    const pill = row.querySelector('.pill');
    if (pill) pill.addEventListener('click', (ev) => {
      ev.stopPropagation();
      favs = favs.filter((x) => x.rel !== f.rel);
      kvSet(kFavs(), favs);
      renderFavorites();
    });
    row.addEventListener('click', () => { openFavorite(f); });
    list.appendChild(row);
  });
}

function openFavorite(f) {
  if (f.local && f.type !== 'dir') {
    const e = { name: f.name, type: 'file', size: f.size || 0, _local: true, _fs: true, _p: f._p || '', _id: f._id, _mime: f._mime || '', _localTree: f.localTree };
    openPreview(e);
    return;
  }
  const p = f.pool || pool;
  const dirRel = dirPart(f.rel).slice(1);
  if (f.type === 'dir') {
    const locked = resolveLockTarget({ name: f.name, dirRel, pool: p, type: 'dir' });
    const doGo = () => {
      pool = p;
      renderPoolBar();
      $$('.nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.target === 'files'));
      go('files');
      loadFiles(f.rel);
    };
    if (locked) { unlockSheet(locked, doGo); return; }
    doGo();
    return;
  }
  const e = { name: f.name, type: 'file', size: f.size || 0, dirRel, pool: p };
  const t = resolveLockTarget(e);
  const open = () => openPreviewWithRel(e, dirRel, p, f.rel);
  if (t) { unlockSheet(t, open); return; }
  open();
}
$('#favorites .section-head .text-btn').addEventListener('click', () => DC.toast('Bấm vào mục để mở. Bấm "Đã thích" để bỏ yêu thích.'));

/* ---------- ĐỒNG BỘ 1 CHIỀU: thiết bị này -> thư mục shared của máy host ----------
 * Toàn bộ tệp trong thư mục đồng bộ trên điện thoại được ĐẨY LÊN host,
 * nằm trong thư mục con đặt theo tên điện thoại (để nhiều điện thoại cùng đồng bộ). */
function phoneName() {
  let n = String(META.device || META.manufacturer || 'Android').trim();
  n = n.replace(/[\\/:*?"<>|]/g, '_').replace(/\s+/g, ' ').trim();
  return n.slice(0, 40) || 'Android';
}

let hostPoolCache = null;
async function hostPool() {
  if (hostPoolCache) {
    const p = pools.find((x) => x.id === hostPoolCache);
    if (p && p.online !== false) return p;
  }
  if (!pools.length) { try { await loadPools(); } catch (e) {} }
  const p = pools.find((x) => x.isDefault && x.online !== false) || pools.find((x) => x.online !== false) || null;
  hostPoolCache = p ? p.id : null;
  return p;
}

function isCameraSyncRunning() {
  return syncUpQueue.some(q => /^Camera(_\d+)?\//i.test(q.rel));
}

function isFolderSyncRunning() {
  return syncUpQueue.some(q => !/^Camera(_\d+)?\//i.test(q.rel));
}

function stopCameraSync() {
  const camItems = syncUpQueue.filter(q => /^Camera(_\d+)?\//i.test(q.rel));
  camItems.forEach(q => {
    const t = transfers['up:sync:' + q.rel + ':' + (q.pool || '')];
    if (t && t.id) callNative('cancel', t.id).catch(() => {});
  });
  syncUpQueue = syncUpQueue.filter(q => !/^Camera(_\d+)?\//i.test(q.rel));
  syncUpBusy = false;
  renderSync();
  DC.toast('⏹️ Đã dừng đồng bộ ảnh Camera');
}

function stopFolderSync() {
  const fItems = syncUpQueue.filter(q => !/^Camera(_\d+)?\//i.test(q.rel));
  fItems.forEach(q => {
    const t = transfers['up:sync:' + q.rel + ':' + (q.pool || '')];
    if (t && t.id) callNative('cancel', t.id).catch(() => {});
  });
  syncUpQueue = syncUpQueue.filter(q => /^Camera(_\d+)?\//i.test(q.rel));
  syncUpBusy = false;
  renderSync();
  DC.toast('⏹️ Đã dừng đồng bộ thư mục');
}

async function syncFolderNow() {
  if (!server || !token) { DC.toast('Chưa kết nối máy chủ.'); return; }
  const srcPath = syncSrc && syncSrc.path;
  if (!srcPath) { DC.toast('Hãy nhấn "Chọn" để chọn thư mục cần đồng bộ.'); return; }
  try {
    const st = await callNative('localFsStatus', '');
    if (!st || !st.ok) { DC.toast('Chưa có quyền truy cập bộ nhớ máy. Vào tab "Thiết bị này" để cấp quyền.'); return; }
    const hp = await hostPool();
    if (!hp) { DC.toast('Không thấy ổ đĩa nào khả dụng trên máy chủ.'); return; }
    DC.toast('Đang quét và tính toán tệp cần đồng bộ…');
    const d = await callNative('localFsDeepList', JSON.stringify({ path: srcPath, limit: 20000 }));
    const files = (d && d.files) || [];
    if (!files.length) { DC.toast('Thư mục đồng bộ đang trống.'); return; }
    const phoneFolder = phoneName();
    const folderBaseName = (syncSrc && syncSrc.name) ? syncSrc.name : (srcPath.split('/').filter(Boolean).pop() || 'Files');

    // Quét đối chiếu toàn diện file đang có sẵn trên Host (chống trùng lặp tuyệt đối)
    let hostFiles = [];
    const hostPoolsToQuery = [hp.id, 'shared'].filter((v, i, a) => v && a.indexOf(v) === i);
    for (const pId of hostPoolsToQuery) {
      for (const pPath of [phoneFolder, 'shared/' + phoneFolder]) {
        try {
          const hRes = await api('/api/files/deep?path=' + enc(pPath) + '&pool=' + enc(pId));
          if (hRes && hRes.files && hRes.files.length) {
            hostFiles = hostFiles.concat(hRes.files);
          }
        } catch (e) {}
      }
    }

    const hostMapByName = new Map();
    const folderFileCounts = new Map();

    hostFiles.forEach((hf) => {
      if (hf && hf.rel) {
        const normRel = hf.rel.replace(/\\/g, '/').replace(/^\/+/, '');
        let subRel = normRel;
        if (subRel.toLowerCase().startsWith(phoneFolder.toLowerCase() + '/')) {
          subRel = subRel.slice(phoneFolder.length + 1);
        } else if (subRel.toLowerCase().startsWith('shared/' + phoneFolder.toLowerCase() + '/')) {
          subRel = subRel.slice(('shared/' + phoneFolder).length + 1);
        }
        const parts = subRel.split('/');
        const fileName = (parts.pop() || '').toLowerCase();
        const fld = parts.length ? parts[0] : '';
        if (fileName) {
          if (!hostMapByName.has(fileName)) hostMapByName.set(fileName, []);
          hostMapByName.get(fileName).push({ ...hf, normRel, folderName: fld });
        }
        if (fld) {
          folderFileCounts.set(fld, (folderFileCounts.get(fld) || 0) + 1);
        }
      }
    });

    const MAX_PER_FOLDER = 200;
    let currentChunkIdx = 1;
    while (true) {
      const count = folderFileCounts.get(`${folderBaseName}_${currentChunkIdx}`) || 0;
      if (count < MAX_PER_FOLDER) break;
      currentChunkIdx++;
    }

    function getNextAvailableFolder() {
      while (true) {
        const folder = `${folderBaseName}_${currentChunkIdx}`;
        const count = folderFileCounts.get(folder) || 0;
        if (count < MAX_PER_FOLDER) {
          folderFileCounts.set(folder, count + 1);
          return folder;
        }
        currentChunkIdx++;
      }
    }

    let skipped = 0;
    let fresh = 0;
    const freshQueue = [];

    files.forEach((f) => {
      const fileName = f.name || f.rel.split('/').pop() || '';
      const name = fileName.toLowerCase();
      const fSize = f.size || 0;

      // Chống trùng lặp theo tên và kích thước
      const existNames = hostMapByName.get(name);
      if (existNames && existNames.some(x => x.size === fSize || Math.abs((x.size || 0) - fSize) < 100)) {
        skipped++;
        return;
      }

      const targetFolder = getNextAvailableFolder();
      const targetRel = targetFolder + '/' + fileName;

      freshQueue.push({
        p: f.p,
        rel: targetRel,
        size: fSize,
        mtime: f.mtime || 0,
        pool: hp.id,
        phoneFolder,
        sharePrefix: ''
      });
      fresh++;
    });

    const isFldRel = (rel) => !/^Camera(_\d+)?\//i.test(rel);
    const nonFldItems = syncUpQueue.filter(q => !isFldRel(q.rel));
    syncUpQueue = nonFldItems.concat(freshQueue);

    if (!fresh) {
      if (skipped > 0) {
        DC.toast('Đồng bộ thư mục: Tất cả ' + skipped + ' tệp đã có trên máy chủ (Bỏ qua, không tải lại).');
      } else {
        DC.toast('Mọi tệp trong thư mục đã được đồng bộ lên máy chủ.');
      }
      renderSyncSafe();
      return;
    }

    syncPaused = false;
    if (skipped > 0) {
      DC.toast('Đồng bộ: Đã quét ' + files.length + ' tệp (' + skipped + ' có sẵn - Bỏ qua). Đang gửi ' + fresh + ' tệp mới (chia nhỏ ≤ 200 tệp/folder)…');
    } else {
      DC.toast('Đồng bộ: Đang gửi ' + fresh + ' tệp mới lên máy chủ (tối đa 200 tệp/folder)…');
    }
    runSyncUpQueue();
    renderSyncSafe();
  } catch (e) {
    DC.toast(errText(e));
  }
}

async function syncCameraNow(isAuto) {
  if (!server || !token) { if (!isAuto) DC.toast('Chưa kết nối máy chủ.'); return; }
  try {
    const st = await callNative('localFsStatus', '');
    if (!st || !st.ok) {
      if (!isAuto) DC.toast('Chưa có quyền truy cập bộ nhớ máy. Vào tab "Thiết bị này" để cấp quyền.');
      return;
    }
    const hp = await hostPool();
    if (!hp) { if (!isAuto) DC.toast('Không thấy ổ đĩa nào khả dụng trên máy chủ.'); return; }
    if (!localRootPath) await ensureLocalRootPath();
    const root = localRootPath || '/storage/emulated/0';
    if (!isAuto) DC.toast('Đang quét và tính toán ảnh cần đồng bộ…');
    const d = await callNative('localFsDeepList', JSON.stringify({ path: root + '/DCIM/Camera', limit: 20000 }));
    const files = (d && d.files) || [];
    if (!files.length) { if (!isAuto) DC.toast('Thư mục ảnh Camera đang trống.'); return; }
    const phoneFolder = phoneName();

    let hostFiles = [];
    const hostPoolsToQuery = [hp.id, 'shared'].filter((v, i, a) => v && a.indexOf(v) === i);
    for (const pId of hostPoolsToQuery) {
      for (const pPath of [phoneFolder, 'shared/' + phoneFolder]) {
        try {
          const hRes = await api('/api/files/deep?path=' + enc(pPath) + '&pool=' + enc(pId));
          if (hRes && hRes.files && hRes.files.length) {
            hostFiles = hostFiles.concat(hRes.files);
          }
        } catch (e) {}
      }
    }

    const hostMapByName = new Map();
    const folderFileCounts = new Map();

    hostFiles.forEach((hf) => {
      if (hf && hf.rel) {
        const normRel = hf.rel.replace(/\\/g, '/').replace(/^\/+/, '');
        let subRel = normRel;
        if (subRel.toLowerCase().startsWith(phoneFolder.toLowerCase() + '/')) {
          subRel = subRel.slice(phoneFolder.length + 1);
        } else if (subRel.toLowerCase().startsWith('shared/' + phoneFolder.toLowerCase() + '/')) {
          subRel = subRel.slice(('shared/' + phoneFolder).length + 1);
        }
        const parts = subRel.split('/');
        const fileName = (parts.pop() || '').toLowerCase();
        const folderName = parts.length ? parts[0] : '';

        if (fileName) {
          if (!hostMapByName.has(fileName)) hostMapByName.set(fileName, []);
          hostMapByName.get(fileName).push({ ...hf, normRel, folderName });
        }

        if (folderName) {
          folderFileCounts.set(folderName, (folderFileCounts.get(folderName) || 0) + 1);
        }
      }
    });

    const MAX_PER_FOLDER = 200;
    let currentChunkIdx = 1;
    while (true) {
      const count = folderFileCounts.get(`Camera_${currentChunkIdx}`) || 0;
      if (count < MAX_PER_FOLDER) break;
      currentChunkIdx++;
    }

    function getNextAvailableCameraFolder() {
      while (true) {
        const folder = `Camera_${currentChunkIdx}`;
        const count = folderFileCounts.get(folder) || 0;
        if (count < MAX_PER_FOLDER) {
          folderFileCounts.set(folder, count + 1);
          return folder;
        }
        currentChunkIdx++;
      }
    }

    let skipped = 0;
    let fresh = 0;
    const freshCamQueue = [];

    files.forEach((f) => {
      const fileName = f.name || f.rel.split('/').pop() || '';
      const name = fileName.toLowerCase();
      const fSize = f.size || 0;

      const existNames = hostMapByName.get(name);
      if (existNames && existNames.some(x => x.size === fSize || Math.abs((x.size || 0) - fSize) < 100)) {
        skipped++;
        return;
      }

      const targetFolder = getNextAvailableCameraFolder();
      const targetRel = targetFolder + '/' + fileName;

      freshCamQueue.push({
        p: f.p,
        rel: targetRel,
        size: fSize,
        mtime: f.mtime || 0,
        pool: hp.id,
        phoneFolder,
        sharePrefix: ''
      });
      fresh++;
    });

    const isCamRel = (rel) => /^Camera(_\d+)?\//i.test(rel);
    const nonCamItems = syncUpQueue.filter(q => !isCamRel(q.rel));
    const activeCam = syncUpQueue.length && syncUpBusy && isCamRel(syncUpQueue[0].rel) ? syncUpQueue[0] : null;
    if (activeCam) {
      syncUpQueue = nonCamItems.concat([activeCam]).concat(freshCamQueue.filter(q => q.rel !== activeCam.rel));
    } else {
      syncUpQueue = nonCamItems.concat(freshCamQueue);
    }

    if (!fresh) {
      if (!isAuto) {
        if (skipped > 0) {
          DC.toast('Camera: Tất cả ' + skipped + ' ảnh đã có trên máy chủ (Bỏ qua, không tải lại).');
        } else {
          DC.toast('Mọi ảnh trong Camera đã được đồng bộ lên máy chủ.');
        }
      }
      renderSyncSafe();
      return;
    }

    syncPaused = false;
    if (skipped > 0) {
      DC.toast('Camera: Đã quét ' + files.length + ' ảnh (' + skipped + ' có sẵn - Bỏ qua). Đang gửi ' + fresh + ' ảnh mới (chia nhỏ ≤ 200 ảnh/folder)…');
    } else {
      DC.toast('Camera: Đang gửi ' + fresh + ' ảnh mới lên máy chủ (tối đa 200 ảnh/folder)…');
    }
    runSyncUpQueue();
    renderSyncSafe();
  } catch (e) {
    if (!isAuto) DC.toast(errText(e));
  }
}

function clearSyncUpWatchdog() {
  if (syncUpWatchdog) { clearTimeout(syncUpWatchdog); syncUpWatchdog = null; }
}

function resetSyncUpWatchdog() {
  clearSyncUpWatchdog();
  syncUpWatchdog = setTimeout(() => {
    if (syncUpBusy && syncUpQueue.length > 0) {
      console.warn('Sync upload watchdog triggered: skipping stalled item');
      const stalled = syncUpQueue.shift();
      if (stalled) {
        const key = 'up:sync:' + stalled.rel + ':' + (stalled.pool || '');
        const t = transfers[key];
        if (t && t.id) callNative('cancel', t.id).catch(() => {});
      }
      syncUpBusy = false;
      setTimeout(runSyncUpQueue, 200);
    }
  }, 35000);
}

function runSyncUpQueue() {
  if (syncUpBusy || syncPaused) { renderSyncSafe(); return; }
  const next = syncUpQueue[0];
  if (!next) { clearSyncUpWatchdog(); renderSyncSafe(); return; }
  syncUpBusy = true;
  resetSyncUpWatchdog();
  const key = 'up:sync:' + next.rel + ':' + (next.pool || '');
  const relFull = (next.sharePrefix || '') + next.phoneFolder + '/' + next.rel;
  const nm = next.rel.split('/').pop();
  transfers[key] = { key, id: key, dir: 'up', name: nm, rel: relFull, pool: next.pool || pool, status: 'active', done: 0, total: next.size || 0, speed: 0, spec: { file: next.p, syncUp: true } };
  callNative('upload', JSON.stringify({ id: key, baseUrl: server.baseUrl, token, pool: next.pool || pool, path: relFull, name: nm, file: next.p }))
    .then((res) => { if (res && res.id) transfers[key].id = res.id; savePendingUps(); })
    .catch(() => {
      clearSyncUpWatchdog();
      transfers[key].status = 'error';
      syncUpBusy = false;
      syncUpQueue.shift();
      setTimeout(runSyncUpQueue, 300);
    });
  renderSyncSafe();
}

function bumpSyncUpIfMatch(t) {
  if (!t || !t.spec || !t.spec.syncUp) return false;
  clearSyncUpWatchdog();
  const q = syncUpQueue[0];
  if (q) {
    const key = 'up:sync:' + q.rel + ':' + (q.pool || '');
    const nm = q.rel.split('/').pop();
    if (t.key === key || t.id === key || t.name === nm || (t.spec && t.spec.file === q.p)) {
      if (t.status === 'done' || t.status === 'error') {
        if (t.status === 'done') {
          syncDbUp[q.rel] = { size: q.size || t.total, mtime: q.mtime || 0 };
          saveSyncDbUp();
        }
        syncUpQueue.shift();
        syncUpBusy = false;
        setTimeout(runSyncUpQueue, 50);
        return true;
      }
    }
  }
  return false;
}

function renderSyncSafe() { if (currentView === 'sync') renderSync(); }

async function renderSync() {
  try {
    const raw = await callNative('cameraBackupStats', '');
    const data = typeof raw === 'string' ? JSON.parse(raw || '{}') : (raw || {});
    const backed = data.backed || 0;
    const pending = data.pending || 0;
    const total = data.total || (backed + pending);
    const devName = data.deviceName || 'iPhone';

    const backedEl = document.getElementById('camBackedCount');
    if (backedEl) backedEl.textContent = backed.toLocaleString('vi-VN');
    const pendingEl = document.getElementById('camPendingCount');
    if (pendingEl) pendingEl.textContent = pending.toLocaleString('vi-VN');

    const devInput = document.getElementById('camDeviceNameInput');
    const savedName = localStorage.getItem('cw_cam_device_name');
    const currentDev = savedName || devName;
    if (devInput) {
      if (!devInput.value || devInput.value === 'iPhone') {
        devInput.value = currentDev;
      }
      if (!devInput.dataset.wired) {
        devInput.dataset.wired = '1';
        devInput.addEventListener('input', () => {
          const val = devInput.value.trim() || devName;
          localStorage.setItem('cw_cam_device_name', val);
          const structEl = document.getElementById('camTargetStructure');
          if (structEl) structEl.textContent = 'Ổ E:\\ ' + val + ' \\ Camera_1 (200 tệp / thư mục)';
        });
      }
    }

    const structEl = document.getElementById('camTargetStructure');
    if (structEl) structEl.textContent = 'Ổ E:\\ ' + (devInput ? (devInput.value.trim() || currentDev) : currentDev) + ' \\ Camera_1 (200 tệp / thư mục)';

    const sTitle = document.getElementById('camStatusTitle');
    const sSub = document.getElementById('camStatusSub');
    if (pending === 0 && total > 0) {
      if (sTitle) sTitle.textContent = 'Camera đã được sao lưu đầy đủ';
      if (sSub) sSub.textContent = 'Toàn bộ ' + total + ' ảnh & video đã được bảo vệ an toàn trên máy chủ.';
    } else {
      if (sTitle) sTitle.textContent = 'Sao lưu Ảnh & Video Camera';
      if (sSub) sSub.textContent = pending ? 'Có ' + pending + ' ảnh/video mới chưa sao lưu lên máy chủ.' : 'Tự động gom 200 ảnh/video vào 1 thư mục, bỏ qua ảnh trùng lặp.';
    }
  } catch (err) {
    console.log('Camera stats error:', err);
  }
}

// Global Camera Progress Bridge Handler
window.DC = window.DC || {};
window.DC._onCameraProgress = function(current, total, filename, part, percent) {
  const bar = document.getElementById('camProgressBar');
  if (bar) bar.style.width = Math.min(100, Math.max(0, percent)) + '%';

  const curFile = document.getElementById('camCurFile');
  if (curFile) {
    curFile.textContent = percent >= 100 ? 'Đã hoàn tất sao lưu!' : 'Đang tải: ' + filename + (part ? ' · ' + part : '') + ' (' + current + '/' + total + ')';
  }

  const backedEl = document.getElementById('camBackedCount');
  if (backedEl) backedEl.textContent = current.toLocaleString('vi-VN');
  const pendingEl = document.getElementById('camPendingCount');
  if (pendingEl) pendingEl.textContent = Math.max(0, total - current).toLocaleString('vi-VN');

  if (percent >= 100) {
    const sTitle = document.getElementById('camStatusTitle');
    if (sTitle) sTitle.textContent = 'Đã sao lưu toàn bộ Camera!';
    const sSub = document.getElementById('camStatusSub');
    if (sSub) sSub.textContent = 'Toàn bộ ảnh & video đã được gom nhóm 200 tệp/folder an toàn trên máy chủ.';
    const startBtn = document.getElementById('camStartBtn');
    if (startBtn) startBtn.style.display = 'inline-block';
    const pauseBtn = document.getElementById('camPauseBtn');
    if (pauseBtn) pauseBtn.style.display = 'none';
  }
};

document.addEventListener('DOMContentLoaded', () => {
  const startBtn = document.getElementById('camStartBtn');
  if (startBtn) {
    startBtn.onclick = async () => {
      const vidToggle = document.getElementById('camVideoToggle');
      const wifiToggle = document.getElementById('camWifiOnlyToggle');
      const devInput = document.getElementById('camDeviceNameInput');
      const includeVideos = vidToggle ? vidToggle.checked : true;
      const wifiOnly = wifiToggle ? wifiToggle.checked : true;
      const customDeviceName = (devInput ? devInput.value : '').trim();

      startBtn.style.display = 'none';
      const pauseBtn = document.getElementById('camPauseBtn');
      if (pauseBtn) pauseBtn.style.display = 'inline-block';

      const sTitle = document.getElementById('camStatusTitle');
      if (sTitle) sTitle.textContent = 'Đang sao lưu ảnh & video...';
      const sSub = document.getElementById('camStatusSub');
      if (sSub) sSub.textContent = 'Đang quét và truyền tải các mục mới lên máy chủ Host.';

      try {
        await callNative('startCameraBackup', JSON.stringify({
          includeVideos,
          wifiOnly,
          customDeviceName,
          baseUrl: server ? server.baseUrl : '',
          pool: pool || '',
          token: token || ''
        }));
      } catch (e) {
        DC.toast(errText(e));
        startBtn.style.display = 'inline-block';
        if (pauseBtn) pauseBtn.style.display = 'none';
      }
    };
  }

  const pauseBtn = document.getElementById('camPauseBtn');
  if (pauseBtn) {
    pauseBtn.onclick = async () => {
      await callNative('pauseCameraBackup', '');
      const sStart = document.getElementById('camStartBtn');
      if (sStart) sStart.style.display = 'inline-block';
      pauseBtn.style.display = 'none';
      const sTitle = document.getElementById('camStatusTitle');
      if (sTitle) sTitle.textContent = 'Đã tạm dừng sao lưu';
    };
  }
});

function kSyncDest() { return 'syncDest:' + (server ? server.baseUrl : ''); }

function loadSyncDest() {
  syncDest = kvGet(kSyncDest()) || null;
  syncSrc = kvGet(kSyncSrc()) || null;
  syncDbUp = kvGet(kSyncDbUp()) || {};
}

function saveSyncDest() { kvSet(kSyncDest(), syncDest); }
function saveSyncSrc() { kvSet(kSyncSrc(), syncSrc); }
function saveSyncDbUp() { kvSet(kSyncDbUp(), syncDbUp); }

function destLabelOf(d) {
  if (!d) return '';
  if (d.path) return d.name || d.path;
  if (d.treeUri) return d.name || 'Thư mục đã chọn';
  return '';
}

function syncDestLabel() {
  if (syncDest && (syncDest.path || syncDest.treeUri)) return destLabelOf(syncDest);
  return 'Downloads/CW-Datacenter (mặc định)';
}

function downloadDestLabel() {
  if (syncDest && (syncDest.path || syncDest.treeUri)) return destLabelOf(syncDest);
  return 'Downloads/CW-Datacenter';
}

function syncSrcLabel() {
  if (syncSrc && syncSrc.path) return destLabelOf(syncSrc);
  return 'Chưa chọn';
}

/* Spec lưu file tải về: ưu tiên thư mục trên máy (path) -> SAF tree -> mặc định Downloads/CW-Datacenter */
function destSpecFor(rel, manual) {
  const spec = { sync: !manual };
  if (syncDest && syncDest.path) {
    spec.destPath = syncDest.path;
    if (!manual) {
      const i = rel.lastIndexOf('/');
      spec.destSub = i >= 0 ? rel.slice(0, i) : '';
    }
    return spec;
  }
  if (syncDest && syncDest.treeUri) {
    spec.destTreeUri = syncDest.treeUri;
    if (!manual) {
      const i = rel.lastIndexOf('/');
      spec.destSub = i >= 0 ? rel.slice(0, i) : '';
    }
  }
  return spec;
}

/* Chọn thư mục (nơi tải về / nguồn đồng bộ) ngay trong app, tab "Thiết bị này":
 * chuyển sang tab Tệp, mở ổ Thiết bị này và chờ người dùng duyệt tới thư mục rồi bấm chọn. */
let pickNavCtx = null; // {kind:'syncDest'|'syncSrc'|'dest', onPick}

function ensureLocalReady() {
  if (localRootPath) return Promise.resolve(true);
  return callNative('localFsStatus', '').then(async (st) => {
    if (!st || !st.ok) {
      await callNative('requestLocalFsAccess', '');
      DC.toast('Sau khi cấp quyền, quay lại đây và bấm nút chọn lần nữa.');
      return false;
    }
    const info = await callNative('localFsInfo', '');
    localRootPath = (info && info.rootPath) || '/storage/emulated/0';
    localDrive = { fs: true, name: 'Thiết bị này' };
    return true;
  }).catch(() => false);
}

function enterLocalPick(kind) {
  const title = kind === 'syncSrc' ? 'Chọn thư mục ĐỒNG BỘ (nguồn trên máy này)' : 'Chọn nơi lưu file tải về';
  ensureLocalReady().then((ok) => {
    if (!ok) return;
    pickNavCtx = { kind };
    $$('.nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.target === 'files'));
    go('files');
    if (pool !== LOCAL_POOL) { pool = LOCAL_POOL; localNav = []; renderPoolBar(); }
    if (!localNav.length) localNav = [{ path: localRootPath, name: 'Bộ nhớ trong' }];
    loadLocalFiles();
    DC.toast(title + ' — duyệt tới thư mục rồi bấm "Chọn thư mục này".');
    updateLocalPickBar();
  });
}

function updateLocalPickBar() {
  const bar = document.getElementById('localPickBar') || (() => {
    const d = document.createElement('div');
    d.id = 'localPickBar';
    d.style.cssText = 'display:none;gap:8px;padding:8px 14px 0;flex-wrap:wrap';
    const sel = document.createElement('button');
    sel.className = 'pill blue';
    sel.style.cssText = 'border:0;background:var(--blue);color:#fff;padding:9px 14px;font-size:12.5px;border-radius:999px;cursor:pointer';
    sel.textContent = '✓ Chọn thư mục này';
    sel.addEventListener('click', () => {
      if (!pickNavCtx) return;
      const cur = localNav.length ? localNav[localNav.length - 1].path : localRootPath;
      const nameSegs = localNav.slice(1).map((s) => s.name);
      const nm = nameSegs.join('/') || 'Bộ nhớ trong';
      applyLocalPick(pickNavCtx.kind, cur, nm);
      pickNavCtx = null;
      updateLocalPickBar();
    });
    const cancel = document.createElement('button');
    cancel.className = 'pill gray';
    cancel.style.cssText = 'border:0;background:#f5f7fa;color:#667085;padding:9px 14px;font-size:12.5px;border-radius:999px;cursor:pointer';
    cancel.textContent = 'Hủy';
    cancel.addEventListener('click', () => { pickNavCtx = null; updateLocalPickBar(); DC.toast('Đã hủy chọn thư mục.'); });
    d.appendChild(sel);
    d.appendChild(cancel);
    const filesSec = $('#files');
    const head = filesSec.querySelector('.app-head');
    head.after(d);
    return d;
  })();
  bar.style.display = pickNavCtx ? 'flex' : 'none';
}

function applyLocalPick(kind, path, name) {
  if (kind === 'syncDest' || kind === 'dest') {
    syncDest = { path, name };
    saveSyncDest();
    DC.toast('File tải về sẽ lưu vào: ' + name);
    hostPoolCache = null;
  } else if (kind === 'syncSrc') {
    syncSrc = { path, name };
    saveSyncSrc();
    DC.toast('Thư mục đồng bộ: ' + name + ' — chỉ đẩy file từ máy này lên máy chủ (1 chiều).');
  }
  if (currentView === 'sync') renderSync();
}

async function chooseSyncFolder() {
  enterLocalPick('syncDest');
}

async function chooseSyncSrcFolder() {
  enterLocalPick('syncSrc');
}

function clearSyncFolder() {
  syncDest = null;
  saveSyncDest();
  DC.toast('Dùng thư mục mặc định Downloads/CW-Datacenter');
  if (currentView === 'sync') renderSync();
}

/* Mở thư mục tải về / đồng bộ ngay trong app tại tab "Thiết bị này" (không mở app ngoài). */
async function openDownloadFolder() {
  const root = await ensureLocalRootPath();
  if (!root) return;
  let targetPath = null;
  if (syncDest && syncDest.path) {
    targetPath = syncDest.path;
  } else if (syncDest && syncDest.treeUri) {
    targetPath = root + '/Download/CW-Datacenter';
  } else {
    targetPath = root + '/Download/CW-Datacenter';
  }
  openLocalFolderInFiles(targetPath);
}

async function ensureLocalRootPath() {
  if (!localRootPath) {
    try {
      const info = await callNative('localFsInfo', '');
      localRootPath = (info && info.rootPath) || '/storage/emulated/0';
    } catch (e) { localRootPath = '/storage/emulated/0'; }
  }
  return localRootPath;
}

function openLocalFolderInFiles(path) {
  const root = localRootPath || '/storage/emulated/0';
  const rel = path.startsWith(root) ? path.slice(root.length).replace(/^\/+/, '') : '';
  const segs = rel ? rel.split('/').filter(Boolean) : [];
  /* Tạo sẵn thư mục để khi mở tab Thiết bị này là thấy ngay */
  try { callNative('localFsEnsure', JSON.stringify({ path })).catch(() => {}); } catch (e) {}
  localNav = [{ path: root, name: 'Bộ nhớ trong' }];
  let acc = root;
  for (const s of segs) { acc = acc + '/' + s; localNav.push({ path: acc, name: s }); }
  $$('.nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.target === 'files'));
  go('files');
  if (pool !== LOCAL_POOL) { pool = LOCAL_POOL; renderPoolBar(); }
  loadLocalFiles();
}

/* ---------- TRASH ---------- */
let trashItems = [];
async function loadTrash() {
  try {
    const d = await api('/api/trash');
    trashItems = d.items || [];
    renderTrash();
  } catch (e) { DC.toast(errText(e)); }
}

function renderTrash() {
  const stats = $$('#trash .stat-value');
  if (stats[0]) stats[0].textContent = String(trashItems.length);
  const total = trashItems.reduce((a, b) => a + (b.size || 0), 0);
  if (stats[1]) stats[1].textContent = fmtBytes(total) || '0 B';
  const list = $('#trash .list-card');
  list.innerHTML = '';
  if (!trashItems.length) {
    list.innerHTML = '<div class="empty">Thùng rác trống.</div>';
    return;
  }
  trashItems.forEach((it) => {
    const icon = it.type === 'dir' ? { sym: 'i-folder', color: 'var(--yellow)' } : fileIcon(it.name);
    const row = document.createElement('div');
    row.className = 'trash-row';
    row.innerHTML =
      '<div style="color:' + icon.color + '">' + iconSvg(icon.sym) + '</div>' +
      '<div><div class="card-title">' + esc(it.name) + '</div><div class="meta2">Đã xóa ' + esc(fmtAgo(it.deletedAt)) + (it.size ? ' · ' + fmtBytes(it.size) : '') + '</div></div>' +
      '<div class="pill red">Khôi phục</div>';
    row.querySelector('.pill').addEventListener('click', async (e) => {
      e.stopPropagation();
      try { await api('/api/trash/restore', 'POST', { id: it.id }); DC.toast('Đã khôi phục "' + it.name + '"'); loadTrash(); }
      catch (er) { DC.toast(errText(er)); }
    });
    list.appendChild(row);
  });
}

$$('#trash .small-btn').forEach((b, i) => b.addEventListener('click', () => {
  if (i === 0) { DC.toast('Bấm "Khôi phục" trên từng mục để lấy lại.'); }
  else {
    if (!trashItems.length) { DC.toast('Thùng rác đang trống'); return; }
    sheetConfirm('Dọn sạch thùng rác', 'Xóa vĩnh viễn toàn bộ ' + trashItems.length + ' mục? Không thể hoàn tác.', 'Xóa tất cả', async () => {
      try { await api('/api/trash/purge', 'POST', {}); DC.toast('Đã dọn sạch thùng rác'); loadTrash(); }
      catch (er) { DC.toast(errText(er)); }
    });
  }
}));
$('#trash .section-head .text-btn').addEventListener('click', () => DC.toast('Mục mới xóa luôn nằm trên cùng.'));
$('#transfers .head-row > span').addEventListener('click', () => {
  openSheet('Truyền tải', (body) => {
    const all = Object.values(transfers);
    const errs = all.filter((t) => t.status === 'error');
    if (errs.length) {
      sheetItem(body, 'Xóa mục lỗi khỏi danh sách (' + errs.length + ')', {
        icon: 'i-trash',
        onClick: () => {
          errs.forEach((t) => delete transfers[t.key]);
          renderTransfers();
          DC.toast('Đã xóa ' + errs.length + ' mục lỗi');
        }
      });
    }
    if (all.length) {
      sheetItem(body, 'Xóa toàn bộ danh sách (' + all.length + ')', {
        icon: 'i-trash',
        danger: true,
        onClick: () => {
          Object.keys(transfers).forEach((k) => delete transfers[k]);
          savePendingUps();
          savePendingDls();
          renderTransfers();
          DC.toast('Đã xóa toàn bộ danh sách truyền tải');
        }
      });
    }
    sheetItem(body, 'Đóng', { onClick: () => {} });
  });
});

const vrResumeBtn = document.getElementById('vrResumeBtn');
if (vrResumeBtn) {
  vrResumeBtn.addEventListener('click', () => {
    if (!pendingResumeVideo) return;
    const { e, rel, p, plIdx, playlist, pos } = pendingResumeVideo;
    closeVideoResumeModal();
    launchMobileVideo(e, rel, p, plIdx, playlist, pos);
  });
}

const vrRestartBtn = document.getElementById('vrRestartBtn');
if (vrRestartBtn) {
  vrRestartBtn.addEventListener('click', () => {
    if (!pendingResumeVideo) return;
    const { e, rel, p, plIdx, playlist } = pendingResumeVideo;
    closeVideoResumeModal();
    launchMobileVideo(e, rel, p, plIdx, playlist, 0);
  });
}

const vrCancelBtn = document.getElementById('vrCancelBtn');
if (vrCancelBtn) {
  vrCancelBtn.addEventListener('click', closeVideoResumeModal);
}

/* ---------- BOOT ---------- */
async function boot() {
  const last = kvGet('last');
  if (last && last.baseUrl) {
    try {
      const tk = kvGet('token:' + last.baseUrl);
      if (tk) {
        const d = await tryApi(last.baseUrl, '/api/me', 'GET', null, tk);
        server = last;
        token = tk;
        me = { role: d.role || 'admin', user: d.user || 'admin' };
        $('#signHost').textContent = server.name;
        $('#signIp').textContent = server.ip;
        fillTrust();
        const trusted = DC.loadKV(kTrust());
        if (trusted === '1') { enterMain(); return; }
        go('trust');
        return;
      }
    } catch (e) {}
  }
  go('discover');
  runDiscover();
}

function rememberLast() {
  if (server) kvSet('last', { baseUrl: server.baseUrl, ip: server.ip, port: server.port, host: server.host, name: server.name, via: server.via });
}
const _enterMain = enterMain;
enterMain = function () { rememberLast(); _enterMain(); };

const origSelectServer = selectServer;

boot();
})();
