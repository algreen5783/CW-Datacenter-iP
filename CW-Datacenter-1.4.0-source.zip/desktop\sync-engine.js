'use strict';
/* Sync engine: Đồng bộ 2 chiều (Bidirectional Sync) hoặc 1 chiều giữa Desktop Client và Host PC.
 * - Tự động upload file mới / sửa đổi từ Client lên Host.
 * - Tự động download file mới / sửa đổi từ Host về Client.
 * - Tự động phát hiện và phản chiếu ĐỔI TÊN (Rename) tức thì trên cả Client và Host.
 * - Tự động xóa file 2 chiều khi một bên xóa.
 * - Chống lặp vô tận (Loop prevention) với in-flight lock và khớp mtime.
 * - Xử lý xung đột (Conflict resolution) an toàn, không bao giờ mất dữ liệu.
 */
const path = require('path');
const fs = require('fs');
const fsp = fs.promises;
const crypto = require('crypto');
const { Readable } = require('stream');
const { pipeline } = require('stream/promises');

function makeEngine({ syncFile, notify }) {
  let cfgs = [];
  let authToken = '';
  let serverOrigin = '';
  const pendingCheck = new Map();
  const watchers = new Map();
  const inFlight = new Set(); // Key: cfgId|rel - Chống loop khi download/xóa cục bộ

  function load() {
    try {
      cfgs = fs.existsSync(syncFile) ? JSON.parse(fs.readFileSync(syncFile, 'utf8')) : [];
    } catch { cfgs = []; }
    let changed = false;
    for (const c of cfgs) {
      c.status = c.status === 'busy' ? 'idle' : (c.status || 'idle');
      if (c.twoWay == null || c.twoWay === false) {
        c.twoWay = true;
        changed = true;
      }
      if (c.remote) {
        c.remote = '';
        changed = true;
      }
    }
    if (changed) save();
  }

  function save() {
    try { fs.writeFileSync(syncFile, JSON.stringify(cfgs, null, 2)); } catch {}
  }

  function setAuth(token, origin) {
    authToken = String(token || '');
    serverOrigin = String(origin || '').replace(/\/$/, '');
  }

  function emit() {
    if (notify) {
      try { notify(listPublic()); } catch {}
    }
  }

  function isIgnored(name) {
    if (!name) return true;
    if (name.startsWith('.') || /^(thumbs\.db|desktop\.ini|\.ds_store)$/i.test(name)) return true;
    if (/^~\$/i.test(name)) return true; // MS Office lock files
    if (/\.(cwtmp|part|tmp|download|crdownload|partial)$/i.test(name)) return true;
    return false;
  }

  function walkLocal(dir, rel) {
    let out = [];
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
    for (const e of entries) {
      if (isIgnored(e.name)) continue;
      const p = path.join(dir, e.name);
      const r = rel ? rel + '/' + e.name : e.name;
      try {
        if (e.isDirectory() && !e.isSymbolicLink()) {
          out = out.concat(walkLocal(p, r));
        } else if (e.isFile() && !e.isSymbolicLink()) {
          const st = fs.statSync(p);
          out.push({ rel: r.split('\\').join('/'), abs: p, size: st.size, mtime: Math.round(st.mtimeMs) });
        }
      } catch {}
    }
    return out;
  }

  async function apiCall(method, apiPath, body) {
    if (!authToken || !serverOrigin) throw new Error('Chưa đăng nhập vào máy chủ.');
    const opts = { method, headers: { Authorization: 'Bearer ' + authToken } };
    if (body != null) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
    const res = await fetch(serverOrigin + apiPath, opts);
    if (res.status === 401) throw new Error('Phiên hết hạn — hãy đăng nhập lại trong app.');
    if (!res.ok) {
      let msg = 'Lỗi ' + res.status;
      try { msg = ((await res.json()).error) || msg; } catch {}
      throw new Error(msg);
    }
    return res.json().catch(() => ({}));
  }

  async function fetchRemoteDeep(cfg) {
    const root = remoteRoot(cfg);
    const qs = '?path=' + encodeURIComponent(root) + (cfg.pool ? '&pool=' + encodeURIComponent(cfg.pool) : '');
    try {
      const res = await apiCall('GET', '/api/files/deep' + qs);
      const list = (res && Array.isArray(res.files)) ? res.files : [];
      return list.filter((f) => !isIgnored(path.basename(f.rel || ''))).map((f) => ({
        rel: String(f.rel || '').replace(/\\/g, '/').replace(/^\/+/, ''),
        size: Number(f.size || 0),
        mtime: Math.round(f.mtime || 0),
      }));
    } catch (err) {
      if (err.message && /không tìm thấy|không tồn tại/i.test(err.message)) return [];
      throw err;
    }
  }

  async function uploadFile(abs, remotePath, poolId) {
    if (!authToken || !serverOrigin) throw new Error('Chưa đăng nhập vào máy chủ.');
    const qs = poolId ? '&pool=' + encodeURIComponent(poolId) : '';
    const fileStream = fs.createReadStream(abs);
    fileStream.on('error', () => {});
    const res = await fetch(serverOrigin + '/api/file?path=' + encodeURIComponent(remotePath) + qs, {
      method: 'PUT',
      headers: { Authorization: 'Bearer ' + authToken },
      body: Readable.toWeb(fileStream),
      duplex: 'half',
    });
    if (!res.ok) {
      let msg = 'Lỗi ' + res.status;
      try { msg = ((await res.json()).error) || msg; } catch {}
      if (res.status === 401) msg = 'Phiên hết hạn — hãy đăng nhập lại trong app.';
      throw new Error(msg);
    }
    return res.json().catch(() => ({}));
  }

  async function downloadFile(remotePath, poolId, localAbs, remoteMtime) {
    if (!authToken || !serverOrigin) throw new Error('Chưa đăng nhập vào máy chủ.');
    const qs = poolId ? '&pool=' + encodeURIComponent(poolId) : '';
    const res = await fetch(serverOrigin + '/api/file?path=' + encodeURIComponent(remotePath) + qs, {
      method: 'GET',
      headers: { Authorization: 'Bearer ' + authToken },
    });
    if (!res.ok) {
      let msg = 'Lỗi ' + res.status;
      try { msg = ((await res.json()).error) || msg; } catch {}
      throw new Error(msg);
    }

    const dir = path.dirname(localAbs);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const tmpPath = localAbs + '.cwtmp.' + Date.now();
    const dest = fs.createWriteStream(tmpPath);
    await pipeline(Readable.fromWeb(res.body), dest);

    try {
      if (fs.existsSync(localAbs)) fs.unlinkSync(localAbs);
      fs.renameSync(tmpPath, localAbs);
      if (remoteMtime && remoteMtime > 0) {
        const d = new Date(remoteMtime);
        fs.utimesSync(localAbs, d, d);
      }
    } catch (e) {
      try { if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath); } catch {}
      throw e;
    }
  }

  async function deleteRemoteFile(remotePath, poolId) {
    const qs = poolId ? '&pool=' + encodeURIComponent(poolId) : '';
    try {
      await apiCall('DELETE', '/api/file?path=' + encodeURIComponent(remotePath) + qs);
    } catch (err) {
      if (err.message && /không tìm thấy|không tồn tại/i.test(err.message)) return;
      throw err;
    }
  }

  async function renameRemoteFile(oldRemotePath, newFilename, poolId) {
    return apiCall('POST', '/api/rename', { path: oldRemotePath, newName: newFilename, pool: poolId });
  }

  function remoteRoot(cfg) {
    return String(cfg.remote || '').split('\\').join('/').replace(/^\/+|\/+$/g, '');
  }

  function remotePathOf(cfg, rel) {
    const r = remoteRoot(cfg);
    return (r ? r + '/' : '') + rel;
  }

  function pushHistory(cfg, dir, rel, size) {
    cfg.history = cfg.history || [];
    cfg.history.unshift({ rel, dir, size: size || 0, time: Date.now() });
    if (cfg.history.length > 60) cfg.history.length = 60;
  }

  /* ---------- Hàm đồng bộ cốt lõi (1 chiều hoặc 2 chiều) ---------- */
  async function syncOne(cfg, force) {
    if (cfg.status === 'busy') {
      cfg._reRun = true;
      return { skipped: true };
    }
    if (!fs.existsSync(cfg.local)) {
      cfg.status = 'err';
      cfg.error = 'Không thấy thư mục trên máy này.';
      save(); emit();
      return { error: cfg.error };
    }

    cfg.status = 'busy';
    cfg.pending = 0;
    cfg._silent = true;
    emit();

    try {
      cfg.manifest = cfg.manifest || {};
      const isTwoWay = cfg.twoWay !== false;
      const root = remoteRoot(cfg);
      if (root) {
        try { await apiCall('POST', '/api/mkdir', { path: root, pool: cfg.pool }); } catch {}
      }

      // 1. Quét tệp cục bộ và tệp từ xa
      const localList = walkLocal(cfg.local, '');
      const localMap = new Map(localList.map((f) => [f.rel, f]));

      let remoteMap = new Map();
      if (isTwoWay) {
        const remoteList = await fetchRemoteDeep(cfg);
        remoteMap = new Map(remoteList.map((f) => [f.rel, f]));
      }

      // 2. TỐI ƯU HÓA ĐỔI TÊN (Rename Detection) TRƯỚC KHI RECONCILE
      if (isTwoWay) {
        // A. Phát hiện đổi tên trên Client (Local có newRel mới, remote & manifest còn oldRel)
        const localNewRels = [...localMap.keys()].filter((r) => !remoteMap.has(r) && !cfg.manifest[r]);
        const localGoneRels = [...remoteMap.keys()].filter((r) => !localMap.has(r) && cfg.manifest[r]);

        for (const newRel of localNewRels) {
          const locItem = localMap.get(newRel);
          // Tìm xem có file cũ cùng thư mục và cùng kích thước không
          const matchIdx = localGoneRels.findIndex((oldRel) => {
            const remItem = remoteMap.get(oldRel);
            return remItem && remItem.size === locItem.size && path.posix.dirname(oldRel) === path.posix.dirname(newRel);
          });
          if (matchIdx >= 0) {
            const oldRel = localGoneRels.splice(matchIdx, 1)[0];
            const remItem = remoteMap.get(oldRel);
            try {
              await renameRemoteFile(remotePathOf(cfg, oldRel), path.posix.basename(newRel), cfg.pool);
              cfg.manifest[newRel] = { size: locItem.size, localMtime: locItem.mtime, remoteMtime: locItem.mtime, mtime: locItem.mtime };
              delete cfg.manifest[oldRel];
              remoteMap.set(newRel, { rel: newRel, size: locItem.size, mtime: locItem.mtime });
              remoteMap.delete(oldRel);
              pushHistory(cfg, 'rename_remote', oldRel + ' ➔ ' + newRel, locItem.size);
            } catch {}
          }
        }

        // B. Phát hiện đổi tên trên Host (Remote có newRel mới, local & manifest còn oldRel)
        const remoteNewRels = [...remoteMap.keys()].filter((r) => !localMap.has(r) && !cfg.manifest[r]);
        const remoteGoneRels = [...localMap.keys()].filter((r) => !remoteMap.has(r) && cfg.manifest[r]);

        for (const newRel of remoteNewRels) {
          const remItem = remoteMap.get(newRel);
          const matchIdx = remoteGoneRels.findIndex((oldRel) => {
            const locItem = localMap.get(oldRel);
            return locItem && locItem.size === remItem.size && path.posix.dirname(oldRel) === path.posix.dirname(newRel);
          });
          if (matchIdx >= 0) {
            const oldRel = remoteGoneRels.splice(matchIdx, 1)[0];
            const oldLocalAbs = path.join(cfg.local, oldRel);
            const newLocalAbs = path.join(cfg.local, newRel);
            const flightKey = cfg.id + '|' + newRel;
            inFlight.add(flightKey);
            try {
              const dir = path.dirname(newLocalAbs);
              if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
              fs.renameSync(oldLocalAbs, newLocalAbs);
              if (remItem.mtime > 0) {
                const d = new Date(remItem.mtime);
                fs.utimesSync(newLocalAbs, d, d);
              }
              const st = fs.statSync(newLocalAbs);
              const mt = Math.round(st.mtimeMs);
              cfg.manifest[newRel] = { size: remItem.size, localMtime: mt, remoteMtime: remItem.mtime, mtime: mt };
              delete cfg.manifest[oldRel];
              localMap.set(newRel, { rel: newRel, abs: newLocalAbs, size: st.size, mtime: mt });
              localMap.delete(oldRel);
              pushHistory(cfg, 'rename_local', oldRel + ' ➔ ' + newRel, remItem.size);
            } catch {} finally {
              setTimeout(() => inFlight.delete(flightKey), 3000);
            }
          }
        }
      }

      // 3. Tập hợp tất cả đường dẫn tệp (Local, Remote, Manifest)
      const allRels = new Set([...localMap.keys(), ...remoteMap.keys(), ...Object.keys(cfg.manifest)]);
      const actions = []; // { type: 'upload'|'download'|'del_remote'|'del_local'|'conflict', rel, localItem, remoteItem }

      for (const rel of allRels) {
        const loc = localMap.get(rel);
        const rem = remoteMap.get(rel);
        const man = cfg.manifest[rel];

        if (loc && rem) {
          // Tệp tồn tại ở CẢ 2 BÊN
          if (!man) {
            // Chưa có bản ghi manifest (khởi tạo ban đầu)
            if (loc.size === rem.size && Math.abs(loc.mtime - rem.mtime) < 2000) {
              cfg.manifest[rel] = { size: loc.size, localMtime: loc.mtime, remoteMtime: rem.mtime };
            } else if (loc.mtime > rem.mtime + 2000) {
              actions.push({ type: 'upload', rel, localItem: loc, remoteItem: rem });
            } else if (rem.mtime > loc.mtime + 2000) {
              actions.push({ type: 'download', rel, localItem: loc, remoteItem: rem });
            } else {
              actions.push({ type: 'upload', rel, localItem: loc, remoteItem: rem });
            }
          } else {
            const locChanged = (loc.size !== man.size || Math.abs(loc.mtime - (man.localMtime || man.mtime || 0)) >= 2000);
            const remChanged = (rem.size !== man.size || Math.abs(rem.mtime - (man.remoteMtime || man.mtime || 0)) >= 2000);

            if (!locChanged && !remChanged) {
              // Cả 2 bên không đổi
              continue;
            } else if (locChanged && !remChanged) {
              // Chỉ sửa ở Client -> Upload
              actions.push({ type: 'upload', rel, localItem: loc, remoteItem: rem });
            } else if (!locChanged && remChanged) {
              // Chỉ sửa ở Host -> Download
              if (isTwoWay) actions.push({ type: 'download', rel, localItem: loc, remoteItem: rem });
            } else {
              // Xung đột: Cả 2 bên cùng sửa!
              if (isTwoWay) actions.push({ type: 'conflict', rel, localItem: loc, remoteItem: rem });
              else actions.push({ type: 'upload', rel, localItem: loc, remoteItem: rem });
            }
          }
        } else if (loc && !rem) {
          // Tệp chỉ có ở LOCAL (Client)
          if (!man) {
            // File mới thêm ở Local -> Upload
            actions.push({ type: 'upload', rel, localItem: loc });
          } else {
            if (isTwoWay) {
              // File đã có trong manifest nhưng biến mất ở Host -> Bị xóa trên Host -> Xóa ở Client
              actions.push({ type: 'del_local', rel, localItem: loc });
            } else {
              // Chế độ 1 chiều: Chỉ upload nếu file local THẬT SỰ thay đổi so với manifest
              const locChanged = (loc.size !== man.size || Math.abs(loc.mtime - (man.localMtime || man.mtime || 0)) >= 2000);
              if (locChanged) actions.push({ type: 'upload', rel, localItem: loc });
            }
          }
        } else if (!loc && rem) {
          // Tệp chỉ có ở REMOTE (Host)
          if (!man) {
            // File mới thêm ở Host -> Download về Client
            if (isTwoWay) actions.push({ type: 'download', rel, remoteItem: rem });
          } else {
            // File đã có trong manifest nhưng biến mất ở Client -> Bị xóa trên Client!
            if (isTwoWay) actions.push({ type: 'del_remote', rel, remoteItem: rem });
            else delete cfg.manifest[rel];
          }
        } else if (!loc && !rem) {
          // Không còn ở cả 2 bên -> dọn manifest
          delete cfg.manifest[rel];
        }
      }

      cfg.pending = actions.length;
      emit();

      let doneUp = 0;
      let doneDown = 0;
      let doneDel = 0;

      for (let i = 0; i < actions.length; i++) {
        const act = actions[i];
        cfg.pending = actions.length - i;
        const flightKey = cfg.id + '|' + act.rel;

        try {
          if (act.type === 'upload') {
            const loc = act.localItem;
            // Kiểm tra tính ổn định trước khi upload (file không bị đang ghi dở)
            if (!force) {
              const seen = pendingCheck.get(flightKey);
              if (!seen || seen.size !== loc.size || seen.mtime !== loc.mtime) {
                pendingCheck.set(flightKey, { size: loc.size, mtime: loc.mtime, t: Date.now() });
                continue;
              }
              if (Date.now() - seen.t < 1800) continue;
            }

            await uploadFile(loc.abs, remotePathOf(cfg, act.rel), cfg.pool);
            const st = await fsp.stat(loc.abs);
            const mt = Math.round(st.mtimeMs);
            cfg.manifest[act.rel] = { size: st.size, localMtime: mt, remoteMtime: mt, mtime: mt };
            pushHistory(cfg, 'up', act.rel, st.size);
            pendingCheck.delete(flightKey);
            doneUp++;
          } else if (act.type === 'download') {
            const rem = act.remoteItem;
            const localAbs = path.join(cfg.local, act.rel);
            inFlight.add(flightKey);
            try {
              await downloadFile(remotePathOf(cfg, act.rel), cfg.pool, localAbs, rem.mtime);
              const st = await fsp.stat(localAbs);
              const mt = Math.round(st.mtimeMs);
              cfg.manifest[act.rel] = { size: rem.size, localMtime: mt, remoteMtime: rem.mtime, mtime: mt };
              pushHistory(cfg, 'down', act.rel, rem.size);
              doneDown++;
            } finally {
              setTimeout(() => inFlight.delete(flightKey), 3000);
            }
          } else if (act.type === 'del_remote') {
            await deleteRemoteFile(remotePathOf(cfg, act.rel), cfg.pool);
            delete cfg.manifest[act.rel];
            pushHistory(cfg, 'del_remote', act.rel, 0);
            doneDel++;
          } else if (act.type === 'del_local') {
            const localAbs = path.join(cfg.local, act.rel);
            inFlight.add(flightKey);
            try {
              if (fs.existsSync(localAbs)) fs.unlinkSync(localAbs);
              delete cfg.manifest[act.rel];
              pushHistory(cfg, 'del_local', act.rel, 0);
              doneDel++;
            } finally {
              setTimeout(() => inFlight.delete(flightKey), 3000);
            }
          } else if (act.type === 'conflict') {
            const loc = act.localItem;
            const rem = act.remoteItem;
            const ext = path.extname(loc.abs);
            const stem = path.basename(loc.abs, ext);
            const timeTag = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);

            if (loc.mtime >= rem.mtime) {
              // Local mới hơn: Lưu bản remote thành conflict copy, giữ local làm bản chính
              const conflictLocalAbs = path.join(path.dirname(loc.abs), `${stem} (Bản sao xung đột Host ${timeTag})${ext}`);
              inFlight.add(flightKey);
              try {
                await downloadFile(remotePathOf(cfg, act.rel), cfg.pool, conflictLocalAbs, rem.mtime);
                await uploadFile(loc.abs, remotePathOf(cfg, act.rel), cfg.pool);
                const st = await fsp.stat(loc.abs);
                const mt = Math.round(st.mtimeMs);
                cfg.manifest[act.rel] = { size: st.size, localMtime: mt, remoteMtime: mt, mtime: mt };
                doneUp++;
              } finally {
                setTimeout(() => inFlight.delete(flightKey), 3000);
              }
            } else {
              // Remote mới hơn: Đổi tên bản local thành conflict copy, download remote làm bản chính
              const conflictLocalAbs = path.join(path.dirname(loc.abs), `${stem} (Bản sao xung đột Client ${timeTag})${ext}`);
              inFlight.add(flightKey);
              try {
                fs.renameSync(loc.abs, conflictLocalAbs);
                await downloadFile(remotePathOf(cfg, act.rel), cfg.pool, loc.abs, rem.mtime);
                const st = await fsp.stat(loc.abs);
                const mt = Math.round(st.mtimeMs);
                cfg.manifest[act.rel] = { size: rem.size, localMtime: mt, remoteMtime: rem.mtime, mtime: mt };
                doneDown++;
              } finally {
                setTimeout(() => inFlight.delete(flightKey), 3000);
              }
            }
          }

          if ((doneUp + doneDown + doneDel) % 3 === 0) {
            save();
            emit();
          }
        } catch (e) {
          cfg.error = act.rel + ': ' + (e.message || e);
          cfg.status = 'err';
          cfg._silent = false;
          save(); emit();
          return { error: cfg.error, done: doneUp + doneDown + doneDel };
        }
      }

      const totalDone = doneUp + doneDown + doneDel;
      cfg.synced = (cfg.synced || 0) + totalDone;
      cfg.lastRun = Date.now();
      if (totalDone || !cfg.error) cfg.error = '';
      cfg.status = 'idle';
      cfg._silent = false;
      save(); emit();

      if (cfg._reRun) {
        cfg._reRun = false;
        setTimeout(() => { if (cfg.enabled !== false) syncOne(cfg, force); }, 80);
      }

      return { done: totalDone, up: doneUp, down: doneDown, del: doneDel };
    } catch (e) {
      cfg.status = 'err';
      cfg.error = e.message || String(e);
      cfg._silent = false;
      save(); emit();
      return { error: cfg.error };
    }
  }

  function watch(cfg) {
    if (watchers.has(cfg.id)) return;
    try {
      const w = fs.watch(cfg.local, { recursive: true }, () => {
        if (cfg._silent) return;
        clearTimeout(cfg._wTimer);
        cfg._wTimer = setTimeout(() => {
          if (cfg.enabled !== false) syncOne(cfg, true);
        }, 1800);
      });
      watchers.set(cfg.id, w);
    } catch {}
  }

  async function add(opts) {
    const local = String((opts && opts.local) || '');
    if (!local || !fs.existsSync(local)) return { ok: false, error: 'Thư mục không tồn tại.' };
    if (cfgs.some((c) => path.resolve(c.local).toLowerCase() === path.resolve(local).toLowerCase())) {
      return { ok: false, error: 'Thư mục này đã được đồng bộ.' };
    }
    const cfg = {
      id: crypto.randomBytes(4).toString('hex'),
      name: path.basename(local),
      local,
      remote: String((opts && opts.remote) || ''),
      pool: String((opts && opts.pool) || ''),
      twoWay: opts && opts.twoWay != null ? !!opts.twoWay : true,
      enabled: true,
      manifest: {},
      status: 'idle',
      synced: 0,
      lastRun: null,
    };
    cfgs.push(cfg);
    save();
    watch(cfg);
    emit();
    await syncOne(cfg, true);
    return { ok: true, id: cfg.id };
  }

  function publicCfg(c) {
    return {
      id: c.id,
      name: c.name,
      local: c.local,
      remote: c.remote || '',
      pool: c.pool || '',
      twoWay: c.twoWay !== false,
      enabled: c.enabled !== false,
      status: c.status || 'idle',
      error: c.error || '',
      pending: c.pending || 0,
      synced: c.synced || 0,
      lastRun: c.lastRun || null,
      history: (c.history || []).slice(0, 30),
    };
  }

  function listPublic() {
    return { items: cfgs.map(publicCfg) };
  }

  function remove(id) {
    const i = cfgs.findIndex((c) => c.id === id);
    if (i < 0) return { ok: true };
    const w = watchers.get(id);
    if (w) {
      try { w.close(); } catch {}
      watchers.delete(id);
    }
    cfgs.splice(i, 1);
    save(); emit();
    return { ok: true };
  }

  function toggle(id, on) {
    const cfg = cfgs.find((c) => c.id === id);
    if (cfg) {
      cfg.enabled = !!on;
      save(); emit();
      if (on) syncOne(cfg, true);
    }
    return { ok: true };
  }

  function setMode(id, twoWay) {
    const cfg = cfgs.find((c) => c.id === id);
    if (cfg) {
      cfg.twoWay = !!twoWay;
      save(); emit();
      syncOne(cfg, true);
    }
    return { ok: true };
  }

  function ensureFolderIcon(folderPath) {
    if (!folderPath || !fs.existsSync(folderPath)) return;
    try {
      const icoPath = path.join(__dirname, 'shell-extension', 'synced.ico');
      if (!fs.existsSync(icoPath)) return;
      const iniPath = path.join(folderPath, 'desktop.ini');
      if (!fs.existsSync(iniPath)) {
        const iniContent = `[.ShellClassInfo]\r\nIconResource=${icoPath},0\r\n[ViewState]\r\nMode=\r\nVid=\r\nFolderType=Generic\r\n`;
        fs.writeFileSync(iniPath, iniContent, 'utf8');
        const { exec } = require('child_process');
        exec(`attrib +h +s "${iniPath}" & attrib +r "${folderPath}"`, { windowsHide: true }, () => {});
      }
    } catch {}
  }

  async function ensureDefaultSync(defaultLocal) {
    if (!defaultLocal) return;
    try {
      if (!fs.existsSync(defaultLocal)) fs.mkdirSync(defaultLocal, { recursive: true });
      ensureFolderIcon(defaultLocal);
    } catch {}

    if (cfgs.length === 0) {
      const cfg = {
        id: crypto.randomBytes(4).toString('hex'),
        name: 'CW Datacenter',
        local: defaultLocal,
        remote: '',
        pool: 'main',
        twoWay: true,
        enabled: true,
        manifest: {},
        status: 'idle',
        synced: 0,
        lastRun: null,
      };
      cfgs.push(cfg);
      save();
      watch(cfg);
      emit();
      if (authToken && serverOrigin) syncOne(cfg, true);
    }
  }

  async function changeDefaultLocal(newLocal) {
    if (!newLocal || !fs.existsSync(newLocal)) return { ok: false, error: 'Thư mục không tồn tại.' };
    ensureFolderIcon(newLocal);
    let cfg = cfgs[0];
    if (!cfg) {
      return add({ local: newLocal, remote: '', pool: 'main', twoWay: true });
    }
    const w = watchers.get(cfg.id);
    if (w) { try { w.close(); } catch {} watchers.delete(cfg.id); }

    cfg.local = newLocal;
    cfg.remote = '';
    cfg.name = path.basename(newLocal);
    cfg.manifest = {};
    save();
    watch(cfg);
    emit();
    if (authToken && serverOrigin) syncOne(cfg, true);
    return { ok: true, path: newLocal };
  }

  load();
  const timer = setInterval(() => {
    for (const c of cfgs) {
      if (c.enabled !== false && c.status !== 'busy') syncOne(c, false);
    }
  }, 3500);
  if (timer.unref) timer.unref();
  for (const c of cfgs) watch(c);

  return {
    setAuth,
    syncOne,
    add,
    remove,
    toggle,
    setMode,
    ensureDefaultSync,
    changeDefaultLocal,
    listPublic,
    _cfgs: () => cfgs,
    stop: () => {
      clearInterval(timer);
      for (const w of watchers.values()) { try { w.close(); } catch {} }
      watchers.clear();
      for (const c of cfgs) { clearTimeout(c._wTimer); }
    },
  };
}

module.exports = { makeEngine };
