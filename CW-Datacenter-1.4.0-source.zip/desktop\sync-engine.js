'use strict';
/* Sync engine: đồng bộ 1 chiều — chỉ đẩy (upload) tệp từ thư mục cục bộ lên máy chủ.
   Không tải về, không xóa trên máy chủ khi xóa ở local.
   Không phụ thuộc Electron — auth/origin được nạp qua setAuth(), notify() là callback. */
const path = require('path');
const fs = require('fs');
const fsp = fs.promises;
const crypto = require('crypto');
const { Readable } = require('stream');

function makeEngine({ syncFile, notify }) {
  let cfgs = [];
  let authToken = '';
  let serverOrigin = '';
  const pendingCheck = new Map();
  const watchers = new Map();

  function load() {
    try { cfgs = fs.existsSync(syncFile) ? JSON.parse(fs.readFileSync(syncFile, 'utf8')) : []; } catch { cfgs = []; }
    for (const c of cfgs) {
      c.status = c.status === 'busy' ? 'idle' : (c.status || 'idle');
      c.twoWay = false;
    }
  }
  function save() { try { fs.writeFileSync(syncFile, JSON.stringify(cfgs, null, 2)); } catch {} }

  function setAuth(token, origin) {
    authToken = String(token || '');
    serverOrigin = String(origin || '').replace(/\/$/, '');
  }
  function emit() { if (notify) { try { notify(listPublic()); } catch {} } }

  function walkLocal(dir, rel) {
    let out = [];
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
    for (const e of entries) {
      if (e.name.startsWith('.') || /^(thumbs\.db|desktop\.ini)$/i.test(e.name)) continue;
      if (/\.(cwtmp|part|tmp|download|crdownload|partial)$/i.test(e.name)) continue;
      const p = path.join(dir, e.name);
      const r = rel ? rel + '/' + e.name : e.name;
      try {
        if (e.isDirectory()) out = out.concat(walkLocal(p, r));
        else if (e.isFile() && !e.isSymbolicLink()) {
          const st = fs.statSync(p);
          out.push({ rel: r.split('\\').join('/'), abs: p, size: st.size, mtime: st.mtimeMs });
        }
      } catch {}
    }
    return out;
  }

  async function apiCall(method, apiPath, body) {
    if (!authToken || !serverOrigin) throw new Error('Chưa đăng nhập vào máy chủ.');
    const opts = { method, headers: { Authorization: 'Bearer ' + authToken } };
    if (body != null) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
    const res = await fetch(serverOrigin + apiPath, opts);
    if (res.status === 401) throw new Error('Phiên hết hạn — hãy đăng nhập lại trong app.');
    if (!res.ok) {
      let msg = 'Lỗi ' + res.status;
      try { msg = ((await res.json()).error) || msg; } catch {}
      throw new Error(msg);
    }
    return res.json().catch(() => ({}));
  }

  async function uploadFile(abs, remotePath, poolId) {
    if (!authToken || !serverOrigin) throw new Error('Chưa đăng nhập vào máy chủ.');
    const qs = poolId ? '&pool=' + encodeURIComponent(poolId) : '';
    const res = await fetch(serverOrigin + '/api/file?path=' + encodeURIComponent(remotePath) + qs, {
      method: 'PUT',
      headers: { Authorization: 'Bearer ' + authToken },
      body: Readable.toWeb(fs.createReadStream(abs)),
      duplex: 'half',
    });
    if (!res.ok) {
      let msg = 'Lỗi ' + res.status;
      try { msg = ((await res.json()).error) || msg; } catch {}
      if (res.status === 401) msg = 'Phiên hết hạn — hãy đăng nhập lại trong app.';
      throw new Error(msg);
    }
    return res.json().catch(() => ({}));
  }

  function remoteRoot(cfg) {
    return String(cfg.remote || '').split('\\').join('/').replace(/^\/+|\/+$/g, '');
  }
  function remotePathOf(cfg, rel) {
    const r = remoteRoot(cfg);
    return (r ? r + '/' : '') + rel;
  }

  function pushHistory(cfg, dir, rel, size) {
    cfg.history = cfg.history || [];
    cfg.history.unshift({ rel, dir, size: size || 0, time: Date.now() });
    if (cfg.history.length > 60) cfg.history.length = 60;
  }

  /* ---------- Đồng bộ 1 chiều (chỉ upload) ---------- */
  async function syncOne(cfg, force) {
    if (cfg.status === 'busy') return { skipped: true };
    if (!fs.existsSync(cfg.local)) { cfg.status = 'err'; cfg.error = 'Không thấy thư mục trên máy này.'; save(); emit(); return { error: cfg.error }; }
    cfg.status = 'busy'; cfg.pending = 0;
    cfg._silent = true;
    emit();
    try {
      cfg.manifest = cfg.manifest || {};
      const root = remoteRoot(cfg);
      if (root) {
        try { await apiCall('POST', '/api/mkdir', { path: root, pool: cfg.pool }); } catch {}
      }
      const items = walkLocal(cfg.local, '');
      const todo = [];
      for (const it of items) {
        const man = cfg.manifest[it.rel];
        if (man && man.size === it.size && Math.abs((man.localMtime || man.mtime || 0) - it.mtime) < 2000) continue;
        const key = cfg.id + '|' + it.rel;
        const mt = Math.round(it.mtime);
        if (!force) {
          const seen = pendingCheck.get(key);
          if (!seen || seen.size !== it.size || seen.mtime !== mt) {
            pendingCheck.set(key, { size: it.size, mtime: mt, t: Date.now() });
            continue;
          }
          if (Date.now() - seen.t < 2000) continue;
        }
        todo.push(it);
      }
      cfg.pending = todo.length;
      emit();
      let done = 0;
      for (const it of todo) {
        cfg.pending = todo.length - done;
        try {
          const st = await fsp.stat(it.abs);
          if (st.size !== it.size || Math.abs(st.mtimeMs - it.mtime) > 15) {
            pendingCheck.set(cfg.id + '|' + it.rel, { size: st.size, mtime: Math.round(st.mtimeMs), t: Date.now() });
            continue;
          }
        } catch { continue; }
        try {
          await uploadFile(it.abs, remotePathOf(cfg, it.rel), cfg.pool);
          cfg.manifest[it.rel] = { size: it.size, mtime: Math.round(it.mtime), localMtime: it.mtime };
          pushHistory(cfg, 'up', it.rel, it.size);
          pendingCheck.delete(cfg.id + '|' + it.rel);
          done++;
          if (done % 3 === 0) { save(); emit(); }
        } catch (e) {
          cfg.error = it.rel + ': ' + (e.message || e);
          cfg.status = 'err';
          cfg._silent = false;
          save(); emit();
          return { error: cfg.error, done };
        }
      }
      for (const rel of Object.keys(cfg.manifest)) {
        if (!items.some((it) => it.rel === rel)) delete cfg.manifest[rel];
      }
      cfg.synced = (cfg.synced || 0) + done;
      cfg.lastRun = Date.now();
      if (done || !cfg.error) cfg.error = '';
      cfg.status = 'idle';
      cfg._silent = false;
      save(); emit();
      return { done, up: done };
    } catch (e) {
      cfg.status = 'err'; cfg.error = e.message || String(e);
      cfg._silent = false;
      save(); emit();
      return { error: cfg.error };
    }
  }

  function watch(cfg) {
    if (watchers.has(cfg.id)) return;
    try {
      const w = fs.watch(cfg.local, { recursive: true }, () => {
        if (cfg._silent) return;
        clearTimeout(cfg._wTimer);
        cfg._wTimer = setTimeout(() => { if (cfg.enabled !== false) syncOne(cfg, true); }, 2000);
      });
      watchers.set(cfg.id, w);
    } catch {}
  }

  function add(opts) {
    const local = String((opts && opts.local) || '');
    if (!local || !fs.existsSync(local)) return { ok: false, error: 'Thư mục không tồn tại.' };
    if (cfgs.some((c) => path.resolve(c.local).toLowerCase() === path.resolve(local).toLowerCase())) {
      return { ok: false, error: 'Thư mục này đã được đồng bộ.' };
    }
    const cfg = {
      id: crypto.randomBytes(4).toString('hex'),
      name: path.basename(local),
      local,
      remote: String((opts && opts.remote) || ''),
      pool: String((opts && opts.pool) || ''),
      twoWay: false,
      enabled: true, manifest: {}, status: 'idle', synced: 0, lastRun: null,
    };
    cfgs.push(cfg);
    save();
    watch(cfg);
    emit();
    syncOne(cfg, true);
    return { ok: true, id: cfg.id };
  }

  function publicCfg(c) {
    return {
      id: c.id, name: c.name, local: c.local, remote: c.remote || '', pool: c.pool || '',
      twoWay: false,
      enabled: c.enabled !== false, status: c.status || 'idle', error: c.error || '',
      pending: c.pending || 0, synced: c.synced || 0, lastRun: c.lastRun || null,
      history: (c.history || []).slice(0, 30),
    };
  }
  function listPublic() { return { items: cfgs.map(publicCfg) }; }

  function remove(id) {
    const i = cfgs.findIndex((c) => c.id === id);
    if (i < 0) return { ok: true };
    const w = watchers.get(id);
    if (w) { try { w.close(); } catch {} watchers.delete(id); }
    cfgs.splice(i, 1);
    save(); emit();
    return { ok: true };
  }
  function toggle(id, on) {
    const cfg = cfgs.find((c) => c.id === id);
    if (cfg) { cfg.enabled = !!on; save(); emit(); if (on) syncOne(cfg, true); }
    return { ok: true };
  }

  load();
  const timer = setInterval(() => {
    for (const c of cfgs) if (c.enabled !== false && c.status !== 'busy') syncOne(c, false);
  }, 4000);
  if (timer.unref) timer.unref();
  for (const c of cfgs) watch(c);

  return { setAuth, syncOne, add, remove, toggle, listPublic, _cfgs: () => cfgs, stop: () => clearInterval(timer) };
}

module.exports = { makeEngine };
