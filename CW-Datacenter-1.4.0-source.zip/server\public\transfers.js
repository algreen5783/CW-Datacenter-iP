'use strict';
const CHUNK_SIZE = 4 * 1024 * 1024;
const MAX_RETRIES = 6;
const transferBus = { list: [], onChange: null };

function trNotify() { if (transferBus.onChange) transferBus.onChange(); }

async function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

async function fetchWithRetry(url, opts, attempts) {
  let lastErr;
  for (let i = 0; i < (attempts || 3); i++) {
    try {
      const res = await fetch(url, opts);
      if (res.status >= 500 || res.status === 429) {
        lastErr = new Error('Server ' + res.status);
        await sleep(800 * Math.pow(2, i));
        continue;
      }
      return res;
    } catch (e) {
      lastErr = e;
      await sleep(800 * Math.pow(2, i));
    }
  }
  throw lastErr || new Error('Network error');
}

function makeTransfer(props) {
  const tr = Object.assign({
    id: 't' + (++trId),
    status: 'queued',
    done: 0,
    total: 0,
    speed: 0,
    error: '',
    cancel: false,
    _abort: null,
    _speedMark: { t: Date.now(), b: 0 },
  }, props);
  transferBus.list.unshift(tr);
  trNotify();
  return tr;
}

function calcSpeed(tr) {
  const now = Date.now();
  const dt = now - tr._speedMark.t;
  if (dt >= 700) {
    tr.speed = ((tr.done - tr._speedMark.b) / dt) * 1000;
    tr._speedMark = { t: now, b: tr.done };
  }
}

function finishTransfer(tr, status) {
  tr.status = status;
  tr._abort = null;
  if (status === 'done') tr.done = tr.total;
  trNotify();
}

/* ---------- Resumable Upload ---------- */
async function uploadFileResumable(file, targetDir, pool, relOverride) {
  const rel = relOverride || ((targetDir ? targetDir + '/' : '') + file.name);
  const displayName = relOverride ? rel.split('/').pop() : file.name;
  const relDir = relOverride ? rel.replace(/\/[^/]*$/, '') : targetDir;
  const initBody = { path: rel, size: file.size };
  if (pool) initBody.pool = pool;
  const tr = makeTransfer({ name: displayName, dir: 'up', target: '/' + (relDir || ''), total: file.size, pool: pool || '' });
  tr.file = file;
  tr.targetDir = relDir;
  const ctrl = new AbortController();
  tr._abort = ctrl;

  try {
    const initRes = await fetchWithRetry('/api/upload/init', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(initBody),
    });
    const init = await initRes.json();
    if (!initRes.ok) throw new Error(init.error || 'Init failed');
    const uploadId = init.uploadId;
    let offset = init.offset || 0;
    tr.done = offset;
    tr.status = 'active';
    trNotify();

    while (offset < file.size) {
      if (tr.cancel) {
        if (navigator.onLine) fetchWithRetry('/api/upload/abort', { method: 'POST', body: JSON.stringify({ uploadId }) }, 1).catch(() => {});
        return finishTransfer(tr, 'cancelled');
      }
      const end = Math.min(offset + CHUNK_SIZE, file.size);
      const blob = file.slice(offset, end);
      let retries = 0;
      let sentOk = false;
      while (!sentOk) {
        if (tr.cancel) {
          fetchWithRetry('/api/upload/abort', { method: 'POST', body: JSON.stringify({ uploadId }) }, 1).catch(() => {});
          return finishTransfer(tr, 'cancelled');
        }
        try {
          const res = await fetch('/api/upload/chunk?id=' + encodeURIComponent(uploadId) + '&offset=' + offset, {
            method: 'POST',
            body: blob,
            signal: ctrl.signal,
          });
          const j = await res.json().catch(() => ({}));
          if (res.status === 409) {
            offset = j.serverOffset != null ? j.serverOffset : offset;
            tr.done = offset;
            trNotify();
            continue;
          }
          if (!res.ok) throw new Error(j.error || 'Chunk failed ' + res.status);
          offset = j.offset;
          tr.done = offset;
          calcSpeed(tr);
          trNotify();
          sentOk = true;
        } catch (e) {
          if (tr.cancel) return finishTransfer(tr, 'cancelled');
          if (e.name === 'AbortError') return finishTransfer(tr, 'paused');
          retries++;
          if (retries > MAX_RETRIES) {
            if (navigator.onLine) throw e;
            tr.status = 'paused';
            trNotify();
            await sleep(3000);
            retries = 0;
            continue;
          }
          tr.status = 'retrying';
          trNotify();
          await sleep(1000 * Math.pow(2, Math.min(retries, 4)));
          tr.status = 'active';
          trNotify();
          const st = await fetchWithRetry('/api/upload/status?path=' + encodeURIComponent(rel) + '&size=' + file.size + (pool ? '&pool=' + encodeURIComponent(pool) : '')).then((r) => r.json()).catch(() => null);
          if (st && st.offset != null) { offset = st.offset; tr.done = offset; }
        }
      }
    }

    const compRes = await fetchWithRetry('/api/upload/complete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ uploadId }),
    });
    const comp = await compRes.json().catch(() => ({}));
    if (!compRes.ok) throw new Error(comp.error || 'Complete failed');
    finishTransfer(tr, 'done');
    return comp;
  } catch (e) {
    tr.error = e.message;
    return finishTransfer(tr, 'error');
  }
}

/* ---------- Resumable Download (Range + blob assemble) ---------- */
async function downloadFileResumable(f, relPath, pool) {
  const qs = (pool ? '&pool=' + encodeURIComponent(pool) : '');
  const tr = makeTransfer({ name: f.name, dir: 'down', target: '/' + relPath, total: f.size, pool: pool || '' });
  const ctrl = new AbortController();
  tr._abort = ctrl;
  const parts = [];
  let doneBlob = 0;

  try {
    // Thư mục: server trả về ZIP (không hỗ trợ Range) — giao thẳng cho trình duyệt/Electron.
    if (f.type === 'dir') {
      tr.status = 'active';
      trNotify();
      const a = document.createElement('a');
      a.href = '/api/file?path=' + encodeURIComponent(relPath) + qs;
      a.download = f.name + '.zip';
      a.click();
      return finishTransfer(tr, 'browser');
    }
    // Electron app: tải qua trình tải xuống gốc (stream thẳng ra đĩa, có % tiến độ, không ngốn RAM).
    if (typeof window !== 'undefined' && window.dc && window.dc.onDownloadProgress) {
      tr.native = true;
      tr.status = 'active';
      trNotify();
      const a = document.createElement('a');
      a.href = '/api/file?path=' + encodeURIComponent(relPath) + qs;
      a.download = f.name;
      a.click();
      return tr;
    }
    // Trình duyệt thường: stream ghép blob; file quá lớn giao cho trình duyệt.
    if (f.size > 2560 * 1024 * 1024) {
      tr.status = 'active';
      trNotify();
      const a = document.createElement('a');
      a.href = '/api/file?path=' + encodeURIComponent(relPath) + qs;
      a.download = f.name;
      a.click();
      return finishTransfer(tr, 'browser');
    }

    const first = await fetch('/api/file?path=' + encodeURIComponent(relPath) + '&preview=1' + qs, {
      headers: { Range: 'bytes=0-' + (Math.min(CHUNK_SIZE, Math.max(f.size, 1)) - 1) },
      signal: ctrl.signal,
    });
    if (!first.ok && first.status !== 206 && first.status !== 200) {
      if (first.status === 416 || first.status === 400) { tr.status = 'error'; }
      throw new Error('Server từ chối tải (' + first.status + ')');
    }
    const total = f.size || Number((first.headers.get('Content-Range') || '').split('/')[1]) || 0;
    tr.total = total;
    tr.status = 'active';
    parts.push(await first.blob());
    doneBlob = parts.reduce((s, b) => s + b.size, 0);
    tr.done = doneBlob;
    calcSpeed(tr);
    trNotify();

    let offset = doneBlob;
    while (offset < total) {
      if (tr.cancel) return finishTransfer(tr, 'cancelled');
      const end = Math.min(offset + CHUNK_SIZE, total) - 1;
      let retries = 0;
      let ok = false;
      while (!ok) {
        if (tr.cancel) return finishTransfer(tr, 'cancelled');
        try {
          const res = await fetch('/api/file?path=' + encodeURIComponent(relPath) + '&preview=1' + qs, {
            headers: { Range: 'bytes=' + offset + '-' + end },
            signal: ctrl.signal,
          });
          if (res.status !== 206 && res.status !== 200) throw new Error('HTTP ' + res.status);
          parts.push(await res.blob());
          offset = end + 1;
          doneBlob = parts.reduce((s, b) => s + b.size, 0);
          tr.done = doneBlob;
          calcSpeed(tr);
          trNotify();
          ok = true;
        } catch (e) {
          if (tr.cancel) return finishTransfer(tr, 'cancelled');
          if (e.name === 'AbortError') return finishTransfer(tr, 'paused');
          retries++;
          if (retries > MAX_RETRIES) throw e;
          tr.status = 'retrying';
          trNotify();
          await sleep(1000 * Math.pow(2, Math.min(retries, 4)));
          tr.status = 'active';
          trNotify();
        }
      }
    }

    const blob = new Blob(parts, { type: 'application/octet-stream' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = f.name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 10000);
    return finishTransfer(tr, 'done');
  } catch (e) {
    tr.error = e.message;
    return finishTransfer(tr, 'error');
  }
}

function pauseTransfer(tr) {
  if (tr.status === 'active' || tr.status === 'retrying') {
    if (tr.dir === 'down') return cancelTransfer(tr);
    if (tr._abort) tr._abort.abort();
    tr.status = 'paused';
    trNotify();
  }
}
function cancelTransfer(tr) {
  tr.cancel = true;
  if (tr._abort) try { tr._abort.abort(); } catch {}
  if (tr.status === 'active' || tr.status === 'retrying') {
    tr.status = 'cancelled';
    trNotify();
  }
}

/* ---------- Electron native download progress bridge ---------- */
if (typeof window !== 'undefined' && window.dc && window.dc.onDownloadProgress) {
  window.dc.onDownloadProgress((p) => {
    const cand = transferBus.list.find((t) => t.native && t.name === p.name && !['done', 'cancelled', 'error'].includes(t.status));
    if (!cand) return;
    if (p.seq != null && cand.seq == null) cand.seq = p.seq;
    if (p.state === 'progressing') {
      cand.status = 'active';
      if (p.received != null) cand.done = p.received;
      if (p.total) cand.total = p.total;
      calcSpeed(cand);
      trNotify();
    } else if (p.state === 'completed') {
      if (p.total) cand.total = p.total;
      finishTransfer(cand, 'done');
    } else {
      cand.error = p.state === 'cancelled' ? 'Đã hủy' : 'Lỗi tải xuống';
      finishTransfer(cand, p.state === 'cancelled' ? 'cancelled' : 'error');
    }
  });
  const _origCancel = cancelTransfer;
  cancelTransfer = function (tr) {
    if (tr.native && tr.seq != null && window.dc && window.dc.cancelDownload) {
      try { window.dc.cancelDownload(tr.seq); } catch {}
      tr.status = 'cancelled';
      trNotify();
      return;
    }
    return _origCancel(tr);
  };
}
