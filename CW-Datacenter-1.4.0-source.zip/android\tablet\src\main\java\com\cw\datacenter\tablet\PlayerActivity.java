package com.cw.datacenter.tablet;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import java.io.File;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.VideoSize;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.HttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.SeekParameters;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.mkv.MatroskaExtractor;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* Trình phát video — UI dựng tay theo bản MVP HTML (cw-video-player-mvp.html):
 * topbar (quay lại / tên / cast / phụ đề / ⋮), cụm giữa (lui 10s, play/pause, tiến 10s),
 * timeline với thumb màu accent #ff385d, panel 5 nút (Khóa / Tốc độ / Lặp lại / Danh sách /
 * Cài đặt), chế độ khóa với nút mở khóa bên trái, sheet danh sách phát/cài đặt/khác,
 * toast chip, tự ẩn điều khiển sau 2,6s khi đang phát. */
public class PlayerActivity extends Activity implements Player.Listener {

    private static final int ACCENT = 0xFFFF385D;
    private static final long CONTROLS_HIDE_DELAY = 2600;
    private static final float[] SPEEDS = { 0.5f, 1f, 1.25f, 1.5f, 2f };

    private ExoPlayer player;
    private volatile String token;
    private volatile String baseUrl;
    private PowerManager.WakeLock wakeLock;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final java.util.concurrent.ExecutorService executor = java.util.concurrent.Executors.newCachedThreadPool();
    private final java.util.concurrent.ExecutorService preloadExecutor = java.util.concurrent.Executors.newSingleThreadExecutor();
    private Runnable preloadRunnable = null;
    private volatile boolean isPreloadCancelled = false;

    private TextureView surface;
    private FrameLayout root;
    private LinearLayout topBar;
    private TextView titleView;
    private ImageButton favBtn;
    private LinearLayout centerControls;
    private ImageButton playBtn;
    private LinearLayout bottom;
    private LinearLayout timelineRow;
    private SeekTrack track;
    private TextView curTime;
    private TextView durTime;
    private LinearLayout portraitExtras;
    private LinearLayout landscapeExtras;
    private ImageButton volumeBtn;
    private FrameLayout actionPanel;
    private GradientDrawable lockActionBg;
    private TextView speedLabel;
    private GradientDrawable repeatActionBg;
    private ImageButton unlockBtn;
    private TextView toastView;
    private FrameLayout sheetBox;
    private TextView sheetTitle;
    private LinearLayout sheetList;

    private List<PlItem> playlist = new ArrayList<>();
    private int plIndex = -1;
    private String videoUrl;
    private String videoName;

    private boolean muted = false;
    private boolean locked = false;
    private boolean repeating = false;
    private boolean controlsShown = true;
    private int speedIndex = 1;
    private int scalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT;
    private boolean fitToScreen = false;
    private String sheetId = null;
    private int videoWidth = 0;
    private int videoHeight = 0;

    public static class PlItem {
        public String name;
        public String url;
        public long size;
    }

    private static volatile List<PlItem> sPendingPlaylist = null;
    private static volatile int sPendingPlIndex = -1;

    public static void setPendingPlaylist(List<PlItem> list, int index) {
        sPendingPlaylist = list;
        sPendingPlIndex = index;
    }

    public static List<PlItem> popPendingPlaylist() {
        List<PlItem> l = sPendingPlaylist;
        sPendingPlaylist = null;
        return l;
    }

    public static int popPendingPlIndex() {
        int idx = sPendingPlIndex;
        sPendingPlIndex = -1;
        return idx;
    }

    private final Runnable hideRunnable = this::hideControls;
    private final Runnable tickRunnable = new Runnable() {
        @Override
        public void run() {
            updateTime();
            h.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        token = getSharedPreferences("cw-datacenter", MODE_PRIVATE).getString("player_token", null);
        if (token == null || token.isEmpty()) {
            token = getIntent().getStringExtra("token");
        }
        baseUrl = getIntent().getStringExtra("baseUrl");
        if (baseUrl == null || baseUrl.isEmpty()) {
            baseUrl = getSharedPreferences("cw-datacenter", MODE_PRIVATE).getString("base_url", "");
        }
        videoUrl = getIntent().getStringExtra("url");
        videoName = getIntent().getStringExtra("name");

        List<PlItem> pendingList = popPendingPlaylist();
        if (pendingList != null && !pendingList.isEmpty()) {
            playlist.clear();
            playlist.addAll(pendingList);
            plIndex = popPendingPlIndex();
            if (plIndex < 0 || plIndex >= playlist.size()) plIndex = 0;
        } else {
            parsePlaylist(getIntent().getStringExtra("playlist"));
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);

        if (videoUrl == null || videoUrl.isEmpty()) {
            Toast.makeText(this, "Không có địa chỉ phát.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        surface = new TextureView(this);
        surface.setKeepScreenOn(true);
        surface.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or2, ob) -> adjustAspectRatio());
        root.addView(surface, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        buildOverlay();
        applyInsets();

        surface.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(android.graphics.SurfaceTexture st, int w, int h2) {
                attachPlayerSurface();
                adjustAspectRatio();
            }
            @Override
            public void onSurfaceTextureSizeChanged(android.graphics.SurfaceTexture st, int w, int h2) {
                adjustAspectRatio();
            }
            @Override
            public boolean onSurfaceTextureDestroyed(android.graphics.SurfaceTexture st) {
                if (player != null) player.clearVideoSurface();
                return true;
            }
            @Override
            public void onSurfaceTextureUpdated(android.graphics.SurfaceTexture st) {}
        });

        final GestureDetector gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                onSurfaceTap();
                return true;
            }
        });
        surface.setOnTouchListener((v, ev) -> { gd.onTouchEvent(ev); return true; });

        try {
            buildPlayer(videoUrl, videoName);
        } catch (Throwable t) {
            try {
                player = new ExoPlayer.Builder(this).build();
                player.addListener(this);
                loadItem(videoUrl, videoName);
            } catch (Throwable t2) {
                Toast.makeText(this, "Không thể mở video: " + t.getMessage(), Toast.LENGTH_LONG).show();
                finish();
                return;
            }
        }
        acquireWake();
        showControls();
    }

    private void parsePlaylist(String json) {
        try {
            if (json == null || json.isEmpty()) return;
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String u = o.optString("url", "");
                if (u.isEmpty()) continue;
                PlItem it = new PlItem();
                it.name = o.optString("name", "");
                it.url = u;
                it.size = o.optLong("size", 0);
                playlist.add(it);
            }
        } catch (Exception ignored) {}
        if (!playlist.isEmpty()) {
            for (int i = 0; i < playlist.size(); i++) {
                if (videoUrl != null && videoUrl.equals(playlist.get(i).url)) { plIndex = i; break; }
            }
            if (plIndex < 0) {
                int idx = getIntent().getIntExtra("plIndex", 0);
                plIndex = (idx >= 0 && idx < playlist.size()) ? idx : 0;
            }
        }
    }

    /* ---------- Dựng UI ---------- */

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private ImageButton iconBtn(int iconRes, String desc) {
        ImageButton b = new ImageButton(this);
        b.setBackgroundResource(R.drawable.pl_icon_btn_bg);
        b.setImageResource(iconRes);
        b.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        b.setContentDescription(desc);
        b.setColorFilter(Color.WHITE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44));
        b.setLayoutParams(lp);
        return b;
    }

    private void buildOverlay() {
        /* --- topbar --- */
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        ((LinearLayout) topBar).setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(22), dp(18), dp(22), dp(12));

        ImageButton back = iconBtn(R.drawable.ic_pl_back, "Quay lại");
        back.setOnClickListener(v -> onBackPressed());
        ((LinearLayout) topBar).addView(back);

        titleView = new TextView(this);
        titleView.setText(videoName == null || videoName.isEmpty() ? "Đang phát" : videoName);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setSingleLine(true);
        titleView.setShadowLayer(10, 0, 2, 0x73000000);
        titleView.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tlp.leftMargin = dp(12);
        tlp.rightMargin = dp(12);
        ((LinearLayout) topBar).addView(titleView, tlp);

        favBtn = iconBtn(R.drawable.ic_photo_heart_off, "Yêu thích");
        favBtn.setOnClickListener(v -> toggleFavoriteCurrent());
        ((LinearLayout) topBar).addView(favBtn);

        ImageButton cast = iconBtn(R.drawable.ic_pl_cast, "Truyền màn hình");
        cast.setOnClickListener(v -> {
            toggleSheet("castSheet");
            startDlnaDiscovery();
        });
        ((LinearLayout) topBar).addView(cast);

        ImageButton share = iconBtn(R.drawable.ic_photo_share, "Chia sẻ");
        share.setOnClickListener(v -> shareCurrentVideo());
        ((LinearLayout) topBar).addView(share);

        ImageButton more = iconBtn(R.drawable.ic_pl_more, "Thêm");
        more.setOnClickListener(v -> toggleSheet("moreSheet"));
        ((LinearLayout) topBar).addView(more);

        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP);
        root.addView(topBar, topLp);

        /* --- center controls --- */
        centerControls = new LinearLayout(this);
        centerControls.setOrientation(LinearLayout.HORIZONTAL);
        centerControls.setGravity(Gravity.CENTER);
        buildCenterControls();
        FrameLayout.LayoutParams midLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        root.addView(centerControls, midLp);

        /* --- unlock button (chế độ khóa) --- */
        unlockBtn = new ImageButton(this);
        unlockBtn.setBackgroundResource(R.drawable.pl_round_bg);
        unlockBtn.setImageResource(R.drawable.ic_pl_unlock);
        unlockBtn.setColorFilter(Color.WHITE);
        unlockBtn.setContentDescription("Mở khóa");
        unlockBtn.setAlpha(0f);
        unlockBtn.setEnabled(false);
        unlockBtn.setOnClickListener(v -> {
            locked = false;
            updateLockUi();
            showToast("Đã mở khóa điều khiển");
            showControls();
        });
        FrameLayout.LayoutParams ulp = new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.START | Gravity.CENTER_VERTICAL);
        ulp.leftMargin = dp(22);
        root.addView(unlockBtn, ulp);

        /* --- bottom --- */
        bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(dp(24), 0, dp(24), dp(22));
        buildBottomSection();
        FrameLayout.LayoutParams botLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        root.addView(bottom, botLp);

        /* --- toast chip --- */
        toastView = new TextView(this);
        toastView.setTextColor(Color.WHITE);
        toastView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        toastView.setPadding(dp(16), dp(10), dp(16), dp(10));
        toastView.setGravity(Gravity.CENTER);
        GradientDrawable tbg = new GradientDrawable();
        tbg.setCornerRadius(dp(999));
        tbg.setColor(0xB3000000);
        toastView.setBackground(tbg);
        toastView.setAlpha(0f);
        FrameLayout.LayoutParams toLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        toLp.topMargin = dp(120);
        root.addView(toastView, toLp);

        /* --- sheet (danh sách phát / cài đặt / khác) --- */
        sheetBox = new FrameLayout(this);
        sheetBox.setBackground(getResources().getDrawable(R.drawable.pl_panel_bg));
        sheetBox.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout sheetInner = new LinearLayout(this);
        sheetInner.setOrientation(LinearLayout.VERTICAL);
        sheetTitle = new TextView(this);
        sheetTitle.setTextColor(Color.WHITE);
        sheetTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        sheetTitle.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams stlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stlp.leftMargin = dp(6);
        stlp.bottomMargin = dp(12);
        sheetInner.addView(sheetTitle, stlp);
        ScrollView sc = new ScrollView(this);
        sc.setVerticalScrollBarEnabled(false);
        sheetList = new LinearLayout(this);
        sheetList.setOrientation(LinearLayout.VERTICAL);
        sc.addView(sheetList);
        sheetInner.addView(sc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        sheetBox.addView(sheetInner, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        sheetBox.setAlpha(0f);
        sheetBox.setEnabled(false);
        sheetBox.setOnClickListener(v -> hideSheet());
        FrameLayout.LayoutParams shlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        shlp.leftMargin = dp(14);
        shlp.rightMargin = dp(14);
        shlp.bottomMargin = dp(150);
        root.addView(sheetBox, shlp);
    }

    private void buildCenterControls() {
        centerControls.removeAllViews();
        boolean landscape = isLandscape();
        int gap = dp(landscape ? 60 : 28);

        LinearLayout rew = roundSkipBtn(R.drawable.ic_pl_rew10, "10", true);
        rew.setOnClickListener(v -> skip(-10000));
        centerControls.addView(rew);
        LinearLayout.LayoutParams rlp = (LinearLayout.LayoutParams) rew.getLayoutParams();
        rlp.rightMargin = gap / 2;

        ImageButton play = new ImageButton(this);
        play.setBackgroundResource(R.drawable.pl_round_main_bg);
        play.setImageResource(R.drawable.ic_pl_pause);
        play.setColorFilter(Color.WHITE);
        play.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        play.setContentDescription("Phát hoặc tạm dừng");
        play.setOnClickListener(v -> togglePlay());
        int mainSize = dp(landscape ? 112 : 96);
        centerControls.addView(play, new LinearLayout.LayoutParams(mainSize, mainSize));
        playBtn = play;

        LinearLayout fwd = roundSkipBtn(R.drawable.ic_pl_fwd10, "10", false);
        fwd.setOnClickListener(v -> skip(10000));
        centerControls.addView(fwd);
        LinearLayout.LayoutParams flp = (LinearLayout.LayoutParams) fwd.getLayoutParams();
        flp.leftMargin = gap / 2;
    }

    private LinearLayout roundSkipBtn(int iconRes, String num, boolean iconFirst) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER);
        int size = dp(isLandscape() ? 76 : 68);
        box.setLayoutParams(new LinearLayout.LayoutParams(size, size));
        box.setBackgroundResource(R.drawable.pl_round_bg);
        ImageView ic = new ImageView(this);
        ic.setImageResource(iconRes);
        ic.setColorFilter(Color.WHITE);
        TextView tv = new TextView(this);
        tv.setText(num);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        LinearLayout.LayoutParams icLp = new LinearLayout.LayoutParams(dp(23), dp(23));
        LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        if (iconFirst) {
            tvLp.leftMargin = dp(5);
            box.addView(ic, icLp);
            box.addView(tv, tvLp);
        } else {
            tvLp.rightMargin = dp(5);
            box.addView(tv, tvLp);
            box.addView(ic, icLp);
        }
        return box;
    }

    private void buildBottomSection() {
        bottom.removeAllViews();
        boolean landscape = isLandscape();

        /* portrait-extras: vừa màn hình + toàn màn hình */
        portraitExtras = new LinearLayout(this);
        portraitExtras.setOrientation(LinearLayout.HORIZONTAL);
        portraitExtras.setGravity(Gravity.CENTER_VERTICAL);
        ImageButton fit = iconBtn(R.drawable.ic_pl_fit, "Vừa màn hình");
        fit.setOnClickListener(v -> toggleFit());
        portraitExtras.addView(fit);

        View spacer = new View(this);
        LinearLayout.LayoutParams spLp = new LinearLayout.LayoutParams(0, dp(1), 1f);
        portraitExtras.addView(spacer, spLp);

        ImageButton fs = iconBtn(R.drawable.ic_pl_fullscreen, "Toàn màn hình");
        fs.setOnClickListener(v -> toggleOrientation());
        LinearLayout.LayoutParams fsLp = new LinearLayout.LayoutParams(dp(44), dp(44));
        portraitExtras.addView(fs, fsLp);
        portraitExtras.setVisibility(landscape ? View.GONE : View.VISIBLE);
        LinearLayout.LayoutParams pel = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pel.bottomMargin = dp(12);
        bottom.addView(portraitExtras, pel);

        /* timeline row: time | track | time | (landscape extras) */
        timelineRow = new LinearLayout(this);
        timelineRow.setOrientation(LinearLayout.HORIZONTAL);
        timelineRow.setGravity(Gravity.CENTER_VERTICAL);

        curTime = new TextView(this);
        curTime.setTextColor(Color.WHITE);
        curTime.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        curTime.setText("00:00");
        curTime.setShadowLayer(8, 0, 2, 0x73000000);
        timelineRow.addView(curTime);

        track = new SeekTrack(this);
        LinearLayout.LayoutParams trkLp = new LinearLayout.LayoutParams(0, dp(26), 1f);
        trkLp.leftMargin = dp(16);
        trkLp.rightMargin = dp(16);
        timelineRow.addView(track, trkLp);

        durTime = new TextView(this);
        durTime.setTextColor(Color.WHITE);
        durTime.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        durTime.setText("00:00");
        durTime.setShadowLayer(8, 0, 2, 0x73000000);
        timelineRow.addView(durTime);

        landscapeExtras = new LinearLayout(this);
        landscapeExtras.setOrientation(LinearLayout.HORIZONTAL);
        landscapeExtras.setGravity(Gravity.CENTER_VERTICAL);
        volumeBtn = iconBtn(R.drawable.ic_pl_vol_on, "Âm lượng");
        volumeBtn.setOnClickListener(v -> toggleVolume());
        LinearLayout.LayoutParams volLp = new LinearLayout.LayoutParams(dp(44), dp(44));
        volLp.leftMargin = dp(10);
        landscapeExtras.addView(volumeBtn, volLp);
        ImageButton fs2 = iconBtn(R.drawable.ic_pl_fullscreen, "Toàn màn hình");
        fs2.setOnClickListener(v -> toggleOrientation());
        landscapeExtras.addView(fs2);
        if (landscape) timelineRow.addView(landscapeExtras);

        LinearLayout.LayoutParams tlLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlLp.bottomMargin = dp(16);
        bottom.addView(timelineRow, tlLp);

        /* action panel: 6 cột Khóa / Tốc độ / Lặp lại / Danh sách / Xoay / Cài đặt */
        actionPanel = new FrameLayout(this);
        actionPanel.setBackground(getResources().getDrawable(R.drawable.pl_panel_bg));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setWeightSum(6);

        LinearLayout lockBtn = actionButton(R.drawable.ic_pl_lock, "Khóa", v -> toggleLock(), true);
        lockActionBg = (GradientDrawable) lockBtn.getBackground();
        LinearLayout speedBtn = actionButton(R.drawable.ic_pl_speed, "Tốc độ", v -> cycleSpeed(), false);
        speedLabel = (TextView) speedBtn.getChildAt(1);
        LinearLayout repeatBtn = actionButton(R.drawable.ic_pl_repeat, "Lặp lại", v -> toggleRepeat(), true);
        repeatActionBg = (GradientDrawable) repeatBtn.getBackground();
        LinearLayout listBtn = actionButton(R.drawable.ic_pl_list, "Danh sách", v -> toggleSheet("playlistSheet"), false);
        LinearLayout rotateBtn = actionButton(R.drawable.ic_pl_rotate, "Xoay", v -> toggleOrientation(), false);
        LinearLayout setBtn = actionButton(R.drawable.ic_pl_settings, "Cài đặt", v -> toggleSheet("settingsSheet"), false);

        for (LinearLayout b : new LinearLayout[]{ lockBtn, speedBtn, repeatBtn, listBtn, rotateBtn, setBtn }) {
            row.addView(b, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        actionPanel.addView(row, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        bottom.addView(actionPanel, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        updateActionButtons();
    }

    private LinearLayout actionButton(int iconRes, String label, View.OnClickListener click, boolean keepBgRef) {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(8), dp(12), dp(8), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(18));
        bg.setColor(0x00000000);
        b.setBackground(bg);
        ImageView ic = new ImageView(this);
        ic.setImageResource(iconRes);
        ic.setColorFilter(Color.WHITE);
        b.addView(ic, new LinearLayout.LayoutParams(dp(27), dp(27)));
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tv.setSingleLine(true);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tvLp.topMargin = dp(8);
        b.addView(tv, tvLp);
        b.setOnClickListener(click);
        return b;
    }

    private boolean isLandscape() {
        return getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
    }

    private void applyInsets() {
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top, bot;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets sys = insets.getInsets(android.view.WindowInsets.Type.systemBars());
                top = sys.top;
                bot = sys.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bot = insets.getSystemWindowInsetBottom();
            }
            topBar.setPadding(topBar.getPaddingLeft(), Math.max(dp(12), top), topBar.getPaddingRight(), topBar.getPaddingBottom());
            bottom.setPadding(bottom.getPaddingLeft(), bottom.getPaddingTop(), bottom.getPaddingRight(), Math.max(dp(22), bot));
            return insets;
        });
    }

    /* ---------- Thanh track thời gian: tự vẽ nền, fill, thumb (giống HTML: accent + halo) ---------- */
    class SeekTrack extends View {
        private final Paint bgP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fillP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint thumbP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint haloP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float frac = 0f;
        private boolean dragging;

        SeekTrack(Context c) {
            super(c);
            bgP.setColor(0x40FFFFFF);
            fillP.setColor(ACCENT);
            thumbP.setColor(ACCENT);
            haloP.setColor(0x38FF385D);
        }

        void setFraction(float f) {
            frac = Math.max(0f, Math.min(1f, f));
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;
            float mid = h / 2f;
            float x = frac * w;
            float rBar = dp(2);
            c.drawRoundRect(0, mid - rBar, w, mid + rBar, rBar, rBar, bgP);
            if (x > 0) c.drawRoundRect(0, mid - rBar, x, mid + rBar, rBar, rBar, fillP);
            float thumbR = dp(9);
            c.drawCircle(x, mid, thumbR + dp(3), haloP);
            c.drawCircle(x, mid, thumbR, thumbP);
        }

        private void seekToX(float x) {
            if (player == null) return;
            long dur = player.getDuration();
            if (dur <= 0) return;
            float f = Math.max(0f, Math.min(1f, x / Math.max(1, getWidth())));
            long target = (long) (f * dur);
            if (player.isCurrentMediaItemSeekable()) {
                player.seekTo(target);
            } else {
                seekViaServer(target);
            }
            setFraction(f);
            updateTime();
        }

        @Override
        public boolean onTouchEvent(MotionEvent ev) {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);
                    dragging = true;
                    seekToX(ev.getX());
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (dragging) seekToX(ev.getX());
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (dragging) {
                        dragging = false;
                        getParent().requestDisallowInterceptTouchEvent(false);
                        showControls();
                    }
                    return true;
            }
            return super.onTouchEvent(ev);
        }
    }

    /* ---------- Phát ---------- */

    private Map<String, String> authHeaders() {
        Map<String, String> hs = new HashMap<>();
        String tk = token;
        if (tk != null && !tk.isEmpty()) hs.put("Authorization", "Bearer " + tk);
        return hs;
    }

    private void buildPlayer(String url, String name) {
        HttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setConnectTimeoutMs(10000)
                .setReadTimeoutMs(30000)
                .setKeepPostFor302Redirects(true)
                .setAllowCrossProtocolRedirects(true)
                .setDefaultRequestProperties(authHeaders());
        DataSource.Factory upstream = new DefaultDataSource.Factory(this, http);

        DefaultExtractorsFactory extractorsFactory = new DefaultExtractorsFactory()
                .setConstantBitrateSeekingEnabled(true)
                .setMatroskaExtractorFlags(MatroskaExtractor.FLAG_EMIT_RAW_SUBTITLE_DATA);

        MediaSource.Factory mf = new DefaultMediaSourceFactory(upstream, extractorsFactory);

        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(
                        1000,
                        15000,
                        500,
                        2000
                )
                .setTargetBufferBytes(32 * 1024 * 1024)
                .setPrioritizeTimeOverSizeThresholds(true)
                .setBackBuffer(10000, true)
                .build();

        DefaultRenderersFactory renderersFactory = new DefaultRenderersFactory(this)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
                .setEnableDecoderFallback(true)
                .setEnableAudioTrackPlaybackParams(true);

        AudioAttributes audioAttrs = new AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .setFlags(C.FLAG_AUDIBILITY_ENFORCED)
                .build();

        DefaultTrackSelector trackSelector = new DefaultTrackSelector(this);
        DefaultTrackSelector.Parameters trackParams = trackSelector.buildUponParameters()
                .setTunnelingEnabled(false)
                .setAllowAudioMixedMimeTypeAdaptiveness(true)
                .setAllowAudioMixedChannelCountAdaptiveness(true)
                .setMaxAudioChannelCount(2)
                .build();
        trackSelector.setParameters(trackParams);

        player = new ExoPlayer.Builder(this, renderersFactory)
                .setTrackSelector(trackSelector)
                .setMediaSourceFactory(mf)
                .setLoadControl(loadControl)
                .setSeekParameters(SeekParameters.CLOSEST_SYNC)
                .setWakeMode(C.WAKE_MODE_NETWORK)
                .setAudioAttributes(audioAttrs, true)
                .setHandleAudioBecomingNoisy(true)
                .build();
        player.addListener(this);
        loadItem(url, name);
    }

    private void loadItem(String url, String name) {
        if (player == null) return;

        String rel = getIntent().getStringExtra("rel");
        String pool = getIntent().getStringExtra("pool");
        String finalPlayUrl = url;

        // Nếu url là local file (ví dụ mở từ Video Offline)
        if (url != null && (url.startsWith("/") || new File(url).exists())) {
            finalPlayUrl = url;
            cancelBackgroundPreload();
        } else {
            // 1. Kiểm tra xem file video đã được Tải trước (Offline Media) chưa (ưu tiên cao nhất)
            File offlineFull = getOfflineVideoFile(pool, rel, name);
            if (offlineFull.exists() && offlineFull.length() > 0) {
                offlineFull.setLastModified(System.currentTimeMillis());
                finalPlayUrl = offlineFull.getAbsolutePath();
                cancelBackgroundPreload();
            } else {
                // 2. Kiểm tra xem file video đã được tải full 100% về Session Cache chưa
                File localFull = getSessionVideoFile(pool, rel, name);
                if (localFull.exists() && localFull.length() > 0) {
                    localFull.setLastModified(System.currentTimeMillis());
                    finalPlayUrl = localFull.getAbsolutePath();
                    cancelBackgroundPreload();
                } else {
                    // Chưa có file full -> Lên lịch tải ngầm sau 10 giây xem
                    scheduleBackgroundPreload(url, token, pool, rel, name);
                }
            }
        }

        Uri playUri;
        if (finalPlayUrl != null && (finalPlayUrl.startsWith("/") || new File(finalPlayUrl).exists())) {
            playUri = Uri.fromFile(new File(finalPlayUrl));
        } else {
            playUri = Uri.parse(finalPlayUrl != null ? finalPlayUrl : "");
        }

        MediaMetadata meta = new MediaMetadata.Builder()
                .setTitle(name == null || name.isEmpty() ? "Đang phát" : name)
                .build();
        player.setMediaItem(new MediaItem.Builder()
                .setUri(playUri)
                .setMediaMetadata(meta)
                .build());
        if (surface.isAvailable()) attachPlayerSurface();
        player.setVideoScalingMode(scalingMode);
        player.setVolume(muted ? 0f : 1f);
        player.setPlaybackSpeed(SPEEDS[speedIndex]);
        player.setRepeatMode(repeating ? Player.REPEAT_MODE_ONE : Player.REPEAT_MODE_OFF);
        player.prepare();
        long explicitStartPos = getIntent().getLongExtra("startPos", -1);
        if (explicitStartPos == 0) {
            String key = getPosKey(name, url);
            getSharedPreferences("cw_video_progress", MODE_PRIVATE).edit().remove(key).apply();
            player.seekTo(0);
            showToast("Phát lại từ đầu");
        } else if (explicitStartPos > 0) {
            player.seekTo(explicitStartPos);
            showToast("Đang phát tiếp từ " + fmtTime(explicitStartPos));
        } else {
            long savedPos = getSavedPosition(name, url);
            if (savedPos > 3000) {
                player.seekTo(savedPos);
                showToast("Đang phát tiếp từ " + fmtTime(savedPos));
            }
        }
        player.setPlayWhenReady(true);
        titleView.setText(name == null || name.isEmpty() ? "Đang phát" : name);
        videoUrl = url;
        videoName = name;
        updateFavUi();
    }

    private File getOfflineVideoFile(String pool, String rel, String name) {
        File dir = new File(getFilesDir(), "offline_media");
        if (!dir.exists()) dir.mkdirs();
        String key = md5((pool != null && !pool.isEmpty() ? pool : "main") + ":" + (rel != null && !rel.isEmpty() ? rel : (name != null ? name : "vid")) + ":vid");
        return new File(dir, key + ".mp4");
    }

    private void scheduleBackgroundPreload(String streamUrl, String token, String pool, String rel, String name) {
        cancelBackgroundPreload();
        isPreloadCancelled = false;
        preloadRunnable = () -> triggerBackgroundPreload(streamUrl, token, pool, rel, name);
        h.postDelayed(preloadRunnable, 10000); // Đếm 10 giây xem thực tế
    }

    private void cancelBackgroundPreload() {
        isPreloadCancelled = true;
        if (preloadRunnable != null) {
            h.removeCallbacks(preloadRunnable);
            preloadRunnable = null;
        }
    }

    private File getSessionVideoFile(String pool, String rel, String name) {
        File dir = new File(getCacheDir(), "session_media");
        if (!dir.exists()) dir.mkdirs();
        String key = md5((pool != null && !pool.isEmpty() ? pool : "main") + ":" + (rel != null && !rel.isEmpty() ? rel : (name != null ? name : "vid")) + ":vid");
        return new File(dir, key + ".mp4");
    }

    private File getSessionPartFile(String pool, String rel, String name) {
        File dir = new File(getCacheDir(), "session_media");
        if (!dir.exists()) dir.mkdirs();
        String key = md5((pool != null && !pool.isEmpty() ? pool : "main") + ":" + (rel != null && !rel.isEmpty() ? rel : (name != null ? name : "vid")) + ":vid");
        return new File(dir, key + ".part");
    }

    private void triggerBackgroundPreload(String streamUrl, String token, String pool, String rel, String name) {
        if (isFinishing() || isDestroyed()) return;
        final File fullFile = getSessionVideoFile(pool, rel, name);
        final File partFile = getSessionPartFile(pool, rel, name);
        if (fullFile.exists() && fullFile.length() > 0) return;

        preloadExecutor.execute(() -> {
            java.net.HttpURLConnection conn = null;
            java.io.FileOutputStream fos = null;
            try {
                long existingBytes = (partFile.exists() && partFile.isFile()) ? partFile.length() : 0;
                java.net.URL u = new java.net.URL(streamUrl);
                conn = (java.net.HttpURLConnection) u.openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(60000);
                if (token != null && !token.isEmpty()) {
                    conn.setRequestProperty("Authorization", "Bearer " + token);
                }
                if (existingBytes > 0) {
                    conn.setRequestProperty("Range", "bytes=" + existingBytes + "-");
                }
                conn.connect();
                int code = conn.getResponseCode();

                boolean append = false;
                if (code == 206) {
                    append = true;
                } else if (code == 200) {
                    append = false;
                    existingBytes = 0;
                } else if (code == 416) {
                    // Đã tải xong đủ dung lượng
                    if (partFile.exists() && partFile.length() > 0) {
                        partFile.renameTo(fullFile);
                        trimSessionMediaCache(15L * 1024 * 1024 * 1024);
                    }
                    return;
                } else {
                    return;
                }

                fos = new java.io.FileOutputStream(partFile, append);
                java.io.InputStream is = conn.getInputStream();
                byte[] buf = new byte[64 * 1024];
                int n;
                while (!isPreloadCancelled && (n = is.read(buf)) != -1) {
                    fos.write(buf, 0, n);
                }
                fos.flush();

                if (!isPreloadCancelled) {
                    fos.close();
                    fos = null;
                    if (partFile.exists() && partFile.length() > 0) {
                        partFile.renameTo(fullFile);
                        trimSessionMediaCache(15L * 1024 * 1024 * 1024);
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (fos != null) { try { fos.close(); } catch (Exception ignored) {} }
                if (conn != null) { conn.disconnect(); }
            }
        });
    }

    private void trimSessionMediaCache(long maxBytes) {
        try {
            File dir = new File(getCacheDir(), "session_media");
            if (!dir.exists() || !dir.isDirectory()) return;
            File[] files = dir.listFiles();
            if (files == null || files.length == 0) return;

            long total = 0;
            for (File f : files) {
                if (f.isFile()) total += f.length();
            }

            if (total <= maxBytes) return;

            java.util.Arrays.sort(files, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
            for (File f : files) {
                if (total <= maxBytes) break;
                long len = f.length();
                if (f.delete()) {
                    total -= len;
                }
            }
        } catch (Exception ignored) {}
    }

    private void attachPlayerSurface() {
        if (player != null && surface.isAvailable()) {
            player.setVideoTextureView(surface);
        }
    }

    /* Giữ CPU chạy khi tắt màn hình để video/âm thanh tiếp tục phát
     * (mạng cục bộ 127.0.0.1 + bộ giải mã cần CPU thức). */
    private void acquireWake() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                if (wakeLock == null) wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "cw:datacenter-player");
                if (!wakeLock.isHeld()) wakeLock.acquire(6L * 60 * 60 * 1000);
            }
        } catch (Exception ignored) {}
    }

    private void releaseWake() {
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) {}
        wakeLock = null;
    }

    private boolean isScreenOn() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            return pm != null && pm.isInteractive();
        } catch (Exception e) {
            return true;
        }
    }

    /* ---------- Điều khiển ---------- */

    private void onSurfaceTap() {
        if (locked) {
            pulseUnlock();
            return;
        }
        if (!controlsShown) { showControls(); return; }
        if (isPlaying()) { hideControls(); } else { showControls(); }
    }

    private boolean isPlaying() {
        return player != null && player.getPlayWhenReady()
                && player.getPlaybackState() == Player.STATE_READY;
    }

    private void showControls() {
        controlsShown = true;
        topBar.setAlpha(1f);
        centerControls.setAlpha(1f);
        bottom.setAlpha(1f);
        topBar.setTranslationY(0);
        bottom.setTranslationY(0);
        topBar.setVisibility(View.VISIBLE);
        centerControls.setVisibility(View.VISIBLE);
        bottom.setVisibility(View.VISIBLE);
        h.removeCallbacks(hideRunnable);
        if (isPlaying() && !locked) h.postDelayed(hideRunnable, CONTROLS_HIDE_DELAY);
    }

    private void hideControls() {
        if (!isPlaying() || locked) return;
        controlsShown = false;
        hideSheet();
        h.removeCallbacks(hideRunnable);
        h.post(() -> {
            topBar.animate().alpha(0f).translationY(-dp(12)).setDuration(220).start();
            bottom.animate().alpha(0f).translationY(dp(12)).setDuration(220).start();
            centerControls.animate().alpha(0f).setDuration(220).start();
        });
        h.postDelayed(() -> {
            if (!controlsShown) {
                topBar.setVisibility(View.INVISIBLE);
                bottom.setVisibility(View.INVISIBLE);
                centerControls.setVisibility(View.INVISIBLE);
            }
        }, 240);
    }

    private void togglePlay() {
        if (player == null) return;
        if (player.getPlaybackState() == Player.STATE_ENDED) {
            player.seekTo(0);
            player.setPlayWhenReady(true);
            showToast("Đang phát");
        } else if (isPlaying()) {
            player.pause();
            showToast("Đã tạm dừng");
        } else {
            player.play();
            showToast("Đang phát");
        }
        boolean playing = isPlaying();
        playBtn.setImageResource(playing ? R.drawable.ic_pl_pause : R.drawable.ic_pl_play);
        if (playing) showControls();
        else { showControls(); h.removeCallbacks(hideRunnable); }
    }

    private void skip(long ms) {
        if (player == null) return;
        long dur = player.getDuration();
        long current = player.getCurrentPosition();
        long target = current + ms;
        if (dur > 0) {
            target = Math.max(0, Math.min(dur, target));
        } else {
            target = Math.max(0, target);
        }
        if (player.isCurrentMediaItemSeekable()) {
            player.seekTo(target);
        } else {
            seekViaServer(target);
        }
        updateTime();
        showToast(ms > 0 ? "Tiến 10 giây" : "Lùi 10 giây");
        showControls();
    }

    private void seekViaServer(long targetMs) {
        if (player == null || videoUrl == null) return;
        long sec = Math.max(0, targetMs / 1000);
        String newUrl = videoUrl.replaceAll("[?&]ss=\\d+", "");
        newUrl += (newUrl.contains("?") ? "&" : "?") + "ss=" + sec;

        MediaMetadata meta = new MediaMetadata.Builder()
                .setTitle(videoName == null || videoName.isEmpty() ? "Đang phát" : videoName)
                .build();
        player.setMediaItem(new MediaItem.Builder()
                .setUri(newUrl)
                .setMediaMetadata(meta)
                .build());
        player.prepare();
        player.play();
    }

    private void toggleVolume() {
        muted = !muted;
        if (player != null) player.setVolume(muted ? 0f : 1f);
        if (volumeBtn != null) volumeBtn.setImageResource(muted ? R.drawable.ic_pl_vol_off : R.drawable.ic_pl_vol_on);
        showToast(muted ? "Đã tắt tiếng" : "Đã bật tiếng");
    }

    private void toggleLock() {
        locked = !locked;
        hideSheet();
        updateLockUi();
        if (locked) {
            showToast("Đã khóa điều khiển — chạm nút mở khóa để mở");
            h.removeCallbacks(hideRunnable);
            hideControlsForced();
        } else {
            showToast("Đã mở khóa điều khiển");
            showControls();
        }
    }

    private void hideControlsForced() {
        controlsShown = false;
        topBar.animate().alpha(0f).setDuration(200).start();
        centerControls.animate().alpha(0f).setDuration(200).start();
        bottom.animate().alpha(0f).setDuration(200).start();
        h.postDelayed(() -> {
            topBar.setVisibility(View.INVISIBLE);
            bottom.setVisibility(View.INVISIBLE);
            centerControls.setVisibility(View.INVISIBLE);
        }, 220);
    }

    private void updateLockUi() {
        if (locked) {
            unlockBtn.animate().alpha(1f).setDuration(200).start();
            unlockBtn.setEnabled(true);
            unlockBtn.setVisibility(View.VISIBLE);
        } else {
            unlockBtn.animate().alpha(0f).setDuration(200).start();
            h.postDelayed(() -> { if (!locked) unlockBtn.setVisibility(View.INVISIBLE); }, 220);
        }
    }

    private void pulseUnlock() {
        unlockBtn.animate().scaleX(1.15f).scaleY(1.15f).setDuration(120).withEndAction(() ->
                unlockBtn.animate().scaleX(1f).scaleY(1f).setDuration(120).start()).start();
        showToast("Đang khóa — chạm nút tròn bên trái để mở khóa");
    }

    private void cycleSpeed() {
        speedIndex = (speedIndex + 1) % SPEEDS.length;
        float v = SPEEDS[speedIndex];
        if (player != null) player.setPlaybackSpeed(v);
        String label = v == 1f ? "Tốc độ" : trimX(v) + "×";
        if (speedLabel != null) speedLabel.setText(label);
        showToast("Tốc độ " + trimX(v) + "×");
    }

    private static String trimX(float v) {
        String s = String.valueOf(v);
        return s.endsWith(".0") ? s.substring(0, s.length() - 2) : s;
    }

    private void toggleRepeat() {
        repeating = !repeating;
        if (player != null) player.setRepeatMode(repeating ? Player.REPEAT_MODE_ONE : Player.REPEAT_MODE_OFF);
        showToast(repeating ? "Đã bật lặp lại" : "Đã tắt lặp lại");
        updateActionButtons();
    }

    private void updateActionButtons() {
        if (lockActionBg != null) lockActionBg.setColor(locked ? 0x1FFFFFFF : 0x00000000);
        if (repeatActionBg != null) repeatActionBg.setColor(repeating ? 0x1FFFFFFF : 0x00000000);
    }

    private void toggleFit() {
        fitToScreen = !fitToScreen;
        adjustAspectRatio();
        showToast(fitToScreen ? "Vừa màn hình (cắt bớt)" : "Vừa màn hình");
    }

    private void adjustAspectRatio() {
        if (surface == null) return;
        int viewWidth = surface.getWidth();
        int viewHeight = surface.getHeight();
        if (viewWidth <= 0 || viewHeight <= 0) return;

        float videoAspect = (videoWidth > 0 && videoHeight > 0)
                ? (float) videoWidth / (float) videoHeight
                : (16f / 9f);
        float viewAspect = (float) viewWidth / (float) viewHeight;

        float scaleX = 1.0f;
        float scaleY = 1.0f;

        if (!fitToScreen) {
            // Chế độ Vừa màn hình: Giữ nguyên 100% tỉ lệ 16:9 (nghiêm cấm méo, kéo dài hay co dãn)
            if (viewAspect > videoAspect) {
                // Màn hình ngang rộng hơn video (Landscape): Co chiều ngang lại theo đúng tỉ lệ 16:9
                scaleX = (viewHeight * videoAspect) / (float) viewWidth;
                scaleY = 1.0f;
            } else {
                // Màn hình dọc cao hơn video (Portrait): Co chiều dọc lại theo đúng tỉ lệ 16:9
                scaleX = 1.0f;
                scaleY = (viewWidth / videoAspect) / (float) viewHeight;
            }
        } else {
            // Chế độ Cắt bớt: Lấp đầy màn hình nhưng vẫn giữ đúng tỉ lệ gốc 16:9
            if (viewAspect > videoAspect) {
                scaleX = 1.0f;
                scaleY = viewAspect / videoAspect;
            } else {
                scaleX = videoAspect / viewAspect;
                scaleY = 1.0f;
            }
        }

        Matrix matrix = new Matrix();
        matrix.setScale(scaleX, scaleY, viewWidth / 2f, viewHeight / 2f);
        surface.setTransform(matrix);
        surface.invalidate();
    }

    private void toggleOrientation() {
        int cur = getResources().getConfiguration().orientation;
        if (cur == Configuration.ORIENTATION_LANDSCAPE) {
            setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
        } else {
            setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        }
    }

    /* ---------- Sheets ---------- */

    private void toggleSheet(String id) {
        if (sheetId != null && sheetId.equals(id)) { hideSheet(); return; }
        sheetId = id;
        buildSheet(id);
        sheetBox.clearAnimation();
        sheetBox.setAlpha(1f);
        sheetBox.setEnabled(true);
        sheetBox.setVisibility(View.VISIBLE);
        showControls();
        h.removeCallbacks(hideRunnable);
    }

    private void hideSheet() {
        sheetId = null;
        sheetBox.animate().alpha(0f).setDuration(180).withEndAction(() ->
                sheetBox.setVisibility(View.INVISIBLE)).start();
        sheetBox.setEnabled(false);
        if (isPlaying() && !locked) scheduleAutoHide();
    }

    private void scheduleAutoHide() {
        h.removeCallbacks(hideRunnable);
        h.postDelayed(hideRunnable, CONTROLS_HIDE_DELAY);
    }

    private void sheetRow(String left, String right, Runnable onClick) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10), dp(12), dp(10), dp(12));
        TextView l = new TextView(this);
        l.setText(left);
        l.setTextColor(Color.WHITE);
        l.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        l.setSingleLine(true);
        l.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        row.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView r = new TextView(this);
        r.setText(right);
        r.setTextColor(0xBDFFFFFF);
        r.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        row.addView(r);
        if (onClick != null) row.setOnClickListener(v -> onClick.run());
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sheetList.addView(row, rlp);
    }

    private void buildSheet(String id) {
        sheetList.removeAllViews();
        switch (id) {
            case "playlistSheet": {
                sheetTitle.setText("Danh sách phát");
                if (playlist.isEmpty()) {
                    sheetRow(videoName == null ? "Đang phát" : videoName, fmtTime(player == null ? 0 : player.getDuration()), null);
                } else {
                    for (int i = 0; i < playlist.size(); i++) {
                        final int idx = i;
                        PlItem it = playlist.get(i);
                        boolean current = i == plIndex;
                        sheetRow((current ? "▶ " : "") + it.name, current ? "Đang phát" : "",
                                () -> playPlItem(idx));
                    }
                }
                break;
            }
            case "settingsSheet": {
                sheetTitle.setText("Cài đặt");
                sheetRow("Chất lượng", "Gốc", null);
                sheetRow("Phụ đề", "Tắt", () -> showToast("Không có phụ đề cho video này"));
                sheetRow("Âm thanh", "Stereo", () -> {
                    toggleVolume();
                    hideSheet();
                });
                sheetRow("Tốc độ phát", trimX(SPEEDS[speedIndex]) + "×", () -> {
                    cycleSpeed();
                    buildSheet("settingsSheet");
                });
                break;
            }
            case "moreSheet": {
                sheetTitle.setText("Tùy chọn khác");
                sheetRow("Thông tin tệp", "MP4" + (fmtSizeBytes().isEmpty() ? "" : " · " + fmtSizeBytes()), null);
                sheetRow("Mở bằng ứng dụng khác", "›", () -> {
                    try {
                        String bUrl = getIntent().getStringExtra("baseUrl");
                        if (bUrl == null || bUrl.isEmpty()) {
                            bUrl = getSharedPreferences("cw-datacenter", MODE_PRIVATE).getString("base_url", "");
                        }
                        String tk = token;
                        if (tk == null || tk.isEmpty()) {
                            tk = getSharedPreferences("cw-datacenter", MODE_PRIVATE).getString("player_token", "");
                        }

                        File localFile = null;
                        if (videoUrl != null) {
                            if (videoUrl.startsWith("file://")) {
                                try { localFile = new File(Uri.parse(videoUrl).getPath()); } catch (Exception ignored) {}
                            } else if (videoUrl.startsWith("/")) {
                                localFile = new File(videoUrl);
                            }
                        }

                        Intent i = new Intent(Intent.ACTION_VIEW);
                        int idx = videoName != null ? videoName.lastIndexOf('.') : -1;
                        String ext = idx >= 0 ? videoName.substring(idx + 1).toLowerCase() : "";
                        String mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
                        if (mime == null || mime.isEmpty()) mime = "video/*";

                        if (localFile != null && localFile.exists() && localFile.isFile()) {
                            Uri uri = StreamProvider.uriFor(this, localFile);
                            i.setDataAndType(uri, mime);
                        } else {
                            String directUrl = videoUrl;
                            String pathParam = null;
                            String poolParam = null;
                            if (videoUrl != null && videoUrl.contains("/play?")) {
                                try {
                                    Uri parsed = Uri.parse(videoUrl);
                                    pathParam = parsed.getQueryParameter("path");
                                    poolParam = parsed.getQueryParameter("pool");
                                } catch (Exception ignored) {}
                            }
                            if (pathParam != null && bUrl != null && !bUrl.isEmpty()) {
                                StringBuilder sb = new StringBuilder(bUrl).append("/api/video?path=").append(java.net.URLEncoder.encode(pathParam, "UTF-8"));
                                if (poolParam != null && !poolParam.isEmpty()) {
                                    sb.append("&pool=").append(java.net.URLEncoder.encode(poolParam, "UTF-8"));
                                }
                                if (tk != null && !tk.isEmpty()) {
                                    sb.append("&token=").append(java.net.URLEncoder.encode(tk, "UTF-8"));
                                }
                                directUrl = sb.toString();
                            }
                            i.setDataAndType(Uri.parse(directUrl), mime);
                        }

                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(Intent.createChooser(i, "Mở video bằng"));
                    } catch (Exception e) {
                        showToast("Không mở được bằng ứng dụng khác: " + e.getMessage());
                    }
                    hideSheet();
                });
                break;
            }
            case "castSheet": {
                sheetTitle.setText("Truyền lên Smart TV");
                if (mDlnaDevices.isEmpty()) {
                    sheetRow(mScanningDlna ? "🔍 Đang quét Smart TV trong mạng…" : "Không tìm thấy Smart TV nào",
                            mScanningDlna ? "" : "Quét lại",
                            mScanningDlna ? null : this::startDlnaDiscovery);
                } else {
                    for (DlnaManager.DlnaDevice dev : mDlnaDevices) {
                        sheetRow("📺 " + dev.name, dev.host, () -> castToDevice(dev));
                    }
                    sheetRow("🔄 Quét lại thiết bị", "", this::startDlnaDiscovery);
                }
                break;
            }
        }
    }

    private void playPlItem(int idx) {
        if (idx < 0 || idx >= playlist.size()) return;
        plIndex = idx;
        PlItem it = playlist.get(idx);
        loadItem(it.url, it.name);
        hideSheet();
        showToast("Đang phát " + it.name);
        showControls();
    }

    private String fmtSizeBytes() {
        long size = plIndex >= 0 && plIndex < playlist.size() ? playlist.get(plIndex).size : getIntent().getLongExtra("size", 0);
        if (size <= 0) return "";
        if (size < 1024 * 1024) return (size / 1024) + " KB";
        if (size < 1024L * 1024 * 1024) return String.format(java.util.Locale.US, "%.1f MB", size / 1024f / 1024f);
        return String.format(java.util.Locale.US, "%.2f GB", size / 1024f / 1024f / 1024f);
    }

    /* ---------- Toast chip ---------- */

    private final Runnable toastHide = () -> toastView.animate().alpha(0f).setDuration(200).start();

    private void showToast(String msg) {
        h.removeCallbacks(toastHide);
        toastView.setText(msg);
        toastView.animate().alpha(1f).setDuration(160).start();
        h.postDelayed(toastHide, 1300);
    }

    /* ---------- Thời gian ---------- */

    private static String fmtTime(long ms) {
        if (ms <= 0) ms = 0;
        long s = ms / 1000;
        long h = s / 3600;
        s %= 3600;
        long m = s / 60;
        long ss = s % 60;
        return h > 0
                ? String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, ss)
                : String.format(java.util.Locale.US, "%02d:%02d", m, ss);
    }

    private void updateTime() {
        if (player == null) return;
        long cur = Math.max(0, player.getCurrentPosition());
        long dur = Math.max(0, player.getDuration());
        curTime.setText(fmtTime(cur));
        durTime.setText(fmtTime(dur));
        track.setFraction(dur > 0 ? (float) cur / dur : 0f);
    }

    /* ---------- Player.Listener ---------- */

    @Override
    public void onIsPlayingChanged(boolean playing) {
        if (playBtn != null) {
            playBtn.setImageResource(playing ? R.drawable.ic_pl_pause : R.drawable.ic_pl_play);
        }
        if (playing) { showControls(); } else { h.removeCallbacks(hideRunnable); }
    }

    @Override
    public void onPlaybackStateChanged(int playbackState) {
        if (playbackState == Player.STATE_ENDED) {
            if (player != null) playBtn.setImageResource(R.drawable.ic_pl_play);
            showControls();
        } else if (playbackState == Player.STATE_READY) {
            errorRetryCount = 0;
            updateTime();
        }
    }

    @Override
    public void onVideoSizeChanged(VideoSize videoSize) {
        if (videoSize != null && videoSize.width > 0 && videoSize.height > 0) {
            videoWidth = videoSize.width;
            videoHeight = videoSize.height;
            adjustAspectRatio();
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        h.postDelayed(this::adjustAspectRatio, 60);
    }

    private int errorRetryCount = 0;

    @Override
    public void onPlayerError(PlaybackException error) {
        if (errorRetryCount < 2) {
            errorRetryCount++;
            final long pos = (player != null) ? player.getCurrentPosition() : 0;
            showToast("Đang kết nối lại luồng video...");
            if (player != null) {
                h.postDelayed(() -> {
                    try {
                        if (player != null && !isFinishing()) {
                            player.prepare();
                            if (pos > 0) player.seekTo(pos);
                            player.play();
                        }
                    } catch (Exception ignored) {}
                }, 1200);
            }
        } else {
            String code = error != null ? error.getErrorCodeName() : "Không xác định";
            Toast.makeText(this, "Không thể phát được định dạng này (" + code + ").\nHãy thử tải về hoặc kiểm tra lại tệp.", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private String getPosKey(String name, String url) {
        return "vpos_" + (name != null && !name.isEmpty() ? name : (url != null ? url.hashCode() : "vid"));
    }

    private long getSavedPosition(String name, String url) {
        try {
            return getSharedPreferences("cw_video_progress", MODE_PRIVATE).getLong(getPosKey(name, url), 0);
        } catch (Exception e) {
            return 0;
        }
    }

    private void savePosition() {
        if (player == null) return;
        try {
            long cur = player.getCurrentPosition();
            long dur = player.getDuration();
            String key = getPosKey(videoName, videoUrl);
            android.content.SharedPreferences.Editor edit = getSharedPreferences("cw_video_progress", MODE_PRIVATE).edit();
            if (dur > 0 && cur >= dur - 5000) {
                edit.remove(key).apply();
            } else if (cur > 2000) {
                edit.putLong(key, cur).apply();
            }
        } catch (Exception ignored) {}
    }

    @Override
    public boolean dispatchKeyEvent(android.view.KeyEvent event) {
        int code = event.getKeyCode();
        if (code == android.view.KeyEvent.KEYCODE_BACK || code == android.view.KeyEvent.KEYCODE_ESCAPE) {
            if (event.getAction() == android.view.KeyEvent.ACTION_UP || event.getAction() == android.view.KeyEvent.ACTION_DOWN) {
                if (sheetId != null) { hideSheet(); return true; }
                savePosition();
                finish();
            }
            return true;
        }

        if (event.getAction() == android.view.KeyEvent.ACTION_DOWN) {
            if (code == android.view.KeyEvent.KEYCODE_DPAD_CENTER || code == android.view.KeyEvent.KEYCODE_ENTER || code == android.view.KeyEvent.KEYCODE_NUMPAD_ENTER || code == android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || code == android.view.KeyEvent.KEYCODE_SPACE) {
                togglePlay();
                return true;
            }
            if (code == android.view.KeyEvent.KEYCODE_MEDIA_PLAY) {
                if (player != null && !player.isPlaying()) player.play();
                showControls();
                return true;
            }
            if (code == android.view.KeyEvent.KEYCODE_MEDIA_PAUSE) {
                if (player != null && player.isPlaying()) player.pause();
                showControls();
                return true;
            }
            if (code == android.view.KeyEvent.KEYCODE_DPAD_LEFT || code == android.view.KeyEvent.KEYCODE_MEDIA_REWIND) {
                skip(-10_000);
                return true;
            }
            if (code == android.view.KeyEvent.KEYCODE_DPAD_RIGHT || code == android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD) {
                skip(10_000);
                return true;
            }
            if (code == android.view.KeyEvent.KEYCODE_DPAD_UP || code == android.view.KeyEvent.KEYCODE_DPAD_DOWN) {
                showControls();
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public void onBackPressed() {
        if (sheetId != null) { hideSheet(); return; }
        savePosition();
        super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        savePosition();
        h.removeCallbacks(tickRunnable);
        if (!isScreenOn()) return;
        if (player != null) player.pause();
        releaseWake();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (player != null) {
            player.setPlayWhenReady(true);
        }
        acquireWake();
        h.post(tickRunnable);
        if (Build.VERSION.SDK_INT >= 26) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    @Override
    protected void onStop() {
        savePosition();
        super.onStop();
    }

    /* ---------- CHIA SẺ VIDEO ---------- */
    private void shareCurrentVideo() {
        if (videoUrl == null || videoUrl.isEmpty()) {
            showToast("Không có đường dẫn chia sẻ video");
            return;
        }

        if (videoUrl.startsWith("file://")) {
            try {
                File f = new File(Uri.parse(videoUrl).getPath());
                if (f.exists() && f.isFile()) {
                    launchShareIntent(f, videoName);
                    return;
                }
            } catch (Exception ignored) {}
        }

        File localFile = new File(videoUrl);
        if (localFile.exists() && localFile.isFile()) {
            launchShareIntent(localFile, videoName);
            return;
        }

        // Kiểm tra xem video đã có sẵn trong Offline Media hoặc Session Cache chưa để chia sẻ tức thì
        String rel = getIntent().getStringExtra("rel");
        String pool = getIntent().getStringExtra("pool");
        File offlineF = getOfflineVideoFile(pool, rel, videoName);
        if (offlineF.exists() && offlineF.length() > 0) {
            launchShareIntent(offlineF, videoName);
            return;
        }

        File sessionF = getSessionVideoFile(pool, rel, videoName);
        if (sessionF.exists() && sessionF.length() > 0) {
            launchShareIntent(sessionF, videoName);
            return;
        }

        showToast("Đang chuẩn bị chia sẻ video…");

        executor.execute(() -> {
            try {
                File cacheDir = new File(getCacheDir(), "shared_videos");
                if (!cacheDir.exists()) cacheDir.mkdirs();

                String fileName = videoName != null && !videoName.isEmpty() ? videoName : "video_" + System.currentTimeMillis() + ".mp4";
                File destFile = new File(cacheDir, fileName);

                java.net.URL u = new java.net.URL(videoUrl);
                java.net.HttpURLConnection conn = (java.net.HttpURLConnection) u.openConnection();
                if (token != null && !token.isEmpty()) {
                    conn.setRequestProperty("Authorization", "Bearer " + token);
                }
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(60000);
                conn.connect();

                if (conn.getResponseCode() >= 200 && conn.getResponseCode() < 300) {
                    try (java.io.InputStream is = conn.getInputStream(); java.io.FileOutputStream fos = new java.io.FileOutputStream(destFile)) {
                        byte[] buf = new byte[65536];
                        int r;
                        while ((r = is.read(buf)) != -1) {
                            fos.write(buf, 0, r);
                        }
                        fos.flush();
                    }
                    h.post(() -> launchShareIntent(destFile, fileName));
                } else {
                    int respCode = conn.getResponseCode();
                    h.post(() -> showToast("Không thể tải video để chia sẻ (mã " + respCode + ")"));
                }
            } catch (Exception e) {
                h.post(() -> showToast("Lỗi chia sẻ video: " + e.getMessage()));
            }
        });
    }

    private void launchShareIntent(File file, String name) {
        try {
            Uri contentUri = StreamProvider.uriFor(this, file);
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            int idx = name != null ? name.lastIndexOf('.') : -1;
            String ext = idx >= 0 ? name.substring(idx + 1).toLowerCase() : "";
            String mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
            if (mime == null || mime.isEmpty()) mime = "video/*";
            shareIntent.setType(mime);
            shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, name != null ? name : "Video");
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(shareIntent, "Chia sẻ video"));
        } catch (Exception e) {
            showToast("Lỗi mở trình chia sẻ: " + e.getMessage());
        }
    }

    private static String md5(String s) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            byte[] d = md.digest(s.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return String.valueOf(s.hashCode());
        }
    }

    /* ---------- FAVORITES ---------- */
    private void updateFavUi() {
        if (favBtn == null) return;
        boolean fav = isCurrentFavorited();
        favBtn.setImageResource(fav ? R.drawable.ic_photo_heart_on : R.drawable.ic_photo_heart_off);
        if (fav) {
            favBtn.setColorFilter(0xFFFF3B30);
        } else {
            favBtn.setColorFilter(Color.WHITE);
        }
    }

    private String favKey() {
        String base = getIntent().getStringExtra("baseUrl");
        if (base == null || base.isEmpty()) {
            base = getSharedPreferences("cw-datacenter", MODE_PRIVATE).getString("base_url", "");
        }
        return "dc_kv_favs:" + base;
    }

    private JSONArray getFavList() {
        String json = getSharedPreferences("cw-datacenter", MODE_PRIVATE).getString(favKey(), "[]");
        try {
            return new JSONArray(json);
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private boolean isCurrentFavorited() {
        JSONArray arr = getFavList();
        String name = videoName != null ? videoName : "";
        String rel = getIntent().getStringExtra("rel");
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String r = o.optString("rel", "");
            String n = o.optString("name", "");
            String u = o.optString("url", "");
            if (rel != null && !rel.isEmpty() && rel.equals(r)) return true;
            if (!name.isEmpty() && name.equals(n)) return true;
            if (videoUrl != null && !videoUrl.isEmpty() && videoUrl.equals(u)) return true;
        }
        return false;
    }

    private void toggleFavoriteCurrent() {
        JSONArray arr = getFavList();
        JSONArray nextArr = new JSONArray();
        boolean found = false;
        String name = videoName != null ? videoName : "";
        String rel = getIntent().getStringExtra("rel");
        String pool = getIntent().getStringExtra("pool");

        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String r = o.optString("rel", "");
            String n = o.optString("name", "");
            String u = o.optString("url", "");
            boolean match = false;
            if (rel != null && !rel.isEmpty() && rel.equals(r)) match = true;
            else if (!name.isEmpty() && name.equals(n)) match = true;
            else if (videoUrl != null && !videoUrl.isEmpty() && videoUrl.equals(u)) match = true;

            if (match) {
                found = true;
            } else {
                nextArr.put(o);
            }
        }

        if (!found) {
            JSONObject newFav = new JSONObject();
            try {
                newFav.put("name", name);
                newFav.put("rel", rel != null ? rel : name);
                newFav.put("pool", pool != null ? pool : "main");
                newFav.put("type", "file");
                newFav.put("url", videoUrl);
                long sz = plIndex >= 0 && plIndex < playlist.size() ? playlist.get(plIndex).size : getIntent().getLongExtra("size", 0);
                newFav.put("size", sz);
                nextArr.put(newFav);
                showToast("Đã thêm vào yêu thích");
            } catch (Exception ignored) {}
        } else {
            showToast("Đã bỏ khỏi yêu thích");
        }

        getSharedPreferences("cw-datacenter", MODE_PRIVATE).edit().putString(favKey(), nextArr.toString()).apply();
        updateFavUi();
    }

    /* ---------- DLNA CAST ---------- */
    private final List<DlnaManager.DlnaDevice> mDlnaDevices = new ArrayList<>();
    private boolean mScanningDlna = false;

    private void startDlnaDiscovery() {
        mScanningDlna = true;
        mDlnaDevices.clear();
        buildSheet("castSheet");
        DlnaManager.discoverDevices(this, 3500, new DlnaManager.DiscoveryCallback() {
            @Override
            public void onDeviceFound(DlnaManager.DlnaDevice device) {
                if (!mDlnaDevices.contains(device)) {
                    mDlnaDevices.add(device);
                    buildSheet("castSheet");
                }
            }

            @Override
            public void onDiscoveryFinished(List<DlnaManager.DlnaDevice> devices) {
                mScanningDlna = false;
                buildSheet("castSheet");
            }
        });
    }

    private void castToDevice(DlnaManager.DlnaDevice dev) {
        hideSheet();
        showToast("Đang kết nối tới " + dev.name + "…");
        String castUrl = getDirectCastUrl();
        DlnaManager.playMedia(dev, castUrl, videoName, "video/mp4", new DlnaManager.ActionCallback() {
            @Override
            public void onSuccess() {
                showToast("Đang phát trên " + dev.name);
                if (player != null && player.isPlaying()) {
                    player.pause();
                }
            }

            @Override
            public void onError(String error) {
                showToast("Không thể truyền tới TV: " + error);
            }
        });
    }

    private String getDirectCastUrl() {
        String base = getIntent().getStringExtra("baseUrl");
        if (base == null || base.isEmpty()) {
            base = getSharedPreferences("cw-datacenter", MODE_PRIVATE).getString("base_url", "");
        }
        String rel = getIntent().getStringExtra("rel");
        String pool = getIntent().getStringExtra("pool");
        String tok = getIntent().getStringExtra("token");
        if (tok == null || tok.isEmpty()) {
            tok = getSharedPreferences("cw-datacenter", MODE_PRIVATE).getString("player_token", "");
        }

        if (base != null && !base.isEmpty() && rel != null && !rel.isEmpty()) {
            try {
                String encRel = java.net.URLEncoder.encode(rel, "UTF-8");
                String encPool = (pool != null && !pool.isEmpty()) ? "&pool=" + java.net.URLEncoder.encode(pool, "UTF-8") : "";
                String encTok = (tok != null && !tok.isEmpty()) ? "&token=" + java.net.URLEncoder.encode(tok, "UTF-8") : "";
                return base.replaceAll("/+$", "") + "/api/file?path=" + encRel + encPool + encTok;
            } catch (Exception ignored) {}
        }

        if (videoUrl != null) {
            if (base != null && !base.isEmpty() && videoUrl.contains("127.0.0.1")) {
                return videoUrl.replaceFirst("http://127\\.0\\.0\\.1:\\d+", base);
            }
            return videoUrl;
        }
        return "";
    }

    @Override
    protected void onDestroy() {
        savePosition();
        cancelBackgroundPreload();
        try { preloadExecutor.shutdownNow(); } catch (Exception ignored) {}
        h.removeCallbacksAndMessages(null);
        releaseWake();
        if (player != null) {
            player.removeListener(this);
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}

