package com.cw.datacenter.tablet;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.barteksc.pdfviewer.PDFView;
import com.github.barteksc.pdfviewer.scroll.DefaultScrollHandle;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/* Đọc PDF trực tiếp trong app bằng AndroidPdfViewer (barteksc/AndroidPdfViewer):
 * - url: file trên server -> tải về cache một lần rồi mở (có tiến độ)
 * - path: file trên bộ nhớ máy -> mở thẳng
 * - uri: content:// (SAF / provider) -> mở thẳng */
public class PdfViewerActivity extends Activity {

    private PDFView pdfView;
    private TextView titleView;
    private TextView statusView;
    private TextView pageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF101318);
        getWindow().setNavigationBarColor(0xFF101318);

        Intent it = getIntent();
        String name = it.getStringExtra("name");
        final String url = it.getStringExtra("url");
        final String path = it.getStringExtra("path");
        final String uriStr = it.getStringExtra("uri");

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF101318);
        setContentView(root);

        pdfView = new PDFView(this, null);
        root.addView(pdfView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xE6101318);
        bar.setPadding(dp(8), dp(8), dp(14), dp(8));

        ImageButton back = new ImageButton(this);
        back.setImageResource(R.drawable.ic_pl_back);
        back.setColorFilter(Color.WHITE);
        back.setBackgroundColor(Color.TRANSPARENT);
        back.setContentDescription("Quay lại");
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));

        titleView = new TextView(this);
        titleView.setText(name == null || name.isEmpty() ? "PDF" : name);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setSingleLine(true);
        titleView.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tlp.leftMargin = dp(6);
        bar.addView(titleView, tlp);

        pageView = new TextView(this);
        pageView.setTextColor(0xBDFFFFFF);
        pageView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        bar.addView(pageView);

        LinearLayout barWrap = new LinearLayout(this);
        barWrap.setOrientation(LinearLayout.VERTICAL);
        barWrap.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(barWrap, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        statusView = new TextView(this);
        statusView.setTextColor(0xFF9AA4B2);
        statusView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        statusView.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        root.addView(statusView, slp);

        if (path != null && !path.isEmpty()) {
            loadFile(new File(path));
        } else if (uriStr != null && !uriStr.isEmpty()) {
            statusView.setText("Đang mở PDF…");
            try {
                pdfView.fromUri(Uri.parse(uriStr))
                        .scrollHandle(new DefaultScrollHandle(this))
                        .onPageChange((page, count) -> updatePage(page, count))
                        .onError(t -> onPdfError(t))
                        .load();
            } catch (Exception e) {
                onPdfError(e);
            }
        } else if (url != null && !url.isEmpty()) {
            downloadAndOpen(url, name);
        } else {
            Toast.makeText(this, "Không có tệp PDF để mở.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void updatePage(int page, int count) {
        pageView.setText((page + 1) + " / " + count);
    }

    private void onPdfError(Throwable t) {
        statusView.setText("Không đọc được tệp PDF này.");
        Toast.makeText(this, "Không đọc được tệp PDF này.", Toast.LENGTH_LONG).show();
    }

    private void loadFile(File f) {
        if (!f.exists()) {
            statusView.setText("Không tìm thấy tệp PDF trên máy.");
            Toast.makeText(this, "Không tìm thấy tệp PDF trên máy.", Toast.LENGTH_LONG).show();
            return;
        }
        statusView.setText("Đang mở PDF…");
        try {
            pdfView.fromFile(f)
                    .scrollHandle(new DefaultScrollHandle(this))
                    .onPageChange(this::updatePage)
                    .onError(this::onPdfError)
                    .load();
        } catch (Exception e) {
            onPdfError(e);
        }
    }

    /* Tải PDF từ server (qua proxy cục bộ 127.0.0.1 đã gắn sẵn token) vào cache. */
    private void downloadAndOpen(final String url, final String name) {
        statusView.setText("Đang tải PDF…");
        new AsyncTask<Void, Integer, File>() {
            private String err = "";

            @Override
            protected File doInBackground(Void... voids) {
                File out = null;
                HttpURLConnection conn = null;
                InputStream is = null;
                FileOutputStream fos = null;
                try {
                    conn = (HttpURLConnection) new URL(url).openConnection();
                    conn.setConnectTimeout(10000);
                    conn.setReadTimeout(60000);
                    int status = conn.getResponseCode();
                    if (status >= 400) { err = "HTTP " + status; return null; }
                    long total = conn.getContentLengthLong();
                    is = conn.getInputStream();
                    File dir = new File(getCacheDir(), "pdf");
                    if (!dir.exists()) dir.mkdirs();
                    String fn = safeName(name);
                    out = new File(dir, fn);
                    fos = new FileOutputStream(out);
                    byte[] buf = new byte[256 * 1024];
                    long done = 0;
                    int n;
                    int lastPc = -1;
                    while ((n = is.read(buf)) > 0) {
                        fos.write(buf, 0, n);
                        done += n;
                        if (total > 0) {
                            int pc = (int) (done * 100 / total);
                            if (pc != lastPc) { lastPc = pc; publishProgress(pc); }
                        }
                        if (isCancelled()) break;
                    }
                    fos.flush();
                    return out;
                } catch (Exception e) {
                    err = String.valueOf(e.getMessage());
                    if (out != null) out.delete();
                    return null;
                } finally {
                    try { if (fos != null) fos.close(); } catch (Exception ignored) {}
                    try { if (is != null) is.close(); } catch (Exception ignored) {}
                    if (conn != null) conn.disconnect();
                }
            }

            @Override
            protected void onProgressUpdate(Integer... vals) {
                statusView.setText("Đang tải PDF… " + vals[0] + "%");
            }

            @Override
            protected void onPostExecute(File f) {
                if (isFinishing()) return;
                if (f == null) {
                    statusView.setText("Không tải được tệp PDF" + (err.isEmpty() ? "." : " (" + err + ")."));
                    Toast.makeText(PdfViewerActivity.this,
                            "Không tải được tệp PDF. Hãy kiểm tra kết nối tới máy chủ.", Toast.LENGTH_LONG).show();
                    return;
                }
                statusView.setVisibility(View.GONE);
                loadFile(f);
            }
        }.execute();
    }

    private String safeName(String name) {
        String n = name == null || name.isEmpty() ? "doc.pdf" : name;
        n = n.replaceAll("[\\\\/:*?\"<>|]", "_");
        if (!n.toLowerCase(Locale.US).endsWith(".pdf")) {
            n = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date()) + "-" + n + ".pdf";
        }
        return n;
    }

    @Override
    protected void onDestroy() {
        try { if (pdfView != null) pdfView.recycle(); } catch (Exception ignored) {}
        super.onDestroy();
    }
}

