package com.cw.datacenter.android;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {

    private WebView webView;
    private Bridge bridge;
    private FrameLayout root;
    private volatile int bottomInsetPx = 0;
    private volatile int topInsetPx = 0;
    private FrameLayout fullscreenContainer;
    private View fullscreenView;
    private WebChromeClient.CustomViewCallback fullscreenCallback;
    private ChromeClient chromeClient;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<Integer, ActivityResultCallback> pendingResults = new HashMap<>();
    private final Map<Integer, PermCallback> pendingPerms = new HashMap<>();
    private final AtomicInteger requestCodeGen = new AtomicInteger(100);

    /* Kiểm tra APK ngay khi khởi động: cầu nối mới gom mọi method bất đồng bộ về
     * một method duy nhất DC.call(name, cbId, argsJson). Nếu APK này không có method đó
     * (bản cũ) -> hiện màn hình "APK cũ, hãy cài lại bản mới" thay vì một lỗi khó hiểu. */
    interface ActivityResultCallback {
        void onResult(int resultCode, Intent data);
    }

    interface PermCallback {
        void onResult(int[] grantResults);
    }

    private boolean bridgeHasCall() {
        try {
            Bridge.class.getMethod("call", String.class, String.class, String.class);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void showOldApkScreen(String reason) {
        android.widget.TextView tv = new android.widget.TextView(this);
        tv.setText("\u26a0\ufe0f APK cũ, hãy cài lại bản mới\n\n"
                + "Phiên bản ứng dụng trên máy không hỗ trợ giao diện này"
                + (reason == null || reason.isEmpty() ? "" : " (" + reason + ")")
                + ".\nHãy gỡ app và cài lại file APK mới nhất của CW Datacenter.");
        tv.setTextSize(15);
        tv.setTextColor(0xFF111827);
        tv.setGravity(android.view.Gravity.CENTER);
        tv.setPadding(96, 96, 96, 96);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        root.removeAllViews();
        root.addView(tv, lp);
        setContentView(root);
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        root = new FrameLayout(this);

        if (!bridgeHasCall()) {
            showOldApkScreen("APK thiếu cầu nối DC.call");
            return;
        }

        webView = new WebView(this);
        webView.setBackgroundColor(0xFFFFFFFF);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.requestFocus();
        root.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        fullscreenContainer = new FrameLayout(this);
        fullscreenContainer.setBackgroundColor(0xFF000000);
        fullscreenContainer.setVisibility(View.GONE);
        root.addView(fullscreenContainer, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(root);

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets sys = insets.getInsets(android.view.WindowInsets.Type.systemBars());
                bottomInsetPx = sys.bottom;
                topInsetPx = sys.top;
            } else {
                bottomInsetPx = insets.getSystemWindowInsetBottom();
                topInsetPx = insets.getSystemWindowInsetTop();
            }
            main.post(() -> {
                if (bridge != null) bridge.pushInsets(topInsetPx, bottomInsetPx);
            });
            return insets;
        });

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        getWindow().setStatusBarColor(0x00000000);
        getWindow().setNavigationBarColor(0x00000000);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                        | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }

        WebSettings st = webView.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setAllowFileAccess(true);
        st.setAllowContentAccess(true);
        st.setMediaPlaybackRequiresUserGesture(false);
        st.setLoadWithOverviewMode(true);
        st.setUseWideViewPort(true);
        st.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        chromeClient = new ChromeClient();
        CwWebViewClient cwClient = new CwWebViewClient();
        bridge = new Bridge(this, webView, main, this::startForResult);
        bridge.setWebViewClient(cwClient);

        webView.setWebChromeClient(chromeClient);
        webView.setWebViewClient(cwClient);

        webView.addJavascriptInterface(bridge, "DC");
        webView.loadUrl("file:///android_asset/app/index.html");

        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{ android.Manifest.permission.POST_NOTIFICATIONS }, 9901);
            }
        }
    }

    int topInsetPx() { return topInsetPx; }
    int bottomInsetPx() { return bottomInsetPx; }

    class ChromeClient extends WebChromeClient {
        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (fullscreenView != null) {
                if (callback != null) callback.onCustomViewHidden();
                return;
            }
            fullscreenView = view;
            fullscreenCallback = callback;
            fullscreenContainer.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            fullscreenContainer.setVisibility(View.VISIBLE);
            webView.setVisibility(View.GONE);
        }

        @Override
        public void onHideCustomView() {
            if (fullscreenView == null) return;
            fullscreenContainer.removeView(fullscreenView);
            fullscreenView = null;
            fullscreenContainer.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE);
            if (fullscreenCallback != null) {
                fullscreenCallback.onCustomViewHidden();
                fullscreenCallback = null;
            }
        }
    }

    int startForResult(Intent intent, ActivityResultCallback cb) {
        int code = requestCodeGen.incrementAndGet();
        pendingResults.put(code, cb);
        startActivityForResult(intent, code);
        return code;
    }

    int requestPerms(String[] perms, PermCallback cb) {
        int code = requestCodeGen.incrementAndGet();
        pendingPerms.put(code, cb);
        requestPermissions(perms, code);
        return code;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        PermCallback cb = pendingPerms.remove(requestCode);
        if (cb != null) cb.onResult(grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        ActivityResultCallback cb = pendingResults.remove(requestCode);
        if (cb != null) cb.onResult(resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (fullscreenView != null) {
            chromeClient.onHideCustomView();
            return;
        }
        if (bridge == null) { super.onBackPressed(); return; }
        boolean handled = bridge.onBack();
        if (!handled) {
            moveTaskToBack(true);
        }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (bridge != null) bridge.onBackground();
    }

    @Override
    protected void onDestroy() {
        if (bridge != null) bridge.shutdown();
        super.onDestroy();
    }
}
