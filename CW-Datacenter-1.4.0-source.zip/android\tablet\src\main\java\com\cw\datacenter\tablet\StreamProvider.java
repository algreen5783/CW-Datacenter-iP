package com.cw.datacenter.tablet;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.webkit.MimeTypeMap;

import java.io.File;
import java.io.FileNotFoundException;

public class StreamProvider extends ContentProvider {

    @Override
    public boolean onCreate() {
        return true;
    }

    static Uri uriFor(android.content.Context ctx, File f) {
        return new Uri.Builder()
                .scheme("content")
                .authority("com.cw.datacenter.tablet.files")
                .path(f.getAbsolutePath())
                .build();
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        File f = new File(uri.getPath() == null ? "" : uri.getPath());
        if (!f.exists() || !f.isFile()) throw new FileNotFoundException(uri.toString());
        String dir = f.getParentFile() == null ? "" : f.getParentFile().getAbsolutePath();
        boolean allowed = dir.startsWith(getContext().getFilesDir().getAbsolutePath())
                || dir.startsWith(getContext().getCacheDir().getAbsolutePath())
                || dir.startsWith(android.os.Environment.getExternalStorageDirectory().getAbsolutePath());
        if (!allowed) throw new FileNotFoundException("forbidden");
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public String getType(Uri uri) {
        String path = uri.getPath() == null ? "" : uri.getPath();
        int i = path.lastIndexOf('.');
        String ext = i >= 0 ? path.substring(i + 1).toLowerCase() : "";
        String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return mime != null ? mime : "application/octet-stream";
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}

