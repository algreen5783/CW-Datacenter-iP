package com.cw.datacenter.tablet;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

public class TransferService extends Service {

    private static final String CH_ID = "cw-transfers";
    private static final int NOTIF_ID = 46631;
    private static final String ACTION_STOP = "com.cw.datacenter.STOP";

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable checker = this::checkState;
    private boolean foreground;

    static void sync(Context ctx, int activeCount) {
        Intent i = new Intent(ctx.getApplicationContext(), TransferService.class);
        if (activeCount > 0) {
            try { ctx.getApplicationContext().startForegroundService(i); } catch (Exception ignored) {}
        } else {
            try { ctx.getApplicationContext().stopService(i); } catch (Exception ignored) {}
        }
    }

    static void stopAll(Context ctx) {
        try { TransferManager.get(ctx.getApplicationContext()).cancelAll(); } catch (Exception ignored) {}
        try { ctx.getApplicationContext().stopService(new Intent(ctx.getApplicationContext(), TransferService.class)); } catch (Exception ignored) {}
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopAll(this);
            return START_NOT_STICKY;
        }
        main.removeCallbacks(checker);
        TransferManager tm = TransferManager.get(this);
        if (tm.activeCount() > 0) {
            startForegroundSafe(tm.describeActive());
        } else if (!foreground) {
            startForegroundSafe("Đang truyền tải…");
        }
        main.postDelayed(checker, 3000);
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        main.removeCallbacks(checker);
        foreground = false;
        super.onDestroy();
    }

    private void checkState() {
        TransferManager tm = TransferManager.get(this);
        if (tm.activeCount() > 0) {
            startForegroundSafe(tm.describeActive());
            main.postDelayed(checker, 1500);
        } else {
            try { stopForeground(true); } catch (Exception ignored) {}
            foreground = false;
            stopSelf();
        }
    }

    private void startForegroundSafe(String text) {
        try {
            ensureChannel(this);
            startForeground(NOTIF_ID, buildNotification(this, text));
            foreground = true;
        } catch (Exception e) {
            try { stopSelf(); } catch (Exception ignored) {}
        }
    }

    static Notification buildNotification(Context ctx, String text) {
        ensureChannel(ctx);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            b = new Notification.Builder(ctx, CH_ID);
        } else {
            b = new Notification.Builder(ctx);
        }
        b.setContentTitle(ctx.getString(R.string.app_name))
                .setContentText(text == null || text.isEmpty() ? "Đang truyền tải…" : text)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setPriority(Notification.PRIORITY_LOW);
        try {
            Intent open = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
            if (open != null) {
                open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                b.setContentIntent(PendingIntent.getActivity(ctx, 1, open,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            }
            b.addAction(new Notification.Action.Builder(
                    android.R.drawable.ic_delete, "Dừng tất cả",
                    PendingIntent.getService(ctx, 2, stopIntent(ctx),
                            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE))
                    .build());
        } catch (Exception ignored) {}
        return b.build();
    }

    private static Intent stopIntent(Context ctx) {
        return new Intent(ctx.getApplicationContext(), TransferService.class).setAction(ACTION_STOP);
    }

    private static void ensureChannel(Context ctx) {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null && nm.getNotificationChannel(CH_ID) == null) {
                    nm.createNotificationChannel(new NotificationChannel(CH_ID, "Truyền tải tệp", NotificationManager.IMPORTANCE_LOW));
                }
            } catch (Exception ignored) {}
        }
    }
}

