import UIKit
import AVFoundation

class PlayerViewController: UIViewController {

    private var videoUrl: String
    private var videoName: String
    private var playlist: [[String: Any]]
    private var explicitStartPos: Int64

    private var player: AVPlayer?
    private var playerLayer: AVPlayerLayer?
    private var timeObserverToken: Any?

    private var isPlaying = false
    private var isLocked = false
    private var controlsVisible = true
    private var currentSpeedIndex = 1
    private let speeds: [Float] = [0.5, 1.0, 1.25, 1.5, 2.0]
    private var scalingModeIndex = 0 // 0: aspectFit, 1: aspectFill, 2: resize

    // UI Elements
    private let topBar = UIView()
    private let titleLabel = UILabel()
    private let speedBtn = UIButton(type: .system)
    private let aspectBtn = UIButton(type: .system)
    private let closeBtn = UIButton(type: .system)

    private let centerControls = UIView()
    private let playPauseBtn = UIButton(type: .custom)
    private let rewindBtn = UIButton(type: .custom)
    private let forwardBtn = UIButton(type: .custom)

    private let bottomBar = UIView()
    private let currentTimeLabel = UILabel()
    private let durationLabel = UILabel()
    private let seekSlider = UISlider()
    private let muteBtn = UIButton(type: .system)
    private let lockBtn = UIButton(type: .system)

    private let unlockBtn = UIButton(type: .custom)
    private let toastLabel = UILabel()

    private var hideTimer: Timer?
    private var isSeeking = false

    init(url: String, name: String?, playlist: [[String: Any]], startPos: Int64) {
        self.videoUrl = url
        self.videoName = name ?? "Đang phát video"
        self.playlist = playlist
        self.explicitStartPos = startPos
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override var prefersStatusBarHidden: Bool {
        return !controlsVisible
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .allButUpsideDown
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        setupPlayer()
        setupUI()
        setupGestures()

        showControls()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        playerLayer?.frame = view.bounds
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        saveCurrentPosition()
        cleanupPlayer()
    }

    // MARK: - Player Setup
    private func setupPlayer() {
        guard let url = URL(string: videoUrl) else { return }
        let asset = AVURLAsset(url: url)
        let playerItem = AVPlayerItem(asset: asset)

        player = AVPlayer(playerItem: playerItem)
        playerLayer = AVPlayerLayer(player: player)
        playerLayer?.videoGravity = .resizeAspect
        playerLayer?.frame = view.bounds
        if let layer = playerLayer {
            view.layer.addSublayer(layer)
        }

        // Time observer
        let interval = CMTime(seconds: 0.5, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        timeObserverToken = player?.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            self?.onTimeUpdate(time: time)
        }

        // Resume position
        let posKey = "vpos_" + (videoName.isEmpty ? String(videoUrl.hashValue) : videoName)
        if explicitStartPos == 0 {
            UserDefaults.standard.removeObject(forKey: posKey)
            showToast("Phát lại từ đầu")
        } else if explicitStartPos > 0 {
            let targetTime = CMTime(seconds: Double(explicitStartPos) / 1000.0, preferredTimescale: 600)
            player?.seek(to: targetTime, toleranceBefore: .zero, toleranceAfter: .zero)
            showToast("Đang phát tiếp từ \(formatTime(seconds: Double(explicitStartPos) / 1000.0))")
        } else {
            let savedPos = UserDefaults.standard.integer(forKey: posKey)
            if savedPos > 5000 {
                let targetTime = CMTime(seconds: Double(savedPos) / 1000.0, preferredTimescale: 600)
                player?.seek(to: targetTime, toleranceBefore: .zero, toleranceAfter: .zero)
                showToast("Đang phát tiếp từ \(formatTime(seconds: Double(savedPos) / 1000.0))")
            }
        }

        player?.play()
        isPlaying = true
        updatePlayPauseButton()
    }

    private func cleanupPlayer() {
        if let token = timeObserverToken {
            player?.removeTimeObserver(token)
            timeObserverToken = nil
        }
        player?.pause()
        player = nil
        playerLayer?.removeFromSuperlayer()
    }

    private func saveCurrentPosition() {
        guard let p = player else { return }
        let sec = CMTimeGetSeconds(p.currentTime())
        if sec > 3 && !sec.isNaN && !sec.isInfinite {
            let posKey = "vpos_" + (videoName.isEmpty ? String(videoUrl.hashValue) : videoName)
            UserDefaults.standard.set(Int(sec * 1000), forKey: posKey)
        }
    }

    // MARK: - UI Setup
    private func setupUI() {
        setupTopBar()
        setupCenterControls()
        setupBottomBar()
        setupUnlockButton()
        setupToast()
    }

    private func setupTopBar() {
        topBar.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        topBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(topBar)

        closeBtn.setTitle("✕", for: .normal)
        closeBtn.setTitleColor(.white, for: .normal)
        closeBtn.titleLabel?.font = UIFont.systemFont(ofSize: 22, weight: .bold)
        closeBtn.addTarget(self, action: #selector(onCloseTapped), for: .touchUpInside)
        closeBtn.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(closeBtn)

        titleLabel.text = videoName
        titleLabel.textColor = .white
        titleLabel.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(titleLabel)

        speedBtn.setTitle("1.0x", for: .normal)
        speedBtn.setTitleColor(.white, for: .normal)
        speedBtn.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: .bold)
        speedBtn.backgroundColor = UIColor.white.withAlphaComponent(0.18)
        speedBtn.layer.cornerRadius = 6
        speedBtn.addTarget(self, action: #selector(onSpeedTapped), for: .touchUpInside)
        speedBtn.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(speedBtn)

        aspectBtn.setTitle("Tỷ lệ", for: .normal)
        aspectBtn.setTitleColor(.white, for: .normal)
        aspectBtn.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: .medium)
        aspectBtn.backgroundColor = UIColor.white.withAlphaComponent(0.18)
        aspectBtn.layer.cornerRadius = 6
        aspectBtn.addTarget(self, action: #selector(onAspectTapped), for: .touchUpInside)
        aspectBtn.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(aspectBtn)

        NSLayoutConstraint.activate([
            topBar.topAnchor.constraint(equalTo: view.topAnchor),
            topBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            topBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            topBar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 50),

            closeBtn.leadingAnchor.constraint(equalTo: topBar.leadingAnchor, constant: 16),
            closeBtn.bottomAnchor.constraint(equalTo: topBar.bottomAnchor, constant: -8),
            closeBtn.widthAnchor.constraint(equalToConstant: 36),
            closeBtn.heightAnchor.constraint(equalToConstant: 36),

            titleLabel.leadingAnchor.constraint(equalTo: closeBtn.trailingAnchor, constant: 12),
            titleLabel.centerYAnchor.constraint(equalTo: closeBtn.centerYAnchor),
            titleLabel.trailingAnchor.constraint(lessThanOrEqualTo: speedBtn.leadingAnchor, constant: -12),

            aspectBtn.trailingAnchor.constraint(equalTo: topBar.trailingAnchor, constant: -16),
            aspectBtn.centerYAnchor.constraint(equalTo: closeBtn.centerYAnchor),
            aspectBtn.widthAnchor.constraint(equalToConstant: 54),
            aspectBtn.heightAnchor.constraint(equalToConstant: 28),

            speedBtn.trailingAnchor.constraint(equalTo: aspectBtn.leadingAnchor, constant: -8),
            speedBtn.centerYAnchor.constraint(equalTo: closeBtn.centerYAnchor),
            speedBtn.widthAnchor.constraint(equalToConstant: 48),
            speedBtn.heightAnchor.constraint(equalToConstant: 28)
        ])
    }

    private func setupCenterControls() {
        centerControls.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(centerControls)

        // Rewind
        rewindBtn.setTitle("⏪ -10s", for: .normal)
        rewindBtn.setTitleColor(.white, for: .normal)
        rewindBtn.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        rewindBtn.backgroundColor = UIColor.black.withAlphaComponent(0.55)
        rewindBtn.layer.cornerRadius = 28
        rewindBtn.layer.borderWidth = 1
        rewindBtn.layer.borderColor = UIColor.white.withAlphaComponent(0.2).cgColor
        rewindBtn.addTarget(self, action: #selector(onRewindTapped), for: .touchUpInside)
        rewindBtn.translatesAutoresizingMaskIntoConstraints = false
        centerControls.addSubview(rewindBtn)

        // Play/Pause
        playPauseBtn.setTitle("⏸", for: .normal)
        playPauseBtn.setTitleColor(.white, for: .normal)
        playPauseBtn.titleLabel?.font = UIFont.systemFont(ofSize: 32)
        playPauseBtn.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        playPauseBtn.layer.cornerRadius = 38
        playPauseBtn.layer.borderWidth = 1
        playPauseBtn.layer.borderColor = UIColor.white.withAlphaComponent(0.25).cgColor
        playPauseBtn.addTarget(self, action: #selector(onPlayPauseTapped), for: .touchUpInside)
        playPauseBtn.translatesAutoresizingMaskIntoConstraints = false
        centerControls.addSubview(playPauseBtn)

        // Forward
        forwardBtn.setTitle("+10s ⏩", for: .normal)
        forwardBtn.setTitleColor(.white, for: .normal)
        forwardBtn.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        forwardBtn.backgroundColor = UIColor.black.withAlphaComponent(0.55)
        forwardBtn.layer.cornerRadius = 28
        forwardBtn.layer.borderWidth = 1
        forwardBtn.layer.borderColor = UIColor.white.withAlphaComponent(0.2).cgColor
        forwardBtn.addTarget(self, action: #selector(onForwardTapped), for: .touchUpInside)
        forwardBtn.translatesAutoresizingMaskIntoConstraints = false
        centerControls.addSubview(forwardBtn)

        NSLayoutConstraint.activate([
            centerControls.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            centerControls.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            centerControls.heightAnchor.constraint(equalToConstant: 80),

            playPauseBtn.centerXAnchor.constraint(equalTo: centerControls.centerXAnchor),
            playPauseBtn.centerYAnchor.constraint(equalTo: centerControls.centerYAnchor),
            playPauseBtn.widthAnchor.constraint(equalToConstant: 76),
            playPauseBtn.heightAnchor.constraint(equalToConstant: 76),

            rewindBtn.trailingAnchor.constraint(equalTo: playPauseBtn.leadingAnchor, constant: -28),
            rewindBtn.centerYAnchor.constraint(equalTo: centerControls.centerYAnchor),
            rewindBtn.widthAnchor.constraint(equalToConstant: 76),
            rewindBtn.heightAnchor.constraint(equalToConstant: 56),

            forwardBtn.leadingAnchor.constraint(equalTo: playPauseBtn.trailingAnchor, constant: 28),
            forwardBtn.centerYAnchor.constraint(equalTo: centerControls.centerYAnchor),
            forwardBtn.widthAnchor.constraint(equalToConstant: 76),
            forwardBtn.heightAnchor.constraint(equalToConstant: 56)
        ])
    }

    private func setupBottomBar() {
        bottomBar.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        bottomBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bottomBar)

        currentTimeLabel.text = "00:00"
        currentTimeLabel.textColor = .white
        currentTimeLabel.font = UIFont.monospacedDigitSystemFont(ofSize: 13, weight: .regular)
        currentTimeLabel.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.addSubview(currentTimeLabel)

        durationLabel.text = "--:--"
        durationLabel.textColor = UIColor.white.withAlphaComponent(0.7)
        durationLabel.font = UIFont.monospacedDigitSystemFont(ofSize: 13, weight: .regular)
        durationLabel.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.addSubview(durationLabel)

        seekSlider.minimumTrackTintColor = UIColor(red: 1.0, green: 0.22, blue: 0.36, alpha: 1.0)
        seekSlider.maximumTrackTintColor = UIColor.white.withAlphaComponent(0.25)
        seekSlider.addTarget(self, action: #selector(onSliderChanged), for: .valueChanged)
        seekSlider.addTarget(self, action: #selector(onSliderTouchDown), for: .touchDown)
        seekSlider.addTarget(self, action: #selector(onSliderTouchUp), for: [.touchUpInside, .touchUpOutside, .touchCancel])
        seekSlider.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.addSubview(seekSlider)

        muteBtn.setTitle("🔊", for: .normal)
        muteBtn.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        muteBtn.addTarget(self, action: #selector(onMuteTapped), for: .touchUpInside)
        muteBtn.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.addSubview(muteBtn)

        lockBtn.setTitle("🔓", for: .normal)
        lockBtn.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        lockBtn.addTarget(self, action: #selector(onLockTapped), for: .touchUpInside)
        lockBtn.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.addSubview(lockBtn)

        NSLayoutConstraint.activate([
            bottomBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bottomBar.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            bottomBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -56),

            currentTimeLabel.leadingAnchor.constraint(equalTo: bottomBar.leadingAnchor, constant: 16),
            currentTimeLabel.topAnchor.constraint(equalTo: bottomBar.topAnchor, constant: 14),

            seekSlider.leadingAnchor.constraint(equalTo: currentTimeLabel.trailingAnchor, constant: 10),
            seekSlider.trailingAnchor.constraint(equalTo: durationLabel.leadingAnchor, constant: -10),
            seekSlider.centerYAnchor.constraint(equalTo: currentTimeLabel.centerYAnchor),

            durationLabel.trailingAnchor.constraint(equalTo: muteBtn.leadingAnchor, constant: -14),
            durationLabel.centerYAnchor.constraint(equalTo: currentTimeLabel.centerYAnchor),

            muteBtn.trailingAnchor.constraint(equalTo: lockBtn.leadingAnchor, constant: -12),
            muteBtn.centerYAnchor.constraint(equalTo: currentTimeLabel.centerYAnchor),
            muteBtn.widthAnchor.constraint(equalToConstant: 32),

            lockBtn.trailingAnchor.constraint(equalTo: bottomBar.trailingAnchor, constant: -16),
            lockBtn.centerYAnchor.constraint(equalTo: currentTimeLabel.centerYAnchor),
            lockBtn.widthAnchor.constraint(equalToConstant: 32)
        ])
    }

    private func setupUnlockButton() {
        unlockBtn.setTitle("🔒 Mở khóa", for: .normal)
        unlockBtn.setTitleColor(.white, for: .normal)
        unlockBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: .bold)
        unlockBtn.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        unlockBtn.layer.cornerRadius = 20
        unlockBtn.layer.borderWidth = 1
        unlockBtn.layer.borderColor = UIColor.white.withAlphaComponent(0.3).cgColor
        unlockBtn.isHidden = true
        unlockBtn.addTarget(self, action: #selector(onUnlockTapped), for: .touchUpInside)
        unlockBtn.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(unlockBtn)

        NSLayoutConstraint.activate([
            unlockBtn.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            unlockBtn.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            unlockBtn.widthAnchor.constraint(equalToConstant: 110),
            unlockBtn.heightAnchor.constraint(equalToConstant: 40)
        ])
    }

    private func setupToast() {
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        toastLabel.textColor = .white
        toastLabel.font = UIFont.systemFont(ofSize: 13.5, weight: .medium)
        toastLabel.textAlignment = .center
        toastLabel.layer.cornerRadius = 18
        toastLabel.layer.masksToBounds = true
        toastLabel.layer.borderWidth = 1
        toastLabel.layer.borderColor = UIColor.white.withAlphaComponent(0.2).cgColor
        toastLabel.alpha = 0
        toastLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(toastLabel)

        NSLayoutConstraint.activate([
            toastLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            toastLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 60),
            toastLabel.heightAnchor.constraint(equalToConstant: 36),
            toastLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 140)
        ])
    }

    private var initialPanLocation: CGPoint = .zero
    private var panMode: Int = 0 // 1: brightness (left), 2: volume (right), 3: seek (horizontal)
    private var initialSeekPos: Double = 0

    private func setupGestures() {
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(onSurfaceTapped))
        singleTap.numberOfTapsRequired = 1

        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(onDoubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        singleTap.require(toFail: doubleTap)

        view.addGestureRecognizer(singleTap)
        view.addGestureRecognizer(doubleTap)

        let pan = UIPanGestureRecognizer(target: self, action: #selector(onPanGesture(_:)))
        view.addGestureRecognizer(pan)
    }

    @objc private func onDoubleTap(_ gesture: UITapGestureRecognizer) {
        if isLocked { return }
        let point = gesture.location(in: view)
        let isLeft = point.x < (view.bounds.width / 2)
        if isLeft {
            skip(seconds: -10)
        } else {
            skip(seconds: 10)
        }
    }

    @objc private func onPanGesture(_ gesture: UIPanGestureRecognizer) {
        if isLocked { return }
        let point = gesture.location(in: view)
        let translation = gesture.translation(in: view)

        switch gesture.state {
        case .began:
            initialPanLocation = point
            if abs(translation.x) > abs(translation.y) {
                panMode = 3 // Seek
                initialSeekPos = player != nil ? CMTimeGetSeconds(player!.currentTime()) : 0
            } else {
                panMode = point.x < (view.bounds.width / 2) ? 1 : 2 // 1: Brightness, 2: Volume
            }
        case .changed:
            if panMode == 1 {
                // Brightness
                let delta = -translation.y / view.bounds.height
                let cur = UIScreen.main.brightness
                UIScreen.main.brightness = max(0, min(1.0, cur + (delta * 0.05)))
                showToast("Độ sáng: \(Int(UIScreen.main.brightness * 100))%")
            } else if panMode == 2 {
                // Volume
                let delta = Float(-translation.y / view.bounds.height)
                let cur = player?.volume ?? 1.0
                player?.volume = max(0, min(1.0, cur + (delta * 0.05)))
                showToast("Âm lượng: \(Int((player?.volume ?? 1.0) * 100))%")
            } else if panMode == 3 {
                // Seek
                guard let dur = player?.currentItem?.duration else { return }
                let total = CMTimeGetSeconds(dur)
                if !total.isNaN && total > 0 {
                    let deltaSec = Double(translation.x / view.bounds.width) * 90.0 // +/- 90s max per swipe
                    let target = max(0, min(total, initialSeekPos + deltaSec))
                    currentTimeLabel.text = formatTime(seconds: target)
                    showToast("\(formatTime(seconds: target)) / \(formatTime(seconds: total))")
                }
            }
        case .ended, .cancelled:
            if panMode == 3 {
                guard let dur = player?.currentItem?.duration else { return }
                let total = CMTimeGetSeconds(dur)
                if !total.isNaN && total > 0 {
                    let deltaSec = Double(translation.x / view.bounds.width) * 90.0
                    let target = max(0, min(total, initialSeekPos + deltaSec))
                    let cmTarget = CMTime(seconds: target, preferredTimescale: 600)
                    player?.seek(to: cmTarget, toleranceBefore: .zero, toleranceAfter: .zero)
                }
            }
            panMode = 0
            scheduleHide()
        default: break
        }
    }

    // MARK: - Actions
    @objc private func onSurfaceTapped() {
        if isLocked {
            unlockBtn.isHidden = !unlockBtn.isHidden
            return
        }
        if controlsVisible {
            hideControls()
        } else {
            showControls()
        }
    }

    @objc private func onPlayPauseTapped() {
        guard let p = player else { return }
        if isPlaying {
            p.pause()
            isPlaying = false
            showToast("Đã tạm dừng")
        } else {
            p.play()
            isPlaying = true
            showToast("Đang phát")
        }
        updatePlayPauseButton()
        scheduleHide()
    }

    @objc private func onRewindTapped() {
        skip(seconds: -10)
    }

    @objc private func onForwardTapped() {
        skip(seconds: 10)
    }

    private func skip(seconds: Double) {
        guard let p = player else { return }
        let current = CMTimeGetSeconds(p.currentTime())
        var target = current + seconds
        if let dur = p.currentItem?.duration {
            let total = CMTimeGetSeconds(dur)
            if !total.isNaN && total > 0 {
                target = max(0, min(total, target))
            }
        }
        target = max(0, target)
        let cmTarget = CMTime(seconds: target, preferredTimescale: 600)
        p.seek(to: cmTarget, toleranceBefore: .zero, toleranceAfter: .zero)
        showToast(seconds > 0 ? "Tiến 10 giây" : "Lùi 10 giây")
        showControls()
    }

    @objc private func onSliderTouchDown() {
        isSeeking = true
        hideTimer?.invalidate()
    }

    @objc private func onSliderChanged() {
        guard let dur = player?.currentItem?.duration else { return }
        let total = CMTimeGetSeconds(dur)
        guard !total.isNaN && total > 0 else { return }
        let current = Double(seekSlider.value) * total
        currentTimeLabel.text = formatTime(seconds: current)
    }

    @objc private func onSliderTouchUp() {
        isSeeking = false
        guard let p = player, let dur = p.currentItem?.duration else { return }
        let total = CMTimeGetSeconds(dur)
        guard !total.isNaN && total > 0 else { return }
        let target = Double(seekSlider.value) * total
        let cmTarget = CMTime(seconds: target, preferredTimescale: 600)
        p.seek(to: cmTarget, toleranceBefore: .zero, toleranceAfter: .zero)
        scheduleHide()
    }

    @objc private func onSpeedTapped() {
        currentSpeedIndex = (currentSpeedIndex + 1) % speeds.count
        let sp = speeds[currentSpeedIndex]
        player?.rate = isPlaying ? sp : 0
        speedBtn.setTitle(String(format: "%.1fx", sp), for: .normal)
        showToast("Tốc độ \(sp)x")
        scheduleHide()
    }

    @objc private func onAspectTapped() {
        scalingModeIndex = (scalingModeIndex + 1) % 3
        switch scalingModeIndex {
        case 0:
            playerLayer?.videoGravity = .resizeAspect
            showToast("Tỷ lệ: Vừa màn hình")
        case 1:
            playerLayer?.videoGravity = .resizeAspectFill
            showToast("Tỷ lệ: Cắt đầy màn hình")
        case 2:
            playerLayer?.videoGravity = .resize
            showToast("Tỷ lệ: Kéo dãn (Toàn màn hình)")
        default: break
        }
        scheduleHide()
    }

    @objc private func onMuteTapped() {
        guard let p = player else { return }
        p.isMuted = !p.isMuted
        muteBtn.setTitle(p.isMuted ? "🔇" : "🔊", for: .normal)
        showToast(p.isMuted ? "Đã tắt tiếng" : "Đã bật tiếng")
        scheduleHide()
    }

    @objc private func onLockTapped() {
        isLocked = true
        hideControls()
        unlockBtn.isHidden = false
        showToast("Đã khóa điều khiển")
    }

    @objc private func onUnlockTapped() {
        isLocked = false
        unlockBtn.isHidden = true
        showControls()
        showToast("Đã mở khóa điều khiển")
    }

    @objc private func onCloseTapped() {
        dismiss(animated: true)
    }

    // MARK: - Helpers
    private func onTimeUpdate(time: CMTime) {
        guard !isSeeking, let p = player else { return }
        let current = CMTimeGetSeconds(time)
        currentTimeLabel.text = formatTime(seconds: current)

        if let dur = p.currentItem?.duration {
            let total = CMTimeGetSeconds(dur)
            if !total.isNaN && total > 0 {
                durationLabel.text = formatTime(seconds: total)
                seekSlider.value = Float(current / total)
            }
        }
    }

    private func updatePlayPauseButton() {
        playPauseBtn.setTitle(isPlaying ? "⏸" : "▶️", for: .normal)
    }

    private func showControls() {
        guard !isLocked else { return }
        controlsVisible = true
        topBar.isHidden = false
        bottomBar.isHidden = false
        centerControls.isHidden = false
        UIView.animate(withDuration: 0.2) {
            self.topBar.alpha = 1
            self.bottomBar.alpha = 1
            self.centerControls.alpha = 1
            self.setNeedsStatusBarAppearanceUpdate()
        }
        scheduleHide()
    }

    private func hideControls() {
        controlsVisible = false
        UIView.animate(withDuration: 0.2, animations: {
            self.topBar.alpha = 0
            self.bottomBar.alpha = 0
            self.centerControls.alpha = 0
            self.setNeedsStatusBarAppearanceUpdate()
        }) { _ in
            if !self.controlsVisible {
                self.topBar.isHidden = true
                self.bottomBar.isHidden = true
                self.centerControls.isHidden = true
            }
        }
    }

    private func scheduleHide() {
        hideTimer?.invalidate()
        hideTimer = Timer.scheduledTimer(withTimeInterval: 3.5, repeats: false) { [weak self] _ in
            self?.hideControls()
        }
    }

    private func showToast(_ text: String) {
        toastLabel.text = "  \(text)  "
        toastLabel.sizeToFit()
        UIView.animate(withDuration: 0.2) {
            self.toastLabel.alpha = 1
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) {
            UIView.animate(withDuration: 0.3) {
                self.toastLabel.alpha = 0
            }
        }
    }

    private func formatTime(seconds: Double) -> String {
        guard !seconds.isNaN && !seconds.isInfinite else { return "00:00" }
        let total = Int(seconds)
        let h = total / 3600
        let m = (total % 3600) / 60
        let s = total % 60
        if h > 0 {
            return String(format: "%d:%02d:%02d", h, m, s)
        }
        return String(format: "%02d:%02d", m, s)
    }
}