# CW Datacenter — Android Client

Client Android (native + WebView) cho server **CW Datacenter**. UI dùng bản MVP HTML tiếng Việt, network layer chạy qua native Java bridge (không dính CORS), hỗ trợ upload/download chunked + resume đúng API server.

## Cấu trúc
```
android/
  app/src/main/assets/app/
    index.html      UI MVP (bản HTML tiếng Việt, đã lược dữ liệu demo)
    app.js          Điều khiển UI + gọi server qua native bridge `DC`
  app/src/main/java/com/cw/datacenter/android/
    MainActivity.java       WebView host
    Bridge.java             JS interface: api, discover, upload, download, picker, file, playVideo...
                            (v1.2: method bất đồng bộ gom về DC.call(name, id, json) + dispatch)
    PdfRendererManager.java Đọc PDF native (PdfRenderer) -> ảnh JPEG từng trang qua LocalProxy
    TransferManager.java    Động cơ truyền tải chunked (4MB) + Range resume (singleton, chạy ngầm)
    TransferService.java    Foreground service giữ upload/download chạy khi thoát app
    StreamProvider.java     ContentProvider để mở tệp bằng app ngoài
    PlayerActivity.java     Trình phát video native (androidx.media3 ExoPlayer)
```

## Hiệu năng & tính năng mới (v1.3)
- **Player gọn lại**: bar dưới chỉ giữ các nút chuẩn của ExoPlayer; tùy chọn tốc độ phát dùng mục có sẵn trong menu ⚙️; thêm 1 nút duy nhất "Xoay màn hình" với icon tự vẽ cùng phong cách icon gốc Exo (Material screen_rotation, 24dp đơn sắc).
- **PDF mở bằng app đọc ngoài**: chạm PDF trên "Thiết bị này" → chọn ứng dụng đọc ngay; PDF trên server → tự tải về rồi mở bằng ứng dụng người dùng chọn (không còn render trong WebView).
- **Chọn nhiều file**: bấm giữ file chỉ vào chế độ chọn (đánh dấu file đó), không tự mở bảng tác vụ; mở bảng bằng nút nổi "Đã chọn N mục" hoặc nút ⋮ của file.
- **Sửa lỗi không vào được thư mục con trong "Thiết bị này"** (navigation dùng nhầm key `undefined` → cứ load lại thư mục hiện tại).

## Hiệu năng & tính năng (v1.2)
- **Nút player thẳng hàng**: 4 nút thêm vào thanh điều khiển ExoPlayer đều dùng chung style chuẩn `ExoStyledControls.Button.Bottom` (cùng size 48dp + padding của Exo), icon tua là icon gốc `exo_styled_controls_rewind/fastforward`, thứ tự trên thanh: ⚙️ cài đặt → ⏪ tua lùi → ⏩ tua tới → ⟳ xoay → tốc độ (chữ, bọc cùng style).
- **PDF native (bỏ pdf.js)**: đọc PDF bằng `android.graphics.pdf.PdfRenderer` qua bridge `pdfInfo/pdfPage/pdfClose`: file server được tải 1 lần vào cache rồi render từng trang thành ảnh JPEG; file trên máy ("Thiết bị này") render thẳng. Trang 1 hiện ngay, cuộn đến đâu render tiếp trang đến đó (LocalProxy phục vụ ảnh qua `/pdfpage`). Không còn WebView + pdf.js → hết lỗi cắt ghép trang.
- **Nút "Đã chọn N mục"**: đang ở chế độ chọn nhiều file mà bảng thao tác đã đóng, xuất hiện nút nổi ghi số mục đang chọn — bấm vào mở lại bảng thao tác (nhấn giữ file vẫn mở bảng như cũ).
- **Cầu nối gom 1 mối**: toàn bộ method bất đồng bộ JS→native đi qua `DC.call(tên_method, id, json_args)` duy nhất, native tự dispatch; tên method lạ trả lỗi tiếng Việt rõ ràng thay vì "Method not found". Khởi động kiểm tra APK có `DC.call` không — APK cũ hiện ngay màn hình "APK cũ, hãy cài lại bản mới".

## Hiệu năng & tính năng (v1.1)
- **Upload nhanh**: đọc tệp song song với gửi chunk (pipeline 3 chunk đệm), HTTP keep-alive, tốc độ không còn bị kẹp ~4MB/s như trước.
- **Chạy ngầm**: thoát app (Home/Back) upload/download vẫn chạy qua foreground service + wake lock, thông báo hiển thị tiến độ và nút "Dừng tất cả". Giết app rồi mở lại sẽ tự nối lại hàng chờ (resume từ offset).
- **Tên file dài**: tự cắt giữa/cuối bằng ellipsis, không còn tràn viền.
- **Player native**: video mở bằng ExoPlayer (androidx.media3) thay vì WebView — buffer/seek mượt, tua ±10s, chỉnh tốc độ phát, xoay màn hình. Auth (Bearer token) được gắn sẵn vào request.

## Tính năng đã đưa lên Android (đúng UX web client)
- **Discover** — quét LAN bằng UDP broadcast `CW-DISCOVER` (port 46631) đúng giao thức server, hoặc kết nối thủ công IP+cổng.
- **Sign in** — `username + password` (Bearer token), `Ghi nhớ thiết bị này`.
- **Tin cậy thiết bị** — màn hình trust ở lần đăng nhập đầu.
- **Tệp** — breadcrumb, search, sort, mở thư mục, `⋮` menu (Mở / Tải xuống / Đổi tên / Thư mục mới / Thêm-Yêu thích / Xóa vào thùng rác / Đồng bộ).
- **Truyền tải** — 2 tab Đang chạy / Hoàn tất, progress + ETA + pause/resume. Upload chunked 4MB resume, download Range resume.
- **Yêu thích** — pin tệp/thư mục local.
- **Đồng bộ** — download 1 chiều server → máy, hàng chờ, pause/resume, toggle backup camera.
- **Thùng rác** — list, restore, purge.
- **Back button** — Android back điều hướng breadcrumb / view.
- **Mở tệp** — dùng `content://` qua `StreamProvider` để mở bằng app ngoài (video, pdf, ảnh, audio...).
- **Tải xuống** — lưu vào thư mục Downloads public (MediaStore API 29+, File API 28).
- **Keep-alive** — ping `/api/health` mỗi 12s, tự nhận lại kết nối.

## Build APK
Cần Android Studio hoặc SDK + JDK. Máy dev hiện có sẵn: Android Studio JBR (Java 25), SDK platform 34, Gradle 9.3 (wrapper tự tải khi build).

```powershell
cd android
# JAVA_HOME đã set sẵn nếu dùng Android Studio JDK; nếu không:
$env:JAVA_HOME = "C:\Program Files\Android\Android Studio\jbr"
.\gradlew.bat assembleDebug
```

APK output: `app\build\outputs\apk\debug\app-debug.apk`

Cài lên thiết bị kết nối ADB:
```powershell
& "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe" install -r app\build\outputs\apk\debug\app-debug.apk
```

## Dùng
1. Bật **Host** (CW Datacenter server) trên PC trong mạng LAN.
2. Mở app trên điện thoại cùng mạng → app tự **Quét mạng** bằng UDP broadcast, chọn server hoặc nhập IP thủ công.
3. Đăng nhập (bỏ trống username = admin), chọn **Tin cậy & tiếp tục**.
4. Bấm `⋮` hoặc `+` để upload; bấm `⋮` của tệp để tải xuống / mở / đồng bộ.

## Ghi chú kỹ thuật
- Server dùng HTTP cleartext nội bộ → manifest có `usesCleartextTraffic="true"`.
- WebView gốc `file:///android_asset`, gọi server qua `window.DC` (JS interface) để tránh CORS.
- `minSdk 26` (Android 8), `targetSdk 34`.
