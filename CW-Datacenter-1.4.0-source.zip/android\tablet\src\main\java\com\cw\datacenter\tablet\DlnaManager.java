package com.cw.datacenter.tablet;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DlnaManager {
    private static final String TAG = "DlnaManager";
    private static final String SSDP_IP = "239.255.255.250";
    private static final int SSDP_PORT = 1900;
    private static final ExecutorService executor = Executors.newCachedThreadPool();
    private static final Handler mainHandler = new Handler(Looper.getMainLooper());

    public static class DlnaDevice {
        public String id;
        public String name;
        public String manufacturer;
        public String modelName;
        public String location;
        public String controlUrl;
        public String host;

        @Override
        public String toString() {
            return name != null && !name.isEmpty() ? name : "Smart TV (" + host + ")";
        }
    }

    public interface DiscoveryCallback {
        void onDeviceFound(DlnaDevice device);
        void onDiscoveryFinished(List<DlnaDevice> devices);
    }

    public interface ActionCallback {
        void onSuccess();
        void onError(String error);
    }

    public static void discoverDevices(Context context, int timeoutMs, DiscoveryCallback callback) {
        final List<DlnaDevice> resultList = Collections.synchronizedList(new ArrayList<>());
        final Map<String, Boolean> seenUdns = new ConcurrentHashMap<>();

        executor.execute(() -> {
            WifiManager.MulticastLock lock = null;
            try {
                WifiManager wm = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if (wm != null) {
                    lock = wm.createMulticastLock("cw_dlna_lock");
                    lock.setReferenceCounted(true);
                    lock.acquire();
                }
            } catch (Exception ignored) {}

            List<DatagramSocket> sockets = new ArrayList<>();
            try {
                try {
                    MulticastSocket ms = new MulticastSocket(null);
                    ms.setReuseAddress(true);
                    ms.bind(new InetSocketAddress(0));
                    ms.setTimeToLive(4);
                    sockets.add(ms);
                } catch (Exception ignored) {}

                try {
                    DatagramSocket ds = new DatagramSocket();
                    ds.setBroadcast(true);
                    sockets.add(ds);
                } catch (Exception ignored) {}

                String[] searchTargets = {
                        "urn:schemas-upnp-org:service:AVTransport:1",
                        "urn:schemas-upnp-org:device:MediaRenderer:1",
                        "ssdp:all"
                };

                for (String st : searchTargets) {
                    String msg = "M-SEARCH * HTTP/1.1\r\n" +
                            "HOST: " + SSDP_IP + ":" + SSDP_PORT + "\r\n" +
                            "MAN: \"ssdp:discover\"\r\n" +
                            "MX: 3\r\n" +
                            "ST: " + st + "\r\n\r\n";
                    byte[] data = msg.getBytes(StandardCharsets.UTF_8);

                    for (DatagramSocket s : sockets) {
                        try {
                            DatagramPacket p = new DatagramPacket(data, data.length,
                                    InetAddress.getByName(SSDP_IP), SSDP_PORT);
                            s.send(p);
                        } catch (Exception ignored) {}
                    }
                }

                long deadline = System.currentTimeMillis() + timeoutMs;
                byte[] buf = new byte[8192];

                while (System.currentTimeMillis() < deadline) {
                    for (DatagramSocket s : sockets) {
                        try {
                            s.setSoTimeout(300);
                            DatagramPacket p = new DatagramPacket(buf, buf.length);
                            s.receive(p);
                            String res = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8);
                            String location = parseHeader(res, "LOCATION");
                            if (location != null && !location.isEmpty()) {
                                String host = p.getAddress().getHostAddress();
                                executor.execute(() -> {
                                    DlnaDevice dev = fetchDeviceDescription(location, host);
                                    if (dev != null && dev.controlUrl != null && !seenUdns.containsKey(dev.controlUrl)) {
                                        seenUdns.put(dev.controlUrl, true);
                                        resultList.add(dev);
                                        if (callback != null) {
                                            mainHandler.post(() -> callback.onDeviceFound(dev));
                                        }
                                    }
                                });
                            }
                        } catch (Exception ignored) {}
                    }
                }

            } catch (Exception e) {
                Log.w(TAG, "SSDP Discovery error: " + e.getMessage());
            } finally {
                for (DatagramSocket s : sockets) {
                    try { s.close(); } catch (Exception ignored) {}
                }
                if (lock != null && lock.isHeld()) {
                    try { lock.release(); } catch (Exception ignored) {}
                }
                if (callback != null) {
                    mainHandler.post(() -> callback.onDiscoveryFinished(new ArrayList<>(resultList)));
                }
            }
        });
    }

    private static String parseHeader(String response, String headerName) {
        String[] lines = response.split("\r\n");
        String prefix = headerName.toLowerCase() + ":";
        for (String line : lines) {
            String lower = line.toLowerCase().trim();
            if (lower.startsWith(prefix)) {
                return line.substring(line.indexOf(':') + 1).trim();
            }
        }
        return null;
    }

    private static DlnaDevice fetchDeviceDescription(String locationUrl, String fallbackHost) {
        try {
            URL u = new URL(locationUrl);
            HttpURLConnection conn = (HttpURLConnection) u.openConnection();
            conn.setConnectTimeout(4000);
            conn.setReadTimeout(4000);
            conn.setRequestProperty("User-Agent", "DLNADOC/1.50 SEC_HHP_CW/1.0");
            conn.connect();

            if (conn.getResponseCode() >= 200 && conn.getResponseCode() < 300) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
                }
                reader.close();

                String xml = sb.toString();
                DlnaDevice dev = new DlnaDevice();
                dev.location = locationUrl;
                dev.host = u.getHost() != null ? u.getHost() : fallbackHost;
                dev.name = extractXmlTag(xml, "friendlyName");
                dev.manufacturer = extractXmlTag(xml, "manufacturer");
                dev.modelName = extractXmlTag(xml, "modelName");
                dev.id = extractXmlTag(xml, "UDN");

                String controlUrl = extractServiceControlUrl(xml, "AVTransport");
                if (controlUrl == null) {
                    controlUrl = extractServiceControlUrl(xml, "avtransport");
                }

                if (controlUrl != null) {
                    if (controlUrl.startsWith("http://") || controlUrl.startsWith("https://")) {
                        dev.controlUrl = controlUrl;
                    } else {
                        String baseUrl = u.getProtocol() + "://" + u.getHost() + (u.getPort() > 0 ? ":" + u.getPort() : "");
                        if (!controlUrl.startsWith("/")) controlUrl = "/" + controlUrl;
                        dev.controlUrl = baseUrl + controlUrl;
                    }
                }

                if (dev.name == null || dev.name.isEmpty()) {
                    dev.name = "Smart TV (" + dev.host + ")";
                }

                return dev;
            }
        } catch (Exception e) {
            Log.w(TAG, "Failed to fetch description from " + locationUrl + ": " + e.getMessage());
        }
        return null;
    }

    private static String extractXmlTag(String xml, String tag) {
        String open = "<" + tag;
        String close = "</" + tag + ">";
        int start = xml.indexOf(open);
        if (start < 0) return "";
        int contentStart = xml.indexOf('>', start) + 1;
        int end = xml.indexOf(close, contentStart);
        if (end < 0) return "";
        return xml.substring(contentStart, end).trim();
    }

    private static String extractServiceControlUrl(String xml, String serviceTypeSub) {
        int idx = 0;
        String lowerXml = xml.toLowerCase();
        String lowerSub = serviceTypeSub.toLowerCase();
        while ((idx = lowerXml.indexOf("<service>", idx)) != -1) {
            int end = lowerXml.indexOf("</service>", idx);
            if (end == -1) break;
            String serviceBlock = xml.substring(idx, end + 10);
            if (serviceBlock.toLowerCase().contains(lowerSub)) {
                return extractXmlTag(serviceBlock, "controlURL");
            }
            idx = end + 10;
        }
        return null;
    }

    /* ---------- CAST ACTIONS (SOAP UPnP) ---------- */

    public static void playMedia(DlnaDevice device, String mediaUrl, String title, String mimeType, ActionCallback callback) {
        executor.execute(() -> {
            try {
                if (device == null || device.controlUrl == null) {
                    if (callback != null) mainHandler.post(() -> callback.onError("Không tìm thấy địa chỉ điều khiển của TV"));
                    return;
                }

                String safeTitle = title != null && !title.isEmpty() ? safeXml(title) : "Media";
                String safeMime = mimeType != null && !mimeType.isEmpty() ? mimeType : (mediaUrl.contains(".mp4") || mediaUrl.contains("stream") || mediaUrl.contains("video") ? "video/mp4" : "image/jpeg");
                String itemClass = safeMime.startsWith("image/") ? "object.item.imageItem.photo" : "object.item.videoItem";

                // 1. Dừng media hiện tại nếu TV đang phát dở
                try {
                    String stopSoap = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                            "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                            "  <s:Body>\n" +
                            "    <u:Stop xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">\n" +
                            "      <InstanceID>0</InstanceID>\n" +
                            "    </u:Stop>\n" +
                            "  </s:Body>\n" +
                            "</s:Envelope>";
                    sendSoap(device.controlUrl, "urn:schemas-upnp-org:service:AVTransport:1#Stop", stopSoap);
                } catch (Exception ignored) {}

                // 2. DIDL-Lite XML (Chuẩn Samsung Tizen OS)
                String didlXml = "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" " +
                        "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
                        "xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\" " +
                        "xmlns:dlna=\"urn:schemas-dlna-org:metadata-1-0/\">" +
                        "<item id=\"0\" parentID=\"-1\" restricted=\"1\">" +
                        "<dc:title>" + safeTitle + "</dc:title>" +
                        "<upnp:class>" + itemClass + "</upnp:class>" +
                        "<res protocolInfo=\"http-get:*:" + safeMime + ":DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000\">" + safeXml(mediaUrl) + "</res>" +
                        "</item></DIDL-Lite>";

                String escapedDidl = safeXml(didlXml);

                boolean uriSet = false;
                Exception lastEx = null;

                // Thử 1: Chuẩn SOAP AVTransport với Double-Escaped DIDL (Samsung Tizen)
                try {
                    String setUriSoap = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                            "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                            "  <s:Body>\n" +
                            "    <u:SetAVTransportURI xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">\n" +
                            "      <InstanceID>0</InstanceID>\n" +
                            "      <CurrentURI>" + safeXml(mediaUrl) + "</CurrentURI>\n" +
                            "      <CurrentURIMetaData>" + escapedDidl + "</CurrentURIMetaData>\n" +
                            "    </u:SetAVTransportURI>\n" +
                            "  </s:Body>\n" +
                            "</s:Envelope>";
                    sendSoap(device.controlUrl, "urn:schemas-upnp-org:service:AVTransport:1#SetAVTransportURI", setUriSoap);
                    uriSet = true;
                } catch (Exception e1) {
                    lastEx = e1;
                }

                // Thử 2: Thử với Empty MetaData
                if (!uriSet) {
                    try {
                        String setUriSoapEmpty = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                                "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                                "  <s:Body>\n" +
                                "    <u:SetAVTransportURI xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">\n" +
                                "      <InstanceID>0</InstanceID>\n" +
                                "      <CurrentURI>" + safeXml(mediaUrl) + "</CurrentURI>\n" +
                                "      <CurrentURIMetaData></CurrentURIMetaData>\n" +
                                "    </u:SetAVTransportURI>\n" +
                                "  </s:Body>\n" +
                                "</s:Envelope>";
                        sendSoap(device.controlUrl, "urn:schemas-upnp-org:service:AVTransport:1#SetAVTransportURI", setUriSoapEmpty);
                        uriSet = true;
                    } catch (Exception e2) {
                        lastEx = e2;
                    }
                }

                // Thử 3: Thử với NOT_IMPLEMENTED MetaData
                if (!uriSet) {
                    try {
                        String setUriSoapNotImp = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                                "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                                "  <s:Body>\n" +
                                "    <u:SetAVTransportURI xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">\n" +
                                "      <InstanceID>0</InstanceID>\n" +
                                "      <CurrentURI>" + safeXml(mediaUrl) + "</CurrentURI>\n" +
                                "      <CurrentURIMetaData>NOT_IMPLEMENTED</CurrentURIMetaData>\n" +
                                "    </u:SetAVTransportURI>\n" +
                                "  </s:Body>\n" +
                                "</s:Envelope>";
                        sendSoap(device.controlUrl, "urn:schemas-upnp-org:service:AVTransport:1#SetAVTransportURI", setUriSoapNotImp);
                        uriSet = true;
                    } catch (Exception e3) {
                        lastEx = e3;
                    }
                }

                if (!uriSet && lastEx != null) {
                    throw lastEx;
                }

                // 3. Gửi lệnh Play
                try {
                    String playSoap = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                            "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                            "  <s:Body>\n" +
                            "    <u:Play xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">\n" +
                            "      <InstanceID>0</InstanceID>\n" +
                            "      <Speed>1</Speed>\n" +
                            "    </u:Play>\n" +
                            "  </s:Body>\n" +
                            "</s:Envelope>";
                    sendSoap(device.controlUrl, "urn:schemas-upnp-org:service:AVTransport:1#Play", playSoap);
                } catch (Exception ePlay) {
                    try {
                        String playSoapSimple = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                                "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                                "  <s:Body>\n" +
                                "    <u:Play xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">\n" +
                                "      <InstanceID>0</InstanceID>\n" +
                                "    </u:Play>\n" +
                                "  </s:Body>\n" +
                                "</s:Envelope>";
                        sendSoap(device.controlUrl, "urn:schemas-upnp-org:service:AVTransport:1#Play", playSoapSimple);
                    } catch (Exception ignored) {}
                }

                if (callback != null) mainHandler.post(callback::onSuccess);
            } catch (Exception e) {
                Log.w(TAG, "Play on TV error: " + e.getMessage());
                if (callback != null) mainHandler.post(() -> callback.onError(e.getMessage()));
            }
        });
    }

    public static void pauseMedia(DlnaDevice device, ActionCallback callback) {
        executor.execute(() -> {
            try {
                String pauseSoap = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                        "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                        "  <s:Body>\n" +
                        "    <u:Pause xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">\n" +
                        "      <InstanceID>0</InstanceID>\n" +
                        "    </u:Pause>\n" +
                        "  </s:Body>\n" +
                        "</s:Envelope>";
                sendSoap(device.controlUrl, "urn:schemas-upnp-org:service:AVTransport:1#Pause", pauseSoap);
                if (callback != null) mainHandler.post(callback::onSuccess);
            } catch (Exception e) {
                if (callback != null) mainHandler.post(() -> callback.onError(e.getMessage()));
            }
        });
    }

    public static void stopMedia(DlnaDevice device, ActionCallback callback) {
        executor.execute(() -> {
            try {
                String stopSoap = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                        "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                        "  <s:Body>\n" +
                        "    <u:Stop xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">\n" +
                        "      <InstanceID>0</InstanceID>\n" +
                        "    </u:Stop>\n" +
                        "  </s:Body>\n" +
                        "</s:Envelope>";
                sendSoap(device.controlUrl, "urn:schemas-upnp-org:service:AVTransport:1#Stop", stopSoap);
                if (callback != null) mainHandler.post(callback::onSuccess);
            } catch (Exception e) {
                if (callback != null) mainHandler.post(() -> callback.onError(e.getMessage()));
            }
        });
    }

    private static String sendSoap(String controlUrl, String soapAction, String soapBody) throws Exception {
        URL url = new URL(controlUrl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(8000);
        conn.setReadTimeout(8000);
        conn.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"");
        conn.setRequestProperty("SOAPAction", "\"" + soapAction + "\"");
        conn.setRequestProperty("User-Agent", "DLNADOC/1.50 SEC_HHP_CW/1.0");

        byte[] bytes = soapBody.getBytes(StandardCharsets.UTF_8);
        conn.setRequestProperty("Content-Length", String.valueOf(bytes.length));

        try (OutputStream os = conn.getOutputStream()) {
            os.write(bytes);
            os.flush();
        }

        int respCode = conn.getResponseCode();
        InputStream is = (respCode >= 200 && respCode < 300) ? conn.getInputStream() : conn.getErrorStream();
        StringBuilder sb = new StringBuilder();
        if (is != null) {
            BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append("\n");
            r.close();
        }

        if (respCode >= 400) {
            throw new Exception("TV trả về mã lỗi " + respCode + ": " + sb);
        }
        return sb.toString();
    }

    private static String safeXml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }
}
