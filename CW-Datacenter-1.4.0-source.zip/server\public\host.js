'use strict';
const ACTION_META = {
  upload: { icon: '<svg class="ic svg-12"><use href="#i-upload"/></svg>', color: 'var(--green)', vi: 'Tải lên' },
  download: { icon: '<svg class="ic svg-12"><use href="#i-download"/></svg>', color: 'var(--blue)', vi: 'Tải xuống / Xem' },
  delete: { icon: '<svg class="ic svg-12"><use href="#i-trash"/></svg>', color: 'var(--red)', vi: 'Xóa' },
  edit: { icon: '<svg class="ic svg-12"><use href="#i-edit"/></svg>', color: 'var(--purple)', vi: 'Chỉnh sửa' },
  rename: { icon: '<svg class="ic svg-12"><use href="#i-swap"/></svg>', color: 'var(--purple)', vi: 'Đổi tên' },
  mkdir: { icon: '<svg class="ic svg-12"><use href="#i-folderplus"/></svg>', color: 'var(--blue)', vi: 'Tạo thư mục' },
  login: { icon: '<svg class="ic svg-12"><use href="#i-user"/></svg>', color: 'var(--purple)', vi: 'Tài khoản' },
  share: { icon: '<svg class="ic svg-12"><use href="#i-share"/></svg>', color: 'var(--orange)', vi: 'Chia sẻ' },
  restore: { icon: '<svg class="ic svg-12"><use href="#i-restore"/></svg>', color: 'var(--green)', vi: 'Khôi phục' },
  purge: { icon: '<svg class="ic svg-12"><use href="#i-trashnav"/></svg>', color: 'var(--red)', vi: 'Dọn thùng rác' },
};

function userLabel(a) {
  const u = a.user || 'khách';
  return '<b style="font-weight:650">' + esc(u) + '</b>&nbsp;';
}

let pollTimer = null;
const spark = { down: [], up: [] };

async function enterApp() {
  await refresh();
  if (!pollTimer) pollTimer = setInterval(refresh, 3000);
}

function fmtRate(b) {
  if (!b) return '0 B/s';
  const u = ['B/s', 'KB/s', 'MB/s', 'GB/s'];
  const i = Math.min(3, Math.floor(Math.log(b) / Math.log(1024)));
  return (b / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1) + ' ' + u[i];
}
function fmtUptime(sec) {
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  return 'Hoạt động: ' + (d ? d + ' ngày ' : '') + h + ' giờ ' + m + ' phút';
}
function sparkPoints(arr) {
  if (!arr.length) return '0,34 100,34';
  const max = Math.max(1, ...arr);
  return arr.map((v, i) => {
    const x = arr.length === 1 ? 50 : (i / (arr.length - 1)) * 100;
    const y = 34 - (v / max) * 30;
    return x.toFixed(1) + ',' + y.toFixed(1);
  }).join(' ');
}

async function refresh() {
  let d;
  try { d = await apiJson('/api/dashboard'); }
  catch (e) {
    if (String(e.message).indexOf('đăng nhập') >= 0 || String(e.message).indexOf('401') >= 0) showLogin();
    return;
  }
  $('#sb-host').textContent = d.host;
  $('#host-label').innerHTML = '<svg class="ic svg-16" style="vertical-align:-3px"><use href="#i-hserver"/></svg> &nbsp;Host: ' + esc(d.host);

  $('#m-storage').innerHTML = fmtSize(d.storage.total - d.storage.free) + ' <small>/ ' + fmtSize(d.storage.total) + '</small>';
  $('#m-storage-pct').textContent = d.storage.usedPct + '% đã dùng';
  $('#m-storage-bar').style.width = d.storage.usedPct + '%';
  $('#m-storage-free').textContent = fmtSize(d.storage.free) + ' trống';

  $('#m-net-down').textContent = fmtRate(d.network.rateRx) + ' ↓';
  $('#m-net-up').textContent = fmtRate(d.network.rateTx) + ' ↑';
  spark.down = d.network.histRx.slice(-20);
  spark.up = d.network.histTx.slice(-20);
  $('#spark-down svg polyline').setAttribute('points', sparkPoints(spark.down));
  $('#spark-up svg polyline').setAttribute('points', sparkPoints(spark.up));

  $('#m-devices').textContent = d.devicesOnline;
  $('#m-devices-last').textContent = d.devices.length
    ? 'Kết nối gần nhất: ' + d.devices[0].name + '<br>' + timeAgo(new Date(d.devices[0].created).toISOString())
    : 'Chưa có thiết bị nào kết nối';

  $('#m-transfers').textContent = d.activeTransfers;
  $('#m-transfers-remain').textContent = d.transferRemaining ? 'còn ' + fmtSize(d.transferRemaining) : 'Không có chuyển động nào';

  $('#pool-body').innerHTML =
    '<tr><td><svg class="ic svg-16"><use href="#i-drives"/></svg> &nbsp;Được chia sẻ</td><td style="word-break:break-all">' + esc(d.root) + '</td><td>' + fmtSize(d.pool.size) + '</td><td>' + fmtSize(d.pool.capacity || 1) + '</td>' +
    '<td><div style="display:flex;align-items:center;gap:8px">' + d.pool.usedPct + '%<div class="tinybar"><span style="width:' + d.pool.usedPct + '%"></span></div></div></td></tr>';

  const devRows = d.devices.slice(0, 8).map((dev) => {
    const status = dev.online
      ? '<span class="device-online"><span class="dot" style="width:8px;height:8px"></span>Trực tuyến</span>'
      : '<span class="device-offline">' + ICON('circle', 'svg-10') + ' Ngoại tuyến</span>';
    const via = dev.via === 'tailscale' ? '<span style="color:var(--blue);font-weight:600;display:inline-flex;align-items:center;gap:5px">' + ICON('lan', 'svg-14') + ' Tailscale</span>' : '<svg class="ic svg-14"><use href="#i-lan"/></svg> LAN';
    return '<tr><td><svg class="ic svg-16"><use href="#i-phone"/></svg> &nbsp;' + esc(dev.name) + '</td><td>' + status + '</td><td>' + via + '</td><td>' + esc(dev.ip) + '</td></tr>';
  });
  $('#devices-body').innerHTML = devRows.join('') || '<tr><td colspan="4" class="muted">Chưa có thiết bị nào kết nối</td></tr>';

  const ts = d.tailscale || {};
  const tsChip = $('#ts-chip');
  if (ts.running) {
    tsChip.className = 'conn-chip tailscale';
    tsChip.textContent = 'Tailscale BẬT' + (ts.selfIp ? ' • ' + ts.selfIp : '');
    $('#sb-tailnet').textContent = 'Tailscale: BẬT (' + (ts.selfIp || 'chưa có IP') + ')';
  } else if (ts.installed) {
    tsChip.className = 'conn-chip dead';
    tsChip.textContent = 'Tailscale TẮT' + (ts.reason ? '' : ' (chưa kết nối)');
    $('#sb-tailnet').textContent = 'Tailscale: đã cài, chưa kết nối';
  } else {
    tsChip.className = 'conn-chip dead';
    tsChip.textContent = 'Chưa cài Tailscale';
    $('#sb-tailnet').textContent = 'Tailscale: chưa cài';
  }

  renderShares(d.shares || []);

  const actRows = d.activity.slice(0, 6).map((a) => {
    const meta = ACTION_META[a.action] || { icon: '·', color: 'var(--muted)' };
    return '<div class="activity-row"><span class="activity-ico" style="color:' + meta.color + '">' + meta.icon + '</span><span>' + userLabel(a) + esc(a.label) + '</span><span class="muted">' + timeAgo(a.time) + '</span></div>';
  });
  $('#activity-list').innerHTML = actRows.join('') || '<div class="muted" style="padding:10px 0">Chưa có hoạt động</div>';

  const cpu = Math.min(100, d.health.cpu);
  const mem = Math.min(100, d.health.memPct);
  $('#donut-cpu').style.setProperty('--p', cpu + '%');
  $('#donut-mem').style.setProperty('--p', mem + '%');
  $('#donut-cpu-pct').textContent = cpu + '%';
  $('#donut-mem-pct').textContent = mem + '%';
  $('#cpu-pct').textContent = cpu + '%';
  $('#mem-pct').textContent = mem + '%';
  $('#cpu-model').textContent = d.health.cpus + '<br>' + d.health.platform;
  $('#cpu-model').innerHTML = d.health.cpus.split(' ').length > 8 ? esc(d.health.cpus.slice(0, 40)) + '<br>' + esc(d.health.platform) : esc(d.health.cpus) + '<br>' + esc(d.health.platform);
  $('#mem-detail').textContent = fmtSize(d.health.memUsed) + ' / ' + fmtSize(d.health.memTotal);
  $('#uptime').textContent = fmtUptime(d.uptime);
  $('#health-status').innerHTML = cpu > 90 || mem > 90 ? '<span style="color:var(--orange);display:inline-flex;align-items:center;gap:6px">' + ICON('warn', 'svg-14') + ' Tải cao</span>' : '<span style="display:inline-flex;align-items:center;gap:6px">' + ICON('checkcircle', 'svg-14') + ' Mọi thứ bình thường</span>';
}

function shareUrl(id) { return location.origin + '/s/?id=' + encodeURIComponent(id); }
function renderShares(sharesList) {
  const dead = (s) => (s.expires && Date.now() > s.expires) || (s.maxUses && s.uses >= s.maxUses);
  const fmtExp = (s) => s.expires ? new Date(s.expires).toLocaleString() : 'không hạn';

  const mini = $('#shares-mini-body');
  if (mini) {
    const rows = sharesList.slice(0, 5).map((s) =>
      '<tr><td><svg class="ic svg-16"><use href="#i-share"/></svg> &nbsp;' + esc(s.name) + '</td><td>' + fmtExp(s.expires) + '</td><td>' + s.uses + (s.maxUses ? ' / ' + s.maxUses : '') + '</td><td style="text-align:right">' + (dead(s) ? '<span class="muted">hết hạn</span>' : '<a class="small-link" target="_blank" href="' + shareUrl(s.id) + '">mở ›</a>') + '</td></tr>'
    );
    mini.innerHTML = rows.join('') || '<tr><td colspan="4" class="muted">Không có link chia sẻ nào</td></tr>';
  }

  const body = $('#shares-body');
  if (!body) return;
  $('#shares-empty').classList.toggle('hidden', sharesList.length > 0);
  body.innerHTML = sharesList.map((s) => {
    const d = dead(s);
    return '<tr' + (d ? ' style="opacity:.55"' : '') + '>' +
      '<td><svg class="ic svg-16"><use href="#i-share"/></svg> &nbsp;' + esc(s.name) + '</td>' +
      '<td>' + (s.type === 'dir' ? 'Thư mục (ZIP)' : 'Tệp') + '</td>' +
      '<td class="muted">' + new Date(s.created).toLocaleDateString() + '</td>' +
      '<td>' + (d && s.maxUses && s.uses >= s.maxUses ? 'đã dùng hết' : d ? 'hết hạn' : fmtExp(s.expires)) + '</td>' +
      '<td>' + s.uses + (s.maxUses ? ' / ' + s.maxUses : '') + '</td>' +
      '<td>' + (d ? '<span class="muted">—</span>' : '<a class="small-link" target="_blank" href="' + shareUrl(s.id) + '">' + shareUrl(s.id).split('?')[1] + '</a>') + '</td>' +
      '<td><span class="small-link" data-revoke="' + s.id + '" style="color:var(--red)">Thu hồi</span></td></tr>';
  }).join('');
  body.querySelectorAll('[data-revoke]').forEach((el) => {
    el.addEventListener('click', async () => {
      try {
        await apiJson('/api/shares?id=' + encodeURIComponent(el.dataset.revoke), { method: 'DELETE' });
        toast('Đã thu hồi link chia sẻ');
        refreshShares();
      } catch (e) { toast(e.message, 'err'); }
    });
  });
}
async function refreshShares() {
  try {
    const d = await apiJson('/api/shares');
    renderShares(d.shares || []);
  } catch (e) { toast(e.message, 'err'); }
}

async function refreshLogs() {
  try {
    const d = await apiJson('/api/dashboard');
    const rows = d.activity.map((a) => {
      const meta = ACTION_META[a.action] || { icon: '·', color: 'var(--muted)', vi: a.action };
      return '<tr><td><span style="display:inline-flex;align-items:center;gap:8px"><span class="activity-ico" style="color:' + meta.color + ';width:22px;height:22px">' + meta.icon + '</span>' + (meta.vi || a.action) + '</span></td><td>' + esc(a.label) + '</td><td class="muted"><b>' + esc(a.user || 'khách') + '</b><br><span style="font-size:11.5px">' + esc(a.ip) + '</span></td><td class="muted">' + timeAgo(a.time) + '</td></tr>';
    });
    $('#logs-body').innerHTML = rows.join('') || '<tr><td colspan="4" class="muted">Chưa ghi nhận hoạt động nào</td></tr>';
  } catch (e) { toast(e.message, 'err'); }
}

$$('.nav-item').forEach((item) => {
  item.addEventListener('click', () => {
    $$('.nav-item').forEach((x) => x.classList.remove('active'));
    item.classList.add('active');
    const v = item.dataset.view;
    $('#view-dashboard').classList.toggle('hidden', v !== 'dashboard');
    $('#view-logs').classList.toggle('hidden', v !== 'logs');
    $('#view-files').classList.toggle('hidden', v !== 'files');
    $('#view-shares').classList.toggle('hidden', v !== 'shares');
    $('#view-locks').classList.toggle('hidden', v !== 'locks');
    $('#view-users').classList.toggle('hidden', v !== 'users');
    $('#view-settings').classList.toggle('hidden', v !== 'settings');
    $('#view-drives').classList.toggle('hidden', v !== 'drives');
    if (v === 'logs') refreshLogs();
    if (v === 'shares') refreshShares();
    if (v === 'locks') refreshLocks();
    if (v === 'users') refreshUsers();
    if (v === 'settings') loadSettings();
    if (v === 'drives') loadDrives();
    if (v === 'files') {
      const fr = $('#files-frame');
      if (fr.src === 'about:blank') fr.src = '/?embed=1';
    }
  });
});

/* ---------- Locked Passwords management ---------- */
let locksCache = [];
let lockPassVisible = {};

async function refreshLocks() {
  try {
    const data = await apiJson('/api/locks');
    locksCache = data.locks || [];
    renderLocks();
  } catch (e) {
    toast(e.message, 'err');
  }
}

function renderLocks() {
  const total = locksCache.length;
  const drives = locksCache.filter((l) => l.type === 'drive').length;
  const files = total - drives;
  if ($('#lk-stat-total')) $('#lk-stat-total').textContent = total;
  if ($('#lk-stat-drives')) $('#lk-stat-drives').textContent = drives;
  if ($('#lk-stat-files')) $('#lk-stat-files').textContent = files;

  const empty = $('#locks-empty');
  const tbody = $('#locks-body');
  if (!empty || !tbody) return;
  if (!total) {
    empty.classList.remove('hidden');
    tbody.innerHTML = '';
    return;
  }
  empty.classList.add('hidden');

  tbody.innerHTML = locksCache.map((l) => {
    const isDrive = l.type === 'drive';
    const isFolder = l.type === 'folder' || (!isDrive && !l.path.includes('.'));
    const iconSym = isDrive ? 'i-drives' : (isFolder ? 'i-folder' : 'i-lock');
    const iconColor = isDrive ? 'var(--purple)' : (isFolder ? '#f4b422' : 'var(--blue)');
    const typeLabel = isDrive ? 'Ổ đĩa' : (isFolder ? 'Thư mục' : 'Tệp');
    const isVis = !!lockPassVisible[l.id];
    const passDisplay = isVis ? esc(l.password || '') : '••••••••';
    const eyeIcon = isVis ? 'i-eye-off' : 'i-eye';
    const pathSub = l.path ? '/' + esc(l.path) : '(Toàn bộ ổ)';

    return '<tr>'
      + '<td><div style="display:flex;align-items:center;gap:9px"><span style="color:' + iconColor + ';display:flex;align-items:center"><svg class="ic svg-18"><use href="#' + iconSym + '"/></svg></span><div><div style="font-weight:600">' + esc(l.name || l.path || 'Mục') + '</div><div class="muted" style="font-size:11.5px">' + typeLabel + ' · ' + pathSub + '</div></div></div></td>'
      + '<td><span class="badge blue">' + esc(l.pool || 'main') + '</span></td>'
      + '<td><div style="display:inline-flex;align-items:center;gap:8px;background:#f8fafc;padding:4px 8px;border-radius:6px;border:1px solid #e2e8f0"><span style="font-family:monospace;font-size:13px;font-weight:600;min-width:70px">' + passDisplay + '</span><button class="btn-icon" data-lk-toggle="' + esc(l.id) + '" title="' + (isVis ? 'Ẩn mật khẩu' : 'Xem mật khẩu') + '" style="background:transparent;border:0;cursor:pointer;color:#64748b;display:flex;align-items:center;padding:2px"><svg class="ic svg-16"><use href="#' + eyeIcon + '"/></svg></button></div></td>'
      + '<td><b>' + esc(l.user || 'admin') + '</b></td>'
      + '<td class="muted">' + timeAgo(l.updatedAt || l.createdAt) + '</td>'
      + '<td><div style="display:flex;gap:6px"><button class="btn" data-lk-edit="' + esc(l.id) + '" style="height:32px;padding:0 10px;font-size:12.5px"><svg class="ic svg-14"><use href="#i-edit"/></svg> Sửa</button><button class="btn" data-lk-del="' + esc(l.id) + '" style="height:32px;padding:0 10px;font-size:12.5px;color:var(--red)"><svg class="ic svg-14"><use href="#i-trash"/></svg> Gỡ</button></div></td>'
      + '</tr>';
  }).join('');

  tbody.querySelectorAll('[data-lk-toggle]').forEach((b) => {
    b.addEventListener('click', () => {
      const id = b.dataset.lkToggle;
      lockPassVisible[id] = !lockPassVisible[id];
      renderLocks();
    });
  });

  tbody.querySelectorAll('[data-lk-edit]').forEach((b) => {
    b.addEventListener('click', () => {
      const id = b.dataset.lkEdit;
      const l = locksCache.find((x) => x.id === id);
      if (l) openEditLockDialog(l);
    });
  });

  tbody.querySelectorAll('[data-lk-del]').forEach((b) => {
    b.addEventListener('click', () => {
      const id = b.dataset.lkDel;
      const l = locksCache.find((x) => x.id === id);
      if (l) deleteLock(l);
    });
  });
}

function openEditLockDialog(l) {
  const back = document.createElement('div');
  back.className = 'overlay';
  back.innerHTML = '<div class="dialog" style="width:420px">'
    + '<h3>Đổi mật khẩu khóa</h3>'
    + '<div class="hint">Đang đổi mật khẩu cho <b>' + esc(l.name) + '</b> (' + (l.type === 'drive' ? 'Ổ đĩa' : l.path) + ').</div>'
    + '<div style="margin:14px 0">'
    + '<label style="display:block;font-size:12px;font-weight:600;margin-bottom:6px;color:#475467">Mật khẩu mới</label>'
    + '<input type="text" id="lk-edit-pass" value="' + esc(l.password || '') + '" style="width:100%;height:38px;padding:0 10px;border:1px solid #d0d5dd;border-radius:8px;font-size:14px">'
    + '</div>'
    + '<div class="dialog-btns"><button class="btn" data-a="cancel">Hủy</button><button class="btn primary" data-a="ok">Lưu mật khẩu</button></div>'
    + '</div>';
  document.body.appendChild(back);
  const inp = back.querySelector('#lk-edit-pass');
  inp.focus();
  inp.select();

  back.querySelector('[data-a="cancel"]').addEventListener('click', () => back.remove());
  back.querySelector('[data-a="ok"]').addEventListener('click', async () => {
    const pw = inp.value.trim();
    if (pw.length < 3) { toast('Mật khẩu tối thiểu 3 ký tự', 'err'); return; }
    try {
      await apiJson('/api/locks/update', { method: 'POST', body: JSON.stringify({ id: l.id, password: pw }) });
      toast('Đã cập nhật mật khẩu cho "' + l.name + '"');
      back.remove();
      refreshLocks();
    } catch (e) { toast(e.message, 'err'); }
  });
}

async function deleteLock(l) {
  if (!confirm('Bạn có chắc chắn muốn gỡ bỏ mật khẩu khóa cho "' + l.name + '"?\nSau khi gỡ, mọi người có thể mở tệp/thư mục này mà không cần nhập mật khẩu.')) return;
  try {
    await apiJson('/api/locks', { method: 'DELETE', body: JSON.stringify({ id: l.id }) });
    toast('Đã gỡ khóa "' + l.name + '"');
    refreshLocks();
  } catch (e) { toast(e.message, 'err'); }
}

const btnLocksRefresh = $('#btn-locks-refresh');
if (btnLocksRefresh) btnLocksRefresh.addEventListener('click', refreshLocks);
function gotoView(v) {
  const it = $$('.nav-item').find((x) => x.dataset.view === v);
  if (it) it.click();
}

$('#btn-open-client').addEventListener('click', () => open('/', '_blank'));
$('#btn-phone').addEventListener('click', openPhoneDialog);

let lastDash = null;
async function openPhoneDialog() {
  try {
    if (!lastDash) lastDash = await apiJson('/api/dashboard');
    const d = lastDash;
    const inv = await apiJson('/api/invite', { method: 'POST' });
    const ip = (d.lanIps && d.lanIps[0]) || location.hostname;
    const url = 'http://' + ip + ':' + (d.port || 8080) + '/?invite=' + encodeURIComponent(inv.code);
    const back = document.createElement('div');
    back.className = 'overlay';
    back.innerHTML = `<div class="dialog" style="width:420px;text-align:center">
      <h3 style="text-align:left"><svg class="ic svg-18"><use href="#i-qr"/></svg> Kết nối điện thoại</h3>
      <div class="hint" style="text-align:left">Hướng camera điện thoại vào mã QR. Link hoạt động trong mạng LAN — không cần mật khẩu trong 15 phút.</div>
      <canvas id="qr-canvas" style="margin:8px auto 12px;image-rendering:pixelated;width:220px;height:220px;border:1px solid var(--line);border-radius:10px"></canvas>
      <div class="share-out"><input type="text" readonly id="qr-url"><button class="btn" style="height:42px" id="qr-copy">Copy</button></div>
      <div class="muted" style="font-size:12.5px;margin-bottom:14px;text-align:left">Mã mời: <b id="qr-code"></b> · hết hạn lúc <span id="qr-exp"></span></div>
      <div class="dialog-btns"><button class="btn" data-a="cancel">Đóng</button><button class="btn primary" data-a="new"><svg class="ic svg-16"><use href="#i-refresh"/></svg> Mã mới</button></div>
    </div>`;
    document.body.appendChild(back);
    const cv = back.querySelector('#qr-canvas');
    window.QRCodeLib.toCanvas(cv, url, { width: 220, margin: 2, errorCorrectionLevel: 'L' });
    back.querySelector('#qr-url').value = url;
    back.querySelector('#qr-code').textContent = inv.code;
    back.querySelector('#qr-exp').textContent = new Date(inv.expiresAt).toLocaleTimeString();
    const done = () => back.remove();
    back.querySelector('[data-a=cancel]').onclick = done;
    back.addEventListener('mousedown', (e) => { if (e.target === back) done(); });
    back.querySelector('#qr-copy').addEventListener('click', async (e) => {
      try { await navigator.clipboard.writeText(url); } catch { back.querySelector('#qr-url').select(); document.execCommand('copy'); }
      e.target.innerHTML = 'Đã copy <svg class="ic svg-12"><use href="#i-check"/></svg>';
      setTimeout(() => { e.target.textContent = 'Copy'; }, 1500);
    });
    back.querySelector('[data-a=new]').onclick = async () => {
      try {
        const inv2 = await apiJson('/api/invite', { method: 'POST' });
        const url2 = 'http://' + ip + ':' + (d.port || 8080) + '/?invite=' + encodeURIComponent(inv2.code);
        back.querySelector('#qr-url').value = url2;
        back.querySelector('#qr-code').textContent = inv2.code;
        back.querySelector('#qr-exp').textContent = new Date(inv2.expiresAt).toLocaleTimeString();
        window.QRCodeLib.toCanvas(cv, url2, { width: 220, margin: 2, errorCorrectionLevel: 'L' });
        toast('Đã tạo mã mời mới');
      } catch (e) { toast(e.message, 'err'); }
    };
  } catch (e) { toast(e.message, 'err'); }
}

$('#btn-logs-refresh').addEventListener('click', refreshLogs);
$('#btn-shares-refresh').addEventListener('click', refreshShares);
$('#shares-link').addEventListener('click', () => gotoView('shares'));
$('#activity-link').addEventListener('click', () => gotoView('logs'));
$('#pool-link').addEventListener('click', () => gotoView('drives'));
$('#devices-link').addEventListener('click', () => toast('Danh sách thiết bị ở trên hiển thị tất cả client đã kết nối', 'warn'));

/* ---------- Storage drives (chia sẻ ổ cho client chọn khi lưu) ---------- */
async function loadDrives() {
  try {
    const [d, pl] = await Promise.all([
      apiJson('/api/drives'),
      apiJson('/api/pools').catch(() => ({ pools: [] })),
    ]);
    renderDrives(d.drives || [], d.pools || [], (pl && pl.pools) || []);
  } catch (e) { toast(e.message, 'err'); }
}

function renderDrives(drives, pools, poolStats) {
  const body = $('#drives-body');
  if (!body) return;
  const defId = (pools.find((p) => p.isDefault) || {}).id || 'main';
  const mainPool = pools.find((p) => p.id === 'main') || { id: 'main', name: 'Shared', path: '' };
  const mainStat = poolStats.find((p) => p.id === 'main') || {};

  const rows = [{
    id: 'main',
    path: mainPool.path,
    label: '<svg class="ic svg-16"><use href="#i-drive"/></svg> &nbsp;<b>' + esc(mainPool.name || 'Shared') + '</b> <span class="muted" style="font-weight:400">(thư mục chia sẻ)</span>',
    free: mainStat.free || 0,
    total: mainStat.total || 0,
    enabled: true,
    locked: true,
    isDefault: defId === 'main',
  }];
  for (const dv of drives) {
    const pool = pools.find((p) => p.id !== 'main' && p.path.toLowerCase() === String(dv.path).toLowerCase());
    const st = pool ? (poolStats.find((p) => p.id === pool.id) || dv) : dv;
    rows.push({
      id: pool ? pool.id : '',
      path: dv.path,
      label: '<svg class="ic svg-16"><use href="#i-drive"/></svg> &nbsp;<b>' + esc(dv.displayName || dv.name || dv.path) + '</b>' + (pool ? ' <span class="muted" style="font-weight:400">(đang chia sẻ)</span>' : ''),
      free: st.free || 0,
      total: st.total || 0,
      enabled: !!pool,
      locked: false,
      isDefault: !!(pool && pool.id === defId),
    });
  }

  $('#drives-empty').classList.toggle('hidden', rows.length > 0);
  body.innerHTML = rows.map((r) => {
    const pct = r.total ? Math.round(((r.total - r.free) / r.total) * 100) : 0;
    return '<tr data-path="' + esc(r.path) + '" data-id="' + esc(r.id || '') + '">' +
      '<td style="text-align:center"><input type="checkbox" class="dv-en"' + (r.enabled ? ' checked' : '') + (r.locked ? ' disabled title="Shared folder mặc định — luôn bật"' : '') + '></td>' +
      '<td>' + r.label + '</td>' +
      '<td class="muted" style="word-break:break-all;font-size:12.5px">' + esc(r.path) + '</td>' +
      '<td>' + fmtSize(r.free) + '</td>' +
      '<td>' + fmtSize(r.total) + '</td>' +
      '<td><div style="display:flex;align-items:center;gap:6px">' + pct + '%<div class="tinybar" style="flex:1;min-width:50px"><span style="width:' + pct + '%"></span></div></div></td>' +
      '<td style="text-align:center"><input type="radio" name="dv-def" class="dv-def"' + (r.isDefault ? ' checked' : '') + ' title="Ổ mặc định khi client không chọn ổ"></td></tr>';
  }).join('');

  body.querySelectorAll('tr').forEach((tr) => {
    const en = tr.querySelector('.dv-en');
    const def = tr.querySelector('.dv-def');
    const sync = () => { def.disabled = !en.checked; if (!en.checked) def.checked = false; };
    if (!en.disabled) en.addEventListener('change', sync);
    sync();
  });
}

$('#btn-drives-refresh').addEventListener('click', loadDrives);
$('#btn-drives-save').addEventListener('click', async () => {
  const rows = $$('#drives-body tr');
  if (!rows.length) return toast('Danh sách ổ trống — hãy quét lại.', 'warn');
  const drives = rows.map((tr) => {
    const entry = {
      path: tr.dataset.path,
      enabled: tr.querySelector('.dv-en').checked,
      isDefault: tr.querySelector('.dv-def').checked,
    };
    if (tr.dataset.id) entry.id = tr.dataset.id;
    return entry;
  });
  if (!drives.some((d) => d.isDefault && d.enabled)) {
    const main = drives.find((d) => d.id === 'main');
    if (main) main.isDefault = true;
  }
  try {
    const r = await apiJson('/api/pools/config', { method: 'POST', body: JSON.stringify({ drives }) });
    toast('Đã lưu — ' + (r.pools || []).length + ' ổ đang chia sẻ cho client');
    loadDrives();
  } catch (e) { toast(e.message, 'err'); }
});

/* ---------- Users management ---------- */
let usersCache = [];

function scopeChips(scope, poolNames) {
  const arr = Array.isArray(scope) ? scope : [];
  if (!arr.length || arr.includes('*')) return '<span class="sc-folder-badge" title="Toàn quyền trên mọi ổ"><svg class="ic svg-12"><use href="#i-drives"/></svg> Tất cả</span>';
  return arr.map((e) => {
    const s = String(e);
    let label = s;
    if (/^pool:/i.test(s)) label = poolNames[s.slice(5).toLowerCase()] || s.slice(5);
    else if (/^path:/i.test(s)) { const p = s.slice(5); label = p.replace(/\\/g, '/'); }
    const short = label.length > 34 ? '…' + label.slice(-33) : label;
    return '<span class="sc-folder-badge" title="' + esc(label) + '"><svg class="ic svg-12"><use href="#i-' + (/^pool:/i.test(s) ? 'drives' : 'folder') + '"/></svg>' + esc(short) + '</span>';
  }).join(' ');
}

function openScopeDialog(currentScope, onOk) {
  const scope = Array.isArray(currentScope) && currentScope.length ? currentScope.map(String) : ['*'];
  const back = document.createElement('div');
  back.className = 'overlay';
  back.innerHTML = '<div class="dialog" style="width:620px;max-width:94vw;max-height:92vh;display:flex;flex-direction:column">'
    + '<h3 style="margin-bottom:6px">Phạm vi truy cập</h3>'
    + '<div class="hint" style="margin-bottom:10px">Tích chọn ổ đĩa hoặc bấm mũi tên để mở rộng và chọn riêng thư mục con. Không tích hoặc chọn "Tất cả" = xem toàn bộ.</div>'
    + '<div style="margin:4px 0 10px"><label style="display:flex;align-items:center;gap:8px;font-size:14px;cursor:pointer">'
    + '<input type="checkbox" id="sc-all" style="width:16px;height:16px;accent-color:var(--blue)"> <b>Tất cả ổ đĩa / thư mục (Toàn quyền)</b></label></div>'
    + '<div class="scope-tree" id="sc-tree" style="flex:1;max-height:320px;overflow-y:auto;min-height:180px;border:1px solid #d6dee9;border-radius:10px;background:#fbfcfe;padding:8px 10px;margin-bottom:10px">đang tải…</div>'
    + '<div class="scope-head" style="margin:4px 0 6px"><span class="scope-title" style="font-size:12px;font-weight:700;color:var(--muted);text-transform:uppercase">Phạm vi đã chọn:</span></div>'
    + '<div class="scope-list-box" id="sc-selected" style="max-height:96px;overflow-y:auto;display:flex;flex-wrap:wrap;gap:6px;border:1px solid #d6dee9;border-radius:8px;min-height:42px;padding:6px 10px;background:#fbfcfe"></div>'
    + '<div class="dialog-btns" style="margin-top:14px;display:flex;justify-content:flex-end;gap:8px"><button class="btn" data-a="cancel">Hủy</button><button class="btn primary" data-a="ok">Xong</button></div></div>';
  document.body.appendChild(back);

  const tree = back.querySelector('#sc-tree');
  const selectedBox = back.querySelector('#sc-selected');
  const allChk = back.querySelector('#sc-all');
  let entries = [];
  const expanded = {};
  const cache = {};

  const isAll = () => allChk.checked || entries.includes('*');
  const hasScope = (entry) => entries.includes(entry);

  function normEntry(s) { return String(s); }
  function isAllInput() { return !scope.length || scope.includes('*'); }

  function entryLabel(s) {
    if (/^pool:/i.test(s)) {
      const p = (window._scopePools || []).find((x) => x.id.toLowerCase() === s.slice(5).toLowerCase());
      return p ? p.name : s.slice(5);
    }
    if (/^path:/i.test(s)) {
      return s.slice(5).replace(/\\/g, '/');
    }
    return s;
  }

  function renderSelected() {
    selectedBox.innerHTML = '';
    if (isAll()) {
      allChk.checked = true;
      selectedBox.innerHTML = '<span class="muted" style="font-size:12.5px;line-height:28px">Tất cả ổ và thư mục — không giới hạn</span>';
      syncTree();
      return;
    }
    allChk.checked = false;
    if (!entries.length) {
      selectedBox.innerHTML = '<span class="muted" style="font-size:12.5px;line-height:28px">Chưa chọn gì — tài khoản sẽ không thấy ổ/thư mục nào</span>';
      syncTree();
      return;
    }
    entries.forEach((e) => {
      const lab = String(entryLabel(e) || e);
      const isPool = /^pool:/i.test(e);
      const chip = document.createElement('span');
      chip.className = 'sc-folder-badge';
      chip.style.cssText = 'display:inline-flex;align-items:center;gap:6px;background:#eff6ff;color:var(--blue);border:1px solid #a9cdff;border-radius:6px;padding:3px 10px;font-size:12px;font-weight:600;';
      chip.innerHTML = '<svg class="ic svg-12"><use href="#i-' + (isPool ? 'drives' : 'folder') + '"/></svg> '
        + esc(lab.length > 42 ? '…' + lab.slice(-40) : lab)
        + '<span class="sc-x" title="Bỏ chọn" style="cursor:pointer;opacity:0.6;margin-left:4px;font-size:14px;font-weight:bold">&times;</span>';
      chip.querySelector('.sc-x').onclick = () => {
        entries = entries.filter((x) => x !== e);
        renderSelected();
      };
      selectedBox.appendChild(chip);
    });
    syncTree();
  }

  function syncTree() {
    tree.querySelectorAll('input[type=checkbox]').forEach((c) => {
      if (c.id === 'sc-all') return;
      const key = c.dataset.entry;
      if (!key) return;
      c.checked = isAll() || hasScope(key);
      if (/^pool:/i.test(key)) {
        const poolId = key.slice(5);
        const p = (window._scopePools || []).find((x) => x.id.toLowerCase() === poolId.toLowerCase());
        const root = p ? (p.root || p.path || '') : '';
        const normRoot = root.toLowerCase().replace(/\\/g, '/').replace(/\/+$/, '');
        c.indeterminate = !isAll() && !hasScope(key) && entries.some((e) => {
          if (!/^path:/i.test(e)) return false;
          const cp = e.slice(5).toLowerCase().replace(/\\/g, '/');
          return cp.startsWith(normRoot + '/') || cp === normRoot;
        });
      }
    });
  }

  async function toggleExpand(poolId, dirPath, holderEl, foldBtn, depth) {
    const expandKey = 'exp:' + dirPath;
    expanded[expandKey] = !expanded[expandKey];
    foldBtn.innerHTML = expanded[expandKey]
      ? '<svg class="ic svg-14"><use href="#i-chevron"/></svg>'
      : '<svg class="ic svg-14"><use href="#i-chevron-r"/></svg>';

    if (!expanded[expandKey]) {
      holderEl.style.display = 'none';
      return;
    }

    holderEl.style.display = 'block';
    if (cache[expandKey]) {
      renderFolderList(cache[expandKey], poolId, holderEl, depth);
      return;
    }

    holderEl.innerHTML = '<div class="scope-row" style="padding-left:' + (24 + depth * 18) + 'px"><span class="muted" style="font-size:12px">Đang quét thư mục con…</span></div>';
    try {
      const r = await apiJson('/api/fs/browse?path=' + encodeURIComponent(dirPath));
      const dirs = (r.entries || []).filter((e) => e.type === 'dir' || e.path);
      cache[expandKey] = dirs;
      renderFolderList(dirs, poolId, holderEl, depth);
    } catch (err) {
      holderEl.innerHTML = '<div class="scope-row" style="padding-left:' + (24 + depth * 18) + 'px"><span class="muted" style="font-size:12px;color:var(--red)">Không đọc được thư mục con</span></div>';
    }
  }

  function renderFolderList(dirs, poolId, holderEl, depth) {
    holderEl.innerHTML = '';
    if (!dirs || !dirs.length) {
      holderEl.innerHTML = '<div class="scope-row" style="padding-left:' + (24 + depth * 18) + 'px"><span class="muted" style="font-size:12px">Không có thư mục con</span></div>';
      return;
    }
    for (const d of dirs) {
      const row = document.createElement('div');
      row.className = 'scope-row';
      row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:5px 6px;padding-left:' + (20 + depth * 20) + 'px;border-radius:7px;cursor:pointer;user-select:none';
      const key = 'path:' + d.path;
      const expandKey = 'exp:' + d.path;

      row.innerHTML = '<input type="checkbox" data-entry="' + esc(key) + '" style="width:15px;height:15px;accent-color:var(--blue);cursor:pointer;flex-shrink:0">'
        + '<span class="sc-fold" style="cursor:pointer;width:18px;height:18px;display:inline-grid;place-items:center;flex-shrink:0">' + (expanded[expandKey] ? '<svg class="ic svg-14"><use href="#i-chevron"/></svg>' : '<svg class="ic svg-14"><use href="#i-chevron-r"/></svg>') + '</span>'
        + '<svg class="ic svg-16" style="color:#f4b422;flex-shrink:0"><use href="#i-folder"/></svg>'
        + '<span class="sc-name" style="font-size:13.5px;font-weight:600">' + esc(d.name) + '</span>'
        + '<span class="sc-path" style="font-size:11.5px;color:var(--muted);margin-left:4px">(' + esc(d.path) + ')</span>';

      holderEl.appendChild(row);

      const chk = row.querySelector('input');
      chk.checked = isAll() || hasScope(key);

      chk.addEventListener('change', () => {
        if (isAll() && !chk.checked) {
          allChk.checked = false;
        }
        if (chk.checked) {
          entries = entries.filter((e) => e !== 'pool:' + poolId);
          const cPath = d.path.toLowerCase().replace(/\\/g, '/');
          entries = entries.filter((e) => {
            if (!/^path:/i.test(e)) return true;
            const ep = e.slice(5).toLowerCase().replace(/\\/g, '/');
            return !(cPath.startsWith(ep + '/') || ep === cPath);
          });
          if (!entries.includes(key)) entries.push(key);
        } else {
          entries = entries.filter((e) => e !== key);
        }
        renderSelected();
      });

      const subHolder = document.createElement('div');
      subHolder.style.display = expanded[expandKey] ? 'block' : 'none';
      holderEl.appendChild(subHolder);

      const foldBtn = row.querySelector('.sc-fold');
      const nameBtn = row.querySelector('.sc-name');
      const toggle = () => toggleExpand(poolId, d.path, subHolder, foldBtn, depth + 1);
      foldBtn.onclick = (ev) => { ev.stopPropagation(); toggle(); };
      nameBtn.onclick = toggle;
    }
    syncTree();
  }

  async function renderTree() {
    const pools = window._scopePools || [];
    tree.innerHTML = '';
    if (!pools.length) {
      tree.innerHTML = '<span class="muted" style="font-size:13px">Không có ổ nào đang chia sẻ.</span>';
      return;
    }
    for (const p of pools) {
      const rootPath = p.root || p.path || '';
      const poolKey = 'pool:' + p.id;
      const expandKey = 'exp:' + rootPath;

      const row = document.createElement('div');
      row.className = 'scope-row';
      row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:6px 6px;border-radius:7px;cursor:pointer;user-select:none';
      row.innerHTML = '<input type="checkbox" data-entry="' + esc(poolKey) + '" style="width:16px;height:16px;accent-color:var(--blue);cursor:pointer;flex-shrink:0">'
        + '<span class="sc-fold" style="cursor:pointer;width:18px;height:18px;display:inline-grid;place-items:center;flex-shrink:0">' + (expanded[expandKey] ? '<svg class="ic svg-14"><use href="#i-chevron"/></svg>' : '<svg class="ic svg-14"><use href="#i-chevron-r"/></svg>') + '</span>'
        + '<svg class="ic svg-16" style="color:var(--blue);flex-shrink:0"><use href="#i-drives"/></svg>'
        + '<span class="sc-name" style="font-size:14px;font-weight:700">' + esc(p.name) + '</span>'
        + '<span class="sc-path" style="font-size:11.5px;color:var(--muted);margin-left:4px">(' + esc(rootPath) + ')</span>';

      tree.appendChild(row);

      const chk = row.querySelector('input');
      chk.checked = isAll() || hasScope(poolKey);

      chk.addEventListener('change', () => {
        if (isAll() && !chk.checked) {
          allChk.checked = false;
        }
        if (chk.checked) {
          const rootNorm = rootPath.toLowerCase().replace(/\\/g, '/').replace(/\/+$/, '');
          entries = entries.filter((e) => {
            if (!/^path:/i.test(e)) return true;
            const ep = e.slice(5).toLowerCase().replace(/\\/g, '/');
            return !(ep === rootNorm || ep.startsWith(rootNorm + '/'));
          });
          if (!entries.includes(poolKey)) entries.push(poolKey);
        } else {
          entries = entries.filter((e) => e !== poolKey);
        }
        renderSelected();
      });

      const subHolder = document.createElement('div');
      subHolder.style.display = expanded[expandKey] ? 'block' : 'none';
      tree.appendChild(subHolder);

      const foldBtn = row.querySelector('.sc-fold');
      const nameBtn = row.querySelector('.sc-name');
      const toggle = () => toggleExpand(p.id, rootPath, subHolder, foldBtn, 1);
      foldBtn.onclick = (ev) => { ev.stopPropagation(); toggle(); };
      nameBtn.onclick = toggle;

      if (expanded[expandKey]) {
        toggleExpand(p.id, rootPath, subHolder, foldBtn, 1);
      }
    }
    syncTree();
  }

  (async () => {
    try {
      const d = await apiJson('/api/drives');
      window._scopePools = (d.pools || []).map((p) => ({ ...p, root: p.root || p.path }));
    } catch { window._scopePools = []; }
    entries = isAllInput() ? [] : scope.map(normEntry);
    renderSelected();
    await renderTree();
  })();

  allChk.addEventListener('change', () => {
    if (allChk.checked) entries = [];
    renderSelected();
  });
  if (isAllInput()) { allChk.checked = true; }

  const done = () => back.remove();
  back.querySelector('[data-a=cancel]').onclick = done;
  back.addEventListener('mousedown', (e) => { if (e.target === back) done(); });
  back.querySelector('[data-a=ok]').onclick = () => {
    const out = allChk.checked || !entries.length ? ['*'] : entries.slice();
    done();
    onOk(out);
  };
}

async function refreshUsers() {
  try {
    let poolNames = {};
    try {
      const d = await apiJson('/api/drives');
      window._scopePools = d.pools || [];
      (d.pools || []).forEach((p) => { poolNames[String(p.id).toLowerCase()] = p.name; });
    } catch {}
    const d = await apiJson('/api/users');
    usersCache = d.users || [];
    const online = usersCache.filter((u) => u.online).length;
    $('#u-stat-total').textContent = usersCache.length;
    $('#u-stat-online').textContent = online;
    $('#u-stat-invite').textContent = (await apiJson('/api/settings').catch(() => ({}))).inviteRole || 'editor';
    $('#users-empty').classList.toggle('hidden', usersCache.length > 0);
    const body = $('#users-body');
    body.innerHTML = usersCache.map((u) => {
      const role = u.role === 'viewer' ? 'viewer' : 'editor';
      const status = u.online
        ? '<span class="device-online"><span class="dot" style="width:8px;height:8px"></span>Trực tuyến' + (u.sessions > 1 ? ' ×' + u.sessions : '') + '</span>'
        : '<span class="device-offline">' + ICON('circle', 'svg-10') + ' Ngoại tuyến</span>';
      return '<tr data-name="' + esc(u.name) + '">' +
        '<td><div class="file-name"><span class="file-ico code" style="background:' + (role === 'viewer' ? 'var(--green)' : 'var(--blue)') + ';color:#fff"><svg class="ic svg-16"><use href="#i-user"/></svg></span><b>' + esc(u.name) + '</b></div>' +
        '<div style="margin-top:5px">' + scopeChips(u.scope, poolNames) + '</div></td>' +
        '<td><span class="role-chip ' + role + '">' + role + '</span></td>' +
        '<td>' + status + '</td>' +
        '<td class="muted">' + (u.lastLogin ? timeAgo(u.lastLogin) : 'chưa bao giờ') + '</td>' +
        '<td class="muted">' + (u.created ? new Date(u.created).toLocaleDateString() : '—') + '</td>' +
        '<td style="text-align:right;white-space:nowrap">' +
        '<select class="u-role" style="height:32px;border:1px solid #d6dee9;border-radius:6px;font-size:12.5px;padding:0 6px;margin-right:6px;width:90px">' +
        '<option value="editor"' + (role === 'editor' ? ' selected' : '') + '>editor</option>' +
        '<option value="viewer"' + (role === 'viewer' ? ' selected' : '') + '>viewer</option></select>' +
        '<button class="btn u-scope" style="height:32px;padding:0 10px" title="Phạm vi ổ/thư mục"><svg class="ic svg-14"><use href="#i-target"/></svg></button> ' +
        '<button class="btn u-pw" style="height:32px;padding:0 10px" title="Đặt lại mật khẩu"><svg class="ic svg-14"><use href="#i-key"/></svg></button> ' +
        '<button class="btn u-logout" style="height:32px;padding:0 10px" title="Đăng xuất mọi thiết bị"><svg class="ic svg-14"><use href="#i-eject"/></svg></button> ' +
        '<button class="btn danger u-del" style="height:32px;width:34px;padding:0" title="Xóa người dùng"><svg class="ic svg-14"><use href="#i-user-x"/></svg></button>' +
        '</td></tr>';
    }).join('');
    body.querySelectorAll('tr[data-name]').forEach((row) => {
      const name = row.dataset.name;
      const user = usersCache.find((u) => u.name === name) || {};
      row.querySelector('.u-role').addEventListener('change', async (e) => {
        try {
          await apiJson('/api/users/update', { method: 'POST', body: JSON.stringify({ name, role: e.target.value }) });
          toast('"' + name + '" → ' + e.target.value);
          refreshUsers();
        } catch (er) { toast(er.message, 'err'); refreshUsers(); }
      });
      row.querySelector('.u-scope').addEventListener('click', () => {
        openScopeDialog(user.scope, async (scope) => {
          try {
            await apiJson('/api/users/update', { method: 'POST', body: JSON.stringify({ name, scope }) });
            toast('Đã cập nhật phạm vi của "' + name + '"');
            refreshUsers();
          } catch (er) { toast(er.message, 'err'); }
        });
      });
      row.querySelector('.u-pw').addEventListener('click', () => {
        promptDialog('Mật khẩu mới cho "' + name + '"', '', 'Đặt lại', async (pw) => {
          try {
            await apiJson('/api/users/update', { method: 'POST', body: JSON.stringify({ name, password: pw }) });
            toast('Đã đặt lại mật khẩu cho "' + name + '"');
          } catch (er) { toast(er.message, 'err'); }
        });
      });
      row.querySelector('.u-logout').addEventListener('click', async () => {
        try {
          const r = await apiJson('/api/users/sessions?name=' + encodeURIComponent(name), { method: 'DELETE' });
          toast('Đã đăng xuất ' + (r.sessionsRevoked || 0) + ' thiết bị của "' + name + '"');
          refreshUsers();
        } catch (er) { toast(er.message, 'err'); }
      });
      row.querySelector('.u-del').addEventListener('click', () => {
        confirmDialog('Xóa "' + name + '"?', 'Tài khoản này sẽ bị xóa và mọi thiết bị của nó sẽ bị đăng xuất. Không thể hoàn tác.', 'Xóa', async () => {
          try {
            await apiJson('/api/users?name=' + encodeURIComponent(name), { method: 'DELETE' });
            toast('Đã xóa người dùng "' + name + '"');
            refreshUsers();
          } catch (er) { toast(er.message, 'err'); }
        });
      });
    });
  } catch (e) { toast(e.message, 'err'); }
}
$('#btn-users-refresh').addEventListener('click', refreshUsers);
$('#btn-user-add').addEventListener('click', () => {
  let chosenScope = ['*'];
  const back = document.createElement('div');
  back.className = 'overlay';
  back.innerHTML = '<div class="dialog"><h3><svg class="ic svg-18"><use href="#i-plus"/></svg> Thêm người dùng</h3>' +
    '<div class="hint">Tên: chữ cái, số, . _ - và dấu cách (2–32 ký tự).</div>' +
    '<input type="text" id="nu-name" placeholder="Tên đăng nhập" autocomplete="off" spellcheck="false">' +
    '<input type="password" id="nu-pw" placeholder="Mật khẩu (tối thiểu 4 ký tự)" autocomplete="off">' +
    '<div class="share-opts" style="margin-bottom:14px;gap:10px;align-items:center"><label style="gap:10px;display:flex;align-items:center"><select id="nu-role" style="min-width:130px"><option value="viewer">viewer</option><option value="editor">editor</option></select><span class="muted" style="font-size:12.5px">viewer = xem, tải về, yêu thích · editor = tải lên &amp; chỉnh sửa</span></label></div>' +
    '<div class="scope-head"><span class="scope-title">Phạm vi chia sẻ</span></div>' +
    '<button class="btn" id="nu-scope-btn" style="height:38px;margin-bottom:6px"><svg class="ic svg-14"><use href="#i-target"/></svg> Chọn ổ / thư mục…</button>' +
    '<div class="scope-list-box" id="nu-scope-view" style="margin-bottom:12px"><span class="muted" style="font-size:12.5px">Tất cả ổ và thư mục — không giới hạn</span></div>' +
    '<div class="dialog-btns"><button class="btn" data-a="cancel">Hủy</button><button class="btn primary" data-a="ok">Tạo</button></div></div>';
  document.body.appendChild(back);
  const scopeView = back.querySelector('#nu-scope-view');
  function renderChosen() {
    if (!chosenScope.length || chosenScope.includes('*')) {
      scopeView.innerHTML = '<span class="muted" style="font-size:12.5px">Tất cả ổ và thư mục — không giới hạn</span>';
      return;
    }
    scopeView.innerHTML = chosenScope.map((e) => {
      const lab = /^pool:/i.test(e) ? ((window._scopePools || []).find((p) => p.id.toLowerCase() === e.slice(5).toLowerCase()) || e.slice(5)) : e.slice(5);
      const labS = typeof lab === 'string' ? lab : lab.name || String(lab);
      return '<span class="sc-folder-badge"><svg class="ic svg-12"><use href="#i-' + (/^pool:/i.test(e) ? 'drives' : 'folder') + '"/></svg>' + esc(labS.length > 40 ? '…' + labS.slice(-39) : labS) + '</span>';
    }).join(' ');
  }
  back.querySelector('#nu-scope-btn').onclick = () => {
    openScopeDialog(chosenScope, (sc) => { chosenScope = sc; renderChosen(); });
  };
  renderChosen();
  const done = () => back.remove();
  back.querySelector('[data-a=cancel]').onclick = done;
  back.addEventListener('mousedown', (e) => { if (e.target === back) done(); });
  back.querySelector('#nu-name').focus();
  back.querySelector('[data-a=ok]').onclick = async () => {
    try {
      const r = await apiJson('/api/users', { method: 'POST', body: JSON.stringify({
        name: back.querySelector('#nu-name').value.trim(),
        password: back.querySelector('#nu-pw').value,
        role: back.querySelector('#nu-role').value,
        scope: chosenScope,
      }) });
      done();
      toast('Đã tạo tài khoản "' + r.name + '"');
      refreshUsers();
    } catch (e) { toast(e.message, 'err'); }
  };
});

/* ---------- Settings ---------- */
let settingsLoaded = false;
async function loadSettings() {
  try {
    const s = await apiJson('/api/settings');
    $('#s-host').textContent = s.host || window.location.hostname;
    $('#s-port').value = s.port;
    $('#s-adminuser').value = s.adminUser || 'admin';
    $('#btn-account-label').textContent = s.adminUser || 'admin';
    $('#s-root').value = s.root;
    $('#s-curpw').value = '';
    $('#s-curpw').placeholder = 'nhập nếu muốn đổi mật khẩu';
    $('#s-newpw').value = '';
    $('#s-invite-role').value = s.inviteRole || 'editor';
    $('#s-usercount').textContent = (s.userCount || 0) + ' người dùng — ' + (s.sessionCount || 0) + ' phiên hoạt động';
    $('#s-sessions').textContent = (s.sessionCount || 0) + ' phiên hoạt động · ' + (s.userCount || 0) + ' tài khoản';
    $('#s-lan').innerHTML = (s.lanIps || []).map((ip) => '<code style="background:#f2f6ff;padding:2px 8px;border-radius:6px;margin-right:6px">' + esc(ip) + ':' + s.port + '</code>').join(' ');
    const ts = s.tailscale || {};
    $('#s-tailscale').textContent = ts.running ? 'BẬT — ' + (ts.selfIp || 'đã kết nối') + (ts.tailnet ? ' (' + ts.tailnet + ')' : '') : ts.installed ? 'đã cài, chưa kết nối' : 'chưa cài';
    $('#s-tailscale').style.color = ts.running ? 'var(--green)' : 'var(--muted)';
    try {
      const pl = await apiJson('/api/pools');
      const pools = pl.pools || [];
      $('#s-drives-info').innerHTML = pools.length
        ? pools.map((p) => '<div><svg class="ic svg-16"><use href="#i-drive"/></svg> <b>' + esc(p.name) + '</b> <span class="muted" style="font-size:12.5px">' + esc(p.root) + '</span>' + (p.isDefault ? ' <span style="color:var(--blue);font-size:12px;font-weight:600">(mặc định)</span>' : '') + '</div>').join('')
        : '—';
    } catch {}
  } catch (e) { toast(e.message, 'err'); }
  const asCard = $('#s-autostart');
  if (asCard && window.host && window.host.autoStartGet) {
    try {
      const r = await window.host.autoStartGet();
      asCard.disabled = !r.ok;
      asCard.checked = !!(r.ok && r.on);
    } catch { asCard.disabled = true; }
    if (!asCard.dataset.wired) {
      asCard.dataset.wired = '1';
      asCard.addEventListener('change', async () => {
        try {
          const r = await window.host.autoStartSet(asCard.checked);
          if (r.ok) toast(asCard.checked ? 'Đã bật: app host sẽ tự chạy ngầm khi mở Windows.' : 'Đã tắt mở cùng Windows.');
          else throw new Error(r.error || 'Không lưu được.');
        } catch (e) { toast(e.message, 'err'); asCard.checked = !asCard.checked; }
      });
    }
  } else if (asCard) {
    asCard.disabled = true;
    asCard.title = 'Chỉ dùng được trong app host (không chạy trên trình duyệt)';
  }
}
/* ---------- Browse folder picker đã bỏ — dùng tab Ổ lưu trữ ---------- */
$('#btn-s-drives').addEventListener('click', () => gotoView('drives'));

$('#btn-s-save').addEventListener('click', async () => {
  const body = {};
  const portVal = Number($('#s-port').value);
  if (portVal) body.port = portVal;

  const adminUserVal = $('#s-adminuser').value.trim();
  if (adminUserVal) body.adminUser = adminUserVal;

  const rootVal = $('#s-root').value.trim();
  if (rootVal) {
    body.root = rootVal;
    body.createRoot = $('#s-create-root').checked;
  }

  const curPw = $('#s-curpw').value;
  if (curPw) body.currentPassword = curPw;

  const newPw = $('#s-newpw').value;
  if (newPw) body.password = newPw;

  try {
    const r = await apiJson('/api/settings', { method: 'POST', body: JSON.stringify(body) });
    if (r.changed && r.changed.length) {
      toast('Đã lưu cài đặt (' + r.changed.join(', ') + ')');
    } else {
      toast('Cài đặt đã được lưu thành công');
    }
    $('#s-newpw').value = '';
    $('#s-curpw').value = '';
    if (r.portChanged) {
      toast('Server chuyển sang cổng ' + r.port + ' — đang kết nối lại…', 'warn');
      const newBase = location.protocol + '//' + location.hostname + ':' + r.port;
      let tries = 0;
      const wait = setInterval(async () => {
        try {
          const h = await fetch(newBase + '/api/health');
          if (h.ok) { clearInterval(wait); toast('Đã kết nối trên cổng ' + r.port); location.href = newBase + '/host.html'; }
        } catch {}
        if (++tries > 15) { clearInterval(wait); toast('Không kết nối được server trên cổng ' + r.port + '. Hãy tải lại thủ công.', 'err'); }
      }, 1000);
    } else {
      loadSettings();
    }
  } catch (e) { toast(e.message, 'err'); }
});
$('#btn-invite-save').addEventListener('click', async () => {
  try {
    await apiJson('/api/settings', { method: 'POST', body: JSON.stringify({ inviteRole: $('#s-invite-role').value }) });
    toast('Quyền QR mời: ' + $('#s-invite-role').value);
    refreshUsers();
  } catch (e) { toast(e.message, 'err'); }
});
$('#s-goto-users').addEventListener('click', () => gotoView('users'));
const btnFixFw = $('#btn-s-fix-firewall');
if (btnFixFw) {
  btnFixFw.addEventListener('click', async () => {
    btnFixFw.disabled = true;
    const oldText = btnFixFw.innerHTML;
    btnFixFw.innerHTML = '<svg class="ic svg-16"><use href="#i-refresh"/></svg> Đang mở UAC…';
    try {
      if (window.host && window.host.fixFirewall) {
        toast('Đang yêu cầu quyền Administrator (UAC). Vui lòng chọn "Yes" nếu xuất hiện thông báo…', 'info');
        const r = await window.host.fixFirewall();
        if (r && r.ok) {
          toast('✅ Đã mở quyền Tường lửa Windows (Port ' + (r.port || 8080) + ', UDP 46631) thành công!');
        } else {
          toast('Chưa cấp được quyền: ' + ((r && r.error) || 'bạn đã từ chối quyền UAC.'), 'err');
        }
      } else {
        toast('Chỉ khả dụng trong App Host Desktop.', 'warn');
      }
    } catch (e) {
      toast('Lỗi: ' + e.message, 'err');
    } finally {
      btnFixFw.innerHTML = oldText;
      btnFixFw.disabled = false;
    }
  });
}

(async function initHostConsole() {
  enterApp();
  loadSettings();
})();
