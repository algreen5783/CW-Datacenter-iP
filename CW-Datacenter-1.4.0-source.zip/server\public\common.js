'use strict';
const $ = (s) => document.querySelector(s);
const $$ = (s) => Array.from(document.querySelectorAll(s));

async function api(url, opts = {}) {
  const headers = { ...(opts.headers || {}) };
  if (typeof opts.body === 'string') headers['Content-Type'] = 'application/json';
  const token = localStorage.getItem('cw_token');
  if (token && !headers['Authorization'] && !headers['authorization']) {
    headers['Authorization'] = 'Bearer ' + token;
  }
  const res = await fetch(url, { ...opts, headers });
  return res;
}
async function apiJson(url, opts) {
  const res = await api(url, opts);
  if (res.status === 401 && typeof onSessionLost === 'function') { onSessionLost(); }
  const data = res.status === 204 ? {} : await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || 'Lỗi ' + res.status);
    err.status = res.status;
    throw err;
  }
  return data;
}
function onSessionLost() {
}

function toast(msg, type, action) {
  const el = document.createElement('div');
  el.className = 'toast' + (type === 'err' ? ' err' : type === 'warn' ? ' warn' : '');
  const span = document.createElement('span');
  const ico = type === 'err' ? 'x' : type === 'warn' ? 'warn' : 'checkcircle';
  span.innerHTML = '<svg class="ic svg-14" style="flex-shrink:0;margin-right:7px"><use href="#i-' + ico + '"/></svg>' + esc(msg);
  span.style.cssText = 'flex:1;display:inline-flex;align-items:center';
  el.appendChild(span);
  if (action && action.label) {
    const b = document.createElement('button');
    b.textContent = action.label;
    b.style.cssText = 'margin-left:10px;border:1px solid rgba(11,108,255,.4);background:#eff6ff;color:var(--blue);border-radius:6px;padding:4px 12px;font-weight:600;font-size:12.5px;cursor:pointer;white-space:nowrap';
    b.addEventListener('click', () => { el.remove(); action.fn(); });
    el.appendChild(b);
  }
  const dur = action ? 6000 : 3400;
  ($('#toasts') || document.body).appendChild(el);
  setTimeout(() => el.remove(), dur);
}

function fmtName(name, maxLen) {
  const n = String(name ?? '');
  const limit = maxLen || 46;
  if (n.length <= limit) return n;
  const dot = n.lastIndexOf('.');
  if (dot > 0 && dot >= 4) {
    const ext = n.slice(dot);
    const stem = n.slice(0, dot);
    return stem.slice(0, limit - ext.length - 2) + '…' + ext;
  }
  return n.slice(0, limit - 1) + '…';
}
function fmtSize(b) {
  if (!b || b === 0) return '—';
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.min(u.length - 1, Math.floor(Math.log(b) / Math.log(1024)));
  return (b / Math.pow(1024, i)).toFixed(i === 0 ? 0 : i === 1 ? 0 : 1) + ' ' + u[i];
}
function fmtDate(s) {
  try {
    const d = new Date(s);
    return String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0') + '/' + d.getFullYear() + ' ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  } catch { return '—'; }
}
function timeAgo(s) {
  const sec = Math.max(0, (Date.now() - new Date(s).getTime()) / 1000);
  if (sec < 60) return Math.round(sec) + 's trước';
  if (sec < 3600) return Math.round(sec / 60) + ' phút trước';
  if (sec < 86400) return Math.round(sec / 3600) + ' giờ trước';
  return Math.round(sec / 86400) + ' ngày trước';
}

function fileKind(name) {
  const ext = (name || '').toLowerCase().split('.').pop();
  const table = {
    pdf: ['pdf', 'pdf'],
    mp4: ['video', 'video'], mkv: ['video', 'video-cam'], avi: ['video', 'video-cam'], mov: ['video', 'video-cam'], webm: ['video', 'video'], flv: ['video', 'video-cam'], wmv: ['video', 'video-cam'], m4v: ['video', 'video'],
    mp3: ['audio', 'music'], wav: ['audio', 'music'], flac: ['audio', 'music'], m4a: ['audio', 'music'], ogg: ['audio', 'music'], aac: ['audio', 'music'],
    png: ['img', 'image'], jpg: ['img', 'image'], jpeg: ['img', 'image'], gif: ['img', 'image'], webp: ['img', 'image'], bmp: ['img', 'image'], svg: ['img', 'image'], ico: ['img', 'image'], avif: ['img', 'image'],
    zip: ['archive', 'archive'], rar: ['archive', 'archive'], '7z': ['archive', 'archive'], tar: ['archive', 'archive'], gz: ['archive', 'archive'], iso: ['archive', 'archive'],
    onnx: ['model', 'cube'], pt: ['model', 'cube'], safetensors: ['model', 'cube'], bin: ['model', 'cube'], gguf: ['model', 'cube'], h5: ['model', 'cube'],
    js: ['code', 'code'], ts: ['code', 'code'], jsx: ['code', 'code'], tsx: ['code', 'code'], py: ['code', 'code'], json: ['code', 'code'], css: ['code', 'code'], html: ['code', 'code'],
    xml: ['code', 'code'], yml: ['code', 'code'], yaml: ['code', 'code'], ini: ['code', 'code'], bat: ['code', 'code'], ps1: ['code', 'code'], sh: ['code', 'code'],
  };
  return table[ext] || ['text', 'text'];
}
const TEXT_EXT = /\.(txt|md|log|json|js|ts|jsx|tsx|css|scss|html|htm|xml|yml|yaml|ini|cfg|conf|env|sh|bat|ps1|py|java|c|cpp|h|hpp|cs|go|rs|sql|csv|srt|vue|php|rb)$/i;
const IMG_EXT = /\.(png|jpe?g|gif|webp|bmp|svg|avif)$/i;
const MEDIA_EXT = /\.(mp4|webm|mp3|wav|ogg|m4a|pdf)$/i;
const PREVIEW_IMG = /\.(png|jpe?g|gif|webp|avif)$/i;

function iconHtml(name, type) {
  if (type === 'dir') return '<span class="file-ico folder"><svg class="ic svg-22"><use href="#i-folder"/></svg></span>';
  const [cls, sym] = fileKind(name);
  return '<span class="file-ico ' + cls + '"><svg class="ic svg-22"><use href="#i-' + sym + '"/></svg></span>';
}
function esc(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

let ctxEl = null;
function closeCtx() { if (ctxEl) { ctxEl.remove(); ctxEl = null; } }
function openCtx(x, y, items) {
  closeCtx();
  const menu = document.createElement('div');
  menu.className = 'ctx-menu';
  items.forEach((it) => {
    if (it === '-') { menu.insertAdjacentHTML('beforeend', '<div class="ctx-sep"></div>'); return; }
    const b = document.createElement('button');
    b.className = 'ctx-item' + (it.danger ? ' danger' : '');
    b.innerHTML = '<span>' + it.icon + '</span>' + esc(it.label);
    b.onclick = () => { closeCtx(); it.fn(); };
    menu.appendChild(b);
  });
  document.body.appendChild(menu);
  const r = menu.getBoundingClientRect();
  menu.style.left = Math.min(x, innerWidth - r.width - 8) + 'px';
  menu.style.top = Math.min(y, innerHeight - r.height - 8) + 'px';
  ctxEl = menu;
}
addEventListener('mousedown', (e) => { if (ctxEl && !e.target.closest('.ctx-menu')) closeCtx(); });

function promptDialog(title, value, okLabel, onOk) {
  const back = document.createElement('div');
  back.className = 'overlay';
  back.innerHTML = '<div class="dialog"><h3></h3><input type="text"><div class="dialog-btns"><button class="btn" data-a="cancel">Hủy</button><button class="btn primary" data-a="ok"></button></div></div>';
  back.querySelector('h3').textContent = title;
  back.querySelector('[data-a=ok]').textContent = okLabel || 'OK';
  const inp = back.querySelector('input');
  inp.value = value || '';
  document.body.appendChild(back);
  inp.focus(); inp.select();
  const done = () => back.remove();
  back.querySelector('[data-a=cancel]').onclick = done;
  back.querySelector('[data-a=ok]').onclick = () => { const v = inp.value.trim(); if (v) { done(); onOk(v); } };
  inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') back.querySelector('[data-a=ok]').click(); if (e.key === 'Escape') done(); });
  back.addEventListener('mousedown', (e) => { if (e.target === back) done(); });
}
function confirmDialog(title, hint, okLabel, onOk) {
  const back = document.createElement('div');
  back.className = 'overlay';
  back.innerHTML = '<div class="dialog"><h3></h3><div class="hint"></div><div class="dialog-btns"><button class="btn" data-a="cancel">Hủy</button><button class="btn primary" style="background:var(--red);border-color:var(--red)" data-a="ok"></button></div></div>';
  back.querySelector('h3').textContent = title;
  back.querySelector('.hint').textContent = hint || '';
  back.querySelector('[data-a=ok]').textContent = okLabel || 'OK';
  document.body.appendChild(back);
  const done = () => back.remove();
  back.querySelector('[data-a=cancel]').onclick = done;
  back.querySelector('[data-a=ok]').onclick = () => { done(); onOk(); };
  back.addEventListener('mousedown', (e) => { if (e.target === back) done(); });
}

document.addEventListener('keydown', (e) => {
  if (!(e.target instanceof Element)) return;
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f' && !e.target.closest('.editor-area')) {
    const s = $('#search');
    if (s) { e.preventDefault(); s.focus(); }
  }
  if (e.ctrlKey && e.key.toLowerCase() === 'r' && !e.target.closest('.editor-area')) {
    const r = $('#refresh');
    if (r) { e.preventDefault(); r.click(); }
  }
  if (e.ctrlKey && e.key.toLowerCase() === 'u' && !e.target.closest('.editor-area')) {
    const p = $('#file-picker');
    if (p) { e.preventDefault(); p.click(); }
  }
});

/* Pure JS SHA-256 (hoạt động 100% trên cả HTTP, HTTPS, WebView, Electron) */
function sha256js(s) {
  const K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  const rr = (v, n) => (v >>> n) | (v << (32 - n));
  const H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
  const bytes = new TextEncoder().encode(s);
  const l = bytes.length, bitLen = l * 8;
  const buf = new Uint8Array(((l + 9 + 63) >> 6) << 6);
  buf.set(bytes); buf[l] = 0x80;
  const dv = new DataView(buf.buffer);
  dv.setUint32(buf.length - 8, Math.floor(bitLen / 0x100000000), false);
  dv.setUint32(buf.length - 4, bitLen >>> 0, false);
  const w = new Uint32Array(64);
  for (let i = 0; i < buf.length; i += 64) {
    for (let j = 0; j < 16; j++) w[j] = dv.getUint32(i + j * 4, false);
    for (let j = 16; j < 64; j++) {
      const s0 = rr(w[j - 15], 7) ^ rr(w[j - 15], 18) ^ (w[j - 15] >>> 3);
      const s1 = rr(w[j - 2], 17) ^ rr(w[j - 2], 19) ^ (w[j - 2] >>> 10);
      w[j] = (w[j - 16] + s0 + w[j - 7] + s1) >>> 0;
    }
    let [a, b, c, d, e, f, g, h] = H;
    for (let j = 0; j < 64; j++) {
      const S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25);
      const ch = (e & f) ^ (~e & g);
      const temp1 = (h + S1 + ch + K[j] + w[j]) >>> 0;
      const S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const temp2 = (S0 + maj) >>> 0;
      h = g; g = f; f = e; e = (d + temp1) >>> 0; d = c; c = b; b = a; a = (temp1 + temp2) >>> 0;
    }
    H[0] = (H[0] + a) >>> 0; H[1] = (H[1] + b) >>> 0; H[2] = (H[2] + c) >>> 0; H[3] = (H[3] + d) >>> 0;
    H[4] = (H[4] + e) >>> 0; H[5] = (H[5] + f) >>> 0; H[6] = (H[6] + g) >>> 0; H[7] = (H[7] + h) >>> 0;
  }
  return H.map((v) => v.toString(16).padStart(8, '0')).join('');
}
