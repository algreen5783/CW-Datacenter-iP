'use strict';
let currentPath = '';
let files = [];
let selected = null;
const selectedSet = new Map();
let anchorIndex = null;
let trId = 0;
let currentPool = '';
let pools = [];
const isTouch = (typeof matchMedia !== 'undefined') && matchMedia('(pointer:coarse)').matches && ('ontouchstart' in window || navigator.maxTouchPoints > 0) && !/Electron/.test(navigator.userAgent);

function poolById(id) { return pools.find((p) => p.id === id); }
function poolQs() { return currentPool ? '&pool=' + encodeURIComponent(currentPool) : ''; }
function poolBody(extra) {
  const body = Object.assign({}, extra || {});
  if (currentPool) body.pool = currentPool;
  return JSON.stringify(body);
}

/* ---------- Locks (mật khẩu khóa file/thư mục, đồng bộ máy chủ) ---------- */
function sha256text(s) {
  return sha256js(s);
}
function lockKeyOf(pool, dirRel, name) {
  return location.origin + '|' + (pool || 'main') + '|' + (dirRel ? dirRel + '/' : '') + name;
}
function lockKeyFor(f) {
  if (f && f._lockKey) return f._lockKey;
  return lockKeyOf(f.pool || effectivePool(), (f.dirRel != null ? f.dirRel : currentPath), f.name);
}
function effectivePool() {
  return currentPool || (pools.length ? pools[0].id : 'main');
}
function poolLockKey(poolId) {
  return location.origin + '|pool:' + (poolId || 'main') + '|';
}
function poolTarget(poolId) {
  return { kind: 'pool', name: poolId || 'Ổ mặc định', type: 'dir', rel: '', dirRel: '', pool: poolId, _lockKey: poolLockKey(poolId) };
}
function isPoolLocked(poolId) {
  if (!poolId) return false;
  const map = ensureLockMapLoaded();
  const k = poolLockKey(poolId);
  return !!(map[k] && !ensureLockSession().has(k));
}
function ensureLockSession() {
  if (!window._lockSession) {
    window._lockSession = new Set();
    try { for (const k of JSON.parse(sessionStorage.getItem('cw_lock_ok') || '[]')) window._lockSession.add(k); } catch {}
  }
  return window._lockSession;
}
function rememberUnlocked(key) {
  const s = ensureLockSession();
  s.add(key);
  try { sessionStorage.setItem('cw_lock_ok', JSON.stringify([...s])); } catch {}
}
function saveLockMap(map) {
  try { localStorage.setItem('cw_locks', JSON.stringify(map)); window._lockCache = map; } catch { window._lockCache = map; }
}
async function syncLocksFromServer() {
  try {
    const res = await apiJson('/api/locks');
    const serverLocks = res.locks || [];
    const map = {};
    for (const l of serverLocks) {
      if (l.type === 'drive') {
        map[poolLockKey(l.pool)] = l.hash;
      } else {
        const p = (l.path || '').replace(/^\/+/, '');
        const dir = p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : '';
        const nm = p.includes('/') ? p.slice(p.lastIndexOf('/') + 1) : p;
        map[lockKeyOf(l.pool || 'main', dir, nm)] = l.hash;
      }
    }
    window._serverLocks = serverLocks;
    window._lockCache = map;
    saveLockMap(map);
  } catch {}
}
function findLockedAncestor(poolId, dirRel) {
  const map = ensureLockMapLoaded();
  const sess = ensureLockSession();
  const parts = dirRel ? String(dirRel).split('/').filter(Boolean) : [];
  for (let i = 1; i <= parts.length; i++) {
    const parentDir = parts.slice(0, i - 1).join('/');
    const key = lockKeyOf(poolId, parentDir, parts[i - 1]);
    if (map[key] && !sess.has(key)) {
      return { kind: 'folder', name: parts[i - 1], type: 'dir', rel: (parentDir ? parentDir + '/' : '') + parts[i - 1], dirRel: parentDir, pool: poolId, _lockKey: key };
    }
  }
  return null;
}
function resolveLockTarget(f) {
  if (!f) return null;
  const pool = f.pool || effectivePool();
  const map = ensureLockMapLoaded();
  const sess = ensureLockSession();
  if (pool && map[poolLockKey(pool)] && !sess.has(poolLockKey(pool))) return poolTarget(pool);
  const dirRel = f.dirRel != null ? f.dirRel : currentPath;
  const anc = findLockedAncestor(pool, dirRel);
  if (anc) return anc;
  if (f.name && map[lockKeyFor(f)] && !sess.has(lockKeyFor(f))) return f;
  return null;
}
function lockWarnToast(t) {
  const key = t._lockKey || lockKeyFor(t);
  const ban = lockBanInfo(key);
  if (ban.until && Date.now() < ban.until) {
    toast((t.kind === 'pool' ? 'Ổ đĩa' : 'Mục') + ' "' + t.name + '" bị khóa tạm thời — mở lại sau ' + fmtLockDur(ban.until - Date.now()), 'warn');
  } else if (t.kind === 'pool') {
    toast('Ổ đĩa "' + t.name + '" đang bị khóa — hãy mở khóa bằng mật khẩu trước.', 'warn');
  } else {
    toast('Mục đang bị khóa — hãy mở khóa bằng mật khẩu trước.', 'warn');
  }
}
function requireUnlocked(f, fn) {
  const t = resolveLockTarget(f);
  if (!t) { fn(); return; }
  lockWarnToast(t);
  unlockDialog(t, fn);
}
async function guardLocked(f) { return resolveLockTarget(f); }
function guardLockedToast(f) {
  const t = resolveLockTarget(f);
  if (!t) return false;
  lockWarnToast(t);
  return true;
}
function fmtLockDur(ms) {
  const s = Math.max(1, Math.round(ms / 1000));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  if (h) return h + ' giờ ' + m + ' phút';
  if (m) return m + ' phút ' + sec + ' giây';
  return sec + ' giây';
}
function getLockBans() { try { return JSON.parse(localStorage.getItem('cw_lock_ban') || '{}'); } catch { return {}; } }
function saveLockBans(m2) { try { localStorage.setItem('cw_lock_ban', JSON.stringify(m2)); } catch {} }
function lockBanInfo(key) {
  const m2 = getLockBans();
  const e = m2[key];
  if (e && e.until && Date.now() < e.until) return { fails: e.fails || 0, until: e.until };
  return { fails: 0, until: 0 };
}
function lockBanUntil(f) {
  if (!f) return 0;
  try { return lockBanInfo(lockKeyFor(f)).until || 0; } catch { return 0; }
}
function recordLockFail(key) {
  const m2 = getLockBans();
  let e = m2[key];
  if (!e || (e.until && Date.now() >= e.until)) e = { fails: 0, until: 0 };
  e.fails = (e.fails || 0) + 1;
  if (e.fails >= 5) { e.until = Date.now() + 8 * 60 * 60 * 1000; e.fails = 0; }
  m2[key] = e;
  saveLockBans(m2);
  return e;
}
function clearLockBan(key) {
  const m2 = getLockBans();
  delete m2[key];
  saveLockBans(m2);
}
function ensureLockMapLoaded() {
  if (window._lockCache === undefined) window._lockCache = null;
  if (!window._lockCache) {
    try { window._lockCache = JSON.parse(localStorage.getItem('cw_locks') || '{}'); } catch { window._lockCache = {}; }
  }
  return window._lockCache;
}
function lockDialog(f) {
  const poolMode = f.kind === 'pool';
  const back = document.createElement('div');
  back.className = 'overlay';
  back.innerHTML = `<div class="dialog lock-dialog">
    <h3><svg class="ic svg-18" style="color:var(--blue)"><use href="#i-lock"/></svg> Khóa "<span class="lk-name"></span>"</h3>
    <div class="hint"></div>
    <div class="lock-form">
      <label class="lock-label">Mật khẩu khóa</label>
      <input type="password" id="lk-pw" placeholder="Tối thiểu 3 ký tự" autocomplete="new-password">
      <div class="lock-note" id="lk-note">Mật khẩu sẽ được lưu trên máy chủ và đồng bộ với app điện thoại.</div>
    </div>
    <div class="dialog-btns">
      <button class="btn" data-a="cancel">Hủy</button>
      <button class="btn primary" data-a="ok" disabled>Xác nhận</button>
    </div></div>`;
  document.body.appendChild(back);
  back.querySelector('.lk-name').textContent = poolMode ? (poolById(f.pool) ? poolById(f.pool).name : f.name) : f.name;
  back.querySelector('.hint').textContent = poolMode
    ? 'Khóa toàn bộ ổ đĩa (pool) này — mọi tệp và thư mục bên trong đều yêu cầu mật khẩu để mở trên cả PC và điện thoại.'
    : 'Đặt mật khẩu khóa cho mục này — đồng bộ tức thì trên cả PC và app điện thoại.';
  const done = () => back.remove();
  const inp = back.querySelector('#lk-pw');
  const okBtn = back.querySelector('[data-a=ok]');
  inp.addEventListener('input', () => { okBtn.disabled = inp.value.length < 3; });
  back.querySelector('[data-a=cancel]').onclick = done;
  back.addEventListener('mousedown', (e) => { if (e.target === back) done(); });
  const submit = async () => {
    if (okBtn.disabled) return;
    const nm = back.querySelector('.lk-name').textContent;
    const poolId = f.pool || effectivePool();
    const itemRel = poolMode ? '' : (f.dirRel ? f.dirRel + '/' : '') + f.name;
    const itemType = poolMode ? 'drive' : (f.type === 'dir' ? 'folder' : 'file');
    try {
      await apiJson('/api/locks', {
        method: 'POST',
        body: JSON.stringify({
          pool: poolId,
          path: itemRel,
          type: itemType,
          name: nm,
          password: inp.value
        })
      });
    } catch (err) {
      toast(err.message || 'Không khóa được', 'err');
      return;
    }
    await syncLocksFromServer();
    done();
    toast(poolMode ? 'Đã khóa ổ đĩa "' + nm + '"' : 'Đã khóa "' + f.name + '"');
    if (typeof updateLockDiskBtn === 'function') updateLockDiskBtn();
    if (poolMode) loadFiles(currentPath);
    else renderFiles();
  };
  okBtn.onclick = submit;
  inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); });
  inp.focus();
}
function lockDialogTargets(targets) {
  if (!targets || !targets.length) return;
  if (targets.length === 1) return lockDialog(targets[0]);
  const back = document.createElement('div');
  back.className = 'overlay';
  back.innerHTML = `<div class="dialog lock-dialog">
    <h3><svg class="ic svg-18" style="color:var(--blue)"><use href="#i-lock"/></svg> Khóa ${targets.length} mục đã chọn</h3>
    <div class="hint">Đặt một mật khẩu chung để khóa ${targets.length} tệp/thư mục này. Mật khẩu đồng bộ trên tất cả thiết bị.</div>
    <div class="lock-form">
      <label class="lock-label">Mật khẩu khóa</label>
      <input type="password" id="lk-pw" placeholder="Tối thiểu 3 ký tự" autocomplete="new-password">
    </div>
    <div class="dialog-btns">
      <button class="btn" data-a="cancel">Hủy</button>
      <button class="btn primary" data-a="ok" disabled>Xác nhận</button>
    </div></div>`;
  document.body.appendChild(back);
  const done = () => back.remove();
  const inp = back.querySelector('#lk-pw');
  const okBtn = back.querySelector('[data-a=ok]');
  inp.addEventListener('input', () => { okBtn.disabled = inp.value.length < 3; });
  back.querySelector('[data-a=cancel]').onclick = done;
  back.addEventListener('mousedown', (e) => { if (e.target === back) done(); });
  const submit = async () => {
    if (okBtn.disabled) return;
    for (const f of targets) {
      const poolId = f.pool || effectivePool();
      const itemRel = (f.dirRel ? f.dirRel + '/' : '') + f.name;
      const itemType = f.type === 'dir' ? 'folder' : 'file';
      try {
        await apiJson('/api/locks', {
          method: 'POST',
          body: JSON.stringify({
            pool: poolId,
            path: itemRel,
            type: itemType,
            name: f.name,
            password: inp.value
          })
        });
      } catch {}
    }
    await syncLocksFromServer();
    done();
    toast('Đã khóa ' + targets.length + ' mục bằng mật khẩu');
    renderFiles();
  };
  okBtn.onclick = submit;
  inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); });
  inp.focus();
}
async function removeLock(f) {
  const poolMode = f.kind === 'pool';
  const poolId = f.pool || effectivePool();
  const itemRel = poolMode ? '' : (f.dirRel ? f.dirRel + '/' : '') + f.name;
  const itemType = poolMode ? 'drive' : (f.type === 'dir' ? 'folder' : 'file');
  try {
    await apiJson('/api/locks', {
      method: 'DELETE',
      body: JSON.stringify({
        pool: poolId,
        path: itemRel,
        type: itemType
      })
    });
  } catch (err) {
    toast(err.message || 'Không gỡ khóa được', 'err');
    return;
  }
  await syncLocksFromServer();
  toast('Đã gỡ khóa "' + f.name + '"');
  renderFiles();
}
function unlockDialog(f, onOk) {
  const key = f._lockKey || lockKeyFor(f);
  const poolMode = f.kind === 'pool';
  const displayName = poolMode && poolById(f.pool) ? poolById(f.pool).name : f.name;
  const back = document.createElement('div');
  back.className = 'overlay';
  back.innerHTML = `<div class="dialog lock-dialog">
    <h3><svg class="ic svg-18" style="color:var(--blue)"><use href="#i-unlock"/></svg> Mở khóa "<span class="lk-name"></span>"</h3>
    <div class="hint"></div>
    <div class="lock-form">
      <label class="lock-label">Mật khẩu khóa</label>
      <input type="password" id="lk-pw" placeholder="Mật khẩu khóa" autocomplete="off">
      <div class="login-error" id="lk-err"></div>
      <div class="lock-note" id="lk-note"></div>
    </div>
    <div class="dialog-btns">
      <button class="btn" data-a="cancel">Hủy</button>
      <button class="btn primary" data-a="ok">Xác nhận</button>
    </div></div>`;
  document.body.appendChild(back);
  back.querySelector('.lk-name').textContent = displayName;
  back.querySelector('.hint').textContent = poolMode
    ? 'Ổ đĩa này đang bị khóa — nhập đúng mật khẩu khóa để dùng.'
    : (f.kind === 'folder' ? 'Thư mục "' + displayName + '" đang bị khóa — nhập đúng mật khẩu khóa để mở các tệp bên trong.' : 'Nhập đúng mật khẩu khóa đã đặt để mở.');
  const done = () => back.remove();
  const inp = back.querySelector('#lk-pw');
  const errEl = back.querySelector('#lk-err');
  const noteEl = back.querySelector('#lk-note');
  const okBtn = back.querySelector('[data-a=ok]');
  back.querySelector('[data-a=cancel]').onclick = done;
  back.addEventListener('mousedown', (e) => { if (e.target === back) done(); });

  const renderBanState = () => {
    const ban = lockBanInfo(key);
    if (ban.until && Date.now() < ban.until) {
      inp.disabled = true;
      okBtn.disabled = true;
      errEl.textContent = 'Đã nhập sai quá 5 lần — không thể mở trong vòng 8 giờ.';
      const left = ban.until - Date.now();
      noteEl.textContent = 'Mở lại sau: ' + fmtLockDur(left) + ' (lúc ' + new Date(ban.until).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) + ').';
      return true;
    }
    return false;
  };
  if (renderBanState()) { inp.blur(); }
  else {
    const ban0 = lockBanInfo(key);
    if (ban0.fails > 0) noteEl.textContent = 'Đã nhập sai ' + ban0.fails + '/5 lần.';
    inp.focus();
  }

  const check = async () => {
    const pw = inp.value;
    if (!pw || okBtn.disabled) return;
    const map = ensureLockMapLoaded();
    const stored = map[key];
    const poolMode = f.kind === 'pool';
    const poolId = f.pool || effectivePool();
    const itemRel = poolMode ? '' : (f.dirRel ? f.dirRel + '/' : '') + f.name;
    const itemType = poolMode ? 'drive' : (f.type === 'dir' ? 'folder' : 'file');

    let isOk = false;
    const h = sha256js(pw);
    if (stored && h === stored) {
      isOk = true;
    } else {
      try {
        const vRes = await apiJson('/api/locks/verify', {
          method: 'POST',
          body: JSON.stringify({
            pool: poolId,
            path: itemRel,
            type: itemType,
            password: pw
          })
        });
        if (vRes && vRes.ok) isOk = true;
      } catch {}
    }

    if (isOk) {
      clearLockBan(key);
      rememberUnlocked(key);
      done();
      toast('Đã mở khóa "' + displayName + '" — có hiệu lực đến khi tắt app');
      renderFiles();
      if (typeof updateLockDiskBtn === 'function') updateLockDiskBtn();
      if (typeof onOk === 'function') onOk();
    } else {
      const e = recordLockFail(key);
      inp.value = '';
      if (e.until && Date.now() < e.until) {
        renderBanState();
        inp.blur();
      } else {
        errEl.textContent = 'Mật khẩu không đúng (' + (e.fails || 0) + '/5 lần), thử lại.';
        noteEl.textContent = 'Còn sai thêm ' + (5 - (e.fails || 0)) + ' lần sẽ khóa không cho mở trong 8 giờ.';
        inp.focus();
      }
    }
  };
  okBtn.onclick = check;
  inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') check(); });
}

/* ---------- Views ---------- */
if (typeof window !== 'undefined' && window.dc) document.body.classList.add('dc-app');
const VIEWS = ['files', 'recent', 'trash', 'transfers', 'sync', 'favorites', 'settings'];
let currentView = 'files';
function switchView(v) {
  if (!VIEWS.includes(v)) return;
  currentView = v;
  $$('.nav-item').forEach((x) => x.classList.toggle('active', x.dataset.nav === v));
  for (const vv of VIEWS) { const el = $('#v-' + vv); if (el) el.classList.toggle('hidden', vv !== v); }
  $('#page-title').textContent = { files: 'Tệp', recent: 'Gần đây', trash: 'Thùng rác', transfers: 'Đang chuyển', sync: 'Đồng bộ', favorites: 'Yêu thích', settings: 'Cài đặt' }[v];
  if (v === 'recent') loadRecent();
  if (v === 'trash') loadTrash();
  if (v === 'sync') loadSync();
  if (v === 'favorites') loadFavorites();
  if (v === 'settings') { loadAppSettings(); if (typeof refreshSyncSettings === 'function') refreshSyncSettings(); if (typeof loadGpuSettings === 'function') loadGpuSettings(); }
}
$$('.nav-item').forEach((item) => {
  item.addEventListener('click', () => switchView(item.dataset.view || item.dataset.nav));
});

/* ---------- Auth ---------- */
function deviceName() {
  if (isTouch && /iPhone|iPad/.test(navigator.userAgent)) return 'iPhone';
  if (isTouch && /Android/.test(navigator.userAgent)) return 'Android Phone';
  if (isTouch) return 'Phone';
  return 'Web Client';
}
function showLogin() {
  $('#page-login').classList.remove('hidden');
  $('#page-app').classList.add('hidden');
  setTimeout(() => { const p = $('#login-pass'); if (p) p.focus(); }, 50);
}
async function doLogin() {
  const user = ($('#login-user').value || '').trim();
  const pass = $('#login-pass').value;
  if (!pass) return;
  $('#login-error').textContent = '';
  try {
    const body = user
      ? { username: user, password: pass, device: deviceName() }
      : { password: pass, device: deviceName() };
    const data = await apiJson('/api/login', { method: 'POST', body: JSON.stringify(body) });
    localStorage.setItem('cw_token', data.token);
    window.cwRole = data.role;
    window.cwUser = data.user;
    enterApp();
  } catch (e) { $('#login-error').textContent = e.message; }
}
async function loginWithInvite(code) {
  const panel = $('#invite-panel');
  if (panel) panel.classList.remove('hidden');
  try {
    const data = await apiJson('/api/login', { method: 'POST', body: JSON.stringify({ invite: code, device: deviceName() }) });
    localStorage.setItem('cw_token', data.token);
    history.replaceState({}, '', location.pathname);
    enterApp();
  } catch (e) {
    if (panel) panel.classList.add('hidden');
    $('#login-error').textContent = 'Lời mời đã hết hạn hoặc không hợp lệ — hãy xin host một cái mới.';
    showLogin();
  }
}

async function enterApp() {
  $('#page-login').classList.add('hidden');
  $('#page-app').classList.remove('hidden');
  applyRoleUI();
  refreshHostInfo();
  probeConnection();
  if (!enterApp._probe) enterApp._probe = setInterval(probeConnection, 15000);
  if (window.dc && window.dc.setToken) { try { window.dc.setToken(localStorage.getItem('cw_token'), location.origin); } catch {} }
  await syncLocksFromServer();
  await loadPools();
  await loadFiles('');
}

/* Role-based UI (viewer = read-only) */
function isViewer() { return window.cwRole === 'viewer'; }
function applyRoleUI() {
  const v = isViewer();
  document.body.classList.toggle('read-only', v);
  const hide = ['#btn-upload', '#btn-newfolder', '#btn-share', '#d-rename', '#d-delete', '#btn-lockdisk'];
  hide.forEach((sel) => { const el = $(sel); if (el) el.classList.toggle('hidden', v); });
  const hint = document.querySelector('.keys-hint');
  if (hint && v) hint.innerHTML = '<svg class="ic svg-14" style="color:var(--muted);vertical-align:-2px"><use href="#i-eye"/></svg> Bạn đang kết nối với quyền <b>chỉ xem</b> — không thể chỉnh sửa';
  const chip = $('#conn-chip');
  const who = window.cwUser && window.cwUser !== 'admin' ? window.cwUser + ' • ' + (window.cwRole || '') : 'admin';
  let badge = $('#user-chip');
  if (!badge && chip) {
    badge = document.createElement('span');
    badge.id = 'user-chip';
    badge.className = 'conn-chip';
    badge.textContent = who;
    chip.after(badge);
  } else if (badge) badge.textContent = who;
}
async function trySilent() {
  const params = new URLSearchParams(location.search);
  const inv = params.get('invite');
  if (inv && inv !== '1') {
    const t = localStorage.getItem('cw_token');
    if (!t) return loginWithInvite(inv);
  }
  const t = localStorage.getItem('cw_token');
  if (!t) return showLogin();
  try {
    const me = await apiJson('/api/me');
    window.cwRole = me.role;
    window.cwUser = me.user;
    enterApp();
  } catch { localStorage.removeItem('cw_token'); showLogin(); }
}

async function refreshHostInfo() {
  try {
    const d = await apiJson('/api/info');
    $('#sb-host').textContent = d.host;
    $('#hd-host').textContent = d.host;
    if (!poolById(currentPool)) $('#sb-space').textContent = fmtSize(d.storage.free) + ' trống / ' + fmtSize(d.storage.total);
  } catch {}
}

/* ---------- Storage drives (pools) — chọn ổ lưu trữ ở host ---------- */
async function loadPools() {
  try {
    const d = await apiJson('/api/pools');
    pools = d.pools || [];
  } catch { pools = []; }
  const sel = $('#pool-select');
  if (!sel) return;
  if (pools.length <= 1) { sel.classList.add('hidden'); return; }
  sel.classList.remove('hidden');
  if (!poolById(currentPool)) currentPool = (pools.find((p) => p.isDefault) || pools[0]).id;
  sel.innerHTML = pools.map((p) => {
    const label = p.online === false ? (p.name + ' — bị rút') : (p.name + ' — trống ' + fmtSize(p.free));
    return '<option value="' + esc(p.id) + '"' + (p.id === currentPool ? ' selected' : '') + '>' + esc(label) + '</option>';
  }).join('');
  updateSidebarSpace();
}
function updateSidebarSpace() {
  const p = poolById(currentPool);
  const el = $('#sb-space');
  if (p && el) el.textContent = p.online === false ? p.name + ' — đã rút khỏi host' : fmtSize(p.free) + ' trống / ' + fmtSize(p.total);
}
function switchPool(poolId) {
  if (!poolById(poolId) || poolId === currentPool) return;
  if (isPoolLocked(poolId)) {
    const sel = $('#pool-select');
    if (sel) sel.value = currentPool;
    lockWarnToast(poolTarget(poolId));
    unlockDialog(poolTarget(poolId), () => switchPool(poolId));
    return;
  }
  currentPool = poolId;
  const sel = $('#pool-select');
  if (sel) sel.value = currentPool;
  updateSidebarSpace();
  loadFiles('');
}

/* ---------- Connection chip (LAN / Tailscale + latency) ---------- */
let connState = { via: 'lan', ms: null, ok: true };
async function probeConnection() {
  const chip = $('#conn-chip');
  const dot = $('#conn-dot');
  if (!chip) return;
  const t0 = performance.now();
  try {
    const res = await api('/api/ping');
    const d = await res.json();
    const ms = Math.round(performance.now() - t0);
    connState = { via: d.via || 'lan', ms, ok: true };
    chip.className = 'conn-chip ' + (d.via === 'tailscale' ? 'tailscale' : 'lan');
    chip.textContent = (d.via === 'tailscale' ? 'Tailscale' : 'LAN') + ' • ' + ms + ' ms';
    chip.title = d.via === 'tailscale' ? 'Kết nối qua Tailscale' : 'Kết nối mạng LAN';
    const sb = $('#sb-conn'); if (sb) sb.textContent = d.via === 'tailscale' ? 'Tailscale' : 'LAN';
    if (dot) dot.style.background = 'var(--green)';
    setOffline(false);
  } catch {
    connState = { ...connState, ok: false };
    chip.className = 'conn-chip dead';
    chip.textContent = 'Mất kết nối';
    if (dot) dot.style.background = '#f97316';
  }
}
let offline = false;
function setOffline(v) {
  if (v === offline) return;
  offline = v;
  $('#offline-banner').classList.toggle('hidden', !v);
  if (v) scheduleReconnect();
}
let reconnectTimer = null;
function scheduleReconnect() {
  if (reconnectTimer) return;
  reconnectTimer = setInterval(async () => {
    try {
      await apiJson('/api/health');
      clearInterval(reconnectTimer);
      reconnectTimer = null;
      setOffline(false);
      await probeConnection();
      loadFiles(currentPath);
      toast('Đã khôi phục kết nối');
    } catch {}
  }, 4000);
}

/* ---------- Lịch sử điều hướng thư mục (nút Back/Forward chuột) ---------- */
const navHist = { back: [], forward: [] };
function navRecordState() {
  navHist.back.push({ path: currentPath, pool: currentPool });
  if (navHist.back.length > 120) navHist.back.shift();
  navHist.forward.length = 0;
}
function navRestore(ent) {
  if (ent.pool && ent.pool !== currentPool && poolById(ent.pool)) {
    currentPool = ent.pool;
    const sel = $('#pool-select');
    if (sel) sel.value = currentPool;
    updateSidebarSpace();
  }
  if (currentView !== 'files') switchView('files');
  loadFiles(ent.path, false);
}
function navGoBack() {
  const ent = navHist.back.pop();
  if (!ent) return;
  navHist.forward.push({ path: currentPath, pool: currentPool });
  navRestore(ent);
}
function navGoForward() {
  const ent = navHist.forward.pop();
  if (!ent) return;
  navHist.back.push({ path: currentPath, pool: currentPool });
  navRestore(ent);
}
if (window.dc && window.dc.onMouseNav) {
  window.dc.onMouseNav((d) => { if (d === 'back') navGoBack(); else if (d === 'forward') navGoForward(); });
}
if (!window.dc) {
  addEventListener('auxclick', (e) => {
    const t = e.target instanceof Element ? e.target : null;
    if (t && t.closest('video, audio, iframe')) return;
    if (e.button === 3 || e.button === 4) e.preventDefault();
  }, { capture: true });
  document.addEventListener('auxclick', (e) => {
    const t = e.target instanceof Element ? e.target : null;
    if (t && t.closest('video, audio, iframe')) return;
    if (e.button !== 3 && e.button !== 4) return;
    e.preventDefault();
    if (e.button === 3) navGoBack(); else navGoForward();
  });
}
document.addEventListener('keydown', (e) => {
  if (!e.altKey || e.defaultPrevented) return;
  if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
  const tg = e.target instanceof Element ? e.target : null;
  if (tg && (tg.tagName === 'INPUT' || tg.tagName === 'TEXTAREA' || tg.closest('.editor-area'))) return;
  if (document.querySelector('.overlay')) return;
  e.preventDefault();
  if (e.key === 'ArrowLeft') navGoBack(); else navGoForward();
});

/* ---------- Files ---------- */
let skeletonTimer = null;
function showSkeleton() {
  const body = $('#fileBody');
  if (body.children.length && !body.querySelector('.skeleton-row')) {
    skeletonTimer = setTimeout(() => {
      if (!body.querySelector('.skeleton-row') && !body.children.length) return;
      body.innerHTML = '';
      for (let i = 0; i < 6; i++) {
        const tr = document.createElement('tr');
        tr.className = 'skeleton-row';
        const w1 = 120 + Math.floor(Math.random() * 160);
        tr.innerHTML = '<td>□</td><td><div class="skeleton-block" style="width:' + w1 + 'px"></div></td><td><div class="skeleton-block" style="width:56px"></div></td><td><div class="skeleton-block" style="width:130px"></div></td><td><div class="skeleton-block" style="width:60px"></div></td><td></td>';
        body.appendChild(tr);
      }
      $('#emptyState').classList.add('hidden');
    }, 260);
  }
}
function hideSkeleton() { if (skeletonTimer) { clearTimeout(skeletonTimer); skeletonTimer = null; } }

async function loadFiles(p, recordNav = true) {
  const next = p || '';
  if (recordNav && next !== currentPath) navRecordState();
  currentPath = next;
  await syncLocksFromServer();
  if (isPoolLocked(effectivePool())) {
    files = [];
    selected = null;
    selectedSet.clear();
    anchorIndex = null;
    renderFiles();
    renderDetail(null);
    lockWarnToast(poolTarget(effectivePool()));
    unlockDialog(poolTarget(effectivePool()), () => { updateLockDiskBtn && updateLockDiskBtn(); loadFiles(currentPath); });
    return;
  }
  showSkeleton();
  try {
    const data = await apiJson('/api/files?path=' + encodeURIComponent(currentPath) + poolQs());
    hideSkeleton();
    if (data.pool) currentPool = data.pool;
    files = data.entries.map((f) => { f.dirRel = currentPath; f.pool = currentPool; return f; });
    selected = null;
    selectedSet.clear();
    anchorIndex = null;
    renderFiles();
    renderDetail(null);
    renderFooter();
    setOffline(false);
    if (typeof updateLockDiskBtn === 'function') updateLockDiskBtn();
  } catch (e) {
    hideSkeleton();
    if (!$('#page-app').classList.contains('hidden')) {
      if (e.status) {
        toast(e.message, 'err');
      } else {
        setOffline(true);
        toast(e.message, 'err');
      }
    }
  }
}

function renderBreadcrumb() {
  const bc = $('#breadcrumb');
  bc.innerHTML = '';
  const mk = (label, p, isCur, isBold) => {
    const el = document.createElement('span');
    el.textContent = label;
    if (isCur) el.style.color = '#111827';
    if (isBold) el.innerHTML = '<b style="color:#111827"></b>', el.firstChild.textContent = label, el.style.cursor = 'default';
    else { el.style.cursor = 'pointer'; el.addEventListener('click', () => loadFiles(p)); }
    return el;
  };
  const sep = () => { const s = document.createElement('span'); s.textContent = '›'; return s; };
  const back = document.createElement('span');
  back.textContent = '←';
  back.style.cursor = 'pointer';
  const parts = currentPath ? currentPath.split('/') : [];
  back.addEventListener('click', () => {
    if (parts.length > 1) loadFiles(parts.slice(0, -1).join('/'));
    else loadFiles('');
  });
  bc.appendChild(back);
  const poolObj = poolById(currentPool);
  const rootLabel = (pools.length > 1 && poolObj && !poolObj.isDefault) ? poolObj.name : 'CW Datacenter';
  bc.appendChild(mk(rootLabel, '', parts.length === 0));
  let acc = '';
  parts.forEach((name, i) => {
    acc = acc ? acc + '/' + name : name;
    bc.appendChild(sep());
    bc.appendChild(mk(name, acc, true, i === parts.length - 1));
  });
}

function filePath(f) {
  if (f.rel) return f.rel;
  const base = (f.dirRel != null ? f.dirRel : currentPath) || '';
  return base ? base + '/' + f.name : f.name;
}

function visibleFiles() {
  const q = ($('#search') ? $('#search').value : '').trim().toLowerCase();
  return q ? files.filter((f) => f.name.toLowerCase().includes(q)) : files;
}

function syncSelection() {
  const list = visibleFiles();
  selected = selectedSet.size ? (selectedSet.get([...selectedSet.keys()][0]) || null) : null;
  $$('#fileBody tr').forEach((r) => {
    const has = selectedSet.has(r.dataset.name);
    r.classList.toggle('selected', has);
    const chk = r.querySelector('.sel-box');
    if (chk) { chk.classList.toggle('checked', has); chk.innerHTML = has ? ICON('check', 'svg-12') : ''; }
  });
  renderFooter();
}

function renderFiles() {
  renderBreadcrumb();
  const body = $('#fileBody');
  body.innerHTML = '';
  const list = visibleFiles();
  $('#emptyState').classList.toggle('hidden', list.length > 0);
  list.forEach((f, idx) => {
    const tr = document.createElement('tr');
    tr.dataset.name = f.name;
    tr.innerHTML = '<td><span class="sel-box" style="cursor:pointer"></span></td>' +
      '<td><div class="file-name">' + iconHtml(f.name, f.type) + '<span class="filename" title="' + esc(f.name) + '"><span class="fn-text">' + esc(fmtName(f.name)) + '</span><span class="fn-extra"></span></span></div></td>' +
      '<td>' + (f.type === 'dir' ? '' : fmtSize(f.size)) + '</td>' +
      '<td>' + fmtDate(f.mtime) + '</td>' +
      '<td><span class="status-synced">' + ICON('checkcircle', 'svg-16') + ' Synced</span></td>' +
      '<td class="row-act-cell"><span class="row-act" title="Thao tác">•••</span></td>';
    tr.addEventListener('click', (e) => {
      const isCheckbox = e.target.closest('.sel-box');
      if (e.shiftKey && anchorIndex != null) {
        const lo = Math.min(anchorIndex, idx);
        const hi = Math.max(anchorIndex, idx);
        selectedSet.clear();
        for (let i = lo; i <= hi; i++) selectedSet.set(list[i].name, list[i]);
        anchorIndex = idx;
      } else if (isCheckbox || e.ctrlKey || e.metaKey) {
        if (selectedSet.has(f.name)) selectedSet.delete(f.name);
        else selectedSet.set(f.name, f);
        anchorIndex = idx;
      } else {
        selectedSet.clear();
        selectedSet.set(f.name, f);
        anchorIndex = idx;
      }
      syncSelection();
      const last = selectedSet.get(f.name) || f;
      renderDetail(selectedSet.size === 1 ? last : null);
      if (isTouch) openEntry(f);
    });
    tr.addEventListener('dblclick', () => openEntry(f));
    tr.addEventListener('contextmenu', async (e) => {
      e.preventDefault();
      if (!selectedSet.has(f.name)) {
        selectedSet.clear();
        selectedSet.set(f.name, f);
        anchorIndex = idx;
        syncSelection();
        renderDetail(selectedSet.size === 1 ? f : null);
      }
      const locked = !!resolveLockTarget(f);
      openCtx(e.clientX, e.clientY, ctxItemsFor(f, locked));
    });
    const rowAct = tr.querySelector('.row-act');
    rowAct.addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!selectedSet.has(f.name)) {
        selectedSet.clear();
        selectedSet.set(f.name, f);
        anchorIndex = idx;
        syncSelection();
        renderDetail(selectedSet.size === 1 ? f : null);
      }
      const locked = !!resolveLockTarget(f);
      const r = rowAct.getBoundingClientRect();
      openCtx(r.left, r.bottom + 4, ctxItemsFor(f, locked));
    });
    (async () => {
      const nameSpan = tr.querySelector('.file-name .filename');
      const extra = nameSpan && nameSpan.querySelector('.fn-extra');
      const into = extra || nameSpan;
      if (await guardLocked(f)) {
        if (into && !into.querySelector('.lock-ico')) into.insertAdjacentHTML('beforeend', '<span class="lock-ico" title="Đã khóa bằng mật khẩu" style="color:#667085">' + ICON('lock', 'svg-14') + '</span>');
      }
      if (isFav(f) && into && !into.querySelector('.fav-star')) into.insertAdjacentHTML('beforeend', '<span class="fav-star" title="Yêu thích"><svg class="ic svg-12"><use href="#i-star-filled"/></svg></span>');
    })();
    body.appendChild(tr);
  });
  syncSelection();
  applyCutMarks();
}

function renderFooter() {
  const list = files;
  const totalSize = list.reduce((s, f) => s + (f.type === 'file' ? f.size : 0), 0);
  const n = selectedSet.size;
  $('#footer-sel').textContent = (n ? ('Đã chọn ' + n + ' mục') : '0 mục') + ' — ' + list.length + ' mục';
  fetch('/api/info').then((r) => r.json()).then((d) => {
    $('#footer-info').textContent = fmtSize(totalSize) + '     ' + fmtSize(d.storage.free) + ' trống';
  }).catch(() => { $('#footer-info').textContent = fmtSize(totalSize); });
}

function renderDetail(f) {
  const favBtn = $('#d-fav');
  const setFavIcon = (on) => {
    if (!favBtn) return;
    favBtn.innerHTML = ICON(on ? 'star-filled' : 'star', 'svg-20');
    favBtn.classList.toggle('on', on);
  };
  if (!f) {
    $('#detailName').textContent = 'Chọn một tệp';
    $('#d-sub').textContent = '—';
    $('#d-ico').className = 'file-ico folder';
    $('#d-ico').innerHTML = '<svg class="ic svg-22"><use href="#i-folder"/></svg>';
    $('#d-loc').textContent = '/';
    $('#d-size').textContent = '—';
    $('#d-mod').textContent = '—';
    if (favBtn) { favBtn.style.visibility = 'hidden'; favBtn.onclick = null; }
    return;
  }
  if (favBtn) {
    favBtn.style.visibility = '';
    const on = isFav(f);
    setFavIcon(on);
    favBtn.title = on ? 'Bỏ yêu thích' : 'Thêm vào Yêu thích';
    favBtn.onclick = () => toggleFav(f);
  }
  $('#detailName').textContent = f.name;
  const sym = f.type === 'dir' ? 'folder' : fileKind(f.name)[1];
  const [cls] = f.type === 'dir' ? ['folder'] : fileKind(f.name);
  $('#d-ico').className = 'file-ico ' + cls;
  $('#d-ico').innerHTML = '<svg class="ic svg-22"><use href="#i-' + sym + '"/></svg>';
  const kindName = f.type === 'dir' ? 'Thư mục' : (f.name.split('.').pop().toUpperCase() + ' File');
  $('#d-sub').textContent = kindName + (f.type === 'file' ? ' – ' + fmtSize(f.size) : '');
  const poolObj = poolById(currentPool);
  $('#d-loc').textContent = (poolObj ? poolObj.name : 'CW Datacenter') + (currentPath ? ' > ' + currentPath.split('/').join(' > ') : '');
  $('#d-size').textContent = f.type === 'dir' ? '—' : fmtSize(f.size);
  $('#d-mod').textContent = fmtDate(f.mtime);
  const pv = $('#pv');
  pv.innerHTML = '';
  pv.className = 'preview';
  pv.onclick = null;
  const src = () => '/api/file?path=' + encodeURIComponent(filePath(f)) + '&preview=1' + poolQs();
  if (f.type === 'file' && PREVIEW_IMG.test(f.name)) {
    pv.classList.add('filled', 'playable');
    const img = document.createElement('img');
    img.src = src();
    img.alt = f.name;
    img.loading = 'lazy';
    pv.appendChild(img);
    pv.onclick = () => openMediaPreview(f);
  } else if (f.type === 'file' && STREAM_VIDEO.test(f.name)) {
    pv.classList.add('filled', 'playable');
    const vid = document.createElement('video');
    vid.src = src();
    vid.muted = true;
    vid.preload = 'metadata';
    vid.playsInline = true;
    vid.autoplay = false;
    vid.addEventListener('error', () => {
      pv.innerHTML = '<div class="play"><svg class="ic svg-28" style="width:28px;height:28px"><use href="#i-play"/></svg></div>';
    });
    vid.addEventListener('loadeddata', () => {
      try { vid.currentTime = Math.min(1, (vid.duration || 2) / 10); } catch {}
    });
    pv.appendChild(vid);
    pv.insertAdjacentHTML('beforeend', '<div class="play"><svg style="width:28px;height:28px;margin-left:3px"><use href="#i-play"/></svg></div>');
    pv.onclick = () => openMediaPreview(f);
  } else if (f.type === 'file' && STREAM_PDF.test(f.name)) {
    pv.classList.add('filled', 'playable');
    pv.innerHTML = '<span class="preview-ico" style="color:#ef4444"><svg style="width:46px;height:46px"><use href="#i-pdf"/></svg></span><span class="preview-name">' + esc(f.name) + '</span>';
    pv.onclick = () => openMediaPreview(f);
  } else if (f.type === 'file' && MEDIA_EXT.test(f.name)) {
    pv.classList.add('filled', 'playable');
    pv.innerHTML = '<div class="play"><svg style="width:28px;height:28px;margin-left:3px"><use href="#i-play"/></svg></div>';
    pv.onclick = () => openMediaPreview(f);
  } else {
    pv.classList.remove('filled');
    pv.innerHTML = '<span class="preview-ico">' + iconHtml(f.name, f.type) + '</span><span class="preview-name">' + esc(f.name) + '</span>';
  }
}

/* ---------- Favorites (yêu thích) ---------- */
function favKeyOf(f) {
  return location.origin + '|' + (f.pool || (pools.length > 0 ? currentPool : 'main')) + '|' + ((f.dirRel != null ? f.dirRel : currentPath) || '') + '|' + f.name;
}
function ensureFavLoaded() {
  if (window._favCache === undefined) window._favCache = null;
  if (!window._favCache) {
    try { window._favCache = JSON.parse(localStorage.getItem('cw_favs') || '{}'); } catch { window._favCache = {}; }
  }
  return window._favCache;
}
function saveFavMap(m) {
  try { localStorage.setItem('cw_favs', JSON.stringify(m)); window._favCache = m; } catch { window._favCache = m; }
}
function isFav(f) { return !!ensureFavLoaded()[favKeyOf(f)]; }
function toggleFav(f) {
  const m = ensureFavLoaded();
  const key = favKeyOf(f);
  if (m[key]) { delete m[key]; toast('Đã bỏ yêu thích "' + f.name + '"'); }
  else { m[key] = { name: f.name, type: f.type || 'file', rel: filePath(f), pool: f.pool || currentPool, size: f.size || 0, added: Date.now() }; toast('Đã thêm "' + f.name + '" vào Yêu thích'); }
  saveFavMap(m);
  renderFiles();
  if (selected === f && $('#d-fav')) {
    $('#d-fav').innerHTML = ICON(m[key] ? 'star-filled' : 'star', 'svg-20');
    $('#d-fav').classList.toggle('on', !!m[key]);
  }
}
function favToFile(it) {
  const rel = it.rel || it.name;
  const dirRel = rel.includes('/') ? rel.replace(/[^/]+$/, '').replace(/\/$/, '') : '';
  return { name: it.name, type: it.type || 'file', size: it.size || 0, rel, dirRel, pool: it.pool || currentPool };
}
function loadFavorites() {
  const m = ensureFavLoaded();
  const items = Object.keys(m).map((k) => { const v = m[k]; v._key = k; return v; }).sort((a, b) => (b.added || 0) - (a.added || 0));
  const body = $('#fav-body');
  if (!body) return;
  $('#fav-empty').classList.toggle('hidden', items.length > 0);
  body.innerHTML = '';
  items.forEach((it) => {
    const tr = document.createElement('tr');
    tr.dataset.favkey = it._key;
    tr.innerHTML = '<td><div class="file-name">' + iconHtml(it.name, it.type) + '<span class="filename" title="' + esc(it.name) + '"><span class="fn-text"></span><span class="fn-extra"></span></span></div>' +
      '<div class="tr-sub" style="font-size:11.5px"></div></td>' +
      '<td class="muted"></td><td class="muted"></td><td class="muted" style="white-space:nowrap"></td>' +
      '<td style="text-align:right"><span class="row-act" title="Thao tác">•••</span></td>';
    body.appendChild(tr);
    tr.querySelector('.filename .fn-text').textContent = fmtName(it.name);
    tr.querySelector('.tr-sub').textContent = 'vị trí: /' + (it.rel ? it.rel.split('/').slice(0, -1).join('/') : '');
    const tds = tr.querySelectorAll('td');
    const poolObj = poolById(it.pool);
    tds[1].textContent = poolObj ? poolObj.name : (it.pool || '—');
    tds[2].textContent = it.type === 'dir' ? 'Thư mục' : fmtSize(it.size);
    tds[3].textContent = it.added ? timeAgo(new Date(it.added).toISOString()) : '—';
    const f = favToFile(it);
    tr.addEventListener('click', (e) => {
      const t = e.target instanceof Element ? e.target : null;
      if (t && (t.closest('.row-act') || t.closest('[data-act]'))) return;
      const list = Array.from(body.querySelectorAll('tr'));
      list.forEach((r) => r.classList.remove('selected'));
      tr.classList.add('selected');
    });
    tr.addEventListener('dblclick', () => openEntry(f));
    const openMenu = async (x, y) => {
      const locked = !!resolveLockTarget(f);
      const mi = [];
      const openInFiles = () => { switchView('files'); if (f.pool && f.pool !== currentPool && poolById(f.pool)) { currentPool = f.pool; const sel = $('#pool-select'); if (sel) sel.value = currentPool; updateSidebarSpace(); } openEntry(f); };
      if (f.type === 'dir') {
        mi.push({ icon: ICON('open', 'svg-16'), label: 'Mở thư mục', fn: openInFiles });
      } else {
        if (isPreviewableMedia(f.name)) mi.push({ icon: ICON('play', 'svg-16'), label: 'Xem trực tiếp', fn: () => openMediaPreview(f, f.rel, f.pool) });
        mi.push({ icon: ICON('download', 'svg-16'), label: 'Tải về', fn: () => downloadFile(f, f.rel, f.pool) });
        if (TEXT_EXT.test(f.name) && f.size < 5 * 1024 * 1024) mi.push({ icon: ICON('text', 'svg-16'), label: 'Sửa văn bản', fn: () => editFile(f) });
        mi.push({ icon: ICON('open', 'svg-16'), label: 'Mở tại tab Tệp', fn: openInFiles });
      }
      mi.push({ icon: ICON(isFav(f) ? 'star-filled' : 'star', 'svg-16'), label: 'Bỏ yêu thích', fn: () => toggleFav(f) });
      if (!locked && (isViewer() === false)) mi.push({ icon: ICON('share', 'svg-16'), label: 'Chia sẻ liên kết', fn: () => shareLink(f) });
      if (!isViewer()) {
        mi.push('-');
        mi.push({ icon: ICON('edit', 'svg-16'), label: 'Đổi tên', fn: () => promptRenameFav(f, it) });
        mi.push({ icon: ICON('trash', 'svg-16'), label: 'Xóa', fn: () => confirmDeleteFav(f, it), danger: true });
      }
      mi.push('-');
      mi.push({ icon: ICON('star', 'svg-16'), label: 'Bỏ khỏi Yêu thích', fn: () => removeFav(it._key), danger: true });
      openCtx(x, y, mi);
    };
    tr.addEventListener('contextmenu', (e) => { e.preventDefault(); tr.click(); openMenu(e.clientX, e.clientY); });
    tr.querySelector('.row-act').addEventListener('click', (e) => {
      e.stopPropagation();
      const r = e.currentTarget.getBoundingClientRect();
      openMenu(r.left, r.bottom + 4);
    });
    tr.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') openEntry(f);
      if (e.key === 'Delete' && !isViewer()) confirmDeleteFav(f, it);
      if (e.key === 'F2' && !isViewer()) promptRenameFav(f, it);
    });
  });
}
function removeFav(key) {
  const m2 = ensureFavLoaded();
  delete m2[key];
  saveFavMap(m2);
  loadFavorites();
  renderFiles();
}
function promptRenameFav(f, it) {
  promptDialog('Đổi tên "' + f.name + '"', f.name, 'Đổi tên', async (name) => {
    try {
      await apiJson('/api/rename', { method: 'POST', body: JSON.stringify({ path: f.rel, newName: name, pool: f.pool }) });
      const m2 = ensureFavLoaded();
      const dir = it.rel ? it.rel.split('/').slice(0, -1).join('/') : '';
      it.name = name;
      it.rel = dir ? dir + '/' + name : name;
      saveFavMap(m2);
      toast('Đã đổi tên thành ' + name);
      loadFavorites();
    } catch (e) { toast(e.message, 'err'); }
  });
}
function confirmDeleteFav(f, it) {
  confirmDialog('Xóa "' + f.name + '"?', 'Sẽ chuyển vào Thùng rác và giữ 30 ngày. Có thể hoàn tác ngay sau khi xóa.', 'Xóa', async () => {
    try {
      await apiJson('/api/file?path=' + encodeURIComponent(f.rel) + (f.pool ? '&pool=' + encodeURIComponent(f.pool) : ''), { method: 'DELETE' });
      toast('Đã chuyển "' + f.name + '" vào Thùng rác', 'warn', {
        label: 'Mở tab Tệp',
        fn: () => switchView('files'),
      });
      loadFavorites();
    } catch (e) { toast(e.message, 'err'); }
  });
}

function ctxItemsFor(f, locked) {
  const sel = (selectedSet.size > 1 && selectedSet.has(f.name)) ? [...selectedSet.values()] : [f];
  const many = sel.length > 1;
  const items = [];
  if (!many && f.type === 'dir') items.push({ icon: ICON('open', 'svg-16'), label: 'Mở', fn: () => openEntry(f) });
  if (!many && isPreviewableMedia(f.name)) items.push({ icon: ICON('play', 'svg-16'), label: 'Xem trực tiếp', fn: () => openMediaPreview(f) });
  items.push({ icon: ICON('download', 'svg-16'), label: many ? 'Tải về ' + sel.length + ' mục' : 'Tải về', fn: () => downloadMany(sel) });
  if (!many && f.type === 'file' && TEXT_EXT.test(f.name) && f.size < 5 * 1024 * 1024) items.push({ icon: ICON('text', 'svg-16'), label: isViewer() ? 'Xem văn bản' : 'Sửa văn bản', fn: () => editFile(f) });
  const allFav = sel.every((t) => isFav(t));
  items.push({ icon: ICON(allFav ? 'star-filled' : 'star', 'svg-16'), label: allFav ? 'Bỏ yêu thích' + (many ? ' ' + sel.length + ' mục' : '') : 'Thêm vào Yêu thích' + (many ? ' ' + sel.length + ' mục' : ''), fn: () => toggleFavMany(sel) });
  if (locked && !many) items.push({ icon: ICON('unlock', 'svg-16'), label: 'Mở khóa bằng mật khẩu', fn: () => unlockDialog(f, () => renderFiles()) });
  else if (!isViewer()) items.push({ icon: ICON('lock', 'svg-16'), label: many ? 'Khóa ' + sel.length + ' mục bằng mật khẩu' : 'Khóa bằng mật khẩu', fn: () => lockDialogTargets(sel) });
  if (!isViewer()) {
    items.push('-');
    items.push({ icon: ICON('copy', 'svg-16'), label: 'Copy' + (selectedSet.size > 1 ? ' ' + selectedSet.size + ' mục' : '') + '  (Ctrl+C)', fn: () => clipboardCopy() });
    items.push({ icon: ICON('cut', 'svg-16'), label: 'Cut' + (selectedSet.size > 1 ? ' ' + selectedSet.size + ' mục' : '') + '  (Ctrl+X)', fn: () => clipboardCut() });
    if (clipboardSize() > 0) items.push({ icon: ICON('paste', 'svg-16'), label: 'Dán vào đây (' + clipboardLabel() + ')' + '  (Ctrl+V)', fn: () => clipboardPaste() });
    items.push('-');
    items.push({ icon: ICON('share', 'svg-16'), label: many ? 'Chia sẻ liên kết ' + sel.length + ' mục' : 'Chia sẻ liên kết', fn: () => shareLinkTargets(sel) });
    if (!many) items.push({ icon: ICON('edit', 'svg-16'), label: 'Đổi tên', fn: () => promptRename(f) });
    if (selectedSet.size > 1) {
      items.push({ icon: ICON('trash', 'svg-16'), label: 'Xóa ' + selectedSet.size + ' mục đã chọn', fn: () => confirmDeleteMany(), danger: true });
    } else {
      items.push({ icon: ICON('trash', 'svg-16'), label: 'Xóa', fn: () => confirmDelete(f), danger: true });
    }
  }
  return items;
}

function downloadEntry(f) {
  if (!f) return;
  if (f.type === 'dir') {
    if (window.dc && window.dc.downloadFolder) {
      toast('Đang chuẩn bị tải thư mục "' + f.name + '"…');
      window.dc.downloadFolder({
        relPath: currentPath ? (currentPath + '/' + f.name) : f.name,
        poolId: f.pool || currentPool,
        folderName: f.name,
      }).then((r) => {
        if (r && r.canceled) return;
        if (r && r.ok) toast('✅ Đã tải thư mục "' + f.name + '" về máy tính!');
        else if (r && r.error) toast(r.error, 'err');
      }).catch((e) => toast(e.message || String(e), 'err'));
      return;
    }
    const p = currentPath ? (currentPath + '/' + f.name) : f.name;
    const a = document.createElement('a');
    a.href = '/api/file?path=' + encodeURIComponent(p) + '&pool=' + encodeURIComponent(f.pool || currentPool);
    a.download = f.name + '.zip';
    document.body.appendChild(a);
    a.click();
    a.remove();
    return;
  }
  downloadFile(f);
}

function downloadMany(list) {
  if (!list || !list.length) return toast('Hãy chọn (các) tệp hoặc thư mục trước', 'warn');
  for (const f of list) downloadEntry(f);
}

function toggleFavMany(list) {
  if (list.length <= 1) return toggleFav(list[0]);
  const m = ensureFavLoaded();
  const allFav = list.every((f) => !!m[favKeyOf(f)]);
  let n = 0;
  for (const f of list) {
    const key = favKeyOf(f);
    if (allFav) { if (m[key]) { delete m[key]; n++; } }
    else if (!m[key]) { m[key] = { name: f.name, type: f.type || 'file', rel: filePath(f), pool: f.pool || currentPool, size: f.size || 0, added: Date.now() }; n++; }
  }
  saveFavMap(m);
  toast((allFav ? 'Đã bỏ yêu thích ' : 'Đã thêm vào Yêu thích ') + n + ' mục');
  renderFiles();
}

/* ---------- Clipboard (Copy / Cut / Paste kiểu Windows) ---------- */
let clipboard = { items: [], mode: '', dir: '', pool: '' };
function saveClipboard() {
  try { sessionStorage.setItem('cw_clipboard', JSON.stringify(clipboard)); } catch {}
  applyCutMarks();
}
function applyCutMarks() {
  const isCut = clipboard.mode === 'cut' && clipboard.items.length > 0;
  $$('#fileBody tr').forEach((r) => {
    const cut = isCut && clipboard.pool === currentPool && clipboard.dir === currentPath && clipboard.items.some((it) => it.name === r.dataset.name);
    r.classList.toggle('cut', cut);
  });
}
try {
  const _cb = JSON.parse(sessionStorage.getItem('cw_clipboard') || 'null');
  if (_cb && Array.isArray(_cb.items) && _cb.items.length) clipboard = _cb;
} catch {}
function clipboardSize() { return clipboard.items.length; }
function clipboardLabel() {
  if (!clipboard.items.length) return '';
  const n = clipboard.items.length;
  return (clipboard.mode === 'copy' ? 'Copy ' : 'Cut ') + n + (n > 1 ? ' mục từ ' : ' mục "' + clipboard.items[0].name + '" từ ') + (clipboard.dir ? '/' + clipboard.dir : 'gốc');
}
function clipboardTargets(mode) {
  const list = selectedSet.size ? [...selectedSet.values()] : (selected ? [selected] : []);
  return list.filter((f) => f && f.name).map((f) => ({
    path: filePath(f),
    pool: f.pool || currentPool,
    name: f.name,
    dir: f.dirRel != null ? f.dirRel : currentPath,
    mode,
  }));
}
function clipboardCopy() {
  if (currentView !== 'files') return;
  if (isViewer()) return toast('Chế độ chỉ xem — không thể copy.', 'warn');
  const items = clipboardTargets('copy');
  if (!items.length) return toast('Hãy chọn tệp hoặc thư mục cần copy', 'warn');
  clipboard = { items, mode: 'copy', dir: currentPath, pool: currentPool };
  saveClipboard();
  toast(clipboardLabel());
}
function clipboardCut() {
  if (currentView !== 'files') return;
  if (isViewer()) return toast('Chế độ chỉ xem — không thể cắt.', 'warn');
  const items = clipboardTargets('cut');
  if (!items.length) return toast('Hãy chọn tệp hoặc thư mục cần cắt', 'warn');
  clipboard = { items, mode: 'cut', dir: currentPath, pool: currentPool };
  saveClipboard();
  toast(clipboardLabel());
}
function clipboardPaste() {
  if (currentView !== 'files') return;
  if (!clipboard.items.length || !clipboard.mode) return toast('Chưa có mục nào được copy/cut — chọn tệp rồi bấm Ctrl+C hoặc Ctrl+X trước.', 'warn');
  const t = resolveLockTarget({ name: '', type: 'dir', rel: '', dirRel: currentPath, pool: currentPool });
  if (t) { lockWarnToast(t); return unlockDialog(t, () => clipboardPaste()); }
  if (isViewer()) return toast('Chế độ chỉ xem — không thể dán.', 'warn');
  const poolObj = poolById(currentPool);
  if (poolObj && poolObj.online === false) return toast('Ổ "' + poolObj.name + '" đang bị rút — không thể dán vào đây.', 'warn');
  const copy = clipboard.mode === 'copy';
  if (!copy && clipboard.pool === currentPool && clipboard.dir === currentPath) return toast('Nguồn và đích giống nhau — không có gì để dán.', 'warn');
  const items = clipboard.items.map((it) => ({ path: it.path, pool: it.pool }));
  apiJson('/api/move', { method: 'POST', body: JSON.stringify({ items, toPool: currentPool, toPath: currentPath, copy }) })
    .then((r) => {
      if (!copy) { clipboard = { items: [], mode: '', dir: '', pool: '' }; saveClipboard(); }
      if (r.jobId) {
        pasteProgressWatch(r.jobId, copy, items.length, currentPool, currentPath);
      } else {
        const n = (r.done || []).length;
        toast((copy ? 'Đã dán (copy) ' : 'Đã dán (cut) ') + n + ' mục vào ' + (currentPath ? '/' + currentPath : 'thư mục gốc'));
        loadFiles(currentPath, false);
      }
    })
    .catch((e) => toast(e.message, 'err'));
}

function pasteProgressWatch(jobId, copy, itemCount, destPool, destPath) {
  const modeLabel = copy ? 'Copy' : 'Di chuyển';
  const poolObj = poolById(destPool);
  const tr = {
    id: 'paste-' + jobId,
    name: modeLabel + (itemCount > 1 ? ' ' + itemCount + ' mục' : ''),
    dir: copy ? 'copy' : 'cut',
    destLabel: modeLabel + ' → ' + ((poolObj && pools.length > 1) ? poolObj.name + ': ' : '') + (destPath ? '/' + destPath : '/ (gốc)'),
    target: '/' + destPath,
    pool: destPool || '',
    status: 'active',
    done: 0,
    total: 0,
    speed: 0,
    error: '',
    _speedMark: { t: Date.now(), b: 0 },
    _jobId: jobId,
    noCancel: true,
  };
  transferBus.list.unshift(tr);
  if (transferBus.onChange) transferBus.onChange();
  const finish = (status, err) => {
    tr.status = status;
    tr.error = err || '';
    if (status === 'done') { tr.done = tr.total || tr.done; tr.speed = 0; }
    if (transferBus.onChange) transferBus.onChange();
    if (status === 'done') {
      toast((copy ? 'Đã dán (copy) xong ' : 'Đã dán (cut) xong ') + (itemCount) + ' mục' + (fmtSize(tr.total) !== '—' ? ' (' + fmtSize(tr.total) + ')' : ''));
      loadFiles(currentPath, false);
    } else if (status === 'error') {
      toast('Dán thất bại: ' + (err || 'lỗi máy chủ'), 'err');
    }
  };
  let failCount = 0;
  const poll = async () => {
    try {
      const res = await api('/api/move/progress?id=' + encodeURIComponent(jobId));
      if (!res.ok) {
        failCount++;
        if (failCount > 5) { finish(tr.status === 'done' ? 'done' : 'error', 'mất kết nối với tiến trình'); return; }
        setTimeout(poll, 1200);
        return;
      }
      const j = await res.json();
      failCount = 0;
      if (j.total) tr.total = j.total;
      if (j.done != null) tr.done = Math.min(j.done, tr.total || j.done);
      const now = Date.now(), dt = now - tr._speedMark.t;
      if (dt >= 600) { tr.speed = ((tr.done - tr._speedMark.b) / dt) * 1000; tr._speedMark = { t: now, b: tr.done }; }
      if (tr.status === 'active') tr.status = j.status === 'running' ? 'active' : j.status;
      if (j.status === 'done') return finish('done');
      if (j.status === 'error') return finish('error', j.error || '');
      if (transferBus.onChange) transferBus.onChange();
      setTimeout(poll, 600);
    } catch {
      failCount++;
      if (failCount > 5) return finish('error', 'mất kết nối với máy chủ');
      setTimeout(poll, 1200);
    }
  };
  setTimeout(poll, 400);
}

function openEntry(f) {
  requireUnlocked(f, () => {
    if (f.type === 'dir') loadFiles(filePath(f));
    else if (isPreviewableMedia(f.name)) openMediaPreview(f);
    else if (TEXT_EXT.test(f.name) && f.size < 5 * 1024 * 1024) editFile(f);
    else downloadFile(f);
  });
}

/* ---------- Xem trực tiếp media (ảnh / video / audio / PDF) ---------- */
const STREAM_IMG = /\.(png|jpe?g|gif|webp|bmp|avif)$/i;
const STREAM_VIDEO = /\.(mp4|webm|mkv|mov|m4v|3gp|avi|wmv|flv|mpg|mpeg|ts)$/i;
const STREAM_AUDIO = /\.(mp3|wav|ogg|m4a|flac|aac)$/i;
const STREAM_PDF = /\.pdf$/i;

let pdfLibPromise = null;
function ensurePdfLib() {
  if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
  if (!pdfLibPromise) {
    pdfLibPromise = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = '/pdfjs/pdf.min.js';
      s.onload = () => {
        try { window.pdfjsLib.GlobalWorkerOptions.workerSrc = '/pdfjs/pdf.worker.min.js'; } catch {}
        resolve(window.pdfjsLib);
      };
      s.onerror = () => { pdfLibPromise = null; reject(new Error('Không tải được thư viện PDF.')); };
      document.head.appendChild(s);
    });
  }
  return pdfLibPromise;
}
function makePdfViewer(url, stage) {
  const wrap = document.createElement('div');
  wrap.className = 'pdf-viewer';
  wrap.innerHTML = '<div class="pdf-toolbar"><button class="pdf-zbtn" data-a="out" title="Thu nhỏ" type="button">−</button><span class="pdf-zoom">100%</span><button class="pdf-zbtn" data-a="in" title="Phóng to" type="button">+</button><span class="pdf-pageinfo"></span></div><div class="pdf-pages"><div class="pdf-loading">Đang tải PDF…</div></div>';
  const pagesEl = wrap.querySelector('.pdf-pages');
  const info = wrap.querySelector('.pdf-pageinfo');
  const zoomEl = wrap.querySelector('.pdf-zoom');
  let zoom = 1, pdfDoc = null, rendering = false, cancelToken = { cancelled: false };

  async function renderAll() {
    if (!pdfDoc || rendering) return;
    rendering = true;
    cancelToken.cancelled = true;
    const myToken = cancelToken = { cancelled: false };
    pagesEl.innerHTML = '';
    try {
      for (let p = 1; p <= pdfDoc.numPages; p++) {
        if (myToken.cancelled) return;
        const page = await pdfDoc.getPage(p);
        if (myToken.cancelled) return;
        const vp0 = page.getViewport({ scale: 1 });
        const fit = Math.max(0.3, Math.min(2.8, zoom));
        const scale = Math.min(1.35 * fit, 1.35 * fit * ((pagesEl.clientWidth - 44) / (vp0.width * 1.35 * fit)));
        const vp = page.getViewport({ scale: Math.max(0.2, scale) });
        const div = document.createElement('div');
        div.className = 'pdf-page';
        const canvas = document.createElement('canvas');
        canvas.style.width = Math.round(vp.width) + 'px';
        canvas.style.height = Math.round(vp.height) + 'px';
        const dpr = Math.min(2, window.devicePixelRatio || 1);
        canvas.width = Math.round(vp.width * dpr);
        canvas.height = Math.round(vp.height * dpr);
        div.appendChild(canvas);
        pagesEl.appendChild(div);
        const ctx = canvas.getContext('2d');
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        await page.render({ canvasContext: ctx, viewport: vp }).promise;
        info.textContent = pdfDoc.numPages + ' trang';
      }
    } catch (e) {
      if (myToken.cancelled) return;
      pagesEl.innerHTML = '<div class="pdf-err">Không hiển thị được trang PDF: ' + (e && e.message ? e.message : 'lỗi không xác định') + '</div>';
    } finally {
      if (!myToken.cancelled) rendering = false;
    }
  }

  function setZoom(z) {
    zoom = Math.max(0.3, Math.min(3, z));
    zoomEl.textContent = Math.round(zoom * 100) + '%';
    rendering = false;
    renderAll();
  }
  wrap.querySelector('[data-a=out]').addEventListener('click', (e) => { e.stopPropagation(); setZoom(zoom - 0.2); });
  wrap.querySelector('[data-a=in]').addEventListener('click', (e) => { e.stopPropagation(); setZoom(zoom + 0.2); });

  (async () => {
    try {
      const pdfjs = await ensurePdfLib();
      const res = await fetch(url);
      if (!res.ok) throw new Error('Lỗi ' + res.status);
      const buf = await res.arrayBuffer();
      pdfDoc = await pdfjs.getDocument({ data: buf }).promise;
      info.textContent = pdfDoc.numPages + ' trang • Đang vẽ…';
      renderAll();
    } catch (e) {
      pagesEl.innerHTML = '<div class="pdf-err">Không đọc được file PDF này.<br>' + (e && e.message ? e.message : '') + '</div>';
    }
  })();
  return wrap;
}

function isPreviewableMedia(name) {
  return !!(STREAM_IMG.test(name) || STREAM_VIDEO.test(name) || STREAM_AUDIO.test(name) || STREAM_PDF.test(name));
}

/* Danh sách tệp media trong thư mục hiện tại (để next/prev) */
function mediaListFor(f) {
  const base = f.dirRel != null ? f.dirRel : currentPath;
  return files.filter((x) => x.type === 'file' && isPreviewableMedia(x.name) && (x.dirRel != null ? x.dirRel : currentPath) === base);
}

function openMediaPreview(f, relPathOverride, poolOverride) {
  requireUnlocked(f, () => openMediaPreviewNow(f, relPathOverride, poolOverride));
}

function openVideoPlayer(initialFile, allSiblings, relPathOverride, poolOverride) {
  const vidSiblings = (allSiblings && allSiblings.length ? allSiblings : [initialFile]).filter((x) => STREAM_VIDEO.test(x.name));
  if (!vidSiblings.length) vidSiblings.push(initialFile);
  let curIndex = vidSiblings.findIndex((x) => x.name === initialFile.name);
  if (curIndex < 0) curIndex = 0;
  let curFile = vidSiblings[curIndex];
  let curPool = poolOverride || (curFile.pool || currentPool);

  const container = document.createElement('div');
  container.className = 'cw-player';
  container.id = 'cwPlayer';
  container.innerHTML = `
    <div class="cw-surface">
      <video id="cwVideo" playsinline preload="auto"></video>
      <div class="cw-ripple-jump left" id="cwRippleLeft">10s ⏪</div>
      <div class="cw-ripple-jump right" id="cwRippleRight">⏩ 10s</div>
    </div>

    <!-- Topbar -->
    <div class="cw-topbar">
      <button class="cw-btn-icon" id="cwBack" title="Quay lại (Esc)">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none"><path d="M15 18l-6-6 6-6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
      <div class="cw-title" id="cwTitle" title="${esc(curFile.name)}">${esc(curFile.name)}</div>
      <div class="cw-top-actions">
        <button class="cw-btn-icon" id="cwFav" title="Thêm vào yêu thích">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
        </button>
        <button class="cw-btn-icon" id="cwCast" title="Truyền phát Smart TV (DLNA)">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M3 18c1.66 0 3 1.34 3 3M3 14c3.87 0 7 3.13 7 7M3 10c6.08 0 11 4.92 11 11M5 4h13a3 3 0 0 1 3 3v10" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>
        </button>
        <button class="cw-btn-icon" id="cwSub" title="Phụ đề (C)">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="14" rx="2.5" stroke="currentColor" stroke-width="1.9"/><path d="M10 10a2 2 0 1 0 0 4M17 10h-2v4h2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
        </button>
        <button class="cw-btn-icon" id="cwMore" title="Tùy chọn khác (⋮)">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="12" cy="19" r="1.8"/></svg>
        </button>
      </div>
    </div>

    <!-- Center Controls -->
    <div class="cw-center">
      <button class="cw-round-btn" id="cwRew10" title="Lùi 10 giây (← / J)">
        <div class="cw-skip-wrap">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M11 6v12l-8-6 8-6Zm9 0v12l-8-6 8-6Z"/></svg>
          <span>10</span>
        </div>
      </button>
      <button class="cw-round-btn main" id="cwPlay" title="Phát / Tạm dừng (Space / K)">
        <div class="cw-pause-bars" id="cwPauseIcon"><span></span><span></span></div>
        <div class="cw-play-triangle hidden" id="cwPlayIcon"></div>
      </button>
      <button class="cw-round-btn" id="cwFwd10" title="Tiến 10 giây (→ / L)">
        <div class="cw-skip-wrap">
          <span>10</span>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M13 6v12l8-6-8-6ZM4 6v12l8-6-8-6Z"/></svg>
        </div>
      </button>
    </div>

    <!-- Left Unlock Button -->
    <button class="cw-unlock" id="cwUnlock" title="Mở khóa điều khiển">
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none"><rect x="5" y="10" width="14" height="10" rx="2" stroke="currentColor" stroke-width="2"/><path d="M8 10V7a4 4 0 0 1 7.5-2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
    </button>

    <!-- Bottom Timeline & Controls -->
    <div class="cw-bottom">
      <div class="cw-timeline-row">
        <div class="cw-time" id="cwCurTime">00:00</div>
        <div class="cw-track" id="cwTrack">
          <div class="cw-track-bg">
            <div class="cw-track-buf" id="cwTrackBuf"></div>
            <div class="cw-track-fill" id="cwTrackFill"></div>
          </div>
          <div class="cw-thumb" id="cwThumb"></div>
          <div class="cw-time-hover" id="cwTimeHover">00:00</div>
        </div>
        <div class="cw-time" id="cwTotalTime">00:00</div>
        <div style="display:flex;align-items:center;gap:6px">
          <div class="cw-vol-box">
            <button class="cw-btn-icon" id="cwVol" title="Âm lượng (M)">
              <svg id="cwVolOn" width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M4 9h4l5-4v14l-5-4H4V9Z" fill="currentColor"/><path d="M16 9.5c1.5 1.5 1.5 3.5 0 5M18.5 7c3 3 3 7 0 10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
              <svg id="cwVolOff" class="hidden" width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M4 9h4l5-4v14l-5-4H4V9Z" fill="currentColor"/><path d="M17 10l4 4m0-4-4 4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
            </button>
            <div class="cw-vol-pop">
              <input type="range" id="cwVolSlider" min="0" max="1" step="0.02" value="1" title="Chỉnh âm lượng">
            </div>
          </div>
          <button class="cw-btn-icon" id="cwPip" title="Thu nhỏ hình (Picture-in-Picture - P)">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="16" rx="2.5" stroke="currentColor" stroke-width="1.8"/><rect x="11" y="11" width="8" height="6" rx="1.5" fill="currentColor"/></svg>
          </button>
          <button class="cw-btn-icon" id="cwFull" title="Toàn màn hình (F)">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M8 3H4a1 1 0 0 0-1 1v4M16 3h4a1 1 0 0 1 1 1v4M8 21H4a1 1 0 0 1-1-1v-4M16 21h4a1 1 0 0 0 1-1v-4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
          </button>
        </div>
      </div>

      <!-- Action 6-Button Panel (Matching Android MVP) -->
      <div class="cw-action-panel">
        <button class="cw-action-btn" id="cwActLock" title="Khóa màn hình">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><rect x="5" y="10" width="14" height="10" rx="2" stroke="currentColor" stroke-width="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
          <span>Khóa</span>
        </button>
        <button class="cw-action-btn" id="cwActSpeed" title="Tốc độ phát">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M4 16a8 8 0 1 1 16 0" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M12 12l4-4M7 15h.01M17 15h.01M12 6h.01" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>
          <span id="cwSpeedLabel">Tốc độ</span>
        </button>
        <button class="cw-action-btn" id="cwActRepeat" title="Chế độ lặp lại">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M17 2l3 3-3 3M20 5H8a4 4 0 0 0-4 4v1M7 22l-3-3 3-3M4 19h12a4 4 0 0 0 4-4v-1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
          <span id="cwRepeatLabel">Lặp lại</span>
        </button>
        <button class="cw-action-btn" id="cwActPlaylist" title="Danh sách phát">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M9 6h11M9 12h11M9 18h11M4 6h.01M4 12h.01M4 18h.01" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>
          <span>Danh sách</span>
        </button>
        <button class="cw-action-btn" id="cwActRotate" title="Tỉ lệ khung hình">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><rect x="7.2" y="4.2" width="9.6" height="15.6" rx="2.2" stroke="currentColor" stroke-width="1.9"/><path d="M4.5 9.2A8 8 0 0 1 7.8 4.8" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/><path d="M4.2 5.8l.3 3.4 3.3-.4" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/><path d="M19.5 14.8a8 8 0 0 1-3.3 4.4" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/><path d="M19.8 18.2l-.3-3.4-3.3.4" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>
          <span id="cwFitActionLabel">Tỉ lệ</span>
        </button>
        <button class="cw-action-btn" id="cwActSettings" title="Cài đặt">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z" stroke="currentColor" stroke-width="2"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.1V21h-4v-.09A1.7 1.7 0 0 0 8.6 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.1-.4H3v-4h.09A1.7 1.7 0 0 0 4.6 8.6a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-.6 1.7 1.7 0 0 0 .4-1.1V3h4v.09A1.7 1.7 0 0 0 15.4 4.6a1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 19.4 9c.19.36.5.67.86.86.34.18.73.28 1.14.28h.1v4h-.09c-.83 0-1.59.45-2.01 1.18Z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>
          <span>Cài đặt</span>
        </button>
      </div>
    </div>

    <div class="cw-toast" id="cwPlayerToast"></div>

    <!-- Sheet 1: Playlist Sheet -->
    <div class="cw-sheet" id="cwPlaylistSheet">
      <h3>
        <span>Danh sách phát (<span id="cwPlCount">${vidSiblings.length}</span>)</span>
        <button class="modal-close" style="color:#fff;background:none;border:none;cursor:pointer;font-size:18px" onclick="this.closest('.cw-sheet').classList.remove('show')">✕</button>
      </h3>
      <div style="margin-bottom:8px">
        <input type="text" id="cwPlSearch" placeholder="Tìm kiếm video trong thư mục…" style="width:100%;height:34px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.15);border-radius:8px;padding:0 10px;color:#fff;font-size:13px;outline:none">
      </div>
      <div id="cwPlaylistItems" style="max-height:280px;overflow-y:auto;display:flex;flex-direction:column;gap:4px"></div>
    </div>

    <!-- Sheet 2: Settings Sheet -->
    <div class="cw-sheet" id="cwSettingsSheet">
      <h3>
        <span>Cài đặt trình phát</span>
        <button class="modal-close" style="color:#fff;background:none;border:none;cursor:pointer;font-size:18px" onclick="this.closest('.cw-sheet').classList.remove('show')">✕</button>
      </h3>
      <div class="cw-sheet-row" id="cwOptFit"><span>Tỉ lệ khung hình</span><span class="cw-sheet-sub" id="cwFitLabel">Vừa khung (Contain)</span></div>
      <div class="cw-sheet-row" id="cwOptSpeed"><span>Tốc độ phát</span><span class="cw-sheet-sub" id="cwSpeedSub">1.0×</span></div>
      <div class="cw-sheet-row" id="cwOptRepeat"><span>Lặp lại video</span><span class="cw-sheet-sub" id="cwRepeatSub">Tắt</span></div>
      <div class="cw-sheet-row" id="cwOptAutoplay"><span>Tự động phát tiếp</span><span class="cw-sheet-sub" id="cwAutoplaySub">Bật</span></div>
      <div class="cw-sheet-row" id="cwOptResume"><span>Nhớ vị trí phát</span><span class="cw-sheet-sub" id="cwResumeSub">Bật</span></div>
    </div>

    <!-- Sheet 3: Subtitles Sheet -->
    <div class="cw-sheet" id="cwSubSheet">
      <h3>
        <span>Phụ đề</span>
        <button class="modal-close" style="color:#fff;background:none;border:none;cursor:pointer;font-size:18px" onclick="this.closest('.cw-sheet').classList.remove('show')">✕</button>
      </h3>
      <div class="cw-sheet-row" id="cwSubToggle"><span>Trạng thái</span><span class="cw-sheet-sub" id="cwSubToggleSub">Tắt</span></div>
      <div class="cw-sheet-row" id="cwSubPick"><span>Tải tệp phụ đề từ máy (.srt, .vtt)</span><span class="cw-sheet-sub">📂 Chọn</span></div>
      <input type="file" id="cwSubFileInput" accept=".srt,.vtt" hidden>
      <div class="cw-sheet-row" id="cwSubSync"><span>Đồng bộ độ trễ phụ đề</span><span class="cw-sheet-sub" id="cwSubDelaySub">0.0s</span></div>
    </div>

    <!-- Sheet 4: Cast / DLNA Sheet -->
    <div class="cw-sheet" id="cwCastSheet">
      <h3>
        <span>Truyền phát Smart TV (DLNA / Cast)</span>
        <button class="modal-close" style="color:#fff;background:none;border:none;cursor:pointer;font-size:18px" onclick="this.closest('.cw-sheet').classList.remove('show')">✕</button>
      </h3>
      <div class="muted" style="font-size:12.5px;margin-bottom:10px;color:rgba(255,255,255,.7)">Đang quét các thiết bị Smart TV / Android TV / DLNA trong mạng LAN…</div>
      <div id="cwCastDeviceList" style="max-height:220px;overflow-y:auto;display:flex;flex-direction:column;gap:6px">
        <div class="cw-sheet-row" id="cwCastLocal"><span>📱 Máy tính này (Phát tại chỗ)</span><span class="cw-sheet-sub" style="color:#22c55e">● Đang phát</span></div>
        <div class="cw-sheet-row" id="cwCastScan"><span><svg class="ic svg-14" style="animation:sync-spin 1s linear infinite"><use href="#i-sync"/></svg> Đang dò tìm Smart TV…</span></div>
      </div>
    </div>

    <!-- Sheet 5: More Options Sheet -->
    <div class="cw-sheet" id="cwMoreSheet">
      <h3>
        <span>Tùy chọn khác</span>
        <button class="modal-close" style="color:#fff;background:none;border:none;cursor:pointer;font-size:18px" onclick="this.closest('.cw-sheet').classList.remove('show')">✕</button>
      </h3>
      <div class="cw-sheet-row" id="cwMoreDl"><span>⇩ Tải về video này</span><span class="cw-sheet-sub">Lưu máy</span></div>
      <div class="cw-sheet-row" id="cwMoreShare"><span>🔗 Chia sẻ link công khai</span><span class="cw-sheet-sub">Link</span></div>
      <div class="cw-sheet-row" id="cwMoreSnap"><span>📸 Chụp ảnh khung hình hiện tại</span><span class="cw-sheet-sub">Ảnh</span></div>
      <div class="cw-sheet-row" id="cwMoreInfo"><span>ℹ️ Thông tin chi tiết tệp</span><span class="cw-sheet-sub" id="cwInfoSub">Xem</span></div>
    </div>
  `;
  document.body.appendChild(container);

  const video = container.querySelector('#cwVideo');
  const titleEl = container.querySelector('#cwTitle');
  const curTimeEl = container.querySelector('#cwCurTime');
  const totalTimeEl = container.querySelector('#cwTotalTime');
  const trackEl = container.querySelector('#cwTrack');
  const trackBufEl = container.querySelector('#cwTrackBuf');
  const trackFillEl = container.querySelector('#cwTrackFill');
  const thumbEl = container.querySelector('#cwThumb');
  const timeHoverEl = container.querySelector('#cwTimeHover');
  const playBtn = container.querySelector('#cwPlay');
  const pauseIcon = container.querySelector('#cwPauseIcon');
  const playIcon = container.querySelector('#cwPlayIcon');
  const toastEl = container.querySelector('#cwPlayerToast');
  const speedLabel = container.querySelector('#cwSpeedLabel');
  const repeatBtn = container.querySelector('#cwActRepeat');
  const repeatLabel = container.querySelector('#cwRepeatLabel');
  const favBtn = container.querySelector('#cwFav');
  const rippleLeft = container.querySelector('#cwRippleLeft');
  const rippleRight = container.querySelector('#cwRippleRight');

  const speeds = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];
  let speedIdx = 2; // 1.0x
  const fitModes = ['fit-contain', 'fit-cover', 'fit-fill', 'fit-16-9', 'fit-4-3'];
  const fitLabels = ['Vừa khung (Contain)', 'Lấp đầy (Cover)', 'Kéo giãn (Fill)', '16:9', '4:3'];
  let fitIdx = 0;
  let isLocked = false;
  let hideTimer = null;
  let toastTimer = null;
  let repeatMode = 0; // 0 = off, 1 = repeat one, 2 = repeat all
  let autoplayNext = true;
  let resumePlayback = true;
  let subOffset = 0;

  function showToast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2200);
  }

  function triggerRipple(isLeft) {
    const el = isLeft ? rippleLeft : rippleRight;
    if (!el) return;
    el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), 400);
  }

  function fmtTime(sec) {
    if (!sec || isNaN(sec) || !isFinite(sec)) return '00:00';
    sec = Math.round(sec);
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    if (h > 0) {
      return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    }
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  function updateTimeline() {
    if (!video.duration) return;
    const pct = Math.max(0, Math.min(100, (video.currentTime / video.duration) * 100));
    trackFillEl.style.width = pct + '%';
    thumbEl.style.left = pct + '%';
    curTimeEl.textContent = fmtTime(video.currentTime);

    // Buffer range
    if (video.buffered && video.buffered.length) {
      try {
        const bufEnd = video.buffered.end(video.buffered.length - 1);
        const bufPct = Math.max(0, Math.min(100, (bufEnd / video.duration) * 100));
        trackBufEl.style.width = bufPct + '%';
      } catch {}
    }

    // Save resume position periodically
    if (resumePlayback && video.currentTime > 5 && (video.duration - video.currentTime > 10)) {
      try {
        localStorage.setItem('cw_resume_' + curFile.name, String(Math.round(video.currentTime)));
      } catch {}
    }
  }

  function showControls() {
    container.classList.remove('controls-hidden');
    clearTimeout(hideTimer);
    if (!video.paused && !isLocked) {
      hideTimer = setTimeout(() => {
        if (!video.paused && !isLocked) {
          closeAllSheets();
          container.classList.add('controls-hidden');
        }
      }, 2600);
    }
  }

  function closeAllSheets() {
    container.querySelectorAll('.cw-sheet').forEach((s) => s.classList.remove('show'));
  }

  function toggleSheet(id) {
    const s = container.querySelector('#' + id);
    if (!s) return;
    const isShowing = s.classList.contains('show');
    closeAllSheets();
    if (!isShowing) s.classList.add('show');
    showControls();
  }

  function updateFavUI() {
    try {
      const favs = JSON.parse(localStorage.getItem('cw_fav_videos') || '[]');
      const isFav = favs.includes(curFile.name);
      if (favBtn) {
        favBtn.classList.toggle('is-fav', isFav);
        favBtn.title = isFav ? 'Đã yêu thích (Bấm để bỏ)' : 'Thêm vào yêu thích';
      }
    } catch {}
  }

  function setVideoSource(f) {
    curFile = f;
    curPool = f.pool || currentPool;
    const rel = filePath(f);
    titleEl.textContent = f.name;
    titleEl.title = f.name;
    updateFavUI();

    const qs = curPool ? '&pool=' + encodeURIComponent(curPool) : '';
    video.src = '/api/video?path=' + encodeURIComponent(rel) + qs;
    video.onerror = () => {
      video.src = '/api/file?path=' + encodeURIComponent(rel) + '&preview=1' + qs;
      video.load();
      video.play().catch(() => {});
    };
    video.load();

    // Check resume position
    if (resumePlayback) {
      try {
        const savedSec = Number(localStorage.getItem('cw_resume_' + f.name) || 0);
        if (savedSec > 10) {
          video.currentTime = savedSec;
          showToast(`▶ Tiếp tục phát từ ${fmtTime(savedSec)}`);
        }
      } catch {}
    }

    video.play().catch(() => {});
    renderPlaylistItems();
  }

  function renderPlaylistItems(filter = '') {
    const box = container.querySelector('#cwPlaylistItems');
    if (!box) return;
    const q = filter.toLowerCase().trim();
    const items = vidSiblings.filter((v) => !q || v.name.toLowerCase().includes(q));

    box.innerHTML = items.map((v) => {
      const isCur = v.name === curFile.name;
      const idx = vidSiblings.findIndex((x) => x.name === v.name);
      return `<div class="cw-sheet-row${isCur ? ' active' : ''}" data-idx="${idx}">
        <span style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:320px">${esc(v.name)}</span>
        <span class="cw-sheet-sub">${v.size ? fmtSize(v.size) : ''}</span>
      </div>`;
    }).join('');

    box.querySelectorAll('.cw-sheet-row').forEach((r) => {
      r.onclick = () => {
        const idx = Number(r.dataset.idx);
        if (vidSiblings[idx]) {
          setVideoSource(vidSiblings[idx]);
          closeAllSheets();
        }
      };
    });
  }

  const plSearchInp = container.querySelector('#cwPlSearch');
  if (plSearchInp) {
    plSearchInp.addEventListener('input', () => renderPlaylistItems(plSearchInp.value));
  }

  function togglePlay() {
    if (video.paused) {
      video.play();
      showToast('Đang phát');
    } else {
      video.pause();
      showToast('Đã tạm dừng');
    }
  }

  function skip(delta) {
    video.currentTime = Math.max(0, Math.min(video.duration || 0, video.currentTime + delta));
    updateTimeline();
    triggerRipple(delta < 0);
    showToast(delta > 0 ? 'Tiến 10 giây' : 'Lùi 10 giây');
  }

  // Video Events
  video.addEventListener('timeupdate', updateTimeline);
  video.addEventListener('progress', updateTimeline);
  video.addEventListener('loadedmetadata', () => {
    totalTimeEl.textContent = fmtTime(video.duration);
    updateTimeline();
    const infoSub = container.querySelector('#cwInfoSub');
    if (infoSub && video.videoWidth) {
      infoSub.textContent = `${video.videoWidth}×${video.videoHeight} · ${fmtTime(video.duration)}`;
    }
  });
  video.addEventListener('play', () => {
    pauseIcon.classList.remove('hidden');
    playIcon.classList.add('hidden');
    showControls();
  });
  video.addEventListener('pause', () => {
    pauseIcon.classList.add('hidden');
    playIcon.classList.remove('hidden');
    container.classList.remove('controls-hidden');
    clearTimeout(hideTimer);
  });
  video.addEventListener('ended', () => {
    if (repeatMode === 1) {
      video.currentTime = 0;
      video.play().catch(() => {});
    } else if (autoplayNext || repeatMode === 2) {
      curIndex = (curIndex + 1) % vidSiblings.length;
      setVideoSource(vidSiblings[curIndex]);
    }
  });

  playBtn.onclick = togglePlay;
  container.querySelector('#cwRew10').onclick = () => skip(-10);
  container.querySelector('#cwFwd10').onclick = () => skip(10);

  // Favorite toggle
  favBtn.onclick = () => {
    try {
      let favs = JSON.parse(localStorage.getItem('cw_fav_videos') || '[]');
      const isFav = favs.includes(curFile.name);
      if (isFav) {
        favs = favs.filter((x) => x !== curFile.name);
        showToast('🤍 Đã xóa khỏi yêu thích');
      } else {
        favs.push(curFile.name);
        showToast('❤️ Đã thêm vào yêu thích');
      }
      localStorage.setItem('cw_fav_videos', JSON.stringify(favs));
      updateFavUI();
    } catch {}
  };

  // Seeking on track & Hover Tooltip
  let dragging = false;
  function seekToEvent(e) {
    const rect = trackEl.getBoundingClientRect();
    const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    if (video.duration) video.currentTime = pos * video.duration;
    updateTimeline();
  }
  trackEl.addEventListener('mousedown', (e) => {
    dragging = true;
    seekToEvent(e);
  });
  trackEl.addEventListener('mousemove', (e) => {
    const rect = trackEl.getBoundingClientRect();
    const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    if (timeHoverEl && video.duration) {
      timeHoverEl.style.left = (pos * 100) + '%';
      timeHoverEl.textContent = fmtTime(pos * video.duration);
    }
  });
  window.addEventListener('mousemove', (e) => { if (dragging) seekToEvent(e); });
  window.addEventListener('mouseup', () => { dragging = false; });

  // Top buttons
  container.querySelector('#cwBack').onclick = () => closePlayer();
  container.querySelector('#cwCast').onclick = () => toggleSheet('cwCastSheet');
  container.querySelector('#cwSub').onclick = () => toggleSheet('cwSubSheet');
  container.querySelector('#cwMore').onclick = () => toggleSheet('cwMoreSheet');

  // Volume & Fullscreen & PiP
  const volBtn = container.querySelector('#cwVol');
  const volOn = container.querySelector('#cwVolOn');
  const volOff = container.querySelector('#cwVolOff');
  const volSlider = container.querySelector('#cwVolSlider');
  const volBox = container.querySelector('.cw-vol-box');

  function updateVolIcon() {
    const isMute = video.muted || video.volume === 0;
    volOn.classList.toggle('hidden', isMute);
    volOff.classList.toggle('hidden', !isMute);
    if (volSlider) volSlider.value = video.muted ? 0 : video.volume;
  }

  volBtn.onclick = () => {
    video.muted = !video.muted;
    updateVolIcon();
    showToast(video.muted ? 'Đã tắt tiếng' : 'Đã bật tiếng (' + Math.round(video.volume * 100) + '%)');
  };

  if (volSlider) {
    volSlider.addEventListener('input', (e) => {
      e.stopPropagation();
      const val = parseFloat(volSlider.value);
      video.volume = val;
      video.muted = (val === 0);
      updateVolIcon();
      showToast('Âm lượng ' + Math.round(val * 100) + '%');
    });
  }

  if (volBox) {
    volBox.addEventListener('wheel', (e) => {
      e.preventDefault();
      let v = video.volume + (e.deltaY < 0 ? 0.05 : -0.05);
      v = Math.max(0, Math.min(1, v));
      video.volume = v;
      video.muted = (v === 0);
      updateVolIcon();
      showToast('Âm lượng ' + Math.round(v * 100) + '%');
    }, { passive: false });
  }

  const pipBtn = container.querySelector('#cwPip');
  if (pipBtn) {
    pipBtn.onclick = async () => {
      try {
        if (document.pictureInPictureElement) await document.exitPictureInPicture();
        else if (document.pictureInPictureEnabled) await video.requestPictureInPicture();
      } catch (e) { showToast('Không hỗ trợ PiP trên thiết bị này'); }
    };
  }

  const fullBtn = container.querySelector('#cwFull');
  fullBtn.onclick = () => {
    if (!document.fullscreenElement) {
      container.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  // Action Panel buttons
  container.querySelector('#cwActLock').onclick = () => {
    isLocked = true;
    container.classList.add('locked');
    closeAllSheets();
    showToast('🔒 Đã khóa điều khiển (Chạm ổ khóa bên trái để mở)');
  };
  container.querySelector('#cwUnlock').onclick = () => {
    isLocked = false;
    container.classList.remove('locked');
    showControls();
    showToast('🔓 Đã mở khóa');
  };

  const speedBtn = container.querySelector('#cwActSpeed');
  speedBtn.onclick = () => {
    speedIdx = (speedIdx + 1) % speeds.length;
    const v = speeds[speedIdx];
    video.playbackRate = v;
    speedLabel.textContent = v === 1 ? 'Tốc độ' : `${v}×`;
    container.querySelector('#cwSpeedSub').textContent = `${v}×`;
    showToast(`⚡ Tốc độ: ${v}×`);
  };

  repeatBtn.onclick = () => {
    repeatMode = (repeatMode + 1) % 3;
    const labels = ['Tắt', 'Lặp 1 video', 'Lặp toàn bộ'];
    repeatLabel.textContent = repeatMode === 0 ? 'Lặp lại' : repeatMode === 1 ? 'Lặp 1' : 'Lặp tất cả';
    repeatBtn.classList.toggle('active', repeatMode !== 0);
    container.querySelector('#cwRepeatSub').textContent = labels[repeatMode];
    showToast(`🔁 Lặp lại: ${labels[repeatMode]}`);
  };

  container.querySelector('#cwActPlaylist').onclick = () => toggleSheet('cwPlaylistSheet');
  container.querySelector('#cwActSettings').onclick = () => toggleSheet('cwSettingsSheet');

  // Rotate / Aspect Ratio
  const fitBtn = container.querySelector('#cwActRotate');
  fitBtn.onclick = () => {
    fitIdx = (fitIdx + 1) % fitModes.length;
    video.className = fitModes[fitIdx];
    container.querySelector('#cwFitLabel').textContent = fitLabels[fitIdx];
    container.querySelector('#cwFitActionLabel').textContent = fitIdx === 0 ? 'Tỉ lệ' : fitLabels[fitIdx].split(' ')[0];
    showToast(`📐 Tỉ lệ: ${fitLabels[fitIdx]}`);
  };

  // Settings sheet items
  container.querySelector('#cwOptFit').onclick = () => fitBtn.click();
  container.querySelector('#cwOptSpeed').onclick = () => speedBtn.click();
  container.querySelector('#cwOptRepeat').onclick = () => repeatBtn.click();
  container.querySelector('#cwOptAutoplay').onclick = () => {
    autoplayNext = !autoplayNext;
    container.querySelector('#cwAutoplaySub').textContent = autoplayNext ? 'Bật' : 'Tắt';
    showToast(`Tự động phát tiếp: ${autoplayNext ? 'BẬT' : 'TẮT'}`);
  };
  container.querySelector('#cwOptResume').onclick = () => {
    resumePlayback = !resumePlayback;
    container.querySelector('#cwResumeSub').textContent = resumePlayback ? 'Bật' : 'Tắt';
    showToast(`Nhớ vị trí phát: ${resumePlayback ? 'BẬT' : 'TẮT'}`);
  };

  // Subtitle sheet items
  const subToggleRow = container.querySelector('#cwSubToggle');
  const subToggleSub = container.querySelector('#cwSubToggleSub');
  const subFileInput = container.querySelector('#cwSubFileInput');
  let subsActive = false;

  subToggleRow.onclick = () => {
    subsActive = !subsActive;
    subToggleSub.textContent = subsActive ? 'Bật' : 'Tắt';
    for (let i = 0; i < video.textTracks.length; i++) {
      video.textTracks[i].mode = subsActive ? 'showing' : 'hidden';
    }
    showToast(`💬 Phụ đề: ${subsActive ? 'BẬT' : 'TẮT'}`);
  };

  container.querySelector('#cwSubPick').onclick = () => subFileInput.click();
  subFileInput.onchange = (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    const track = document.createElement('track');
    track.kind = 'subtitles';
    track.label = file.name;
    track.srclang = 'vi';
    track.src = url;
    track.default = true;
    video.appendChild(track);
    subsActive = true;
    subToggleSub.textContent = file.name;
    showToast('✅ Đã nạp phụ đề: ' + file.name);
    closeAllSheets();
  };

  // More sheet items
  container.querySelector('#cwMoreDl').onclick = () => {
    downloadFile({ name: curFile.name, type: 'file' }, filePath(curFile), curPool);
    closeAllSheets();
  };
  container.querySelector('#cwMoreShare').onclick = () => {
    closeAllSheets();
    if (typeof openShareDialog === 'function') openShareDialog(curFile);
  };
  container.querySelector('#cwMoreSnap').onclick = () => {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 1280;
      canvas.height = video.videoHeight || 720;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const a = document.createElement('a');
      a.download = `snapshot_${curFile.name}_${Math.round(video.currentTime)}s.jpg`;
      a.href = canvas.toDataURL('image/jpeg', 0.92);
      a.click();
      showToast('📸 Đã lưu ảnh chụp màn hình!');
    } catch { showToast('Không thể chụp màn hình video này'); }
    closeAllSheets();
  };
  container.querySelector('#cwMoreInfo').onclick = () => {
    showToast(`ℹ️ ${curFile.name} (${video.videoWidth || 0}×${video.videoHeight || 0}, ${fmtTime(video.duration)})`);
  };

  // Mouse activity & Double-click gestures
  container.addEventListener('mousemove', showControls);
  let lastClickTime = 0;
  container.addEventListener('click', (e) => {
    if (e.target === container || e.target.closest('.cw-surface')) {
      const now = Date.now();
      const rect = container.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const pctX = clickX / rect.width;

      if (now - lastClickTime < 300) {
        // Double click
        if (pctX < 0.35) {
          skip(-10);
        } else if (pctX > 0.65) {
          skip(10);
        } else {
          fullBtn.click();
        }
      } else {
        // Single click
        if (container.classList.contains('controls-hidden')) {
          showControls();
        } else {
          togglePlay();
        }
      }
      lastClickTime = now;
    }
  });

  function keyHandler(e) {
    if (e.key === 'Escape') {
      if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
      else closePlayer();
    } else if (e.key === ' ' || e.key === 'k' || e.key === 'K') {
      e.preventDefault();
      togglePlay();
    } else if (e.key === 'ArrowLeft' || e.key === 'j' || e.key === 'J') {
      e.preventDefault();
      skip(-10);
    } else if (e.key === 'ArrowRight' || e.key === 'l' || e.key === 'L') {
      e.preventDefault();
      skip(10);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      video.volume = Math.min(1, video.volume + 0.05);
      updateVolIcon();
      showToast(`Âm lượng ${Math.round(video.volume * 100)}%`);
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      video.volume = Math.max(0, video.volume - 0.05);
      updateVolIcon();
      showToast(`Âm lượng ${Math.round(video.volume * 100)}%`);
    } else if (e.key === 'f' || e.key === 'F') {
      e.preventDefault();
      fullBtn.click();
    } else if (e.key === 'm' || e.key === 'M') {
      e.preventDefault();
      volBtn.click();
    } else if (e.key === 'p' || e.key === 'P') {
      e.preventDefault();
      if (pipBtn) pipBtn.click();
    } else if (e.key === 's' || e.key === 'S') {
      e.preventDefault();
      fitBtn.click();
    } else if (e.key === 'r' || e.key === 'R') {
      e.preventDefault();
      repeatBtn.click();
    } else if (e.key === 'c' || e.key === 'C') {
      e.preventDefault();
      subToggleRow.click();
    } else if (e.key === 'n' || e.key === 'N') {
      e.preventDefault();
      if (vidSiblings.length > 1) {
        curIndex = (curIndex + 1) % vidSiblings.length;
        setVideoSource(vidSiblings[curIndex]);
      }
    }
  }
  document.addEventListener('keydown', keyHandler, true);

  function closePlayer() {
    document.removeEventListener('keydown', keyHandler, true);
    clearTimeout(hideTimer);
    clearTimeout(toastTimer);
    video.pause();
    container.remove();
  }

  setVideoSource(initialFile);
  showControls();
}

function openMediaPreviewNow(f, relPathOverride, poolOverride) {
  const relPath = relPathOverride || filePath(f);
  const pool = poolOverride || (f.pool || currentPool);
  const siblings = mediaListFor(f);

  if (STREAM_VIDEO.test(f.name)) {
    openVideoPlayer(f, siblings, relPath, pool);
    return;
  }

  let cur = { name: f.name, rel: relPath, pool };
  const idxOf = (x) => siblings.findIndex((s) => s.name === x.name);

  const back = document.createElement('div');
  back.className = 'pv-back';
  back.innerHTML = ''
    + '<div class="pv-top">'
    +   '<button class="btn pv-btn pv-close" data-a="close" title="Đóng (Esc)">' + ICON('x', 'svg-16') + '<span>Đóng</span></button>'
    +   '<h3></h3>'
    +   '<div class="pv-counter"></div>'
    +   '<button class="btn pv-btn pv-dl" data-a="dl" title="Tải về">' + ICON('download', 'svg-16') + '<span>Tải về</span></button>'
    + '</div>'
    + (siblings.length > 1 ? (''
    + '<button class="pv-arrow pv-prev" data-a="prev" title="Trước (←)">' + ICON('chevron-l', 'svg-28') + '</button>'
    + '<button class="pv-arrow pv-next" data-a="next" title="Sau (→)">' + ICON('chevron-r', 'svg-28') + '</button>') : '')
    + '<div class="pv-stage"></div>';
  document.body.appendChild(back);
  const stage = back.querySelector('.pv-stage');
  const title = back.querySelector('h3');
  const counter = back.querySelector('.pv-counter');

  let keyHandler = null;
  const done = () => {
    if (keyHandler) document.removeEventListener('keydown', keyHandler, true);
    back.remove();
  };

  function renderMedia(x) {
    cur = { name: x.name, rel: filePath(x), pool: x.pool || pool };
    title.textContent = x.name;
    const i = idxOf(x);
    if (counter) counter.textContent = siblings.length > 1 ? (i + 1) + ' / ' + siblings.length : '';
    stage.innerHTML = '';
    const qs = (cur.pool ? '&pool=' + encodeURIComponent(cur.pool) : '');
    const src = '/api/file?path=' + encodeURIComponent(cur.rel) + '&preview=1' + qs;
    let el;
    if (STREAM_IMG.test(x.name)) {
      el = document.createElement('img');
      el.src = src;
      el.onerror = () => { stage.innerHTML = '<div class="pv-err">Không tải được ảnh.</div>'; };
    } else if (STREAM_AUDIO.test(x.name)) {
      el = document.createElement('audio');
      el.src = src;
      el.controls = true;
      el.autoplay = true;
      el.onerror = () => { stage.innerHTML = '<div class="pv-err">Không phát được tệp âm thanh.</div>'; };
    } else if (STREAM_PDF.test(x.name)) {
      el = makePdfViewer('/api/file?path=' + encodeURIComponent(cur.rel) + qs, stage);
    } else {
      stage.innerHTML = '<div class="pv-err">Loại tệp này chưa hỗ trợ xem trực tiếp.</div>';
      return;
    }
    stage.appendChild(el);
  }

  function step(dir) {
    const i = siblings.findIndex((s) => s.name === cur.name);
    const n = (i + dir + siblings.length) % siblings.length;
    renderMedia(siblings[n]);
  }

  back.querySelector('[data-a=close]').onclick = done;
  back.querySelector('[data-a=dl]').onclick = () => { downloadFile({ name: cur.name, type: 'file' }, cur.rel, cur.pool); };
  const prevBtn = back.querySelector('[data-a=prev]');
  const nextBtn = back.querySelector('[data-a=next]');
  if (prevBtn) prevBtn.onclick = () => step(-1);
  if (nextBtn) nextBtn.onclick = () => step(1);

  keyHandler = (e) => {
    if (e.key === 'Escape') { e.stopPropagation(); done(); }
    else if (e.key === 'ArrowLeft' && siblings.length > 1) { e.preventDefault(); e.stopPropagation(); step(-1); }
    else if (e.key === 'ArrowRight' && siblings.length > 1) { e.preventDefault(); e.stopPropagation(); step(1); }
  };
  document.addEventListener('keydown', keyHandler, true);

  renderMedia(f);
  back.tabIndex = -1;
  back.focus();
}

/* ---------- Download (resumable, Range + retry) ---------- */
function downloadFile(f, relPathOverride, poolOverride) {
  requireUnlocked(f, () => downloadFileResumable(f, relPathOverride || filePath(f), poolOverride || currentPool));
}

/* ---------- Upload (chunked, resumable) ---------- */
function uploadFiles(fileList) {
  const arr = Array.from(fileList || []);
  if (!arr.length) return;
  if (isViewer()) return toast('Chế độ chỉ xem — không thể tải lên.', 'warn');
  const poolObj = poolById(currentPool);
  if (poolObj && poolObj.online === false) return toast('Ổ "' + poolObj.name + '" đã bị rút — hãy chọn ổ khác.', 'warn');
  if (isPoolLocked(currentPool)) { lockWarnToast(poolTarget(currentPool)); return unlockDialog(poolTarget(currentPool)); }
  const dir = currentPath;
  (async () => {
    let anyDone = false;
    for (const f of arr) {
      const rel = f._rel ? ((dir ? dir + '/' : '') + f._rel) : undefined;
      const r = await uploadFileResumable(f, dir, currentPool, rel);
      if (r && r.rel != null) anyDone = true;
    }
    if (anyDone) loadFiles(currentPath);
  })();
}

/* ---------- Move / copy between storage drives ----------
   Kiểu Windows: chọn tệp → Ctrl+C (Copy) hoặc Ctrl+X (Cut) →
   duyệt sang ổ/thư mục khác → Ctrl+V (hoặc chuột phải → Dán vào đây).
   Không còn bảng chọn ổ đích nữa — xem clipboardCopy/clipboardCut/clipboardPaste ở trên. */


/* ---------- Edit ---------- */
function poolQsOf(f) { const p = (f && f.pool) || currentPool; return p ? '&pool=' + encodeURIComponent(p) : ''; }
function poolOfF(f) { return (f && f.pool) || currentPool; }
function editFile(f) {
  requireUnlocked(f, () => editFileNow(f));
}
async function editFileNow(f) {
  try {
    const res = await api('/api/file?path=' + encodeURIComponent(filePath(f)) + poolQsOf(f));
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || 'Lỗi');
    const text = await res.text();
    const back = document.createElement('div');
    back.className = 'overlay';
    back.innerHTML = '<div class="dialog editor-dialog"><div class="editor-head"><h3><span class="file-ico code" style="flex-shrink:0"><svg class="ic svg-16"><use href="#i-edit"/></svg></span><span></span></h3><div class="dialog-btns"><button class="btn" data-a="close">Đóng</button><button class="btn primary" data-a="save">' + ICON('check', 'svg-14') + ' Lưu</button></div></div><textarea class="editor-area" spellcheck="false"></textarea></div>';
    back.querySelector('h3 span:last-child').textContent = f.name;
    const ta = back.querySelector('textarea');
    ta.value = text;
    if (isViewer()) {
      ta.readOnly = true;
      const saveBtn = back.querySelector('[data-a=save]');
      if (saveBtn) saveBtn.classList.add('hidden');
    }
    document.body.appendChild(back);
    ta.focus();
    const done = () => back.remove();
    back.querySelector('[data-a=close]').onclick = done;
    back.querySelector('[data-a=save]').onclick = async () => {
      try {
        await apiJson('/api/save', { method: 'POST', body: JSON.stringify({ path: filePath(f), pool: poolOfF(f), content: ta.value }) });
        toast('Đã lưu ' + f.name);
        done();
        loadFiles(currentPath);
      } catch (e) { toast('Lưu thất bại: ' + e.message, 'err'); }
    };
  } catch (e) { toast('Không mở được tệp: ' + e.message, 'err'); }
}

/* ---------- Share link ---------- */
function lockDialogTargets(list) {
  if (list.length <= 1) return lockDialog(list[0]);
  const back = document.createElement('div');
  back.className = 'overlay';
  back.innerHTML = `<div class="dialog lock-dialog">
    <h3><svg class="ic svg-18" style="color:var(--blue)"><use href="#i-lock"/></svg> Khóa <span class="lk-name"></span> mục bằng mật khẩu</h3>
    <div class="hint">Một mật khẩu áp dụng chung cho tất cả các mục đã chọn. Mật khẩu chỉ có hiệu lực trên thiết bị/app này.</div>
    <div class="lock-form">
      <label class="lock-label">Mật khẩu khóa</label>
      <input type="password" id="lk-pw" placeholder="Tối thiểu 3 ký tự" autocomplete="new-password">
      <div class="lock-note" id="lk-note">Sai mật khẩu quá 5 lần sẽ không thể mở mục này trong 8 giờ.</div>
    </div>
    <div class="dialog-btns">
      <button class="btn" data-a="cancel">Hủy</button>
      <button class="btn primary" data-a="ok" disabled>Xác nhận</button>
    </div></div>`;
  back.querySelector('.lk-name').textContent = list.length;
  document.body.appendChild(back);
  const done = () => back.remove();
  const inp = back.querySelector('#lk-pw');
  const okBtn = back.querySelector('[data-a=ok]');
  inp.addEventListener('input', () => { okBtn.disabled = inp.value.length < 3; });
  back.querySelector('[data-a=cancel]').onclick = done;
  back.addEventListener('mousedown', (e) => { if (e.target === back) done(); });
  const submit = async () => {
    if (okBtn.disabled) return;
    const h = await sha256text(inp.value);
    const map = ensureLockMapLoaded();
    let n = 0;
    for (const f of list) { map[lockKeyFor(f)] = h; n++; }
    saveLockMap(map);
    done();
    toast('Đã khóa ' + n + ' mục bằng cùng một mật khẩu');
    if (typeof updateLockDiskBtn === 'function') updateLockDiskBtn();
    renderFiles();
  };
  okBtn.onclick = submit;
  inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); });
  inp.focus();
}
function shareLinkTargets(list) {
  if (!list || !list.length) return toast('Hãy chọn tệp hoặc thư mục trước', 'warn');
  return shareLink(list.length === 1 ? list[0] : list);
}
async function shareLink(f) {
  if (isViewer()) return toast('Chế độ chỉ xem — không thể tạo link chia sẻ.', 'warn');
  if (!f) return toast('Hãy chọn một tệp hoặc thư mục trước', 'warn');
  const multi = Array.isArray(f) ? f : [f];
  const back = document.createElement('div');
  back.className = 'overlay';
  back.innerHTML = `<div class="dialog">
    <h3><svg class="ic svg-18" style="color:var(--blue)"><use href="#i-share"/></svg> Chia sẻ "..."</h3>
    <div class="hint">Ai có link đều tải được (không cần mật khẩu).</div>
    <div class="share-out-wrap" id="sh-out-wrap" style="display:none;max-height:220px;overflow:auto;margin-bottom:10px"></div>
    <div class="share-opts" id="sh-opts">
      <label>Link hết hạn:
        <select id="sh-ttl">
          <option value="1">1 giờ</option>
          <option value="24" selected>1 ngày</option>
          <option value="168">7 ngày</option>
          <option value="720">30 ngày</option>
        </select>
      </label>
      <label><input type="checkbox" id="sh-once"> Chỉ dùng 1 lần (tự hủy sau khi tải)</label>
    </div>
    <div class="dialog-btns">
      <button class="btn" data-a="cancel">Đóng</button>
      <button class="btn primary" data-a="create">Tạo link</button>
    </div></div>`;
  back.querySelector('h3').innerHTML = '<svg class="ic svg-18" style="color:var(--blue)"><use href="#i-share"/></svg> ' +
    (multi.length > 1 ? 'Chia sẻ ' + multi.length + ' mục' : 'Chia sẻ "' + esc(multi[0].name) + '"');
  document.body.appendChild(back);
  const done = () => back.remove();
  back.querySelector('[data-a=cancel]').onclick = done;
  back.addEventListener('mousedown', (e) => { if (e.target === back) done(); });
  const outWrap = back.querySelector('#sh-out-wrap');
  const copyAll = async (text) => {
    let ok = false;
    if (navigator.clipboard && window.isSecureContext) {
      try { await navigator.clipboard.writeText(text); ok = true; } catch {}
    }
    if (!ok) {
      try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.left = '-9999px';
        ta.style.top = '0';
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        document.execCommand('copy');
        ta.remove();
        ok = true;
      } catch {}
    }
    return ok;
  };
  back.querySelector('[data-a=create]').onclick = async () => {
    const ttlHours = Number(back.querySelector('#sh-ttl').value);
    const once = back.querySelector('#sh-once').checked;
    const links = [];
    for (const it of multi) {
      if (resolveLockTarget(it)) continue;
      try {
        const r = await apiJson('/api/share', { method: 'POST', body: JSON.stringify({ path: filePath(it), pool: poolOfF(it), ttlHours, once }) });
        const linkUrl = r.shareUrl || (location.origin + '/s/?id=' + encodeURIComponent(r.id));
        links.push({ name: it.name, url: linkUrl });
      } catch (e) { toast(it.name + ': ' + e.message, 'err'); }
    }
    if (!links.length) return;
    outWrap.innerHTML = links.map((l) =>
      '<div style="display:flex;align-items:center;gap:6px;margin-bottom:6px">' +
      '<input type="text" readonly style="flex:1" value="' + esc(l.url) + '" title="' + esc(l.name) + '">' +
      '<button class="btn" style="height:40px;min-width:64px" data-u="' + esc(l.url) + '">Copy</button></div>'
    ).join('') + (links.length > 1 ? '<button class="btn" id="sh-copy-all" style="height:36px;width:100%">Copy tất cả ' + links.length + ' link</button>' : '');
    outWrap.style.display = 'block';
    outWrap.querySelectorAll('button[data-u]').forEach((b) => b.addEventListener('click', async () => {
      await copyAll(b.dataset.u);
      b.innerHTML = 'Đã copy ✓';
      setTimeout(() => { b.textContent = 'Copy'; }, 1500);
    }));
    const copyAllBtn = outWrap.querySelector('#sh-copy-all');
    if (copyAllBtn) copyAllBtn.addEventListener('click', async () => {
      await copyAll(links.map((l) => l.url).join('\n'));
      copyAllBtn.innerHTML = 'Đã copy tất cả ✓';
      setTimeout(() => { copyAllBtn.textContent = 'Copy tất cả ' + links.length + ' link'; }, 1500);
    });
    back.querySelector('#sh-opts').style.display = 'none';
    back.querySelector('[data-a=create]').classList.add('hidden');
    toast(multi.length > 1 ? 'Đã tạo ' + links.length + ' link chia sẻ' : 'Đã tạo link chia sẻ');
  };
}

/* ---------- Transfers panel (driven by transferBus) ---------- */
function statusLabel(tr, pct) {
  switch (tr.status) {
    case 'active': return (pct + '%   ' + fmtSize(tr.done) + ' / ' + fmtSize(tr.total));
    case 'retrying': return 'Đang thử lại…';
    case 'paused': return 'Tạm dừng';
    case 'done': return '100%   ' + fmtSize(tr.total || tr.done);
    case 'browser': return 'Tải qua trình duyệt';
    case 'cancelled': return 'Đã hủy';
    case 'error': return 'Thất bại' + (tr.error ? ': ' + tr.error.slice(0, 40) : '');
    default: return 'Đang chờ';
  }
}
function etaLabel(tr) {
  if (tr.status === 'active' && tr.speed > 0 && tr.total > tr.done) {
    const sec = Math.round((tr.total - tr.done) / tr.speed);
    if (sec < 60) return fmtSize(tr.speed) + '/s • còn ' + sec + 's';
    return fmtSize(tr.speed) + '/s • còn ' + Math.floor(sec / 60) + ' phút';
  }
  if (tr.status === 'active') return tr.dir === 'copy' || tr.dir === 'cut' ? 'Đang ' + (tr.dir === 'copy' ? 'copy' : 'di chuyển') + '…' : 'Đang chuyển…';
  if (tr.status === 'retrying') return 'Mạng yếu — đang thử lại';
  if (tr.status === 'done') return tr.dir === 'up' ? 'Đã tải lên xong' : tr.dir === 'copy' ? 'Đã copy xong' : tr.dir === 'cut' ? 'Đã di chuyển xong' : 'Đã tải về xong';
  if (tr.status === 'paused') return 'Tạm dừng';
  if (tr.status === 'cancelled') return 'Đã hủy';
  if (tr.status === 'browser') return 'Do trình duyệt xử lý';
  if (tr.status === 'error') return 'Lỗi';
  return '';
}
function buildTransferRow(tr) {
  const pct = tr.total ? Math.min(100, Math.round((tr.done / tr.total) * 100)) : 0;
  const progCls = tr.status === 'done' ? ' green' : (tr.status === 'error' || tr.status === 'cancelled') ? ' red' : '';
  const poolObj = poolById(tr.pool);
  const dest = tr.destLabel || ((tr.dir === 'up' ? 'Tải lên → ' : 'Tải về ← ') + ((pools.length > 1 && poolObj) ? poolObj.name + ':' : '') + (tr.target || '/'));
  const arrow = tr.dir === 'copy' ? ICON('copy', 'svg-14') : tr.dir === 'cut' ? ICON('swap', 'svg-14') : (tr.dir === 'up' ? ICON('upload', 'svg-14') : ICON('download', 'svg-14'));
  const row = document.createElement('div');
  row.className = 'transfer-row';
  row.innerHTML =
    '<div class="transfer-name">' + iconHtml(tr.name, 'file') + '<span><b>' + esc(tr.name) + '</b> &nbsp; ' + arrow + '<br><span class="tr-sub">' + esc(dest) + '</span></span></div>' +
    '<div class="progress mini' + progCls + '"><span style="width:' + pct + '%"></span></div>' +
    '<div class="muted">' + esc(statusLabel(tr, pct)) + '</div>' +
    '<div class="muted">' + esc(etaLabel(tr)) + '</div>' +
    '<div style="text-align:right;white-space:nowrap" class="tr-btns"></div>';
  const btns = row.querySelector('.tr-btns');
  const mkBtn = (txt, title, fn) => {
    const b = document.createElement('span');
    b.className = 'small-link';
    b.textContent = txt;
    b.title = title;
    b.style.marginRight = '8px';
    b.addEventListener('click', fn);
    btns.appendChild(b);
    return b;
  };
  if (['active', 'retrying'].includes(tr.status) && !tr.noCancel) {
    mkBtn('Hủy', 'Hủy chuyển này', () => cancelTransfer(tr));
  } else if (tr.status === 'paused' && tr.dir === 'up' && tr.file) {
    mkBtn('Tiếp tục', 'Tiếp tục tải lên', () => {
      const i = transferBus.list.indexOf(tr);
      if (i >= 0) transferBus.list.splice(i, 1);
      renderTransfers();
      uploadFileResumable(tr.file, tr.targetDir || '', tr.pool, tr.file && tr.file._rel).then((r) => { if (r && r.rel != null) loadFiles(currentPath); });
    });
  }
  mkBtn('Xóa', 'Xóa khỏi danh sách', () => {
    const i = transferBus.list.indexOf(tr);
    if (i >= 0) { if (['active', 'retrying'].includes(tr.status)) cancelTransfer(tr); transferBus.list.splice(i, 1); renderTransfers(); }
  });
  return row;
}
function renderTransfers() {
  const list = transferBus.list.slice(0, 12);
  const activeCount = transferBus.list.filter((t) => ['active', 'retrying'].includes(t.status)).length;
  const compact = $('#tr-count'); if (compact) compact.textContent = activeCount;
  const fullCount = $('#tr-count-full'); if (fullCount) fullCount.textContent = activeCount;

  const fill = (wrap, items) => {
    if (!wrap) return;
    wrap.innerHTML = '';
    if (!items.length) {
      wrap.innerHTML = '<div class="empty-state" style="padding:18px"><div class="muted">Chưa có chuyển động nào</div></div>';
      return;
    }
    for (const tr of items) wrap.appendChild(buildTransferRow(tr));
  };
  fill($('#tr-list'), list);
  fill($('#tr-list-full'), list);
}
transferBus.onChange = renderTransfers;

/* ---------- Actions: rename / delete / new folder ---------- */
async function promptRename(f) {
  if (isViewer()) return toast('Chế độ chỉ xem — không thể đổi tên.', 'warn');
  if (await guardLocked(f)) { toast('Mục đang bị khóa — hãy mở khóa trước.', 'warn'); return; }
  promptDialog('Đổi tên "' + f.name + '"', f.name, 'Đổi tên', async (name) => {
    try {
      await apiJson('/api/rename', { method: 'POST', body: poolBody({ path: filePath(f), newName: name }) });
      toast('Đã đổi tên thành ' + name);
      loadFiles(currentPath);
    } catch (e) { toast(e.message, 'err'); }
  });
}
function confirmDelete(f) {
  if (isViewer()) return toast('Chế độ chỉ xem — không thể xóa.', 'warn');
  if (guardLockedToast(f)) return;
  confirmDialog('Xóa "' + f.name + '"?', 'Sẽ chuyển vào Thùng rác và giữ 30 ngày. Có thể hoàn tác ngay sau khi xóa.', 'Xóa', async () => {
    try {
      const r = await apiJson('/api/file?path=' + encodeURIComponent(filePath(f)) + poolQs(), { method: 'DELETE' });
      if (selected === f) { selected = null; renderDetail(null); }
      selectedSet.delete(f.name);
      loadFiles(currentPath);
      toast('Đã chuyển "' + f.name + '" vào Thùng rác', 'warn', {
        label: 'Hoàn tác',
        fn: async () => {
          try {
            await apiJson('/api/trash/restore', { method: 'POST', body: JSON.stringify({ id: r.trash }) });
            toast('Đã khôi phục ' + f.name);
            if (currentView === 'files') loadFiles(currentPath);
            if (currentView === 'trash') loadTrash();
          } catch (e2) { toast(e2.message, 'err'); }
        },
      });
    } catch (e) { toast(e.message, 'err'); }
  });
}
function confirmDeleteMany() {
  if (isViewer()) return toast('Chế độ chỉ xem — không thể xóa.', 'warn');
  const targets = [...selectedSet.values()];
  if (targets.length <= 1) return confirmDelete(targets[0] || selected);
  confirmDialog('Xóa ' + targets.length + ' mục đã chọn?', 'Tất cả sẽ chuyển vào Thùng rác và giữ 30 ngày.', 'Xóa', async () => {
    let okCount = 0;
    const failures = [];
    for (const f of targets) {
      try {
        await apiJson('/api/file?path=' + encodeURIComponent(filePath(f)) + poolQs(), { method: 'DELETE' });
        okCount++;
      } catch { failures.push(f.name); }
    }
    selectedSet.clear();
    loadFiles(currentPath);
    if (currentView === 'trash' || currentView === 'recent') return;
    toast('Đã chuyển ' + okCount + ' mục vào Thùng rác' + (failures.length ? ' — lỗi ' + failures.length + ' mục' : ''), failures.length ? 'err' : 'warn', {
      label: 'Mở Thùng rác',
      fn: () => switchView('trash'),
    });
  });
}

/* ---------- Recent ---------- */
async function loadRecent() {
  try {
    const d = await apiJson('/api/recent');
    const body = $('#recent-body');
    $('#recent-empty').classList.toggle('hidden', d.items.length > 0);
    body.innerHTML = d.items.map((it) => {
      const actLabel = { upload: 'Đã tải lên', download: 'Đã tải về', edit: 'Đã sửa', restore: 'Đã khôi phục' }[it.action] || it.action;
      return '<tr data-path="' + esc(it.path) + '"><td><div class="file-name">' + iconHtml(it.name, 'file') + '<span class="filename" title="' + esc(it.name) + '"><span class="fn-text">' + esc(fmtName(it.name)) + '</span></span></div></td>' +
        '<td class="muted">' + esc(actLabel) + '</td><td>' + fmtSize(it.size) + '</td><td class="muted">' + esc(timeAgo(it.time)) + '</td>' +
        '<td><span class="small-link" data-act="open">Mở thư mục</span> &nbsp; <span class="small-link" data-act="dl">' + ICON('download', 'svg-12') + '</span></td></tr>';
    }).join('');
    body.querySelectorAll('tr[data-path]').forEach((rowEl) => {
      const pth = rowEl.dataset.path;
      const it = d.items.find((x) => x.path === pth);
      const openBtn = rowEl.querySelector('[data-act=open]');
      if (!openBtn) return;
      const goto = () => {
        const dir = pth.split('/').slice(0, -1).join('/');
        switchView('files');
        if (it.pool && it.pool !== currentPool && poolById(it.pool)) {
          currentPool = it.pool;
          const sel = $('#pool-select');
          if (sel) sel.value = currentPool;
          updateSidebarSpace();
        }
        loadFiles(dir).then(() => {
          const row = $$('#fileBody tr').find((r) => r.dataset.name === it.name);
          if (row) row.click();
        });
      };
      rowEl.addEventListener('click', (e) => {
        const act = e.target && e.target.dataset ? e.target.dataset.act : null;
        const dir = pth.split('/').slice(0, -1).join('/');
        const ff = { name: it.name, size: it.size, type: 'file', rel: pth, dirRel: dir, pool: it.pool || currentPool };
        if (act === 'dl') { downloadFile(ff, pth, it.pool || currentPool); return; }
        goto();
      });
    });
  } catch (e) { toast(e.message, 'err'); }
}

/* ---------- Trash ---------- */
async function loadTrash() {
  try {
    const d = await apiJson('/api/trash');
    const body = $('#trash-body');
    $('#trash-empty').classList.toggle('hidden', d.items.length > 0);
    body.innerHTML = d.items.map((it) =>
      '<tr data-id="' + esc(it.id) + '"><td><div class="file-name">' + iconHtml(it.name, it.type) + '<span class="filename" title="' + esc(it.name) + '"><span class="fn-text">' + esc(fmtName(it.name)) + '</span></span></div>' +
      '<div class="tr-sub" style="font-size:11.5px">vị trí cũ: /' + esc(it.rel) + '</div></td>' +
      '<td>' + fmtSize(it.size) + '</td><td class="muted">' + esc(timeAgo(it.deletedAt)) + '</td>' +
      '<td><button class="btn" style="height:32px" data-act="restore">' + ICON('restore', 'svg-14') + ' Khôi phục</button> <button class="btn danger" style="height:32px;width:38px;padding:0" data-act="purge" title="Xóa vĩnh viễn">' + ICON('trash', 'svg-14') + '</button></td></tr>'
    ).join('');
    body.querySelectorAll('button[data-act="restore"]').forEach((b) => {
      b.addEventListener('click', async () => {
        try {
          await apiJson('/api/trash/restore', { method: 'POST', body: JSON.stringify({ id: b.closest('tr').dataset.id }) });
          toast('Đã khôi phục');
          loadTrash();
        } catch (e) { toast(e.message, 'err'); }
      });
    });
    body.querySelectorAll('button[data-act="purge"]').forEach((b) => {
      b.addEventListener('click', () => {
        confirmDialog('Xóa vĩnh viễn?', 'Mục này sẽ bị xóa hoàn toàn. Không thể hoàn tác.', 'Xóa vĩnh viễn', async () => {
          try {
            await apiJson('/api/trash/purge', { method: 'POST', body: JSON.stringify({ id: b.closest('tr').dataset.id }) });
            toast('Đã xóa vĩnh viễn');
            loadTrash();
          } catch (e) { toast(e.message, 'err'); }
        });
      });
    });
  } catch (e) { toast(e.message, 'err'); }
}

/* ---------- Keyboard shortcuts ---------- */
document.addEventListener('keydown', (e) => {
  if (isViewer() && e.ctrlKey && e.key.toLowerCase() === 'u') { e.preventDefault(); toast('Chế độ chỉ xem — không thể tải lên.', 'warn'); }
}, true);
document.addEventListener('keydown', (e) => {
  const tg = e.target instanceof Element ? e.target : null;
  if (tg && (tg.tagName === 'INPUT' || tg.tagName === 'TEXTAREA' || tg.closest('.editor-area'))) return;
  if (document.querySelector('.overlay') || document.querySelector('.ctx-menu')) return;
  if (currentView !== 'files') return;
  if (e.ctrlKey && (e.key === 'a' || e.key === 'A')) {
    e.preventDefault();
    const list = visibleFiles();
    selectedSet.clear();
    list.forEach((f) => selectedSet.set(f.name, f));
    anchorIndex = list.length - 1;
    syncSelection();
    return;
  }
  if ((e.ctrlKey) && (e.key === 'c' || e.key === 'C')) { e.preventDefault(); clipboardCopy(); return; }
  if ((e.ctrlKey) && (e.key === 'x' || e.key === 'X')) { e.preventDefault(); clipboardCut(); return; }
  if ((e.ctrlKey) && (e.key === 'v' || e.key === 'V')) { e.preventDefault(); clipboardPaste(); return; }
  if (e.key === 'Escape' && selectedSet.size && $('#search') !== document.activeElement) {
    selectedSet.clear();
    anchorIndex = null;
    syncSelection();
    renderDetail(null);
    return;
  }
  if (e.key === 'Enter' && selected) { e.preventDefault(); openEntry(selected); }
  else if (e.key === 'F2' && selected && !isViewer()) { e.preventDefault(); promptRename(selected); }
  else if (e.key === 'Delete' && selectedSet.size && !isViewer()) {
    e.preventDefault();
    if (selectedSet.size > 1) confirmDeleteMany(); else confirmDelete(selected);
  }
  else if (e.key === 'Backspace') {
    e.preventDefault();
    const parts = currentPath.split('/');
    if (parts.length > 1) loadFiles(parts.slice(0, -1).join('/'));
    else if (currentPath) loadFiles('');
  } else if (e.key === 'Escape' && $('#search') === document.activeElement) {
    $('#search').value = '';
    renderFiles();
  }
});

/* ---------- Sync (app desktop: đồng bộ thư mục local -> host) ---------- */
const hasSyncUI = !!(typeof window !== 'undefined' && window.dc && window.dc.syncList);
if (hasSyncUI && $('#nav-sync')) $('#nav-sync').classList.remove('hidden');
let refreshSyncSettings = null;

/* ---------- Cài đặt client (chỉ hiện trong app desktop) ---------- */
if ($('#nav-settings')) $('#nav-settings').classList.remove('hidden');
async function loadAppSettings() {
  const chk = $('#cs-autostart');
  if (!chk) return;
  if (!window.dc || !window.dc.autoStartGet) { chk.disabled = true; return; }
  try {
    const r = await window.dc.autoStartGet();
    chk.disabled = !r.ok;
    chk.checked = !!(r.ok && r.on);
  } catch { chk.disabled = true; }
  if (!chk.dataset.wired) {
    chk.dataset.wired = '1';
    chk.addEventListener('change', async () => {
      try {
        const r = await window.dc.autoStartSet(chk.checked);
        if (r.ok) toast(chk.checked ? 'Đã bật: app sẽ tự chạy ngầm khi mở Windows.' : 'Đã tắt mở cùng Windows.');
        else throw new Error(r.error || 'Không lưu được.');
      } catch (e) { toast(e.message, 'err'); chk.checked = !chk.checked; }
    });
  }
}

let gpuSettingsWired = false;
async function loadGpuSettings(forceRefresh = false) {
  const card = $('#gpu-settings-card');
  if (!card) return;
  const probeBtn = $('#gpu-probe-btn');
  const titleEl = $('#gpu-title');
  const badgeEl = $('#gpu-badge');
  const descEl = $('#gpu-desc');
  const nameEl = $('#gpu-name');
  const driverEl = $('#gpu-driver');
  const h264El = $('#gpu-h264');
  const hevcEl = $('#gpu-hevc');
  const adviceRow = $('#gpu-advice-row');
  const adviceLink = $('#gpu-advice-link');

  if (probeBtn && !probeBtn.dataset.wired) {
    probeBtn.dataset.wired = '1';
    probeBtn.addEventListener('click', () => {
      probeBtn.disabled = true;
      const oldHtml = probeBtn.innerHTML;
      probeBtn.innerHTML = '<svg class="ic svg-14"><use href="#i-refresh"/></svg> Đang quét phần cứng…';
      loadGpuSettings(true).finally(() => {
        probeBtn.innerHTML = oldHtml;
        probeBtn.disabled = false;
      });
    });
  }

  if (!gpuSettingsWired) {
    gpuSettingsWired = true;
    $$('input[name="gpu-mode"]').forEach((radio) => {
      radio.addEventListener('change', async () => {
        if (!radio.checked) return;
        try {
          const res = await api('/api/gpu/mode', 'POST', { mode: radio.value });
          if (res && res.ok) {
            toast('Đã đổi chế độ: ' + (radio.value === 'auto' ? 'Tự động' : radio.value === 'gpu' ? 'Ưu tiên GPU' : 'Chỉ dùng CPU'));
            if (res.info) renderGpuInfo(res.info);
          }
        } catch (e) {
          toast(errText(e), 'err');
        }
      });
    });
  }

  function renderGpuInfo(info) {
    if (!info) return;
    const mode = info.currentMode || 'auto';
    const checkedRadio = $(`input[name="gpu-mode"][value="${mode}"]`);
    if (checkedRadio) checkedRadio.checked = true;

    if (nameEl) nameEl.textContent = info.primaryGpuName || 'Không xác định';
    if (driverEl) {
      const c = (info.controllers && info.controllers[0]) || {};
      driverEl.textContent = c.driver || 'Mặc định hệ thống';
    }
    if (h264El) {
      h264El.innerHTML = info.h264Hw
        ? '<span style="color:var(--green);font-weight:600">✅ Có hỗ trợ phần cứng</span>'
        : '<span style="color:var(--muted)">⚠️ Xử lý qua CPU</span>';
    }
    if (hevcEl) {
      hevcEl.innerHTML = info.hevcHw
        ? '<span style="color:var(--green);font-weight:600">✅ Có hỗ trợ phần cứng</span>'
        : '<span style="color:var(--muted)">⚠️ Xử lý qua CPU</span>';
    }

    if (titleEl) titleEl.textContent = info.statusTitle || 'Trạng thái GPU';
    if (descEl) descEl.textContent = info.statusMessage || '';

    if (badgeEl) {
      if (info.statusType === 'ok') {
        badgeEl.textContent = '🟢 Hoạt động tối ưu';
        badgeEl.style.background = '#dcfce7';
        badgeEl.style.color = '#15803d';
      } else if (info.statusType === 'warning') {
        badgeEl.textContent = '🟡 Cần cập nhật driver';
        badgeEl.style.background = '#fef9c3';
        badgeEl.style.color = '#854d0e';
      } else {
        badgeEl.textContent = '⚪ Chế độ CPU';
        badgeEl.style.background = '#f1f5f9';
        badgeEl.style.color = '#475569';
      }
    }

    if (adviceRow && adviceLink) {
      if (info.adviceLink) {
        adviceRow.style.display = 'block';
        adviceLink.href = info.adviceLink;
      } else {
        adviceRow.style.display = 'none';
      }
    }
  }

  try {
    const info = await api('/api/gpu/status' + (forceRefresh ? '?refresh=1' : ''), 'GET');
    renderGpuInfo(info);
    if (forceRefresh) toast('✅ Đã hoàn tất chẩn đoán phần cứng GPU!');
  } catch (e) {
    if (titleEl) titleEl.textContent = 'Không thể lấy thông tin GPU';
    if (descEl) descEl.textContent = errText(e);
  }
}

function syncStatusLabel(cfg) {
  const modeText = cfg.twoWay ? '🔄 Đồng bộ 2 chiều' : '⬆ Chỉ tải lên';
  if (cfg.status === 'busy') return `${modeText} — Đang đồng bộ` + (cfg.pending ? ' (' + cfg.pending + ' tệp)…' : '…');
  if (cfg.status === 'err') return `${modeText} — ⚠ Lỗi: ` + (cfg.error || 'không rõ');
  if (!cfg.enabled) return `${modeText} — Tạm dừng`;
  if (cfg.lastRun) return `${modeText} — Đã đồng bộ lúc ` + new Date(cfg.lastRun).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) + (cfg.synced != null ? ' (' + cfg.synced + ' lượt)' : '');
  return `${modeText} — Đang theo dõi…`;
}
async function loadSync() {
  if (!hasSyncUI) return;
  const wrap = $('#sync-list');
  if (!wrap) return;
  let d;
  try { d = await window.dc.syncList(); } catch { d = { items: [] }; }
  const items = (d && d.items) || [];
  $('#sync-empty').classList.toggle('hidden', items.length > 0);
  wrap.innerHTML = '';
  for (const cfg of items) {
    const card = document.createElement('div');
    card.className = 'sync-card';
    const dotCls = cfg.status === 'busy' ? 'busy' : cfg.status === 'err' ? 'err' : cfg.enabled ? 'ok' : 'paused';
    card.innerHTML =
      '<div class="sync-name"><span class="file-ico folder" style="color:var(--yellow)"><svg class="ic svg-22"><use href="#i-folder"/></svg></span><span class="snm"></span>' +
      (cfg.twoWay ? '<span class="badge" style="background:#e0f2fe;color:#0369a1;margin-left:8px;font-size:11px;font-weight:600;padding:2px 6px;border-radius:4px">2 chiều</span>' : '<span class="badge" style="background:#f1f5f9;color:#475569;margin-left:8px;font-size:11px;font-weight:600;padding:2px 6px;border-radius:4px">1 chiều</span>') +
      '<span style="margin-left:auto;display:flex;gap:8px">' +
      (cfg.enabled ? '<button class="btn" style="height:32px" data-a="pause">' + ICON('pause', 'svg-14') + ' Tạm dừng</button>' : '<button class="btn primary" style="height:32px" data-a="resume">' + ICON('play', 'svg-14') + ' Tiếp tục</button>') +
      '<button class="btn" style="height:32px" data-a="mode" title="Chuyển chế độ 2 chiều / 1 chiều">' + (cfg.twoWay ? 'Chuyển 1 chiều' : 'Chuyển 2 chiều') + '</button>' +
      '<button class="btn" style="height:32px" data-a="now">' + ICON('refresh', 'svg-14') + ' Đồng bộ ngay</button>' +
      '<button class="btn" style="height:32px" data-a="open">' + ICON('folder', 'svg-14') + ' Mở</button>' +
      '<button class="btn danger" style="height:32px" data-a="del">' + ICON('trash', 'svg-14') + ' Gỡ</button>' +
      '</span></div>' +
      '<div class="sync-path"></div>' +
      '<div class="sync-status"><span class="sync-dots ' + dotCls + '"></span><span class="st-text"></span></div>' +
      '<div class="sync-hist"></div>';
    card.querySelector('.snm').textContent = cfg.name || cfg.local;
    const histWrap = card.querySelector('.sync-hist');
    const hist = (cfg.history || []);
    if (hist.length) {
      const dirLabel = { up: 'Đã tải lên', down: 'Đã tải về', del_remote: 'Đã xóa trên Host', del_local: 'Đã xóa trên Client', rename_remote: 'Đã đổi tên trên Host', rename_local: 'Đã đổi tên trên Client' };
      const dirIcon = { up: 'i-status-synced', down: 'i-status-synced', del_remote: 'i-status-error', del_local: 'i-status-error', rename_remote: 'i-status-synced', rename_local: 'i-status-synced' };
      let html = '<div class="sync-history-title">Lịch sử đồng bộ (' + cfg.synced + ' lượt)</div><div class="sync-history">';
      for (const h of hist) {
        const ic = dirIcon[h.dir] || 'i-status-synced';
        html += '<div class="sync-hist-row">' + iconHtml(h.rel, 'file') + '<span><svg class="svg-status" style="width:14px;height:14px;margin-right:6px;vertical-align:-2px"><use href="#' + ic + '"/></svg><span class="hn"></span></span><span class="hr">' + esc(dirLabel[h.dir] || h.dir) + '</span><span class="hr">' + esc(fmtSize(h.size)) + '</span><span class="hr">' + esc(timeAgo(new Date(h.time).toISOString())) + '</span></div>';
      }
      html += '</div>';
      histWrap.innerHTML = html;
      histWrap.querySelectorAll('.sync-hist-row .hn').forEach((el, i) => { el.textContent = hist[i].rel; });
    } else if (cfg.status !== 'busy') {
      histWrap.innerHTML = '<div class="muted" style="font-size:12.5px;margin-top:8px">Chưa có tệp nào được đồng bộ.</div>';
    }
    card.querySelector('.sync-path').textContent = cfg.local + '  ⇄  máy chủ: ' + (cfg.remote || '(gốc)') + (cfg.pool && pools.length > 1 ? '  •  ổ ' + ((poolById(cfg.pool) || {}).name || cfg.pool) : '');
    card.querySelector('.st-text').textContent = syncStatusLabel(cfg);
    card.querySelector('[data-a=now]').onclick = async () => { try { await window.dc.syncNow(cfg.id); toast('Đang đồng bộ "' + (cfg.name || cfg.local) + '"'); setTimeout(loadSync, 800); } catch (e) { toast(String(e.message || e), 'err'); } };
    const pauseBtn = card.querySelector('[data-a=pause]');
    if (pauseBtn) pauseBtn.onclick = () => window.dc.syncToggle(cfg.id, false).then(loadSync);
    const resumeBtn = card.querySelector('[data-a=resume]');
    if (resumeBtn) resumeBtn.onclick = () => window.dc.syncToggle(cfg.id, true).then(loadSync);
    const modeBtn = card.querySelector('[data-a=mode]');
    if (modeBtn) modeBtn.onclick = () => window.dc.syncMode(cfg.id, !cfg.twoWay).then(loadSync);
    card.querySelector('[data-a=open]').onclick = () => window.dc.syncOpen(cfg.id);
    card.querySelector('[data-a=del]').onclick = () => {
      confirmDialog('Gỡ đồng bộ "' + (cfg.name || cfg.local) + '"?', 'Các tệp đã đẩy lên máy chủ sẽ được giữ nguyên, chỉ ngừng theo dõi thư mục này.', 'Gỡ đồng bộ', async () => {
        try { await window.dc.syncRemove(cfg.id); toast('Đã gỡ đồng bộ'); loadSync(); } catch (e) { toast(String(e.message || e), 'err'); }
      });
    };
    wrap.appendChild(card);
  }
}
if (hasSyncUI) {
  /* Đồng bộ thư mục: Cài đặt và Tự động phát hiện */
  async function refreshSyncSettingsUI() {
    if (!window.dc || !window.dc.syncList) return;
    try {
      const d = await window.dc.syncList();
      const items = (d && d.items) || [];
      const primary = items[0];
      if (primary) {
        if ($('#cs-local')) $('#cs-local').value = primary.local;
        if ($('#cs-mode-2way')) $('#cs-mode-2way').checked = primary.twoWay !== false;
        if ($('#cs-mode-1way')) $('#cs-mode-1way').checked = primary.twoWay === false;
      }
    } catch {}

    const hn = $('#cs-host-name');
    if (hn) {
      const hostDisplay = (serverState && serverState.host) || window.location.hostname || 'Máy chủ Host';
      const portDisplay = (serverState && serverState.port) || window.location.port || '8080';
      hn.textContent = `${hostDisplay} (${window.location.hostname}:${portDisplay})`;
    }
  }

  /* Host Picker Modal Logic */
  let selectedHostToSwitch = '';

  async function openHostPickerModal() {
    const modal = $('#modal-pick-host');
    if (!modal) return;
    modal.classList.remove('hidden');
    selectedHostToSwitch = '';
    const inp = $('#pick-host-custom-input');
    if (inp) inp.value = '';
    await scanAndRenderHosts();
  }

  function closeHostPickerModal() {
    const modal = $('#modal-pick-host');
    if (modal) modal.classList.add('hidden');
  }

  async function scanAndRenderHosts() {
    const listEl = $('#pick-host-list');
    if (!listEl) return;
    listEl.innerHTML = '<div class="muted" style="text-align:center;padding:20px 0;font-size:13px"><svg class="ic svg-16" style="animation:sync-spin 1s linear infinite;margin-right:6px"><use href="#i-sync"/></svg> Đang quét tìm các máy chủ trong mạng…</div>';

    const currentOrigin = window.location.origin.toLowerCase();
    let discovered = [];
    let saved = [];

    if (window.dc) {
      try {
        const [d, s] = await Promise.all([
          window.dc.discover ? window.dc.discover() : Promise.resolve({ hosts: [] }),
          window.dc.hostsList ? window.dc.hostsList() : Promise.resolve([])
        ]);
        discovered = (d && d.hosts) || [];
        saved = s || [];
      } catch {}
    }

    const hostMap = new Map();
    for (const h of [...discovered, ...saved]) {
      const url = h.url || `http://${h.ip}:${h.port || 8080}`;
      const key = url.replace(/\/$/, '').toLowerCase();
      if (!hostMap.has(key)) {
        hostMap.set(key, {
          name: h.name || 'CW Datacenter',
          ip: h.ip,
          port: h.port || 8080,
          url: url.replace(/\/$/, ''),
          online: h.ok !== false
        });
      }
    }

    const curKey = currentOrigin.replace(/\/$/, '');
    if (!hostMap.has(curKey)) {
      hostMap.set(curKey, {
        name: (serverState && serverState.host) || 'Host hiện tại',
        ip: window.location.hostname,
        port: window.location.port || 8080,
        url: curKey,
        online: true,
        isCurrent: true
      });
    } else {
      hostMap.get(curKey).isCurrent = true;
    }

    const allHosts = [...hostMap.values()];
    if (allHosts.length === 0) {
      listEl.innerHTML = '<div class="muted" style="text-align:center;padding:16px 0;font-size:13px">Chưa tìm thấy máy chủ nào. Bạn có thể nhập trực tiếp IP ở ô bên trên.</div>';
      return;
    }

    listEl.innerHTML = '';
    for (const h of allHosts) {
      const isCur = h.url.toLowerCase() === currentOrigin;
      const isSelected = selectedHostToSwitch === h.url || (!selectedHostToSwitch && isCur);
      if (isSelected) selectedHostToSwitch = h.url;

      const item = document.createElement('label');
      item.className = 'scope-row';
      item.style.cssText = `display:flex;align-items:center;justify-content:space-between;padding:10px 12px;border-radius:8px;border:1px solid ${isSelected ? 'var(--blue)' : '#e2e8f0'};background:${isSelected ? '#f0f7ff' : '#ffffff'};cursor:pointer;user-select:none;transition:all 0.15s`;
      
      item.innerHTML = `
        <div style="display:flex;align-items:center;gap:12px">
          <input type="radio" name="pick-host-radio" value="${esc(h.url)}" ${isSelected ? 'checked' : ''} style="accent-color:var(--blue);width:16px;height:16px">
          <div>
            <div style="display:flex;align-items:center;gap:8px">
              <b style="font-size:14px;color:#1e293b">${esc(h.name || 'CW Datacenter')}</b>
              ${isCur ? '<span class="badge" style="background:#e0f2fe;color:#0369a1;font-size:11px;font-weight:600;padding:2px 6px;border-radius:4px">Đang kết nối hiện tại</span>' : ''}
              ${!isCur && h.online ? '<span class="badge" style="background:#dcfce7;color:#15803d;font-size:11px;font-weight:600;padding:2px 6px;border-radius:4px">● Online</span>' : ''}
            </div>
            <div class="muted" style="font-size:12.5px;margin-top:2px;font-family:monospace">${esc(h.url)}</div>
          </div>
        </div>
      `;

      item.addEventListener('click', () => {
        selectedHostToSwitch = h.url;
        listEl.querySelectorAll('label').forEach((el) => {
          el.style.border = '1px solid #e2e8f0';
          el.style.background = '#ffffff';
        });
        item.style.border = '1px solid var(--blue)';
        item.style.background = '#f0f7ff';
        const rad = item.querySelector('input[type=radio]');
        if (rad) rad.checked = true;
      });

      listEl.appendChild(item);
    }
  }

  const switchHostBtn = $('#cs-switch-host');
  if (switchHostBtn) {
    switchHostBtn.addEventListener('click', openHostPickerModal);
  }

  const modalCloseBtn = $('#modal-pick-host-close');
  if (modalCloseBtn) modalCloseBtn.addEventListener('click', closeHostPickerModal);

  const modalCancelBtn = $('#modal-pick-host-cancel');
  if (modalCancelBtn) modalCancelBtn.addEventListener('click', closeHostPickerModal);

  const refreshHostsBtn = $('#btn-pick-host-refresh');
  if (refreshHostsBtn) refreshHostsBtn.addEventListener('click', scanAndRenderHosts);

  const confirmSwitchHostBtn = $('#modal-pick-host-confirm');
  if (confirmSwitchHostBtn) {
    confirmSwitchHostBtn.addEventListener('click', async () => {
      const customVal = ($('#pick-host-custom-input') && $('#pick-host-custom-input').value.trim()) || '';
      let targetUrl = customVal || selectedHostToSwitch;
      if (!targetUrl) return toast('Hãy chọn một Host hoặc nhập địa chỉ IP máy chủ.', 'warn');
      if (!/^https?:\/\//i.test(targetUrl)) targetUrl = 'http://' + targetUrl;

      confirmSwitchHostBtn.disabled = true;
      confirmSwitchHostBtn.textContent = 'Đang kết nối…';

      try {
        if (window.dc && window.dc.connect) {
          const r = await window.dc.connect(targetUrl);
          if (r && r.ok === false) {
            throw new Error(r.error || 'Không kết nối được tới Host này.');
          }
          closeHostPickerModal();
          toast('✅ Đang kết nối tới Host: ' + targetUrl);
        } else {
          window.location.href = targetUrl;
        }
      } catch (e) {
        toast(e.message || String(e), 'err');
      } finally {
        confirmSwitchHostBtn.disabled = false;
        confirmSwitchHostBtn.innerHTML = '<svg class="ic svg-14"><use href="#i-checkcircle"/></svg> Xác nhận chuyển Host';
      }
    });
  }

  const openLocalBtn = $('#cs-open-local');
  if (openLocalBtn) {
    openLocalBtn.addEventListener('click', () => {
      const val = ($('#cs-local') && $('#cs-local').value) || '';
      if (window.dc && window.dc.syncOpenDir) window.dc.syncOpenDir(val);
    });
  }

  const pickLocalBtn = $('#cs-pick-local');
  if (pickLocalBtn) {
    pickLocalBtn.addEventListener('click', async () => {
      if (window.dc && window.dc.syncChangeDir) {
        try {
          const r = await window.dc.syncChangeDir();
          if (r && r.ok) {
            toast('✅ Đã chuyển thư mục đồng bộ sang: ' + r.path);
            refreshSyncSettingsUI();
            loadSync();
          }
        } catch (e) { toast(String(e.message || e), 'err'); }
      }
    });
  }

  const syncNowBtn = $('#cs-sync-now-btn');
  if (syncNowBtn) {
    syncNowBtn.addEventListener('click', async () => {
      if (!window.dc || !window.dc.syncList) return;
      try {
        const d = await window.dc.syncList();
        const items = (d && d.items) || [];
        if (items[0]) {
          await window.dc.syncNow(items[0].id);
          toast('🔄 Đang đồng bộ thư mục ngay…');
          setTimeout(loadSync, 800);
        }
      } catch (e) { toast(String(e.message || e), 'err'); }
    });
  }

  const mode2wayRadio = $('#cs-mode-2way');
  if (mode2wayRadio) {
    mode2wayRadio.addEventListener('change', async () => {
      if (mode2wayRadio.checked && window.dc && window.dc.syncList && window.dc.syncMode) {
        const d = await window.dc.syncList();
        const items = (d && d.items) || [];
        if (items[0]) {
          await window.dc.syncMode(items[0].id, true);
          toast('🔄 Đã chuyển sang chế độ Đồng bộ 2 chiều.');
          loadSync();
        }
      }
    });
  }

  const mode1wayRadio = $('#cs-mode-1way');
  if (mode1wayRadio) {
    mode1wayRadio.addEventListener('change', async () => {
      if (mode1wayRadio.checked && window.dc && window.dc.syncList && window.dc.syncMode) {
        const d = await window.dc.syncList();
        const items = (d && d.items) || [];
        if (items[0]) {
          await window.dc.syncMode(items[0].id, false);
          toast('⬆ Đã chuyển sang chế độ Đồng bộ 1 chiều (chỉ tải lên).');
          loadSync();
        }
      }
    });
  }

  refreshSyncSettings = refreshSyncSettingsUI;
  if (window.dc.onSyncUpdate) window.dc.onSyncUpdate(() => {
    refreshSyncSettingsUI();
    if (currentView === 'sync') loadSync();
  });
}

/* ---------- Window controls (desktop frameless) ---------- */
function bindWinButtons(root) {
  root.querySelectorAll('[data-win]').forEach((b) => {
    if (b.dataset.winBound) return;
    b.dataset.winBound = '1';
    b.addEventListener('click', () => {
      if (window.dc && window.dc.winControl) window.dc.winControl(b.dataset.win);
    });
  });
}
bindWinButtons(document);
if (window.dc && document.body.classList.contains('dc-app')) {
  if (window.dc.onWinMaximized) {
    window.dc.onWinMaximized((m) => { $$('[data-win=max]').forEach((b) => { b.textContent = m ? '❐' : '□'; }); });
  }
}

/* ---------- Wire up ---------- */
$('#login-btn').addEventListener('click', doLogin);
$('#login-pass').addEventListener('keydown', (e) => { if (e.key === 'Enter') doLogin(); });
$('#btn-logout').addEventListener('click', async () => {
  try { await api('/api/logout', { method: 'POST' }); } catch {}
  localStorage.removeItem('cw_token');
  if (window.dc && window.dc.disconnect) {
    await window.dc.disconnect();
  } else {
    showLogin();
  }
});
$('#refresh').addEventListener('click', () => { loadPools(); loadFiles(currentPath); });
$('#search').addEventListener('input', renderFiles);
$('#pool-select').addEventListener('change', (e) => switchPool(e.target.value));
$('#btn-upload').addEventListener('click', () => $('#file-picker').click());
$('#file-picker').addEventListener('change', (e) => { uploadFiles(e.target.files); e.target.value = ''; });
$('#btn-newfolder').addEventListener('click', () => {
  if (isViewer()) return toast('Chế độ chỉ xem — không thể tạo thư mục.', 'warn');
  if (isPoolLocked(currentPool)) { lockWarnToast(poolTarget(currentPool)); return unlockDialog(poolTarget(currentPool)); }
  promptDialog('Tên thư mục mới', 'Thư mục mới', 'Tạo', async (name) => {
    try {
      await apiJson('/api/mkdir', { method: 'POST', body: poolBody({ path: (currentPath ? currentPath + '/' : '') + name }) });
      toast('Đã tạo thư mục ' + name);
      loadFiles(currentPath);
    } catch (e) { toast(e.message, 'err'); }
  });
});
$('#btn-download').addEventListener('click', () => {
  const targets = [...selectedSet.values()];
  if (!targets.length && selected) return downloadEntry(selected);
  if (!targets.length) return toast('Hãy chọn (các) tệp hoặc thư mục trước', 'warn');
  downloadMany(targets);
});
$('#btn-share').addEventListener('click', () => {
  const targets = [...selectedSet.values()];
  if (targets.length) return shareLinkTargets(targets);
  if (selected) return shareLinkTargets([selected]);
  toast('Hãy chọn một tệp hoặc thư mục trước', 'warn');
});
function updateLockDiskBtn() {
  const b = $('#btn-lockdisk');
  if (!b) return;
  const locked = isPoolLocked(effectivePool());
  b.innerHTML = ICON(locked ? 'unlock' : 'lock', 'svg-16') + (locked ? ' Mở khóa ổ này' : ' Khóa ổ này');
  const icEl = b.querySelector('svg');
  if (icEl) { icEl.style.verticalAlign = '-3px'; icEl.style.color = 'var(--blue)'; }
}
$('#btn-lockdisk').addEventListener('click', () => {
  const t = poolTarget(effectivePool());
  if (isPoolLocked(effectivePool())) unlockDialog(t, () => { updateLockDiskBtn(); loadFiles(currentPath); });
  else lockDialog(t);
});
function clearCompleted() {
  for (let i = transferBus.list.length - 1; i >= 0; i--) if (transferBus.list[i].status !== 'active' && transferBus.list[i].status !== 'retrying') transferBus.list.splice(i, 1);
  renderTransfers();
}
$('#tr-clear').addEventListener('click', clearCompleted);
$('#tr-clear-full').addEventListener('click', clearCompleted);
$('#btn-empty-trash').addEventListener('click', () => {
  if (isViewer()) return toast('Read-only mode.', 'warn');
  confirmDialog('Empty Trash?', 'All items in Trash will be permanently removed. This cannot be undone.', 'Empty Trash', async () => {
    try {
      await apiJson('/api/trash/purge', { method: 'POST', body: JSON.stringify({}) });
      toast('Trash emptied');
      loadTrash();
    } catch (e) { toast(e.message, 'err'); }
  });
});
$('#sb-viewhost').addEventListener('click', () => { open('/host.html', '_blank'); });

$('#d-open').addEventListener('click', () => selected && openEntry(selected));
$('#d-download').addEventListener('click', () => { if (selected) downloadEntry(selected); else toast('Hãy chọn tệp hoặc thư mục trước', 'warn'); });
$('#d-rename').addEventListener('click', () => selected && promptRename(selected));
$('#d-delete').addEventListener('click', () => selected && confirmDelete(selected));

const dz = $('#dropzone');
['dragenter', 'dragover'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add('dropzone-active'); }));
['dragleave', 'drop'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); if (!e.relatedTarget || !dz.contains(e.relatedTarget)) dz.classList.remove('dropzone-active'); }));
async function expandDropItems(entries) {
  const out = [];
  for (const e of entries) {
    if (e.isFile) {
      let f;
      try { f = await new Promise((res, rej) => e.file(res, rej)); } catch { continue; }
      f._rel = (e.fullPath ? e.fullPath.replace(/^\/+/, '').replace(/\\/g, '/') : f.name) || f.name;
      out.push(f);
    } else if (e.isDirectory) {
      const reader = e.createReader();
      const batched = [];
      for (;;) {
        let batch;
        try { batch = await new Promise((res, rej) => reader.readEntries(res, rej)); } catch { break; }
        if (!batch || !batch.length) break;
        batched.push(...batch);
        if (batch.length < 100) break;
      }
      out.push(...(await expandDropItems(batched)));
    }
  }
  return out;
}
dz.addEventListener('drop', async (e) => {
  const dts = e.dataTransfer;
  let entries = null;
  try {
    if (dts && dts.items && dts.items.length) {
      entries = [...dts.items].map((it) => (it.webkitGetAsEntry ? it.webkitGetAsEntry() : null)).filter(Boolean);
    }
  } catch {}
  const list = entries && entries.length ? await expandDropItems(entries) : Array.from(dts ? dts.files : []);
  if (!list.length) { toast('Không tải lên được — hãy chọn tệp/thư mục có thể đọc được.', 'warn'); return; }
  uploadFiles(list);
});
$('#v-files').addEventListener('contextmenu', (e) => {
  if (e.target.closest('tr') || e.target.closest('button') || e.target.closest('.detail') || e.target.closest('.client-toolbar-wrap') || e.target.closest('.transfer-panel')) return;
  if (currentView !== 'files') return;
  e.preventDefault();
  const items = [];
  if (clipboardSize() > 0) items.push({ icon: ICON('paste', 'svg-16'), label: 'Dán vào đây (' + clipboardLabel() + ')  (Ctrl+V)', fn: () => clipboardPaste() });
  else items.push({ icon: ICON('paste', 'svg-16'), label: 'Dán vào đây (chưa có gì để dán)', fn: () => {} });
  items.push('-');
  items.push({ icon: ICON('folderplus', 'svg-16'), label: 'Thư mục mới', fn: () => $('#btn-newfolder').click() });
  items.push({ icon: ICON('upload', 'svg-16'), label: 'Tải lên', fn: () => $('#file-picker').click() });
  items.push({ icon: ICON('refresh', 'svg-16'), label: 'Làm mới', fn: () => $('#refresh').click() });
  openCtx(e.clientX, e.clientY, items);
});

renderTransfers();
if (isTouch) {
  const kh = document.querySelector('.keys-hint');
  if (kh) kh.remove();
}
if (new URLSearchParams(location.search).get('embed') === '1') {
  const app = $('#page-app');
  app.style.gridTemplateColumns = '1fr';
  app.style.gridTemplateRows = '1fr';
  const tb = document.querySelector('.window-titlebar');
  const sb = document.querySelector('.sidebar');
  if (tb) tb.remove();
  if (sb) sb.remove();
  app.style.height = '100vh';
  app.style.width = '100vw';
  app.style.borderRadius = '0';
  app.style.border = '0';
  app.style.boxShadow = 'none';
  document.body.style.padding = '0';
  const lg = document.querySelector('.login-page');
  if (lg) lg.style.minHeight = '100vh';
}
trySilent();
