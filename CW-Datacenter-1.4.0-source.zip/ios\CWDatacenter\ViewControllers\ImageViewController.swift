import UIKit

class ImageViewController: UIViewController, UIPageViewControllerDataSource, UIPageViewControllerDelegate {

    private let playlist: [[String: Any]]
    private var currentIndex: Int
    private var pageViewController: UIPageViewController!

    private let topBar = UIView()
    private let closeBtn = UIButton(type: .system)
    private let titleLabel = UILabel()
    private let counterLabel = UILabel()
    private let shareBtn = UIButton(type: .system)

    init(playlist: [[String: Any]], initialIndex: Int) {
        self.playlist = playlist.isEmpty ? [["name": "Hình ảnh", "url": ""]] : playlist
        self.currentIndex = max(0, min(initialIndex, playlist.count - 1))
        super.init(nibName: nil, bundle: nil)
    }

    convenience init(url: String, name: String) {
        self.init(playlist: [["name": name, "url": url]], initialIndex: 0)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        setupPageViewController()
        setupTopBar()
        updateHeaderInfo(for: currentIndex)
    }

    private func setupPageViewController() {
        pageViewController = UIPageViewController(
            transitionStyle: .scroll,
            navigationOrientation: .horizontal,
            options: [UIPageViewController.OptionsKey.interPageSpacing: 16]
        )
        pageViewController.dataSource = self
        pageViewController.delegate = self

        let initialVC = singlePhotoVC(for: currentIndex)
        pageViewController.setViewControllers([initialVC], direction: .forward, animated: false, completion: nil)

        addChild(pageViewController)
        view.addSubview(pageViewController.view)
        pageViewController.view.frame = view.bounds
        pageViewController.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        pageViewController.didMove(toParent: self)
    }

    private func setupTopBar() {
        topBar.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        topBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(topBar)

        closeBtn.setTitle("✕", for: .normal)
        closeBtn.setTitleColor(.white, for: .normal)
        closeBtn.titleLabel?.font = UIFont.systemFont(ofSize: 22, weight: .bold)
        closeBtn.addTarget(self, action: #selector(onCloseTapped), for: .touchUpInside)
        closeBtn.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(closeBtn)

        titleLabel.textColor = .white
        titleLabel.font = UIFont.systemFont(ofSize: 14, weight: .semibold)
        titleLabel.textAlignment = .left
        titleLabel.lineBreakMode = .byTruncatingMiddle
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(titleLabel)

        counterLabel.textColor = UIColor.white.withAlphaComponent(0.8)
        counterLabel.font = UIFont.monospacedDigitSystemFont(ofSize: 12, weight: .regular)
        counterLabel.textAlignment = .left
        counterLabel.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(counterLabel)

        shareBtn.setTitle("Chia sẻ", for: .normal)
        shareBtn.setTitleColor(.white, for: .normal)
        shareBtn.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
        shareBtn.backgroundColor = UIColor.white.withAlphaComponent(0.18)
        shareBtn.layer.cornerRadius = 6
        shareBtn.addTarget(self, action: #selector(onShareTapped), for: .touchUpInside)
        shareBtn.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(shareBtn)

        NSLayoutConstraint.activate([
            topBar.topAnchor.constraint(equalTo: view.topAnchor),
            topBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            topBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            topBar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 54),

            closeBtn.leadingAnchor.constraint(equalTo: topBar.leadingAnchor, constant: 14),
            closeBtn.bottomAnchor.constraint(equalTo: topBar.bottomAnchor, constant: -10),
            closeBtn.widthAnchor.constraint(equalToConstant: 36),
            closeBtn.heightAnchor.constraint(equalToConstant: 36),

            titleLabel.leadingAnchor.constraint(equalTo: closeBtn.trailingAnchor, constant: 10),
            titleLabel.topAnchor.constraint(equalTo: closeBtn.topAnchor, constant: -2),
            titleLabel.trailingAnchor.constraint(lessThanOrEqualTo: shareBtn.leadingAnchor, constant: -10),

            counterLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            counterLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 2),

            shareBtn.trailingAnchor.constraint(equalTo: topBar.trailingAnchor, constant: -14),
            shareBtn.centerYAnchor.constraint(equalTo: closeBtn.centerYAnchor),
            shareBtn.widthAnchor.constraint(equalToConstant: 68),
            shareBtn.heightAnchor.constraint(equalToConstant: 30)
        ])
    }

    private func updateHeaderInfo(for index: Int) {
        guard index >= 0 && index < playlist.count else { return }
        let item = playlist[index]
        titleLabel.text = (item["name"] as? String) ?? "Hình ảnh"
        counterLabel.text = "\(index + 1) / \(playlist.count)"
    }

    private func singlePhotoVC(for index: Int) -> SinglePhotoViewController {
        let item = playlist[index]
        let url = (item["url"] as? String) ?? ""
        let localPath = (item["localPath"] as? String) ?? ""
        return SinglePhotoViewController(index: index, urlString: url, localPath: localPath)
    }

    // MARK: - UIPageViewControllerDataSource
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let photoVC = viewController as? SinglePhotoViewController else { return nil }
        let prevIndex = photoVC.index - 1
        guard prevIndex >= 0 else { return nil }
        return singlePhotoVC(for: prevIndex)
    }

    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let photoVC = viewController as? SinglePhotoViewController else { return nil }
        let nextIndex = photoVC.index + 1
        guard nextIndex < playlist.count else { return nil }
        return singlePhotoVC(for: nextIndex)
    }

    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        if completed, let currentVC = pageViewController.viewControllers?.first as? SinglePhotoViewController {
            currentIndex = currentVC.index
            updateHeaderInfo(for: currentIndex)
        }
    }

    @objc private func onShareTapped() {
        guard currentIndex >= 0 && currentIndex < playlist.count else { return }
        let item = playlist[currentIndex]
        let localPath = item["localPath"] as? String ?? ""
        if !localPath.isEmpty && FileManager.default.fileExists(atPath: localPath) {
            let fileUrl = URL(fileURLWithPath: localPath)
            let avc = UIActivityViewController(activityItems: [fileUrl], applicationActivities: nil)
            present(avc, animated: true)
            return
        }
        guard let urlStr = item["url"] as? String, let url = URL(string: urlStr) else { return }
        var req = URLRequest(url: url)
        if !LocalProxy.shared.token.isEmpty && !url.isFileURL {
            req.setValue("Bearer " + LocalProxy.shared.token, forHTTPHeaderField: "Authorization")
        }
        URLSession.shared.dataTask(with: req) { [weak self] data, _, _ in
            guard let d = data, let img = UIImage(data: d) else { return }
            DispatchQueue.main.async {
                let avc = UIActivityViewController(activityItems: [img], applicationActivities: nil)
                self?.present(avc, animated: true)
            }
        }.resume()
    }

    @objc private func onCloseTapped() {
        dismiss(animated: true)
    }
}

class SinglePhotoViewController: UIViewController, UIScrollViewDelegate {
    let index: Int
    let urlString: String
    let localPath: String

    private var scrollView: UIScrollView!
    private var imageView: UIImageView!
    private var spinner: UIActivityIndicatorView!

    init(index: Int, urlString: String, localPath: String) {
        self.index = index
        self.urlString = urlString
        self.localPath = localPath
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear

        scrollView = UIScrollView(frame: view.bounds)
        scrollView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        scrollView.delegate = self
        scrollView.minimumZoomScale = 1.0
        scrollView.maximumZoomScale = 4.0
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        view.addSubview(scrollView)

        imageView = UIImageView(frame: scrollView.bounds)
        imageView.contentMode = .scaleAspectFit
        imageView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        imageView.isUserInteractionEnabled = true
        scrollView.addSubview(imageView)

        spinner = UIActivityIndicatorView(style: .large)
        spinner.color = .white
        spinner.center = view.center
        spinner.hidesWhenStopped = true
        view.addSubview(spinner)

        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(onDoubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        view.addGestureRecognizer(doubleTap)

        loadImage()
    }

    private func loadImage() {
        if !localPath.isEmpty && FileManager.default.fileExists(atPath: localPath) {
            if let img = UIImage(contentsOfFile: localPath) {
                imageView.image = img
                return
            }
        }
        guard let url = URL(string: urlString) else { return }
        spinner.startAnimating()

        var req = URLRequest(url: url)
        if !LocalProxy.shared.token.isEmpty && !url.isFileURL {
            req.setValue("Bearer " + LocalProxy.shared.token, forHTTPHeaderField: "Authorization")
        }

        URLSession.shared.dataTask(with: req) { [weak self] data, _, _ in
            DispatchQueue.main.async {
                self?.spinner.stopAnimating()
                if let d = data, let img = UIImage(data: d) {
                    self?.imageView.image = img
                }
            }
        }.resume()
    }

    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return imageView
    }

    @objc private func onDoubleTap(_ gesture: UITapGestureRecognizer) {
        if scrollView.zoomScale > 1.0 {
            scrollView.setZoomScale(1.0, animated: true)
        } else {
            let point = gesture.location(in: imageView)
            let rect = CGRect(x: point.x - 60, y: point.y - 60, width: 120, height: 120)
            scrollView.zoom(to: rect, animated: true)
        }
    }
}