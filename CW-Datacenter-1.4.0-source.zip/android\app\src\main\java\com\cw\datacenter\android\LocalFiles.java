package com.cw.datacenter.android;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.webkit.MimeTypeMap;

import org.json.JSONArray;
import org.json.JSONObject;

public class LocalFiles {

    public static Uri childUri(Uri tree, String docId) {
        try {
            String treeRoot = DocumentsContract.getTreeDocumentId(tree);
            if (docId.startsWith(treeRoot)) {
                return DocumentsContract.buildDocumentUriUsingTree(tree, docId);
            }
        } catch (Exception ignored) {}
        return DocumentsContract.buildDocumentUri(tree.getAuthority(), docId);
    }

    public static JSONObject list(ContentResolver cr, Uri tree, String docId) throws Exception {
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        JSONArray arr = new JSONArray();
        try (Cursor c = cr.query(childrenUri, new String[]{
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                        DocumentsContract.Document.COLUMN_SIZE,
                        DocumentsContract.Document.COLUMN_LAST_MODIFIED,
                        DocumentsContract.Document.COLUMN_MIME_TYPE },
                null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    String id = c.getString(0);
                    String name = c.getString(1);
                    JSONObject e = new JSONObject();
                    e.put("id", id);
                    e.put("name", name == null ? id : name);
                    e.put("size", c.isNull(2) ? 0L : c.getLong(2));
                    e.put("mtime", c.isNull(3) ? 0L : c.getLong(3));
                    String mime = c.getString(4);
                    boolean isDir = DocumentsContract.Document.MIME_TYPE_DIR.equals(mime);
                    e.put("dir", isDir);
                    e.put("mime", mime == null ? "" : mime);
                    arr.put(e);
                }
            }
        }
        JSONObject o = new JSONObject();
        o.put("entries", arr);
        o.put("parentId", docId);
        return o;
    }

    public static JSONObject listFs(java.io.File dir) throws Exception {
        JSONArray arr = new JSONArray();
        java.io.File[] files = dir.listFiles();
        if (files != null) {
            java.util.Arrays.sort(files, (a, b) -> {
                boolean ad = a.isDirectory(), bd = b.isDirectory();
                if (ad != bd) return ad ? -1 : 1;
                return a.getName().compareToIgnoreCase(b.getName());
            });
            for (java.io.File f : files) {
                String n = f.getName();
                if (n.startsWith(".")) continue;
                JSONObject e = new JSONObject();
                e.put("id", f.getAbsolutePath());
                e.put("name", n);
                e.put("dir", f.isDirectory());
                e.put("size", f.isDirectory() ? 0L : f.length());
                e.put("mtime", f.lastModified());
                e.put("mime", "");
                arr.put(e);
            }
        }
        JSONObject o = new JSONObject();
        o.put("entries", arr);
        o.put("parentId", dir.getAbsolutePath());
        return o;
    }

    static boolean fsAllowed(android.content.Context ctx) {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            try { return android.os.Environment.isExternalStorageManager(); }
            catch (Exception e) { return false; }
        }
        try {
            return ctx.checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE")
                    == android.content.pm.PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) { return false; }
    }

    /* Liệt kê đệ quy toàn bộ tệp trong 1 thư mục (phục vụ đồng bộ / dán).
     * Nếu root là 1 tệp duy nhất -> trả về chính tệp đó. */
    public static JSONObject deepList(java.io.File root, int limit) {
        JSONArray arr = new JSONArray();
        if (root != null) {
            if (root.isFile()) {
                try {
                    JSONObject e = new JSONObject();
                    e.put("rel", root.getName());
                    e.put("p", root.getAbsolutePath());
                    e.put("name", root.getName());
                    e.put("size", root.length());
                    e.put("mtime", root.lastModified());
                    arr.put(e);
                } catch (Exception ignored) {}
            } else if (root.isDirectory()) {
                walk(root, root, arr, limit);
            }
        }
        JSONObject o = new JSONObject();
        try {
            o.put("files", arr);
            o.put("truncated", arr.length() >= limit);
        } catch (Exception ignored) {}
        return o;
    }

    private static void walk(java.io.File base, java.io.File dir, JSONArray out, int limit) {
        try {
            if (out.length() >= limit) return;
            java.io.File[] files = dir.listFiles();
            if (files == null) return;
            for (java.io.File f : files) {
                if (out.length() >= limit) return;
                String n = f.getName();
                if (n.startsWith(".")) continue;
                if (f.isDirectory()) {
                    walk(base, f, out, limit);
                } else if (f.isFile()) {
                    try {
                        JSONObject e = new JSONObject();
                        e.put("rel", relativize(base, f));
                        e.put("p", f.getAbsolutePath());
                        e.put("name", n);
                        e.put("size", f.length());
                        e.put("mtime", f.lastModified());
                        out.put(e);
                    } catch (Exception ignored) {}
                }
            }
        } catch (Exception ignored) {}
    }

    public static String relativize(java.io.File base, java.io.File f) {
        try {
            String b = base.getCanonicalPath();
            String p = f.getCanonicalPath();
            if (p.startsWith(b)) {
                String rel = p.substring(b.length());
                if (rel.startsWith(java.io.File.separator)) rel = rel.substring(1);
                return rel.replace('\\', '/');
            }
        } catch (Exception ignored) {}
        return f.getName();
    }

    /* Sao chép/di chuyển mục giữa các thư mục trên thiết bị (đệ quy). */
    public static JSONObject moveItems(java.util.List<String> items, String toPath, boolean cut) {
        int okCount = 0;
        int failCount = 0;
        StringBuilder errs = new StringBuilder();
        java.io.File to = new java.io.File(toPath);
        for (String srcPath : items) {
            try {
                java.io.File src = new java.io.File(srcPath).getCanonicalFile();
                if (!src.exists()) { failCount++; continue; }
                java.io.File target = uniqueTarget(new java.io.File(to, src.getName()));
                if (cut && src.getCanonicalPath().startsWith(to.getCanonicalPath())) {
                    failCount++;
                    if (errs.length() > 0) errs.append("; ");
                    errs.append("Không chuyển vào chính nó: ").append(src.getName());
                    continue;
                }
                if (cut && src.renameTo(target)) { okCount++; continue; }
                copyTree(src, target);
                if (cut) deleteTree(src);
                okCount++;
            } catch (Exception e) {
                failCount++;
                if (errs.length() > 0) errs.append("; ");
                errs.append(srcPath).append(": ").append(e.getMessage());
            }
        }
        try {
            JSONObject r = new JSONObject();
            r.put("ok", failCount == 0);
            r.put("done", okCount);
            r.put("failed", failCount);
            if (errs.length() > 0) r.put("err", errs.toString());
            return r;
        } catch (Exception e) {
            JSONObject r = new JSONObject();
            try { r.put("ok", false); } catch (Exception ignored) {}
            return r;
        }
    }

    /* Xóa đệ quy tệp/thư mục (phục vụ "Cut" từ thiết bị lên máy chủ). */
    public static JSONObject deleteItems(java.util.List<String> items) {
        int okCount = 0, failCount = 0;
        for (String p : items) {
            try {
                java.io.File f = new java.io.File(p);
                if (!f.exists()) { okCount++; continue; }
                if (deleteTree(f)) okCount++; else failCount++;
            } catch (Exception e) { failCount++; }
        }
        try {
            JSONObject r = new JSONObject();
            r.put("ok", failCount == 0);
            r.put("done", okCount);
            r.put("failed", failCount);
            return r;
        } catch (Exception e) {
            JSONObject r = new JSONObject();
            try { r.put("ok", false); } catch (Exception ignored) {}
            return r;
        }
    }

    private static boolean deleteTree(java.io.File f) {
        if (f.isDirectory()) {
            java.io.File[] ch = f.listFiles();
            if (ch != null) for (java.io.File c : ch) deleteTree(c);
        }
        return f.delete();
    }

    private static void copyTree(java.io.File src, java.io.File dst) throws Exception {
        if (src.isDirectory()) {
            if (!dst.exists() && !dst.mkdirs()) throw new Exception("Không tạo được thư mục " + dst.getName());
            java.io.File[] ch = src.listFiles();
            if (ch == null) return;
            for (java.io.File c : ch) copyTree(c, new java.io.File(dst, c.getName()));
        } else {
            java.io.File parent = dst.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            try (java.io.FileInputStream in = new java.io.FileInputStream(src);
                 java.io.FileOutputStream out = new java.io.FileOutputStream(dst)) {
                byte[] buf = new byte[256 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            try { dst.setLastModified(src.lastModified()); } catch (Exception ignored) {}
        }
    }

    private static java.io.File uniqueTarget(java.io.File f) {
        if (!f.exists()) return f;
        String name = f.getName();
        String base = name;
        String ext = "";
        int i = name.lastIndexOf('.');
        if (i > 0 && !f.isDirectory()) { base = name.substring(0, i); ext = name.substring(i); }
        for (int k = 1; k < 10000; k++) {
            java.io.File cand = new java.io.File(f.getParentFile(), base + " (" + k + ")" + ext);
            if (!cand.exists()) return cand;
        }
        return new java.io.File(f.getParentFile(), name + "." + System.currentTimeMillis());
    }

    public static String guessMimeByName(String name, String mime) {
        if (mime != null && !mime.isEmpty()) return mime;
        String n = name == null ? "" : name.toLowerCase();
        int i = n.lastIndexOf('.');
        String ext = i >= 0 ? n.substring(i + 1) : "";
        String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return m != null ? m : "application/octet-stream";
    }
}
