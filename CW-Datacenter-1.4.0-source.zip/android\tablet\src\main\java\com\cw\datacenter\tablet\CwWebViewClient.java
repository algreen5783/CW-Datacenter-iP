package com.cw.datacenter.tablet;

import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class CwWebViewClient extends WebViewClient {

    private volatile String baseUrl;
    private volatile String token;

    void setAuth(String baseUrl, String token) {
        this.baseUrl = baseUrl;
        this.token = token;
    }

    @Override
    public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        String u = this.baseUrl;
        Uri rUri = request.getUrl();
        if (u == null || u.isEmpty() || rUri == null) return null;
        String url = rUri.toString();
        if (!url.startsWith(u)) return null;
        String path = rUri.getPath() == null ? "" : rUri.getPath();
        if (!path.startsWith("/api/")) return null;

        Map<String, String> hs = request.getRequestHeaders();

        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            WebResourceResponse pre = new WebResourceResponse("text/plain", null, new ByteArrayInputStream(new byte[0]));
            pre.setStatusCodeAndReasonPhrase(204, "No Content");
            Map<String, String> rh = new HashMap<>();
            putCors(rh, hs);
            pre.setResponseHeaders(rh);
            return pre;
        }

        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(120000);
            String tk = this.token;
            if (tk != null && !tk.isEmpty()) conn.setRequestProperty("Authorization", "Bearer " + tk);
            if (hs != null) {
                String range = hs.get("Range");
                if (range != null) conn.setRequestProperty("Range", range);
                String ifr = hs.get("If-Range");
                if (ifr != null) conn.setRequestProperty("If-Range", ifr);
            }
            int status = conn.getResponseCode();
            InputStream is = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
            if (is == null) is = conn.getInputStream();
            String ct = conn.getContentType();
            String mime = ct != null ? ct.split(";")[0].trim() : "application/octet-stream";
            String enc = (ct != null && ct.toLowerCase().contains("charset=")) ? "UTF-8" : null;
            WebResourceResponse resp = new WebResourceResponse(mime, enc, is);
            resp.setStatusCodeAndReasonPhrase(status, reasonPhrase(status));
            Map<String, String> rh = new HashMap<>();
            String cl = conn.getHeaderField("Content-Length");
            if (cl != null) rh.put("Content-Length", cl);
            String cr = conn.getHeaderField("Content-Range");
            if (cr != null) rh.put("Content-Range", cr);
            String lm = conn.getHeaderField("Last-Modified");
            if (lm != null) rh.put("Last-Modified", lm);
            String etag = conn.getHeaderField("ETag");
            if (etag != null) rh.put("ETag", etag);
            rh.put("Accept-Ranges", "bytes");
            putCors(rh, hs);
            resp.setResponseHeaders(rh);
            return resp;
        } catch (Exception e) {
            if (conn != null) conn.disconnect();
            return null;
        }
    }

    private static void putCors(Map<String, String> rh, Map<String, String> reqHeaders) {
        if (reqHeaders != null && reqHeaders.containsKey("Origin")) {
            rh.put("Access-Control-Allow-Origin", reqHeaders.get("Origin"));
            rh.put("Vary", "Origin");
        } else {
            rh.put("Access-Control-Allow-Origin", "*");
        }
        rh.put("Access-Control-Allow-Headers", "Authorization, Content-Type, Range, If-Range");
        rh.put("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        rh.put("Access-Control-Max-Age", "86400");
    }

    private static String reasonPhrase(int status) {
        switch (status) {
            case 200: return "OK";
            case 204: return "No Content";
            case 206: return "Partial Content";
            case 301: return "Moved Permanently";
            case 302: return "Found";
            case 304: return "Not Modified";
            case 400: return "Bad Request";
            case 401: return "Unauthorized";
            case 403: return "Forbidden";
            case 404: return "Not Found";
            case 409: return "Conflict";
            case 413: return "Payload Too Large";
            case 416: return "Range Not Satisfiable";
            case 429: return "Too Many Requests";
            case 500: return "Internal Server Error";
            case 503: return "Service Unavailable";
            default: return status < 400 ? "OK" : "Error";
        }
    }
}

