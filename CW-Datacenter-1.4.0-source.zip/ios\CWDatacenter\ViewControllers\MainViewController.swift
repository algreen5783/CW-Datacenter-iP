import UIKit
import WebKit
import Network

class MainViewController: UIViewController, WKNavigationDelegate, WKScriptMessageHandler, UIScrollViewDelegate {

    private var webView: WKWebView!
    private var isLoaded = false
    private var netBrowser: NWBrowser?

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .default
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.94, green: 0.96, blue: 1.0, alpha: 1.0)
        triggerLocalNetworkPermission()
        setupWebView()
        loadLocalApp()
    }

    private func triggerLocalNetworkPermission() {
        let params = NWParameters()
        params.includePeerToPeer = true
        let descriptor = NWBrowser.Descriptor.bonjour(type: "_http._tcp", domain: nil)
        netBrowser = NWBrowser(for: descriptor, using: params)
        netBrowser?.stateUpdateHandler = { _ in }
        netBrowser?.start(queue: .main)
    }

    override func viewSafeAreaInsetsDidChange() {
        super.viewSafeAreaInsetsDidChange()
        pushSafeAreaInsets()
    }

    private func setupWebView() {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        let userContent = WKUserContentController()
        userContent.add(self, name: "DC")

        // Comprehensive JS bridge helper matching Android Bridge API
        let bridgeJs = """
        window.DC = window.DC || {};
        window.DC.call = function(method, id, args) {
            window.webkit.messageHandlers.DC.postMessage({ method: method, id: id, args: args });
        };
        window.DC.getMeta = function() {
            return JSON.stringify({
                device: "iPhone",
                manufacturer: "Apple",
                brand: "Apple",
                model: "iPhone",
                ios: "iOS",
                platform: "ios"
            });
        };
        window.DC.getInsets = function() {
            return "47,34";
        };
        window.DC.loadKV = function(k) {
            try { return localStorage.getItem("cw_kv_" + k); } catch(e) { return null; }
        };
        window.DC.saveKV = function(k, v) {
            try { localStorage.setItem("cw_kv_" + k, v); } catch(e) {}
        };
        window.DC.removeKV = function(k) {
            try { localStorage.removeItem("cw_kv_" + k); } catch(e) {}
        };
        window.DC.toast = function(msg) {
            console.log("[CW_TOAST]", msg);
        };
        document.addEventListener('gesturestart', function(e) { e.preventDefault(); }, { passive: false });
        document.addEventListener('gesturechange', function(e) { e.preventDefault(); }, { passive: false });
        document.addEventListener('gestureend', function(e) { e.preventDefault(); }, { passive: false });
        document.addEventListener('dblclick', function(e) { e.preventDefault(); }, { passive: false });
        """
        let script = WKUserScript(source: bridgeJs, injectionTime: .atDocumentStart, forMainFrameOnly: true)
        userContent.addUserScript(script)
        config.userContentController = userContent

        webView = WKWebView(frame: view.bounds, configuration: config)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        webView.navigationDelegate = self
        webView.scrollView.delegate = self
        webView.scrollView.bounces = false
        webView.scrollView.pinchGestureRecognizer?.isEnabled = false
        webView.scrollView.maximumZoomScale = 1.0
        webView.scrollView.minimumZoomScale = 1.0
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.isOpaque = false
        webView.backgroundColor = .clear
        view.addSubview(webView)
    }

    // MARK: - UIScrollViewDelegate (Strictly Disable Zoom)
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return nil
    }

    private func loadLocalApp() {
        if let webDir = Bundle.main.url(forResource: "Web", withExtension: nil) {
            let indexUrl = webDir.appendingPathComponent("index.html")
            webView.loadFileURL(indexUrl, allowingReadAccessTo: webDir)
        } else if let indexUrl = Bundle.main.url(forResource: "index", withExtension: "html") {
            webView.loadFileURL(indexUrl, allowingReadAccessTo: indexUrl.deletingLastPathComponent())
        }
    }

    private func pushSafeAreaInsets() {
        let insets = view.safeAreaInsets
        let top = Int(insets.top)
        let bottom = Int(insets.bottom)
        let js = "window.DC && DC._insets && DC._insets(\(top), \(bottom));"
        webView?.evaluateJavaScript(js, completionHandler: nil)
    }

    // MARK: - WKNavigationDelegate
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        isLoaded = true
        pushSafeAreaInsets()
    }

    // MARK: - WKScriptMessageHandler
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "DC", let body = message.body as? [String: Any] else { return }
        let method = body["method"] as? String ?? ""
        let cbId = body["id"] as? String ?? ""
        let argsRaw = body["args"] as? String ?? "[]"

        var args: [Any] = []
        if let data = argsRaw.data(using: .utf8), let parsed = try? JSONSerialization.jsonObject(with: data) as? [Any] {
            args = parsed
        }

        handleNativeCall(method: method, cbId: cbId, args: args)
    }

    private func handleNativeCall(method: String, cbId: String, args: [Any]) {
        switch method {
        case "invoke":
            let httpMethod = args.indices.contains(0) ? (args[0] as? String ?? "GET") : "GET"
            var urlString = args.indices.contains(1) ? (args[1] as? String ?? "") : ""
            let headersJson = args.indices.contains(2) ? (args[2] as? String ?? "{}") : "{}"
            let bodyStr = args.indices.contains(3) ? (args[3] as? String) : nil

            urlString = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
            if !urlString.starts(with: "http://") && !urlString.starts(with: "https://") {
                urlString = "http://" + urlString
            }

            guard let url = URL(string: urlString) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"URL không hợp lệ: \(urlString)\"}")
                return
            }

            var request = URLRequest(url: url, timeoutInterval: 15)
            request.httpMethod = httpMethod
            if let headersData = headersJson.data(using: .utf8),
               let headers = try? JSONSerialization.jsonObject(with: headersData) as? [String: String] {
                for (k, v) in headers {
                    request.setValue(v, forHTTPHeaderField: k)
                }
            }
            if let bodyStr = bodyStr, !bodyStr.isEmpty, httpMethod != "GET" && httpMethod != "HEAD" {
                if request.value(forHTTPHeaderField: "Content-Type") == nil {
                    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                }
                request.httpBody = bodyStr.data(using: .utf8)
            }

            let sessionConfig = URLSessionConfiguration.default
            sessionConfig.timeoutIntervalForRequest = 15
            sessionConfig.timeoutIntervalForResource = 30
            sessionConfig.requestCachePolicy = .reloadIgnoringLocalCacheData
            let session = URLSession(configuration: sessionConfig)

            session.dataTask(with: request) { [weak self] data, response, error in
                if let error = error {
                    let errMsg = error.localizedDescription
                    let payload: [String: Any] = [
                        "status": 0,
                        "text": "{\"error\":\"\(errMsg)\"}",
                        "err": errMsg
                    ]
                    if let resData = try? JSONSerialization.data(withJSONObject: payload),
                       let resJson = String(data: resData, encoding: .utf8) {
                        self?.callback(cbId: cbId, ok: false, json: resJson)
                    } else {
                        self?.callback(cbId: cbId, ok: false, json: "{\"err\":\"\(errMsg)\"}")
                    }
                    return
                }
                let status = (response as? HTTPURLResponse)?.statusCode ?? 200
                let text = data.flatMap { String(data: $0, encoding: .utf8) } ?? ""
                
                let payload: [String: Any] = [
                    "status": status,
                    "text": text
                ]
                if let resData = try? JSONSerialization.data(withJSONObject: payload),
                   let resJson = String(data: resData, encoding: .utf8) {
                    self?.callback(cbId: cbId, ok: true, json: resJson)
                } else {
                    self?.callback(cbId: cbId, ok: true, json: "{\"status\":\(status),\"text\":\"\"}")
                }
            }.resume()

        case "discover":
            performLanDiscovery { [weak self] hosts in
                let payload: [String: Any] = ["hosts": hosts]
                if let resData = try? JSONSerialization.data(withJSONObject: payload),
                   let resJson = String(data: resData, encoding: .utf8) {
                    self?.callback(cbId: cbId, ok: true, json: resJson)
                } else {
                    self?.callback(cbId: cbId, ok: true, json: "{\"hosts\":[]}")
                }
            }

        case "toast":
            let msg = args.first as? String ?? ""
            DispatchQueue.main.async { [weak self] in
                let alert = UIAlertController(title: nil, message: msg, preferredStyle: .alert)
                self?.present(alert, animated: true)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    alert.dismiss(animated: true)
                }
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "setSession":
            let baseUrl = args.indices.contains(0) ? (args[0] as? String ?? "") : ""
            let token = args.indices.contains(1) ? (args[1] as? String ?? "") : ""
            LocalProxy.shared.setAuth(baseUrl: baseUrl, token: token)
            UserDefaults.standard.set(baseUrl, forKey: "cw_base_url")
            UserDefaults.standard.set(token, forKey: "cw_token")
            callback(cbId: cbId, ok: true, json: "{}")

        case "proxyUrl":
            let rel = args.indices.contains(0) ? (args[0] as? String ?? "") : ""
            let pool = args.indices.contains(1) ? (args[1] as? String) : nil
            let isVideo = args.indices.contains(2) ? (args[2] as? Bool ?? false) : false
            let pUrl = LocalProxy.shared.urlFor(relEncoded: rel, poolEncoded: pool, video: isVideo)
            callback(cbId: cbId, ok: true, json: "\"\(pUrl)\"")

        case "thumbUrl":
            let rel = args.indices.contains(0) ? (args[0] as? String ?? "") : ""
            let pool = args.indices.contains(1) ? (args[1] as? String) : nil
            let tUrl = LocalProxy.shared.thumbUrl(relEncoded: rel, poolEncoded: pool)
            callback(cbId: cbId, ok: true, json: "\"\(tUrl)\"")

        case "getInsets":
            let insets = view.safeAreaInsets
            callback(cbId: cbId, ok: true, json: "\"\(Int(insets.top)),\(Int(insets.bottom))\"")

        case "localFsStatus":
            callback(cbId: cbId, ok: true, json: "{\"ok\":true}")

        case "localFsInfo":
            callback(cbId: cbId, ok: true, json: "{\"free\":50000000000,\"total\":128000000000}")

        case "playVideo":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let url = params["url"] as? String ?? ""
            let name = params["name"] as? String ?? ""
            let playlist = params["playlist"] as? [[String: Any]] ?? []
            let startPos = params["startPos"] as? Int64 ?? -1

            DispatchQueue.main.async { [weak self] in
                let playerVc = PlayerViewController(url: url, name: name, playlist: playlist, startPos: startPos)
                playerVc.modalPresentationStyle = .fullScreen
                self?.present(playerVc, animated: true)
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "openPdf":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let url = params["url"] as? String ?? ""
            let name = params["name"] as? String ?? "Tài liệu PDF"

            DispatchQueue.main.async { [weak self] in
                let pdfVc = PdfViewController(url: url, titleText: name)
                let nav = UINavigationController(rootViewController: pdfVc)
                nav.modalPresentationStyle = .fullScreen
                self?.present(nav, animated: true)
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "openPhoto":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let url = params["url"] as? String ?? ""
            let name = params["name"] as? String ?? "Hình ảnh"

            DispatchQueue.main.async { [weak self] in
                let imgVc = ImageViewController(url: url, name: name)
                imgVc.modalPresentationStyle = .fullScreen
                self?.present(imgVc, animated: true)
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "copyClipboard":
            let text = args.first as? String ?? ""
            UIPasteboard.general.string = text
            callback(cbId: cbId, ok: true, json: "{}")

        case "getVideoProgress":
            let key = args.first as? String ?? ""
            let pos = UserDefaults.standard.integer(forKey: "vpos_" + key)
            callback(cbId: cbId, ok: true, json: "{\"pos\":\(pos)}")

        case "clearVideoProgress":
            let key = args.first as? String ?? ""
            UserDefaults.standard.removeObject(forKey: "vpos_" + key)
            callback(cbId: cbId, ok: true, json: "{}")

        case "exitApp":
            UIControl().sendAction(#selector(NSXPCConnection.suspend), to: UIApplication.shared, for: nil)
            callback(cbId: cbId, ok: true, json: "{}")

        default:
            callback(cbId: cbId, ok: true, json: "{}")
        }
    }

    private func parseJsonObject(_ obj: Any?) -> [String: Any]? {
        guard let str = obj as? String, let data = str.data(using: .utf8) else { return nil }
        return (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
    }

    private func callback(cbId: String, ok: Bool, json: String) {
        guard !cbId.isEmpty else { return }
        DispatchQueue.main.async { [weak self] in
            if let data = json.data(using: .utf8),
               let obj = try? JSONSerialization.jsonObject(with: data) {
                let payload: [String: Any] = ["id": cbId, "ok": ok, "data": obj]
                if let jsData = try? JSONSerialization.data(withJSONObject: payload),
                   let jsStr = String(data: jsData, encoding: .utf8) {
                    let js = "window.DC && DC._cbObj && DC._cbObj(\(jsStr));"
                    self?.webView?.evaluateJavaScript(js, completionHandler: nil)
                    return
                }
            }
            if let jsData = try? JSONSerialization.data(withJSONObject: [json]),
               let jsStr = String(data: jsData, encoding: .utf8) {
                let inner = String(jsStr.dropFirst().dropLast())
                let js = "window.DC && DC._cb && DC._cb('\(cbId)', \(ok), \(inner));"
                self?.webView?.evaluateJavaScript(js, completionHandler: nil)
            }
        }
    }

    // MARK: - LAN Discovery
    private func performLanDiscovery(completion: @escaping ([[String: Any]]) -> Void) {
        var foundHosts: [[String: Any]] = []
        let lock = NSLock()
        
        var prefixes: Set<String> = []
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        if getifaddrs(&ifaddr) == 0 {
            var ptr = ifaddr
            while ptr != nil {
                let flags = Int32(ptr!.pointee.ifa_flags)
                let addr = ptr!.pointee.ifa_addr.pointee
                if (flags & (IFF_UP|IFF_RUNNING|IFF_LOOPBACK)) == (IFF_UP|IFF_RUNNING) {
                    if addr.sa_family == UInt8(AF_INET) {
                        var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                        if getnameinfo(ptr!.pointee.ifa_addr, socklen_t(addr.sa_len), &hostname, socklen_t(hostname.count), nil, 0, NI_NUMERICHOST) == 0 {
                            let ip = String(cString: hostname)
                            if !ip.starts(with: "127.") {
                                let parts = ip.split(separator: ".")
                                if parts.count == 4 {
                                    prefixes.insert("\(parts[0]).\(parts[1]).\(parts[2]).")
                                }
                            }
                        }
                    }
                }
                ptr = ptr!.pointee.ifa_next
            }
            freeifaddrs(ifaddr)
        }
        
        if prefixes.isEmpty {
            prefixes.insert("192.168.1.")
            prefixes.insert("192.168.0.")
            prefixes.insert("192.168.2.")
            prefixes.insert("192.168.31.")
            prefixes.insert("172.20.10.")
            prefixes.insert("10.0.0.")
        }
        
        let group = DispatchGroup()
        
        // 1. UDP Broadcast Discovery to Port 46631
        group.enter()
        DispatchQueue.global(qos: .userInitiated).async {
            let sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)
            if sock >= 0 {
                var broadcastEnable: Int32 = 1
                setsockopt(sock, SOL_SOCKET, SO_BROADCAST, &broadcastEnable, socklen_t(MemoryLayout<Int32>.size))
                var tv = timeval(tv_sec: 1, tv_usec: 200000)
                setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))
                
                var addr = sockaddr_in()
                addr.sin_family = sa_family_t(AF_INET)
                addr.sin_port = in_port_t(46631).bigEndian
                addr.sin_addr.s_addr = inet_addr("255.255.255.255")
                
                let msg = "CW-DISCOVER"
                if let msgData = msg.data(using: .utf8) {
                    msgData.withUnsafeBytes { rawBuffer in
                        withUnsafePointer(to: &addr) { addrPtr in
                            addrPtr.withMemoryRebound(to: sockaddr.self, capacity: 1) { saPtr in
                                _ = sendto(sock, rawBuffer.baseAddress, rawBuffer.count, 0, saPtr, socklen_t(MemoryLayout<sockaddr_in>.size))
                            }
                        }
                    }
                }
                
                var recvBuf = [UInt8](repeating: 0, count: 2048)
                var srcAddr = sockaddr_in()
                var srcLen = socklen_t(MemoryLayout<sockaddr_in>.size)
                
                let deadline = Date().addingTimeInterval(1.2)
                while Date() < deadline {
                    let bytesRead = withUnsafeMutablePointer(to: &srcAddr) { srcPtr in
                        srcPtr.withMemoryRebound(to: sockaddr.self, capacity: 1) { saPtr in
                            recvfrom(sock, &recvBuf, recvBuf.count, 0, saPtr, &srcLen)
                        }
                    }
                    if bytesRead > 0 {
                        let fromIp = String(cString: inet_ntoa(srcAddr.sin_addr))
                        if let data = String(bytes: recvBuf[0..<bytesRead], encoding: .utf8)?.data(using: .utf8),
                           let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] {
                            let hostName = (obj["name"] as? String) ?? (obj["host"] as? String) ?? fromIp
                            let port = (obj["port"] as? Int) ?? 8080
                            let hostObj: [String: Any] = [
                                "ip": fromIp,
                                "port": port,
                                "host": hostName,
                                "name": hostName,
                                "via": "lan"
                            ]
                            lock.lock()
                            if !foundHosts.contains(where: { ($0["ip"] as? String) == fromIp && ($0["port"] as? Int) == port }) {
                                foundHosts.append(hostObj)
                            }
                            lock.unlock()
                        }
                    } else {
                        break
                    }
                }
                close(sock)
            }
            group.leave()
        }
        
        // 2. Parallel HTTP Subnet Scanner
        let sessionConfig = URLSessionConfiguration.ephemeral
        sessionConfig.timeoutIntervalForRequest = 1.8
        sessionConfig.timeoutIntervalForResource = 1.8
        let scanSession = URLSession(configuration: sessionConfig)
        
        for prefix in prefixes {
            for i in 1...254 {
                let targetIp = "\(prefix)\(i)"
                for port in [8080, 8081] {
                    guard let url = URL(string: "http://\(targetIp):\(port)/api/ping") else { continue }
                    group.enter()
                    scanSession.dataTask(with: url) { data, response, error in
                        defer { group.leave() }
                        guard let data = data,
                              let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else { return }
                        
                        let isCwHost = (obj["app"] as? String == "cw-datacenter") ||
                                       (obj["ok"] as? Bool == true && (obj["via"] != nil || obj["host"] != nil || obj["version"] != nil))
                        guard isCwHost else { return }
                        
                        let hostName = (obj["name"] as? String) ?? (obj["host"] as? String) ?? targetIp
                        let p = (obj["port"] as? Int) ?? port
                        let hostObj: [String: Any] = [
                            "ip": targetIp,
                            "port": p,
                            "host": hostName,
                            "name": hostName,
                            "via": "lan"
                        ]
                        lock.lock()
                        if !foundHosts.contains(where: { ($0["ip"] as? String) == targetIp && ($0["port"] as? Int) == p }) {
                            foundHosts.append(hostObj)
                        }
                        lock.unlock()
                    }.resume()
                }
            }
        }
        
        group.notify(queue: .main) {
            completion(foundHosts)
        }
    }
}