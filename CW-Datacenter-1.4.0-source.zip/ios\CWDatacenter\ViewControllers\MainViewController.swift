import UIKit
import WebKit

class MainViewController: UIViewController, WKNavigationDelegate, WKScriptMessageHandler {

    private var webView: WKWebView!
    private var isLoaded = false

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .default
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.94, green: 0.96, blue: 1.0, alpha: 1.0)
        setupWebView()
        loadLocalApp()
    }

    override func viewSafeAreaInsetsDidChange() {
        super.viewSafeAreaInsetsDidChange()
        pushSafeAreaInsets()
    }

    private func setupWebView() {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        let userContent = WKUserContentController()
        userContent.add(self, name: "DC")

        // Comprehensive JS bridge helper matching Android Bridge API
        let bridgeJs = """
        window.DC = window.DC || {};
        window.DC.call = function(method, id, args) {
            window.webkit.messageHandlers.DC.postMessage({ method: method, id: id, args: args });
        };
        window.DC.getMeta = function() {
            return JSON.stringify({
                device: "iPhone",
                manufacturer: "Apple",
                brand: "Apple",
                model: "iPhone",
                ios: "iOS",
                platform: "ios"
            });
        };
        window.DC.getInsets = function() {
            return "47,34";
        };
        window.DC.loadKV = function(k) {
            try { return localStorage.getItem("cw_kv_" + k); } catch(e) { return null; }
        };
        window.DC.saveKV = function(k, v) {
            try { localStorage.setItem("cw_kv_" + k, v); } catch(e) {}
        };
        window.DC.removeKV = function(k) {
            try { localStorage.removeItem("cw_kv_" + k); } catch(e) {}
        };
        window.DC.toast = function(msg) {
            console.log("[CW_TOAST]", msg);
        };
        """
        let script = WKUserScript(source: bridgeJs, injectionTime: .atDocumentStart, forMainFrameOnly: true)
        userContent.addUserScript(script)
        config.userContentController = userContent

        webView = WKWebView(frame: view.bounds, configuration: config)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        webView.navigationDelegate = self
        webView.scrollView.bounces = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.isOpaque = false
        webView.backgroundColor = .clear
        view.addSubview(webView)
    }

    private func loadLocalApp() {
        if let webDir = Bundle.main.url(forResource: "Web", withExtension: nil) {
            let indexUrl = webDir.appendingPathComponent("index.html")
            webView.loadFileURL(indexUrl, allowingReadAccessTo: webDir)
        } else if let indexUrl = Bundle.main.url(forResource: "index", withExtension: "html") {
            webView.loadFileURL(indexUrl, allowingReadAccessTo: indexUrl.deletingLastPathComponent())
        }
    }

    private func pushSafeAreaInsets() {
        let insets = view.safeAreaInsets
        let top = Int(insets.top)
        let bottom = Int(insets.bottom)
        let js = "window.DC && DC._insets && DC._insets(\(top), \(bottom));"
        webView?.evaluateJavaScript(js, completionHandler: nil)
    }

    // MARK: - WKNavigationDelegate
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        isLoaded = true
        pushSafeAreaInsets()
    }

    // MARK: - WKScriptMessageHandler
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "DC", let body = message.body as? [String: Any] else { return }
        let method = body["method"] as? String ?? ""
        let cbId = body["id"] as? String ?? ""
        let argsRaw = body["args"] as? String ?? "[]"

        var args: [Any] = []
        if let data = argsRaw.data(using: .utf8), let parsed = try? JSONSerialization.jsonObject(with: data) as? [Any] {
            args = parsed
        }

        handleNativeCall(method: method, cbId: cbId, args: args)
    }

    private func handleNativeCall(method: String, cbId: String, args: [Any]) {
        switch method {
        case "invoke":
            let httpMethod = args.indices.contains(0) ? (args[0] as? String ?? "GET") : "GET"
            let urlString = args.indices.contains(1) ? (args[1] as? String ?? "") : ""
            let headersJson = args.indices.contains(2) ? (args[2] as? String ?? "{}") : "{}"
            let bodyStr = args.indices.contains(3) ? (args[3] as? String) : nil

            guard let url = URL(string: urlString) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"URL không hợp lệ\"}")
                return
            }

            var request = URLRequest(url: url, timeoutInterval: 12)
            request.httpMethod = httpMethod
            if let headersData = headersJson.data(using: .utf8),
               let headers = try? JSONSerialization.jsonObject(with: headersData) as? [String: String] {
                for (k, v) in headers {
                    request.setValue(v, forHTTPHeaderField: k)
                }
            }
            if let bodyStr = bodyStr, !bodyStr.isEmpty, httpMethod != "GET" && httpMethod != "HEAD" {
                request.httpBody = bodyStr.data(using: .utf8)
            }

            URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
                if let error = error {
                    self?.callback(cbId: cbId, ok: false, json: "{\"err\":\"\(error.localizedDescription)\"}")
                    return
                }
                let status = (response as? HTTPURLResponse)?.statusCode ?? 200
                let text = data.flatMap { String(data: $0, encoding: .utf8) } ?? ""
                let ok = status >= 200 && status < 400
                
                let payload: [String: Any] = [
                    "status": status,
                    "text": text,
                    "ok": ok
                ]
                if let resData = try? JSONSerialization.data(withJSONObject: payload),
                   let resJson = String(data: resData, encoding: .utf8) {
                    self?.callback(cbId: cbId, ok: ok, json: resJson)
                } else {
                    self?.callback(cbId: cbId, ok: ok, json: "{\"status\":\(status),\"text\":\"\(text)\"}")
                }
            }.resume()

        case "discover":
            DispatchQueue.global().asyncAfter(deadline: .now() + 1.2) { [weak self] in
                self?.callback(cbId: cbId, ok: true, json: "{\"hosts\":[]}")
            }

        case "toast":
            let msg = args.first as? String ?? ""
            DispatchQueue.main.async { [weak self] in
                let alert = UIAlertController(title: nil, message: msg, preferredStyle: .alert)
                self?.present(alert, animated: true)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    alert.dismiss(animated: true)
                }
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "setSession":
            let baseUrl = args.indices.contains(0) ? (args[0] as? String ?? "") : ""
            let token = args.indices.contains(1) ? (args[1] as? String ?? "") : ""
            LocalProxy.shared.setAuth(baseUrl: baseUrl, token: token)
            UserDefaults.standard.set(baseUrl, forKey: "cw_base_url")
            UserDefaults.standard.set(token, forKey: "cw_token")
            callback(cbId: cbId, ok: true, json: "{}")

        case "proxyUrl":
            let rel = args.indices.contains(0) ? (args[0] as? String ?? "") : ""
            let pool = args.indices.contains(1) ? (args[1] as? String) : nil
            let isVideo = args.indices.contains(2) ? (args[2] as? Bool ?? false) : false
            let pUrl = LocalProxy.shared.urlFor(relEncoded: rel, poolEncoded: pool, video: isVideo)
            callback(cbId: cbId, ok: true, json: "\"\(pUrl)\"")

        case "thumbUrl":
            let rel = args.indices.contains(0) ? (args[0] as? String ?? "") : ""
            let pool = args.indices.contains(1) ? (args[1] as? String) : nil
            let tUrl = LocalProxy.shared.thumbUrl(relEncoded: rel, poolEncoded: pool)
            callback(cbId: cbId, ok: true, json: "\"\(tUrl)\"")

        case "getInsets":
            let insets = view.safeAreaInsets
            callback(cbId: cbId, ok: true, json: "\"\(Int(insets.top)),\(Int(insets.bottom))\"")

        case "localFsStatus":
            callback(cbId: cbId, ok: true, json: "{\"ok\":true}")

        case "localFsInfo":
            callback(cbId: cbId, ok: true, json: "{\"free\":50000000000,\"total\":128000000000}")

        case "playVideo":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let url = params["url"] as? String ?? ""
            let name = params["name"] as? String ?? ""
            let playlist = params["playlist"] as? [[String: Any]] ?? []
            let startPos = params["startPos"] as? Int64 ?? -1

            DispatchQueue.main.async { [weak self] in
                let playerVc = PlayerViewController(url: url, name: name, playlist: playlist, startPos: startPos)
                playerVc.modalPresentationStyle = .fullScreen
                self?.present(playerVc, animated: true)
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "openPdf":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let url = params["url"] as? String ?? ""
            let name = params["name"] as? String ?? "Tài liệu PDF"

            DispatchQueue.main.async { [weak self] in
                let pdfVc = PdfViewController(url: url, titleText: name)
                let nav = UINavigationController(rootViewController: pdfVc)
                nav.modalPresentationStyle = .fullScreen
                self?.present(nav, animated: true)
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "openPhoto":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let url = params["url"] as? String ?? ""
            let name = params["name"] as? String ?? "Hình ảnh"

            DispatchQueue.main.async { [weak self] in
                let imgVc = ImageViewController(url: url, name: name)
                imgVc.modalPresentationStyle = .fullScreen
                self?.present(imgVc, animated: true)
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "copyClipboard":
            let text = args.first as? String ?? ""
            UIPasteboard.general.string = text
            callback(cbId: cbId, ok: true, json: "{}")

        case "getVideoProgress":
            let key = args.first as? String ?? ""
            let pos = UserDefaults.standard.integer(forKey: "vpos_" + key)
            callback(cbId: cbId, ok: true, json: "{\"pos\":\(pos)}")

        case "clearVideoProgress":
            let key = args.first as? String ?? ""
            UserDefaults.standard.removeObject(forKey: "vpos_" + key)
            callback(cbId: cbId, ok: true, json: "{}")

        case "exitApp":
            UIControl().sendAction(#selector(NSXPCConnection.suspend), to: UIApplication.shared, for: nil)
            callback(cbId: cbId, ok: true, json: "{}")

        default:
            callback(cbId: cbId, ok: true, json: "{}")
        }
    }

    private func parseJsonObject(_ obj: Any?) -> [String: Any]? {
        guard let str = obj as? String, let data = str.data(using: .utf8) else { return nil }
        return (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
    }

    private func callback(cbId: String, ok: Bool, json: String) {
        guard !cbId.isEmpty else { return }
        DispatchQueue.main.async { [weak self] in
            let escaped = json.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "'", with: "\\'")
            let js = "window.DC && DC._cb && DC._cb('\(cbId)', \(ok), '\(escaped)');"
            self?.webView?.evaluateJavaScript(js, completionHandler: nil)
        }
    }
}