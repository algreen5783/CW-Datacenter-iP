package com.cw.datacenter.android;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Bridge {

    public interface IntentStarter {
        int start(Intent intent, MainActivity.ActivityResultCallback callback);
    }

    private final MainActivity activity;
    private final WebView webView;
    private final Handler main;
    private final IntentStarter starter;
    private final TransferManager transfers;
    private final SharedPreferences prefs;
    private final ExecutorService io = Executors.newCachedThreadPool();
    private final java.util.function.Consumer<String> eventSink = this::postEvent;

    private volatile boolean canGoBack = false;
    private volatile CwWebViewClient cvClient;
    private final LocalProxy proxy;

    Bridge(MainActivity activity, WebView webView, Handler main, IntentStarter starter) {
        this.activity = activity;
        this.webView = webView;
        this.main = main;
        this.starter = starter;
        this.prefs = activity.getSharedPreferences("cw-datacenter", android.content.Context.MODE_PRIVATE);
        this.transfers = TransferManager.get(activity.getApplicationContext());
        this.transfers.addSink(eventSink);
        this.proxy = this.transfers.proxy();
    }

    void setWebViewClient(CwWebViewClient client) {
        this.cvClient = client;
    }

    /* ---------- Báo insets thanh hệ thống cho JS (đếm px -> css px) ---------- */
    void pushInsets(int topPx, int bottomPx) {
        float d = activity.getResources().getDisplayMetrics().density;
        if (d <= 0) d = 1f;
        int top = Math.round(topPx / d);
        int bottom = Math.round(bottomPx / d);
        postJs("DC._insets && DC._insets(" + top + "," + bottom + ")");
    }

    @JavascriptInterface
    public String getInsets() {
        float d = activity.getResources().getDisplayMetrics().density;
        if (d <= 0) d = 1f;
        int top = Math.round(activity.topInsetPx() / d);
        int bottom = Math.round(activity.bottomInsetPx() / d);
        return top + "," + bottom;
    }

    /* ---------- Session auth cho WebView interceptor + proxy + native player ---------- */
    @SuppressLint("JavascriptInterface")
    @JavascriptInterface
    public void setSession(String baseUrl, String token) {
        if (cvClient != null) cvClient.setAuth(baseUrl, token);
        proxy.setAuth(baseUrl, token);
        try { prefs.edit().putString("base_url", baseUrl == null ? "" : baseUrl).putString("player_token", token == null ? "" : token).apply(); } catch (Exception ignored) {}
    }

    /* ---------- URL proxy cục bộ (127.0.0.1) để media seek mượt ---------- */
    @JavascriptInterface
    public String proxyUrl(String relEncoded, String poolEncoded, boolean video) {
        return proxy.urlFor(relEncoded, poolEncoded, video);
    }

    /* ---------- URL proxy cho thumbnail (gắn token, cache 1 tuần, ETag) ---------- */
    @JavascriptInterface
    public String thumbUrl(String relEncoded, String poolEncoded) {
        return proxy.thumbUrl(relEncoded, poolEncoded);
    }

    /* ---------- Chọn thư mục lưu bằng SAF, giữ quyền lâu dài ---------- */
    void pickFolder(final String cbId) {
        main.post(() -> {
            Intent intent = new Intent(android.content.Intent.ACTION_OPEN_DOCUMENT_TREE);
            starter.start(intent, (resultCode, data) -> {
                if (resultCode == android.app.Activity.RESULT_OK && data != null && data.getData() != null) {
                    Uri tree = data.getData();
                    int flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION | android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
                    try { activity.getContentResolver().takePersistableUriPermission(tree, flags); }
                    catch (SecurityException ignored) {}
                    JSONObject o = new JSONObject();
                    try {
                        o.put("treeUri", tree.toString());
                        o.put("name", treeDisplayName(tree));
                        resolve(cbId, true, o.toString());
                        return;
                    } catch (Exception ignored) {}
                }
                resolve(cbId, false, "{\"err\":\"cancelled\"}");
            });
        });
    }

    private String treeDisplayName(Uri tree) {
        try {
            String docId = android.provider.DocumentsContract.getTreeDocumentId(tree);
            if (docId == null) return "";
            String docName = docId.contains("/") ? docId.substring(docId.lastIndexOf('/') + 1) : docId;
            Uri docUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, docId);
            try (android.database.Cursor c = activity.getContentResolver().query(docUri,
                    new String[]{ android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME }, null, null, null)) {
                if (c != null && c.moveToFirst()) docName = c.getString(0);
            }
            return docName == null ? "" : docName;
        } catch (Exception e) {
            return "";
        }
    }

    void shutdown() {
        transfers.removeSink(eventSink);
        io.shutdownNow();
    }

    /* ---------- JS -> native (sync) ---------- */

    @JavascriptInterface
    public String getMeta() {
        try {
            JSONObject o = new JSONObject();
            o.put("appVersion", "1.1.0");
            o.put("android", Build.VERSION.RELEASE);
            o.put("sdk", Build.VERSION.SDK_INT);
            o.put("device", Build.MODEL);
            o.put("manufacturer", Build.MANUFACTURER);
            o.put("ip", localIp());
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    @JavascriptInterface
    public String loadKV(String key) {
        return prefs.getString(key, null);
    }

    @JavascriptInterface
    public void saveKV(String key, String value) {
        prefs.edit().putString(key, value).apply();
    }

    @JavascriptInterface
    public void removeKV(String key) {
        prefs.edit().remove(key).apply();
    }

    @JavascriptInterface
    public void setCanGoBack(boolean v) {
        canGoBack = v;
    }

    @JavascriptInterface
    public void toast(final String msg) {
        main.post(() -> Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show());
    }

    /* ---------- JS -> native (async, gom 1 mối) ----------
     * Toàn bộ method bất đồng bộ chỉ đi qua DC.call(tên_method, id, json_args).
     * Native tự dispatch theo tên; tên lạ -> trả lỗi tiếng Việt rõ ràng
     * thay vì "Method not found". */
    @JavascriptInterface
    public void call(final String name, final String cbId, final String argsJson) {
        String[] a;
        try {
            JSONArray arr = new JSONArray(argsJson == null || argsJson.isEmpty() ? "[]" : argsJson);
            a = new String[arr.length()];
            for (int i = 0; i < arr.length(); i++) {
                a[i] = arr.isNull(i) ? "" : String.valueOf(arr.get(i));
            }
        } catch (Exception e) {
            resolve(cbId, false, "{\"err\":\"Tham số gọi cầu nối không hợp lệ.\"}");
            return;
        }
        String m1 = a.length > 0 ? a[0] : "";
        String m2 = a.length > 1 ? a[1] : "";
        String m3 = a.length > 2 ? a[2] : "";
        String m4 = a.length > 3 ? a[3] : "";
        switch (name == null ? "" : name) {
            case "invoke": invoke(cbId, m1, m2, m3, m4); return;
            case "discover": discover(cbId, m1); return;
            case "pickFiles": pickFiles(cbId); return;
            case "upload": upload(cbId, m1); return;
            case "download": download(cbId, m1); return;
            case "cancel": cancel(cbId, m1); return;
            case "openFile": openFile(cbId, m1); return;
            case "openPdf": openPdf(cbId, m1); return;
            case "playVideo": playVideo(cbId, m1); return;
            case "getLocalIp": getLocalIp(cbId); return;
            case "pickFolder": pickFolder(cbId); return;
            case "localList": localList(cbId, m1); return;
            case "localOpen": localOpen(cbId, m1); return;
            case "openTree": openTree(cbId, m1); return;
            case "openDownloads": openDownloads(cbId, m1); return;
            case "localDownload": localDownload(cbId, m1); return;
            case "localFsStatus": localFsStatus(cbId); return;
            case "localFsInfo": localFsInfo(cbId, m1); return;
            case "requestLocalFsAccess": requestLocalFsAccess(cbId); return;
            case "localFsList": localFsList(cbId, m1); return;
            case "localFsOpen": localFsOpen(cbId, m1); return;
            case "localFsDownload": localFsDownload(cbId, m1); return;
            case "localFsEnsure": localFsEnsure(cbId, m1); return;
            case "localFsDeepList": localFsDeepList(cbId, m1); return;
            case "localFsMove": localFsMove(cbId, m1); return;
            case "localFsDelete": localFsDelete(cbId, m1); return;
            case "openPhoto": openPhoto(cbId, m1); return;
            case "copyClipboard": copyClipboard(cbId, m1); return;
            case "localFsMkdir": localFsMkdir(cbId, m1); return;
            case "exitApp": activity.finish(); return;
            case "getVideoProgress": getVideoProgress(cbId, m1); return;
            case "clearVideoProgress": clearVideoProgress(cbId, m1); return;
            case "showKeyboard": showKeyboard(cbId); return;
            case "hideKeyboard": hideKeyboard(cbId); return;
            case "clearCache": clearCache(cbId); return;
            case "getOfflineVideos": getOfflineVideos(cbId); return;
            case "deleteOfflineVideo": deleteOfflineVideo(cbId, m1); return;
            case "clearAllOfflineVideos": clearAllOfflineVideos(cbId); return;
            case "startOfflinePreload": startOfflinePreload(cbId, m1); return;
            default:
                resolve(cbId, false, "{\"err\":\"Không tìm thấy phương thức \\\""
                        + esc(name == null ? "" : name)
                        + "\\\" trong APK này. Hãy gỡ và cài lại bản mới.\"}");
        }
    }

    void clearCache(final String cbId) {
        main.post(() -> {
            try {
                if (webView != null) {
                    webView.clearCache(true);
                }
                io.execute(() -> {
                    try {
                        File cacheDir = activity.getCacheDir();
                        if (cacheDir != null && cacheDir.isDirectory()) {
                            deleteDirContents(cacheDir);
                        }
                    } catch (Exception ignored) {}
                    resolve(cbId, true, "{\"ok\":true}");
                });
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(e.getMessage()) + "\"}");
            }
        });
    }

    private void deleteDirContents(File dir) {
        if (dir == null || !dir.isDirectory()) return;
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory()) deleteDirContents(f);
            try { f.delete(); } catch (Exception ignored) {}
        }
    }

    /* ---------- JS -> native (async, callback id) ---------- */

    void invoke(final String cbId, final String method, final String url, final String headersJson, final String body) {
        io.execute(() -> {
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setRequestMethod(method == null ? "GET" : method.toUpperCase());
                conn.setConnectTimeout(8000);
                conn.setReadTimeout(20000);
                if (headersJson != null && !headersJson.isEmpty()) {
                    JSONObject hs = new JSONObject(headersJson);
                    for (java.util.Iterator<String> it = hs.keys(); it.hasNext(); ) {
                        String k = it.next();
                        conn.setRequestProperty(k, hs.optString(k));
                    }
                }
                if (body != null && !body.isEmpty()) {
                    if (conn.getRequestProperty("Content-Type") == null) {
                        conn.setRequestProperty("Content-Type", "application/json");
                    }
                    conn.setDoOutput(true);
                    byte[] data = body.getBytes(StandardCharsets.UTF_8);
                    conn.setFixedLengthStreamingMode(data.length);
                    OutputStream os = conn.getOutputStream();
                    os.write(data);
                    os.flush();
                    os.close();
                }
                int status = conn.getResponseCode();
                String text = readStream(conn, status);
                JSONObject r = new JSONObject();
                r.put("status", status);
                r.put("text", text);
                resolve(cbId, true, r.toString());
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }

    private String readStream(HttpURLConnection conn, int status) throws Exception {
        java.io.InputStream is = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (is == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        char[] buf = new char[4096];
        int n;
        while ((n = br.read(buf)) > 0) sb.append(buf, 0, n);
        br.close();
        return sb.toString();
    }

    void discover(final String cbId, final String optsJson) {
        io.execute(() -> {
            long timeoutMs = 2500;
            try {
                JSONObject opts = new JSONObject(optsJson == null || optsJson.isEmpty() ? "{}" : optsJson);
                timeoutMs = opts.optLong("timeoutMs", 2500);
            } catch (Exception ignored) {}
            timeoutMs = Math.max(2000, Math.min(4500, timeoutMs));
            final List<JSONObject> hosts = Collections.synchronizedList(new ArrayList<>());

            List<InterfaceAddress> ifAddrs = new ArrayList<>();
            try {
                for (Enumeration<NetworkInterface> nis = NetworkInterface.getNetworkInterfaces(); nis.hasMoreElements(); ) {
                    NetworkInterface ni = nis.nextElement();
                    if (ni.isLoopback() || !ni.isUp()) continue;
                    for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                        InetAddress a = ia.getAddress();
                        if (a instanceof Inet4Address && !a.isLoopbackAddress()) ifAddrs.add(ia);
                    }
                }
            } catch (Exception ignored) {}

            List<DatagramSocket> sockets = new ArrayList<>();
            for (InterfaceAddress ia : ifAddrs) {
                try {
                    DatagramSocket s = new DatagramSocket(0, ia.getAddress());
                    s.setBroadcast(true);
                    sockets.add(s);
                } catch (Exception ignored) {}
            }
            if (sockets.isEmpty()) {
                try { DatagramSocket s = new DatagramSocket(); s.setBroadcast(true); sockets.add(s); } catch (Exception ignored) {}
            }
            final List<DatagramSocket> fSockets = sockets;
            final long deadline = System.currentTimeMillis() + timeoutMs;

            Runnable receiver = () -> {
                for (DatagramSocket s : fSockets) { try { s.setSoTimeout(250); } catch (Exception ignored) {} }
                byte[] buf = new byte[2048];
                while (System.currentTimeMillis() < deadline) {
                    for (DatagramSocket s : fSockets) {
                        if (s.isClosed()) continue;
                        try {
                            DatagramPacket p = new DatagramPacket(buf, buf.length);
                            s.receive(p);
                            String resp = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8).trim();
                            if (!resp.startsWith("{")) continue;
                            JSONObject r = new JSONObject(resp);
                            if (!"cw-datacenter".equals(r.optString("app"))) continue;
                            String fromIp = p.getAddress().getHostAddress();
                            addHost(hosts, fromIp, r.optInt("port", 8080),
                                    r.optString("host", fromIp), r.optString("name", "CW Datacenter"),
                                    fromIp.startsWith("100.") ? "tailscale" : "lan");
                        } catch (java.net.SocketTimeoutException ignored) {
                        } catch (java.net.SocketException e) {
                            break;
                        } catch (Exception ignored) {}
                    }
                }
            };
            Thread recT = new Thread(receiver, "cw-discover-recv");
            recT.setDaemon(true);
            recT.start();

            /* 1. Gửi UDP broadcast + unicast tới toàn bộ dải IP 1..254 */
            final byte[] msg = "CW-DISCOVER".getBytes(StandardCharsets.UTF_8);
            for (InterfaceAddress ia : ifAddrs) {
                java.util.LinkedHashSet<String> targets = new java.util.LinkedHashSet<>();
                try {
                    targets.add("255.255.255.255");
                    InetAddress b = ia.getBroadcast();
                    if (b != null) targets.add(b.getHostAddress());
                    String ip = ia.getAddress().getHostAddress();
                    String[] parts = ip.split("\\.");
                    if (parts.length == 4) {
                        String pre = parts[0] + "." + parts[1] + "." + parts[2] + ".";
                        int self = Integer.parseInt(parts[3]);
                        for (int i = 1; i <= 254; i++) {
                            if (i != self) targets.add(pre + i);
                        }
                    }
                } catch (Exception ignored) {}
                DatagramSocket sock = null;
                for (DatagramSocket s : fSockets) {
                    try {
                        if (s.getLocalAddress() != null && s.getLocalAddress().equals(ia.getAddress())) { sock = s; break; }
                    } catch (Exception ignored) {}
                }
                if (sock == null && !fSockets.isEmpty()) sock = fSockets.get(0);
                if (sock == null) continue;
                for (String t : targets) {
                    try {
                        InetAddress d = InetAddress.getByName(t);
                        sock.send(new DatagramPacket(msg, msg.length, d, 46631));
                    } catch (Exception ignored) {}
                }
            }

            /* 2. Song song: Quét nhanh HTTP /api/ping toàn bộ subnet 1..254 (phòng trường hợp Router/Firewall chặn UDP) */
            java.util.concurrent.ExecutorService httpPool = Executors.newFixedThreadPool(64);
            try {
                for (InterfaceAddress ia : ifAddrs) {
                    String ip = ia.getAddress().getHostAddress();
                    String[] parts = ip.split("\\.");
                    if (parts.length == 4) {
                        String pre = parts[0] + "." + parts[1] + "." + parts[2] + ".";
                        int self = Integer.parseInt(parts[3]);
                        for (int i = 1; i <= 254; i++) {
                            if (i == self) continue;
                            final String targetIp = pre + i;
                            httpPool.execute(() -> probeServer(targetIp, 8080, hosts));
                        }
                    }
                }
            } catch (Exception ignored) {}

            try { recT.join(Math.max(500, deadline - System.currentTimeMillis())); } catch (InterruptedException ignored) {}
            for (DatagramSocket s : fSockets) { try { s.close(); } catch (Exception ignored) {} }
            httpPool.shutdown();
            try { httpPool.awaitTermination(600, java.util.concurrent.TimeUnit.MILLISECONDS); } catch (Exception ignored) {}

            try {
                JSONObject o = new JSONObject();
                o.put("hosts", new JSONArray(new ArrayList<>(hosts)));
                resolve(cbId, true, o.toString());
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"discover failed\"}");
            }
        });
    }

    private static void addHost(List<JSONObject> hosts, String ip, int port, String host, String name, String via) {
        if (ip == null || ip.isEmpty() || "127.0.0.1".equals(ip)) return;
        synchronized (hosts) {
            for (JSONObject e : hosts) {
                if (e.optString("ip").equals(ip) && e.optInt("port") == port) return;
            }
            try {
                JSONObject h = new JSONObject();
                h.put("ip", ip);
                h.put("port", port);
                h.put("host", host == null || host.isEmpty() ? ip : host);
                h.put("name", name == null || name.isEmpty() ? "CW Datacenter" : name);
                h.put("via", via == null || via.isEmpty() ? (ip.startsWith("100.") ? "tailscale" : "lan") : via);
                hosts.add(h);
            } catch (Exception ignored) {}
        }
    }

    private void probeServer(String ip, int port, List<JSONObject> hosts) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL("http://" + ip + ":" + port + "/api/ping").openConnection();
            conn.setConnectTimeout(800);
            conn.setReadTimeout(800);
            int code = conn.getResponseCode();
            if (code == 200) {
                String body = readStream(conn, code);
                JSONObject r = new JSONObject(body);
                if (r.optBoolean("ok", false) || "cw-datacenter".equals(r.optString("app"))) {
                    String hostName = r.optString("host", ip);
                    String appName = r.optString("name", "CW Datacenter");
                    String via = r.optString("via", ip.startsWith("100.") ? "tailscale" : "lan");
                    int p = r.optInt("port", port);
                    addHost(hosts, ip, p, hostName, appName, via);
                    return;
                }
            } else if (code == 401 || code == 403 || code == 404) {
                addHost(hosts, ip, port, ip, "CW Datacenter", ip.startsWith("100.") ? "tailscale" : "lan");
            }
        } catch (Exception ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
    }


    void pickFiles(final String cbId) {
        main.post(() -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            starter.start(intent, (resultCode, data) -> {
                List<Uri> uris = new ArrayList<>();
                if (resultCode == android.app.Activity.RESULT_OK && data != null) {
                    if (data.getClipData() != null) {
                        for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                            Uri u = data.getClipData().getItemAt(i).getUri();
                            if (u != null) uris.add(u);
                        }
                    } else if (data.getData() != null) {
                        uris.add(data.getData());
                    }
                }
                for (Uri u : uris) {
                    try { activity.getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                    catch (SecurityException ignored) {}
                }
                try {
                    JSONArray arr = new JSONArray();
                    for (Uri u : uris) {
                        JSONObject f = describeUri(u);
                        if (f != null) arr.put(f);
                    }
                    JSONObject o = new JSONObject();
                    o.put("files", arr);
                    resolve(cbId, true, o.toString());
                } catch (Exception e) {
                    resolve(cbId, false, "{\"err\":\"pick failed\"}");
                }
            });
        });
    }

    private JSONObject describeUri(Uri uri) {
        try (Cursor c = activity.getContentResolver().query(uri, null, null, null, null)) {
            JSONObject f = new JSONObject();
            f.put("uri", uri.toString());
            String name = "file";
            long size = -1;
            String mime = activity.getContentResolver().getType(uri);
            if (c != null && c.moveToFirst()) {
                int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int si = c.getColumnIndex(OpenableColumns.SIZE);
                if (ni >= 0) name = c.getString(ni);
                if (si >= 0) size = c.getLong(si);
            }
            f.put("name", name == null ? "file" : name);
            f.put("size", size);
            f.put("mime", mime == null ? "application/octet-stream" : mime);
            return f;
        } catch (Exception e) {
            return null;
        }
    }

    void download(final String cbId, final String specJson) {
        io.execute(() -> {
            try {
                JSONObject spec = new JSONObject(specJson);
                JSONObject r = transfers.startDownload(spec);
                resolve(cbId, r.optBoolean("ok"), r.toString());
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    void upload(final String cbId, final String specJson) {
        io.execute(() -> {
            try {
                JSONObject spec = new JSONObject(specJson);
                JSONObject r = transfers.startUpload(spec);
                resolve(cbId, r.optBoolean("ok"), r.toString());
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    void cancel(final String cbId, final String id) {
        io.execute(() -> {
            if (id != null && id.startsWith("off:")) {
                String k = id.substring(4);
                java.net.HttpURLConnection c = offlinePreloadConns.remove(k);
                if (c != null) {
                    try { c.disconnect(); } catch (Exception ignored) {}
                }
            }
            transfers.cancel(id);
            resolve(cbId, true, "{\"ok\":true}");
        });
    }

    void openFile(final String cbId, final String specJson) {
        main.post(() -> {
            try {
                JSONObject spec = new JSONObject(specJson);
                String path = spec.optString("path");
                Uri uri;
                if (path.startsWith("content://")) {
                    uri = Uri.parse(path);
                } else {
                    java.io.File f = new java.io.File(path);
                    uri = StreamProvider.uriFor(activity, f);
                }
                String mime = spec.optString("mime", TransferManager.guessMime(path));
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(uri, mime);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    activity.startActivity(Intent.createChooser(intent, "Mở bằng"));
                } catch (Exception e) {
                    Toast.makeText(activity, "Không có ứng dụng mở tệp này", Toast.LENGTH_SHORT).show();
                }
                resolve(cbId, true, "{\"ok\":true}");
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    /* ---------- Mở PDF bằng trình đọc AndroidPdfViewer trong app ---------- */
    void openPdf(final String cbId, final String specJson) {
        main.post(() -> {
            try {
                JSONObject spec = new JSONObject(specJson);
                String url = spec.optString("url", "");
                String rel = spec.optString("rel", "");
                String poolId = spec.optString("pool", "");
                String name = spec.optString("name", "");
                String path = spec.optString("path", "");
                String uri = spec.optString("uri", "");
                if (url == null || url.isEmpty()) {
                    if (rel != null && !rel.isEmpty()) {
                        String relEnc = java.net.URLEncoder.encode(rel, "UTF-8");
                        String poolEnc = poolId == null || poolId.isEmpty() ? "" : java.net.URLEncoder.encode(poolId, "UTF-8");
                        url = proxy.urlFor(relEnc, poolEnc, false);
                    }
                }
                if ((url == null || url.isEmpty()) && (path == null || path.isEmpty()) && (uri == null || uri.isEmpty())) {
                    resolve(cbId, false, "{\"err\":\"thiếu đường dẫn PDF\"}");
                    return;
                }
                Intent i = new Intent(activity, PdfViewerActivity.class);
                if (url != null && !url.isEmpty()) i.putExtra("url", url);
                if (path != null && !path.isEmpty()) i.putExtra("path", path);
                if (uri != null && !uri.isEmpty()) i.putExtra("uri", uri);
                i.putExtra("name", name);
                try {
                    activity.startActivity(i);
                    resolve(cbId, true, "{\"ok\":true}");
                } catch (Exception e) {
                    resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
                }
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    /* ---------- Mở video/audio bằng player native (ExoPlayer) ---------- */
    void playVideo(final String cbId, final String specJson) {
        main.post(() -> {
            try {
                JSONObject spec = new JSONObject(specJson);
                String url = spec.optString("url", "");
                String rel = spec.optString("rel", "");
                String poolId = spec.optString("pool", "");
                String name = spec.optString("name", "");
                long size = spec.optLong("size", 0);
                int plIndex = spec.optInt("plIndex", 0);

                if (url == null || url.isEmpty()) {
                    if (rel == null || rel.isEmpty()) { resolve(cbId, false, "{\"err\":\"thiếu url/rel\"}"); return; }
                    String relEnc = java.net.URLEncoder.encode(rel, "UTF-8");
                    String poolEnc = poolId == null || poolId.isEmpty() ? "" : java.net.URLEncoder.encode(poolId, "UTF-8");
                    url = proxy.urlFor(relEnc, poolEnc, true);
                }
                if (url == null || url.isEmpty()) {
                    resolve(cbId, false, "{\"err\":\"proxy chưa sẵn sàng\"}");
                    return;
                }

                if (spec.has("playlist")) {
                    try {
                        JSONArray arr = spec.optJSONArray("playlist");
                        if (arr == null) {
                            String plStr = spec.optString("playlist", "");
                            if (plStr != null && !plStr.isEmpty()) arr = new JSONArray(plStr);
                        }
                        if (arr != null) {
                            List<PlayerActivity.PlItem> parsedList = new ArrayList<>();
                            for (int k = 0; k < arr.length(); k++) {
                                JSONObject o = arr.getJSONObject(k);
                                String u = o.optString("url", "");
                                if (u.isEmpty()) continue;
                                PlayerActivity.PlItem it = new PlayerActivity.PlItem();
                                it.name = o.optString("name", "");
                                it.url = u;
                                it.size = o.optLong("size", 0);
                                parsedList.add(it);
                            }
                            if (!parsedList.isEmpty()) {
                                PlayerActivity.setPendingPlaylist(parsedList, plIndex);
                            }
                        }
                    } catch (Exception ignored) {}
                }

                Intent i = new Intent(activity, PlayerActivity.class);
                i.putExtra("url", url);
                i.putExtra("name", name);
                i.putExtra("size", size);
                i.putExtra("baseUrl", spec.optString("baseUrl", ""));
                i.putExtra("token", spec.optString("token", ""));
                i.putExtra("rel", rel);
                i.putExtra("pool", poolId);
                long startPos = spec.optLong("startPos", -1);
                if (startPos >= 0) {
                    i.putExtra("startPos", startPos);
                }
                try {
                    activity.startActivity(i);
                    resolve(cbId, true, "{\"ok\":true}");
                } catch (Exception e) {
                    resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
                }
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    void getVideoProgress(final String cbId, final String specJson) {
        io.execute(() -> {
            try {
                JSONObject spec = new JSONObject(specJson);
                String name = spec.optString("name", "");
                String url = spec.optString("url", "");
                String key = "vpos_" + (name != null && !name.isEmpty() ? name : (url != null ? url.hashCode() : "vid"));
                long pos = activity.getSharedPreferences("cw_video_progress", android.content.Context.MODE_PRIVATE).getLong(key, 0);
                JSONObject o = new JSONObject();
                o.put("pos", pos);
                resolve(cbId, true, o.toString());
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    void clearVideoProgress(final String cbId, final String specJson) {
        io.execute(() -> {
            try {
                JSONObject spec = new JSONObject(specJson);
                String name = spec.optString("name", "");
                String url = spec.optString("url", "");
                String key = "vpos_" + (name != null && !name.isEmpty() ? name : (url != null ? url.hashCode() : "vid"));
                activity.getSharedPreferences("cw_video_progress", android.content.Context.MODE_PRIVATE).edit().remove(key).apply();
                resolve(cbId, true, "{\"ok\":true}");
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    void showKeyboard(final String cbId) {
        main.post(() -> {
            try {
                if (webView != null) {
                    webView.requestFocus();
                    android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) activity.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
                    if (imm != null) {
                        imm.showSoftInput(webView, android.view.inputmethod.InputMethodManager.SHOW_FORCED);
                    }
                }
                resolve(cbId, true, "{\"ok\":true}");
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    void hideKeyboard(final String cbId) {
        main.post(() -> {
            try {
                if (webView != null) {
                    android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) activity.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
                    if (imm != null) {
                        imm.hideSoftInputFromWindow(webView.getWindowToken(), 0);
                    }
                }
                resolve(cbId, true, "{\"ok\":true}");
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    void getLocalIp(final String cbId) {
        io.execute(() -> {
            try {
                JSONObject o = new JSONObject();
                o.put("ip", localIp());
                resolve(cbId, true, o.toString());
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"no ip\"}");
            }
        });
    }

    /* ---------- Duyệt file/thư mục trên chính thiết bị (SAF / Storage Access Framework) ---------- */

    private Uri parseRootTreeUri(String specTreeUri) throws Exception {
        Uri tree = Uri.parse(specTreeUri);
        try {
            String treeDocId = android.provider.DocumentsContract.getTreeDocumentId(tree);
            return android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, treeDocId);
        } catch (Exception e) {
            return tree;
        }
    }

    @JavascriptInterface
    public String localUrl(final String specJson) {
        try {
            JSONObject spec = new JSONObject(specJson);
            String tree = spec.getString("tree");
            String id = spec.getString("id");
            String name = spec.optString("name", "");
            String mime = spec.optString("mime", "");
            Uri root = parseRootTreeUri(tree);
            return localUrlFor(root.toString(), id, name, mime);
        } catch (Exception e) {
            return "";
        }
    }

    @JavascriptInterface
    public String localThumbUrl(final String specJson) {
        return localUrl(specJson);
    }

    private String localUrlFor(String treeUri, String docId, String name, String mime) {
        int p = proxy.port();
        if (p == 0) return "";
        try {
            return "http://127.0.0.1:" + p + "/doc?tree=" + java.net.URLEncoder.encode(treeUri, "UTF-8")
                    + "&id=" + java.net.URLEncoder.encode(docId, "UTF-8")
                    + "&name=" + java.net.URLEncoder.encode(name == null ? "" : name, "UTF-8")
                    + "&mime=" + java.net.URLEncoder.encode(mime == null ? "" : mime, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    void localList(final String cbId, final String specJson) {
        io.execute(() -> {
            try {
                JSONObject spec = new JSONObject(specJson);
                Uri tree = Uri.parse(spec.getString("tree"));
                String folderId = spec.optString("folder", "");
                if (folderId == null || folderId.isEmpty()) {
                    folderId = android.provider.DocumentsContract.getTreeDocumentId(tree);
                }
                JSONObject o = LocalFiles.list(activity.getContentResolver(), tree, folderId);
                o.put("rootId", android.provider.DocumentsContract.getTreeDocumentId(tree));
                resolve(cbId, true, o.toString());
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    void localOpen(final String cbId, final String specJson) {
        main.post(() -> {
            try {
                JSONObject spec = new JSONObject(specJson);
                Uri tree = Uri.parse(spec.getString("tree"));
                String docId = spec.getString("id");
                String mime = spec.optString("mime", "");
                String name = spec.optString("name", "");
                Uri child = LocalFiles.childUri(tree, docId);
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(child, LocalFiles.guessMimeByName(name, mime));
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    activity.startActivity(Intent.createChooser(intent, "Mở bằng"));
                } catch (Exception e) {
                    Toast.makeText(activity, "Không có ứng dụng mở tệp này", Toast.LENGTH_SHORT).show();
                }
                resolve(cbId, true, "{\"ok\":true}");
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    void openTree(final String cbId, final String specJson) {
        main.post(() -> {
            try {
                JSONObject spec = new JSONObject(specJson);
                Uri tree = Uri.parse(spec.getString("tree"));
                Uri children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(
                        tree, android.provider.DocumentsContract.getTreeDocumentId(tree));
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(children);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    activity.startActivity(intent);
                } catch (Exception e) {
                    try {
                        Intent alt = new Intent(Intent.ACTION_VIEW);
                        alt.setData(tree);
                        activity.startActivity(alt);
                    } catch (Exception e2) {
                        Toast.makeText(activity, "Không mở được thư mục này", Toast.LENGTH_SHORT).show();
                    }
                }
                resolve(cbId, true, "{\"ok\":true}");
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    void openDownloads(final String cbId, final String dummy) {
        main.post(() -> {
            try {
                Intent i = new Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS);
                try {
                    activity.startActivity(i);
                } catch (Exception e) {
                    Uri dl = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(
                            Uri.parse("content://com.android.externalstorage.documents/tree/primary%3A"), "primary:Download");
                    Intent alt = new Intent(Intent.ACTION_VIEW);
                    alt.setData(dl);
                    alt.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { activity.startActivity(alt); }
                    catch (Exception e2) { Toast.makeText(activity, "Không mở được thư mục Download", Toast.LENGTH_SHORT).show(); }
                }
                resolve(cbId, true, "{\"ok\":true}");
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    void localDownload(final String cbId, final String specJson) {
        io.execute(() -> {
            try {
                JSONObject spec = new JSONObject(specJson);
                Uri tree = parseRootTreeUri(spec.getString("tree"));
                String docId = spec.getString("id");
                String name = spec.optString("name", "file");
                Uri child = LocalFiles.childUri(tree, docId);
                JSONObject dl = new JSONObject();
                dl.put("url", child.toString());
                dl.put("name", name);
                dl.put("headers", "{}");
                if (spec.has("destTreeUri")) dl.put("destTreeUri", spec.optString("destTreeUri", ""));
                if (spec.has("destSub")) dl.put("destSub", spec.optString("destSub", ""));
                if (spec.has("destPath")) dl.put("destPath", spec.optString("destPath", ""));
                dl.put("sync", spec.optBoolean("sync", false));
                JSONObject r = transfers.startDownload(dl);
                r.put("url", child.toString());
                resolve(cbId, r.optBoolean("ok"), r.toString());
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    /* ---------- Ổ "Thiết bị này": duyệt thẳng bộ nhớ máy (giống các ổ chia sẻ) ---------- */

    @JavascriptInterface
    public String localFsUrl(final String specJson) {
        try {
            JSONObject spec = new JSONObject(specJson);
            String p = spec.getString("p");
            String mime = spec.optString("mime", "");
            int pt = proxy.port();
            if (pt == 0) return "";
            return "http://127.0.0.1:" + pt + "/f?p=" + java.net.URLEncoder.encode(p, "UTF-8")
                    + "&mime=" + java.net.URLEncoder.encode(mime == null ? "" : mime, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    void localFsStatus(final String cbId) {
        boolean ok = LocalFiles.fsAllowed(activity);
        resolve(cbId, true, "{\"ok\":" + ok + ",\"sdk\":" + Build.VERSION.SDK_INT + "}");
    }

    void localFsInfo(final String cbId, final String specJson) {
        io.execute(() -> {
            try {
                String path = specJson == null || specJson.isEmpty() ? "" : specJson;
                java.io.File base = path.isEmpty()
                        ? android.os.Environment.getExternalStorageDirectory()
                        : new java.io.File(path);
                android.os.StatFs st = new android.os.StatFs(base.getAbsolutePath());
                JSONObject o = new JSONObject();
                o.put("total", st.getTotalBytes());
                o.put("free", st.getAvailableBytes());
                o.put("rootPath", android.os.Environment.getExternalStorageDirectory().getAbsolutePath());
                resolve(cbId, true, o.toString());
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    void requestLocalFsAccess(final String cbId) {
        main.post(() -> {
            if (LocalFiles.fsAllowed(activity)) { resolve(cbId, true, "{\"ok\":true}"); return; }
            if (Build.VERSION.SDK_INT >= 30) {
                try {
                    Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                    i.setData(Uri.parse("package:" + activity.getPackageName()));
                    activity.startActivity(i);
                } catch (Exception e) {
                    try {
                        activity.startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                    } catch (Exception e2) {
                        resolve(cbId, false, "{\"err\":\"Không mở được trang cấp quyền\"}");
                        return;
                    }
                }
                resolve(cbId, true, "{\"ok\":false,\"waiting\":true}");
            } else {
                activity.requestPerms(new String[]{ "android.permission.READ_EXTERNAL_STORAGE" }, (grants) -> {
                    boolean granted = grants != null && grants.length > 0
                            && grants[0] == android.content.pm.PackageManager.PERMISSION_GRANTED;
                    resolve(cbId, true, "{\"ok\":" + granted + "}");
                });
            }
        });
    }

    void localFsList(final String cbId, final String specJson) {
        io.execute(() -> {
            try {
                JSONObject spec = new JSONObject(specJson == null || specJson.isEmpty() ? "{}" : specJson);
                String path = spec.optString("path", "");
                if (path == null || path.isEmpty()) {
                    path = android.os.Environment.getExternalStorageDirectory().getAbsolutePath();
                }
                JSONObject o = LocalFiles.listFs(new java.io.File(path));
                resolve(cbId, true, o.toString());
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    void localFsOpen(final String cbId, final String specJson) {
        main.post(() -> {
            try {
                JSONObject spec = new JSONObject(specJson);
                String path = spec.getString("p");
                java.io.File f = new java.io.File(path);
                Uri uri = StreamProvider.uriFor(activity, f);
                String mime = LocalFiles.guessMimeByName(f.getName(), spec.optString("mime", ""));
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(uri, mime);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    activity.startActivity(Intent.createChooser(intent, "Mở bằng"));
                } catch (Exception e) {
                    Toast.makeText(activity, "Không có ứng dụng mở tệp này", Toast.LENGTH_SHORT).show();
                }
                resolve(cbId, true, "{\"ok\":true}");
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    void localFsDownload(final String cbId, final String specJson) {
        io.execute(() -> {
            try {
                JSONObject spec = new JSONObject(specJson);
                java.io.File f = new java.io.File(spec.getString("p"));
                String name = spec.optString("name", f.getName());
                JSONObject dl = new JSONObject();
                dl.put("url", f.toURI().toString());
                dl.put("name", name);
                dl.put("headers", "{}");
                if (spec.has("destTreeUri")) dl.put("destTreeUri", spec.optString("destTreeUri", ""));
                if (spec.has("destSub")) dl.put("destSub", spec.optString("destSub", ""));
                if (spec.has("destPath")) dl.put("destPath", spec.optString("destPath", ""));
                dl.put("sync", spec.optBoolean("sync", false));
                JSONObject r = transfers.startDownload(dl);
                resolve(cbId, r.optBoolean("ok"), r.toString());
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    /* Đảm bảo đường dẫn thư mục tồn tại trên bộ nhớ máy (tạo đệ quy nếu thiếu).
     * Dùng cho đồng bộ 1 chiều: tạo thư mục con tên thiết bị trong ổ shared máy host. */
    void localFsEnsure(final String cbId, final String specJson) {
        io.execute(() -> {
            try {
                JSONObject spec = new JSONObject(specJson == null || specJson.isEmpty() ? "{}" : specJson);
                String p = spec.optString("path", "");
                if (p.isEmpty()) { resolve(cbId, false, "{\"err\":\"thiếu đường dẫn\"}"); return; }
                java.io.File dir = new java.io.File(p);
                boolean ok = dir.isDirectory() || dir.mkdirs();
                JSONObject r = new JSONObject();
                r.put("ok", ok);
                r.put("path", dir.getAbsolutePath());
                resolve(cbId, ok, r.toString());
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    /* Liệt kê đệ quy toàn bộ tệp trong một thư mục trên bộ nhớ máy (đồng bộ 1 chiều lên host). */
    void localFsDeepList(final String cbId, final String specJson) {
        io.execute(() -> {
            try {
                JSONObject spec = new JSONObject(specJson == null || specJson.isEmpty() ? "{}" : specJson);
                String path = spec.optString("path", "");
                if (path.isEmpty()) path = android.os.Environment.getExternalStorageDirectory().getAbsolutePath();
                int limit = Math.min(Math.max(spec.optInt("limit", 5000), 100), 20000);
                JSONObject o = LocalFiles.deepList(new java.io.File(path), limit);
                resolve(cbId, true, o.toString());
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    /* Sao chép/di chuyển (copy/cut) file+folder giữa 2 thư mục trên bộ nhớ máy — phục vụ nút "Paste". */
    void localFsMove(final String cbId, final String specJson) {
        io.execute(() -> {
            try {
                JSONObject spec = new JSONObject(specJson);
                JSONArray it = spec.optJSONArray("items");
                String to = spec.getString("to");
                boolean cut = spec.optBoolean("cut", false);
                if (it == null || it.length() == 0) { resolve(cbId, false, "{\"err\":\"chưa có mục nào được chọn\"}"); return; }
                if (!LocalFiles.fsAllowed(activity)) { resolve(cbId, false, "{\"err\":\"Chưa có quyền truy cập bộ nhớ máy.\"}"); return; }
                java.util.List<String> items = new java.util.ArrayList<>();
                for (int i = 0; i < it.length(); i++) items.add(it.optString(i, ""));
                JSONObject r = LocalFiles.moveItems(items, to, cut);
                resolve(cbId, true, r.toString());
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    /* Xóa file/folder trên bộ nhớ máy sau khi đã cut sang nơi khác. */
    void localFsDelete(final String cbId, final String specJson) {
        io.execute(() -> {
            try {
                JSONObject spec = new JSONObject(specJson);
                JSONArray it = spec.optJSONArray("items");
                if (it == null || it.length() == 0) { resolve(cbId, false, "{\"err\":\"chưa có mục nào\"}"); return; }
                if (!LocalFiles.fsAllowed(activity)) { resolve(cbId, false, "{\"err\":\"Chưa có quyền truy cập bộ nhớ máy.\"}"); return; }
                java.util.List<String> items = new java.util.ArrayList<>();
                for (int i = 0; i < it.length(); i++) items.add(it.optString(i, ""));
                JSONObject r = LocalFiles.deleteItems(items);
                resolve(cbId, true, r.toString());
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    /* ---------- helpers ---------- */

    boolean onBack() {
        if (!canGoBack) return false;
        postJs("DC._back && DC._back()");
        return true;
    }

    /* App vào nền: truyền tải vẫn chạy ngầm qua TransferService + wake lock. */
    void onBackground() {
        if (transfers.hasActive()) {
            TransferService.sync(activity.getApplicationContext(), transfers.activeCount());
        }
    }

    void resolve(final String cbId, final boolean ok, final String json) {
        postJs("DC._cb && DC._cb(" + quote(cbId) + "," + ok + "," + quote(json) + ")");
    }

    void postEvent(final String json) {
        postJs("DC._evt && DC._evt(" + quote(json) + ")");
    }

    private void postJs(final String expr) {
        main.post(() -> webView.evaluateJavascript(expr, null));
    }

    private static String quote(String s) {
        if (s == null) return "null";
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                case '\u2028': sb.append("\\u2028"); break;
                case '\u2029': sb.append("\\u2029"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        sb.append('"');
        return sb.toString();
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ");
    }

    void openPhoto(final String cbId, final String specJson) {
        main.post(() -> {
            try {
                JSONObject spec = new JSONObject(specJson == null || specJson.isEmpty() ? "{}" : specJson);
                String url = spec.optString("url", "");
                String name = spec.optString("name", "");
                String token = spec.optString("token", "");
                String localPath = spec.optString("localPath", "");
                int initialIndex = spec.optInt("initialIndex", 0);
                String baseUrl = spec.optString("baseUrl", "");

                if (spec.has("playlist")) {
                    try {
                        JSONArray arr = spec.optJSONArray("playlist");
                        if (arr == null) {
                            String plStr = spec.optString("playlist", "");
                            if (plStr != null && !plStr.isEmpty()) arr = new JSONArray(plStr);
                        }
                        if (arr != null) {
                            List<PhotoViewerActivity.PhotoItem> parsedList = new ArrayList<>();
                            for (int k = 0; k < arr.length(); k++) {
                                parsedList.add(PhotoViewerActivity.PhotoItem.fromJson(arr.getJSONObject(k)));
                            }
                            if (!parsedList.isEmpty()) {
                                PhotoViewerActivity.setPendingItems(parsedList, initialIndex);
                            }
                        }
                    } catch (Exception ignored) {}
                }

                Intent i = new Intent(activity, PhotoViewerActivity.class);
                if (url != null && !url.isEmpty()) i.putExtra(PhotoViewerActivity.EXTRA_URL, url);
                if (name != null && !name.isEmpty()) i.putExtra(PhotoViewerActivity.EXTRA_NAME, name);
                if (token != null && !token.isEmpty()) i.putExtra(PhotoViewerActivity.EXTRA_TOKEN, token);
                if (localPath != null && !localPath.isEmpty()) i.putExtra(PhotoViewerActivity.EXTRA_LOCAL_PATH, localPath);
                i.putExtra(PhotoViewerActivity.EXTRA_INITIAL_INDEX, initialIndex);
                if (baseUrl != null && !baseUrl.isEmpty()) i.putExtra(PhotoViewerActivity.EXTRA_BASE_URL, baseUrl);
                activity.startActivity(i);
                resolve(cbId, true, "{\"ok\":true}");
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    void copyClipboard(final String cbId, final String text) {
        main.post(() -> {
            try {
                android.content.ClipboardManager cm = (android.content.ClipboardManager) activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
                android.content.ClipData clip = android.content.ClipData.newPlainText("text", text != null ? text : "");
                if (cm != null) cm.setPrimaryClip(clip);
                resolve(cbId, true, "{\"ok\":true}");
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    void localFsMkdir(final String cbId, final String specJson) {
        io.execute(() -> {
            try {
                JSONObject spec = new JSONObject(specJson == null || specJson.isEmpty() ? "{}" : specJson);
                String parent = spec.optString("parent", "");
                String name = spec.optString("name", "");
                if (parent == null || parent.isEmpty()) {
                    parent = android.os.Environment.getExternalStorageDirectory().getAbsolutePath();
                }
                java.io.File dir = new java.io.File(parent, name);
                boolean ok = dir.mkdirs() || dir.exists();
                if (ok) resolve(cbId, true, "{\"ok\":true}");
                else resolve(cbId, false, "{\"err\":\"Không thể tạo thư mục.\"}");
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(String.valueOf(e.getMessage())) + "\"}");
            }
        });
    }

    /* ---------- Video Offline (Lưu trữ cố định trong app) ---------- */

    private File getOfflineDir() {
        File dir = new File(activity.getFilesDir(), "offline_media");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private static String md5(String s) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            byte[] dig = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : dig) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return Integer.toHexString(s.hashCode());
        }
    }

    void getOfflineVideos(final String cbId) {
        io.execute(() -> {
            try {
                File dir = getOfflineDir();
                File[] files = dir.listFiles((d, n) -> n.endsWith(".mp4"));
                JSONArray arr = new JSONArray();
                long totalBytes = 0;
                if (files != null) {
                    android.content.SharedPreferences sp = activity.getSharedPreferences("cw_offline_meta", android.content.Context.MODE_PRIVATE);
                    for (File f : files) {
                        if (f.isFile() && f.length() > 0) {
                            String key = f.getName().replace(".mp4", "");
                            String metaJson = sp.getString(key, null);
                            JSONObject item = new JSONObject();
                            if (metaJson != null) {
                                try { item = new JSONObject(metaJson); } catch (Exception ignored) {}
                            }
                            item.put("key", key);
                            item.put("path", f.getAbsolutePath());
                            item.put("size", f.length());
                            item.put("savedAt", f.lastModified());
                            if (!item.has("name")) item.put("name", f.getName());
                            arr.put(item);
                            totalBytes += f.length();
                        }
                    }
                }
                JSONObject r = new JSONObject();
                r.put("ok", true);
                r.put("videos", arr);
                r.put("totalSize", totalBytes);
                resolve(cbId, true, r.toString());
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(e.getMessage()) + "\"}");
            }
        });
    }

    void deleteOfflineVideo(final String cbId, final String specJson) {
        io.execute(() -> {
            try {
                JSONObject spec = new JSONObject(specJson == null || specJson.isEmpty() ? "{}" : specJson);
                String key = spec.optString("key", "");
                if (key.isEmpty() && spec.has("rel")) {
                    String pool = spec.optString("pool", "main");
                    String rel = spec.optString("rel", "");
                    key = md5(pool + ":" + rel + ":vid");
                }
                if (key.isEmpty()) { resolve(cbId, false, "{\"err\":\"Thiếu key video\"}"); return; }
                File dir = getOfflineDir();
                File f = new File(dir, key + ".mp4");
                File p = new File(dir, key + ".part");
                if (f.exists()) f.delete();
                if (p.exists()) p.delete();
                activity.getSharedPreferences("cw_offline_meta", android.content.Context.MODE_PRIVATE).edit().remove(key).apply();
                resolve(cbId, true, "{\"ok\":true}");
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(e.getMessage()) + "\"}");
            }
        });
    }

    void clearAllOfflineVideos(final String cbId) {
        io.execute(() -> {
            try {
                File dir = getOfflineDir();
                deleteDirContents(dir);
                activity.getSharedPreferences("cw_offline_meta", android.content.Context.MODE_PRIVATE).edit().clear().apply();
                resolve(cbId, true, "{\"ok\":true}");
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(e.getMessage()) + "\"}");
            }
        });
    }

    private final java.util.concurrent.ConcurrentHashMap<String, java.net.HttpURLConnection> offlinePreloadConns = new java.util.concurrent.ConcurrentHashMap<>();

    void startOfflinePreload(final String cbId, final String specJson) {
        io.execute(() -> {
            try {
                JSONObject spec = new JSONObject(specJson == null || specJson.isEmpty() ? "{}" : specJson);
                String url = spec.getString("url");
                String name = spec.optString("name", "video.mp4");
                String pool = spec.optString("pool", "main");
                String rel = spec.optString("rel", name);
                String tok = spec.optString("token", "");
                if (tok.isEmpty()) tok = activity.getSharedPreferences("cw-datacenter", android.content.Context.MODE_PRIVATE).getString("player_token", "");

                String key = md5((pool != null && !pool.isEmpty() ? pool : "main") + ":" + (rel != null && !rel.isEmpty() ? rel : name) + ":vid");
                File dir = getOfflineDir();
                File fullFile = new File(dir, key + ".mp4");
                File partFile = new File(dir, key + ".part");
                final String transferId = "off:" + key;

                if (fullFile.exists() && fullFile.length() > 0) {
                    JSONObject ev = new JSONObject();
                    ev.put("type", "transfer");
                    ev.put("id", transferId);
                    ev.put("status", "done");
                    ev.put("total", fullFile.length());
                    ev.put("path", fullFile.getAbsolutePath());
                    postEvent(ev.toString());

                    JSONObject r = new JSONObject();
                    r.put("ok", true);
                    r.put("done", true);
                    r.put("key", key);
                    r.put("path", fullFile.getAbsolutePath());
                    resolve(cbId, true, r.toString());
                    return;
                }

                // Lưu metadata trước
                JSONObject meta = new JSONObject();
                meta.put("key", key);
                meta.put("name", name);
                meta.put("pool", pool);
                meta.put("rel", rel);
                meta.put("savedAt", System.currentTimeMillis());
                activity.getSharedPreferences("cw_offline_meta", android.content.Context.MODE_PRIVATE)
                        .edit().putString(key, meta.toString()).apply();

                final String finalTok = tok;
                final String finalKey = key;

                io.execute(() -> {
                    java.net.HttpURLConnection conn = null;
                    java.io.FileOutputStream fos = null;
                    try {
                        long existing = (partFile.exists() && partFile.isFile()) ? partFile.length() : 0;
                        java.net.URL u = new java.net.URL(url);
                        conn = (java.net.HttpURLConnection) u.openConnection();
                        offlinePreloadConns.put(finalKey, conn);
                        conn.setConnectTimeout(15000);
                        conn.setReadTimeout(60000);
                        if (finalTok != null && !finalTok.isEmpty()) {
                            conn.setRequestProperty("Authorization", "Bearer " + finalTok);
                        }
                        if (existing > 0) {
                            conn.setRequestProperty("Range", "bytes=" + existing + "-");
                        }
                        conn.connect();
                        int code = conn.getResponseCode();
                        boolean append = false;
                        long totalBytes = 0;
                        if (code == 206) {
                            append = true;
                            long len = conn.getContentLengthLong();
                            totalBytes = len > 0 ? existing + len : 0;
                        } else if (code == 200) {
                            append = false;
                            existing = 0;
                            totalBytes = conn.getContentLengthLong();
                        } else if (code == 416) {
                            if (partFile.exists() && partFile.length() > 0) {
                                partFile.renameTo(fullFile);
                                JSONObject ev = new JSONObject();
                                ev.put("type", "transfer");
                                ev.put("id", transferId);
                                ev.put("status", "done");
                                ev.put("total", fullFile.length());
                                ev.put("path", fullFile.getAbsolutePath());
                                postEvent(ev.toString());
                            }
                            return;
                        } else {
                            JSONObject ev = new JSONObject();
                            ev.put("type", "transfer");
                            ev.put("id", transferId);
                            ev.put("status", "error");
                            ev.put("err", "Mã phản hồi từ máy chủ: " + code);
                            postEvent(ev.toString());
                            return;
                        }

                        fos = new java.io.FileOutputStream(partFile, append);
                        java.io.BufferedOutputStream bos = new java.io.BufferedOutputStream(fos, 1024 * 1024);
                        java.io.InputStream rawIs = conn.getInputStream();
                        java.io.BufferedInputStream bis = new java.io.BufferedInputStream(rawIs, 1024 * 1024);
                        byte[] buf = new byte[1024 * 1024];
                        int n;
                        long currentDone = existing;
                        long lastReportTime = System.currentTimeMillis();
                        long lastReportBytes = currentDone;

                        // Báo cáo bắt đầu truyền tải
                        JSONObject evInit = new JSONObject();
                        evInit.put("type", "transfer");
                        evInit.put("id", transferId);
                        evInit.put("status", "active");
                        evInit.put("done", currentDone);
                        evInit.put("total", totalBytes > 0 ? totalBytes : currentDone);
                        evInit.put("speed", 0);
                        postEvent(evInit.toString());

                        while ((n = bis.read(buf)) != -1) {
                            bos.write(buf, 0, n);
                            currentDone += n;

                            long now = System.currentTimeMillis();
                            if (now - lastReportTime >= 400) {
                                long timeDelta = now - lastReportTime;
                                long byteDelta = currentDone - lastReportBytes;
                                double speed = timeDelta > 0 ? (byteDelta * 1000.0 / timeDelta) : 0;

                                JSONObject ev = new JSONObject();
                                ev.put("type", "transfer");
                                ev.put("id", transferId);
                                ev.put("status", "active");
                                ev.put("done", currentDone);
                                ev.put("total", totalBytes > 0 ? totalBytes : currentDone);
                                ev.put("speed", (long) speed);
                                postEvent(ev.toString());

                                lastReportTime = now;
                                lastReportBytes = currentDone;
                            }
                        }
                        bos.flush();
                        bos.close();
                        fos = null;

                        if (partFile.exists() && partFile.length() > 0) {
                            partFile.renameTo(fullFile);
                            JSONObject ev = new JSONObject();
                            ev.put("type", "transfer");
                            ev.put("id", transferId);
                            ev.put("status", "done");
                            ev.put("total", fullFile.length());
                            ev.put("path", fullFile.getAbsolutePath());
                            postEvent(ev.toString());
                        }
                    } catch (Exception e) {
                        try {
                            JSONObject ev = new JSONObject();
                            ev.put("type", "transfer");
                            ev.put("id", transferId);
                            ev.put("status", "error");
                            ev.put("err", e.getMessage() != null ? e.getMessage() : "Lỗi tải video");
                            postEvent(ev.toString());
                        } catch (Exception ignored) {}
                    } finally {
                        offlinePreloadConns.remove(finalKey);
                        if (fos != null) { try { fos.close(); } catch (Exception ignored) {} }
                        if (conn != null) { conn.disconnect(); }
                    }
                });

                JSONObject r = new JSONObject();
                r.put("ok", true);
                r.put("started", true);
                r.put("key", key);
                resolve(cbId, true, r.toString());
            } catch (Exception e) {
                resolve(cbId, false, "{\"err\":\"" + esc(e.getMessage()) + "\"}");
            }
        });
    }

    static String localIp() {
        try {
            for (Enumeration<NetworkInterface> nis = NetworkInterface.getNetworkInterfaces(); nis.hasMoreElements(); ) {
                NetworkInterface ni = nis.nextElement();
                if (ni.isLoopback() || !ni.isUp()) continue;
                for (Enumeration<InetAddress> addrs = ni.getInetAddresses(); addrs.hasMoreElements(); ) {
                    InetAddress a = addrs.nextElement();
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) return a.getHostAddress();
                }
            }
        } catch (Exception ignored) {}
        return "";
    }
}

