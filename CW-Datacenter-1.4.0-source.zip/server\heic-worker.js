const { parentPort } = require('worker_threads');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const { execFile } = require('child_process');
let heicConvert = null;
try { heicConvert = require('heic-convert'); } catch {}

function findAnyEmbeddedJpeg(buf) {
  if (!buf || buf.length < 1024) return null;

  // 1. Quét tìm Exif marker
  const exifIdx = buf.indexOf(Buffer.from('Exif\0\0'));
  if (exifIdx !== -1) {
    const tiffStart = exifIdx + 6;
    if (tiffStart + 8 <= buf.length) {
      const isLE = buf[tiffStart] === 0x49 && buf[tiffStart + 1] === 0x49;
      const read16 = (o) => isLE ? buf.readUInt16LE(tiffStart + o) : buf.readUInt16BE(tiffStart + o);
      const read32 = (o) => isLE ? buf.readUInt32LE(tiffStart + o) : buf.readUInt32BE(tiffStart + o);
      try {
        const firstIFD = read32(4);
        if (firstIFD > 0 && firstIFD + 2 <= buf.length - tiffStart) {
          const numEntries0 = read16(firstIFD);
          const nextIFDOffset = firstIFD + 2 + numEntries0 * 12;
          if (nextIFDOffset + 4 <= buf.length - tiffStart) {
            const ifd1 = read32(nextIFDOffset);
            if (ifd1 > 0 && ifd1 + 2 <= buf.length - tiffStart) {
              const numEntries1 = read16(ifd1);
              let thumbOffset = 0, thumbLen = 0;
              for (let i = 0; i < numEntries1; i++) {
                const entryOff = ifd1 + 2 + i * 12;
                const tag = read16(entryOff);
                if (tag === 0x0201) thumbOffset = read32(entryOff + 8);
                else if (tag === 0x0202) thumbLen = read32(entryOff + 8);
              }
              if (thumbOffset > 0 && thumbLen > 0 && tiffStart + thumbOffset + thumbLen <= buf.length) {
                const slice = buf.slice(tiffStart + thumbOffset, tiffStart + thumbOffset + thumbLen);
                if (slice.length >= 500 && slice[0] === 0xFF && slice[1] === 0xD8) {
                  return slice;
                }
              }
            }
          }
        }
      } catch (e) {}
    }
  }

  // 2. Quét tìm bất kỳ JPEG thumbnail nhúng nào trong toàn bộ tệp (Boyer-Moore byte scan)
  let i = 0;
  while (i < buf.length - 4) {
    if (buf[i] === 0xFF && buf[i+1] === 0xD8 && buf[i+2] === 0xFF) {
      let j = i + 4;
      const maxJ = Math.min(buf.length - 1, i + 900 * 1024);
      while (j < maxJ) {
        if (buf[j] === 0xFF && buf[j+1] === 0xD9) {
          const slice = buf.slice(i, j + 2);
          if (slice.length >= 1024) {
            return slice;
          }
          break;
        }
        j++;
      }
      i = j + 1;
    } else {
      i++;
    }
  }

  return null;
}

parentPort.on('message', async (task) => {
  const { id, abs, tmp, isPreview, vf, ffmpegBin } = task;
  try {
    let inputBuf = await fsp.readFile(abs);

    if (!isPreview) {
      // 1. Cố gắng trích xuất trực tiếp ảnh Thumbnail JPEG nhúng (siêu tốc < 0.2ms, 0% CPU, 0 RAM)
      const embeddedThumb = findAnyEmbeddedJpeg(inputBuf);
      if (embeddedThumb && embeddedThumb.length > 0) {
        if (embeddedThumb.length <= 150 * 1024 || !ffmpegBin) {
          await fsp.writeFile(tmp, embeddedThumb);
        } else {
          const tmpFull = tmp + '.full-' + Math.random().toString(36).slice(2, 6) + '.jpg';
          await fsp.writeFile(tmpFull, embeddedThumb);
          const args = ['-hide_banner', '-loglevel', 'error', '-nostdin', '-y', '-i', tmpFull, '-vf', vf || "scale='min(160,iw)':'min(160,ih)':force_original_aspect_ratio=decrease", '-q:v', '7', '-f', 'image2', tmp];
          await new Promise((resolve) => {
            execFile(ffmpegBin, args, { windowsHide: true, timeout: 3000 }, () => resolve());
          });
          try { await fsp.unlink(tmpFull); } catch {}
        }
        if (fs.existsSync(tmp)) {
          inputBuf = null;
          parentPort.postMessage({ id, ok: true });
          return;
        }
      }
    }

    // 2. Nếu không có thumbnail nhúng, dùng heic-convert với chất lượng nén nhẹ để tránh tốn RAM
    if (!heicConvert) {
      inputBuf = null;
      parentPort.postMessage({ id, ok: false, error: 'heic-convert missing' });
      return;
    }

    const outputBuf = await heicConvert({
      buffer: inputBuf,
      format: 'JPEG',
      quality: isPreview ? 0.70 : 0.20
    });
    inputBuf = null;

    if (!outputBuf || !outputBuf.length) {
      parentPort.postMessage({ id, ok: false, error: 'empty decode' });
      return;
    }

    if (isPreview || !ffmpegBin) {
      await fsp.writeFile(tmp, outputBuf);
    } else {
      const tmpFull = tmp + '.full-' + Math.random().toString(36).slice(2, 6) + '.jpg';
      await fsp.writeFile(tmpFull, outputBuf);
      const args = ['-hide_banner', '-loglevel', 'error', '-nostdin', '-y', '-i', tmpFull, '-vf', vf || "scale='min(160,iw)':'min(160,ih)':force_original_aspect_ratio=decrease", '-q:v', '7', '-f', 'image2', tmp];
      await new Promise((resolve) => {
        execFile(ffmpegBin, args, { windowsHide: true, timeout: 6000 }, () => resolve());
      });
      try { await fsp.unlink(tmpFull); } catch {}
    }

    const ok = fs.existsSync(tmp);
    parentPort.postMessage({ id, ok });
  } catch (err) {
    parentPort.postMessage({ id, ok: false, error: err && err.message });
  }
});
