const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'CWDatacenter/Resources/Web/app.js'), 'utf8');
const music = fs.readFileSync(path.join(root, 'CWDatacenter/ViewControllers/MusicPlayerController.swift'), 'utf8');
const plist = fs.readFileSync(path.join(root, 'CWDatacenter/Info.plist'), 'utf8');

assert.match(app, /function pauseOverviewThumbnailWork\(\)/);
assert.match(app, /function resumeOverviewThumbnailWork\(\)/);
assert.match(app, /window\.CWOverviewThumbnailLoaded/);
assert.match(app, /function armOverviewThumbnailWatchdogs\(box\)/);
assert.match(app, /if \(document\.hidden\) return;/);
assert.match(app, /Promise\.all\(\[worker\(\), worker\(\), worker\(\)\]\)/);
assert.match(music, /item\.preferredForwardBufferDuration = 60/);
assert.match(music, /AVAudioSession\.interruptionNotification/);
assert.match(music, /AVAudioSession\.mediaServicesWereResetNotification/);
assert.match(music, /UIApplication\.didEnterBackgroundNotification/);
assert.match(music, /private func scheduleStalledRecovery\(\)/);
assert.match(plist, /<string>audio<\/string>/);
console.log('PASS iOS 1.6.52 thumbnail recovery and background audio safeguards');
