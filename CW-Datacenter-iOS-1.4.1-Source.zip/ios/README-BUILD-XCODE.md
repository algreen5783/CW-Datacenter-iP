# Build CW Datacenter iOS 1.4.1 bằng Xcode

1. Chép hoặc giải nén toàn bộ thư mục `ios` sang máy Mac.
2. Mở `CWDatacenter.xcodeproj` bằng Xcode.
3. Chọn target `CWDatacenter`, mở `Signing & Capabilities`, rồi chọn Apple Development Team của bạn.
4. Giữ bundle identifier `com.cw.datacenter.ios` nếu tài khoản Apple của bạn đã sở hữu identifier này; nếu chưa, đổi sang identifier duy nhất của bạn.
5. Chọn iPhone thật để thử nghiệm. Ứng dụng hỗ trợ từ iOS 14.0.
6. Build bằng `Product > Build`; tạo bản phát hành bằng `Product > Archive`.

## Test đồng bộ Camera

- Đăng nhập Host bằng tài khoản `admin` hoặc `editor`; tài khoản `viewer` không có quyền upload.
- Cấp quyền truy cập đầy đủ Thư viện ảnh khi iOS hỏi.
- Mở tab Đồng bộ, bật/tắt video theo nhu cầu rồi bắt đầu Sao lưu Camera.
- Thử một ảnh, một video lớn và thử ngắt Wi-Fi giữa chừng. Khi kết nối lại/chạy lại, Host phải trả offset để upload tiếp thay vì tải lại từ đầu.

Không cần sửa hoặc build lại Host để dùng cơ chế chunked upload, vì API này đã có trong Host 1.4.0.
