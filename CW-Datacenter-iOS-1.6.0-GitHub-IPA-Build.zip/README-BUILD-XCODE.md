# Build CW Datacenter iOS 1.6.0

## Build IPA bằng GitHub Actions (không cần máy Mac)

### Cách khuyên dùng

1. Giải nén gói ZIP trên máy tính.
2. Đưa **toàn bộ nội dung vừa giải nén** lên thư mục gốc của repository. Khi đó `.github/workflows/build-ipa.yml`, `CWDatacenter` và `CWDatacenter.xcodeproj` phải nằm ngay ở root.
3. Thay workflow cũ có bước `Extract Source Zip` bằng workflow nằm trong gói 1.6.0 này. Workflow mới build trực tiếp source ở root và không còn phụ thuộc thư mục `ios` trung gian.
4. Mở tab **Actions** > **Build CW Datacenter iOS 1.6.0 IPA** > **Run workflow**.
5. Khi job hoàn tất, tải artifact `CW-Datacenter-iOS-1.6.0-unsigned`.

Artifact chứa `CW-Datacenter-iOS-1.6.0-unsigned.ipa` và checksum SHA-256. Tên artifact được đọc trực tiếp từ phiên bản bên trong app đã build để tránh trả nhầm tên phiên bản cũ.

IPA từ workflow là bản **unsigned**. Cần ký bằng chứng chỉ/provisioning profile của bạn trước khi cài lên iPhone, hoặc dùng công cụ sideload có hỗ trợ ký.

## Build/ký bằng Xcode

1. Mở `CWDatacenter.xcodeproj` bằng Xcode.
2. Chọn target **CWDatacenter** > **Signing & Capabilities**.
3. Chọn Team và Bundle Identifier thuộc tài khoản Apple Developer của bạn.
4. Chọn thiết bị hoặc **Any iOS Device (arm64)** rồi **Product > Archive**.
5. Trong Organizer, dùng **Distribute App** để xuất IPA đã ký.

## Kiểm tra bắt buộc

- Phiên bản app: `1.6.0` (build `10600`).
- Trong app bundle phải có `Web/index.html` và `Web/app.js`, đều mang marker `1.6.0`.
- Quyền Photos và Local Network phải còn trong `Info.plist`.
- Lần đầu dùng Đồng bộ, cấp quyền **Tất cả ảnh** (hoặc lựa chọn ảnh mong muốn nếu dùng quyền giới hạn).

Xem chi tiết thay đổi trong `CHANGELOG-1.6.0.md`.
