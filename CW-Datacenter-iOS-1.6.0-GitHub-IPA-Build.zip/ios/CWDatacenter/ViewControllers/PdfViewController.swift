﻿import UIKit
import PDFKit

class PdfViewController: UIViewController {

    private let urlString: String
    private let titleText: String

    private var pdfView: PDFView!
    private var activityIndicator: UIActivityIndicatorView!
    private var pageLabel: UILabel!
    private var localPdfUrl: URL?

    init(url: String, titleText: String) {
        self.urlString = url
        self.titleText = titleText
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = titleText
        view.backgroundColor = .systemBackground

        setupNavBar()
        setupPDFView()
        setupActivityIndicator()
        loadPDF()
    }

    private func setupNavBar() {
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Đóng", style: .plain, target: self, action: #selector(onCloseTapped))
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .action, target: self, action: #selector(onShareTapped))
    }

    private func setupPDFView() {
        pdfView = PDFView(frame: view.bounds)
        pdfView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        pdfView.autoScales = true
        pdfView.displayMode = .singlePageContinuous
        pdfView.displayDirection = .vertical
        view.addSubview(pdfView)

        NotificationCenter.default.addObserver(self, selector: #selector(onPageChanged), name: .PDFViewPageChanged, object: pdfView)

        pageLabel = UILabel()
        pageLabel.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        pageLabel.textColor = .white
        pageLabel.font = UIFont.systemFont(ofSize: 12.5, weight: .semibold)
        pageLabel.textAlignment = .center
        pageLabel.layer.cornerRadius = 12
        pageLabel.layer.masksToBounds = true
        pageLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(pageLabel)

        NSLayoutConstraint.activate([
            pageLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            pageLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16),
            pageLabel.heightAnchor.constraint(equalToConstant: 26),
            pageLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 90)
        ])
    }

    private func setupActivityIndicator() {
        activityIndicator = UIActivityIndicatorView(style: .large)
        activityIndicator.center = view.center
        activityIndicator.hidesWhenStopped = true
        view.addSubview(activityIndicator)
    }

    private func loadPDF() {
        guard let url = URL(string: urlString) else { return }
        activityIndicator.startAnimating()

        if url.isFileURL {
            if let doc = PDFDocument(url: url) {
                pdfView.document = doc
                localPdfUrl = url
                updatePageCount()
            }
            activityIndicator.stopAnimating()
            return
        }

        var req = URLRequest(url: url)
        if !LocalProxy.shared.token.isEmpty {
            req.setValue("Bearer " + LocalProxy.shared.token, forHTTPHeaderField: "Authorization")
        }

        URLSession.shared.downloadTask(with: req) { [weak self] tempUrl, _, error in
            DispatchQueue.main.async {
                self?.activityIndicator.stopAnimating()
                guard let self = self, let tUrl = tempUrl, error == nil else { return }
                let dst = FileManager.default.temporaryDirectory.appendingPathComponent("doc_\(UUID().uuidString).pdf")
                try? FileManager.default.copyItem(at: tUrl, to: dst)
                self.localPdfUrl = dst
                if let doc = PDFDocument(url: dst) {
                    self.pdfView.document = doc
                    self.updatePageCount()
                }
            }
        }.resume()
    }

    @objc private func onPageChanged() {
        updatePageCount()
    }

    private func updatePageCount() {
        guard let doc = pdfView.document, let cur = pdfView.currentPage else {
            pageLabel.isHidden = true
            return
        }
        pageLabel.isHidden = false
        let curIdx = doc.index(for: cur) + 1
        let total = doc.pageCount
        pageLabel.text = " Trang \(curIdx) / \(total) "
    }

    @objc private func onShareTapped() {
        guard let url = localPdfUrl else { return }
        let activityVc = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        present(activityVc, animated: true)
    }

    @objc private func onCloseTapped() {
        dismiss(animated: true)
    }
}