import Foundation
import UIKit

enum AppLogLevel: String {
    case debug = "DEBUG"
    case info = "INFO"
    case warning = "WARN"
    case error = "ERROR"
}

final class AppLogger {
    static let shared = AppLogger()

    private let queue = DispatchQueue(label: "com.cw.datacenter.app-log", qos: .utility)
    private let maxFileSize: UInt64 = 2 * 1024 * 1024
    private let maximumExportBytes: UInt64 = 768 * 1024
    private let formatter: ISO8601DateFormatter = {
        let value = ISO8601DateFormatter()
        value.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return value
    }()

    private let directoryURL: URL
    private let currentURL: URL
    private let previousURL: URL

    private init() {
        let base = FileManager.default.urls(for: .libraryDirectory, in: .userDomainMask).first!
        directoryURL = base.appendingPathComponent("CWDatacenterLogs", isDirectory: true)
        currentURL = directoryURL.appendingPathComponent("cw-datacenter.log")
        previousURL = directoryURL.appendingPathComponent("cw-datacenter.previous.log")
        try? FileManager.default.createDirectory(at: directoryURL, withIntermediateDirectories: true)
    }

    func bootstrap() {
        let defaults = UserDefaults.standard
        if defaults.bool(forKey: "cw_log_session_active") {
            log(.warning, category: "CRASH", "Phiên chạy trước kết thúc bất thường hoặc bị iOS cưỡng chế đóng")
        }
        defaults.set(true, forKey: "cw_log_session_active")
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "?"
        let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "?"
        log(.info, category: "APP", "Khởi động CW Datacenter iOS \(version) (\(build)); iOS \(UIDevice.current.systemVersion); model=\(UIDevice.current.model)")
    }

    func markCleanTermination() {
        UserDefaults.standard.set(false, forKey: "cw_log_session_active")
        log(.info, category: "LIFECYCLE", "Ứng dụng kết thúc bình thường")
    }

    func log(
        _ level: AppLogLevel = .info,
        category: String,
        _ message: String,
        file: String = #fileID,
        function: String = #function,
        line: Int = #line
    ) {
        let safeMessage = redact(message.replacingOccurrences(of: "\n", with: " "))
        let source = URL(fileURLWithPath: file).lastPathComponent
        queue.async { [weak self] in
            guard let self = self else { return }
            self.rotateIfNeeded()
            let timestamp = self.formatter.string(from: Date())
            let entry = "[\(timestamp)] [\(level.rawValue)] [\(category)] \(safeMessage) (\(source):\(line) \(function))\n"
            self.append(Data(entry.utf8))
        }
    }

    func recentText(completion: @escaping (String, Int64) -> Void) {
        queue.async { [weak self] in
            guard let self = self else { return }
            let current = self.tail(of: self.currentURL, maximumBytes: self.maximumExportBytes)
            let previous = self.tail(of: self.previousURL, maximumBytes: self.maximumExportBytes / 2)
            var data = Data()
            data.append(previous)
            data.append(current)
            let text = String(data: data, encoding: .utf8) ?? "Không đọc được dữ liệu nhật ký."
            DispatchQueue.main.async { completion(text, Int64(data.count)) }
        }
    }

    func clear(completion: (() -> Void)? = nil) {
        queue.async { [weak self] in
            guard let self = self else { return }
            try? FileManager.default.removeItem(at: self.currentURL)
            try? FileManager.default.removeItem(at: self.previousURL)
            self.append(Data("[Nhật ký đã được xóa]\n".utf8))
            DispatchQueue.main.async { completion?() }
        }
    }

    func makeExportFile(completion: @escaping (URL?) -> Void) {
        recentText { text, _ in
            let stamp = DateFormatter.localizedString(from: Date(), dateStyle: .short, timeStyle: .medium)
                .replacingOccurrences(of: "/", with: "-")
                .replacingOccurrences(of: ":", with: "-")
                .replacingOccurrences(of: " ", with: "_")
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("CW-Datacenter-iOS-1.5.5-\(stamp).log")
            do {
                guard let data = text.data(using: .utf8) else {
                    completion(nil)
                    return
                }
                try data.write(to: url, options: .atomic)
                completion(url)
            } catch {
                completion(nil)
            }
        }
    }

    private func append(_ data: Data) {
        if !FileManager.default.fileExists(atPath: currentURL.path) {
            FileManager.default.createFile(atPath: currentURL.path, contents: nil)
        }
        guard let handle = try? FileHandle(forWritingTo: currentURL) else { return }
        defer { try? handle.close() }
        do {
            try handle.seekToEnd()
            try handle.write(contentsOf: data)
        } catch { }
    }

    private func rotateIfNeeded() {
        guard let size = (try? currentURL.resourceValues(forKeys: [.fileSizeKey]).fileSize), UInt64(size) >= maxFileSize else { return }
        try? FileManager.default.removeItem(at: previousURL)
        try? FileManager.default.moveItem(at: currentURL, to: previousURL)
    }

    private func tail(of url: URL, maximumBytes: UInt64) -> Data {
        guard let handle = try? FileHandle(forReadingFrom: url) else { return Data() }
        defer { try? handle.close() }
        do {
            let end = try handle.seekToEnd()
            try handle.seek(toOffset: end > maximumBytes ? end - maximumBytes : 0)
            return try handle.readToEnd() ?? Data()
        } catch {
            return Data()
        }
    }

    private func redact(_ value: String) -> String {
        var result = value
        result = result.replacingOccurrences(of: "Bearer\\s+[A-Za-z0-9._~+\\-/=]+", with: "Bearer <redacted>", options: .regularExpression)
        result = result.replacingOccurrences(of: "(?i)(token|password|pass|authorization)\\s*[:=]\\s*[^,;\\s]+", with: "$1=<redacted>", options: .regularExpression)
        return result
    }
}
