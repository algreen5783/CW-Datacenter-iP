# CW Datacenter iOS 1.5.9

- Nút tải lên cho phép chọn nhiều tệp, ảnh/video hoặc chọn cả thư mục từ Files.
- Upload thư mục giữ nguyên folder mẹ, folder con và đường dẫn của các tệp.
- Đưa mục Thông tin xuống cuối bảng tác vụ, dưới mục Xóa.
