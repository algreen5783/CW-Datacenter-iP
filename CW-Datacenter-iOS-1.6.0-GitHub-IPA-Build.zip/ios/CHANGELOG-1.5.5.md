# CW Datacenter iOS 1.5.5

- Trình xem ảnh có Yêu thích, Tải về Thư viện ảnh, Chia sẻ và Xóa, theo bố cục gần bản Tablet.
- Trình phát nhạc hiển thị toàn bộ bài nhạc trong cùng thư mục, cho phép chọn bài và tiếp tục hỗ trợ next/back/phát nền.
- Đồng bộ marker Web/native, workflow GitHub Actions, marketing version `1.5.5` và build `10505`.
