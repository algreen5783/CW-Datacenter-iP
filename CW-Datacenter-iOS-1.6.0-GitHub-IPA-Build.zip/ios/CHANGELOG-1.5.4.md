# CW Datacenter iOS 1.5.4

## Sửa đồng bộ Photos/iCloud

- Không lặp lại ba lần cùng một yêu cầu khi iCloud trả `CloudPhotoLibraryErrorDomain 1005`.
- Khi không lấy được resource gốc, ưu tiên bản hiện tại do Photos quản lý rồi mới thử lại bản gốc.
- Áp dụng fallback riêng cho ảnh và video, cho phép Photos tải dữ liệu từ iCloud và báo tiến độ chi tiết trong tab Nhật ký.
- Giữ luồng xử lý tuần tự để tránh tăng RAM khi thư viện có hàng nghìn ảnh/video.

## Sửa trình phát nhạc

- Sửa lỗi playlist từ Host bị loại bỏ trước khi gửi sang native player.
- Sửa `OSStatus -50`: không truyền tùy chọn `allowAirPlay`/`defaultToSpeaker` không hợp lệ với audio session `.playback`.
- Chỉ kích hoạt audio session khi bắt đầu phát, vẫn hỗ trợ phát nền và khóa màn hình.
- Gửi token cả trong URL và Authorization header để AVPlayer stream ổn định hơn từ Host.

## Phiên bản

- Marketing version: `1.5.4`
- Build: `10504`
- Web/native asset marker: `1.5.4`
