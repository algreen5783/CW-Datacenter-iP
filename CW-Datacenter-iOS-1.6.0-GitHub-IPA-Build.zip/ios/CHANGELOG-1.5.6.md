# CW Datacenter iOS 1.5.6

- Upload Photos/video dùng chunk 256 KiB và timeout riêng 200 giây, tiếp tục resume theo offset Host.
- Watchdog đồng bộ thư mục chỉ kích hoạt sau 10 phút không có byte tiến triển, không đánh lỗi theo tổng thời gian file lớn.
- Sau khi Host xác nhận hoàn tất upload, asset được đưa vào danh sách xóa an toàn.
- Khi quét lại, chỉ tự xóa asset có đúng đường dẫn và đúng kích thước đã ghi nhận trên Host.
- PhotoKit xóa theo lô vào album **Đã xóa gần đây**, không xóa vĩnh viễn.
- Ghi log riêng `PHOTOS_DELETE` cho kết quả xóa để dễ chẩn đoán.
