# CW Datacenter iOS 1.6.0

- Không tự động upload thư viện khi mở app; chỉ đồng bộ sau khi người dùng nhấn nút.
- Thêm ba chế độ: Ảnh và video, Chỉ ảnh, Chỉ video.
- Khóa nguyên tử một phiên camera backup để ngăn nhiều lượt chạy chồng nhau.
- Dùng định danh PHAsset ổn định trong tên/nhóm file mới, không còn phụ thuộc vị trí media trong thư viện.
- Giữ tương thích và nhận diện file do các bản 1.5.9 trở về trước đã upload.
- Đối chiếu đường dẫn và dung lượng record đã xác minh trước khi bỏ qua upload.
- Quét lại Host trước khi thông báo đã đồng bộ toàn bộ.
- Không ép giao diện thành 100% nếu Host vẫn còn thiếu file.
- Sửa nháy tab Đồng bộ bằng cách chỉ cập nhật các thành phần tiến độ thay vì dựng lại toàn bộ danh sách.
- Mở rộng vùng bấm nút quay lại và căn giữa biểu tượng mũi tên.
- GitHub Actions đọc phiên bản từ app đã compile và xuất đúng tên `CW-Datacenter-iOS-1.6.0-unsigned.ipa`.
