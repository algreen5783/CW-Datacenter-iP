# Build CW Datacenter iOS 1.5.6

## Build IPA bằng GitHub Actions (không cần máy Mac)

### Repository đang có bước `Extract Source Zip`

Đây là kiểu repository bạn đang sử dụng. Không giải nén gói trên máy tính:

1. Xóa file ZIP iOS cũ khỏi repository để workflow không chọn nhầm.
2. Tải nguyên file `CW-Datacenter-iOS-1.5.6-GitHub-IPA-Build.zip` lên thư mục gốc.
3. Workflow giải nén sẽ tạo `ios/CWDatacenter` và `ios/CWDatacenter.xcodeproj`.
4. Chạy lại workflow build hiện có.

### Repository mới, không có bước giải nén ZIP

1. Giải nén gói ZIP trên máy tính.
2. Mở thư mục `ios` vừa giải nén.
3. Đưa **nội dung bên trong `ios`** lên thư mục gốc của repository. Khi đó `.github/workflows/build-ipa.yml`, `CWDatacenter` và `CWDatacenter.xcodeproj` phải nằm ngay ở root.
4. Mở tab **Actions** > **Build CW Datacenter iOS 1.5.6 IPA** > **Run workflow**.
5. Khi job hoàn tất, tải artifact `CW-Datacenter-iOS-1.5.6-unsigned`.

Artifact chứa `CW-Datacenter-iOS-1.5.6-unsigned.ipa` và checksum SHA-256.

IPA từ workflow là bản **unsigned**. Cần ký bằng chứng chỉ/provisioning profile của bạn trước khi cài lên iPhone, hoặc dùng công cụ sideload có hỗ trợ ký.

## Build/ký bằng Xcode

1. Mở `CWDatacenter.xcodeproj` bằng Xcode.
2. Chọn target **CWDatacenter** > **Signing & Capabilities**.
3. Chọn Team và Bundle Identifier thuộc tài khoản Apple Developer của bạn.
4. Chọn thiết bị hoặc **Any iOS Device (arm64)** rồi **Product > Archive**.
5. Trong Organizer, dùng **Distribute App** để xuất IPA đã ký.

## Kiểm tra bắt buộc

- Phiên bản app: `1.5.6` (build `10506`).
- Trong app bundle phải có `Web/index.html` và `Web/app.js`, đều mang marker `1.5.6`.
- Quyền Photos và Local Network phải còn trong `Info.plist`.
- Lần đầu dùng Đồng bộ, cấp quyền **Tất cả ảnh** (hoặc lựa chọn ảnh mong muốn nếu dùng quyền giới hạn).

Xem chi tiết thay đổi trong `CHANGELOG-1.5.6.md`.
