# CW Datacenter iOS 1.6.58

- Mục `Sắp xếp theo Ngày` ở tab Tổng quan mở bộ chọn ngày dạng Apple Photos, ba ngày mỗi hàng.
- Mỗi ngày có thumbnail đại diện từ cache và số lượng ảnh/video.
- Chọn ngày để lọc thư viện; `Tất cả ngày` quay lại toàn bộ nội dung.
- Bộ lọc ngày được lưu riêng theo thư viện thiết bị đang xem.
