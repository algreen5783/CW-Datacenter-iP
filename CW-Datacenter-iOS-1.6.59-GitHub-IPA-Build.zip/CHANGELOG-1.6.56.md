# CW Datacenter iOS 1.6.56

- Nút Đồng bộ quét lại thư viện Photos và đối chiếu với Host.
- Khi ảnh/video gốc còn trên iPhone và Host có bản tên cũ `_cw_` hoặc `__cw_`, ứng dụng tải file gốc với tên gốc lên trước, xác nhận upload thành công rồi mới xóa bản tên cũ.
- File tên cũ trên Host được giữ nguyên nếu không còn file gốc tương ứng trên iPhone.
- Nếu bước xóa bản tên cũ bị gián đoạn, đường dẫn được lưu lại để thử dọn ở lần đồng bộ sau mà không tải trùng bản gốc; bản gốc đã tải lên không bị xóa.
