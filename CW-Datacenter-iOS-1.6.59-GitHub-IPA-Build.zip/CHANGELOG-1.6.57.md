# CW Datacenter iOS 1.6.57

- Trình xem ảnh dùng bảng thông tin riêng đồng nhất với giao diện app, không dùng hộp thoại mặc định iOS.
- Bảng thông tin trong và ngoài trình xem ảnh hiển thị dung lượng, kích thước pixel, ngày chụp và vị trí khi dữ liệu có sẵn.
- Nút **Bỏ chọn** có biểu tượng SVG rõ ràng.

