const assert = require('assert');
const fs = require('fs');
const path = require('path');

const app = fs.readFileSync(path.resolve(__dirname, '../CWDatacenter/Resources/Web/app.js'), 'utf8');
const imageViewer = fs.readFileSync(path.resolve(__dirname, '../CWDatacenter/ViewControllers/ImageViewController.swift'), 'utf8');
assert.match(app, /\[\['size', 'Dung lượng'\]\]\.forEach/);
assert.doesNotMatch(app, /\[\['name', 'Tên'\], \['size', 'Dung lượng'\]\]/);
assert.match(app, /!String\(savedSort\)\.startsWith\('name-'\)/);
assert.match(app, /Sắp xếp theo Ngày/);
assert.match(app, /Sắp xếp theo Thư mục/);
assert.match(app, /function bindInfoCopyHold\(element, label, value\)/);
assert.match(app, /setTimeout\(async \(\) => \{[\s\S]*copyToClipboard\(text\)[\s\S]*\}, 1000\)/);
assert.match(imageViewer, /copyHold\.minimumPressDuration = 1\.0/);
assert.match(imageViewer, /UIPasteboard\.general\.string = value/);
assert.match(imageViewer, /showInfoCopyToast/);

console.log('PASS iOS 1.6.59 simplified Overview sorting');
