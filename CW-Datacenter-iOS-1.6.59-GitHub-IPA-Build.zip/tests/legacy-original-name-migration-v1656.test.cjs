const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const swift = fs.readFileSync(path.join(root, 'CWDatacenter', 'ViewControllers', 'MainViewController.swift'), 'utf8');
const plist = fs.readFileSync(path.join(root, 'CWDatacenter', 'Info.plist'), 'utf8');

assert.match(swift, /private func isLegacyTaggedCameraName/);
assert.match(swift, /\^\\\(escapedStem\)__\?cw_/);
assert.match(swift, /guard let legacyPath = item\.legacyHostPath else/);
assert.match(swift, /guard normalizedPath\.lowercased\(\)\.hasPrefix\(normalizedDevice\.lowercased\(\) \+ "\/"\)/);
assert.match(swift, /self\.deleteMigratedCameraHostFile/);
assert.match(swift, /deleteMigratedCameraHostFileNow/);
assert.match(swift, /không upload trùng file gốc/);

const uploadSuccess = swift.indexOf('guard ok else');
const legacyDelete = swift.indexOf('self.deleteMigratedCameraHostFile', uploadSuccess);
assert(uploadSuccess >= 0 && legacyDelete > uploadSuccess, 'legacy file must only be deleted after upload succeeds');

const assetLoop = swift.indexOf('for index in 0..<totalAssets');
const migrationDetection = swift.indexOf('let legacyPath = self.isLegacyTaggedCameraName', assetLoop);
assert(assetLoop >= 0 && migrationDetection > assetLoop, 'migration detection must be scoped to local Photos assets');

assert(plist.includes('<string>1.6.59</string>'));
assert(plist.includes('<string>10659</string>'));
console.log('PASS iOS 1.6.59 safe legacy-to-original migration');
