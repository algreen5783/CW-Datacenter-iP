const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const web = fs.readFileSync(path.join(root, 'CWDatacenter', 'Resources', 'Web', 'app.js'), 'utf8');
const main = fs.readFileSync(path.join(root, 'CWDatacenter', 'ViewControllers', 'MainViewController.swift'), 'utf8');
const image = fs.readFileSync(path.join(root, 'CWDatacenter', 'ViewControllers', 'ImageViewController.swift'), 'utf8');

test('sort sheet exposes day, size and folder choices while folder picker scrolls separately', () => {
  assert.match(web, /function openOverviewGalleryFolderPicker\(\)/);
  assert.match(web, /max-height:65dvh;overflow-y:auto/);
  assert.match(web, /Sắp xếp theo Thư mục/);
});

test('camera upload request helper is active after the disabled legacy block', () => {
  assert.match(main, /#endif\s+\/\/\/ Synchronous camera-upload helper[\s\S]+?private func performCameraRequest\(/);
});

test('image viewer exposes metadata including dimensions and GPS when available', () => {
  assert.match(image, /@objc private func onInfoTapped\(\)/);
  assert.match(image, /kCGImagePropertyPixelWidth/);
  assert.match(image, /kCGImagePropertyGPSDictionary/);
  assert.match(image, /Địa điểm/);
});
