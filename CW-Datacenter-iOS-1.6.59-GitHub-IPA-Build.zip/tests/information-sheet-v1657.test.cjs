const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const viewer = fs.readFileSync(path.join(root, 'CWDatacenter/ViewControllers/ImageViewController.swift'), 'utf8');
const app = fs.readFileSync(path.join(root, 'CWDatacenter/Resources/Web/app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'CWDatacenter/Resources/Web/index.html'), 'utf8');

test('photo information uses an app-owned sheet with pixel dimensions', () => {
  assert.match(viewer, /private func presentAppInfoSheet\(rows:/);
  assert.match(viewer, /rows\.append\(\("Kích thước", "\\\(width\) × \\\(height\) px"\)\)/);
  const infoBlock = viewer.slice(viewer.indexOf('private func presentImageInfo'), viewer.indexOf('private func numericValue'));
  assert.doesNotMatch(infoBlock, /UIAlertController/);
});

test('selection actions expose the SVG deselect icon', () => {
  assert.match(app, /'Bỏ chọn', \{ icon: 'i-deselect'/);
  assert.match(html, /symbol id="i-deselect"/);
});

