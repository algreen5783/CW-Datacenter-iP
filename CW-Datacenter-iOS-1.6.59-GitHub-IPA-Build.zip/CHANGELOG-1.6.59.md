# CW Datacenter iOS 1.6.59

- Menu sắp xếp ở tab Tổng quan chỉ còn Ngày, Dung lượng và Thư mục.
- Tùy chọn sắp xếp theo Tên đã được gỡ khỏi giao diện.
- Thiết lập sắp xếp theo Tên đã lưu từ bản cũ được tự động chuyển về Ngày mới nhất.
- Nhấn giữ một dòng trong bảng Thông tin ảnh/video 1 giây để sao chép giá trị; có phản hồi rung và thông báo xác nhận.
