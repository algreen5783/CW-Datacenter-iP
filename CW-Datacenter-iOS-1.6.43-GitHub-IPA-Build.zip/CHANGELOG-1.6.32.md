# CW Datacenter iOS 1.6.32

- Thay hàng công cụ của trình phát video bằng bốn nút: Tải về, Yêu thích, Chia sẻ và Xóa.
- Tải video về vùng tệp cục bộ của ứng dụng và hiển thị tiến trình trong tab Truyền tải.
- Chia sẻ chuẩn iOS bằng file video cục bộ, tương thích các ứng dụng nhận video như Facebook.
- Nút Yêu thích cập nhật ngay tab Yêu thích và hiển thị trạng thái trái tim hiện tại.
- Nút Xóa có bước xác nhận, chuyển video vào Thùng rác của Host và dọn mục khỏi danh sách gần đây/yêu thích.
- Giữ nguyên toàn bộ bản sửa kết nối Tailscale và thumbnail của 1.6.31.
