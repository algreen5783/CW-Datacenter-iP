# CW Datacenter iOS 1.6.4

- Xem HEIC/HEIF chất lượng đầy đủ qua Host 1.5.12.
- Tải trước tối đa bốn ảnh kế cận ở mỗi phía và gộp các yêu cầu tải trùng.
- Cache ảnh của trình xem được giới hạn 128 MB / 9 ảnh và xóa khi đóng trình xem.
- Nút lên đầu danh sách có thể kéo tới vị trí thuận tay và ghi nhớ vị trí.
