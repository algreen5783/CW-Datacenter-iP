# iOS 1.6.43 (10643)

- Thêm nút SVG sắp xếp bên phải tìm kiếm ở Tổng quan: ngày mới/cũ, tên A–Z/Z–A, dung lượng lớn/nhỏ. Lưu lựa chọn theo tài khoản và Host.
- HEIC dùng bộ giải mã Image I/O trên iPhone, dự phòng JPEG từ Host nếu giải mã thất bại.
- JPG/PNG/WebP dùng ảnh xem trước vừa màn hình 1280–2048 px từ Host 1.5.47; thumbnail hiện trước, ảnh gốc dùng khi phóng to, tải hoặc chia sẻ.
- Kiểm tra giải mã thumbnail trước khi lưu/đánh dấu tải xong. Cache hỏng được thay riêng từng ảnh; giữ cache còn tốt.
- Khi Host không tạo được thumbnail HEIC, iPhone tải file gốc vào tệp tạm, tạo thumbnail JPEG 160 px và lưu cache bền vững.
- Giữ nguyên 5 ảnh/hàng, số ảnh tải trước, số luồng tải thumbnail và cơ chế phát video. Không sửa Android, TV, tablet hoặc client desktop.

Đã kiểm tra JavaScript trên Windows. Gói này là source/workflow, chưa phải IPA đã biên dịch; kiểm tra Swift và build IPA chạy trên Mac/GitHub Actions. Cần thử lại những file HEIC gặp lỗi trên iPhone thực tế.
