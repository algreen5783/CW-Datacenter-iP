# CW Datacenter iOS 1.6.26 (10626)

- Continue Watching hides videos located in password-protected drives, folders, and files, including stale local history.
- The Recent Folders "Xem tệp" action opens a popup list; protected folders require their password before opening.
- Updates and validates the unsigned IPA workflow for version 1.6.26 (10626).
- Keeps all iOS 1.6.25 Overview, playback, drive, transfer, and sync behavior.
