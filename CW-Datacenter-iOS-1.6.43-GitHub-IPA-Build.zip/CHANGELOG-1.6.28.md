# CW Datacenter iOS 1.6.28

- Thêm trình đọc EPUB không DRM, FB2, TXT, HTML/HTM và Markdown trong app.
- Có mục lục, tùy chỉnh kiểu đọc và đồng bộ vị trí đọc qua Host 1.5.40.
- Cập nhật workflow build IPA cho phiên bản 1.6.28 (build 10628).
