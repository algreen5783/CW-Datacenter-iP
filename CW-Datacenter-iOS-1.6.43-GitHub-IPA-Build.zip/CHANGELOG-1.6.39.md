# CW Datacenter iOS 1.6.39

- Sửa lỗi không mở được thư mục con trong ổ Đồng bộ theo tên thiết bị khi thư mục camera nằm trong một ổ đĩa Host khác.
- Luôn dùng đúng mã ổ đĩa và đường dẫn chuẩn do Host trả về cho thư mục, ảnh và video.
- Giữ trạng thái chọn “Đồng bộ (tên máy)” khi Host ánh xạ thư mục sang ổ lưu trữ vật lý.
