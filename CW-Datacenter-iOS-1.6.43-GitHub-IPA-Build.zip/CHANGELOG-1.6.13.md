# CW Datacenter iOS 1.6.13

- Thêm nút Chọn ổ đĩa trong thanh ổ đĩa.
- Popup hiển thị Thiết bị này, thư mục Đồng bộ iOS và toàn bộ ổ Host.
- Hiển thị tên ổ, dung lượng đã dùng/tổng dung lượng, dung lượng trống, trạng thái khả dụng và ổ đang chọn.
- Có nút đóng, Hủy và Chọn ổ này; tái sử dụng cơ chế chuyển ổ và mở khóa hiện có.

