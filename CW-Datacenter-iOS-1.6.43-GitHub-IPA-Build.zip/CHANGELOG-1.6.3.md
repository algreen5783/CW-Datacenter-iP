# CW Datacenter iOS 1.6.3

- Khi Host báo phiên upload không tồn tại (HTTP 404/410), ứng dụng tự khởi tạo lại phiên và tiếp tục đúng tệp đang đồng bộ thay vì bỏ qua sang tệp khác.
- Giới hạn tối đa 3 lần khôi phục phiên cho mỗi tệp để tránh lặp vô hạn khi Host có sự cố kéo dài.
- Xử lý lệch offset lúc hoàn tất bằng cách quay lại đúng offset Host cung cấp rồi gửi tiếp phần còn thiếu.
- Nhật ký ghi rõ số lần khôi phục, upload ID và offset để chẩn đoán khi cần.
- Dùng cùng Host 1.5.11 để Host phục hồi phiên upload từ tệp `.meta`/`.part` sau khi dịch vụ tự khởi động lại.
