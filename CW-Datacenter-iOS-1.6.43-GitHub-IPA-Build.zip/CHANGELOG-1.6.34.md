# CW Datacenter iOS 1.6.34

## Sửa tải video từ trình phát

- Nút Tải về không còn chỉ chép video vào Documents nội bộ rồi báo thành công.
- Sau khi tải đủ dữ liệu, app dùng PhotoKit để thêm video vào ứng dụng Ảnh của iOS.
- Chỉ báo thành công sau khi Thư viện ảnh xác nhận đã tạo video.
- Nếu chưa có quyền Ảnh, app hiển thị hướng dẫn cấp quyền và đánh dấu truyền tải là lỗi thay vì báo hoàn tất sai.

## Lịch sử truyền tải

- Tạo mục tải xuống trong tab Truyền tải ngay khi bấm Tải về trong trình phát.
- Đồng bộ trạng thái chờ, đang tải, tiến độ, hoàn tất và lỗi từ native về giao diện.
- Mục hoàn tất ghi rõ `Đã lưu vào ứng dụng Ảnh` và vẫn có thể mở bản video cục bộ.

## Phiên bản

- Marketing version: `1.6.34`
- Build: `10634`
- Chỉ thay đổi ứng dụng iOS; không cần cài lại Host.
