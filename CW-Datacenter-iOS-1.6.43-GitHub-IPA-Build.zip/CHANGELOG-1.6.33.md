# CW Datacenter iOS 1.6.33

## Tổng quan kiểu thư viện ảnh

- Thiết kế lại tab Tổng quan thành thư viện ảnh/video dạng lưới, tối ưu cho thao tác một tay trên iPhone.
- Chỉ lấy nội dung đồng bộ của đúng thiết bị đang cấu hình trong `Tên thiết bị/Images/Images_00x` và `Tên thiết bị/Videos/Videos_00x`.
- Nhóm ảnh/video theo ngày, có tìm kiếm, lọc Tất cả, Ảnh, Video và Yêu thích.
- Mở ảnh trực tiếp bằng trình xem ảnh và mở video trực tiếp bằng trình phát video hiện có.
- Không đưa nội dung thuộc ổ đĩa hoặc thư mục đã cấu hình khóa mật khẩu vào thư viện Tổng quan.

## Bộ nhớ đệm và hiệu năng

- Dùng chung đường dẫn thumbnail với tab Tệp và bộ nhớ đệm native của iOS.
- Thumbnail đã tải được lưu trong Application Support trên thiết bị; lần đăng nhập sau ưu tiên đọc lại từ cache trước khi tải mạng.
- Lưu chỉ mục thư viện theo Host, tài khoản và tên thiết bị để hiện danh sách cũ ngay trong lúc quét cập nhật nền.
- Tải thumbnail lười, giới hạn số thư mục quét song song và render từng đợt 120 mục để tránh giật khi thư viện lớn.
- Sau khi đồng bộ hoàn tất, thư viện Tổng quan tự quét lại.

## Phiên bản

- Marketing version: `1.6.33`
- Build: `10633`
- Chỉ thay đổi ứng dụng iOS; không cần cài lại Host.
