# CW Datacenter iOS 1.6.6

- Cố định chế độ thư viện thành 3 thumbnail vuông mỗi hàng ở màn hình dọc.
- Tất cả ô media và thư mục trong lưới đều giữ tỷ lệ 1:1.
- Yêu cầu thumbnail 360 x 360 từ Host để ảnh rõ trên màn hình mật độ điểm ảnh cao.
- Phiên bản ứng dụng: 1.6.6 (build 10606).
