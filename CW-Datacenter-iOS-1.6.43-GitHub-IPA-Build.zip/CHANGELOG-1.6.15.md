# CW Datacenter iOS 1.6.15

- Thêm tab Tổng quan và thanh điều hướng 5 mục giống Android Mobile.
- Gỡ tab Nhật ký khỏi giao diện; hệ thống ghi log nội bộ vẫn được giữ.
- Dừng và giải phóng trình phát nhạc, đóng mini-player trước khi mở video.
- Nâng cấp video player: giao diện điều khiển gọn, vuốt tua/độ sáng/âm lượng, tốc độ, tỷ lệ và phụ đề cùng tên trong thư mục.
- Phụ đề hỗ trợ chọn/tắt, chỉnh nhanh/chậm và cỡ chữ.
