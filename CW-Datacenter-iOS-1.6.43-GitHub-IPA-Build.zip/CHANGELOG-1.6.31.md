# CW Datacenter iOS 1.6.31

- Sửa proxy nội bộ gửi thiếu byte làm phần lớn thumbnail hỏng trên WebView.
- Tạo URL thumbnail bằng `URLComponents` để hỗ trợ ổn định tên file có dấu, khoảng trắng và ký tự đặc biệt.
- Dùng phiên URLSession riêng cho thumbnail, đi trực tiếp qua Tailscale và giới hạn kết nối hợp lý.
- Yêu cầu thumbnail đúng kích thước thay vì mặc định ảnh lớn hơn cần thiết.
- Tự thử lại tối đa hai lần khi tải thumbnail gặp lỗi tạm thời; chỉ hiện icon dự phòng sau khi thử lại thất bại.
- Giữ cache thumbnail trên đĩa để ảnh đã tải không phải lấy lại từ Host.
