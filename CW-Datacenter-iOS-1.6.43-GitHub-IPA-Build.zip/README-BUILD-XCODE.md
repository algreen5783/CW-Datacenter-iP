# Build CW Datacenter iOS 1.6.43 (10643)

## Thay đổi của bản này

Bản này sửa thumbnail HEIC/cache hỏng, mở ảnh bằng giải mã native và ảnh xem trước vừa màn hình, thêm sắp xếp theo ngày/tên/dung lượng ở Tổng quan. Cập nhật Host 1.5.47 để dùng ảnh xem trước và sửa cache phía máy chủ. Giữ nguyên các sửa lỗi Tailscale/ATS, bundle ID và cơ chế video. Không sửa Android hay client desktop.

## Build IPA bằng GitHub Actions

1. Upload **CW-Datacenter-iOS-1.6.43-GitHub-IPA-Build.zip** vào thư mục gốc repository. Không đổi tên ZIP và không dùng ZIP bản cũ cho lần build này.
2. Cập nhật file **.github/workflows/build-ipa.yml** bằng workflow đi kèm 1.6.43. Nếu chỉ upload workflow vào thư mục gốc, GitHub sẽ không chạy nó.
3. Mở **Actions → Build CW Datacenter iOS 1.6.43 IPA → Run workflow** trên nhánh vừa cập nhật.
4. Chờ toàn bộ job thành công rồi tải artifact **CW-Datacenter-iOS-1.6.43-unsigned**.
5. Trong artifact có **CW-Datacenter-iOS-1.6.43-unsigned.ipa** và mã SHA-256. IPA chưa ký, cần ký bằng phương thức bạn đang dùng trước khi cài.

Sửa lỗi upload IPA (1.6.43): workflow đã dùng chung IPA_BASENAME cho bước tạo file và upload. Nếu repository đang dùng `.github/workflows/build-ios.yml`, thay nội dung file đó bằng workflow mới, không tạo thêm workflow trùng. Upload lại ZIP đi kèm và chạy một lượt **Run workflow** mới trên nhánh đã cập nhật; **Re-run jobs** của lượt cũ vẫn dùng workflow cũ.

Nếu dùng source giải nén thay ZIP, mở `CWDatacenter.xcodeproj` trên Mac, chọn scheme CWDatacenter, cấu hình signing của bạn và build bằng Xcode. Deployment target giữ nguyên iOS 14.

## Kiểm tra tự động

Workflow kiểm tra cả source lẫn Info.plist **bên trong app đã build**, yêu cầu đúng phiên bản `1.6.43` / `10643` và có ngoại lệ HTTP cho Tailscale. Nếu thiếu ngoại lệ hoặc dùng nhầm source cũ, job phải dừng, không xuất IPA.

Các bước có thể chạy tại thư mục source:

```sh
python3 tests/check-tailscale-config.py
node --check CWDatacenter/Resources/Web/app.js
node --test tests/network-bridge.test.cjs
```

Trên Mac chạy thêm kiểm tra mã Swift phân loại lỗi:

```sh
xcrun swiftc CWDatacenter/Network/HostConnectionDiagnostics.swift tests/main.swift -o /tmp/cw-host-network-tests
/tmp/cw-host-network-tests
```

Workflow vẫn giữ build tuần tự, xuất nhật ký và xcresult trong artifact **CW-Datacenter-iOS-build-diagnostics** khi lỗi build.

## Kiểm tra trên iPhone sau khi cài

- Kiểm tra app hiển thị phiên bản **1.6.43** và Host **1.5.47**.
- Kiểm tra thumbnail HEIC từng bị lỗi; mở ảnh, phóng to, tải và chia sẻ ảnh gốc. Đăng xuất/đăng nhập lại để kiểm tra cache.
- Kiểm tra sáu lựa chọn sắp xếp bên phải ô tìm kiếm; ảnh/video phải theo đúng thứ tự và nhớ lựa chọn của tài khoản.
- Bật Tailscale, chọn Host `100.66.66.66`, cổng `8080`: trạng thái phải chuyển Trực tuyến.
- Đăng nhập bằng tài khoản đang dùng; thử cả thông báo khi nhập sai mật khẩu.
- Mở danh sách tệp, thumbnail, ảnh, video, PDF và thử tải một tệp nhỏ qua cùng IP Tailscale.
- Thử kết nối qua IP LAN như trước; thử ngắt mạng để kiểm tra thông báo không đánh đồng với lỗi ATS.

## Giới hạn xác minh

Gói này được sửa và kiểm tra cấu hình/JavaScript trên Windows. Chưa biên dịch Xcode, chưa tạo IPA và chưa chạy trên iPhone trong phiên làm việc này. Kiểm tra Swift và Info.plist của app đã biên dịch sẽ chạy khi bạn chạy workflow trên Mac/GitHub Actions.

Ngoại lệ mới áp dụng cho **IP Tailscale IPv4** trong dải đã nêu. Không mở rộng HTTP ra mọi website, không vô hiệu hóa xác minh chứng chỉ HTTPS và không thay đổi cơ chế video/download.
