# CW Datacenter iOS 1.6.8

- Sửa lưới nhiều file không còn co tất cả hàng vào một màn hình.
- Mỗi ô được tính kích thước vuông cố định theo chiều rộng cột; danh sách tăng chiều cao và cuộn dọc bình thường.
- Giảm mỗi đợt render xuống 12 mục (4 hàng) để khi kéo xuống mới tải dần phần tiếp theo.
- Đổi icon thư mục từ màu xám về màu vàng/cam.
- Thumbnail tiếp tục dùng kích thước 240×240.
- Phiên bản 1.6.8, build 10608.
