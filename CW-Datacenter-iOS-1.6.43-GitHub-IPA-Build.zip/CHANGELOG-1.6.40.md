# CW Datacenter iOS 1.6.40

- Thêm nút lên đầu trang cho thư viện ảnh/video ở tab Tổng quan.
- Nút hiện khi cuộn xuống, tự ẩn sau 2 giây không thao tác và hiện lại khi tiếp tục cuộn.
- Thêm thanh cuộn nhanh ở mép phải; giữ và kéo để đi nhanh tới vị trí bất kỳ trong thư viện.
- Thanh cuộn nhanh đồng bộ vị trí với nội dung, không tự ẩn trong lúc đang kéo và tự ẩn sau 2 giây khi thả tay.
- Các điều khiển nằm trên thanh tab dưới và tôn trọng vùng an toàn của iPhone/iPad.
- Giữ nguyên bản sửa điều hướng thư mục đồng bộ từ iOS 1.6.39.
