# CW Datacenter iOS 1.6.37

## Tải trước thumbnail ở Tổng quan

- Khi mở app vào Tổng quan, app tự quét danh sách ảnh/video đã đồng bộ và tải trước toàn bộ thumbnail, không cần đợi người dùng cuộn tới từng ảnh.
- Dùng hàng đợi giới hạn 3 yêu cầu đồng thời để không làm nghẽn proxy nội bộ hoặc máy Host.
- Thumbnail vẫn dùng kích thước 160 px và được lưu bền vững trong vùng Application Support của app trên iPhone/iPad.
- Mỗi file có dấu vân tay gồm đường dẫn, dung lượng và thời gian sửa. Chỉ file mới hoặc file đã thay đổi mới phải tạo/tải lại thumbnail.
- Trạng thái hoàn thành được ghi dần trong chỉ mục thư viện. Khi toàn bộ thumbnail đã có và không phát hiện file mới, hàng đợi tải nền không khởi chạy.
- Yêu cầu lỗi có thời gian chờ tối đa, thử lại giãn cách và tạm nghỉ 60 giây trước vòng tiếp theo, tránh tình trạng vài thumbnail lỗi làm cả hàng đợi đứng vĩnh viễn.
- Khi app hoạt động lại sau thời gian bị iOS tạm dừng, hàng đợi chưa hoàn tất sẽ tiếp tục.
- Khi người dùng chủ động xóa cache, trạng thái thumbnail được đặt lại đồng bộ với cache thật.

## Kế thừa từ 1.6.36

- Nút Play/Pause/Phát lại đã sửa; hai nút tua ±10 giây đã được bỏ.
- Đầu trang Tổng quan chỉ giữ ô tìm kiếm và các bộ lọc.

## Phiên bản

- Marketing version: `1.6.37`
- Build: `10637`
- Chỉ thay đổi app iOS; không thay đổi Host, Android, tablet hoặc desktop client.
