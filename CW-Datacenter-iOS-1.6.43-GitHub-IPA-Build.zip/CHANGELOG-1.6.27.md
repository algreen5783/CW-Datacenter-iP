# CW Datacenter iOS 1.6.27

- Remote PDFs now open progressively through Host byte-range streaming in WKWebView.
- The first page appears without waiting for the whole PDF to download.
- Nearby pages render lazily while the remaining data downloads in the background.
- Local PDFs keep using PDFKit; Share downloads a complete temporary copy only when requested.
