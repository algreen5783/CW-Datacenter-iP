# CW Datacenter iOS 1.6.12

- Upload và download file lớn theo từng phần, giữ offset để tiếp tục sau lỗi mạng/Host khởi động lại.
- Tăng số lần thử lại và timeout cho mạng LAN chập chờn; không nạp toàn bộ file lớn vào RAM.
- Các file được chọn hàng loạt chuyển sang trạng thái chờ và chạy tuần tự từng file một.
- Giữ phần tải dở trong Application Support để nút Thử lại tiếp tục thay vì tải lại từ đầu.
- Giữ nguyên tên artifact `CW-Datacenter-iOS-1.4.0-unsigned.ipa` để tương thích GitHub Actions hiện có; phiên bản thực trong app là 1.6.12 (10612).
