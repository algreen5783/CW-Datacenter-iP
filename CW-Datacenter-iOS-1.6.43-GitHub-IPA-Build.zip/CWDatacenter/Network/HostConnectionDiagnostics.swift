import Foundation

/// Keep the original transport failure separate from VPN/account failures.
/// Foundation-only so these messages can be tested without launching UIKit.
enum HostConnectionDiagnostics {
    static func message(for error: Error, url: URL) -> String {
        let failure = error as NSError
        let endpoint = (url.host ?? "Host") + (url.port.map { ":\($0)" } ?? "")
        if failure.domain == NSURLErrorDomain {
            switch failure.code {
            case NSURLErrorAppTransportSecurityRequiresSecureConnection:
                return "iOS chặn kết nối HTTP tới \(endpoint) (ATS -1022). Bản iOS đang cài cần được cập nhật cấu hình kết nối. Đây không phải lỗi tài khoản hay mật khẩu."
            case NSURLErrorTimedOut:
                return "Hết thời gian chờ phản hồi từ \(endpoint). Hãy kiểm tra đường truyền và thử lại."
            case NSURLErrorCannotFindHost, NSURLErrorDNSLookupFailed:
                return "Không tìm được địa chỉ máy chủ \(endpoint). Hãy kiểm tra IP hoặc tên máy chủ đã nhập."
            case NSURLErrorCannotConnectToHost:
                return "Không mở được kết nối tới \(endpoint). Hãy kiểm tra địa chỉ, cổng, dịch vụ Host và đường truyền Tailscale nếu đang sử dụng."
            case NSURLErrorNotConnectedToInternet:
                return "App chưa có đường mạng khả dụng tới \(endpoint). Hãy kiểm tra Wi-Fi/di động, quyền truy cập mạng của app và kết nối VPN nếu đang sử dụng."
            case NSURLErrorNetworkConnectionLost:
                return "Kết nối tới \(endpoint) bị gián đoạn. Hãy thử lại khi Wi-Fi/di động và VPN đã ổn định."
            case NSURLErrorSecureConnectionFailed, NSURLErrorServerCertificateUntrusted,
                 NSURLErrorServerCertificateHasBadDate, NSURLErrorServerCertificateHasUnknownRoot,
                 NSURLErrorServerCertificateNotYetValid:
                return "Không xác minh được kết nối HTTPS tới \(endpoint). Hãy kiểm tra chứng chỉ của Host; không bỏ qua xác minh bảo mật."
            default:
                break
            }
        }
        return "Không gửi được yêu cầu tới \(endpoint): \(failure.localizedDescription) [\(failure.domain):\(failure.code)]"
    }
}
