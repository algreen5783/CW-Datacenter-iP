# CW Datacenter iOS 1.6.5

- Tách nội dung đồng bộ thành `Images/Images_001...` và `Videos/Videos_001...`, giới hạn số tệp mỗi thư mục có thể cấu hình.
- Thêm bộ lọc nguồn: trên máy và iCloud, chỉ trên máy, hoặc chỉ iCloud Photos.
- File Photos/iCloud lỗi được thử lại có giới hạn, ghi log, bỏ qua và tiếp tục hàng đợi thay vì chặn toàn bộ.
- Tab Đồng bộ có thống kê file lỗi, nút đồng bộ thủ công nổi bật, cấu hình gọn hơn và danh sách lỗi có nút thử lại.
- Menu `+` dùng biểu tượng SVG, bỏ chọn thư mục lỗi, tách Chụp ảnh và Quay video.
- Thêm kiểu xem Tự động / Thư viện / Danh sách cho thư mục có nhiều ảnh và video.
- Phiên bản ứng dụng: 1.6.5 (build 10605).
