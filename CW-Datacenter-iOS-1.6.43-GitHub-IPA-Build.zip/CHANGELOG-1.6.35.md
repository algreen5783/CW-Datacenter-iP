# CW Datacenter iOS 1.6.35

## SVG và căn chỉnh nút

- Bổ sung biểu tượng SVG `i-play` còn thiếu nên thumbnail video không còn chỉ hiện vòng tròn đen.
- Căn chính giữa biểu tượng đăng xuất/chọn lại Host và nút làm mới cạnh bộ lọc Yêu thích.
- Chuẩn hóa `padding`, `line-height`, kích thước và vị trí SVG trong các nút icon-only.
- Căn lại biểu tượng phát video và biểu tượng trái tim phủ trên thumbnail.

## Thumbnail nhẹ hơn

- Hạ kích thước thumbnail của ứng dụng iOS từ 240 xuống 160 px.
- Áp dụng cho Tổng quan và các danh sách ảnh/video dùng thumbnail từ Host.
- Cache native dùng khóa kích thước 160 riêng, tiếp tục lưu trên thiết bị để lần mở sau tải nhanh.

## Phiên bản

- Marketing version: `1.6.35`
- Build: `10635`
- Chỉ thay đổi ứng dụng iOS; không thay đổi các ứng dụng khác và không cần cài lại Host.
