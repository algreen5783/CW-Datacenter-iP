# CW Datacenter iOS 1.6.9

- Lưu thumbnail 240×240 vào Application Support của app để tải nhanh ở lần mở sau.
- Cache thumbnail được loại khỏi iCloud Backup và chỉ bị xóa khi người dùng chọn Xóa cache.
- Cache tự phân biệt theo đường dẫn, dung lượng và thời gian sửa file để tránh hiện thumbnail cũ.
- Nút lên đầu trang mặc định nằm ngay phía trên nút tải lên, vẫn kéo thả được và không còn nhảy lên góc trái.
- Phiên bản 1.6.9, build 10609.

