# CW Datacenter iOS 1.6.24 (10624)

- Bổ sung đúng biểu tượng SVG cho nút **Mở**.
- Tệp tải về mở bằng menu **Open in** của iOS để chọn ứng dụng tương thích.
- Thư mục vẫn mở bên trong ứng dụng; chỉ báo không hỗ trợ khi iOS không có trình xử lý.
- Workflow `build-ipa.yml` được cập nhật và kiểm tra đúng phiên bản 1.6.24 (10624).
