# CW Datacenter iOS 1.6.25 (10625)

- Không hiện nút **Mở** ngoài hệ thống cho ảnh, video và PDF; các định dạng này tiếp tục dùng trình xem tích hợp.
- Tương thích với cơ chế thùng rác đã sửa trên Host 1.5.30.
- Workflow `build-ipa.yml` được cập nhật và kiểm tra đúng phiên bản 1.6.25 (10625).
