# CW Datacenter iOS 1.6.20

- Sửa đăng nhập Host qua IP Tailscale `100.64.0.0/10`: request đi trực tiếp qua tunnel, không bị HTTP proxy của Wi-Fi định tuyến nhầm.
- Cho phép kết nối qua mạng di động, mạng tính phí và chế độ dữ liệu thấp khi Tailscale đang hoạt động.
- Hiển thị trạng thái kiểm tra Host chính xác thay vì luôn báo trực tuyến.
- Hiển thị lỗi đăng nhập ngay dưới biểu mẫu và bằng thông báo nổi; ghi lỗi vào nhật ký ứng dụng.
- Nút **My Files** trên Tổng quan mở đúng thư mục đồng bộ của thiết bị trong tab Tệp.
- Chọn một ổ trong popup sẽ đóng popup và chuyển ngay vào ổ vừa chọn.
- Phiên bản `1.6.20`, build `10620`.
