# iOS 1.6.29 — Tailscale HTTP / ATS fix

## Nguyên nhân được xác nhận

Ảnh lỗi từ iPhone báo App Transport Security yêu cầu secure connection, trong khi Safari truy cập `/api/health` của Host qua Tailscale được. Source 1.6.28 thiếu ngoại lệ HTTP cho IP CGNAT Tailscale trên iOS mới; thông báo native lại quy mọi lỗi về việc Tailscale chưa online.

## Thay đổi

- Thêm `NSExceptionDomains → 100.64.0.0/10 → NSExceptionAllowsInsecureHTTPLoads = true` ở Info.plist app. Giữ các cấu hình LAN cũ, không thêm ngoại lệ cho địa chỉ Internet khác hay bỏ kiểm tra HTTPS.
- Phân loại lỗi native: ATS -1022, hết thời gian chờ, DNS, không mở được kết nối, không có mạng, mất kết nối và chứng chỉ HTTPS.
- Nhật ký HTTP ghi domain và code lỗi gốc; không ghi nội dung tài khoản/mật khẩu, token hoặc query URL.
- Mã hóa JSON lỗi đúng cách khi thông báo chứa dấu nháy/xuống dòng; giải phóng URLSession riêng của request sau khi hoàn tất.
- Tăng đồng bộ version/build, thông tin giao diện, tên file nhật ký và workflow lên 1.6.29 / 10629.
- Thêm kiểm tra source, 5 ca kiểm tra cầu nối đăng nhập, kiểm tra Swift và kiểm tra Info.plist app sau Xcode build. Sửa hướng dẫn build còn ghi tên phiên bản cũ.

Không đổi Host, các bản Android, desktop client, Share Extension hay cơ chế phát/tải media.

## Xác minh

- Windows: kiểm tra cấu hình, cú pháp JavaScript và 5 ca bridge/API đã đạt.
- Swift/Xcode/IPA/iPhone: chưa chạy trong phiên Windows; workflow đã thêm các cổng kiểm tra cần thiết. Chưa tuyên bố đã kết nối thành công trên thiết bị thật.

Tham chiếu: [Apple ATS exceptions](https://developer.apple.com/documentation/bundleresources/information-property-list/nsapptransportsecurity/nsexceptiondomains), [Tailscale IPv4 range](https://tailscale.com/docs/concepts/tailscale-ip-addresses).
