# CW Datacenter iOS 1.6.30

- Giữ nguyên vị trí vuốt của danh sách Tiếp tục xem và cập nhật tiến độ không dựng lại carousel.
- Sửa vùng an toàn cho Video Offline, Tổng quan và trình đọc PDF.
- Sửa thao tác lùi 10 giây, phát/tạm dừng và tiến 10 giây trong trình phát video.
- Rút gọn nhãn thanh công cụ video trên màn hình nhỏ.
- Sửa nút Yêu thích trong trình xem ảnh.
- Thêm thumbnail cho Yêu thích, Truyền tải, Đồng bộ và Thùng rác.
- Thêm nút xóa riêng từng mục trong Thùng rác.
- Giảm nhấp nháy khi upload/download bằng cập nhật tiến độ tại chỗ.
- Thêm bốn thư mục chọn nhanh theo tài khoản và Host.
- Thêm nút đăng xuất/chọn lại Host trên Tổng quan.
- Đổi thanh tab dưới sang kiểu bo tròn; đưa Yêu thích ra tab chính và chuyển Truyền tải vào Khác.
- Thêm 10 file xem gần nhất và ẩn nội dung thuộc ổ/thư mục khóa.
