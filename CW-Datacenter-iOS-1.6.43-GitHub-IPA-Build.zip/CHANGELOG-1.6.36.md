# CW Datacenter iOS 1.6.36

## Trình phát video

- Bỏ hai nút tua lùi 10 giây và tua nhanh 10 giây khỏi cụm điều khiển giữa màn hình.
- Tách nút Play/Pause thành nút tương tác độc lập, tăng vùng bấm và ngăn cử chỉ trên bề mặt video chặn thao tác nút.
- Khi video đang phát, nút giữa dùng để tạm dừng; khi đang dừng, nút dùng để tiếp tục.
- Khi video phát hết, nút giữa tự đổi thành biểu tượng phát lại. Nhấn nút sẽ đưa video về đầu và phát lại.

## Tổng quan ảnh/video

- `Tất cả` tiếp tục hiển thị lẫn ảnh và video theo cùng một dòng thời gian.
- Bỏ tiêu đề `Tổng quan`, trạng thái Host và nút đăng xuất/chọn lại Host khỏi đầu trang.
- Giữ nguyên ô tìm kiếm và các bộ lọc `Tất cả`, `Ảnh`, `Video`, `Yêu thích`; kéo cụm này lên sát vùng an toàn phía trên để dành thêm diện tích cho thư viện.

## Phiên bản

- Marketing version: `1.6.36`
- Build: `10636`
- Chỉ thay đổi source iOS; không thay đổi Host, Android, tablet hoặc desktop client.
