const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const app = fs.readFileSync(path.join(__dirname, '..', 'CWDatacenter', 'Resources', 'Web', 'app.js'), 'utf8');

test('host file responses keep the server pool and canonical child paths', () => {
  assert.match(app, /function normalizeHostFileResponse\(data, requestedPool\)/);
  assert.match(app, /entry\.pool = String\(entry\.pool \|\| resolvedPool/);
  assert.match(app, /entry\._rel = String\(entry\._rel \|\| \(resolvedPath \? resolvedPath \+ '\/' : ''\) \+ name\)/);
  assert.match(app, /if \(resolved\.pool && resolved\.pool !== pool\) pool = resolved\.pool/);
});

test('sync drive remains active after the host resolves an overlapping storage pool', () => {
  assert.match(app, /syncDeviceBrowse\.pool = resolved\.pool/);
  assert.match(app, /syncDeviceBrowse\.root = resolved\.path/);
  assert.match(app, /const syncActive = isSyncDeviceBrowseActive\(\)/);
  assert.match(app, /const isSyncActive = isSyncDeviceBrowseActive\(\)/);
});
