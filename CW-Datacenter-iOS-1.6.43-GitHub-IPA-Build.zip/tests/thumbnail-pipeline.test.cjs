'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const proxy = fs.readFileSync(path.join(root, 'CWDatacenter', 'Network', 'LocalProxy.swift'), 'utf8');
const main = fs.readFileSync(path.join(root, 'CWDatacenter', 'ViewControllers', 'MainViewController.swift'), 'utf8');
const app = fs.readFileSync(path.join(root, 'CWDatacenter', 'Resources', 'Web', 'app.js'), 'utf8');

test('local proxy sends complete thumbnail responses and safely encodes paths', () => {
  assert.match(proxy, /URLComponents\(string: upstream\.baseUrl \+ endpoint\)/);
  assert.match(proxy, /URLQueryItem\(name: "path", value: rel\)/);
  assert.match(proxy, /guard self\.sendAll\(clientSock, data: Data\(headerStr\.utf8\)\)/);
  assert.match(proxy, /self\.sendAll\(clientSock, data: d\)/);
  assert.doesNotMatch(proxy, /URLSession\.shared\.dataTask/);
  assert.match(proxy, /httpMaximumConnectionsPerHost = 10/);
  assert.match(proxy, /configuration\.connectionProxyDictionary = \[:\]/);
});

test('thumbnail requests are sized, cached and retried before fallback', () => {
  assert.match(main, /window\.DC\.thumbUrl = function\(rel, pool, size\)/);
  assert.match(main, /'&thumb=1&size=' \+ \(size \|\| 160\)/);
  assert.match(proxy, /&thumb=1&size=160/);
  assert.match(app, /function retryThumbnailElement\(img\)/);
  assert.match(app, /attempt >= 2/);
  assert.match(app, /function loadReliableThumbnail\(img, url, finalFallback\)/);
  assert.match(app, /CWRetryThumbnail\(this\)/);
  assert.doesNotMatch(app, /onerror="this\.remove\(\)"/);
});
