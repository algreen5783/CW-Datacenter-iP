const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const app = fs.readFileSync(path.join(__dirname, '../CWDatacenter/Resources/Web/app.js'), 'utf8');
const start = app.indexOf('function compareOverviewMedia(');
const end = app.indexOf('\nfunction renderOverviewGallery(', start);
const context = vm.createContext({overviewGalleryTimestamp: () => 0, overviewThumbIdentity: x => x.pool + '|' + x.rel});
vm.runInContext(app.slice(start, end), context);
const items = [
  {name: 'Ảnh 10.jpg', rel: 'a', pool: 'main', at: 30, size: 10},
  {name: 'Ảnh 2.heic', rel: 'b', pool: 'main', at: 10, size: 30},
  {name: 'Video.mp4', rel: 'c', pool: 'main', at: 20, size: 20}
];
test('mixed photos/videos sort by dates, natural names and byte sizes in both directions', () => {
  const sort = mode => items.slice().sort((a,b) => context.compareOverviewMedia(a,b,mode)).map(x => x.rel).join('');
  assert.equal(sort('date-desc'), 'acb');
  assert.equal(sort('date-asc'), 'bca');
  assert.equal(sort('name-asc'), 'bac');
  assert.equal(sort('name-desc'), 'cab');
  assert.equal(sort('size-desc'), 'bca');
  assert.equal(sort('size-asc'), 'acb');
  assert.equal(items.map(x => x.rel).join(''), 'abc');
});
test('equal sort values have deterministic ordering across rerenders and scans', () => {
  const a={name:'same',rel:'z',pool:'main',at:0,size:0}, b={...a,rel:'a'};
  for(const mode of ['date-desc','date-asc','name-asc','name-desc','size-asc','size-desc']) {
    assert(context.compareOverviewMedia(a,b,mode)>0);
    assert(context.compareOverviewMedia(b,a,mode)<0);
  }
});
