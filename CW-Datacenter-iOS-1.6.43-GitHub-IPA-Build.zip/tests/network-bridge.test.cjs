// Exercise the shipped JS bridge/API wrapper, not a replacement implementation.
const { readFileSync } = require('node:fs');
const { join } = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const { test } = require('node:test');
const js = readFileSync(join(__dirname, '../CWDatacenter/Resources/Web/app.js'), 'utf8');
function between(start, end) {
  const from = js.indexOf(start);
  const to = js.indexOf(end, from);
  assert.ok(from >= 0 && to > from);
  return js.slice(from, to);
}
function harness(ok, payload) {
  const requests = [];
  const context = vm.createContext({
    server: { baseUrl: 'http://100.66.66.66:8080', ip: '100.66.66.66', port: 8080 },
    token: '', onSessionLost() { throw new Error('unexpected session loss'); },
    DC: { call(method, id, args) {
      requests.push({ method, args: JSON.parse(args) });
      queueMicrotask(() => context.DC._cb(id, ok, JSON.stringify(payload)));
    } },
  });
  vm.runInContext(between('const cbs = new Map();', 'DC._evt ='), context);
  vm.runInContext(between('function errText(e)', 'function isLocalMode()'), context);
  vm.runInContext(between('async function api(path', '/* ---------- Views ---------- */'), context);
  return { context, requests };
}

test('ATS failure survives bridge and is not rewritten as enable-VPN advice', async () => {
  const error = 'iOS chặn kết nối HTTP tới 100.66.66.66:8080 (ATS -1022). Bản iOS cần cập nhật cấu hình kết nối.';
  const { context } = harness(false, { status: 0, text: JSON.stringify({ error }), err: error, errorCode: -1022 });
  await assert.rejects(context.api('/api/login', 'POST', { username: 'demo', password: 'test-only' }), e => {
    assert.equal(context.errText(e), error);
    assert.ok(!context.errText(e).includes('BẬT VPN'));
    return true;
  });
});
test('successful login retains method, URL and JSON body', async () => {
  const { context, requests } = harness(true, { status: 200, text: JSON.stringify({ token: 'test-token', user: 'demo' }) });
  const result = await context.api('/api/login', 'POST', { username: 'demo', password: 'test-only' });
  assert.equal(result.token, 'test-token');
  assert.deepEqual(requests[0], { method: 'invoke', args: ['POST', 'http://100.66.66.66:8080/api/login', '{}', '{"username":"demo","password":"test-only"}'] });
});
test('wrong password remains an HTTP auth error, not a network error', async () => {
  const { context } = harness(true, { status: 401, text: JSON.stringify({ error: 'Sai tài khoản hoặc mật khẩu' }) });
  await assert.rejects(context.api('/api/login', 'POST', {}), e => e.status === 401 && context.errText(e) === 'Sai tài khoản hoặc mật khẩu');
});
test('failed Host probe rejects rather than reporting online', async () => {
  const { context } = harness(false, { status: 0, err: 'Hết thời gian chờ phản hồi từ Host.' });
  await assert.rejects(context.tryApi('http://100.66.66.66:8080', '/api/ping', 'GET'), e => context.errText(e) === 'Hết thời gian chờ phản hồi từ Host.');
});
test('successful Host probe still supports LAN addresses', async () => {
  const { context, requests } = harness(true, { status: 200, text: '{"ok":true,"via":"lan"}' });
  const result = await context.tryApi('http://192.168.1.47:8080', '/api/ping', 'GET');
  assert.equal(result.ok, true);
  assert.equal(requests[0].args[1], 'http://192.168.1.47:8080/api/ping');
});
