import Foundation
import ImageIO
import CoreGraphics

// The production proxy is compiled unmodified; only its logging dependency is stubbed.
final class AppLogger {
    enum Level { case debug, error, info, warning }
    static let shared = AppLogger()
    func log(_ level: Level, category: String, _ message: String) {}
}

@main
struct ImageValidationTests {
    static func main() throws {
        guard let context = CGContext(data: nil, width: 640, height: 480, bitsPerComponent: 8,
                                      bytesPerRow: 0, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue) else { fatalError("Image context") }
        context.setFillColor(CGColor(red: 0.2, green: 0.6, blue: 0.8, alpha: 1))
        context.fill(CGRect(x: 0, y: 0, width: 640, height: 480))
        let image = context.makeImage()!
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        for format in ["public.jpeg", "public.heic"] {
            let data = NSMutableData()
            guard let destination = CGImageDestinationCreateWithData(data, format as CFString, 1, nil) else {
                precondition(format == "public.heic"); print("HEIC encoder unavailable on this runner"); continue
            }
            CGImageDestinationAddImage(destination, image, nil)
            guard CGImageDestinationFinalize(destination) else {
                precondition(format == "public.heic"); print("HEIC encoding unavailable on this runner"); continue
            }
            let decoded = LocalProxy.decodedImage(data as Data, maxPixelSize: 160)
            precondition(decoded?.width == 160 && decoded?.height == 120, "Native downsampling: \(format)")
            let file = directory.appendingPathComponent(format)
            try (data as Data).write(to: file)
            let thumbnail = LocalProxy.jpegThumbnail(from: file, size: 160)
            precondition(thumbnail != nil, "Native thumbnail: \(format)")
            let jpeg = CGImageSourceCreateWithData(thumbnail! as CFData, nil)!
            precondition(CGImageSourceGetType(jpeg)! as String == "public.jpeg")
            precondition(LocalProxy.decodedImage(thumbnail!, maxPixelSize: 160)?.width == 160)
            print("PASS native \(format) decode, downsample and JPEG thumbnail")
        }
        for invalid in [Data(), Data("broken image cache".utf8), Data([0xff, 0xd8, 0xff, 0xd9])] {
            precondition(LocalProxy.decodedImage(invalid, maxPixelSize: 160) == nil, "Invalid image accepted")
        }
        print("PASS invalid thumbnail rejection")
    }
}
