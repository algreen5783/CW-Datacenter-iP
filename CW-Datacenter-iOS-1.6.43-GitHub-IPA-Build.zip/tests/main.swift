import Foundation

let host = URL(string: "http://100.66.66.66:8080/api/login")!
func message(_ code: Int, domain: String = NSURLErrorDomain) -> String {
    return HostConnectionDiagnostics.message(
        for: NSError(domain: domain, code: code, userInfo: [NSLocalizedDescriptionKey: "Original \"detail\"\nline"]),
        url: host
    )
}

let ats = message(NSURLErrorAppTransportSecurityRequiresSecureConnection)
precondition(ats.contains("ATS -1022"))
precondition(ats.contains("100.66.66.66:8080"))
precondition(!ats.contains("đều đang Online"))
precondition(message(NSURLErrorTimedOut).contains("Hết thời gian chờ"))
precondition(message(NSURLErrorCannotFindHost).contains("IP hoặc tên máy chủ"))
precondition(message(NSURLErrorDNSLookupFailed).contains("IP hoặc tên máy chủ"))
precondition(message(NSURLErrorCannotConnectToHost).contains("địa chỉ, cổng"))
precondition(message(NSURLErrorNotConnectedToInternet).contains("quyền truy cập mạng"))
precondition(message(NSURLErrorNetworkConnectionLost).contains("bị gián đoạn"))
for code in [NSURLErrorSecureConnectionFailed, NSURLErrorServerCertificateUntrusted,
             NSURLErrorServerCertificateHasBadDate, NSURLErrorServerCertificateHasUnknownRoot,
             NSURLErrorServerCertificateNotYetValid] {
    precondition(message(code).contains("không bỏ qua xác minh bảo mật"))
}
let other = message(-1022, domain: "CustomDomain")
precondition(!other.contains("ATS -1022"))
precondition(other.contains("CustomDomain:-1022"))
let inner = try JSONSerialization.data(withJSONObject: ["error": other])
let payload = try JSONSerialization.data(withJSONObject: [
    "status": 0, "text": String(data: inner, encoding: .utf8)!, "err": other,
    "errorDomain": "CustomDomain", "errorCode": -1022
] as [String: Any])
let decoded = try JSONSerialization.jsonObject(with: payload) as! [String: Any]
precondition(decoded["err"] as? String == other)
let decodedBody = try JSONSerialization.jsonObject(with: (decoded["text"] as! String).data(using: .utf8)!) as! [String: String]
precondition(decodedBody["error"] == other)
print("PASS: native transport error classification and JSON escaping")
