# CW Datacenter iOS 1.6.16

- Tổng quan hiển thị tối đa 5 video xem dở dạng thẻ ngang, có thumbnail và mở tiếp video đã chọn.
- Hiển thị 4 thư mục gần đây với icon thư mục.
- Thao tác nhanh đổi thành Tải lên, Yêu thích, My Files và Chọn ổ.
- Popup chọn ổ chuyển sang chọn trực tiếp bằng một lần chạm.
- Trình xem ảnh tự ẩn thanh tên và thanh tác vụ sau 2 giây, chạm lại để hiện.
- Trình phát video được sắp xếp theo kiểu Android Mobile: cụm điều khiển trung tâm, thanh thời gian và thanh công cụ Khóa/Tốc độ/Lặp lại/Danh sách/Phụ đề/Tỷ lệ.
- Phiên bản thực trong app là 1.6.16 (build 10616); tên IPA tương thích vẫn là `CW-Datacenter-iOS-1.4.0-unsigned.ipa`.
