# CW Datacenter iOS 1.6.7

- Sửa lưới ảnh/video thành ô vuông độc lập, không chồng hàng; thumbnail giảm về 240×240.
- Giảm số ô render mỗi đợt để hạ RAM và tăng tốc hiển thị thư mục lớn.
- Khi iOS báo bộ nhớ thấp, giải phóng cache ngoài màn hình nhưng không tự dừng file đang đồng bộ.
- Thêm Share Extension để CW Datacenter xuất hiện trong bảng Chia sẻ ảnh/video của iOS.
- Tệp được chia sẻ được giữ trong hàng chờ; người dùng chọn ổ/thư mục Host rồi mới xác nhận tải lên.
- Phiên bản ứng dụng 1.6.7, build 10607. Tên IPA artifact cũ 1.4.0 vẫn được giữ để tương thích pipeline GitHub hiện tại.
