# CW Datacenter iOS 1.6.60

- Tự chuyển video đang phát sang Picture in Picture khi rời ứng dụng.
- Tổng quan chọn ngày và sắp xếp bằng ngày chụp/quay gốc; chỉ dùng ngày sửa khi thiếu metadata gốc.
- Thu gọn tên video dài trong bảng tiếp tục xem và luôn giữ phần mở rộng.
- Trình xem ảnh chỉ hiển thị biểu tượng ở thanh tác vụ.
- Sửa lỗi build Xcode 16.4 do kết quả khởi tạo Picture in Picture chưa được unwrap.
