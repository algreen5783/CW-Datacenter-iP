﻿# CW Datacenter iOS 1.6.61

## Sửa lỗi & Nâng cấp

- **Sửa lỗi giữ chọn thumbnail (1s)**: Loại bỏ triệt để hiện tượng kéo/nhấc nổi thumbnail ảnh khi nhấn giữ 1 giây để chọn. Vô hiệu hóa UIDragInteraction và allowsLinkPreview trên WKWebView, đồng thời ngăn chặn dragstart và áp dụng -webkit-user-drag: none, pointer-events: none trên thẻ hình ảnh <img>.
- **Sắp xếp tab Tổng quan theo ngày chụp gốc**: Tab Tổng quan ưu tiên sắp xếp và gom nhóm theo ngày chụp gốc (captureDate), chỉ sử dụng ngày sửa đổi nếu tệp không có thông tin ngày chụp gốc.
- **Hiển thị chính xác ngày chụp gốc và địa điểm**: Bảng Thông tin chi tiết và trình xem ảnh hiển thị đúng Ngày tạo theo ngày chụp gốc, bổ sung Ngày chụp gốc và Địa điểm (tọa độ GPS).
