# Build CW Datacenter iOS 1.5.1

## Build IPA bằng GitHub Actions (không cần máy Mac)

1. Giải nén gói `CW-Datacenter-iOS-1.5.1-GitHub-IPA-Build.zip`.
2. Đưa toàn bộ nội dung bên trong lên thư mục gốc của một repository GitHub. Phải thấy `.github/workflows/build-ipa.yml` ở đúng vị trí này.
3. Mở tab **Actions** > **Build CW Datacenter iOS 1.5.1 IPA** > **Run workflow**.
4. Khi job hoàn tất, tải artifact `CW-Datacenter-iOS-1.5.1-unsigned`.
5. Artifact chứa `CW-Datacenter-iOS-1.5.1-unsigned.ipa` và checksum SHA-256.

IPA từ workflow là bản **unsigned**. Cần ký bằng chứng chỉ/provisioning profile của bạn trước khi cài lên iPhone, hoặc dùng công cụ sideload có hỗ trợ ký.

## Build/ký bằng Xcode

1. Mở `CWDatacenter.xcodeproj` bằng Xcode.
2. Chọn target **CWDatacenter** > **Signing & Capabilities**.
3. Chọn Team và Bundle Identifier thuộc tài khoản Apple Developer của bạn.
4. Chọn thiết bị hoặc **Any iOS Device (arm64)** rồi **Product > Archive**.
5. Trong Organizer, dùng **Distribute App** để xuất IPA đã ký.

## Kiểm tra bắt buộc

- Phiên bản app: `1.5.1` (build `10501`).
- Trong app bundle phải có `Web/index.html` và `Web/app.js`, đều mang marker `1.5.1`.
- Quyền Photos và Local Network phải còn trong `Info.plist`.
- Lần đầu dùng Đồng bộ, cấp quyền **Tất cả ảnh** (hoặc lựa chọn ảnh mong muốn nếu dùng quyền giới hạn).

Xem chi tiết thay đổi trong `CHANGELOG-1.5.1.md`.
