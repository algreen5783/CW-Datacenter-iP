import Foundation

class LocalProxy {
    static let shared = LocalProxy()

    private var serverSocket: Int32 = -1
    private(set) var port: Int = 0
    private var isRunning = false
    private let queue = DispatchQueue(label: "com.cw.datacenter.proxy", qos: .userInitiated, attributes: .concurrent)

    private(set) var baseUrl: String = ""
    private(set) var token: String = ""

    func setAuth(baseUrl: String, token: String) {
        self.baseUrl = baseUrl
        self.token = token
        if !isRunning {
            start()
        }
    }

    func start() {
        guard !isRunning else { return }
        isRunning = true

        var addr = sockaddr_in()
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_port = in_port_t(0) // random port
        addr.sin_addr.s_addr = inet_addr("127.0.0.1")

        let sock = socket(AF_INET, SOCK_STREAM, 0)
        guard sock >= 0 else { isRunning = false; return }

        var yes: Int32 = 1
        setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &yes, socklen_t(MemoryLayout<Int32>.size))

        let bindRes = withUnsafePointer(to: &addr) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                bind(sock, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        guard bindRes == 0 else {
            close(sock)
            isRunning = false
            return
        }

        listen(sock, 64)
        serverSocket = sock

        var assignedAddr = sockaddr_in()
        var len = socklen_t(MemoryLayout<sockaddr_in>.size)
        _ = withUnsafeMutablePointer(to: &assignedAddr) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                getsockname(sock, $0, &len)
            }
        }
        port = Int(UInt16(bigEndian: assignedAddr.sin_port))

        queue.async { [weak self] in
            self?.acceptLoop()
        }
    }

    func stop() {
        isRunning = false
        if serverSocket >= 0 {
            close(serverSocket)
            serverSocket = -1
        }
        port = 0
    }

    func urlFor(relEncoded: String, poolEncoded: String?, video: Bool) -> String {
        guard port > 0 else { return "" }
        var u = "http://127.0.0.1:\(port)/play?path=\(relEncoded)"
        if let p = poolEncoded, !p.isEmpty { u += "&pool=\(p)" }
        if video { u += "&video=1" }
        return u
    }

    func thumbUrl(relEncoded: String, poolEncoded: String?) -> String {
        guard port > 0 else { return "" }
        var u = "http://127.0.0.1:\(port)/play?path=\(relEncoded)&thumb=1"
        if let p = poolEncoded, !p.isEmpty { u += "&pool=\(p)" }
        return u
    }

    private func acceptLoop() {
        while isRunning && serverSocket >= 0 {
            var clientAddr = sockaddr_in()
            var clientLen = socklen_t(MemoryLayout<sockaddr_in>.size)
            let clientSock = withUnsafeMutablePointer(to: &clientAddr) {
                $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                    accept(serverSocket, $0, &clientLen)
                }
            }
            guard clientSock >= 0 else { continue }
            queue.async { [weak self] in
                self?.handleClient(clientSock)
            }
        }
    }

    private func handleClient(_ clientSock: Int32) {
        defer { close(clientSock) }

        var buffer = [UInt8](repeating: 0, count: 8192)
        let bytesRead = recv(clientSock, &buffer, buffer.count, 0)
        guard bytesRead > 0 else { return }

        guard let requestString = String(bytes: buffer.prefix(bytesRead), encoding: .utf8) else { return }
        let lines = requestString.components(separatedBy: "\r\n")
        guard let requestLine = lines.first else { return }
        let reqParts = requestLine.components(separatedBy: " ")
        guard reqParts.count >= 2 else { return }

        let method = reqParts[0].uppercased()
        let target = reqParts[1]

        var headers = [String: String]()
        for line in lines.dropFirst() {
            if line.isEmpty { break }
            let parts = line.split(separator: ":", maxSplits: 1).map(String.init)
            if parts.count == 2 {
                headers[parts[0].trimmingCharacters(in: .whitespaces).lowercased()] = parts[1].trimmingCharacters(in: .whitespaces)
            }
        }

        if method == "OPTIONS" {
            let res = "HTTP/1.1 204 No Content\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: Range, Authorization, Content-Type\r\nAccess-Control-Allow-Methods: GET, HEAD, OPTIONS\r\nConnection: close\r\n\r\n"
            _ = send(clientSock, res, res.utf8.count, 0)
            return
        }

        guard let urlComponents = URLComponents(string: "http://127.0.0.1" + target) else { return }
        let queryItems = urlComponents.queryItems ?? []
        let queryMap = Dictionary(queryItems.compactMap { item in item.value.map { (item.name, $0) } }, uniquingKeysWith: { first, _ in first })

        if urlComponents.path == "/local" {
            guard let spec = queryMap["spec"] else {
                sendError(clientSock, status: 400, msg: "Missing local file")
                return
            }
            serveLocalFile(clientSock, method: method, spec: spec, headers: headers)
            return
        }

        guard let rel = queryMap["path"] ?? queryMap["file"], !rel.isEmpty else {
            sendError(clientSock, status: 404, msg: "Not found")
            return
        }

        let isVideo = queryMap["video"] == "1"
        let isThumb = queryMap["thumb"] == "1"
        let pool = queryMap["pool"]
        let ss = queryMap["ss"]

        var upstreamStr = baseUrl
        if isVideo {
            upstreamStr += "/api/video?raw=1&path=" + rel
            if let ssVal = ss, !ssVal.isEmpty { upstreamStr += "&ss=" + ssVal }
        } else if isThumb {
            upstreamStr += "/api/thumb?path=" + rel
        } else {
            upstreamStr += "/api/file?path=" + rel + "&preview=1"
        }
        if let p = pool, !p.isEmpty { upstreamStr += "&pool=" + p }

        guard let upstreamUrl = URL(string: upstreamStr) else {
            sendError(clientSock, status: 400, msg: "Invalid URL")
            return
        }

        var req = URLRequest(url: upstreamUrl)
        req.httpMethod = method
        if !token.isEmpty {
            req.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        }
        if let rangeHeader = headers["range"] {
            req.setValue(rangeHeader, forHTTPHeaderField: "Range")
        }

        let semaphore = DispatchSemaphore(value: 0)
        let task = URLSession.shared.dataTask(with: req) { data, response, error in
            defer { semaphore.signal() }
            guard let httpResponse = response as? HTTPURLResponse else {
                LocalProxy.sendError(clientSock, status: 502, msg: "Bad Gateway")
                return
            }

            var headerStr = "HTTP/1.1 \(httpResponse.statusCode) OK\r\n"
            if httpResponse.statusCode == 206 {
                headerStr = "HTTP/1.1 206 Partial Content\r\n"
            }
            headerStr += "Access-Control-Allow-Origin: *\r\n"
            headerStr += "Accept-Ranges: bytes\r\n"

            for (k, v) in httpResponse.allHeaderFields {
                let keyStr = String(describing: k)
                let valStr = String(describing: v)
                if ["content-type", "content-length", "content-range", "etag", "cache-control"].contains(keyStr.lowercased()) {
                    headerStr += "\(keyStr): \(valStr)\r\n"
                }
            }
            headerStr += "Connection: close\r\n\r\n"

            _ = send(clientSock, headerStr, headerStr.utf8.count, 0)
            if let d = data, method != "HEAD" {
                d.withUnsafeBytes { rawBuffer in
                    if let baseAddress = rawBuffer.baseAddress {
                        _ = send(clientSock, baseAddress, d.count, 0)
                    }
                }
            }
        }
        task.resume()
        _ = semaphore.wait(timeout: .now() + 60)
    }

    private func serveLocalFile(_ sock: Int32, method: String, spec: String, headers: [String: String]) {
        guard let data = spec.data(using: .utf8),
              let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let rawPath = object["p"] as? String,
              !rawPath.isEmpty else {
            sendError(sock, status: 400, msg: "Invalid local file")
            return
        }

        let fileUrl = URL(fileURLWithPath: rawPath).standardizedFileURL
        let documentsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!.standardizedFileURL
        let allowedRoot = documentsUrl.path.hasSuffix("/") ? documentsUrl.path : documentsUrl.path + "/"
        guard fileUrl.path == documentsUrl.path || fileUrl.path.hasPrefix(allowedRoot) else {
            sendError(sock, status: 403, msg: "Local file is outside app storage")
            return
        }

        guard let attributes = try? FileManager.default.attributesOfItem(atPath: fileUrl.path),
              let number = attributes[.size] as? NSNumber else {
            sendError(sock, status: 404, msg: "Local file not found")
            return
        }

        let fileSize = number.uint64Value
        var start: UInt64 = 0
        var end = fileSize > 0 ? fileSize - 1 : 0
        var partial = false
        if let range = headers["range"], range.lowercased().hasPrefix("bytes=") {
            let value = String(range.dropFirst(6)).split(separator: ",", maxSplits: 1).first.map(String.init) ?? ""
            let pieces = value.split(separator: "-", maxSplits: 1, omittingEmptySubsequences: false)
            if let first = pieces.first, let requestedStart = UInt64(first), requestedStart < fileSize {
                start = requestedStart
                if pieces.count > 1, let requestedEnd = UInt64(pieces[1]) {
                    end = min(requestedEnd, fileSize - 1)
                }
                partial = true
            }
        }

        let length = fileSize == 0 ? 0 : end - start + 1
        let statusLine = partial ? "HTTP/1.1 206 Partial Content" : "HTTP/1.1 200 OK"
        var response = "\(statusLine)\r\n"
        response += "Content-Type: \(mimeType(for: fileUrl.pathExtension))\r\n"
        response += "Content-Length: \(length)\r\n"
        response += "Accept-Ranges: bytes\r\n"
        response += "Access-Control-Allow-Origin: *\r\n"
        if partial { response += "Content-Range: bytes \(start)-\(end)/\(fileSize)\r\n" }
        response += "Connection: close\r\n\r\n"
        guard sendAll(sock, data: Data(response.utf8)) else { return }
        guard method != "HEAD", length > 0, let handle = try? FileHandle(forReadingFrom: fileUrl) else { return }
        defer { try? handle.close() }
        try? handle.seek(toOffset: start)
        var remaining = length
        while remaining > 0 {
            let chunk = handle.readData(ofLength: Int(min(remaining, 256 * 1024)))
            if chunk.isEmpty || !sendAll(sock, data: chunk) { break }
            remaining -= UInt64(chunk.count)
        }
    }

    private func sendAll(_ sock: Int32, data: Data) -> Bool {
        if data.isEmpty { return true }
        return data.withUnsafeBytes { bytes in
            guard let base = bytes.baseAddress else { return false }
            var offset = 0
            while offset < data.count {
                let sent = send(sock, base.advanced(by: offset), data.count - offset, 0)
                if sent <= 0 { return false }
                offset += sent
            }
            return true
        }
    }

    private func mimeType(for ext: String) -> String {
        switch ext.lowercased() {
        case "mp3": return "audio/mpeg"
        case "m4a", "mp4": return "audio/mp4"
        case "aac": return "audio/aac"
        case "wav": return "audio/wav"
        case "flac": return "audio/flac"
        case "mov": return "video/quicktime"
        case "mkv": return "video/x-matroska"
        case "jpg", "jpeg": return "image/jpeg"
        case "png": return "image/png"
        default: return "application/octet-stream"
        }
    }

    private static func sendError(_ sock: Int32, status: Int, msg: String) {
        let body = msg.data(using: .utf8) ?? Data()
        let resp = "HTTP/1.1 \(status) Error\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: \(body.count)\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n\(msg)"
        _ = send(sock, resp, resp.utf8.count, 0)
    }

    private func sendError(_ sock: Int32, status: Int, msg: String) {
        LocalProxy.sendError(sock, status: status, msg: msg)
    }
}
