import UIKit
import WebKit
import Network
import AVKit
import AVFoundation
import Photos
import PhotosUI
import UniformTypeIdentifiers
import PDFKit
import Darwin

private enum CameraMediaMode: String {
    case all
    case photos
    case videos
}

private enum CameraStorageMode: String {
    case all
    case local
    case iCloud
}

class FileDownloadDelegate: NSObject, URLSessionDownloadDelegate {
    let downloadId: String
    let key: String
    let destUrl: URL
    let onProgress: ([String: Any]) -> Void
    var startTime = Date()
    private var lastProgressTime: Date = .distantPast

    init(downloadId: String, key: String, destUrl: URL, onProgress: @escaping ([String: Any]) -> Void) {
        self.downloadId = downloadId
        self.key = key
        self.destUrl = destUrl
        self.onProgress = onProgress
        super.init()
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        let now = Date()
        if now.timeIntervalSince(lastProgressTime) >= 0.25 || (totalBytesExpectedToWrite > 0 && totalBytesWritten >= totalBytesExpectedToWrite) {
            lastProgressTime = now
            let elapsed = now.timeIntervalSince(startTime)
            let speed = elapsed > 0 ? Int64(Double(totalBytesWritten) / elapsed) : 0
            let total = totalBytesExpectedToWrite > 0 ? totalBytesExpectedToWrite : totalBytesWritten
            onProgress([
                "type": "transfer",
                "id": downloadId,
                "key": key,
                "status": "active",
                "done": totalBytesWritten,
                "total": total,
                "speed": speed
            ])
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        try? FileManager.default.removeItem(at: destUrl)
        try? FileManager.default.moveItem(at: location, to: destUrl)
        let size = (try? destUrl.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
        onProgress([
            "type": "transfer",
            "id": downloadId,
            "key": key,
            "status": "done",
            "done": size,
            "total": size,
            "path": destUrl.path
        ])
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let err = error {
            onProgress([
                "type": "transfer",
                "id": downloadId,
                "key": key,
                "status": "error",
                "err": err.localizedDescription
            ])
        }
    }
}

final class FileUploadDelegate: NSObject, URLSessionTaskDelegate, URLSessionDataDelegate {
    private let onProgress: (Int64, Int64, Int64) -> Void
    private let onComplete: (Bool, Int, String?) -> Void
    private var startTime = Date()
    private var lastProgressTime: Date = .distantPast
    private var httpStatusCode: Int = 0
    private var responseData = Data()

    init(onProgress: @escaping (Int64, Int64, Int64) -> Void, onComplete: @escaping (Bool, Int, String?) -> Void) {
        self.onProgress = onProgress
        self.onComplete = onComplete
        super.init()
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didSendBodyData bytesSent: Int64, totalBytesSent: Int64, totalBytesExpectedToSend: Int64) {
        let now = Date()
        if now.timeIntervalSince(lastProgressTime) >= 0.2 || (totalBytesExpectedToSend > 0 && totalBytesSent >= totalBytesExpectedToSend) {
            lastProgressTime = now
            let elapsed = now.timeIntervalSince(startTime)
            let speed = elapsed > 0 ? Int64(Double(totalBytesSent) / elapsed) : 0
            onProgress(totalBytesSent, totalBytesExpectedToSend, speed)
        }
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        if let http = response as? HTTPURLResponse {
            self.httpStatusCode = http.statusCode
        }
        completionHandler(.allow)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        self.responseData.append(data)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        let code = (task.response as? HTTPURLResponse)?.statusCode ?? self.httpStatusCode
        let ok = (error == nil && (code == 200 || code == 201))
        var serverMsg: String? = nil
        if !responseData.isEmpty {
            if let json = try? JSONSerialization.jsonObject(with: responseData) as? [String: Any],
               let err = json["error"] as? String {
                serverMsg = err
            } else if let raw = String(data: responseData, encoding: .utf8), !raw.isEmpty {
                serverMsg = raw
            }
        }
        let errMsg = serverMsg ?? error?.localizedDescription ?? (code != 200 && code != 201 ? "HTTP \(code)" : nil)
        onComplete(ok, code, errMsg)
    }
}

private final class ThreadSafeCounter {
    private var count: Int = 0
    private let lock = NSLock()

    init(_ initial: Int = 0) { self.count = initial }

    func get() -> Int {
        lock.lock()
        defer { lock.unlock() }
        return count
    }

    func increment() -> Int {
        lock.lock()
        defer { lock.unlock() }
        count += 1
        return count
    }
}

private struct BackupTaskItem {
    let index: Int
    let asset: PHAsset
    let originalName: String
    let targetFolder: String
    let partName: String
}

private struct CameraHTTPResult {
    let code: Int
    let data: Data
    let error: String?
    let headers: [AnyHashable: Any]

    init(code: Int, data: Data, error: String?, headers: [AnyHashable: Any] = [:]) {
        self.code = code
        self.data = data
        self.error = error
        self.headers = headers
    }
}

private struct CameraBackupRecord: Codable {
    let assetIdentifier: String
    let name: String
    let path: String
    let size: Int64
    let syncedAt: TimeInterval
    // nil là record từ bản cũ; false là chỉ suy ra theo tên/path, chưa đủ điều kiện tự xóa.
    let verifiedUpload: Bool?
}

private final class OneShotGate {
    private let lock = NSLock()
    private var finished = false

    func claim() -> Bool {
        lock.lock()
        defer { lock.unlock() }
        guard !finished else { return false }
        finished = true
        return true
    }
}

private final class WeakURLSessionTaskBox {
    weak var task: URLSessionTask?
}

private final class CameraBackupRunContext {
    let tasks: [BackupTaskItem]
    let totalAssets: Int
    let stateKey: String
    let baseUrl: String
    let pool: String
    let token: String
    let mediaMode: CameraMediaMode
    let storageMode: CameraStorageMode
    let deviceFolder: String
    let imageFolderLimit: Int
    let videoFolderLimit: Int
    let deleteAfterUpload: Bool
    let completion: (Bool, String) -> Void
    let finishGate = OneShotGate()
    private let progressLock = NSLock()
    private let deletionLock = NSLock()
    private var lastProgressAt = Date.distantPast
    private var deletionAssetsByIdentifier: [String: PHAsset] = [:]

    var cursor = 0
    var completedCount: Int
    var backedUpSet: Set<String>
    var failedItems: [String] = []

    init(tasks: [BackupTaskItem], totalAssets: Int, completedCount: Int, backedUpSet: Set<String>, assetsToDelete: [PHAsset], stateKey: String, baseUrl: String, pool: String, token: String, mediaMode: CameraMediaMode, storageMode: CameraStorageMode, deviceFolder: String, imageFolderLimit: Int, videoFolderLimit: Int, deleteAfterUpload: Bool, completion: @escaping (Bool, String) -> Void) {
        self.tasks = tasks
        self.totalAssets = totalAssets
        self.completedCount = completedCount
        self.backedUpSet = backedUpSet
        self.stateKey = stateKey
        self.baseUrl = baseUrl
        self.pool = pool
        self.token = token
        self.mediaMode = mediaMode
        self.storageMode = storageMode
        self.deviceFolder = deviceFolder
        self.imageFolderLimit = imageFolderLimit
        self.videoFolderLimit = videoFolderLimit
        self.deleteAfterUpload = deleteAfterUpload
        self.completion = completion
        for asset in assetsToDelete { deletionAssetsByIdentifier[asset.localIdentifier] = asset }
    }

    func shouldReportProgress(force: Bool = false) -> Bool {
        progressLock.lock()
        defer { progressLock.unlock() }
        let now = Date()
        if force || now.timeIntervalSince(lastProgressAt) >= 0.3 {
            lastProgressAt = now
            return true
        }
        return false
    }

    func recordFailure(_ value: String) {
        failedItems.append(value)
    }

    func addAssetForDeletion(_ asset: PHAsset) {
        deletionLock.lock()
        deletionAssetsByIdentifier[asset.localIdentifier] = asset
        deletionLock.unlock()
    }

    func deletionAssets() -> [PHAsset] {
        deletionLock.lock()
        defer { deletionLock.unlock() }
        return Array(deletionAssetsByIdentifier.values)
    }
}

private final class CameraFileUploadContext {
    let fileUrl: URL
    let fileName: String
    let targetFolder: String
    let baseUrl: String
    let pool: String
    let token: String
    let totalSize: Int64
    let onProgress: (Int64, Int64, Int64) -> Void
    let completion: (Bool, Int, String?) -> Void
    let finishGate = OneShotGate()

    var uploadId = ""
    var currentOffset: Int64 = 0
    var startedOffset: Int64 = 0
    var startedAt = Date()
    var sessionRecoveryCount = 0
    let maximumSessionRecoveries = 8

    init(fileUrl: URL, fileName: String, targetFolder: String, baseUrl: String, pool: String, token: String, totalSize: Int64, onProgress: @escaping (Int64, Int64, Int64) -> Void, completion: @escaping (Bool, Int, String?) -> Void) {
        self.fileUrl = fileUrl
        self.fileName = fileName
        self.targetFolder = targetFolder
        self.baseUrl = baseUrl
        self.pool = pool
        self.token = token
        self.totalSize = totalSize
        self.onProgress = onProgress
        self.completion = completion
    }

    func finish(_ ok: Bool, _ code: Int, _ error: String?) {
        guard finishGate.claim() else { return }
        completion(ok, code, error)
    }
}

class MainViewController: UIViewController, WKNavigationDelegate, WKScriptMessageHandler, UIScrollViewDelegate, UIDocumentPickerDelegate, UIDocumentInteractionControllerDelegate, PHPickerViewControllerDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    private var webView: WKWebView!
    private let webAssetVersion = "1.6.45"
    private var isLoaded = false
    private var attemptedWebAssetRepair = false
    private var netBrowser: NWBrowser?
    private var pendingPickerCbId: String?
    private var pendingPickerIsFolder = false
    private var documentInteractionController: UIDocumentInteractionController?
    private var miniMusicPlayer: MiniMusicPlayerView?
    private var isPresentingMusicPlayer = false
    // Tất cả upload/download do người dùng chọn đi qua cùng một hàng đợi.
    // Nhờ vậy nhiều tệp lớn không tranh băng thông/RAM và tệp sau chỉ chạy
    // khi tệp trước đã hoàn tất hoặc trả lỗi.
    private let manualTransferQueue = DispatchQueue(label: "com.cw.datacenter.manual-transfer", qos: .userInitiated)

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .default
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.94, green: 0.96, blue: 1.0, alpha: 1.0)
        triggerLocalNetworkPermission()
        setupWebView()
        setupMiniMusicPlayer()
        setupGestures()
        loadLocalAppRefreshingCacheIfNeeded()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        webView?.evaluateJavaScript("window.collectIncomingShares && window.collectIncomingShares()", completionHandler: nil)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        layoutWebViewAndMiniPlayer()
    }

    private func setupMiniMusicPlayer() {
        let mini = MiniMusicPlayerView()
        mini.isHidden = MusicPlaybackManager.shared.current == nil
        mini.onOpen = { [weak self] in self?.presentMusicPlayer() }
        mini.onVisibilityChanged = { [weak self] _ in
            self?.layoutWebViewAndMiniPlayer()
            self?.pushSafeAreaInsets()
        }
        view.addSubview(mini)
        miniMusicPlayer = mini
        layoutWebViewAndMiniPlayer()
    }

    private func layoutWebViewAndMiniPlayer() {
        guard let webView else { return }
        let bounds = view.bounds
        let showMini = miniMusicPlayer?.isHidden == false
        let topInset = view.safeAreaInsets.top
        let webTop = showMini ? topInset + 76 : 0
        webView.frame = CGRect(x: 0, y: webTop, width: bounds.width, height: max(0, bounds.height - webTop))
        if let mini = miniMusicPlayer {
            mini.frame = CGRect(x: 10, y: topInset + 7, width: max(0, bounds.width - 20), height: 62)
        }
    }

    private func presentMusicPlayer() {
        guard MusicPlaybackManager.shared.current != nil else { return }
        guard !isPresentingMusicPlayer else { return }
        if presentedViewController is MusicPlayerViewController { return }
        guard presentedViewController == nil else {
            AppLogger.shared.log(.warning, category: "MUSIC", "Không mở player vì đang hiển thị \(String(describing: presentedViewController))")
            return
        }
        isPresentingMusicPlayer = true
        let controller = MusicPlayerViewController()
        controller.modalPresentationStyle = .fullScreen
        present(controller, animated: true) { [weak self] in
            self?.isPresentingMusicPlayer = false
        }
    }

    private func photoFavoriteAction(item: [String: Any], completion: @escaping (Bool) -> Void) {
        guard JSONSerialization.isValidJSONObject(item),
              let data = try? JSONSerialization.data(withJSONObject: item),
              let json = String(data: data, encoding: .utf8) else { completion(false); return }
        let script = "window.CWPhotoFavoriteToggle ? window.CWPhotoFavoriteToggle(\(json)) : false"
        webView.evaluateJavaScript(script) { value, error in
            if let error = error {
                AppLogger.shared.log(.error, category: "PHOTO", "Không cập nhật được yêu thích: \(error.localizedDescription)")
            }
            DispatchQueue.main.async { completion(value as? Bool ?? false) }
        }
    }

    private func videoFavoriteAction(item: [String: Any], completion: @escaping (Bool) -> Void) {
        guard JSONSerialization.isValidJSONObject(item),
              let data = try? JSONSerialization.data(withJSONObject: item),
              let json = String(data: data, encoding: .utf8) else { completion(false); return }
        let script = "window.CWVideoFavoriteToggle ? window.CWVideoFavoriteToggle(\(json)) : false"
        webView.evaluateJavaScript(script) { value, error in
            if let error {
                AppLogger.shared.log(.error, category: "VIDEO", "Không cập nhật được yêu thích: \(error.localizedDescription)")
            }
            DispatchQueue.main.async { completion(value as? Bool ?? false) }
        }
    }

    private func videoFileRequest(item: [String: Any], method: String) -> URLRequest? {
        let rawUrl = item["url"] as? String ?? ""
        if rawUrl.hasPrefix("file://"), let localUrl = URL(string: rawUrl) {
            return URLRequest(url: localUrl)
        }
        let rel = item["rel"] as? String ?? ""
        let pool = item["pool"] as? String ?? "main"
        guard !rel.isEmpty else { return nil }
        let localBase = LocalProxy.shared.baseUrl.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let remoteBase = (item["baseUrl"] as? String ?? "").trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let base = localBase.isEmpty ? remoteBase : localBase
        guard !base.isEmpty else { return nil }
        guard var components = URLComponents(string: base + "/api/file") else { return nil }
        var queryItems = [
            URLQueryItem(name: "path", value: rel),
            URLQueryItem(name: "pool", value: pool)
        ]
        if method == "GET" { queryItems.append(URLQueryItem(name: "download", value: "1")) }
        components.queryItems = queryItems
        guard let url = components.url else { return nil }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.timeoutInterval = 210
        let authToken = LocalProxy.shared.token.isEmpty ? (item["token"] as? String ?? "") : LocalProxy.shared.token
        if !authToken.isEmpty {
            request.setValue("Bearer " + authToken, forHTTPHeaderField: "Authorization")
        }
        return request
    }

    private func safeVideoFileName(_ item: [String: Any]) -> String {
        let raw = (item["name"] as? String ?? "video.mp4") as NSString
        let name = raw.lastPathComponent.trimmingCharacters(in: .whitespacesAndNewlines)
        return name.isEmpty ? "video.mp4" : name
    }

    private func saveVideoToPhotoLibrary(fileUrl: URL, completion: @escaping (Bool, String?) -> Void) {
        guard FileManager.default.fileExists(atPath: fileUrl.path) else {
            completion(false, "Không tìm thấy video đã tải để lưu vào ứng dụng Ảnh.")
            return
        }

        let saveAsset = {
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: fileUrl)
            }) { success, error in
                DispatchQueue.main.async {
                    completion(success, success ? nil : (error?.localizedDescription ?? "iOS không thể lưu video vào ứng dụng Ảnh."))
                }
            }
        }

        switch PHPhotoLibrary.authorizationStatus(for: .addOnly) {
        case .authorized, .limited:
            saveAsset()
        case .notDetermined:
            PHPhotoLibrary.requestAuthorization(for: .addOnly) { status in
                if status == .authorized || status == .limited {
                    saveAsset()
                } else {
                    DispatchQueue.main.async {
                        completion(false, "Chưa cấp quyền thêm video vào ứng dụng Ảnh. Hãy bật quyền Ảnh trong Cài đặt iOS.")
                    }
                }
            }
        case .denied, .restricted:
            completion(false, "Ứng dụng chưa có quyền thêm video vào Ảnh. Hãy mở Cài đặt iOS → CW Datacenter → Ảnh và cho phép thêm ảnh.")
        @unknown default:
            completion(false, "iOS không cấp quyền lưu video vào ứng dụng Ảnh.")
        }
    }

    private func prepareVideoFile(item: [String: Any], forSharing: Bool,
                                  completion: @escaping (URL?, String?) -> Void) {
        guard let request = videoFileRequest(item: item, method: "GET") else {
            completion(nil, "Địa chỉ video không hợp lệ.")
            return
        }
        let name = safeVideoFileName(item)
        let rel = item["rel"] as? String ?? name
        let pool = item["pool"] as? String ?? "main"
        let timestamp = Int(Date().timeIntervalSince1970 * 1000)
        let downloadId = "video-\(UInt(bitPattern: (rel + pool).hashValue))-\(timestamp)"
        let transferKey = (forSharing ? "share:video:" : "dl:video-player:") + pool + ":" + rel + ":\(timestamp)"
        let expectedSize = max(0, int64Value(item["size"]))

        if !forSharing {
            emitEvent([
                "type": "transfer", "origin": "videoPlayer", "id": downloadId, "key": transferKey,
                "dir": "down", "name": name, "rel": rel, "pool": pool,
                "status": "queued", "done": 0, "total": expectedSize
            ])
        }

        if request.url?.isFileURL == true, let localUrl = request.url,
           FileManager.default.fileExists(atPath: localUrl.path) {
            if forSharing { completion(localUrl, nil); return }
            let destination = localDocumentsDirectory.appendingPathComponent(name)
            do {
                if localUrl.standardizedFileURL != destination.standardizedFileURL {
                    try? FileManager.default.removeItem(at: destination)
                    try FileManager.default.copyItem(at: localUrl, to: destination)
                }
                let actualSize = Int64((try? destination.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? Int(expectedSize))
                emitEvent(["type": "transfer", "id": downloadId, "key": transferKey, "status": "active", "done": actualSize, "total": actualSize])
                saveVideoToPhotoLibrary(fileUrl: destination) { [weak self] saved, errorText in
                    if saved {
                        self?.emitEvent(["type": "transfer", "id": downloadId, "key": transferKey, "status": "done", "done": actualSize, "total": actualSize, "path": destination.path])
                        completion(destination, "Đã lưu video vào ứng dụng Ảnh.")
                    } else {
                        self?.emitTransferError(id: downloadId, key: transferKey, message: errorText ?? "Không lưu được video vào ứng dụng Ảnh.")
                        completion(nil, errorText)
                    }
                }
            } catch {
                emitTransferError(id: downloadId, key: transferKey, message: error.localizedDescription)
                completion(nil, error.localizedDescription)
            }
            return
        }

        let destination: URL
        if forSharing {
            let cacheKey = String(UInt(bitPattern: (rel + "|" + (item["pool"] as? String ?? "main")).hashValue))
            let folder = FileManager.default.temporaryDirectory
                .appendingPathComponent("CWVideoShare", isDirectory: true)
                .appendingPathComponent(cacheKey, isDirectory: true)
            do { try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true) }
            catch { completion(nil, error.localizedDescription); return }
            destination = folder.appendingPathComponent(name)
        } else {
            destination = localDocumentsDirectory.appendingPathComponent(name)
        }
        manualTransferQueue.async { [weak self] in
            guard let self else { return }
            self.runResumableDownload(
                sourceUrl: request.url!,
                token: LocalProxy.shared.token.isEmpty ? (item["token"] as? String ?? "") : LocalProxy.shared.token,
                destination: destination,
                downloadId: downloadId,
                transferKey: transferKey,
                emitCompletion: forSharing
            ) { ok, errorText in
                DispatchQueue.main.async {
                    guard ok else { completion(nil, errorText); return }
                    if forSharing {
                        completion(destination, nil)
                        return
                    }
                    self.saveVideoToPhotoLibrary(fileUrl: destination) { saved, saveError in
                        if saved {
                            let actualSize = Int64((try? destination.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? Int(expectedSize))
                            self.emitEvent(["type": "transfer", "id": downloadId, "key": transferKey, "status": "done", "done": actualSize, "total": actualSize, "path": destination.path])
                            completion(destination, "Đã lưu video vào ứng dụng Ảnh.")
                        } else {
                            let message = saveError ?? "Không lưu được video vào ứng dụng Ảnh."
                            self.emitTransferError(id: downloadId, key: transferKey, message: message)
                            completion(nil, message)
                        }
                    }
                }
            }
        }
    }

    private func deleteVideo(item: [String: Any], completion: @escaping (Bool, String?) -> Void) {
        guard var request = videoFileRequest(item: item, method: "DELETE") else {
            completion(false, "Đường dẫn video không hợp lệ.")
            return
        }
        if request.url?.isFileURL == true, let localUrl = request.url {
            do { try FileManager.default.removeItem(at: localUrl); completion(true, "Đã xóa video khỏi thiết bị.") }
            catch { completion(false, error.localizedDescription) }
            return
        }
        request.httpMethod = "DELETE"
        URLSession.shared.dataTask(with: request) { [weak self] _, response, error in
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            let ok = error == nil && (200..<300).contains(status)
            DispatchQueue.main.async {
                if ok, let self,
                   JSONSerialization.isValidJSONObject(item),
                   let data = try? JSONSerialization.data(withJSONObject: item),
                   let json = String(data: data, encoding: .utf8) {
                    self.webView.evaluateJavaScript("window.CWVideoDeleted && window.CWVideoDeleted(\(json));", completionHandler: nil)
                }
                completion(ok, ok ? "Đã chuyển video vào Thùng rác." : (error?.localizedDescription ?? "Host trả về lỗi \(status)."))
            }
        }.resume()
    }

    private func photoRequest(item: [String: Any], method: String, preview: Bool) -> URLRequest? {
        let localPath = item["localPath"] as? String ?? ""
        if method == "GET", !localPath.isEmpty {
            return URLRequest(url: URL(fileURLWithPath: localPath))
        }
        let rel = item["rel"] as? String ?? ""
        let pool = item["pool"] as? String ?? ""
        if method == "GET", let raw = item["url"] as? String, let direct = URL(string: raw), !raw.isEmpty {
            var request = URLRequest(url: direct)
            request.httpMethod = method
            if !LocalProxy.shared.token.isEmpty { request.setValue("Bearer " + LocalProxy.shared.token, forHTTPHeaderField: "Authorization") }
            return request
        }
        guard !rel.isEmpty else { return nil }
        let base = LocalProxy.shared.baseUrl.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard var components = URLComponents(string: base + "/api/file") else { return nil }
        var query = [URLQueryItem(name: "path", value: rel)]
        if !pool.isEmpty { query.append(URLQueryItem(name: "pool", value: pool)) }
        if preview { query.append(URLQueryItem(name: "preview", value: "1")) }
        components.queryItems = query
        guard let url = components.url else { return nil }
        var request = URLRequest(url: url)
        request.httpMethod = method
        if !LocalProxy.shared.token.isEmpty { request.setValue("Bearer " + LocalProxy.shared.token, forHTTPHeaderField: "Authorization") }
        return request
    }

    private func savePhoto(item: [String: Any], completion: @escaping (Bool, String?) -> Void) {
        let persist: (UIImage) -> Void = { image in
            PHPhotoLibrary.requestAuthorization(for: .addOnly) { status in
                guard status == .authorized || status == .limited else { completion(false, "Chưa cấp quyền lưu vào Thư viện ảnh."); return }
                PHPhotoLibrary.shared().performChanges({ PHAssetChangeRequest.creationRequestForAsset(from: image) }) { ok, error in
                    completion(ok, error?.localizedDescription)
                }
            }
        }
        let localPath = item["localPath"] as? String ?? ""
        if !localPath.isEmpty, let image = UIImage(contentsOfFile: localPath) { persist(image); return }
        guard let request = photoRequest(item: item, method: "GET", preview: true) else { completion(false, "Địa chỉ ảnh không hợp lệ."); return }
        URLSession.shared.dataTask(with: request) { data, response, error in
            guard error == nil, let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode), let data = data, let image = UIImage(data: data) else {
                completion(false, error?.localizedDescription ?? "Không tải được ảnh từ Host.")
                return
            }
            persist(image)
        }.resume()
    }

    private func deletePhoto(item: [String: Any], completion: @escaping (Bool, String?) -> Void) {
        let localPath = item["localPath"] as? String ?? ""
        if !localPath.isEmpty {
            do { try FileManager.default.removeItem(atPath: localPath); completion(true, "Đã xóa ảnh khỏi thiết bị.") }
            catch { completion(false, error.localizedDescription) }
            return
        }
        guard let request = photoRequest(item: item, method: "DELETE", preview: false) else { completion(false, "Đường dẫn ảnh không hợp lệ."); return }
        URLSession.shared.dataTask(with: request) { [weak self] _, response, error in
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            let ok = error == nil && (200..<300).contains(status)
            if ok {
                DispatchQueue.main.async {
                    self?.webView.evaluateJavaScript("if (typeof loadFiles === 'function') loadFiles(currentPath);", completionHandler: nil)
                    if JSONSerialization.isValidJSONObject(item),
                       let data = try? JSONSerialization.data(withJSONObject: item),
                       let json = String(data: data, encoding: .utf8) {
                        self?.webView.evaluateJavaScript("window.CWOverviewMediaDeleted && window.CWOverviewMediaDeleted(\(json));", completionHandler: nil)
                    }
                }
            }
            completion(ok, ok ? "Đã chuyển ảnh vào Thùng rác." : (error?.localizedDescription ?? "Host trả về lỗi \(status)."))
        }.resume()
    }

    private func setupGestures() {
        let edgePan = UIScreenEdgePanGestureRecognizer(target: self, action: #selector(handleEdgePan(_:)))
        edgePan.edges = .left
        webView.addGestureRecognizer(edgePan)
    }

    @objc private func handleEdgePan(_ gesture: UIScreenEdgePanGestureRecognizer) {
        guard gesture.state == .ended else { return }
        let js = """
        (function() {
            if (typeof onHardwareBack === 'function') {
                onHardwareBack();
            } else if (typeof closePreviewModal === 'function' && document.getElementById('pvModal')?.classList.contains('show')) {
                closePreviewModal();
            } else if (typeof goDir === 'function' && typeof parentPath !== 'undefined' && parentPath !== null) {
                goDir(parentPath);
            }
        })();
        """
        webView.evaluateJavaScript(js, completionHandler: nil)
    }

    private func triggerLocalNetworkPermission() {
        let params = NWParameters()
        params.includePeerToPeer = true
        let descriptor = NWBrowser.Descriptor.bonjour(type: "_http._tcp", domain: nil)
        netBrowser = NWBrowser(for: descriptor, using: params)
        netBrowser?.stateUpdateHandler = { _ in }
        netBrowser?.start(queue: .main)
    }

    override func viewSafeAreaInsetsDidChange() {
        super.viewSafeAreaInsetsDidChange()
        pushSafeAreaInsets()
    }

    private func setupWebView() {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.allowsPictureInPictureMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        if #available(iOS 15.4, *) {
            config.preferences.isElementFullscreenEnabled = true
        }

        let userContent = WKUserContentController()
        userContent.add(self, name: "DC")

        // Comprehensive JS bridge helper matching Android Bridge API
        let bridgeJs = """
        window.DC = window.DC || {};
        window.DC.call = function(method, id, args) {
            window.webkit.messageHandlers.DC.postMessage({ method: method, id: id, args: args });
        };
        window.DC.getMeta = function() {
            return JSON.stringify({
                device: "iPhone",
                manufacturer: "Apple",
                brand: "Apple",
                model: "iPhone",
                ios: "iOS",
                platform: "ios"
            });
        };
        window.DC.getInsets = function() {
            return "47,34";
        };
        window.DC.loadKV = function(k) {
            try { return localStorage.getItem("cw_kv_" + k); } catch(e) { return null; }
        };
        window.DC.saveKV = function(k, v) {
            try { localStorage.setItem("cw_kv_" + k, v); } catch(e) {}
        };
        window.DC.removeKV = function(k) {
            try { localStorage.removeItem("cw_kv_" + k); } catch(e) {}
        };
        window.DC.setCanGoBack = function(can) {};
        window.DC.setSession = function(url, tk) {
            window.DC.call('setSession', '', [url, tk]);
        };
        window.DC._localProxyPort = 0;
        window.DC.proxyUrl = function(rel, pool, video) {
            if (!window.DC._localProxyPort) return '';
            var value = 'http://127.0.0.1:' + window.DC._localProxyPort + '/play?path=' + rel;
            if (pool) value += '&pool=' + pool;
            if (video) value += '&video=1';
            return value;
        };
        window.DC.thumbUrl = function(rel, pool, size) {
            if (!window.DC._localProxyPort) return '';
            var value = 'http://127.0.0.1:' + window.DC._localProxyPort + '/play?path=' + rel + '&thumb=1&size=' + (size || 160);
            if (pool) value += '&pool=' + pool;
            return value;
        };
        window.DC.localFsUrl = function(spec) {
            if (!window.DC._localProxyPort) return '';
            return 'http://127.0.0.1:' + window.DC._localProxyPort + '/local?spec=' + encodeURIComponent(spec || '');
        };
        window.DC.toast = function(msg) {
            if (typeof showUiToast === 'function') {
                showUiToast(msg);
            } else {
                console.log("[CW_TOAST]", msg);
            }
        };
        window.DC.appLog = function(level, category, message) {
            try {
                window.DC.call('clientLog', '', [{ level: level || 'INFO', category: category || 'WEB', message: String(message || '') }]);
            } catch(e) {}
        };
        window.addEventListener('error', function(event) {
            var where = event.filename ? (' @ ' + event.filename + ':' + event.lineno + ':' + event.colno) : '';
            window.DC.appLog('ERROR', 'WEB', (event.message || 'JavaScript error') + where);
        });
        window.addEventListener('unhandledrejection', function(event) {
            var reason = event.reason && (event.reason.stack || event.reason.message || JSON.stringify(event.reason));
            window.DC.appLog('ERROR', 'WEB_PROMISE', reason || 'Unhandled promise rejection');
        });
        window.DC.cameraBackupStats = function(cb) {
            window.DC.call('cameraBackupStats', cb || '', []);
        };
        window.DC.startCameraBackup = function(opts, cb) {
            window.DC.call('startCameraBackup', cb || '', [opts]);
        };
        window.DC.pauseCameraBackup = function(cb) {
            window.DC.call('pauseCameraBackup', cb || '', []);
        };
        document.addEventListener('gesturestart', function(e) { e.preventDefault(); }, { passive: false });
        document.addEventListener('gesturechange', function(e) { e.preventDefault(); }, { passive: false });
        document.addEventListener('gestureend', function(e) { e.preventDefault(); }, { passive: false });
        document.addEventListener('dblclick', function(e) { e.preventDefault(); }, { passive: false });
        
        // Prevent viewport zoom when keyboard opens
        function installIOSViewportStyle() {
            if (!document.head || document.getElementById('cw-ios-native-style')) return;
            var styleEl = document.createElement('style');
            styleEl.id = 'cw-ios-native-style';
            styleEl.innerHTML = 'input, select, textarea { font-size: 16px !important; } html, body { overflow: hidden !important; -webkit-text-size-adjust: 100% !important; }';
            document.head.appendChild(styleEl);
        }
        if (document.head) installIOSViewportStyle();
        else document.addEventListener('DOMContentLoaded', installIOSViewportStyle, { once: true });
        """
        let script = WKUserScript(source: bridgeJs, injectionTime: .atDocumentStart, forMainFrameOnly: true)
        userContent.addUserScript(script)
        config.userContentController = userContent

        webView = WKWebView(frame: view.bounds, configuration: config)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        webView.navigationDelegate = self
        webView.scrollView.delegate = self
        webView.scrollView.bounces = false
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.bouncesZoom = false
        webView.scrollView.pinchGestureRecognizer?.isEnabled = false
        webView.scrollView.maximumZoomScale = 1.0
        webView.scrollView.minimumZoomScale = 1.0
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.isOpaque = false
        webView.backgroundColor = .clear
        view.addSubview(webView)
    }

    // MARK: - UIScrollViewDelegate (Strictly Disable Zoom & Keyboard Jumps)
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return nil
    }

    func scrollViewWillBeginZooming(_ scrollView: UIScrollView, with view: UIView?) {
        scrollView.pinchGestureRecognizer?.isEnabled = false
    }

    private func loadLocalApp() {
        if let webDir = Bundle.main.url(forResource: "Web", withExtension: nil) {
            let indexUrl = webDir.appendingPathComponent("index.html")
            webView.loadFileURL(indexUrl, allowingReadAccessTo: webDir)
        } else if let indexUrl = Bundle.main.url(forResource: "index", withExtension: "html") {
            webView.loadFileURL(indexUrl, allowingReadAccessTo: indexUrl.deletingLastPathComponent())
        }
    }

    private func loadLocalAppRefreshingCacheIfNeeded() {
        let versionKey = "cw_web_asset_version"
        guard UserDefaults.standard.string(forKey: versionKey) != webAssetVersion else {
            loadLocalApp()
            return
        }

        // Chỉ xóa cache HTTP/WebKit. Không xóa localStorage vì trong đó có host,
        // token và các lựa chọn của người dùng.
        let cacheTypes: Set<String> = [WKWebsiteDataTypeDiskCache, WKWebsiteDataTypeMemoryCache]
        WKWebsiteDataStore.default().removeData(ofTypes: cacheTypes, modifiedSince: .distantPast) { [weak self] in
            DispatchQueue.main.async {
                guard let self = self else { return }
                UserDefaults.standard.set(self.webAssetVersion, forKey: versionKey)
                self.loadLocalApp()
            }
        }
    }

    private func pushSafeAreaInsets() {
        let insets = view.safeAreaInsets
        let top = miniMusicPlayer?.isHidden == false ? 0 : Int(insets.top)
        let bottom = Int(insets.bottom)
        let js = "window.DC && DC._insets && DC._insets(\(top), \(bottom));"
        webView?.evaluateJavaScript(js, completionHandler: nil)
    }

    // MARK: - WKNavigationDelegate
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        isLoaded = true
        pushSafeAreaInsets()
        verifyLoadedWebAssets()
        let model = getHardwareModelName()
        let rawName = UIDevice.current.name.trimmingCharacters(in: .whitespacesAndNewlines)
        let safeName = rawName.components(separatedBy: CharacterSet.alphanumerics.inverted).filter { !$0.isEmpty }.joined(separator: "_")
        let devName = (!safeName.isEmpty && safeName.lowercased() != "iphone") ? safeName : model
        let js = "window.DC = window.DC || {}; window.DC.platform = 'ios'; window.DC._deviceName = '\(devName)'; window.DC._hardwareModel = '\(model)';"
        webView.evaluateJavaScript(js, completionHandler: nil)
    }

    private func verifyLoadedWebAssets() {
        let js = "[document.querySelector('meta[name=\\\"cw-web-version\\\"]')?.content || '', window.CW_WEB_VERSION || '']"
        webView.evaluateJavaScript(js) { [weak self] value, _ in
            guard let self = self else { return }
            let versions = value as? [String] ?? []
            guard versions.count == 2,
                  versions[0] == self.webAssetVersion,
                  versions[1] == self.webAssetVersion else {
                if !self.attemptedWebAssetRepair {
                    self.attemptedWebAssetRepair = true
                    let types: Set<String> = [WKWebsiteDataTypeDiskCache, WKWebsiteDataTypeMemoryCache]
                    WKWebsiteDataStore.default().removeData(ofTypes: types, modifiedSince: .distantPast) { [weak self] in
                        DispatchQueue.main.async { self?.loadLocalApp() }
                    }
                } else {
                    let message = "Bộ giao diện trong IPA không đồng bộ. Hãy tải lại đúng bản iOS 1.6.45."
                    let payload = self.jsonString([message])
                    let fatalJs = "document.body.innerHTML='<main style=\\\"font-family:-apple-system;padding:48px 24px;text-align:center;color:#111827\\\"><h2>Không thể nạp giao diện</h2><p id=\\\"cw-fatal\\\"></p></main>';document.getElementById('cw-fatal').textContent=\(payload)[0];"
                    self.webView.evaluateJavaScript(fatalJs, completionHandler: nil)
                }
                return
            }
            self.attemptedWebAssetRepair = false
        }
    }

    // MARK: - WKScriptMessageHandler
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "DC", let body = message.body as? [String: Any] else { return }
        let method = body["method"] as? String ?? ""
        let cbId = body["id"] as? String ?? ""
        
        var args: [Any] = []
        if let arr = body["args"] as? [Any] {
            args = arr
        } else if let argsStr = body["args"] as? String {
            if let data = argsStr.data(using: .utf8), let parsed = try? JSONSerialization.jsonObject(with: data) as? [Any] {
                args = parsed
            } else if !argsStr.isEmpty {
                args = [argsStr]
            }
        }

        handleNativeCall(method: method, cbId: cbId, args: args)
    }

    private func isTailscaleAddress(_ host: String?) -> Bool {
        guard let host = host?.trimmingCharacters(in: .whitespacesAndNewlines), !host.isEmpty else { return false }
        let octets = host.split(separator: ".").compactMap { Int($0) }
        return octets.count == 4 && octets[0] == 100 && (64...127).contains(octets[1])
    }

    private func apiSessionConfiguration(for url: URL) -> URLSessionConfiguration {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 20
        config.timeoutIntervalForResource = 40
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.waitsForConnectivity = false
        config.allowsCellularAccess = true
        config.allowsExpensiveNetworkAccess = true
        config.allowsConstrainedNetworkAccess = true
        config.httpShouldUsePipelining = true
        config.httpMaximumConnectionsPerHost = 4
        // Dải CGNAT 100.64.0.0/10 của Tailscale phải đi trực tiếp qua tunnel.
        // Không để HTTP proxy của Wi-Fi chặn hoặc định tuyến nhầm request đăng nhập.
        if isTailscaleAddress(url.host) {
            config.connectionProxyDictionary = [:]
        }
        return config
    }

    private func handleNativeCall(method: String, cbId: String, args: [Any]) {
        switch method {
        case "clientLog":
            let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) ?? [:]
            let rawLevel = (params["level"] as? String ?? "INFO").uppercased()
            let level: AppLogLevel = rawLevel == "ERROR" ? .error : (rawLevel == "WARN" || rawLevel == "WARNING" ? .warning : (rawLevel == "DEBUG" ? .debug : .info))
            let category = params["category"] as? String ?? "WEB"
            let text = params["message"] as? String ?? ""
            AppLogger.shared.log(level, category: category, text)
            if !cbId.isEmpty { callback(cbId: cbId, ok: true, json: "{}") }

        case "appLogs":
            AppLogger.shared.recentText { [weak self] text, size in
                let payload: [String: Any] = ["text": text, "size": size, "version": "1.6.45"]
                self?.callback(cbId: cbId, ok: true, json: self?.jsonString(payload) ?? "{}")
            }

        case "clearAppLogs":
            AppLogger.shared.clear { [weak self] in
                AppLogger.shared.log(.info, category: "LOG", "Người dùng đã xóa nhật ký")
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "shareAppLogs":
            AppLogger.shared.makeExportFile { [weak self] url in
                guard let self = self else { return }
                guard let url = url else {
                    self.callback(cbId: cbId, ok: false, json: "{\"err\":\"Không tạo được file log\"}")
                    return
                }
                let controller = UIActivityViewController(activityItems: [url], applicationActivities: nil)
                if let popover = controller.popoverPresentationController {
                    popover.sourceView = self.view
                    popover.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
                    popover.permittedArrowDirections = []
                }
                AppLogger.shared.log(.info, category: "LOG", "Mở bảng chia sẻ file log")
                self.present(controller, animated: true)
                self.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "invoke":
            let httpMethod = args.indices.contains(0) ? (args[0] as? String ?? "GET") : "GET"
            var urlString = args.indices.contains(1) ? (args[1] as? String ?? "") : ""
            let headersJson = args.indices.contains(2) ? (args[2] as? String ?? "{}") : "{}"
            let bodyStr = args.indices.contains(3) ? (args[3] as? String) : nil

            urlString = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
            if !urlString.starts(with: "http://") && !urlString.starts(with: "https://") {
                urlString = "http://" + urlString
            }

            guard let url = URL(string: urlString) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"URL không hợp lệ: \(urlString)\"}")
                return
            }

            var request = URLRequest(url: url, timeoutInterval: 20)
            request.httpMethod = httpMethod
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            if let headersData = headersJson.data(using: .utf8),
               let headers = try? JSONSerialization.jsonObject(with: headersData) as? [String: String] {
                for (k, v) in headers {
                    request.setValue(v, forHTTPHeaderField: k)
                }
            }
            if let bodyStr = bodyStr, !bodyStr.isEmpty, httpMethod != "GET" && httpMethod != "HEAD" {
                if request.value(forHTTPHeaderField: "Content-Type") == nil {
                    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                }
                request.httpBody = bodyStr.data(using: .utf8)
            }

            let sessionConfig = apiSessionConfiguration(for: url)
            let session = URLSession(configuration: sessionConfig)

            session.dataTask(with: request) { [weak self] data, response, error in
                defer { session.finishTasksAndInvalidate() }
                if let error = error {
                    let failure = error as NSError
                    AppLogger.shared.log(.error, category: "HTTP", "\(httpMethod) \(url.host ?? "")\(url.path) thất bại [\(failure.domain):\(failure.code)]: \(failure.localizedDescription)")
                    let errMsg = HostConnectionDiagnostics.message(for: error, url: url)
                    let errorBody = (try? JSONSerialization.data(withJSONObject: ["error": errMsg]))
                        .flatMap { String(data: $0, encoding: .utf8) } ?? "{}"
                    let payload: [String: Any] = [
                        "status": 0,
                        "text": errorBody,
                        "err": errMsg,
                        "errorDomain": failure.domain,
                        "errorCode": failure.code
                    ]
                    if let resData = try? JSONSerialization.data(withJSONObject: payload),
                       let resJson = String(data: resData, encoding: .utf8) {
                        self?.callback(cbId: cbId, ok: false, json: resJson)
                    } else {
                        self?.callback(cbId: cbId, ok: false, json: "{\"err\":\"Không đọc được phản hồi lỗi kết nối.\"}")
                    }
                    return
                }
                let status = (response as? HTTPURLResponse)?.statusCode ?? 200
                if status >= 400 {
                    AppLogger.shared.log(.warning, category: "HTTP", "\(httpMethod) \(url.path) trả HTTP \(status)")
                }
                let text = data.flatMap { String(data: $0, encoding: .utf8) } ?? ""
                
                let payload: [String: Any] = [
                    "status": status,
                    "text": text
                ]
                if let resData = try? JSONSerialization.data(withJSONObject: payload),
                   let resJson = String(data: resData, encoding: .utf8) {
                    self?.callback(cbId: cbId, ok: true, json: resJson)
                } else {
                    self?.callback(cbId: cbId, ok: true, json: "{\"status\":\(status),\"text\":\"\"}")
                }
            }.resume()

        case "discover", "scanLan":
            performLanDiscovery { [weak self] hosts in
                let payload: [String: Any] = ["hosts": hosts]
                if let resData = try? JSONSerialization.data(withJSONObject: payload),
                   let resJson = String(data: resData, encoding: .utf8) {
                    self?.callback(cbId: cbId, ok: true, json: resJson)
                } else {
                    self?.callback(cbId: cbId, ok: true, json: "{\"hosts\":[]}")
                }
            }

        case "toast":
            let msg = args.first as? String ?? ""
            DispatchQueue.main.async { [weak self] in
                let alert = UIAlertController(title: nil, message: msg, preferredStyle: .alert)
                self?.present(alert, animated: true)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    alert.dismiss(animated: true)
                }
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "setSession":
            let baseUrl = args.indices.contains(0) ? (args[0] as? String ?? "") : ""
            let token = args.indices.contains(1) ? (args[1] as? String ?? "") : ""
            LocalProxy.shared.setAuth(baseUrl: baseUrl, token: token)
            AppLogger.shared.log(.info, category: "SESSION", baseUrl.isEmpty ? "Đã ngắt phiên Host" : "Đã đặt phiên Host \(baseUrl); authenticated=\(!token.isEmpty)")
            let proxyPort = LocalProxy.shared.port
            DispatchQueue.main.async { [weak self] in
                self?.webView?.evaluateJavaScript("window.DC && (window.DC._localProxyPort = \(proxyPort));", completionHandler: nil)
            }
            UserDefaults.standard.set(baseUrl, forKey: "cw_base_url")
            UserDefaults.standard.set(token, forKey: "cw_token")
            callback(cbId: cbId, ok: true, json: "{}")

        case "proxyUrl":
            let rel = args.indices.contains(0) ? (args[0] as? String ?? "") : ""
            let pool = args.indices.contains(1) ? (args[1] as? String) : nil
            let isVideo = args.indices.contains(2) ? (args[2] as? Bool ?? false) : false
            let pUrl = LocalProxy.shared.urlFor(relEncoded: rel, poolEncoded: pool, video: isVideo)
            callback(cbId: cbId, ok: true, json: "\"\(pUrl)\"")

        case "thumbUrl":
            let rel = args.indices.contains(0) ? (args[0] as? String ?? "") : ""
            let pool = args.indices.contains(1) ? (args[1] as? String) : nil
            let tUrl = LocalProxy.shared.thumbUrl(relEncoded: rel, poolEncoded: pool)
            callback(cbId: cbId, ok: true, json: "\"\(tUrl)\"")

        case "getInsets":
            let insets = view.safeAreaInsets
            callback(cbId: cbId, ok: true, json: "\"\(Int(insets.top)),\(Int(insets.bottom))\"")

        case "localFsStatus":
            callback(cbId: cbId, ok: true, json: "{\"ok\":true,\"sdk\":17}")

        case "requestLocalFsAccess":
            callback(cbId: cbId, ok: true, json: "{\"ok\":true}")

        case "localFsInfo":
            let docs = localDocumentsDirectory
            var freeBytes: Int64 = 50 * 1024 * 1024 * 1024
            var totalBytes: Int64 = 128 * 1024 * 1024 * 1024
            if let values = try? docs.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey, .volumeTotalCapacityKey]) {
                freeBytes = values.volumeAvailableCapacityForImportantUsage ?? freeBytes
                totalBytes = Int64(values.volumeTotalCapacity ?? Int(totalBytes))
            }
            let payload: [String: Any] = [
                "free": freeBytes,
                "total": totalBytes,
                "rootPath": docs.path,
                "path": docs.path,
                "parentId": docs.path,
                "ok": true
            ]
            if let d = try? JSONSerialization.data(withJSONObject: payload), let j = String(data: d, encoding: .utf8) {
                callback(cbId: cbId, ok: true, json: j)
            } else {
                callback(cbId: cbId, ok: true, json: "{\"free\":50000000000,\"total\":128000000000,\"rootPath\":\"\(docs.path)\",\"path\":\"\(docs.path)\",\"parentId\":\"\(docs.path)\"}")
            }

        case "localFsList":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let reqPath = params["path"] as? String ?? ""
            let targetDir: URL
            if reqPath.isEmpty || reqPath.contains("/storage/emulated/0") {
                targetDir = localDocumentsDirectory
            } else if reqPath.starts(with: "/") {
                targetDir = URL(fileURLWithPath: reqPath)
            } else {
                targetDir = localDocumentsDirectory.appendingPathComponent(reqPath)
            }
            
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                guard let self = self else { return }
                var entries: [[String: Any]] = []
                let fileManager = FileManager.default
                if let items = try? fileManager.contentsOfDirectory(at: targetDir, includingPropertiesForKeys: [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey], options: [.skipsHiddenFiles]) {
                    for item in items {
                        let values = try? item.resourceValues(forKeys: [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey])
                        let isDir = values?.isDirectory ?? false
                        let size = Int64(values?.fileSize ?? 0)
                        let mtime = Int64((values?.contentModificationDate?.timeIntervalSince1970 ?? 0) * 1000)
                        entries.append([
                            "name": item.lastPathComponent,
                            "type": isDir ? "dir" : "file",
                            "dir": isDir,
                            "size": size,
                            "mtime": mtime,
                            "p": item.path,
                            "id": item.path,
                            "path": item.path,
                            "local": true
                        ])
                    }
                }
                let payload: [String: Any] = [
                    "path": targetDir.path,
                    "parentId": targetDir.path,
                    "entries": entries,
                    "ok": true
                ]
                if let d = try? JSONSerialization.data(withJSONObject: payload), let j = String(data: d, encoding: .utf8) {
                    self.callback(cbId: cbId, ok: true, json: j)
                } else {
                    self.callback(cbId: cbId, ok: true, json: "{\"entries\":[]}")
                }
            }

        case "localFsDeepList":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let reqPath = params["path"] as? String ?? ""
            let baseDir: URL
            if reqPath.isEmpty || reqPath.contains("/storage/emulated/0") {
                baseDir = localDocumentsDirectory
            } else if reqPath.starts(with: "/") {
                baseDir = URL(fileURLWithPath: reqPath)
            } else {
                baseDir = localDocumentsDirectory.appendingPathComponent(reqPath)
            }
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                guard let self = self else { return }
                var files: [[String: Any]] = []
                let fileManager = FileManager.default
                if let enumerator = fileManager.enumerator(at: baseDir, includingPropertiesForKeys: [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey], options: [.skipsHiddenFiles]) {
                    for case let fileUrl as URL in enumerator {
                        let values = try? fileUrl.resourceValues(forKeys: [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey])
                        if values?.isDirectory != true {
                            let rel = fileUrl.path.replacingOccurrences(of: baseDir.path + "/", with: "")
                            let size = Int64(values?.fileSize ?? 0)
                            let mtime = Int64((values?.contentModificationDate?.timeIntervalSince1970 ?? 0) * 1000)
                            files.append([
                                "name": fileUrl.lastPathComponent,
                                "rel": rel,
                                "p": fileUrl.path,
                                "size": size,
                                "mtime": mtime
                            ])
                        }
                    }
                }
                let payload: [String: Any] = ["files": files, "ok": true]
                if let d = try? JSONSerialization.data(withJSONObject: payload), let j = String(data: d, encoding: .utf8) {
                    self.callback(cbId: cbId, ok: true, json: j)
                } else {
                    self.callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
                }
            }

        case "openDownloads":
            let docs = localDocumentsDirectory
            DispatchQueue.main.async { [weak self] in
                let activityVc = UIActivityViewController(activityItems: [docs], applicationActivities: nil)
                if let popover = activityVc.popoverPresentationController {
                    popover.sourceView = self?.view
                    popover.sourceRect = CGRect(x: self?.view.bounds.midX ?? 0, y: self?.view.bounds.midY ?? 0, width: 0, height: 0)
                    popover.permittedArrowDirections = []
                }
                self?.present(activityVc, animated: true)
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "localFsMkdir":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let path = params["path"] as? String ?? ""
            let name = params["name"] as? String ?? "Thư mục mới"
            let parentDir = path.isEmpty ? localDocumentsDirectory : URL(fileURLWithPath: path)
            let newDir = parentDir.appendingPathComponent(name)
            try? FileManager.default.createDirectory(at: newDir, withIntermediateDirectories: true)
            callback(cbId: cbId, ok: true, json: "{}")

        case "localFsDelete":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let path = params["path"] as? String ?? ""
            if !path.isEmpty {
                try? FileManager.default.removeItem(atPath: path)
            }
            callback(cbId: cbId, ok: true, json: "{}")

        case "localFsMove":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let from = params["from"] as? String ?? ""
            let to = params["to"] as? String ?? ""
            if !from.isEmpty && !to.isEmpty {
                try? FileManager.default.moveItem(atPath: from, toPath: to)
            }
            callback(cbId: cbId, ok: true, json: "{}")

        case "playAudio":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Thiếu thông tin tệp nhạc\"}")
                return
            }
            var rawPlaylist = params["playlist"] as? [[String: Any]] ?? []
            if rawPlaylist.isEmpty,
               let playlistString = params["playlist"] as? String,
               let data = playlistString.data(using: .utf8),
               let parsed = (try? JSONSerialization.jsonObject(with: data)) as? [[String: Any]] {
                rawPlaylist = parsed
            }
            if rawPlaylist.isEmpty {
                rawPlaylist = [[
                    "name": params["name"] as? String ?? "Bài hát",
                    "url": params["url"] as? String ?? "",
                    "rel": params["rel"] as? String ?? "",
                    "pool": params["pool"] as? String ?? "",
                    "size": params["size"] ?? 0
                ]]
            }
            let musicBaseUrl = (params["baseUrl"] as? String ?? LocalProxy.shared.baseUrl)
                .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            let musicToken = params["token"] as? String ?? LocalProxy.shared.token
            let tracks: [MusicTrack] = rawPlaylist.compactMap { item in
                let rawUrl = (item["url"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                var rel = (item["rel"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                var targetPool = (item["pool"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                var url: URL?

                if rawUrl.starts(with: "file://") {
                    url = URL(string: rawUrl)
                } else {
                    // 1.5.2 used a localhost proxy which buffered the complete
                    // song in RAM. Recover its path if an old Web payload still
                    // reaches this native code, then stream directly from Host.
                    if rel.isEmpty, let components = URLComponents(string: rawUrl), components.host == "127.0.0.1" {
                        let values = Dictionary((components.queryItems ?? []).compactMap { item in
                            item.value.map { (item.name, $0) }
                        }, uniquingKeysWith: { first, _ in first })
                        rel = values["path"] ?? values["file"] ?? ""
                        if targetPool.isEmpty { targetPool = values["pool"] ?? "" }
                    }

                    if !rel.isEmpty, !musicBaseUrl.isEmpty, var components = URLComponents(string: musicBaseUrl + "/api/file") {
                        var query = [
                            URLQueryItem(name: "path", value: rel),
                            URLQueryItem(name: "preview", value: "1")
                        ]
                        if !targetPool.isEmpty { query.append(URLQueryItem(name: "pool", value: targetPool)) }
                        if !musicToken.isEmpty { query.append(URLQueryItem(name: "token", value: musicToken)) }
                        components.queryItems = query
                        url = components.url
                    } else if !rawUrl.isEmpty {
                        url = URL(string: rawUrl)
                    }
                }

                guard let resolvedUrl = url else { return nil }
                var headers: [String: String] = [:]
                if !musicToken.isEmpty && !resolvedUrl.isFileURL {
                    headers["Authorization"] = "Bearer \(musicToken)"
                }
                return MusicTrack(
                    name: item["name"] as? String ?? resolvedUrl.lastPathComponent,
                    url: resolvedUrl,
                    size: self.int64Value(item["size"]),
                    headers: headers
                )
            }
            guard !tracks.isEmpty else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Không mở được địa chỉ tệp nhạc\"}")
                return
            }
            let requestedIndex = params["plIndex"] as? Int ?? 0
            AppLogger.shared.log(.info, category: "MUSIC", "Bridge playAudio; tracks=\(tracks.count); requestedIndex=\(requestedIndex)")
            DispatchQueue.main.async { [weak self] in
                MusicPlaybackManager.shared.load(tracks, index: requestedIndex)
                self?.layoutWebViewAndMiniPlayer()
                self?.pushSafeAreaInsets()
                self?.presentMusicPlayer()
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "playVideo":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            var urlString = params["url"] as? String ?? ""
            let name = params["name"] as? String ?? "Đang phát video"
            let rel = params["rel"] as? String ?? ""
            let pool = params["pool"] as? String ?? ""
            let favorite = params["favorite"] as? Bool ?? false
            let size = (params["size"] as? NSNumber)?.int64Value ?? 0
            let startPos = params["startPos"] as? Int64 ?? -1
            var playlist: [[String: Any]] = []
            if let pl = params["playlist"] as? [[String: Any]] {
                playlist = pl
            } else if let plStr = params["playlist"] as? String, let plData = plStr.data(using: .utf8),
                      let parsed = (try? JSONSerialization.jsonObject(with: plData)) as? [[String: Any]] {
                playlist = parsed
            }
            var subtitleCandidates: [[String: String]] = []
            if let candidates = params["subtitleCandidates"] as? [[String: Any]] {
                subtitleCandidates = candidates.compactMap { item in
                    guard let name = item["name"] as? String, let url = item["url"] as? String else { return nil }
                    return ["name": name, "url": url]
                }
            }

            let base = (params["baseUrl"] as? String ?? LocalProxy.shared.baseUrl).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            let token = params["token"] as? String ?? LocalProxy.shared.token
            if urlString.isEmpty && !rel.isEmpty {
                urlString = "\(base)/api/video?path=\(rel.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? rel)"
                if !pool.isEmpty { urlString += "&pool=\(pool)" }
            }
            if !token.isEmpty && !urlString.contains("token=") && !urlString.starts(with: "file:") {
                urlString += (urlString.contains("?") ? "&" : "?") + "token=\(token)"
            }
            if !urlString.contains("ios=") && !urlString.starts(with: "file:") {
                urlString += (urlString.contains("?") ? "&" : "?") + "ios=1"
            }

            guard let _ = URL(string: urlString) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"URL video không hợp lệ\"}")
                return
            }

            // Video và nhạc không được phát chồng. close() dừng AVPlayer, xóa
            // playlist/Now Playing và phát thông báo để mini-player biến mất.
            MusicPlaybackManager.shared.close()
            layoutWebViewAndMiniPlayer()
            pushSafeAreaInsets()
            try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback, options: [])
            try? AVAudioSession.sharedInstance().setActive(true)

            DispatchQueue.main.async { [weak self] in
                let playerVc = PlayerViewController(
                    url: urlString,
                    name: name,
                    playlist: playlist,
                    startPos: startPos,
                    subtitleCandidates: subtitleCandidates,
                    baseUrl: base,
                    token: token,
                    rel: rel,
                    pool: pool,
                    size: size,
                    favorite: favorite
                )
                playerVc.onFavorite = { [weak self] item, done in
                    guard let self else { done(false); return }
                    self.videoFavoriteAction(item: item, completion: done)
                }
                playerVc.onDownload = { [weak self] item, done in
                    guard let self else { done(false, "Trình phát video đã đóng."); return }
                    self.prepareVideoFile(item: item, forSharing: false) { url, message in
                        done(url != nil, message)
                    }
                }
                playerVc.onPrepareShare = { [weak self] item, done in
                    guard let self else { done(nil, "Trình phát video đã đóng."); return }
                    self.prepareVideoFile(item: item, forSharing: true, completion: done)
                }
                playerVc.onDelete = { [weak self] item, done in
                    guard let self else { done(false, "Trình phát video đã đóng."); return }
                    self.deleteVideo(item: item, completion: done)
                }
                playerVc.modalPresentationStyle = .fullScreen
                self?.present(playerVc, animated: true, completion: nil)
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "openPdf":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            var url = params["url"] as? String ?? ""
            let viewerUrl = params["viewerUrl"] as? String ?? ""
            let rel = params["rel"] as? String ?? ""
            let pool = params["pool"] as? String ?? ""
            let name = params["name"] as? String ?? "Tài liệu PDF"
            let localPath = params["path"] as? String ?? ""

            if url.isEmpty && !localPath.isEmpty {
                url = URL(fileURLWithPath: localPath).absoluteString
            } else if url.isEmpty && !rel.isEmpty {
                url = "\(LocalProxy.shared.baseUrl)/api/file?path=\(rel.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? rel)&preview=1"
                if !pool.isEmpty { url += "&pool=\(pool)" }
            }
            if !LocalProxy.shared.token.isEmpty && !url.contains("token=") && !url.starts(with: "file:") {
                url += (url.contains("?") ? "&" : "?") + "token=\(LocalProxy.shared.token)"
            }

            DispatchQueue.main.async { [weak self] in
                let pdfVc = PdfViewController(url: viewerUrl.isEmpty ? url : viewerUrl, titleText: name, directWeb: !viewerUrl.isEmpty)
                let nav = UINavigationController(rootViewController: pdfVc)
                nav.modalPresentationStyle = .fullScreen
                self?.present(nav, animated: true)
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "openPhoto":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            var playlist: [[String: Any]] = []
            if let pl = params["playlist"] as? [[String: Any]] {
                playlist = pl
            } else if let plStr = params["playlist"] as? String, let plData = plStr.data(using: .utf8),
                      let parsedPl = (try? JSONSerialization.jsonObject(with: plData)) as? [[String: Any]] {
                playlist = parsedPl
            } else {
                let url = params["url"] as? String ?? ""
                let name = params["name"] as? String ?? "Hình ảnh"
                let localPath = params["localPath"] as? String ?? ""
                playlist = [["name": name, "url": url, "localPath": localPath]]
            }
            let initialIndex = params["initialIndex"] as? Int ?? 0

            DispatchQueue.main.async { [weak self] in
                let imgVc = ImageViewController(playlist: playlist, initialIndex: initialIndex)
                imgVc.onFavorite = { [weak self] item, done in
                    guard let self = self else { done(false); return }
                    self.photoFavoriteAction(item: item, completion: done)
                }
                imgVc.onDownload = { [weak self] item, done in
                    guard let self = self else { done(false, "Trình xem ảnh đã đóng."); return }
                    self.savePhoto(item: item, completion: done)
                }
                imgVc.onDelete = { [weak self] item, done in
                    guard let self = self else { done(false, "Trình xem ảnh đã đóng."); return }
                    self.deletePhoto(item: item, completion: done)
                }
                imgVc.modalPresentationStyle = .fullScreen
                self?.present(imgVc, animated: true)
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "cameraBackupStats":
            let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) ?? [:]
            AppLogger.shared.log(.debug, category: "SYNC", "Đọc thống kê thư viện ảnh")
            getCameraBackupStats(params: params) { jsonStr in
                self.callback(cbId: cbId, ok: true, json: jsonStr)
            }

        case "startCameraBackup":
            let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) ?? [:]
            AppLogger.shared.log(.info, category: "SYNC", "Người dùng bắt đầu đồng bộ thư viện ảnh/video")
            startCameraBackup(params: params) { success, msg in
                let payload: [String: Any] = success ? ["message": msg] : ["err": msg]
                self.callback(cbId: cbId, ok: success, json: self.jsonString(payload))
            }

        case "pauseCameraBackup":
            AppLogger.shared.log(.info, category: "SYNC", "Người dùng tạm dừng đồng bộ thư viện")
            pauseCameraBackup()
            callback(cbId: cbId, ok: true, json: "{}")

        case "pickFiles":
            self.pendingPickerCbId = cbId
            self.pendingPickerIsFolder = false
            let pickerSource = ((args.first as? String) ?? "files").lowercased()
            DispatchQueue.main.async { [weak self] in
                guard let self = self else { return }
                switch pickerSource {
                case "photos":
                    var config = PHPickerConfiguration()
                    config.selectionLimit = 0
                    config.filter = .any(of: [.images, .videos])
                    let picker = PHPickerViewController(configuration: config)
                    picker.delegate = self
                    self.present(picker, animated: true)
                case "camera", "video":
                    guard UIImagePickerController.isSourceTypeAvailable(.camera) else {
                        self.callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
                        self.pendingPickerCbId = nil
                        return
                    }
                    let picker = UIImagePickerController()
                    picker.sourceType = .camera
                    picker.delegate = self
                    if pickerSource == "video" {
                        picker.mediaTypes = [UTType.movie.identifier]
                        picker.cameraCaptureMode = .video
                        picker.videoQuality = .typeHigh
                    } else {
                        picker.mediaTypes = [UTType.image.identifier]
                        picker.cameraCaptureMode = .photo
                    }
                    self.present(picker, animated: true)
                default:
                    let docPicker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType.item], asCopy: true)
                    docPicker.delegate = self
                    docPicker.allowsMultipleSelection = true
                    self.present(docPicker, animated: true)
                }
            }

        case "takeIncomingShares":
            let groupId = "group.com.cw.datacenter.ios"
            guard let groupRoot = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: groupId) else {
                callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
                return
            }
            let inbox = groupRoot.appendingPathComponent("IncomingShares", isDirectory: true)
            let importDir = FileManager.default.temporaryDirectory.appendingPathComponent("IncomingShares", isDirectory: true)
            try? FileManager.default.createDirectory(at: importDir, withIntermediateDirectories: true)
            let urls = (try? FileManager.default.contentsOfDirectory(at: inbox, includingPropertiesForKeys: [.fileSizeKey, .isRegularFileKey], options: [.skipsHiddenFiles])) ?? []
            var files: [[String: Any]] = []
            for source in urls {
                let values = try? source.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey])
                guard values?.isRegularFile == true else { continue }
                let storedName = source.lastPathComponent
                let displayName: String
                if storedName.count > 37, storedName[storedName.index(storedName.startIndex, offsetBy: 36)] == "_" {
                    displayName = String(storedName.dropFirst(37))
                } else {
                    displayName = storedName
                }
                let target = importDir.appendingPathComponent(UUID().uuidString + "_" + displayName)
                do {
                    try FileManager.default.moveItem(at: source, to: target)
                    files.append([
                        "uri": target.absoluteString,
                        "name": displayName,
                        "size": values?.fileSize ?? 0,
                        "mime": UTType(filenameExtension: (displayName as NSString).pathExtension)?.preferredMIMEType ?? "application/octet-stream"
                    ])
                } catch {
                    AppLogger.shared.log(.warning, category: "SHARE", "Không nhập được \(source.lastPathComponent): \(error.localizedDescription)")
                }
            }
            callback(cbId: cbId, ok: true, json: jsonString(["files": files]))

        case "upload":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            let baseUrl = (params["baseUrl"] as? String ?? LocalProxy.shared.baseUrl).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            let token = params["token"] as? String ?? LocalProxy.shared.token
            let pool = params["pool"] as? String ?? ""
            let relPath = params["path"] as? String ?? ""
            let _ = params["name"] as? String ?? "file"
            let uriString = params["uri"] as? String ?? (params["file"] as? String ?? "")
            let defaultKey = relPath.contains(":") ? relPath : "up:\(relPath)"
            let transferKey = params["key"] as? String ?? defaultKey
            let uploadId = "ul-\(abs(relPath.hashValue))-\(Int(Date().timeIntervalSince1970))"

            var fileUrl: URL? = nil
            if uriString.starts(with: "file://"), let u = URL(string: uriString) {
                fileUrl = u
            } else if FileManager.default.fileExists(atPath: uriString) {
                fileUrl = URL(fileURLWithPath: uriString)
            } else if let u = URL(string: uriString), FileManager.default.fileExists(atPath: u.path) {
                fileUrl = u
            }

            guard let finalUrl = fileUrl else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Không tìm thấy tệp nguồn\"}")
                return
            }

            self.callback(cbId: cbId, ok: true, json: "{\"id\":\"\(uploadId)\",\"done\":false}")
            self.emitEvent(["type": "transfer", "id": uploadId, "key": transferKey, "status": "queued", "done": 0, "total": 0])

            manualTransferQueue.async { [weak self] in
                self?.runResumableUpload(
                    fileUrl: finalUrl,
                    baseUrl: baseUrl,
                    token: token,
                    pool: pool,
                    relPath: relPath,
                    uploadId: uploadId,
                    transferKey: transferKey
                )
            }

        case "download", "localFsDownload":
            guard let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"Missing params\"}")
                return
            }
            var urlString = params["url"] as? String ?? ""
            let name = params["name"] as? String ?? "file"
            let rel = params["rel"] as? String ?? name
            let pool = params["pool"] as? String ?? ""
            let localSrcPath = params["p"] as? String ?? ""
            let downloadId = "dl-\(abs(name.hashValue))-\(Int(Date().timeIntervalSince1970))"

            if !localSrcPath.isEmpty && FileManager.default.fileExists(atPath: localSrcPath) {
                let destDir = self.localDocumentsDirectory
                let destFile = destDir.appendingPathComponent(name)
                let transferKey = "dl:\(rel):\(pool)"
                self.callback(cbId: cbId, ok: true, json: "{\"id\":\"\(downloadId)\",\"done\":false}")
                self.emitEvent(["type": "transfer", "id": downloadId, "key": transferKey, "status": "queued", "done": 0, "total": 0])
                manualTransferQueue.async { [weak self] in
                    guard let self = self else { return }
                    do {
                        try? FileManager.default.removeItem(at: destFile)
                        try FileManager.default.copyItem(atPath: localSrcPath, toPath: destFile.path)
                        let total = (try? destFile.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
                        self.emitEvent([
                            "type": "transfer", "id": downloadId, "key": transferKey,
                            "status": "done", "done": total, "total": total, "path": destFile.path
                        ])
                    } catch {
                        self.emitTransferError(id: downloadId, key: transferKey, message: error.localizedDescription)
                    }
                }
                return
            }

            let base = LocalProxy.shared.baseUrl
            let token = LocalProxy.shared.token
            if urlString.isEmpty && !rel.isEmpty {
                urlString = "\(base)/api/file?path=\(rel.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? rel)&download=1"
                if !pool.isEmpty { urlString += "&pool=\(pool)" }
            }

            guard let url = URL(string: urlString) else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"URL download không hợp lệ\"}")
                return
            }

            self.callback(cbId: cbId, ok: true, json: "{\"id\":\"\(downloadId)\"}")

            let destDir = self.localDocumentsDirectory
            let destFile = destDir.appendingPathComponent(name)
            let transferKey = "dl:\(rel):\(pool)"
            self.emitEvent(["type": "transfer", "id": downloadId, "key": transferKey, "status": "queued", "done": 0, "total": 0])
            manualTransferQueue.async { [weak self] in
                self?.runResumableDownload(
                    sourceUrl: url,
                    token: token,
                    destination: destFile,
                    downloadId: downloadId,
                    transferKey: transferKey
                )
            }

        case "openFile", "localFsOpen":
            let params = (args.first as? [String: Any]) ?? parseJsonObject(args.first) ?? [:]
            let rawPath = ((params["path"] as? String) ?? (params["p"] as? String) ?? "")
                .trimmingCharacters(in: .whitespacesAndNewlines)
            guard !rawPath.isEmpty else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"File không hỗ trợ\"}")
                return
            }
            let fileURL: URL
            if rawPath.hasPrefix("file://"), let parsed = URL(string: rawPath) {
                fileURL = parsed
            } else {
                fileURL = URL(fileURLWithPath: rawPath)
            }
            var isDirectory: ObjCBool = false
            guard FileManager.default.fileExists(atPath: fileURL.path, isDirectory: &isDirectory), !isDirectory.boolValue else {
                callback(cbId: cbId, ok: false, json: "{\"err\":\"File không hỗ trợ\"}")
                return
            }
            let controller = UIDocumentInteractionController(url: fileURL)
            controller.delegate = self
            documentInteractionController = controller
            let anchor = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
            if controller.presentOpenInMenu(from: anchor, in: view, animated: true) {
                callback(cbId: cbId, ok: true, json: "{\"ok\":true}")
            } else {
                documentInteractionController = nil
                callback(cbId: cbId, ok: false, json: "{\"err\":\"File không hỗ trợ\"}")
            }

        case "copyClipboard":
            let text = args.first as? String ?? ""
            UIPasteboard.general.string = text
            callback(cbId: cbId, ok: true, json: "{}")

        case "getVideoProgress":
            let raw = args.first as? String ?? ""
            let spec = (try? JSONSerialization.jsonObject(with: Data(raw.utf8))) as? [String: Any]
            let key = (spec?["name"] as? String).flatMap { $0.isEmpty ? nil : $0 } ?? raw
            let pos = UserDefaults.standard.integer(forKey: "vpos_" + key)
            callback(cbId: cbId, ok: true, json: "{\"pos\":\(pos)}")

        case "clearVideoProgress":
            let raw = args.first as? String ?? ""
            let spec = (try? JSONSerialization.jsonObject(with: Data(raw.utf8))) as? [String: Any]
            let key = (spec?["name"] as? String).flatMap { $0.isEmpty ? nil : $0 } ?? raw
            UserDefaults.standard.removeObject(forKey: "vpos_" + key)
            callback(cbId: cbId, ok: true, json: "{}")

        case "clearCache":
            URLCache.shared.removeAllCachedResponses()
            LocalProxy.shared.clearThumbnailCache()
            let cacheTypes: Set<String> = [WKWebsiteDataTypeDiskCache, WKWebsiteDataTypeMemoryCache]
            WKWebsiteDataStore.default().removeData(ofTypes: cacheTypes, modifiedSince: .distantPast) { [weak self] in
                self?.callback(cbId: cbId, ok: true, json: "{}")
            }

        case "exitApp":
            UIControl().sendAction(#selector(NSXPCConnection.suspend), to: UIApplication.shared, for: nil)
            callback(cbId: cbId, ok: true, json: "{}")

        default:
            callback(cbId: cbId, ok: true, json: "{}")
        }
    }

    func documentInteractionControllerViewControllerForPreview(_ controller: UIDocumentInteractionController) -> UIViewController {
        return self
    }

    // MARK: - Resumable large-file transfers
    // Các hàm này dùng chung cho mọi loại tệp. Dữ liệu luôn được truyền theo
    // từng đoạn và offset được xác nhận với Host, nên tệp nhiều GB không bị nạp
    // toàn bộ vào RAM và có thể tiếp tục sau lỗi mạng ngắn hoặc sau khi bấm thử lại.
    private let largeTransferAttempts = 12
    private let uploadChunkBytes = 2 * 1024 * 1024
    private let downloadChunkBytes: Int64 = 32 * 1024 * 1024

    private func performBlockingRequest(_ request: URLRequest) -> CameraHTTPResult {
        let gate = DispatchSemaphore(value: 0)
        let lock = NSLock()
        var result = CameraHTTPResult(code: 0, data: Data(), error: "Không nhận được phản hồi")
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            let http = response as? HTTPURLResponse
            let value = CameraHTTPResult(
                code: http?.statusCode ?? 0,
                data: data ?? Data(),
                error: error?.localizedDescription,
                headers: http?.allHeaderFields ?? [:]
            )
            lock.lock()
            result = value
            lock.unlock()
            gate.signal()
        }
        task.resume()
        gate.wait()
        lock.lock()
        defer { lock.unlock() }
        return result
    }

    private func transferRetryDelay(_ attempt: Int) {
        let delay = min(8.0, 0.5 * pow(2.0, Double(max(0, attempt - 1))))
        Thread.sleep(forTimeInterval: delay)
    }

    private func beginTransferBackgroundTask(_ name: String) -> UIBackgroundTaskIdentifier {
        var identifier = UIBackgroundTaskIdentifier.invalid
        DispatchQueue.main.sync {
            identifier = UIApplication.shared.beginBackgroundTask(withName: name, expirationHandler: nil)
        }
        return identifier
    }

    private func endTransferBackgroundTask(_ identifier: UIBackgroundTaskIdentifier) {
        guard identifier != .invalid else { return }
        DispatchQueue.main.async {
            UIApplication.shared.endBackgroundTask(identifier)
        }
    }

    private func runResumableUpload(fileUrl: URL, baseUrl: String, token: String, pool: String, relPath: String, uploadId: String, transferKey: String) {
        let backgroundId = beginTransferBackgroundTask("CWLargeUpload")
        defer { endTransferBackgroundTask(backgroundId) }

        do {
            let attributes = try FileManager.default.attributesOfItem(atPath: fileUrl.path)
            guard let sizeNumber = attributes[.size] as? NSNumber else {
                throw NSError(domain: "CWUpload", code: 1, userInfo: [NSLocalizedDescriptionKey: "Không đọc được kích thước tệp"])
            }
            let totalSize = sizeNumber.int64Value
            let fileHandle = try FileHandle(forReadingFrom: fileUrl)
            defer { try? fileHandle.close() }

            var serverUploadId = ""
            var currentOffset: Int64 = 0
            var sessionRecoveries = 0
            var lastError = "Khởi tạo upload thất bại"
            let startedAt = Date()
            var startedOffset: Int64 = 0
            var lastProgressAt = Date.distantPast

            func initializeSession() -> Bool {
                guard let url = URL(string: "\(baseUrl)/api/upload/init") else {
                    lastError = "URL khởi tạo upload không hợp lệ"
                    return false
                }
                for attempt in 1...largeTransferAttempts {
                    var request = URLRequest(url: url, timeoutInterval: 45)
                    request.httpMethod = "POST"
                    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                    if !token.isEmpty { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
                    request.httpBody = try? JSONSerialization.data(withJSONObject: ["path": relPath, "pool": pool, "size": totalSize])
                    let response = performBlockingRequest(request)
                    if response.code == 200,
                       let object = (try? JSONSerialization.jsonObject(with: response.data)) as? [String: Any],
                       let newId = object["uploadId"] as? String,
                       !newId.isEmpty {
                        let remoteOffset = int64Value(object["offset"])
                        guard remoteOffset >= 0 && remoteOffset <= totalSize else {
                            lastError = "Host trả offset upload không hợp lệ: \(remoteOffset)"
                            return false
                        }
                        serverUploadId = newId
                        currentOffset = remoteOffset
                        startedOffset = currentOffset
                        return true
                    }
                    lastError = cameraErrorMessage(response, fallback: "Khởi tạo upload thất bại")
                    if [400, 401, 403].contains(response.code) { return false }
                    if attempt < largeTransferAttempts { transferRetryDelay(attempt) }
                }
                return false
            }

            guard initializeSession() else {
                emitTransferError(id: uploadId, key: transferKey, message: lastError)
                return
            }

            transferLoop: while true {
                while currentOffset < totalSize {
                    try fileHandle.seek(toOffset: UInt64(currentOffset))
                    let requested = min(Int64(uploadChunkBytes), totalSize - currentOffset)
                    let chunk = fileHandle.readData(ofLength: Int(requested))
                    guard !chunk.isEmpty else {
                        lastError = "Không đọc được dữ liệu tại vị trí \(currentOffset)"
                        break transferLoop
                    }

                    let offsetAtRequest = currentOffset
                    var accepted = false
                    var mustRecoverSession = false
                    for attempt in 1...largeTransferAttempts {
                        let encodedId = safeQueryEncode(serverUploadId)
                        guard let url = URL(string: "\(baseUrl)/api/upload/chunk?id=\(encodedId)&offset=\(offsetAtRequest)") else {
                            lastError = "URL gửi dữ liệu không hợp lệ"
                            break
                        }
                        var request = URLRequest(url: url, timeoutInterval: 210)
                        request.httpMethod = "POST"
                        request.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
                        if !token.isEmpty { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
                        request.httpBody = chunk
                        let response = performBlockingRequest(request)

                        if response.code == 200 {
                            var nextOffset = offsetAtRequest + Int64(chunk.count)
                            if let object = (try? JSONSerialization.jsonObject(with: response.data)) as? [String: Any] {
                                let hostOffset = int64Value(object["offset"])
                                if hostOffset > 0 { nextOffset = hostOffset }
                            }
                            if nextOffset > offsetAtRequest && nextOffset <= totalSize {
                                currentOffset = nextOffset
                                accepted = true
                                break
                            }
                            lastError = "Host không xác nhận đúng offset upload"
                        } else if response.code == 409,
                                  let object = (try? JSONSerialization.jsonObject(with: response.data)) as? [String: Any] {
                            let hostOffset = int64Value(object["serverOffset"])
                            if hostOffset >= 0 && hostOffset <= totalSize {
                                currentOffset = hostOffset
                                accepted = true
                                break
                            }
                            lastError = "Host trả offset xung đột không hợp lệ"
                        } else if response.code == 404 || response.code == 410 {
                            lastError = cameraErrorMessage(response, fallback: "Phiên upload không tồn tại")
                            mustRecoverSession = true
                            break
                        } else {
                            lastError = cameraErrorMessage(response, fallback: "Gửi khối dữ liệu thất bại")
                            if [400, 401, 403].contains(response.code) { break }
                        }
                        if attempt < largeTransferAttempts { transferRetryDelay(attempt) }
                    }

                    if mustRecoverSession {
                        sessionRecoveries += 1
                        guard sessionRecoveries <= largeTransferAttempts && initializeSession() else { break transferLoop }
                        continue
                    }
                    guard accepted else { break transferLoop }

                    let now = Date()
                    if now.timeIntervalSince(lastProgressAt) >= 0.25 || currentOffset >= totalSize {
                        lastProgressAt = now
                        let elapsed = max(now.timeIntervalSince(startedAt), 0.001)
                        let speed = Int64(Double(max(0, currentOffset - startedOffset)) / elapsed)
                        emitEvent(["type": "transfer", "id": uploadId, "key": transferKey, "status": "active", "done": currentOffset, "total": totalSize, "speed": speed])
                    }
                }

                guard currentOffset >= totalSize else { break }
                var completed = false
                var recoverAfterComplete = false
                for attempt in 1...largeTransferAttempts {
                    guard let url = URL(string: "\(baseUrl)/api/upload/complete") else {
                        lastError = "URL hoàn tất upload không hợp lệ"
                        break
                    }
                    var request = URLRequest(url: url, timeoutInterval: 45)
                    request.httpMethod = "POST"
                    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                    if !token.isEmpty { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
                    request.httpBody = try? JSONSerialization.data(withJSONObject: ["uploadId": serverUploadId])
                    let response = performBlockingRequest(request)
                    if response.code == 200 || response.code == 201 {
                        completed = true
                        break
                    }
                    if response.code == 409,
                       let object = (try? JSONSerialization.jsonObject(with: response.data)) as? [String: Any] {
                        let hostOffset = int64Value(object["serverOffset"])
                        if hostOffset >= 0 && hostOffset <= totalSize {
                            currentOffset = hostOffset
                            recoverAfterComplete = true
                            break
                        }
                    }
                    if response.code == 404 || response.code == 410 {
                        recoverAfterComplete = true
                        break
                    }
                    lastError = cameraErrorMessage(response, fallback: "Hoàn tất upload thất bại")
                    if [400, 401, 403].contains(response.code) { break }
                    if attempt < largeTransferAttempts { transferRetryDelay(attempt) }
                }

                if completed {
                    emitEvent(["type": "transfer", "id": uploadId, "key": transferKey, "status": "done", "done": totalSize, "total": totalSize])
                    return
                }
                if recoverAfterComplete {
                    sessionRecoveries += 1
                    guard sessionRecoveries <= largeTransferAttempts && initializeSession() else { break }
                    continue
                }
                break
            }
            emitTransferError(id: uploadId, key: transferKey, message: lastError)
        } catch {
            emitTransferError(id: uploadId, key: transferKey, message: error.localizedDescription)
        }
    }

    private func runResumableDownload(sourceUrl: URL, token: String, destination: URL, downloadId: String,
                                      transferKey: String, emitCompletion: Bool = true,
                                      completion: ((Bool, String?) -> Void)? = nil) {
        let backgroundId = beginTransferBackgroundTask("CWLargeDownload")
        defer { endTransferBackgroundTask(backgroundId) }

        let fileManager = FileManager.default
        do {
            let support = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
            let partsDirectory = support.appendingPathComponent("CWTransferParts", isDirectory: true)
            try fileManager.createDirectory(at: partsDirectory, withIntermediateDirectories: true, attributes: nil)
            let stableId = stableTransferIdentifier(sourceUrl.absoluteString + "|" + destination.lastPathComponent)
            let partialUrl = partsDirectory.appendingPathComponent(stableId + ".cwpart")
            let metadataUrl = partsDirectory.appendingPathComponent(stableId + ".cwpart.json")

            if let metadata = try? Data(contentsOf: metadataUrl),
               let object = (try? JSONSerialization.jsonObject(with: metadata)) as? [String: Any],
               (object["url"] as? String) != sourceUrl.absoluteString {
                try? fileManager.removeItem(at: partialUrl)
                try? fileManager.removeItem(at: metadataUrl)
            }
            if !fileManager.fileExists(atPath: partialUrl.path) {
                fileManager.createFile(atPath: partialUrl.path, contents: nil, attributes: nil)
            }
            let metadata = try JSONSerialization.data(withJSONObject: ["url": sourceUrl.absoluteString, "name": destination.lastPathComponent])
            try metadata.write(to: metadataUrl, options: .atomic)

            var currentOffset = Int64((try? partialUrl.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0)
            var expectedTotal: Int64 = 0
            var totalKnown = false
            var lastError = "Lỗi tải xuống"
            let startedAt = Date()
            let startedOffset = currentOffset

            downloadLoop: while !totalKnown || currentOffset < expectedTotal {
                var chunkAccepted = false
                for attempt in 1...largeTransferAttempts {
                    let end = currentOffset + downloadChunkBytes - 1
                    var request = URLRequest(url: sourceUrl, timeoutInterval: 210)
                    request.setValue("bytes=\(currentOffset)-\(end)", forHTTPHeaderField: "Range")
                    if !token.isEmpty { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
                    let response = performBlockingRequest(request)

                    if response.code == 416 {
                        let total = parseUnsatisfiedRangeTotal(headerValue("Content-Range", in: response.headers))
                        if total >= 0 && total == currentOffset {
                            expectedTotal = total
                            totalKnown = true
                            chunkAccepted = true
                            break
                        }
                        lastError = "Host từ chối offset tải tiếp \(currentOffset)"
                    } else if response.code == 206 || response.code == 200 {
                        if response.code == 200 && currentOffset > 0 {
                            try truncateFile(at: partialUrl)
                            currentOffset = 0
                            expectedTotal = 0
                            totalKnown = false
                            chunkAccepted = true
                            break
                        }
                        if response.code == 206 {
                            let contentRange = headerValue("Content-Range", in: response.headers)
                            let start = parseRangeStart(contentRange)
                            guard start == currentOffset else {
                                lastError = "Host trả sai offset tải tiếp: cần \(currentOffset), nhận \(start)"
                                if attempt < largeTransferAttempts { transferRetryDelay(attempt) }
                                continue
                            }
                            let total = parseRangeTotal(contentRange)
                            if total >= 0 {
                                expectedTotal = total
                                totalKnown = true
                            }
                        }
                        if response.data.isEmpty {
                            if totalKnown && currentOffset >= expectedTotal {
                                chunkAccepted = true
                                break
                            }
                            lastError = "Host trả về khối dữ liệu rỗng"
                        } else {
                            let handle = try FileHandle(forWritingTo: partialUrl)
                            defer { try? handle.close() }
                            try handle.seek(toOffset: UInt64(currentOffset))
                            try handle.write(contentsOf: response.data)
                            try handle.synchronize()
                            currentOffset += Int64(response.data.count)
                            if response.code == 200 && !totalKnown {
                                expectedTotal = currentOffset
                                totalKnown = true
                            }
                            let elapsed = max(Date().timeIntervalSince(startedAt), 0.001)
                            let speed = Int64(Double(max(0, currentOffset - startedOffset)) / elapsed)
                            emitEvent(["type": "transfer", "id": downloadId, "key": transferKey, "status": "active", "done": currentOffset, "total": max(expectedTotal, currentOffset), "speed": speed])
                            chunkAccepted = true
                            break
                        }
                    } else {
                        lastError = cameraErrorMessage(response, fallback: "Lỗi tải xuống")
                        if [400, 401, 403, 404].contains(response.code) { break }
                    }
                    if attempt < largeTransferAttempts { transferRetryDelay(attempt) }
                }
                guard chunkAccepted else { break downloadLoop }
                if totalKnown && currentOffset >= expectedTotal { break }
            }

            guard totalKnown, currentOffset == expectedTotal else {
                let message = "\(lastError). Đã giữ \(currentOffset) byte để thử lại."
                emitTransferError(id: downloadId, key: transferKey, message: message)
                completion?(false, message)
                return
            }
            try? fileManager.removeItem(at: destination)
            try fileManager.moveItem(at: partialUrl, to: destination)
            try? fileManager.removeItem(at: metadataUrl)
            if emitCompletion {
                emitEvent(["type": "transfer", "id": downloadId, "key": transferKey, "status": "done", "done": expectedTotal, "total": expectedTotal, "path": destination.path])
            }
            completion?(true, nil)
        } catch {
            emitTransferError(id: downloadId, key: transferKey, message: error.localizedDescription)
            completion?(false, error.localizedDescription)
        }
    }

    private func emitTransferError(id: String, key: String, message: String) {
        emitEvent(["type": "transfer", "id": id, "key": key, "status": "error", "err": message])
    }

    private func truncateFile(at url: URL) throws {
        let handle = try FileHandle(forWritingTo: url)
        defer { try? handle.close() }
        try handle.truncate(atOffset: 0)
        try handle.synchronize()
    }

    private func stableTransferIdentifier(_ value: String) -> String {
        var hash: UInt64 = 1469598103934665603
        for byte in value.utf8 {
            hash ^= UInt64(byte)
            hash = hash &* 1099511628211
        }
        return String(hash, radix: 16)
    }

    private func headerValue(_ name: String, in headers: [AnyHashable: Any]) -> String {
        for (key, value) in headers where String(describing: key).caseInsensitiveCompare(name) == .orderedSame {
            return String(describing: value)
        }
        return ""
    }

    private func parseRangeStart(_ value: String) -> Int64 {
        guard let rangePart = value.split(separator: " ").last?.split(separator: "/").first,
              let startPart = rangePart.split(separator: "-").first,
              let start = Int64(startPart) else { return -1 }
        return start
    }

    private func parseRangeTotal(_ value: String) -> Int64 {
        guard let totalPart = value.split(separator: "/").last,
              totalPart != "*",
              let total = Int64(totalPart) else { return -1 }
        return total
    }

    private func parseUnsatisfiedRangeTotal(_ value: String) -> Int64 {
        guard value.lowercased().hasPrefix("bytes */") else { return -1 }
        return parseRangeTotal(value)
    }

    // MARK: - Local Documents Path
    private var localDocumentsDirectory: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let dir = docs.appendingPathComponent("CW-Datacenter")
        let fm = FileManager.default
        if !fm.fileExists(atPath: dir.path) {
            try? fm.createDirectory(at: dir, withIntermediateDirectories: true, attributes: nil)
        }
        for sub in ["Tải về", "Hình ảnh", "Tài liệu"] {
            let subDir = dir.appendingPathComponent(sub)
            if !fm.fileExists(atPath: subDir.path) {
                try? fm.createDirectory(at: subDir, withIntermediateDirectories: true, attributes: nil)
            }
        }
        return dir
    }

    private func emitEvent(_ obj: [String: Any]) {
        guard let data = try? JSONSerialization.data(withJSONObject: obj),
              let jsonStr = String(data: data, encoding: .utf8) else { return }
        DispatchQueue.main.async { [weak self] in
            if let jsData = try? JSONSerialization.data(withJSONObject: [jsonStr]),
               let jsStr = String(data: jsData, encoding: .utf8) {
                let inner = String(jsStr.dropFirst().dropLast())
                let js = "window.DC && DC._evt && DC._evt(\(inner));"
                self?.webView?.evaluateJavaScript(js, completionHandler: nil)
            }
        }
    }

    // MARK: - UIDocumentPickerDelegate
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let cbId = pendingPickerCbId else { return }
        pendingPickerCbId = nil
        let selectingFolder = pendingPickerIsFolder
        pendingPickerIsFolder = false
        var files: [[String: Any]] = []
        for url in urls {
            let start = url.startAccessingSecurityScopedResource()
            defer { if start { url.stopAccessingSecurityScopedResource() } }
            let tempContainer = FileManager.default.temporaryDirectory
                .appendingPathComponent("cw-upload-\(UUID().uuidString)", isDirectory: true)
            try? FileManager.default.createDirectory(at: tempContainer, withIntermediateDirectories: true)
            let tmpDst = tempContainer.appendingPathComponent(url.lastPathComponent, isDirectory: selectingFolder)
            do {
                try FileManager.default.copyItem(at: url, to: tmpDst)
                if selectingFolder {
                    let keys: [URLResourceKey] = [.isRegularFileKey, .fileSizeKey]
                    let enumerator = FileManager.default.enumerator(at: tmpDst, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles])
                    while let fileURL = enumerator?.nextObject() as? URL {
                        let values = try? fileURL.resourceValues(forKeys: Set(keys))
                        guard values?.isRegularFile == true else { continue }
                        let basePath = tmpDst.standardizedFileURL.path
                        let fullPath = fileURL.standardizedFileURL.path
                        guard fullPath.hasPrefix(basePath) else { continue }
                        var child = String(fullPath.dropFirst(basePath.count))
                        child = child.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
                        let relative = url.lastPathComponent + (child.isEmpty ? "" : "/" + child)
                        files.append([
                            "name": fileURL.lastPathComponent,
                            "rel": relative,
                            "uri": fileURL.path,
                            "size": values?.fileSize ?? 0
                        ])
                    }
                } else {
                    let size = (try? tmpDst.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
                    files.append([
                        "name": url.lastPathComponent,
                        "uri": tmpDst.path,
                        "size": size
                    ])
                }
            } catch {
                AppLogger.shared.log(.error, category: "UPLOAD", "Không sao chép được mục đã chọn: \(error.localizedDescription)")
            }
        }
        let payload: [String: Any] = ["files": files]
        if let d = try? JSONSerialization.data(withJSONObject: payload), let j = String(data: d, encoding: .utf8) {
            callback(cbId: cbId, ok: true, json: j)
        } else {
            callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
        }
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        guard let cbId = pendingPickerCbId else { return }
        pendingPickerCbId = nil
        pendingPickerIsFolder = false
        callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
    }

    // MARK: - PHPickerViewControllerDelegate
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        guard let cbId = pendingPickerCbId else { return }
        pendingPickerCbId = nil
        guard !results.isEmpty else {
            callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
            return
        }

        let group = DispatchGroup()
        var files: [[String: Any]] = []
        let lock = NSLock()

        for result in results {
            group.enter()
            result.itemProvider.loadFileRepresentation(forTypeIdentifier: UTType.item.identifier) { url, error in
                defer { group.leave() }
                guard let srcUrl = url else { return }
                let filename = srcUrl.lastPathComponent
                let dst = FileManager.default.temporaryDirectory.appendingPathComponent(filename)
                try? FileManager.default.removeItem(at: dst)
                try? FileManager.default.copyItem(at: srcUrl, to: dst)
                let size = (try? dst.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
                lock.lock()
                files.append([
                    "name": filename,
                    "uri": dst.path,
                    "size": size
                ])
                lock.unlock()
            }
        }

        group.notify(queue: .main) { [weak self] in
            let payload: [String: Any] = ["files": files]
            if let d = try? JSONSerialization.data(withJSONObject: payload), let j = String(data: d, encoding: .utf8) {
                self?.callback(cbId: cbId, ok: true, json: j)
            } else {
                self?.callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
            }
        }
    }

    // MARK: - UIImagePickerControllerDelegate
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)
        guard let cbId = pendingPickerCbId else { return }
        pendingPickerCbId = nil

        if let img = info[.originalImage] as? UIImage, let data = img.jpegData(compressionQuality: 0.9) {
            let filename = "IMG_\(Int(Date().timeIntervalSince1970)).jpg"
            let dst = FileManager.default.temporaryDirectory.appendingPathComponent(filename)
            try? data.write(to: dst)
            let files: [[String: Any]] = [["name": filename, "uri": dst.path, "size": data.count]]
            let payload: [String: Any] = ["files": files]
            if let d = try? JSONSerialization.data(withJSONObject: payload), let j = String(data: d, encoding: .utf8) {
                callback(cbId: cbId, ok: true, json: j)
                return
            }
        }
        if let mediaURL = info[.mediaURL] as? URL {
            let ext = mediaURL.pathExtension.isEmpty ? "mov" : mediaURL.pathExtension.lowercased()
            let filename = "VID_\(Int(Date().timeIntervalSince1970)).\(ext)"
            let dst = FileManager.default.temporaryDirectory.appendingPathComponent(filename)
            try? FileManager.default.removeItem(at: dst)
            do {
                try FileManager.default.copyItem(at: mediaURL, to: dst)
                let size = (try? dst.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
                let payload: [String: Any] = ["files": [["name": filename, "uri": dst.path, "size": size]]]
                callback(cbId: cbId, ok: true, json: jsonString(payload))
                return
            } catch {
                AppLogger.shared.log(.error, category: "UPLOAD", "Không sao chép được video vừa quay: \(error.localizedDescription)")
            }
        }
        callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
        guard let cbId = pendingPickerCbId else { return }
        pendingPickerCbId = nil
        callback(cbId: cbId, ok: true, json: "{\"files\":[]}")
    }

    private func parseJsonObject(_ obj: Any?) -> [String: Any]? {
        guard let str = obj as? String, let data = str.data(using: .utf8) else { return nil }
        return (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
    }

    private func jsonString(_ object: Any) -> String {
        guard JSONSerialization.isValidJSONObject(object),
              let data = try? JSONSerialization.data(withJSONObject: object),
              let value = String(data: data, encoding: .utf8) else {
            return "{}"
        }
        return value
    }

    private func callback(cbId: String, ok: Bool, json: String) {
        guard !cbId.isEmpty else { return }
        DispatchQueue.main.async { [weak self] in
            if let jsData = try? JSONSerialization.data(withJSONObject: [json]),
               let jsStr = String(data: jsData, encoding: .utf8) {
                let inner = String(jsStr.dropFirst().dropLast())
                let js = """
                (function() {
                    if (window.DC && typeof DC._cb === 'function') {
                        DC._cb('\(cbId)', \(ok), \(inner));
                    } else if (window.DC && typeof DC._cbObj === 'function') {
                        DC._cbObj({ id: '\(cbId)', ok: \(ok), data: \(json) });
                    }
                })();
                """
                self?.webView?.evaluateJavaScript(js, completionHandler: nil)
            }
        }
    }

    // MARK: - LAN Discovery
    private func performLanDiscovery(completion: @escaping ([[String: Any]]) -> Void) {
        var foundHosts: [[String: Any]] = []
        let lock = NSLock()
        
        var prefixes: Set<String> = []
        var broadcastAddrs: Set<String> = ["255.255.255.255"]
        
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        if getifaddrs(&ifaddr) == 0 {
            var ptr = ifaddr
            while ptr != nil {
                let flags = Int32(ptr!.pointee.ifa_flags)
                let addr = ptr!.pointee.ifa_addr.pointee
                if (flags & Int32(IFF_UP)) != 0 && (flags & Int32(IFF_LOOPBACK)) == 0 {
                    if addr.sa_family == UInt8(AF_INET) {
                        var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                        if getnameinfo(ptr!.pointee.ifa_addr, socklen_t(addr.sa_len), &hostname, socklen_t(hostname.count), nil, 0, NI_NUMERICHOST) == 0 {
                            let ip = String(cString: hostname)
                            if !ip.starts(with: "127.") && !ip.starts(with: "169.254.") {
                                let parts = ip.split(separator: ".")
                                if parts.count == 4 {
                                    let pref = "\(parts[0]).\(parts[1]).\(parts[2])."
                                    prefixes.insert(pref)
                                    broadcastAddrs.insert("\(pref)255")
                                }
                            }
                        }
                    }
                }
                ptr = ptr!.pointee.ifa_next
            }
            freeifaddrs(ifaddr)
        }
        
        if prefixes.isEmpty {
            prefixes.insert("192.168.1.")
            prefixes.insert("192.168.0.")
            prefixes.insert("192.168.2.")
            prefixes.insert("192.168.31.")
            prefixes.insert("172.20.10.")
            prefixes.insert("10.0.0.")
        }
        
        let group = DispatchGroup()
        
        // 1. UDP Broadcast Discovery to Port 46631
        group.enter()
        DispatchQueue.global(qos: .userInitiated).async {
            let sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)
            if sock >= 0 {
                var broadcastEnable: Int32 = 1
                setsockopt(sock, SOL_SOCKET, SO_BROADCAST, &broadcastEnable, socklen_t(MemoryLayout<Int32>.size))
                var tv = timeval(tv_sec: 0, tv_usec: 300000)
                setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))
                
                let msg = "CW-DISCOVER"
                if let msgData = msg.data(using: .utf8) {
                    msgData.withUnsafeBytes { rawBuffer in
                        for bAddr in broadcastAddrs {
                            var addr = sockaddr_in()
                            addr.sin_family = sa_family_t(AF_INET)
                            addr.sin_port = in_port_t(46631).bigEndian
                            addr.sin_addr.s_addr = inet_addr(bAddr)
                            
                            withUnsafePointer(to: &addr) { addrPtr in
                                addrPtr.withMemoryRebound(to: sockaddr.self, capacity: 1) { saPtr in
                                    _ = sendto(sock, rawBuffer.baseAddress, rawBuffer.count, 0, saPtr, socklen_t(MemoryLayout<sockaddr_in>.size))
                                }
                            }
                        }
                    }
                }
                
                var recvBuf = [UInt8](repeating: 0, count: 2048)
                var srcAddr = sockaddr_in()
                var srcLen = socklen_t(MemoryLayout<sockaddr_in>.size)
                
                let deadline = Date().addingTimeInterval(1.8)
                while Date() < deadline {
                    let bytesRead = withUnsafeMutablePointer(to: &srcAddr) { srcPtr in
                        srcPtr.withMemoryRebound(to: sockaddr.self, capacity: 1) { saPtr in
                            recvfrom(sock, &recvBuf, recvBuf.count, 0, saPtr, &srcLen)
                        }
                    }
                    if bytesRead > 0 {
                        let fromIp = String(cString: inet_ntoa(srcAddr.sin_addr))
                        if let data = String(bytes: recvBuf[0..<bytesRead], encoding: .utf8)?.data(using: .utf8),
                           let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] {
                            let hostName = (obj["name"] as? String) ?? (obj["host"] as? String) ?? fromIp
                            let port = (obj["port"] as? Int) ?? 8080
                            let hostObj: [String: Any] = [
                                "ip": fromIp,
                                "port": port,
                                "host": hostName,
                                "name": hostName,
                                "via": "lan"
                            ]
                            lock.lock()
                            if !foundHosts.contains(where: { ($0["ip"] as? String) == fromIp && ($0["port"] as? Int) == port }) {
                                foundHosts.append(hostObj)
                            }
                            lock.unlock()
                        }
                    }
                }
                close(sock)
            }
            group.leave()
        }
        
        // 2. Parallel HTTP Subnet Scanner
        let sessionConfig = URLSessionConfiguration.ephemeral
        sessionConfig.timeoutIntervalForRequest = 1.8
        sessionConfig.timeoutIntervalForResource = 1.8
        let scanSession = URLSession(configuration: sessionConfig)
        
        for prefix in prefixes {
            for i in 1...254 {
                let targetIp = "\(prefix)\(i)"
                for port in [8080, 8081] {
                    guard let url = URL(string: "http://\(targetIp):\(port)/api/ping") else { continue }
                    group.enter()
                    scanSession.dataTask(with: url) { data, response, error in
                        defer { group.leave() }
                        guard let data = data,
                              let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else { return }
                        
                        let isCwHost = (obj["app"] as? String == "cw-datacenter") ||
                                       (obj["ok"] as? Bool == true && (obj["via"] != nil || obj["host"] != nil || obj["version"] != nil))
                        guard isCwHost else { return }
                        
                        let hostName = (obj["name"] as? String) ?? (obj["host"] as? String) ?? targetIp
                        let p = (obj["port"] as? Int) ?? port
                        let hostObj: [String: Any] = [
                            "ip": targetIp,
                            "port": p,
                            "host": hostName,
                            "name": hostName,
                            "via": "lan"
                        ]
                        lock.lock()
                        if !foundHosts.contains(where: { ($0["ip"] as? String) == targetIp && ($0["port"] as? Int) == p }) {
                            foundHosts.append(hostObj)
                        }
                        lock.unlock()
                    }.resume()
                }
            }
        }
        
        group.notify(queue: .main) {
            completion(foundHosts)
        }
    }

    // MARK: - Camera Backup (Photos & Videos with 200 items/folder chunking & duplicate detection)
    private let cameraStateLock = NSLock()
    private var cameraBackupRunningValue = false
    private var cameraBackupPausedValue = false
    private var isCameraBackupRunning: Bool {
        get { cameraStateLock.lock(); defer { cameraStateLock.unlock() }; return cameraBackupRunningValue }
        set { cameraStateLock.lock(); cameraBackupRunningValue = newValue; cameraStateLock.unlock() }
    }
    private var isCameraBackupPaused: Bool {
        get { cameraStateLock.lock(); defer { cameraStateLock.unlock() }; return cameraBackupPausedValue }
        set { cameraStateLock.lock(); cameraBackupPausedValue = newValue; cameraStateLock.unlock() }
    }

    private func claimCameraBackupRun() -> Bool {
        cameraStateLock.lock()
        defer { cameraStateLock.unlock() }
        guard !cameraBackupRunningValue else { return false }
        cameraBackupRunningValue = true
        cameraBackupPausedValue = false
        return true
    }

    private func cameraMediaMode(from params: [String: Any]) -> CameraMediaMode {
        if let raw = (params["mediaMode"] as? String)?.lowercased(),
           let mode = CameraMediaMode(rawValue: raw) {
            return mode
        }
        return (params["includeVideos"] as? Bool ?? true) ? .all : .photos
    }

    private func cameraStorageMode(from params: [String: Any]) -> CameraStorageMode {
        guard let raw = (params["storageMode"] as? String)?.lowercased() else { return .all }
        switch raw {
        case "local": return .local
        case "icloud": return .iCloud
        default: return .all
        }
    }

    private func cameraFolderLimit(_ value: Any?, fallback: Int) -> Int {
        let raw: Int
        if let number = value as? NSNumber { raw = number.intValue }
        else if let string = value as? String, let parsed = Int(string) { raw = parsed }
        else { raw = fallback }
        return min(5_000, max(25, raw))
    }

    /// PhotoKit không công khai thuộc tính "iCloud-only". Cách kiểm tra an
    /// toàn cho App Store là yêu cầu vài byte của resource khi tắt network:
    /// nhận được dữ liệu nghĩa là bản gốc đang có trên thiết bị; lỗi trước byte
    /// đầu tiên nghĩa là Photos cần tải resource từ iCloud.
    private func cameraResourceIsLocal(_ resource: PHAssetResource, timeout: TimeInterval = 12) -> Bool {
        let manager = PHAssetResourceManager.default()
        let options = PHAssetResourceRequestOptions()
        options.isNetworkAccessAllowed = false
        let semaphore = DispatchSemaphore(value: 0)
        let gate = OneShotGate()
        let stateLock = NSLock()
        var receivedData = false
        var requestID: PHAssetResourceDataRequestID = 0

        requestID = manager.requestData(for: resource, options: options, dataReceivedHandler: { data in
            guard !data.isEmpty else { return }
            stateLock.lock()
            receivedData = true
            stateLock.unlock()
            if requestID != 0 { manager.cancelDataRequest(requestID) }
            if gate.claim() { semaphore.signal() }
        }, completionHandler: { _ in
            if gate.claim() { semaphore.signal() }
        })

        stateLock.lock()
        let receivedBeforeRequestReturned = receivedData
        stateLock.unlock()
        if receivedBeforeRequestReturned { manager.cancelDataRequest(requestID) }

        if semaphore.wait(timeout: .now() + timeout) == .timedOut {
            manager.cancelDataRequest(requestID)
        }
        stateLock.lock()
        let result = receivedData
        stateLock.unlock()
        return result
    }

    private func filteredCameraAssets(_ fetchResult: PHFetchResult<PHAsset>, storageMode: CameraStorageMode) -> [PHAsset] {
        var allAssets: [PHAsset] = []
        allAssets.reserveCapacity(fetchResult.count)
        for index in 0..<fetchResult.count { allAssets.append(fetchResult.object(at: index)) }
        guard storageMode != .all else { return allAssets }

        let resultLock = NSLock()
        var matches: [(Int, PHAsset)] = []
        let queue = OperationQueue()
        queue.name = "com.cw.datacenter.photos-location-probe"
        queue.qualityOfService = .utility
        queue.maxConcurrentOperationCount = 4
        for (index, asset) in allAssets.enumerated() {
            queue.addOperation { [weak self] in
                guard let self = self, let resource = self.primaryResource(for: asset) else { return }
                let isLocal = self.cameraResourceIsLocal(resource)
                let shouldInclude = storageMode == .local ? isLocal : !isLocal
                if shouldInclude {
                    resultLock.lock()
                    matches.append((index, asset))
                    resultLock.unlock()
                }
            }
        }
        queue.waitUntilAllOperationsAreFinished()
        return matches.sorted { $0.0 < $1.0 }.map { $0.1 }
    }

    private func cameraFetchOptions(for mode: CameraMediaMode) -> PHFetchOptions {
        let options = PHFetchOptions()
        options.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: true)]
        switch mode {
        case .all:
            options.predicate = NSPredicate(
                format: "mediaType == %d OR mediaType == %d",
                PHAssetMediaType.image.rawValue,
                PHAssetMediaType.video.rawValue
            )
        case .photos:
            options.predicate = NSPredicate(format: "mediaType == %d", PHAssetMediaType.image.rawValue)
        case .videos:
            options.predicate = NSPredicate(format: "mediaType == %d", PHAssetMediaType.video.rawValue)
        }
        return options
    }

    private func cameraStableToken(for assetIdentifier: String) -> String {
        // FNV-1a 64-bit: ổn định giữa các lần chạy và không phụ thuộc thứ tự Photos.
        var hash: UInt64 = 14_695_981_039_346_656_037
        for byte in assetIdentifier.utf8 {
            hash ^= UInt64(byte)
            hash = hash &* 1_099_511_628_211
        }
        return String(format: "%016llx", hash)
    }

    private func stableCameraDestination(originalName: String, assetIdentifier: String) -> (part: String, name: String, relativePath: String) {
        let token = cameraStableToken(for: assetIdentifier)
        let nsName = originalName as NSString
        let ext = nsName.pathExtension
        let stem = nsName.deletingPathExtension
        let reserved = token.count + 5 + (ext.isEmpty ? 0 : ext.count + 1)
        let safeStem = String(stem.prefix(max(1, 180 - reserved)))
        let taggedName = ext.isEmpty ? "\(safeStem)__cw_\(token)" : "\(safeStem)__cw_\(token).\(ext)"
        // Đây là đường dẫn băm đã dùng ở 1.6.0. Chỉ giữ lại để nhận diện
        // file đã upload, không dùng nó để xếp file mới nữa vì sẽ tạo tới
        // 256 thư mục Camera_x thưa thớt.
        let bucket = (Int(String(token.prefix(2)), radix: 16) ?? 0) + 1
        let part = "Camera_\(bucket)"
        return (part, taggedName, "\(part)/\(taggedName)".lowercased())
    }

    private func relativeCameraRecordPath(_ record: CameraBackupRecord, deviceFolder: String) -> String? {
        let normalized = record.path
            .replacingOccurrences(of: "\\", with: "/")
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let prefix = deviceFolder.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        if normalized.lowercased().hasPrefix(prefix.lowercased() + "/") {
            return String(normalized.dropFirst(prefix.count + 1)).lowercased()
        }
        return normalized.lowercased()
    }
    private let cameraNetworkTaskLock = NSLock()
    private let cameraRecordLock = NSLock()
    private var activeCameraNetworkTask: URLSessionTask?
    private var cameraBackgroundTask: UIBackgroundTaskIdentifier = .invalid

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        AppLogger.shared.log(.warning, category: "MEMORY", "MainViewController nhận cảnh báo bộ nhớ; cameraRunning=\(isCameraBackupRunning)")
        // Không hủy file đang đọc/upload chỉ vì một memory warning. Việc hủy giữa
        // chừng chính là nguyên nhân log 1.6.5 dừng sau vài chục tệp. Hạ áp lực RAM
        // bằng cache HTTP + thumbnail ngoài màn hình rồi để hàng đợi tuần tự chạy tiếp.
        URLCache.shared.removeAllCachedResponses()
        webView?.evaluateJavaScript("window.CWReleaseMediaCaches && window.CWReleaseMediaCaches()", completionHandler: nil)
        if isCameraBackupRunning {
            notifyCameraProgress(
                current: 0,
                total: 0,
                filename: "[Tối ưu bộ nhớ] Đã giải phóng cache; đồng bộ vẫn tiếp tục.",
                part: "",
                percent: 0
            )
        }
    }

    private func beginCameraBackgroundTask() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self, self.cameraBackgroundTask == .invalid else { return }
            self.cameraBackgroundTask = UIApplication.shared.beginBackgroundTask(withName: "CWCameraBackup") { [weak self] in
                guard let self = self else { return }
                self.pauseCameraBackup()
                self.notifyCameraProgress(current: 0, total: 0, filename: "[Dừng] iOS hết thời gian chạy nền. Mở lại app để tiếp tục.", part: "", percent: 0)
            }
        }
    }

    private func endCameraBackgroundTask() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self, self.cameraBackgroundTask != .invalid else { return }
            UIApplication.shared.endBackgroundTask(self.cameraBackgroundTask)
            self.cameraBackgroundTask = .invalid
        }
    }

    private func getCameraBackupStats(params: [String: Any], completion: @escaping (String) -> Void) {
        PHPhotoLibrary.requestAuthorization(for: .readWrite) { [weak self] status in
            guard let self = self else {
                completion("{}")
                return
            }
            guard status == .authorized || status == .limited else {
                let res: [String: Any] = ["err": "Chưa được cấp quyền truy cập Thư viện ảnh", "total": 0, "backed": 0, "pending": 0]
                if let data = try? JSONSerialization.data(withJSONObject: res), let str = String(data: data, encoding: .utf8) {
                    completion(str)
                } else {
                    completion("{}")
                }
                return
            }

            let mediaMode = self.cameraMediaMode(from: params)
            let storageMode = self.cameraStorageMode(from: params)
            let baseUrl = (params["baseUrl"] as? String ?? "").trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            let token = params["token"] as? String ?? ""
            let pool = (params["pool"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            let customDeviceName = params["customDeviceName"] as? String ?? ""
            let deviceFolder = self.cameraDeviceFolder(customName: customDeviceName)

            let fetchOptions = self.cameraFetchOptions(for: mediaMode)
            let fetchedAssets = PHAsset.fetchAssets(with: fetchOptions)
            let assets = self.filteredCameraAssets(fetchedAssets, storageMode: storageMode)

            let stateKey = self.cameraBackupStateKey(baseUrl: baseUrl, pool: pool, deviceFolder: deviceFolder)
            let backedUpList = UserDefaults.standard.stringArray(forKey: stateKey) ?? []
            let locallyBackedUpSet = Set(backedUpList)
            let locallySavedRecords = self.loadCameraBackupRecords(stateKey: stateKey)

            var totalPhotos = 0
            var totalVideos = 0
            for i in 0..<assets.count {
                let asset = assets[i]
                if asset.mediaType == .image { totalPhotos += 1 }
                else if asset.mediaType == .video { totalVideos += 1 }
            }

            func finishStats(backedUpSet: Set<String>, records inputRecords: [String: CameraBackupRecord], hostVerified: Bool, error: String? = nil) {
                var records = inputRecords
                var backedCount = 0
                for i in 0..<assets.count {
                    let asset = assets[i]
                    guard backedUpSet.contains(asset.localIdentifier) else { continue }
                    backedCount += 1
                    // Không tự đoán đường dẫn cho state cũ thiếu record. Đường dẫn
                    // chỉ được ghi sau khi Host xác nhận file hoặc upload complete;
                    // nếu đoán theo hash 1.6.0 sẽ làm sống lại Camera_27, Camera_191…
                }
                self.saveCameraBackupRecords(records, stateKey: stateKey)
                UserDefaults.standard.set(Array(backedUpSet), forKey: stateKey)
                let recent = records.values
                    .filter { backedUpSet.contains($0.assetIdentifier) }
                    .sorted { $0.syncedAt > $1.syncedAt }
                    .prefix(30)
                    .map { ["name": $0.name, "path": $0.path, "size": $0.size, "syncedAt": $0.syncedAt] as [String: Any] }
                let pendingCount = max(0, assets.count - backedCount)
                var result: [String: Any] = [
                    "total": assets.count,
                    "totalPhotos": totalPhotos,
                    "totalVideos": totalVideos,
                    "backed": backedCount,
                    "pending": pendingCount,
                    "recent": Array(recent),
                    "deviceName": deviceFolder,
                    "modelName": self.getHardwareModelName(),
                    "mediaMode": mediaMode.rawValue,
                    "storageMode": storageMode.rawValue,
                    "hostVerified": hostVerified
                ]
                if let error = error, !error.isEmpty { result["err"] = error }
                AppLogger.shared.log(.info, category: "SYNC", "Thống kê Photos: mode=\(mediaMode.rawValue), storage=\(storageMode.rawValue), total=\(assets.count), backed=\(backedCount), pending=\(pendingCount), verified=\(hostVerified), recent=\(recent.count)")
                if let data = try? JSONSerialization.data(withJSONObject: result), let str = String(data: data, encoding: .utf8) {
                    completion(str)
                } else {
                    completion("{}")
                }
            }

            guard !baseUrl.isEmpty, !pool.isEmpty else {
                finishStats(backedUpSet: locallyBackedUpSet, records: locallySavedRecords, hostVerified: false, error: "Chưa thể xác minh file trên Host")
                return
            }
            let deepUrlString = "\(baseUrl)/api/files/deep?path=\(self.safeQueryEncode(deviceFolder))&camera=1&pool=\(self.safeQueryEncode(pool))"
            guard let deepUrl = URL(string: deepUrlString) else {
                finishStats(backedUpSet: locallyBackedUpSet, records: locallySavedRecords, hostVerified: false, error: "URL kiểm tra Host không hợp lệ")
                return
            }
            var request = URLRequest(url: deepUrl, timeoutInterval: 25)
            if !token.isEmpty { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
            self.performCameraRequestAsync(request, timeout: 25) { result in
                guard result.code == 200,
                      let object = (try? JSONSerialization.jsonObject(with: result.data)) as? [String: Any],
                      let files = object["files"] as? [[String: Any]] else {
                    AppLogger.shared.log(.warning, category: "SYNC", "Stats không đối chiếu được Host; HTTP=\(result.code)")
                    let detail = self.cameraErrorMessage(result, fallback: "Không thể xác minh file trên Host")
                    finishStats(backedUpSet: locallyBackedUpSet, records: locallySavedRecords, hostVerified: false, error: detail)
                    return
                }
                var serverPaths = Set<String>()
                var serverSizes: [String: Int64] = [:]
                for file in files {
                    guard let rel = file["rel"] as? String else { continue }
                    let normalized = rel.replacingOccurrences(of: "\\", with: "/").trimmingCharacters(in: CharacterSet(charactersIn: "/")).lowercased()
                    serverPaths.insert(normalized)
                    serverSizes[normalized] = self.int64Value(file["size"])
                }
                var reconciledSet = Set<String>()
                var reconciledRecords = locallySavedRecords
                var legacyPlannedPaths = Set<String>()
                for i in 0..<assets.count {
                    let asset = assets[i]
                    guard let resource = self.primaryResource(for: asset) else { continue }
                    let originalName = self.safeCameraFileName(resource.originalFilename, fallbackIndex: i, isVideo: asset.mediaType == .video)

                    if let saved = locallySavedRecords[asset.localIdentifier],
                       let savedRel = self.relativeCameraRecordPath(saved, deviceFolder: deviceFolder),
                       serverPaths.contains(savedRel),
                       saved.size <= 0 || serverSizes[savedRel] == saved.size {
                        reconciledSet.insert(asset.localIdentifier)
                        reconciledRecords[asset.localIdentifier] = CameraBackupRecord(
                            assetIdentifier: asset.localIdentifier,
                            name: saved.name,
                            path: saved.path,
                            size: serverSizes[savedRel] ?? saved.size,
                            syncedAt: saved.syncedAt,
                            verifiedUpload: saved.verifiedUpload
                        )
                        continue
                    }

                    // Có record nhưng Host thiếu hoặc sai dung lượng: giữ ở trạng thái
                    // pending để lượt đồng bộ kế tiếp sửa đúng đường dẫn record đó.
                    if locallySavedRecords[asset.localIdentifier] != nil { continue }

                    let stable = self.stableCameraDestination(originalName: originalName, assetIdentifier: asset.localIdentifier)
                    if serverPaths.contains(stable.relativePath) {
                        reconciledSet.insert(asset.localIdentifier)
                        reconciledRecords[asset.localIdentifier] = CameraBackupRecord(
                            assetIdentifier: asset.localIdentifier,
                            name: stable.name,
                            path: "\(deviceFolder)/\(stable.part)/\(stable.name)",
                            size: serverSizes[stable.relativePath] ?? 0,
                            syncedAt: locallySavedRecords[asset.localIdentifier]?.syncedAt ?? Date().timeIntervalSince1970,
                            verifiedUpload: locallySavedRecords[asset.localIdentifier]?.verifiedUpload ?? false
                        )
                        continue
                    }

                    if let existingRel = serverPaths.first(where: { ($0 as NSString).lastPathComponent.lowercased() == stable.name.lowercased() }) {
                        reconciledSet.insert(asset.localIdentifier)
                        reconciledRecords[asset.localIdentifier] = CameraBackupRecord(
                            assetIdentifier: asset.localIdentifier,
                            name: stable.name,
                            path: "\(deviceFolder)/\(existingRel)",
                            size: serverSizes[existingRel] ?? 0,
                            syncedAt: Date().timeIntervalSince1970,
                            verifiedUpload: false
                        )
                        continue
                    }

                    // Tương thích dữ liệu do các bản <= 1.5.9 đã gửi theo vị trí trong thư viện.
                    var legacyName = originalName
                    let legacyPart = "Camera_\((i / 200) + 1)"
                    var legacyTarget = "\(legacyPart)/\(legacyName)".lowercased()
                    if legacyPlannedPaths.contains(legacyTarget) {
                        let nsName = legacyName as NSString
                        let ext = nsName.pathExtension
                        let stem = nsName.deletingPathExtension
                        let suffix = asset.localIdentifier.components(separatedBy: CharacterSet.alphanumerics.inverted).filter { !$0.isEmpty }.joined().prefix(10)
                        legacyName = ext.isEmpty ? "\(stem)_\(suffix)" : "\(stem)_\(suffix).\(ext)"
                        legacyTarget = "\(legacyPart)/\(legacyName)".lowercased()
                    }
                    legacyPlannedPaths.insert(legacyTarget)
                    if locallySavedRecords[asset.localIdentifier] == nil && serverPaths.contains(legacyTarget) {
                        reconciledSet.insert(asset.localIdentifier)
                        reconciledRecords[asset.localIdentifier] = CameraBackupRecord(
                            assetIdentifier: asset.localIdentifier,
                            name: legacyName,
                            path: "\(deviceFolder)/\(legacyPart)/\(legacyName)",
                            size: serverSizes[legacyTarget] ?? 0,
                            syncedAt: reconciledRecords[asset.localIdentifier]?.syncedAt ?? Date().timeIntervalSince1970,
                            verifiedUpload: false
                        )
                    }
                }
                AppLogger.shared.log(.info, category: "SYNC", "Stats đối chiếu Host: serverFiles=\(serverPaths.count); matched=\(reconciledSet.count)")
                finishStats(backedUpSet: reconciledSet, records: reconciledRecords, hostVerified: true)
            }
        }
    }

    private func getHardwareModelName() -> String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let identifier = withUnsafePointer(to: &systemInfo.machine) {
            $0.withMemoryRebound(to: CChar.self, capacity: 1) { ptr in
                String(validatingUTF8: ptr) ?? "iPhone"
            }
        }
        let modelMap: [String: String] = [
            "iPhone13,1": "iPhone_12_mini",
            "iPhone13,2": "iPhone_12",
            "iPhone13,3": "iPhone_12_Pro",
            "iPhone13,4": "iPhone_12_Pro_Max",
            "iPhone14,4": "iPhone_13_mini",
            "iPhone14,5": "iPhone_13",
            "iPhone14,2": "iPhone_13_Pro",
            "iPhone14,3": "iPhone_13_Pro_Max",
            "iPhone14,7": "iPhone_14",
            "iPhone14,8": "iPhone_14_Plus",
            "iPhone15,2": "iPhone_14_Pro",
            "iPhone15,3": "iPhone_14_Pro_Max",
            "iPhone15,4": "iPhone_15",
            "iPhone15,5": "iPhone_15_Plus",
            "iPhone16,1": "iPhone_15_Pro",
            "iPhone16,2": "iPhone_15_Pro_Max",
            "iPhone17,1": "iPhone_16_Pro",
            "iPhone17,2": "iPhone_16_Pro_Max",
            "iPhone17,3": "iPhone_16",
            "iPhone17,4": "iPhone_16_Plus",
            "iPhone11,8": "iPhone_XR",
            "iPhone11,2": "iPhone_XS",
            "iPhone11,4": "iPhone_XS_Max",
            "iPhone11,6": "iPhone_XS_Max",
            "iPhone12,1": "iPhone_11",
            "iPhone12,3": "iPhone_11_Pro",
            "iPhone12,5": "iPhone_11_Pro_Max",
            "iPhone10,1": "iPhone_8",
            "iPhone10,4": "iPhone_8",
            "iPhone10,2": "iPhone_8_Plus",
            "iPhone10,5": "iPhone_8_Plus",
            "iPhone10,3": "iPhone_X",
            "iPhone10,6": "iPhone_X",
            "iPhone8,4": "iPhone_SE",
            "iPhone12,8": "iPhone_SE_2",
            "iPhone14,6": "iPhone_SE_3"
        ]
        return modelMap[identifier] ?? identifier.replacingOccurrences(of: ",", with: "_")
    }

    private func cameraDeviceFolder(customName: String) -> String {
        let safeCustom = customName
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty }
            .joined(separator: "_")
        if !safeCustom.isEmpty { return safeCustom }

        let safeDeviceName = UIDevice.current.name
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty }
            .joined(separator: "_")
        if !safeDeviceName.isEmpty && safeDeviceName.lowercased() != "iphone" {
            return safeDeviceName
        }
        return getHardwareModelName()
    }

    private func safeCameraFileName(_ value: String, fallbackIndex: Int, isVideo: Bool) -> String {
        var result = value
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .components(separatedBy: CharacterSet(charactersIn: "/\\:"))
            .filter { !$0.isEmpty && $0 != "." && $0 != ".." }
            .joined(separator: "_")
        if result.isEmpty {
            result = "IMG_\(String(format: "%04d", fallbackIndex + 1)).\(isVideo ? "MOV" : "HEIC")"
        }
        if result.count > 180 {
            let ns = result as NSString
            let ext = ns.pathExtension
            let stemLimit = max(1, 179 - ext.count)
            let stem = String(ns.deletingPathExtension.prefix(stemLimit))
            result = ext.isEmpty ? stem : "\(stem).\(ext)"
        }
        return result
    }

    private func cameraBackupStateKey(baseUrl: String, pool: String, deviceFolder: String) -> String {
        let identity = "\(baseUrl.lowercased())|\(pool.lowercased())|\(deviceFolder.lowercased())"
        let encoded = Data(identity.utf8).base64EncodedString()
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "=", with: "")
        return "cw_backed_up_assets_v2_\(encoded)"
    }

    private func cameraBackupRecordsKey(stateKey: String) -> String {
        return stateKey + "_records_v1"
    }

    private func loadCameraBackupRecords(stateKey: String) -> [String: CameraBackupRecord] {
        cameraRecordLock.lock()
        defer { cameraRecordLock.unlock() }
        guard let data = UserDefaults.standard.data(forKey: cameraBackupRecordsKey(stateKey: stateKey)),
              let records = try? JSONDecoder().decode([String: CameraBackupRecord].self, from: data) else {
            return [:]
        }
        return records
    }

    private func saveCameraBackupRecords(_ records: [String: CameraBackupRecord], stateKey: String) {
        cameraRecordLock.lock()
        defer { cameraRecordLock.unlock() }
        let key = cameraBackupRecordsKey(stateKey: stateKey)
        var merged: [String: CameraBackupRecord] = [:]
        if let currentData = UserDefaults.standard.data(forKey: key),
           let current = try? JSONDecoder().decode([String: CameraBackupRecord].self, from: currentData) {
            merged = current
        }
        for (identifier, incoming) in records {
            if let existing = merged[identifier], existing.syncedAt > incoming.syncedAt { continue }
            merged[identifier] = incoming
        }
        if merged.count > 20_000 {
            let keep = merged.values.sorted { $0.syncedAt > $1.syncedAt }.prefix(15_000)
            merged = Dictionary(uniqueKeysWithValues: keep.map { ($0.assetIdentifier, $0) })
        }
        guard let data = try? JSONEncoder().encode(merged) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }

    @discardableResult
    private func saveCameraBackupRecord(for item: BackupTaskItem, size: Int64, stateKey: String) -> CameraBackupRecord {
        var records = loadCameraBackupRecords(stateKey: stateKey)
        let record = CameraBackupRecord(
            assetIdentifier: item.asset.localIdentifier,
            name: item.originalName,
            path: "\(item.targetFolder)/\(item.originalName)",
            size: size,
            syncedAt: Date().timeIntervalSince1970,
            verifiedUpload: true
        )
        records[item.asset.localIdentifier] = record
        if records.count > 20_000 {
            let keep = records.values.sorted { $0.syncedAt > $1.syncedAt }.prefix(15_000)
            records = Dictionary(uniqueKeysWithValues: keep.map { ($0.assetIdentifier, $0) })
        }
        saveCameraBackupRecords(records, stateKey: stateKey)
        return record
    }

    private func notifyCameraUploaded(_ record: CameraBackupRecord, current: Int, total: Int) {
        let payload: [String: Any] = [
            "name": record.name,
            "path": record.path,
            "size": record.size,
            "syncedAt": record.syncedAt,
            "current": current,
            "total": total
        ]
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            let js = "window.DC && DC._onCameraUploaded && DC._onCameraUploaded(\(self.jsonString(payload)));"
            self.webView?.evaluateJavaScript(js, completionHandler: nil)
        }
    }

    #if false
    private func hasWiFiConnection(timeout: TimeInterval = 2.5) -> Bool {
        let monitor = NWPathMonitor()
        let semaphore = DispatchSemaphore(value: 0)
        let lock = NSLock()
        var isWiFi = false
        var delivered = false

        monitor.pathUpdateHandler = { path in
            lock.lock()
            guard !delivered else {
                lock.unlock()
                return
            }
            delivered = true
            isWiFi = path.status == .satisfied && path.usesInterfaceType(.wifi)
            lock.unlock()
            semaphore.signal()
        }
        monitor.start(queue: DispatchQueue(label: "com.cw.datacenter.camera-network-check"))
        _ = semaphore.wait(timeout: .now() + timeout)
        monitor.cancel()

        lock.lock()
        let result = isWiFi
        lock.unlock()
        return result
    }
    #endif

    private func checkWiFiConnection(timeout: TimeInterval = 2.5, completion: @escaping (Bool) -> Void) {
        let callbackGate = OneShotGate()
        let callbackQueue = DispatchQueue(label: "com.cw.datacenter.camera-network-check.async")
        var monitor: NWPathMonitor? = NWPathMonitor()

        func finish(_ connected: Bool) {
            guard callbackGate.claim() else { return }
            monitor?.pathUpdateHandler = nil
            monitor?.cancel()
            monitor = nil
            completion(connected)
        }

        monitor?.pathUpdateHandler = { path in
            finish(path.status == .satisfied && path.usesInterfaceType(.wifi))
        }
        monitor?.start(queue: callbackQueue)
        callbackQueue.asyncAfter(deadline: .now() + timeout) { finish(false) }
    }

    private func startCameraBackup(params: [String: Any], completion: @escaping (Bool, String) -> Void) {
        guard claimCameraBackupRun() else {
            AppLogger.shared.log(.warning, category: "SYNC", "Bỏ qua start vì một phiên đồng bộ đang chạy")
            completion(false, "Một phiên đồng bộ khác đang chạy")
            return
        }

        PHPhotoLibrary.requestAuthorization(for: .readWrite) { [weak self] status in
            guard let self = self else { return }
            guard status == .authorized || status == .limited else {
                AppLogger.shared.log(.error, category: "PHOTOS", "Không có quyền Photos; status=\(status.rawValue)")
                self.finishCameraBackupBeforeRun(message: "Vui lòng cấp quyền Thư viện ảnh trong Cài đặt iPhone", completion: completion)
                return
            }

            let mediaMode = self.cameraMediaMode(from: params)
            let storageMode = self.cameraStorageMode(from: params)
            let wifiOnly = params["wifiOnly"] as? Bool ?? true
            let baseUrl = (params["baseUrl"] as? String ?? LocalProxy.shared.baseUrl).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            let token = params["token"] as? String ?? LocalProxy.shared.token
            let pool = (params["pool"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            let customDeviceName = (params["customDeviceName"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            let imageFolderLimit = self.cameraFolderLimit(params["imageFolderLimit"], fallback: 400)
            let videoFolderLimit = self.cameraFolderLimit(params["videoFolderLimit"], fallback: 300)
            let deleteAfterUpload = params["deleteAfterUpload"] as? Bool ?? false

            guard !baseUrl.isEmpty else { self.finishCameraBackupBeforeRun(message: "Chưa có địa chỉ máy chủ", completion: completion); return }
            guard !pool.isEmpty else { self.finishCameraBackupBeforeRun(message: "Không tìm thấy ổ lưu Camera trên máy chủ", completion: completion); return }
            AppLogger.shared.log(.info, category: "SYNC", "Chuẩn bị đồng bộ Photos; mode=\(mediaMode.rawValue); storage=\(storageMode.rawValue); imagesPerFolder=\(imageFolderLimit); videosPerFolder=\(videoFolderLimit); wifiOnly=\(wifiOnly); deleteAfterUpload=\(deleteAfterUpload); pool=\(pool); host=\(baseUrl)")

            let begin = { [weak self] in
                self?.beginSequentialCameraBackup(
                    mediaMode: mediaMode,
                    storageMode: storageMode,
                    baseUrl: baseUrl,
                    token: token,
                    pool: pool,
                    customDeviceName: customDeviceName,
                    imageFolderLimit: imageFolderLimit,
                    videoFolderLimit: videoFolderLimit,
                    deleteAfterUpload: deleteAfterUpload,
                    completion: completion
                )
            }

            if wifiOnly {
                self.checkWiFiConnection { connected in
                    if connected { begin() }
                    else { self.finishCameraBackupBeforeRun(message: "Chế độ chỉ Wi-Fi đang bật. Hãy kết nối Wi-Fi rồi thử lại", completion: completion) }
                }
            } else {
                begin()
            }
        }
    }

    private func beginSequentialCameraBackup(mediaMode: CameraMediaMode, storageMode: CameraStorageMode, baseUrl: String, token: String, pool: String, customDeviceName: String, imageFolderLimit: Int, videoFolderLimit: Int, deleteAfterUpload: Bool, completion: @escaping (Bool, String) -> Void) {
        beginCameraBackgroundTask()

        let deviceFolder = cameraDeviceFolder(customName: customDeviceName)
        let fetchOptions = cameraFetchOptions(for: mediaMode)
        let fetchedAssets = PHAsset.fetchAssets(with: fetchOptions)
        let assets = filteredCameraAssets(fetchedAssets, storageMode: storageMode)
        let totalAssets = assets.count
        AppLogger.shared.log(.info, category: "PHOTOS", "Đã quét thấy \(totalAssets) mục; mode=\(mediaMode.rawValue); storage=\(storageMode.rawValue); deviceFolder=\(deviceFolder)")
        let stateKey = cameraBackupStateKey(baseUrl: baseUrl, pool: pool, deviceFolder: deviceFolder)

        var deepUrlString = "\(baseUrl)/api/files/deep?path=\(safeQueryEncode(deviceFolder))&camera=1"
        deepUrlString += "&pool=\(safeQueryEncode(pool))"
        guard let deepUrl = URL(string: deepUrlString) else {
            finishCameraBackupBeforeRun(message: "URL kiểm tra thư mục Camera không hợp lệ", completion: completion)
            return
        }
        var request = URLRequest(url: deepUrl, timeoutInterval: 25)
        if !token.isEmpty { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }

        performCameraRequestAsync(request, timeout: 25) { [weak self] result in
            guard let self = self else { return }
            guard self.isCameraBackupRunning && !self.isCameraBackupPaused else {
                self.finishCameraBackupBeforeRun(message: "Đã tạm dừng", success: true, completion: completion)
                return
            }
            guard result.code == 200 else {
                let detail = self.cameraErrorMessage(result, fallback: "Không đọc được thư mục đích trên Host")
                AppLogger.shared.log(.error, category: "SYNC_HTTP", "Deep list thất bại HTTP \(result.code): \(detail)")
                self.notifyCameraProgress(current: 0, total: totalAssets, filename: "[Host] \(detail)", part: "", percent: 0)
                self.finishCameraBackupBeforeRun(message: detail, completion: completion)
                return
            }

            DispatchQueue.global(qos: .userInitiated).async {
                var serverFilePaths = Set<String>()
                var serverFileSizes: [String: Int64] = [:]
                if let object = (try? JSONSerialization.jsonObject(with: result.data)) as? [String: Any],
                   let files = object["files"] as? [[String: Any]] {
                    for file in files {
                        if let relativePath = file["rel"] as? String {
                            let normalized = relativePath.replacingOccurrences(of: "\\", with: "/").trimmingCharacters(in: CharacterSet(charactersIn: "/"))
                            let key = normalized.lowercased()
                            serverFilePaths.insert(key)
                            serverFileSizes[key] = self.int64Value(file["size"])
                        }
                    }
                }
                AppLogger.shared.log(.info, category: "SYNC", "Host đang có \(serverFilePaths.count) file trong thư mục thiết bị")

                var backedUpSet = Set<String>()
                var pendingTasks: [BackupTaskItem] = []
                var verifiedAssetsToDelete: [PHAsset] = []
                var completedCount = 0
                let savedRecords = self.loadCameraBackupRecords(stateKey: stateKey)
                var reconciledRecords = savedRecords
                var legacyPlannedPaths = Set<String>()
                var mediaFolderCounts: [String: [Int: Int]] = ["images": [:], "videos": [:]]
                for relativePath in serverFilePaths {
                    let components = relativePath.split(separator: "/").map { String($0).lowercased() }
                    guard components.count >= 3 else { continue }
                    let root = components[0]
                    let folderName = components[1]
                    guard root == "images" || root == "videos",
                          folderName.hasPrefix(root + "_"),
                          let folderNumber = Int(folderName.dropFirst((root + "_").count)),
                          folderNumber > 0 else { continue }
                    mediaFolderCounts[root, default: [:]][folderNumber, default: 0] += 1
                }
                var nextMediaFolderNumber: [String: Int] = ["images": 1, "videos": 1]
                func allocateSequentialMediaFolder(for asset: PHAsset) -> String {
                    let root = asset.mediaType == .video ? "videos" : "images"
                    let displayRoot = asset.mediaType == .video ? "Videos" : "Images"
                    let limit = asset.mediaType == .video ? videoFolderLimit : imageFolderLimit
                    var number = nextMediaFolderNumber[root, default: 1]
                    while mediaFolderCounts[root, default: [:]][number, default: 0] >= limit {
                        number += 1
                    }
                    nextMediaFolderNumber[root] = number
                    mediaFolderCounts[root, default: [:]][number, default: 0] += 1
                    return "\(displayRoot)/\(displayRoot)_\(String(format: "%03d", number))"
                }
                func reserveMediaFolderIfNeeded(_ folder: String) {
                    let components = folder.replacingOccurrences(of: "\\", with: "/").split(separator: "/").map { String($0).lowercased() }
                    guard components.count >= 2 else { return }
                    let root = components[0]
                    let leaf = components[1]
                    guard root == "images" || root == "videos",
                          leaf.hasPrefix(root + "_"),
                          let folderNumber = Int(leaf.dropFirst((root + "_").count)),
                          folderNumber > 0 else { return }
                    mediaFolderCounts[root, default: [:]][folderNumber, default: 0] += 1
                }

                for index in 0..<totalAssets {
                    guard self.isCameraBackupRunning && !self.isCameraBackupPaused else {
                        self.finishCameraBackupBeforeRun(message: "Đã tạm dừng", success: true, completion: completion)
                        return
                    }
                    let asset = assets[index]
                    guard let primary = self.primaryResource(for: asset) else { continue }
                    let originalName = self.safeCameraFileName(primary.originalFilename, fallbackIndex: index, isVideo: asset.mediaType == .video)

                    if let record = savedRecords[asset.localIdentifier],
                       let recordRel = self.relativeCameraRecordPath(record, deviceFolder: deviceFolder),
                       serverFilePaths.contains(recordRel),
                       record.size <= 0 || serverFileSizes[recordRel] == record.size {
                        backedUpSet.insert(asset.localIdentifier)
                        completedCount += 1
                        if deleteAfterUpload, record.verifiedUpload != false, record.size > 0, serverFileSizes[recordRel] == record.size {
                            verifiedAssetsToDelete.append(asset)
                        }
                        continue
                    }

                    // Đã có mapping nhưng file Host thiếu/sai kích thước: gửi lại đúng
                    // đường dẫn cũ để sửa file, không tạo thêm một bản ở thư mục mới.
                    if let record = savedRecords[asset.localIdentifier],
                       let recordRel = self.relativeCameraRecordPath(record, deviceFolder: deviceFolder) {
                        let relName = (recordRel as NSString).lastPathComponent
                        let relFolder = (recordRel as NSString).deletingLastPathComponent
                        let targetFolder = relFolder.isEmpty || relFolder == "." ? deviceFolder : "\(deviceFolder)/\(relFolder)"
                        let partName = relFolder.isEmpty || relFolder == "." ? (asset.mediaType == .video ? "Videos" : "Images") : relFolder
                        backedUpSet.remove(asset.localIdentifier)
                        reserveMediaFolderIfNeeded(partName)
                        pendingTasks.append(BackupTaskItem(index: index, asset: asset, originalName: relName.isEmpty ? record.name : relName, targetFolder: targetFolder, partName: partName))
                        continue
                    }

                    let stable = self.stableCameraDestination(originalName: originalName, assetIdentifier: asset.localIdentifier)
                    if serverFilePaths.contains(stable.relativePath) {
                        backedUpSet.insert(asset.localIdentifier)
                        completedCount += 1
                        reconciledRecords[asset.localIdentifier] = CameraBackupRecord(
                            assetIdentifier: asset.localIdentifier,
                            name: stable.name,
                            path: "\(deviceFolder)/\(stable.part)/\(stable.name)",
                            size: serverFileSizes[stable.relativePath] ?? 0,
                            syncedAt: savedRecords[asset.localIdentifier]?.syncedAt ?? Date().timeIntervalSince1970,
                            verifiedUpload: savedRecords[asset.localIdentifier]?.verifiedUpload ?? false
                        )
                        continue
                    }

                    // Bản 1.6.6 dùng tên có token ổn định trong Images/Videos.
                    // Khi cài lại app, dò token trên Host để phục hồi mapping mà
                    // không cần upload trùng hoặc phụ thuộc thứ tự thư viện.
                    if let existingRel = serverFilePaths.first(where: { ($0 as NSString).lastPathComponent.lowercased() == stable.name.lowercased() }) {
                        let existingSize = serverFileSizes[existingRel] ?? 0
                        backedUpSet.insert(asset.localIdentifier)
                        completedCount += 1
                        reconciledRecords[asset.localIdentifier] = CameraBackupRecord(
                            assetIdentifier: asset.localIdentifier,
                            name: stable.name,
                            path: "\(deviceFolder)/\(existingRel)",
                            size: existingSize,
                            syncedAt: Date().timeIntervalSince1970,
                            verifiedUpload: false
                        )
                        continue
                    }

                    // Migration: nhận diện đường dẫn do bản 1.5.9 trở về trước đã tạo.
                    var legacyName = originalName
                    let legacyPart = "Camera_\((index / 200) + 1)"
                    var legacyTarget = "\(legacyPart)/\(legacyName)".lowercased()
                    if legacyPlannedPaths.contains(legacyTarget) {
                        let nsName = legacyName as NSString
                        let ext = nsName.pathExtension
                        let stem = nsName.deletingPathExtension
                        let stableSuffix = asset.localIdentifier
                            .components(separatedBy: CharacterSet.alphanumerics.inverted)
                            .filter { !$0.isEmpty }
                            .joined()
                            .prefix(10)
                        let suffix = stableSuffix.isEmpty ? String(index + 1) : String(stableSuffix)
                        legacyName = ext.isEmpty ? "\(stem)_\(suffix)" : "\(stem)_\(suffix).\(ext)"
                        legacyTarget = "\(legacyPart)/\(legacyName)".lowercased()
                    }
                    var collisionNumber = 2
                    while legacyPlannedPaths.contains(legacyTarget) {
                        let nsName = legacyName as NSString
                        let ext = nsName.pathExtension
                        let stem = nsName.deletingPathExtension
                        legacyName = ext.isEmpty ? "\(stem)_\(collisionNumber)" : "\(stem)_\(collisionNumber).\(ext)"
                        legacyTarget = "\(legacyPart)/\(legacyName)".lowercased()
                        collisionNumber += 1
                    }
                    legacyPlannedPaths.insert(legacyTarget)
                    if savedRecords[asset.localIdentifier] == nil && serverFilePaths.contains(legacyTarget) {
                        backedUpSet.insert(asset.localIdentifier)
                        completedCount += 1
                        reconciledRecords[asset.localIdentifier] = CameraBackupRecord(
                            assetIdentifier: asset.localIdentifier,
                            name: legacyName,
                            path: "\(deviceFolder)/\(legacyPart)/\(legacyName)",
                            size: serverFileSizes[legacyTarget] ?? 0,
                            syncedAt: savedRecords[asset.localIdentifier]?.syncedAt ?? Date().timeIntervalSince1970,
                            verifiedUpload: false
                        )
                    } else {
                        backedUpSet.remove(asset.localIdentifier)
                        let sequentialPart = allocateSequentialMediaFolder(for: asset)
                        pendingTasks.append(BackupTaskItem(index: index, asset: asset, originalName: stable.name, targetFolder: "\(deviceFolder)/\(sequentialPart)", partName: sequentialPart))
                    }
                }

                self.saveCameraBackupRecords(reconciledRecords, stateKey: stateKey)
                UserDefaults.standard.set(Array(backedUpSet), forKey: stateKey)
                AppLogger.shared.log(.info, category: "SYNC", "Đối chiếu hoàn tất: đã có=\(completedCount), cần gửi=\(pendingTasks.count), đủ điều kiện xóa=\(verifiedAssetsToDelete.count)")

                let context = CameraBackupRunContext(
                    tasks: pendingTasks,
                    totalAssets: totalAssets,
                    completedCount: completedCount,
                    backedUpSet: backedUpSet,
                    assetsToDelete: verifiedAssetsToDelete,
                    stateKey: stateKey,
                    baseUrl: baseUrl,
                    pool: pool,
                    token: token,
                    mediaMode: mediaMode,
                    storageMode: storageMode,
                    deviceFolder: deviceFolder,
                    imageFolderLimit: imageFolderLimit,
                    videoFolderLimit: videoFolderLimit,
                    deleteAfterUpload: deleteAfterUpload,
                    completion: completion
                )
                self.processNextCameraBackupItem(context)
            }
        }
    }

    private func primaryResource(for asset: PHAsset) -> PHAssetResource? {
        let resources = PHAssetResource.assetResources(for: asset)
        return resources.first(where: {
            $0.type == .photo || $0.type == .video || $0.type == .fullSizePhoto || $0.type == .fullSizeVideo
        }) ?? resources.first
    }

    private func processNextCameraBackupItem(_ context: CameraBackupRunContext) {
        guard isCameraBackupRunning && !isCameraBackupPaused else {
            finishCameraBackup(context, success: true, message: "Đã tạm dừng")
            return
        }
        guard context.cursor < context.tasks.count else {
            if context.failedItems.isEmpty {
                finishCameraBackup(context, success: true, message: "Hoàn tất sao lưu")
            } else {
                let sample = context.failedItems.prefix(3).joined(separator: ", ")
                finishCameraBackup(context, success: false, message: "Đã đồng bộ phần còn lại; lỗi \(context.failedItems.count) tệp: \(sample)")
            }
            return
        }

        let item = context.tasks[context.cursor]
        guard let primary = primaryResource(for: item.asset) else {
            AppLogger.shared.log(.error, category: "PHOTOS", "Không tìm thấy PHAssetResource: \(item.originalName)")
            context.recordFailure(item.originalName)
            context.cursor += 1
            notifyCameraProgress(current: context.completedCount, total: context.totalAssets, filename: "[Lỗi Photos] Bỏ qua \(item.originalName): không tìm thấy dữ liệu asset", part: item.partName, percent: context.totalAssets > 0 ? Int(Double(context.cursor) / Double(context.tasks.count) * 100) : 0)
            processNextCameraBackupItem(context)
            return
        }

        let temporaryUrl = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + "_" + item.originalName)
        try? FileManager.default.removeItem(at: temporaryUrl)
        AppLogger.shared.log(.info, category: "PHOTOS", "Đọc asset \(item.index + 1)/\(context.totalAssets): \(item.originalName); resourceType=\(primary.type.rawValue)")
        materializeCameraAsset(item, primary: primary, destination: temporaryUrl, context: context) { [weak self] materializeError in
            guard let self = self else { try? FileManager.default.removeItem(at: temporaryUrl); return }
            guard self.isCameraBackupRunning && !self.isCameraBackupPaused else {
                try? FileManager.default.removeItem(at: temporaryUrl)
                self.finishCameraBackup(context, success: true, message: "Đã tạm dừng")
                return
            }
            guard materializeError == nil && FileManager.default.fileExists(atPath: temporaryUrl.path) else {
                try? FileManager.default.removeItem(at: temporaryUrl)
                let detail = materializeError ?? "Không đọc được từ Thư viện ảnh/iCloud"
                AppLogger.shared.log(.error, category: "PHOTOS", "Bỏ qua asset lỗi \(item.originalName): \(detail)")
                context.recordFailure(item.originalName)
                context.cursor += 1
                self.notifyCameraProgress(current: context.completedCount, total: context.totalAssets, filename: "[Lỗi iCloud] Đã bỏ qua \(item.originalName): \(detail)", part: item.partName, percent: context.tasks.isEmpty ? 0 : Int(Double(context.cursor) / Double(context.tasks.count) * 100))
                self.processNextCameraBackupItem(context)
                return
            }

            let temporaryAttributes = try? FileManager.default.attributesOfItem(atPath: temporaryUrl.path)
            let temporarySize = (temporaryAttributes?[.size] as? NSNumber)?.int64Value ?? 0
            AppLogger.shared.log(.info, category: "PHOTOS", "Đã tạo tệp tạm \(item.originalName); size=\(temporarySize)")

            self.uploadCameraFileAsync(
                fileUrl: temporaryUrl,
                fileName: item.originalName,
                targetFolder: item.targetFolder,
                baseUrl: context.baseUrl,
                pool: context.pool,
                token: context.token,
                onProgress: { [weak self] sent, total, speed in
                    guard let self = self, context.shouldReportProgress(force: sent >= total) else { return }
                    let percent = context.totalAssets > 0 ? Int(Double(item.index + 1) / Double(context.totalAssets) * 100) : 0
                    let progressText = "\(self.formatSize(sent)) / \(self.formatSize(total)) · \(self.formatSpeed(speed))"
                    self.notifyCameraProgress(current: context.completedCount, total: context.totalAssets, filename: "[Mạng LAN] \(item.originalName) (\(progressText))", part: item.partName, percent: percent)
                },
                completion: { [weak self] ok, code, errorMessage in
                    try? FileManager.default.removeItem(at: temporaryUrl)
                    guard let self = self else { return }
                    guard self.isCameraBackupRunning && !self.isCameraBackupPaused else {
                        self.finishCameraBackup(context, success: true, message: "Đã tạm dừng")
                        return
                    }
                    guard ok else {
                        let detail = errorMessage ?? (code > 0 ? "HTTP \(code)" : "Mất kết nối máy chủ")
                        AppLogger.shared.log(.error, category: "SYNC_HTTP", "Dừng upload tại \(item.originalName); HTTP=\(code); \(detail)")
                        context.recordFailure(item.originalName)
                        self.notifyCameraProgress(current: context.completedCount, total: context.totalAssets, filename: "[Lỗi Host] Dừng tại \(item.originalName): \(detail)", part: item.partName, percent: context.totalAssets > 0 ? Int(Double(context.completedCount) / Double(context.totalAssets) * 100) : 0)
                        self.finishCameraBackup(context, success: false, message: "Upload chưa hoàn tất \(item.originalName): \(detail)")
                        return
                    }

                    context.backedUpSet.insert(item.asset.localIdentifier)
                    context.completedCount += 1
                    context.cursor += 1
                    UserDefaults.standard.set(Array(context.backedUpSet), forKey: context.stateKey)
                    let record = self.saveCameraBackupRecord(for: item, size: temporarySize, stateKey: context.stateKey)
                    self.notifyCameraUploaded(record, current: context.completedCount, total: context.totalAssets)
                    if context.deleteAfterUpload {
                        context.addAssetForDeletion(item.asset)
                    }
                    AppLogger.shared.log(.info, category: "SYNC", "Đồng bộ thành công \(item.targetFolder)/\(item.originalName); HTTP=\(code)")
                    self.processNextCameraBackupItem(context)
                }
            )
        }
    }

    private func materializeCameraAsset(
        _ item: BackupTaskItem,
        primary: PHAssetResource,
        destination: URL,
        context: CameraBackupRunContext,
        attempt: Int = 1,
        completion: @escaping (String?) -> Void
    ) {
        guard isCameraBackupRunning && !isCameraBackupPaused else {
            completion("Đã tạm dừng")
            return
        }
        try? FileManager.default.removeItem(at: destination)
        let options = PHAssetResourceRequestOptions()
        options.isNetworkAccessAllowed = true
        options.progressHandler = { [weak self] progress in
            guard let self = self, context.shouldReportProgress() else { return }
            let percent = context.totalAssets > 0 ? Int(Double(item.index + 1) / Double(context.totalAssets) * 100) : 0
            self.notifyCameraProgress(current: context.completedCount, total: context.totalAssets, filename: "[iCloud] Đang tải (\(Int(progress * 100))%): \(item.originalName)", part: item.partName, percent: percent)
        }

        PHAssetResourceManager.default().writeData(for: primary, toFile: destination, options: options) { [weak self] error in
            guard let self = self else { completion("Tác vụ đã kết thúc"); return }
            if error == nil, FileManager.default.fileExists(atPath: destination.path) {
                completion(nil)
                return
            }

            let nsError = error as NSError?
            let detail = nsError.map { "\($0.domain) code=\($0.code): \($0.localizedDescription)" } ?? "Không tạo được file từ Photos"
            AppLogger.shared.log(.warning, category: "ICLOUD", "Lần \(attempt)/3 lỗi \(item.originalName): \(detail)")
            try? FileManager.default.removeItem(at: destination)
            guard self.isCameraBackupRunning && !self.isCameraBackupPaused else {
                completion("Đã tạm dừng")
                return
            }
            // CloudPhotoLibraryErrorDomain/1005 is a deterministic iCloud
            // materialization failure. Repeating writeData three times only
            // wastes several seconds per asset, so switch immediately to the
            // PHImageManager current-version path. Transient errors still get
            // one retry before the fallback.
            let isCloudMaterializationError = nsError?.domain == "CloudPhotoLibraryErrorDomain" && nsError?.code == 1005
            if attempt < 2, !isCloudMaterializationError, self.isCameraBackupRunning, !self.isCameraBackupPaused {
                DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + Double(attempt)) { [weak self] in
                    self?.materializeCameraAsset(item, primary: primary, destination: destination, context: context, attempt: attempt + 1, completion: completion)
                }
                return
            }

            self.materializeCameraAssetFallback(item, destination: destination, context: context) { fallbackError in
                if let fallbackError = fallbackError {
                    if attempt < 3, self.isCameraBackupRunning, !self.isCameraBackupPaused {
                        AppLogger.shared.log(.warning, category: "ICLOUD", "Fallback lần \(attempt)/3 chưa đọc được \(item.originalName); sẽ thử lại: \(fallbackError)")
                        DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + Double(attempt * 2)) { [weak self] in
                            self?.materializeCameraAsset(item, primary: primary, destination: destination, context: context, attempt: attempt + 1, completion: completion)
                        }
                        return
                    }
                    completion("\(detail); \(fallbackError)")
                } else {
                    completion(nil)
                }
            }
        }
    }

    private func materializeCameraAssetFallback(
        _ item: BackupTaskItem,
        destination: URL,
        context: CameraBackupRunContext,
        completion: @escaping (String?) -> Void
    ) {
        AppLogger.shared.log(.info, category: "ICLOUD", "Dùng phương án Photos fallback cho \(item.originalName)")
        let finishGate = OneShotGate()
        func finish(_ error: String?) {
            guard finishGate.claim() else { return }
            completion(error)
        }
        if item.asset.mediaType == .image {
            func requestImageData(version: PHImageRequestOptionsVersion, label: String, retryOriginal: Bool) {
                guard self.isCameraBackupRunning && !self.isCameraBackupPaused else {
                    finish("Đã tạm dừng")
                    return
                }
                try? FileManager.default.removeItem(at: destination)
                let options = PHImageRequestOptions()
                options.isNetworkAccessAllowed = true
                options.version = version
                options.deliveryMode = .highQualityFormat
                options.resizeMode = .none
                options.isSynchronous = false
                options.progressHandler = { [weak self] progress, error, _, _ in
                    guard let self = self, context.shouldReportProgress() else { return }
                    let percent = context.totalAssets > 0 ? Int(Double(item.index + 1) / Double(context.totalAssets) * 100) : 0
                    let suffix = error.map { " · \($0.localizedDescription)" } ?? ""
                    self.notifyCameraProgress(current: context.completedCount, total: context.totalAssets, filename: "[iCloud \(label)] \(Int(progress * 100))%: \(item.originalName)\(suffix)", part: item.partName, percent: percent)
                }
                PHImageManager.default().requestImageDataAndOrientation(for: item.asset, options: options) { data, dataUTI, _, info in
                    if (info?[PHImageResultIsDegradedKey] as? Bool) == true { return }
                    if let data = data, !data.isEmpty {
                        do {
                            try data.write(to: destination, options: .atomic)
                            AppLogger.shared.log(.info, category: "ICLOUD", "Fallback ảnh \(label) thành công: \(item.originalName); size=\(data.count); uti=\(dataUTI ?? "?")")
                            finish(nil)
                        } catch {
                            finish("Fallback ảnh không ghi được file: \(error.localizedDescription)")
                        }
                        return
                    }

                    let requestError = info?[PHImageErrorKey] as? NSError
                    let detail = requestError.map { "\($0.domain) code=\($0.code): \($0.localizedDescription)" } ?? "không có dữ liệu"
                    if retryOriginal {
                        AppLogger.shared.log(.warning, category: "ICLOUD", "Ảnh bản hiện tại lỗi \(item.originalName): \(detail); thử bản gốc")
                        requestImageData(version: .original, label: "bản gốc", retryOriginal: false)
                    } else {
                        finish("Fallback ảnh thất bại: \(detail)")
                    }
                }
            }

            // The current rendition is often locally available even when the
            // original resource is optimized into iCloud. Preserve the original
            // request as a second chance.
            requestImageData(version: .current, label: "bản hiện tại", retryOriginal: true)
            return
        }

        func requestVideoAsset(version: PHVideoRequestOptionsVersion, label: String, retryOriginal: Bool) {
            guard self.isCameraBackupRunning && !self.isCameraBackupPaused else {
                finish("Đã tạm dừng")
                return
            }
            let options = PHVideoRequestOptions()
            options.isNetworkAccessAllowed = true
            options.version = version
            options.deliveryMode = .highQualityFormat
            options.progressHandler = { [weak self] progress, error, _, _ in
                guard let self = self, context.shouldReportProgress() else { return }
                let percent = context.totalAssets > 0 ? Int(Double(item.index + 1) / Double(context.totalAssets) * 100) : 0
                let suffix = error.map { " · \($0.localizedDescription)" } ?? ""
                self.notifyCameraProgress(current: context.completedCount, total: context.totalAssets, filename: "[iCloud video \(label)] \(Int(progress * 100))%: \(item.originalName)\(suffix)", part: item.partName, percent: percent)
            }
            PHImageManager.default().requestAVAsset(forVideo: item.asset, options: options) { asset, _, info in
                guard let asset = asset else {
                    let requestError = info?[PHImageErrorKey] as? NSError
                    let detail = requestError.map { "\($0.domain) code=\($0.code): \($0.localizedDescription)" } ?? "không có AVAsset"
                    if retryOriginal {
                        AppLogger.shared.log(.warning, category: "ICLOUD", "Video bản hiện tại lỗi \(item.originalName): \(detail); thử bản gốc")
                        requestVideoAsset(version: .original, label: "bản gốc", retryOriginal: false)
                    } else {
                        finish("Fallback video thất bại: \(detail)")
                    }
                    return
                }

                if let urlAsset = asset as? AVURLAsset, urlAsset.url.isFileURL {
                    do {
                        try? FileManager.default.removeItem(at: destination)
                        try FileManager.default.copyItem(at: urlAsset.url, to: destination)
                        AppLogger.shared.log(.info, category: "ICLOUD", "Fallback video \(label) copy thành công: \(item.originalName)")
                        finish(nil)
                    } catch {
                        finish("Fallback video không copy được: \(error.localizedDescription)")
                    }
                    return
                }

                guard let exporter = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetPassthrough) else {
                    if retryOriginal {
                        requestVideoAsset(version: .original, label: "bản gốc", retryOriginal: false)
                    } else {
                        finish("Fallback video không tạo được phiên xuất")
                    }
                    return
                }
                try? FileManager.default.removeItem(at: destination)
                exporter.outputURL = destination
                let preferred: AVFileType = destination.pathExtension.lowercased() == "mp4" ? .mp4 : .mov
                exporter.outputFileType = exporter.supportedFileTypes.contains(preferred) ? preferred : exporter.supportedFileTypes.first
                exporter.shouldOptimizeForNetworkUse = false
                exporter.exportAsynchronously {
                    if exporter.status == .completed, FileManager.default.fileExists(atPath: destination.path) {
                        AppLogger.shared.log(.info, category: "ICLOUD", "Fallback video \(label) export thành công: \(item.originalName)")
                        finish(nil)
                    } else {
                        let detail = exporter.error?.localizedDescription ?? "status=\(exporter.status.rawValue)"
                        if retryOriginal {
                            AppLogger.shared.log(.warning, category: "ICLOUD", "Xuất video bản hiện tại lỗi \(item.originalName): \(detail); thử bản gốc")
                            requestVideoAsset(version: .original, label: "bản gốc", retryOriginal: false)
                        } else {
                            finish("Fallback video export lỗi: \(detail)")
                        }
                    }
                }
            }
        }

        requestVideoAsset(version: .current, label: "bản hiện tại", retryOriginal: true)
        return

        #if false
        // 1.5.3 fallback retained as a compile-time-disabled migration reference.
        if item.asset.mediaType == .image {
            let options = PHImageRequestOptions()
            options.isNetworkAccessAllowed = true
            options.version = .original
            options.deliveryMode = .highQualityFormat
            options.progressHandler = { [weak self] progress, _, _, _ in
                guard let self = self, context.shouldReportProgress() else { return }
                let percent = context.totalAssets > 0 ? Int(Double(item.index + 1) / Double(context.totalAssets) * 100) : 0
                self.notifyCameraProgress(current: context.completedCount, total: context.totalAssets, filename: "[iCloud fallback] \(Int(progress * 100))%: \(item.originalName)", part: item.partName, percent: percent)
            }
            PHImageManager.default().requestImageDataAndOrientation(for: item.asset, options: options) { data, _, _, info in
                if (info?[PHImageResultIsDegradedKey] as? Bool) == true { return }
                if let data = data {
                    do {
                        try data.write(to: destination, options: .atomic)
                        AppLogger.shared.log(.info, category: "ICLOUD", "Fallback ảnh thành công: \(item.originalName); size=\(data.count)")
                        finish(nil)
                    } catch {
                        finish("Fallback ảnh không ghi được file: \(error.localizedDescription)")
                    }
                } else {
                    let error = info?[PHImageErrorKey] as? Error
                    finish("Fallback ảnh thất bại: \(error?.localizedDescription ?? "không có dữ liệu")")
                }
            }
            return
        }

        let options = PHVideoRequestOptions()
        options.isNetworkAccessAllowed = true
        options.version = .original
        options.deliveryMode = .highQualityFormat
        options.progressHandler = { [weak self] progress, _, _, _ in
            guard let self = self, context.shouldReportProgress() else { return }
            let percent = context.totalAssets > 0 ? Int(Double(item.index + 1) / Double(context.totalAssets) * 100) : 0
            self.notifyCameraProgress(current: context.completedCount, total: context.totalAssets, filename: "[iCloud video] \(Int(progress * 100))%: \(item.originalName)", part: item.partName, percent: percent)
        }
        PHImageManager.default().requestAVAsset(forVideo: item.asset, options: options) { asset, _, info in
            if let urlAsset = asset as? AVURLAsset, urlAsset.url.isFileURL {
                do {
                    try? FileManager.default.removeItem(at: destination)
                    try FileManager.default.copyItem(at: urlAsset.url, to: destination)
                    AppLogger.shared.log(.info, category: "ICLOUD", "Fallback video copy thành công: \(item.originalName)")
                    finish(nil)
                } catch {
                    finish("Fallback video không copy được: \(error.localizedDescription)")
                }
                return
            }
            guard let asset = asset,
                  let exporter = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetPassthrough) else {
                let error = info?[PHImageErrorKey] as? Error
                finish("Fallback video thất bại: \(error?.localizedDescription ?? "không có AVAsset")")
                return
            }
            try? FileManager.default.removeItem(at: destination)
            exporter.outputURL = destination
            let preferred: AVFileType = destination.pathExtension.lowercased() == "mp4" ? .mp4 : .mov
            exporter.outputFileType = exporter.supportedFileTypes.contains(preferred) ? preferred : exporter.supportedFileTypes.first
            exporter.shouldOptimizeForNetworkUse = false
            exporter.exportAsynchronously {
                if exporter.status == .completed, FileManager.default.fileExists(atPath: destination.path) {
                    AppLogger.shared.log(.info, category: "ICLOUD", "Fallback video export thành công: \(item.originalName)")
                    finish(nil)
                } else {
                    finish("Fallback video export lỗi: \(exporter.error?.localizedDescription ?? "status=\(exporter.status.rawValue)")")
                }
            }
        }
        #endif
    }

    private func deleteVerifiedCameraAssets(_ assets: [PHAsset], completion: @escaping (Int, String?) -> Void) {
        var unique: [String: PHAsset] = [:]
        for asset in assets { unique[asset.localIdentifier] = asset }
        let values = Array(unique.values)
        guard !values.isEmpty else { completion(0, nil); return }
        AppLogger.shared.log(.info, category: "PHOTOS_DELETE", "Chuẩn bị chuyển \(values.count) asset đã xác minh vào Đã xóa gần đây")
        PHPhotoLibrary.shared().performChanges({
            PHAssetChangeRequest.deleteAssets(values as NSArray)
        }) { ok, error in
            if ok {
                AppLogger.shared.log(.info, category: "PHOTOS_DELETE", "Đã chuyển \(values.count) asset vào Đã xóa gần đây")
                completion(values.count, nil)
            } else {
                let detail = error?.localizedDescription ?? "PhotoKit từ chối xóa"
                AppLogger.shared.log(.warning, category: "PHOTOS_DELETE", "Không xóa được asset đã đồng bộ: \(detail)")
                completion(0, detail)
            }
        }
    }

    private func finishCameraBackup(_ context: CameraBackupRunContext, success: Bool, message: String) {
        guard context.finishGate.claim() else { return }
        let paused = isCameraBackupPaused
        let baseMessage = paused ? "Đã tạm dừng" : message

        func finalize(_ finalSuccess: Bool, _ verifiedCount: Int, _ verifiedTotal: Int, _ verifiedMessage: String) {
            let percent = verifiedTotal > 0 ? Int(Double(verifiedCount) / Double(verifiedTotal) * 100) : (finalSuccess ? 100 : 0)
            // Chỉ chuyển khỏi Photos sau khi vòng đối chiếu cuối xác nhận Host đủ file.
            // Mỗi asset trong danh sách này đã nhận phản hồi upload hoàn tất từ
            // Host. Một asset iCloud lỗi không được ngăn việc chuyển các asset
            // thành công khác vào Đã xóa gần đây.
            let assetsToDelete = !paused && context.deleteAfterUpload ? context.deletionAssets() : []
            self.deleteVerifiedCameraAssets(assetsToDelete) { [weak self] deletedCount, deletionError in
                guard let self = self else { return }
                self.isCameraBackupRunning = false
                self.endCameraBackgroundTask()
                var finalMessage = verifiedMessage
                if deletedCount > 0 {
                    finalMessage += " · Đã chuyển \(deletedCount) mục vào Đã xóa gần đây"
                } else if let deletionError = deletionError {
                    finalMessage += " · Không xóa được ảnh: \(deletionError)"
                }
                self.notifyCameraProgress(current: verifiedCount, total: verifiedTotal, filename: finalMessage, part: "", percent: percent)
                AppLogger.shared.log(finalSuccess || paused ? .info : .error, category: "SYNC", "Kết thúc đồng bộ: verified=\(verifiedCount)/\(verifiedTotal); failed=\(context.failedItems.count); deleted=\(deletedCount); message=\(finalMessage)")
                context.completion(finalSuccess || paused, finalMessage)
            }
        }

        guard success && !paused && context.failedItems.isEmpty else {
            finalize(success, context.completedCount, context.totalAssets, baseMessage)
            return
        }

        let verificationParams: [String: Any] = [
            "mediaMode": context.mediaMode.rawValue,
            "storageMode": context.storageMode.rawValue,
            "baseUrl": context.baseUrl,
            "token": context.token,
            "pool": context.pool,
            "customDeviceName": context.deviceFolder
        ]
        getCameraBackupStats(params: verificationParams) { jsonString in
            guard let data = jsonString.data(using: .utf8),
                  let stats = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else {
                finalize(false, context.completedCount, context.totalAssets, "Đã gửi xong nhưng không xác minh được kết quả trên Host")
                return
            }
            let hostVerified = stats["hostVerified"] as? Bool ?? false
            let verifiedTotal = stats["total"] == nil ? context.totalAssets : Int(self.int64Value(stats["total"]))
            let verifiedCount = stats["backed"] == nil ? context.completedCount : Int(self.int64Value(stats["backed"]))
            let pending = stats["pending"] == nil ? max(0, verifiedTotal - verifiedCount) : Int(self.int64Value(stats["pending"]))
            if hostVerified && pending == 0 && verifiedCount == verifiedTotal {
                let label: String
                switch context.mediaMode {
                case .all: label = "ảnh/video"
                case .photos: label = "ảnh"
                case .videos: label = "video"
                }
                finalize(true, verifiedCount, verifiedTotal, "Đã đồng bộ toàn bộ \(verifiedCount)/\(verifiedTotal) \(label)")
            } else {
                let detail = stats["err"] as? String
                let suffix = detail.map { ": \($0)" } ?? ""
                finalize(false, verifiedCount, verifiedTotal, "Còn \(max(0, pending)) mục chưa được xác minh trên Host\(suffix)")
            }
        }
    }

    private func finishCameraBackupBeforeRun(message: String, success: Bool = false, completion: @escaping (Bool, String) -> Void) {
        isCameraBackupRunning = false
        endCameraBackgroundTask()
        completion(success, message)
    }

    #if false
    // Kept only as a migration reference. The 1.5.4 runtime never compiles or
    // executes this semaphore-based producer/consumer implementation.
    private func startCameraBackupLegacy(params: [String: Any], completion: @escaping (Bool, String) -> Void) {
        guard !isCameraBackupRunning else {
            completion(true, "Đang sao lưu")
            return
        }

        PHPhotoLibrary.requestAuthorization(for: .readWrite) { [weak self] status in
            guard let self = self else { return }
            guard status == .authorized || status == .limited else {
                completion(false, "Vui lòng cấp quyền Thư viện ảnh trong Cài đặt iPhone")
                return
            }

            let includeVideos = params["includeVideos"] as? Bool ?? true
            let wifiOnly = params["wifiOnly"] as? Bool ?? true
            let baseUrl = (params["baseUrl"] as? String ?? LocalProxy.shared.baseUrl).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            let token = params["token"] as? String ?? LocalProxy.shared.token
            let pool = (params["pool"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)

            guard !baseUrl.isEmpty else {
                completion(false, "Chưa có địa chỉ máy chủ")
                return
            }
            guard !pool.isEmpty else {
                completion(false, "Không tìm thấy ổ lưu Camera trên máy chủ")
                return
            }
            if wifiOnly && !self.hasWiFiConnection() {
                completion(false, "Chế độ chỉ Wi-Fi đang bật. Hãy kết nối Wi-Fi rồi thử lại")
                return
            }

            self.isCameraBackupRunning = true
            self.isCameraBackupPaused = false
            self.beginCameraBackgroundTask()

            let customDev = (params["customDeviceName"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            let devFolder = self.cameraDeviceFolder(customName: customDev)

            let fetchOptions = PHFetchOptions()
            fetchOptions.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: true)]
            if includeVideos {
                fetchOptions.predicate = NSPredicate(
                    format: "mediaType == %d OR mediaType == %d",
                    PHAssetMediaType.image.rawValue,
                    PHAssetMediaType.video.rawValue
                )
            } else {
                fetchOptions.predicate = NSPredicate(format: "mediaType == %d", PHAssetMediaType.image.rawValue)
            }
            let assets = PHAsset.fetchAssets(with: fetchOptions)

            let stateKey = self.cameraBackupStateKey(baseUrl: baseUrl, pool: pool, deviceFolder: devFolder)
            var backedUpList = UserDefaults.standard.stringArray(forKey: stateKey) ?? []
            var backedUpSet = Set(backedUpList)

            DispatchQueue.global(qos: .userInitiated).async {
                defer { self.endCameraBackgroundTask() }
                let totalAssets = assets.count
                var serverFilePaths = Set<String>()
                let failedCounter = ThreadSafeCounter(0)

                var deepUrlStr = "\(baseUrl)/api/files/deep?path=\(self.safeQueryEncode(devFolder))&camera=1"
                if !pool.isEmpty { deepUrlStr += "&pool=\(self.safeQueryEncode(pool))" }
                guard let deepUrl = URL(string: deepUrlStr) else {
                    self.isCameraBackupRunning = false
                    completion(false, "URL kiểm tra thư mục Camera không hợp lệ")
                    return
                }
                var deepRequest = URLRequest(url: deepUrl, timeoutInterval: 20)
                if !token.isEmpty { deepRequest.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
                let deepResult = self.performCameraRequest(deepRequest, timeout: 25)
                guard deepResult.code == 200 else {
                    self.isCameraBackupRunning = false
                    let detail = self.cameraErrorMessage(deepResult, fallback: "Không đọc được thư mục đích trên Host")
                    self.notifyCameraProgress(current: 0, total: totalAssets, filename: "[Host] \(detail)", part: "", percent: 0)
                    completion(false, detail)
                    return
                }
                if let obj = (try? JSONSerialization.jsonObject(with: deepResult.data)) as? [String: Any],
                   let files = obj["files"] as? [[String: Any]] {
                    for f in files {
                        if let rel = f["rel"] as? String {
                            let normalized = rel.replacingOccurrences(of: "\\", with: "/").trimmingCharacters(in: CharacterSet(charactersIn: "/"))
                            serverFilePaths.insert(normalized.lowercased())
                        }
                    }
                }

                var pendingTasks: [BackupTaskItem] = []
                let counter = ThreadSafeCounter(0)
                var plannedTargetPaths = Set<String>()

                for i in 0..<totalAssets {
                    let asset = assets.object(at: i)

                    let resources = PHAssetResource.assetResources(for: asset)
                    var primaryResource: PHAssetResource? = nil
                    for res in resources {
                        let t = res.type
                        if t == .photo || t == .video || t == .fullSizePhoto || t == .fullSizeVideo {
                            primaryResource = res
                            break
                        }
                    }
                    if primaryResource == nil {
                        primaryResource = resources.first
                    }
                    guard let primary = primaryResource else {
                        continue
                    }

                    var originalName = self.safeCameraFileName(
                        primary.originalFilename,
                        fallbackIndex: i,
                        isVideo: asset.mediaType == .video
                    )

                    let partNum = (i / 200) + 1
                    let partName = "Camera_\(partNum)"
                    let targetFolder = "\(devFolder)/\(partName)"

                    // iOS có thể tạo lại IMG_0001 sau khi reset/import ảnh. Hai
                    // asset trùng tên trong cùng Camera_N phải được đổi tên ổn
                    // định, nếu không file sau sẽ bị hiểu nhầm là đã đồng bộ.
                    var targetPath = "\(partName)/\(originalName)".lowercased()
                    if plannedTargetPaths.contains(targetPath) {
                        let nsName = originalName as NSString
                        let ext = nsName.pathExtension
                        let stem = nsName.deletingPathExtension
                        let stableSuffix = asset.localIdentifier
                            .components(separatedBy: CharacterSet.alphanumerics.inverted)
                            .filter { !$0.isEmpty }
                            .joined()
                            .prefix(10)
                        let suffix = stableSuffix.isEmpty ? String(i + 1) : String(stableSuffix)
                        originalName = ext.isEmpty ? "\(stem)_\(suffix)" : "\(stem)_\(suffix).\(ext)"
                        targetPath = "\(partName)/\(originalName)".lowercased()
                    }
                    var collisionNumber = 2
                    while plannedTargetPaths.contains(targetPath) {
                        let nsName = originalName as NSString
                        let ext = nsName.pathExtension
                        let stem = nsName.deletingPathExtension
                        originalName = ext.isEmpty ? "\(stem)_\(collisionNumber)" : "\(stem)_\(collisionNumber).\(ext)"
                        targetPath = "\(partName)/\(originalName)".lowercased()
                        collisionNumber += 1
                    }
                    plannedTargetPaths.insert(targetPath)

                    if backedUpSet.contains(asset.localIdentifier) && serverFilePaths.contains(targetPath) {
                        _ = counter.increment()
                        continue
                    }

                    // Host không còn file (cài lại Host, đổi ổ hoặc người dùng đã xóa).
                    // Không được tin trạng thái local cũ và bỏ qua asset này.
                    if backedUpSet.contains(asset.localIdentifier) {
                        backedUpSet.remove(asset.localIdentifier)
                    }

                    // /api/files/deep trả đường dẫn tương đối so với devFolder.
                    if serverFilePaths.contains(targetPath) {
                        backedUpSet.insert(asset.localIdentifier)
                        backedUpList = Array(backedUpSet)
                        UserDefaults.standard.set(backedUpList, forKey: stateKey)
                        _ = counter.increment()
                        continue
                    }

                    pendingTasks.append(BackupTaskItem(index: i, asset: asset, originalName: originalName, targetFolder: targetFolder, partName: partName))
                }
                backedUpList = Array(backedUpSet)
                UserDefaults.standard.set(backedUpList, forKey: stateKey)

                guard !pendingTasks.isEmpty else {
                    self.isCameraBackupRunning = false
                    self.notifyCameraProgress(current: totalAssets, total: totalAssets, filename: "Camera đã được sao lưu đầy đủ", part: "", percent: 100)
                    completion(true, "Hoàn tất")
                    return
                }

                var readyQueue: [ReadyTaskItem] = []
                let queueLock = NSLock()
                let itemsAvailable = DispatchSemaphore(value: 0)
                // Chỉ chuẩn bị một asset mỗi lần để không giữ đồng thời nhiều
                // video/Live Photo lớn trong bộ nhớ và thư mục tạm của iOS.
                let bufferSlots = DispatchSemaphore(value: 1)
                var producerDone = false
                var firstUploadError: String? = nil

                // Producer Thread: Prefetches from iCloud into local temp files
                DispatchQueue.global(qos: .userInitiated).async {
                    for item in pendingTasks {
                        if !self.isCameraBackupRunning || self.isCameraBackupPaused { break }
                        var acquiredBufferSlot = false
                        while self.isCameraBackupRunning && !self.isCameraBackupPaused && !acquiredBufferSlot {
                            acquiredBufferSlot = bufferSlots.wait(timeout: .now() + 0.5) == .success
                        }
                        if !acquiredBufferSlot { break }
                        if !self.isCameraBackupRunning || self.isCameraBackupPaused {
                            bufferSlots.signal()
                            break
                        }

                        let resources = PHAssetResource.assetResources(for: item.asset)
                        var primaryResource: PHAssetResource? = nil
                        for res in resources {
                            let t = res.type
                            if t == .photo || t == .video || t == .fullSizePhoto || t == .fullSizeVideo {
                                primaryResource = res
                                break
                            }
                        }
                        if primaryResource == nil {
                            primaryResource = resources.first
                        }
                        guard let primary = primaryResource else {
                            _ = failedCounter.increment()
                            firstUploadError = "\(item.originalName): Không tìm thấy dữ liệu gốc trong Thư viện ảnh"
                            self.notifyCameraProgress(
                                current: counter.get(),
                                total: totalAssets,
                                filename: "[Dừng] Không tìm thấy dữ liệu gốc: \(item.originalName)",
                                part: item.partName,
                                percent: totalAssets > 0 ? Int(Double(item.index + 1) / Double(totalAssets) * 100) : 0
                            )
                            self.isCameraBackupRunning = false
                            bufferSlots.signal()
                            break
                        }

                        let tempFileUrl = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + "_" + item.originalName)

                        let opt = PHAssetResourceRequestOptions()
                        opt.isNetworkAccessAllowed = true
                        opt.progressHandler = { [weak self] progress in
                            let pct = Int(progress * 100)
                            let currentPercent = totalAssets > 0 ? Int(Double(item.index + 1) / Double(totalAssets) * 100) : 0
                            self?.notifyCameraProgress(
                                current: counter.get(),
                                total: totalAssets,
                                filename: "[iCloud] Đang tải từ iCloud (\(pct)%): \(item.originalName)",
                                part: item.partName,
                                percent: currentPercent
                            )
                        }

                        let fetchSema = DispatchSemaphore(value: 0)
                        var fetchSuccess = false

                        PHAssetResourceManager.default().writeData(for: primary, toFile: tempFileUrl, options: opt) { error in
                            if error == nil && FileManager.default.fileExists(atPath: tempFileUrl.path) {
                                fetchSuccess = true
                            }
                            fetchSema.signal()
                        }
                        let waitRes = fetchSema.wait(timeout: .now() + 600)
                        if waitRes == .timedOut {
                            fetchSuccess = false
                        }

                        if fetchSuccess {
                            queueLock.lock()
                            readyQueue.append(ReadyTaskItem(task: item, tempUrl: tempFileUrl))
                            queueLock.unlock()
                            itemsAvailable.signal()
                        } else {
                            try? FileManager.default.removeItem(at: tempFileUrl)
                            _ = failedCounter.increment()
                            firstUploadError = "\(item.originalName): Không đọc được dữ liệu từ Thư viện ảnh/iCloud"
                            self.notifyCameraProgress(
                                current: counter.get(),
                                total: totalAssets,
                                filename: "[Dừng] Không đọc được từ Thư viện/iCloud: \(item.originalName)",
                                part: item.partName,
                                percent: totalAssets > 0 ? Int(Double(item.index + 1) / Double(totalAssets) * 100) : 0
                            )
                            self.isCameraBackupRunning = false
                            bufferSlots.signal()
                            break
                        }
                    }

                    queueLock.lock()
                    producerDone = true
                    queueLock.unlock()
                    itemsAvailable.signal()
                }

                // Consumer Loop: Streams ready items to Host LAN
                while self.isCameraBackupRunning && !self.isCameraBackupPaused {
                    itemsAvailable.wait()

                    var nextItem: ReadyTaskItem? = nil
                    queueLock.lock()
                    if !readyQueue.isEmpty {
                        nextItem = readyQueue.removeFirst()
                    }
                    let isAllDone = producerDone && readyQueue.isEmpty
                    queueLock.unlock()

                    if let ready = nextItem {
                        let currentPercent = totalAssets > 0 ? Int(Double(ready.task.index + 1) / Double(totalAssets) * 100) : 0
                        var uploadOk = false
                        var uploadCode = 0
                        var uploadErr: String? = nil
                        // uploadFileToHost đã tự resume và retry riêng cho init/chunk/complete.
                        // Không lồng thêm một vòng retry cả tệp vì sẽ tạo 9 lần thử và
                        // làm UI chỉ hiện 1/3..3/3 rồi âm thầm bỏ qua.
                        let maxRetries = 1

                        for attempt in 1...maxRetries {
                            if !self.isCameraBackupRunning || self.isCameraBackupPaused { break }

                            let uploadSema = DispatchSemaphore(value: 0)
                            uploadOk = false
                            uploadCode = 0
                            uploadErr = nil

                            self.uploadFileToHost(
                                fileUrl: ready.tempUrl,
                                fileName: ready.task.originalName,
                                targetFolder: ready.task.targetFolder,
                                baseUrl: baseUrl,
                                pool: pool,
                                token: token,
                                onProgress: { [weak self] sentBytes, totalExpected, speedBytes in
                                    guard let self = self else { return }
                                    let speedStr = self.formatSpeed(speedBytes)
                                    let sentStr = self.formatSize(sentBytes)
                                    let totalStr = totalExpected > 0 ? self.formatSize(totalExpected) : ""
                                    let retryPrefix = attempt > 1 ? "[Thử lại \(attempt)/\(maxRetries)] " : ""
                                    let fileProgressStr = totalExpected > 0 ? " (\(sentStr) / \(totalStr) · \(speedStr))" : " (\(sentStr) · \(speedStr))"

                                    self.notifyCameraProgress(
                                        current: counter.get(),
                                        total: totalAssets,
                                        filename: "\(retryPrefix)[Mạng LAN] \(ready.task.originalName)\(fileProgressStr)",
                                        part: ready.task.partName,
                                        percent: currentPercent
                                    )
                                },
                                completion: { ok, code, err in
                                    uploadOk = ok
                                    uploadCode = code
                                    uploadErr = err
                                    uploadSema.signal()
                                }
                            )
                            uploadSema.wait()

                            if uploadOk {
                                break
                            } else if [400, 401, 403, 404].contains(uploadCode) {
                                break
                            } else if attempt < maxRetries && self.isCameraBackupRunning && !self.isCameraBackupPaused {
                                Thread.sleep(forTimeInterval: 0.5)
                            }
                        }

                        try? FileManager.default.removeItem(at: ready.tempUrl)
                        bufferSlots.signal()

                        if uploadOk {
                            backedUpSet.insert(ready.task.asset.localIdentifier)
                            backedUpList = Array(backedUpSet)
                            UserDefaults.standard.set(backedUpList, forKey: stateKey)
                            _ = counter.increment()
                        } else if self.isCameraBackupPaused || !self.isCameraBackupRunning {
                            // Tạm dừng là trạng thái chủ động, không tính tệp hiện tại là lỗi.
                        } else {
                            _ = failedCounter.increment()
                            let errDetail = uploadErr ?? (uploadCode > 0 ? "HTTP \(uploadCode)" : "Mất kết nối máy chủ")
                            firstUploadError = "\(ready.task.originalName): \(errDetail)"
                            self.notifyCameraProgress(
                                current: counter.get(),
                                total: totalAssets,
                                filename: "[Dừng] \(ready.task.originalName): \(errDetail)",
                                part: ready.task.partName,
                                percent: currentPercent
                            )
                            // Giữ asset này ở trạng thái chưa đồng bộ để lần bấm tiếp theo
                            // tiếp tục đúng tệp, không nhảy sang tệp khác.
                            self.isCameraBackupRunning = false
                        }
                    }

                    if isAllDone {
                        break
                    }
                }

                // Clean up remaining temp files if paused or stopped
                queueLock.lock()
                for remaining in readyQueue {
                    try? FileManager.default.removeItem(at: remaining.tempUrl)
                }
                readyQueue.removeAll()
                queueLock.unlock()

                self.isCameraBackupRunning = false
                let finalCount = counter.get()
                let failedCount = failedCounter.get()
                let finalMsg: String
                if self.isCameraBackupPaused {
                    finalMsg = "Đã tạm dừng"
                } else if failedCount > 0 {
                    finalMsg = "Không thể đồng bộ: \(firstUploadError ?? "Host từ chối tệp")"
                } else {
                    finalMsg = "Hoàn tất sao lưu"
                }
                self.notifyCameraProgress(current: finalCount, total: totalAssets, filename: finalMsg, part: "", percent: totalAssets > 0 ? Int(Double(finalCount) / Double(totalAssets) * 100) : 100)
                completion(failedCount == 0 || self.isCameraBackupPaused, finalMsg)
            }
        }
    }

    #endif

    private func pauseCameraBackup() {
        // Giữ running=true cho đến khi callback PhotoKit/URLSession hiện tại
        // quay về và finishCameraBackup dọn xong context. Nhờ vậy người dùng
        // không thể khởi chạy một phiên mới chồng lên phiên đang hủy.
        isCameraBackupPaused = true
        cancelActiveCameraNetworkTask()
        endCameraBackgroundTask()
    }

    private func safeQueryEncode(_ str: String) -> String {
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "+&=")
        return str.addingPercentEncoding(withAllowedCharacters: allowed) ?? str
    }

    private func formatSpeed(_ bytesPerSec: Int64) -> String {
        if bytesPerSec >= 1024 * 1024 {
            return String(format: "%.1f MB/s", Double(bytesPerSec) / 1048576.0)
        } else if bytesPerSec >= 1024 {
            return String(format: "%.0f KB/s", Double(bytesPerSec) / 1024.0)
        } else {
            return "\(bytesPerSec) B/s"
        }
    }

    private func formatSize(_ bytes: Int64) -> String {
        if bytes >= 1024 * 1024 * 1024 {
            return String(format: "%.2f GB", Double(bytes) / 1073741824.0)
        } else if bytes >= 1024 * 1024 {
            return String(format: "%.1f MB", Double(bytes) / 1048576.0)
        } else if bytes >= 1024 {
            return String(format: "%.0f KB", Double(bytes) / 1024.0)
        } else {
            return "\(bytes) B"
        }
    }

    private func notifyCameraProgress(current: Int, total: Int, filename: String, part: String, percent: Int) {
        DispatchQueue.main.async { [weak self] in
            let args: [Any] = [current, total, filename, part, percent]
            let json = self?.jsonString(args) ?? "[]"
            let js = "window.DC && DC._onCameraProgress && DC._onCameraProgress.apply(null, \(json));"
            self?.webView?.evaluateJavaScript(js, completionHandler: nil)
        }
    }

    private func uploadCameraFileAsync(
        fileUrl: URL,
        fileName: String,
        targetFolder: String,
        baseUrl: String,
        pool: String,
        token: String,
        onProgress: @escaping (Int64, Int64, Int64) -> Void,
        completion: @escaping (Bool, Int, String?) -> Void
    ) {
        guard FileManager.default.fileExists(atPath: fileUrl.path),
              let attributes = try? FileManager.default.attributesOfItem(atPath: fileUrl.path),
              let fileNumber = attributes[.size] as? NSNumber else {
            completion(false, 0, "Không đọc được tệp tạm")
            return
        }
        let context = CameraFileUploadContext(
            fileUrl: fileUrl,
            fileName: fileName,
            targetFolder: targetFolder,
            baseUrl: baseUrl,
            pool: pool,
            token: token,
            totalSize: fileNumber.int64Value,
            onProgress: onProgress,
            completion: completion
        )
        AppLogger.shared.log(.info, category: "SYNC_HTTP", "Khởi tạo upload \(targetFolder)/\(fileName); size=\(fileNumber.int64Value); pool=\(pool)")
        attemptCameraUploadInit(context, attempt: 1)
    }

    private func attemptCameraUploadInit(_ context: CameraFileUploadContext, attempt: Int) {
        guard isCameraBackupRunning && !isCameraBackupPaused else {
            context.finish(false, 0, "Đã tạm dừng")
            return
        }
        guard let url = URL(string: "\(context.baseUrl)/api/upload/init") else {
            context.finish(false, 0, "URL khởi tạo upload không hợp lệ")
            return
        }
        var payload: [String: Any] = [
            "path": "\(context.targetFolder)/\(context.fileName)",
            "size": context.totalSize
        ]
        if !context.pool.isEmpty { payload["pool"] = context.pool }

        var request = URLRequest(url: url, timeoutInterval: 30)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if !context.token.isEmpty { request.setValue("Bearer \(context.token)", forHTTPHeaderField: "Authorization") }
        request.httpBody = try? JSONSerialization.data(withJSONObject: payload)

        performCameraRequestAsync(request, timeout: 35) { [weak self] result in
            guard let self = self else { return }
            guard self.isCameraBackupRunning && !self.isCameraBackupPaused else {
                context.finish(false, 0, "Đã tạm dừng")
                return
            }
            if result.code == 200,
               let object = (try? JSONSerialization.jsonObject(with: result.data)) as? [String: Any],
               let uploadId = object["uploadId"] as? String,
               !uploadId.isEmpty {
                context.uploadId = uploadId
                context.currentOffset = min(max(0, self.int64Value(object["offset"])), context.totalSize)
                context.startedOffset = context.currentOffset
                context.startedAt = Date()
                AppLogger.shared.log(.info, category: "SYNC_HTTP", "Upload init OK \(context.fileName); offset=\(context.currentOffset); attempt=\(attempt)")
                self.sendNextCameraUploadChunk(context)
                return
            }

            let error = self.cameraErrorMessage(result, fallback: "Không khởi tạo được upload")
            AppLogger.shared.log(.warning, category: "SYNC_HTTP", "Upload init lỗi \(context.fileName); HTTP=\(result.code); attempt=\(attempt): \(error)")
            if attempt < largeTransferAttempts && ![400, 401, 403, 404].contains(result.code) {
                DispatchQueue.global(qos: .userInitiated).asyncAfter(deadline: .now() + min(8.0, 0.5 * pow(2.0, Double(attempt - 1)))) { [weak self] in
                    guard let self = self else { return }
                    self.attemptCameraUploadInit(context, attempt: attempt + 1)
                }
            } else {
                context.finish(false, result.code, error)
            }
        }
    }

    private func sendNextCameraUploadChunk(_ context: CameraFileUploadContext) {
        guard isCameraBackupRunning && !isCameraBackupPaused else {
            context.finish(false, 0, "Đã tạm dừng")
            return
        }
        guard context.currentOffset < context.totalSize else {
            attemptCameraUploadComplete(context, attempt: 1)
            return
        }

        // 4 MiB keeps resume granularity while reducing HTTP/file-handle churn
        // by 16x versus the old 256 KiB chunks. This is important for long
        // iCloud videos and prevents Host CPU/RAM pressure on sustained LAN.
        let chunkSize: Int64 = 4 * 1024 * 1024
        let wanted = min(chunkSize, context.totalSize - context.currentOffset)
        let chunk: Data
        do {
            let handle = try FileHandle(forReadingFrom: context.fileUrl)
            defer { try? handle.close() }
            try handle.seek(toOffset: UInt64(context.currentOffset))
            chunk = handle.readData(ofLength: Int(wanted))
        } catch {
            context.finish(false, 0, error.localizedDescription)
            return
        }
        guard !chunk.isEmpty else {
            context.finish(false, 0, "Không đọc được dữ liệu tại vị trí \(context.currentOffset)")
            return
        }
        attemptCameraUploadChunk(context, chunk: chunk, attempt: 1)
    }

    private func attemptCameraUploadChunk(_ context: CameraFileUploadContext, chunk: Data, attempt: Int) {
        guard isCameraBackupRunning && !isCameraBackupPaused else {
            context.finish(false, 0, "Đã tạm dừng")
            return
        }
        let offsetAtRequest = context.currentOffset
        let urlString = "\(context.baseUrl)/api/upload/chunk?id=\(safeQueryEncode(context.uploadId))&offset=\(offsetAtRequest)"
        guard let url = URL(string: urlString) else {
            context.finish(false, 0, "URL gửi dữ liệu không hợp lệ")
            return
        }
        var request = URLRequest(url: url, timeoutInterval: 180)
        request.httpMethod = "POST"
        request.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
        request.setValue("camera-backup", forHTTPHeaderField: "X-CW-Part")
        if !context.token.isEmpty { request.setValue("Bearer \(context.token)", forHTTPHeaderField: "Authorization") }
        request.httpBody = chunk

        performCameraRequestAsync(request, timeout: 200) { [weak self] result in
            guard let self = self else { return }
            guard self.isCameraBackupRunning && !self.isCameraBackupPaused else {
                context.finish(false, 0, "Đã tạm dừng")
                return
            }
            if result.code == 200 {
                var serverOffset: Int64 = 0
                if let object = (try? JSONSerialization.jsonObject(with: result.data)) as? [String: Any] {
                    serverOffset = self.int64Value(object["offset"])
                }
                context.currentOffset = serverOffset > offsetAtRequest
                    ? min(serverOffset, context.totalSize)
                    : min(offsetAtRequest + Int64(chunk.count), context.totalSize)
                let elapsed = max(Date().timeIntervalSince(context.startedAt), 0.001)
                let sentThisRun = max(0, context.currentOffset - context.startedOffset)
                context.onProgress(context.currentOffset, context.totalSize, Int64(Double(sentThisRun) / elapsed))
                self.sendNextCameraUploadChunk(context)
                return
            }

            if result.code == 409,
               let object = (try? JSONSerialization.jsonObject(with: result.data)) as? [String: Any] {
                let serverOffset = self.int64Value(object["serverOffset"])
                if serverOffset >= 0 && serverOffset <= context.totalSize {
                    context.currentOffset = serverOffset
                    self.sendNextCameraUploadChunk(context)
                    return
                }
            }

            let error = self.cameraErrorMessage(result, fallback: "Gửi khối dữ liệu thất bại")
            AppLogger.shared.log(.warning, category: "SYNC_HTTP", "Upload chunk lỗi \(context.fileName); HTTP=\(result.code); offset=\(offsetAtRequest); attempt=\(attempt): \(error)")
            if result.code == 404 || result.code == 410 {
                self.recoverCameraUploadSession(context, phase: "gửi dữ liệu", error: error)
                return
            }
            if attempt < largeTransferAttempts && ![400, 401, 403, 404].contains(result.code) {
                DispatchQueue.global(qos: .userInitiated).asyncAfter(deadline: .now() + min(8.0, 0.5 * pow(2.0, Double(attempt - 1)))) { [weak self] in
                    guard let self = self else { return }
                    self.attemptCameraUploadChunk(context, chunk: chunk, attempt: attempt + 1)
                }
            } else {
                context.finish(false, result.code, error)
            }
        }
    }

    private func attemptCameraUploadComplete(_ context: CameraFileUploadContext, attempt: Int) {
        guard isCameraBackupRunning && !isCameraBackupPaused else {
            context.finish(false, 0, "Đã tạm dừng")
            return
        }
        guard let url = URL(string: "\(context.baseUrl)/api/upload/complete") else {
            context.finish(false, 0, "URL hoàn tất upload không hợp lệ")
            return
        }
        var request = URLRequest(url: url, timeoutInterval: 30)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if !context.token.isEmpty { request.setValue("Bearer \(context.token)", forHTTPHeaderField: "Authorization") }
        request.httpBody = try? JSONSerialization.data(withJSONObject: ["uploadId": context.uploadId])

        performCameraRequestAsync(request, timeout: 35) { [weak self] result in
            guard let self = self else { return }
            guard self.isCameraBackupRunning && !self.isCameraBackupPaused else {
                context.finish(false, 0, "Đã tạm dừng")
                return
            }
            if result.code == 200 || result.code == 201 {
                context.onProgress(context.totalSize, context.totalSize, 0)
                context.finish(true, result.code, nil)
                return
            }

            if result.code == 409,
               let object = (try? JSONSerialization.jsonObject(with: result.data)) as? [String: Any] {
                let serverOffset = self.int64Value(object["serverOffset"])
                if serverOffset >= 0 && serverOffset <= context.totalSize {
                    context.currentOffset = serverOffset
                    self.sendNextCameraUploadChunk(context)
                    return
                }
            }
            let error = self.cameraErrorMessage(result, fallback: "Hoàn tất upload thất bại")
            AppLogger.shared.log(.warning, category: "SYNC_HTTP", "Upload complete lỗi \(context.fileName); HTTP=\(result.code); attempt=\(attempt): \(error)")
            if result.code == 404 || result.code == 410 {
                self.recoverCameraUploadSession(context, phase: "hoàn tất", error: error)
                return
            }
            if attempt < largeTransferAttempts && ![400, 401, 403, 404].contains(result.code) {
                DispatchQueue.global(qos: .userInitiated).asyncAfter(deadline: .now() + min(8.0, 0.5 * pow(2.0, Double(attempt - 1)))) { [weak self] in
                    guard let self = self else { return }
                    self.attemptCameraUploadComplete(context, attempt: attempt + 1)
                }
            } else {
                context.finish(false, result.code, error)
            }
        }
    }

    private func recoverCameraUploadSession(_ context: CameraFileUploadContext, phase: String, error: String) {
        guard isCameraBackupRunning && !isCameraBackupPaused else {
            context.finish(false, 0, "Đã tạm dừng")
            return
        }
        guard context.sessionRecoveryCount < context.maximumSessionRecoveries else {
            AppLogger.shared.log(.error, category: "SYNC_HTTP", "Không thể khôi phục phiên upload \(context.fileName) sau \(context.sessionRecoveryCount) lần: \(error)")
            context.finish(false, 404, "Phiên upload liên tục bị mất. Hãy kiểm tra hoặc cập nhật Host rồi thử lại.")
            return
        }

        context.sessionRecoveryCount += 1
        let oldUploadId = context.uploadId
        let oldOffset = context.currentOffset
        context.uploadId = ""
        AppLogger.shared.log(.warning, category: "SYNC_HTTP", "Khôi phục phiên upload \(context.fileName) ở bước \(phase); lần=\(context.sessionRecoveryCount)/\(context.maximumSessionRecoveries); uploadId=\(oldUploadId); offset=\(oldOffset)")

        DispatchQueue.global(qos: .userInitiated).asyncAfter(deadline: .now() + 0.75) { [weak self] in
            guard let self = self else { return }
            self.attemptCameraUploadInit(context, attempt: 1)
        }
    }

    private func performCameraRequestAsync(_ request: URLRequest, timeout: TimeInterval, completion: @escaping (CameraHTTPResult) -> Void) {
        var timedRequest = request
        timedRequest.timeoutInterval = timeout
        let taskBox = WeakURLSessionTaskBox()
        let task = URLSession.shared.dataTask(with: timedRequest) { [weak self] data, response, error in
            if let finishedTask = taskBox.task {
                self?.clearActiveCameraNetworkTask(finishedTask)
            }
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            if let error = error {
                AppLogger.shared.log(.warning, category: "SYNC_HTTP", "\(timedRequest.httpMethod ?? "GET") \(timedRequest.url?.path ?? "") lỗi mạng: \(error.localizedDescription)")
            }
            completion(CameraHTTPResult(
                code: status,
                data: data ?? Data(),
                error: error?.localizedDescription
            ))
        }
        taskBox.task = task
        setActiveCameraNetworkTask(task)
        task.resume()
    }

    #if false
    private func uploadFileToHost(
        fileUrl: URL,
        fileName: String,
        targetFolder: String,
        baseUrl: String,
        pool: String,
        token: String,
        onProgress: @escaping (Int64, Int64, Int64) -> Void,
        completion: @escaping (Bool, Int, String?) -> Void
    ) {
        guard FileManager.default.fileExists(atPath: fileUrl.path) else {
            completion(false, 0, "Tệp tạm không tồn tại")
            return
        }

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else {
                completion(false, 0, "Tác vụ đã kết thúc")
                return
            }

            do {
                let attrs = try FileManager.default.attributesOfItem(atPath: fileUrl.path)
                guard let fileNumber = attrs[.size] as? NSNumber else {
                    completion(false, 0, "Không đọc được kích thước tệp")
                    return
                }
                let totalSize = fileNumber.int64Value
                let fullRelPath = "\(targetFolder)/\(fileName)"
                let targetPool = pool.trimmingCharacters(in: .whitespacesAndNewlines)

                var initPayload: [String: Any] = ["path": fullRelPath, "size": totalSize]
                if !targetPool.isEmpty { initPayload["pool"] = targetPool }

                guard let initURL = URL(string: "\(baseUrl)/api/upload/init") else {
                    completion(false, 0, "URL khởi tạo upload không hợp lệ")
                    return
                }

                var serverUploadId = ""
                var currentOffset: Int64 = 0
                var lastCode = 0
                var lastError = "Không khởi tạo được upload"

                for _ in 1...3 {
                    if !self.isCameraBackupRunning || self.isCameraBackupPaused {
                        completion(false, 0, "Đã tạm dừng")
                        return
                    }

                    var request = URLRequest(url: initURL, timeoutInterval: 30)
                    request.httpMethod = "POST"
                    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                    if !token.isEmpty { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
                    request.httpBody = try JSONSerialization.data(withJSONObject: initPayload)

                    let result = self.performCameraRequest(request, timeout: 35)
                    lastCode = result.code
                    if result.code == 200,
                       let object = try? JSONSerialization.jsonObject(with: result.data) as? [String: Any],
                       let uploadId = object["uploadId"] as? String,
                       !uploadId.isEmpty {
                        serverUploadId = uploadId
                        currentOffset = min(max(0, self.int64Value(object["offset"])), totalSize)
                        break
                    }

                    lastError = self.cameraErrorMessage(result, fallback: "Không khởi tạo được upload")
                    if [400, 401, 403, 404].contains(result.code) { break }
                    Thread.sleep(forTimeInterval: 0.5)
                }

                guard !serverUploadId.isEmpty else {
                    completion(false, lastCode, lastError)
                    return
                }

                let fileHandle = try FileHandle(forReadingFrom: fileUrl)
                defer { try? fileHandle.close() }
                // 512 KiB giữ đỉnh RAM thấp hơn trên các iPhone cũ trong khi
                // vẫn đủ lớn để upload LAN hiệu quả.
                let chunkSize = 512 * 1024
                let startedOffset = currentOffset
                let startedAt = Date()

                uploadLoop: while currentOffset < totalSize {
                    if !self.isCameraBackupRunning || self.isCameraBackupPaused {
                        completion(false, 0, "Đã tạm dừng")
                        return
                    }

                    try fileHandle.seek(toOffset: UInt64(currentOffset))
                    let wanted = min(Int64(chunkSize), totalSize - currentOffset)
                    let chunk = fileHandle.readData(ofLength: Int(wanted))
                    guard !chunk.isEmpty else {
                        completion(false, 0, "Không đọc được dữ liệu tại vị trí \(currentOffset)")
                        return
                    }

                    var chunkSent = false
                    var shouldReloadOffset = false
                    for attempt in 1...3 {
                        if !self.isCameraBackupRunning || self.isCameraBackupPaused {
                            completion(false, 0, "Đã tạm dừng")
                            return
                        }
                        let chunkURLString = "\(baseUrl)/api/upload/chunk?id=\(self.safeQueryEncode(serverUploadId))&offset=\(currentOffset)"
                        guard let chunkURL = URL(string: chunkURLString) else {
                            completion(false, 0, "URL gửi dữ liệu không hợp lệ")
                            return
                        }

                        var request = URLRequest(url: chunkURL, timeoutInterval: 60)
                        request.httpMethod = "POST"
                        request.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
                        if !token.isEmpty { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
                        request.httpBody = chunk

                        let result = self.performCameraRequest(request, timeout: 70)
                        lastCode = result.code
                        if result.code == 200,
                           let object = try? JSONSerialization.jsonObject(with: result.data) as? [String: Any] {
                            let serverOffset = self.int64Value(object["offset"])
                            currentOffset = serverOffset > currentOffset ? min(serverOffset, totalSize) : min(currentOffset + Int64(chunk.count), totalSize)
                            chunkSent = true
                            break
                        }

                        if result.code == 409,
                           let object = try? JSONSerialization.jsonObject(with: result.data) as? [String: Any] {
                            let serverOffset = self.int64Value(object["serverOffset"])
                            if serverOffset >= 0 && serverOffset <= totalSize {
                                currentOffset = serverOffset
                                shouldReloadOffset = true
                                break
                            }
                        }

                        lastError = self.cameraErrorMessage(result, fallback: "Gửi khối dữ liệu thất bại")
                        if [400, 401, 403, 404].contains(result.code) { break }
                        if attempt < 3 { Thread.sleep(forTimeInterval: 0.5) }
                    }

                    if shouldReloadOffset { continue uploadLoop }
                    guard chunkSent else {
                        completion(false, lastCode, lastError)
                        return
                    }

                    let elapsed = max(Date().timeIntervalSince(startedAt), 0.001)
                    let sentThisRun = max(0, currentOffset - startedOffset)
                    let speed = Int64(Double(sentThisRun) / elapsed)
                    onProgress(currentOffset, totalSize, speed)
                }

                guard let completeURL = URL(string: "\(baseUrl)/api/upload/complete") else {
                    completion(false, 0, "URL hoàn tất upload không hợp lệ")
                    return
                }

                for attempt in 1...3 {
                    if !self.isCameraBackupRunning || self.isCameraBackupPaused {
                        completion(false, 0, "Đã tạm dừng")
                        return
                    }
                    var request = URLRequest(url: completeURL, timeoutInterval: 30)
                    request.httpMethod = "POST"
                    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                    if !token.isEmpty { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
                    request.httpBody = try JSONSerialization.data(withJSONObject: ["uploadId": serverUploadId])

                    let result = self.performCameraRequest(request, timeout: 35)
                    lastCode = result.code
                    if result.code == 200 || result.code == 201 {
                        onProgress(totalSize, totalSize, 0)
                        completion(true, result.code, nil)
                        return
                    }

                    lastError = self.cameraErrorMessage(result, fallback: "Hoàn tất upload thất bại")
                    if [400, 401, 403, 404].contains(result.code) { break }
                    if attempt < 3 { Thread.sleep(forTimeInterval: 0.5) }
                }

                completion(false, lastCode, lastError)
            } catch {
                completion(false, 0, error.localizedDescription)
            }
        }
    }

    private func performCameraRequest(_ request: URLRequest, timeout: TimeInterval) -> CameraHTTPResult {
        let semaphore = DispatchSemaphore(value: 0)
        let resultLock = NSLock()
        var responseCode = 0
        var responseData = Data()
        var responseError: String?

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            resultLock.lock()
            responseCode = (response as? HTTPURLResponse)?.statusCode ?? 0
            responseData = data ?? Data()
            responseError = error?.localizedDescription
            resultLock.unlock()
            semaphore.signal()
        }

        setActiveCameraNetworkTask(task)
        task.resume()

        if semaphore.wait(timeout: .now() + timeout) == .timedOut {
            task.cancel()
            _ = semaphore.wait(timeout: .now() + 5)
            clearActiveCameraNetworkTask(task)
            return CameraHTTPResult(code: 0, data: Data(), error: "Quá thời gian chờ (\(Int(timeout))s)")
        }

        clearActiveCameraNetworkTask(task)
        resultLock.lock()
        let result = CameraHTTPResult(code: responseCode, data: responseData, error: responseError)
        resultLock.unlock()
        return result
    }
    #endif

    private func setActiveCameraNetworkTask(_ task: URLSessionTask) {
        cameraNetworkTaskLock.lock()
        activeCameraNetworkTask = task
        cameraNetworkTaskLock.unlock()
    }

    private func clearActiveCameraNetworkTask(_ task: URLSessionTask) {
        cameraNetworkTaskLock.lock()
        if activeCameraNetworkTask === task { activeCameraNetworkTask = nil }
        cameraNetworkTaskLock.unlock()
    }

    private func cancelActiveCameraNetworkTask() {
        cameraNetworkTaskLock.lock()
        let task = activeCameraNetworkTask
        activeCameraNetworkTask = nil
        cameraNetworkTaskLock.unlock()
        task?.cancel()
    }

    private func int64Value(_ value: Any?) -> Int64 {
        if let number = value as? NSNumber { return number.int64Value }
        if let value = value as? Int64 { return value }
        if let value = value as? Int { return Int64(value) }
        if let value = value as? String, let number = Int64(value) { return number }
        return 0
    }

    private func cameraErrorMessage(_ result: CameraHTTPResult, fallback: String) -> String {
        if !result.data.isEmpty,
           let object = try? JSONSerialization.jsonObject(with: result.data) as? [String: Any],
           let message = object["error"] as? String,
           !message.isEmpty {
            return message
        }
        if let error = result.error, !error.isEmpty { return error }
        if result.code > 0 { return "HTTP \(result.code): \(fallback)" }
        return fallback
    }
}
