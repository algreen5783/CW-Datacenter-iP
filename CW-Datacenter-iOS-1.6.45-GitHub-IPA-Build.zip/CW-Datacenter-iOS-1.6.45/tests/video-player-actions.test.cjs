const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const player = fs.readFileSync(path.join(root, 'CWDatacenter', 'ViewControllers', 'PlayerViewController.swift'), 'utf8');
const main = fs.readFileSync(path.join(root, 'CWDatacenter', 'ViewControllers', 'MainViewController.swift'), 'utf8');
const web = fs.readFileSync(path.join(root, 'CWDatacenter', 'Resources', 'Web', 'app.js'), 'utf8');

test('video toolbar contains only the four requested actions', () => {
  assert.match(player, /UIStackView\(arrangedSubviews: \[downloadBtn, favoriteBtn, shareBtn, deleteBtn\]\)/);
  assert.match(player, /title: "Tải về", symbol: "arrow\.down\.to\.line"/);
  assert.match(player, /title: "Yêu thích", symbol: isFavorite \? "heart\.fill" : "heart"/);
  assert.match(player, /title: "Chia sẻ", symbol: "square\.and\.arrow\.up"/);
  assert.match(player, /title: "Xóa", symbol: "trash"/);
  for (const oldButton of ['lockBtn', 'speedBtn', 'subtitleBtn', 'aspectBtn', 'playlistBtn']) {
    assert.doesNotMatch(player, new RegExp(`configureToolButton\\(${oldButton}`));
  }
});

test('video transport uses one tappable play-pause-replay control without seek buttons', () => {
  assert.doesNotMatch(player, /gobackward\.10/);
  assert.doesNotMatch(player, /goforward\.10/);
  assert.doesNotMatch(player, /onRewindTapped/);
  assert.doesNotMatch(player, /onForwardTapped/);
  assert.match(player, /playPauseBtn\.isUserInteractionEnabled = true/);
  assert.match(player, /isDescendant\(of: playPauseBtn\)/);
  assert.match(player, /AVPlayerItemDidPlayToEndTime/);
  assert.match(player, /hasReachedEnd \? "arrow\.counterclockwise\.circle\.fill"/);
  assert.match(player, /p\.seek\(to: \.zero/);
});

test('horizontal swipes change adjacent videos like the image viewer', () => {
  assert.match(player, /UISwipeGestureRecognizer\(target: self, action: #selector\(onSwipeLeft\)\)/);
  assert.match(player, /UISwipeGestureRecognizer\(target: self, action: #selector\(onSwipeRight\)\)/);
  assert.match(player, /onSwipeLeft[\s\S]*moveToAdjacentVideo\(offset: 1\)/);
  assert.match(player, /onSwipeRight[\s\S]*moveToAdjacentVideo\(offset: -1\)/);
  assert.match(player, /currentPlaylistIndex = index/);
  assert.doesNotMatch(player, /UIPanGestureRecognizer/);
  assert.doesNotMatch(player, /UIScreen\.main\.brightness/);
  assert.doesNotMatch(player, /panMode|initialSeekPos/);
});

test('player actions are wired to native storage, favorites, share sheet and host delete', () => {
  assert.match(player, /var onDownload:/);
  assert.match(player, /var onFavorite:/);
  assert.match(player, /var onPrepareShare:/);
  assert.match(player, /var onDelete:/);
  assert.match(player, /UIActivityViewController\(activityItems: \[localUrl\]/);
  assert.match(player, /title: "Xóa video\?"/);
  assert.match(main, /playerVc\.onDownload =/);
  assert.match(main, /playerVc\.onFavorite =/);
  assert.match(main, /playerVc\.onPrepareShare =/);
  assert.match(main, /playerVc\.onDelete =/);
  assert.match(main, /request\.httpMethod = "DELETE"/);
  assert.match(main, /runResumableDownload\(/);
});

test('favorites and deletion synchronize back to the web UI', () => {
  assert.match(web, /window\.CWVideoFavoriteToggle = function/);
  assert.match(web, /window\.CWVideoDeleted = function/);
  assert.match(web, /favorite: favs\.some/);
  assert.match(web, /kvSet\(kFavs\(\), favs\)/);
  assert.match(player, /if !wasDeleted \{ saveCurrentPosition\(\) \}/);
});

test('player download is committed to Photos and registered in Transfers', () => {
  assert.match(main, /PHPhotoLibrary\.authorizationStatus\(for: \.addOnly\)/);
  assert.match(main, /creationRequestForAssetFromVideo\(atFileURL: fileUrl\)/);
  assert.match(main, /Đã lưu video vào ứng dụng Ảnh/);
  assert.match(main, /"origin": "videoPlayer"/);
  assert.match(main, /emitCompletion: forSharing/);
  assert.match(web, /ev\.origin === 'videoPlayer'/);
  assert.match(web, /photoLibrary: true/);
  assert.match(web, /Đã lưu vào ứng dụng Ảnh/);
});
