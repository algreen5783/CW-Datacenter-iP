# Cách đưa bản 1.5.0 lên GitHub

1. Xóa workflow cũ có bước `Extract Source Zip`, hoặc thay toàn bộ repository thử nghiệm bằng nội dung gói này.
2. Giải nén `CW-Datacenter-iOS-1.5.0-GitHub-Repo-Ready.zip` trên Windows.
3. Đưa cả hai thư mục `.github` và `ios` lên thư mục gốc của repository.
4. GitHub phải nhìn thấy:
   - `.github/workflows/build-ios.yml`
   - `ios/CWDatacenter.xcodeproj/project.pbxproj`
   - `ios/CWDatacenter/Info.plist`
5. Mở **Actions** > **Build CW Datacenter iOS 1.5.0 IPA** > **Run workflow**.
6. Tải artifact `CW-Datacenter-iOS-1.5.0-unsigned`.

Workflow mới không còn bước tìm ZIP hoặc `ls ios` trước khi source được giải nén. Source iOS nằm sẵn đúng trong thư mục `ios/`.
