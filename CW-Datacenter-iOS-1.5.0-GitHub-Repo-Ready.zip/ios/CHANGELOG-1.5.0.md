# CW Datacenter iOS 1.5.0

## Giao diện

- Dựng lại toàn bộ Web UI iOS từ giao diện Android Mobile hiện tại: màn hình tìm Host, đăng nhập, Tệp, Truyền tải, Yêu thích, Đồng bộ và Thùng rác.
- Chỉ sao chép giao diện làm nguồn tham chiếu; không sửa source Android Mobile, Tablet hoặc TV.
- Cố định kích thước SVG, viewport, vùng cuộn và safe-area cho WKWebView để tránh icon phóng lớn, nội dung đè nhau hoặc nhiều màn hình cùng hiện.
- Khi đăng nhập xong, mở tab Tệp ở ổ “Thiết bị này”.

## Đồng bộ thư viện iOS

- Dùng PhotoKit với quyền `.readWrite` để đọc cả ảnh và video trong thư viện iOS.
- Lấy dữ liệu gốc bằng `PHAssetResourceManager`, bao gồm ảnh/video nằm trong iCloud khi thiết bị cho phép tải về.
- Đối chiếu danh sách tệp thực tế trên Host trước khi bỏ qua một asset đã ghi nhận ở máy.
- Chia đích thành `Camera_1`, `Camera_2`, ... tối đa 200 tệp/thư mục.
- Upload theo từng khối 1 MiB qua `/api/upload/init`, `/api/upload/chunk`, `/api/upload/complete`, hỗ trợ tiếp tục offset và báo đúng lỗi Host.
- Không bỏ qua âm thầm file lỗi; tiến độ, file hiện tại, số đã đồng bộ và số đang chờ được đưa lên giao diện.
- Tự đồng bộ sau khi đăng nhập và kiểm tra lại mỗi 30 giây khi tính năng đang bật; có nút dừng.

## Phiên bản

- Marketing version: `1.5.0`
- Build: `10500`
- Web/native asset marker: `1.5.0`

Host hiện tại đã có đủ API cần thiết, vì vậy bản này không sửa app Host.
