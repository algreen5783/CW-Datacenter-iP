# CW Datacenter iOS 1.6.62

## Sửa lỗi & Nâng cấp

- **Sắp xếp ảnh theo ngày chụp gốc**: Tab Tổng quan (Photos) ưu tiên sắp xếp và gom nhóm theo ngày chụp gốc (`captureDate`), chỉ sử dụng ngày chỉnh sửa nếu tệp không có thông tin ngày chụp gốc.
- **Đổi thứ tự hiển thị thông tin ảnh**: Đưa "Ngày chụp gốc" lên trước "Ngày chỉnh sửa" trong popup thông tin chi tiết.
- **Thống nhất định dạng ngày giờ**: Định dạng chuẩn `dd/MM/yyyy HH:mm:ss` cho cả ngày chụp gốc và ngày chỉnh sửa.
- **Cập nhật phiên bản**: Đồng bộ lên phiên bản 1.6.62 (build 10662).
