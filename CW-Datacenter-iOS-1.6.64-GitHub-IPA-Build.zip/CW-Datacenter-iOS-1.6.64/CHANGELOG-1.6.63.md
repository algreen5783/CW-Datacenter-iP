# CW Datacenter iOS 1.6.63

## Sửa lỗi & Nâng cấp

- **Đổi tên tab Tổng quan thành Photos**: Đổi nhãn tab thành **Photos** và cập nhật biểu tượng icon hình ảnh (`#i-image`) đồng bộ với giao diện Android Mobile.
- **Sắp xếp ảnh theo ngày chụp gốc chuẩn xác**: Đồng bộ với Windows Host 1.5.56, tab Photos ưu tiên sắp xếp và gom nhóm theo ngày chụp gốc thực tế (`captureDate` / EXIF `DateTimeOriginal`), chỉ fallback về ngày chỉnh sửa (`mtime`) khi tệp không có dữ liệu ngày chụp.
- **Thống nhất popup thông tin ảnh**: Đưa "Ngày chụp gốc" lên trước "Ngày chỉnh sửa", đổi nhãn thành "Ngày chỉnh sửa", thống nhất định dạng hiển thị `dd/MM/yyyy HH:mm:ss`, đồng thời hỗ trợ đầy đủ kích thước ảnh (`width × height px`) và vị trí GPS ở cả ngoài danh sách chọn lẫn trong trình xem ảnh native.
- **Cập nhật phiên bản & build**: Nâng lên phiên bản **1.6.63** (build **10663**).
