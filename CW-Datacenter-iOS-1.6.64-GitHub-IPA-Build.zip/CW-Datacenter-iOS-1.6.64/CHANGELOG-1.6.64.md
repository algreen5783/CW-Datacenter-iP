# CW Datacenter iOS 1.6.64

## Bản sửa lỗi trọng yếu (Hotfix)

### 1. Khắc phục lỗi popup Thông tin (`fmtDuration is not defined`)
- **Nguyên nhân gốc rễ**: Hàm `openItemInfoSheet` trong `app.js` gọi hàm `fmtDuration` để định dạng thời lượng nhưng hàm này chưa được khai báo ở Client.
- **Khắc phục**:
  - Định nghĩa đầy đủ hàm chuẩn `fmtDuration(d)` hỗ trợ chuyển đổi giây/mili-giây sang định dạng `phút:giây` hoặc `giờ:phút:giây`.
  - Thêm kiểm tra điều kiện `isVideo`: Chỉ tệp Video mới hiển thị dòng "Thời lượng". Tệp ảnh tĩnh hiển thị đúng chuẩn 100% các trường: Tên, Định dạng, Dung lượng, Kích thước, Ngày chụp gốc, Ngày chỉnh sửa, Địa điểm, Vị trí tệp (giống hệt popup trong trình xem ảnh native).

### 2. Cập nhật phiên bản & build
- Nâng lên phiên bản **1.6.64** (build **10664**).
