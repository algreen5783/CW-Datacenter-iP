const assert = require('assert');
const fs = require('fs');
const path = require('path');

const iosDir = path.join(__dirname, '..');
const appJs = fs.readFileSync(path.join(iosDir, 'CWDatacenter/Resources/Web/app.js'), 'utf8');
const plist = fs.readFileSync(path.join(iosDir, 'CWDatacenter/Info.plist'), 'utf8');
const pbx = fs.readFileSync(path.join(iosDir, 'CWDatacenter.xcodeproj/project.pbxproj'), 'utf8');
const mvc = fs.readFileSync(path.join(iosDir, 'CWDatacenter/ViewControllers/MainViewController.swift'), 'utf8');
const html = fs.readFileSync(path.join(iosDir, 'CWDatacenter/Resources/Web/index.html'), 'utf8');

// 1. Versions
assert(plist.includes('<string>1.6.64</string>'), 'Info.plist must have version 1.6.64');
assert(plist.includes('<string>10664</string>'), 'Info.plist must have build 10664');
assert(pbx.includes('MARKETING_VERSION = 1.6.64;'), 'project.pbxproj must have MARKETING_VERSION 1.6.64');
assert(pbx.includes('CURRENT_PROJECT_VERSION = 10664;'), 'project.pbxproj must have CURRENT_PROJECT_VERSION 10664');
assert(mvc.includes('webAssetVersion = "1.6.64"'), 'MainViewController.swift must have webAssetVersion 1.6.64');
assert(html.includes('content="1.6.64"'), 'index.html must have cw-web-version 1.6.64');
assert(appJs.includes("window.CW_WEB_VERSION = '1.6.64';"), 'app.js must have window.CW_WEB_VERSION 1.6.64');

// 2. fmtDuration declaration
assert(appJs.includes('function fmtDuration(d)'), 'app.js must declare function fmtDuration(d)');

// 3. isVideo guard in openItemInfoSheet
const sheetCode = appJs.slice(appJs.indexOf('function openItemInfoSheet(e)'), appJs.indexOf('function openFileSheet(e)'));
assert(sheetCode.includes('isVideo && (d.duration || media.duration)'), 'openItemInfoSheet must guard duration with isVideo');

console.log('PASS iOS 1.6.64 fmtDuration and version verified');
