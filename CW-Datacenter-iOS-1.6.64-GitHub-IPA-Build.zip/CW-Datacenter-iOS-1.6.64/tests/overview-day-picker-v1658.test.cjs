const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'CWDatacenter/Resources/Web/app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'CWDatacenter/Resources/Web/index.html'), 'utf8');
const plist = fs.readFileSync(path.join(root, 'CWDatacenter/Info.plist'), 'utf8');

assert.match(app, /let overviewGalleryDayFilter = 'all'/);
assert.match(app, /function openOverviewGalleryDayPicker\(\)/);
assert.match(app, /overviewGalleryCalendarKey\(item\) !== overviewGalleryDayFilter/);
assert.match(app, /Sắp xếp theo Ngày[\s\S]*onClick: openOverviewGalleryDayPicker/);
assert.match(app, /Tất cả ngày/);
assert.match(html, /media-day-picker-grid\{display:grid;grid-template-columns:repeat\(3/);
assert.match(plist, /<string>1\.6\.(?:60|61|62|63|64)<\/string>/);
assert.match(plist, /<string>1066[01234]<\/string>/);

console.log('PASS iOS 1.6.60 Overview day picker');
