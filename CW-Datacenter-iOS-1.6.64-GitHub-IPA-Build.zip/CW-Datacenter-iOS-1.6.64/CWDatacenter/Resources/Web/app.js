/* CW Datacenter iOS client - app.js
 * Điều khiển toàn bộ UI MVP (index.html) và gọi server qua native bridge `DC`.
 * UX giữ đúng bản HTML: Discover -> Sign in -> Trust -> Tabs (Files/Truyền tải/Yêu thích/Đồng bộ/Thùng rác).
 */
(() => {
'use strict';

window.CW_WEB_VERSION = '1.6.64';

const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const enc = encodeURIComponent;

let uiToastTimer = null;
window.showUiToast = function(message) {
  let toast = document.getElementById('cwUiToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'cwUiToast';
    toast.className = 'cw-ui-toast';
    toast.setAttribute('role', 'status');
    (document.body || document.documentElement).appendChild(toast);
  }
  toast.textContent = String(message || '');
  toast.classList.add('show');
  if (uiToastTimer) clearTimeout(uiToastTimer);
  uiToastTimer = setTimeout(() => toast.classList.remove('show'), 3200);
};

/* Kiểm tra cầu nối native ngay khi khởi động để tránh tải nhầm giao diện đã cache. */
function showOldApkNotice() {
  const d = document.createElement('div');
  d.style.cssText = 'position:fixed;inset:0;z-index:9999;background:#fff;display:flex;'
    + 'flex-direction:column;align-items:center;justify-content:center;text-align:center;'
    + 'padding:32px;gap:14px;font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:#111827;';
  d.innerHTML = '<div style="font-size:40px;line-height:1">⚠️</div>'
    + '<div style="font-size:18px;font-weight:600">Ứng dụng iOS cần được cài lại</div>'
    + '<div style="font-size:13.5px;color:#667085;line-height:1.6;max-width:320px">'
    + 'Phiên bản ứng dụng trên máy không khớp với giao diện này. '
    + 'Hãy cài lại bản IPA mới nhất của CW Datacenter.</div>';
  (document.body || document.documentElement).appendChild(d);
}
if (!window.DC || typeof DC.call !== 'function') {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', showOldApkNotice);
  else showOldApkNotice();
  throw new Error('Bản iOS cũ: thiếu cầu nối DC.call');
}

const META = JSON.parse(DC.getMeta() || '{}');
const HOST = (META.manufacturer || '') + ' ' + (META.device || '');
const IS_IOS = META.platform === 'ios' || /iphone|ipad|ipod/i.test(String(META.device || ''));

/* ---------- Native bridge plumbing ---------- */
const cbs = new Map();
let cbSeq = 0;
function callNative(method, ...args) {
  return new Promise((res, rej) => {
    const id = String(++cbSeq);
    cbs.set(id, { res, rej });
    try { DC.call(method, id, JSON.stringify(args)); } catch (e) { cbs.delete(id); rej(String(e)); }
  });
}
DC._cb = (id, ok, jsonStr) => {
  const c = cbs.get(id); if (!c) return; cbs.delete(id);
  let data = null;
  if (typeof jsonStr === 'object' && jsonStr !== null) {
    data = jsonStr;
  } else {
    try { data = jsonStr ? JSON.parse(jsonStr) : {}; } catch (e) {}
  }
  ok ? c.res(data) : c.rej((data && data.err) || 'Lỗi');
};
DC._cbObj = (obj) => {
  if (obj && obj.id) {
    DC._cb(obj.id, obj.ok, obj.data);
  }
};
DC._evt = (arg) => {
  try {
    const obj = typeof arg === 'string' ? JSON.parse(arg) : arg;
    if (obj) onNativeEvent(obj);
  } catch (e) {}
};
DC._back = () => handleBack();
DC._insets = (top, bottom) => {
  const root = document.documentElement;
  root.style.setProperty('--sat', Math.max(0, top | 0) + 'px');
  root.style.setProperty('--sab', Math.max(0, bottom | 0) + 'px');
};
document.addEventListener('selectstart', (e) => {
  const t = e.target;
  if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) return;
  e.preventDefault();
});
try {
  const ins = String(DC.getInsets() || '').split(',');
  if (ins.length === 2) DC._insets(parseInt(ins[0], 10), parseInt(ins[1], 10));
} catch (e) {}

/* ---------- State ---------- */
let server = null;               // {name, host, ip, port, baseUrl, via}
let token = null;
let me = null;                   // {role, user}
let pools = [];
let pool = 'main';
let currentPath = '';
let parentPath = null;
let entries = [];
let syncDeviceBrowse = null;       // {pool, root, requestedPool, requestedRoot, pending}
let fileNavSeq = 0;
let currentView = 'discover';
let sortMode = 'name';
let fileViewMode = 'auto';
let currentFileLayout = 'list';
let searchQuery = '';
let transfers = {};              // key -> {key,id,dir,name,rel,status,done,total,speed,err,path,pool,spec}
let favs = [];
let syncDb = {};                 // rel -> {size, mtime}
let dlPaths = {};                // rel -> local path (downloaded)
let syncPaused = false;
let camOn = false;
let rememberDevice = true;
let lockMap = null;
let lockBans = null;
const lockSession = new Set();
let clipboard = { items: [], mode: '', dir: '' };   // {path,pool,local,dir,size}[] + mode 'copy'|'cut'
let syncDest = null;                                 // {localPath, name} — thư mục trên máy lưu file tải về
let syncSrc = null;                                  // {path, name} — thư mục trên máy đồng bộ 1 chiều lên host
let syncDbUp = {};                                   // rel -> {size, mtime} — tệp thiết bị đã đẩy lên host
let syncUpQueue = [];
let syncUpBusy = false;
let syncUpWatchdog = null;
let syncUpLastProgressAt = 0;
let syncUpLastDone = -1;
const SYNC_UPLOAD_STALL_TIMEOUT_MS = 10 * 60 * 1000;
let phoneFolderOk = false;
let lpSuppressClick = false; // chặn click ngay sau khi nhấn giữ thành công (tránh bỏ chọn luôn)
const LOCAL_POOL = 'thisdevice';
let localDrive = null;                               // {treeUri, name} — gốc bộ nhớ của thiết bị (do người dùng chọn)
let localNav = [];                                   // [{path,name}] — stack thư mục local đang duyệt
let localFree = '';                                  // dung lượng trống ổ thiết bị (hiển thị như các ổ chia sẻ)
let localFreeBytes = 0;
let localTotalBytes = 0;
let localRootPath = '';                              // đường dẫn gốc bộ nhớ trong (/storage/emulated/0)
let iosCameraState = { running: false, total: 0, backed: 0, pending: 0, failed: 0, current: 0, percent: 0, filename: '', part: '', error: '', recent: [], hostVerified: false };
let iosCameraMediaMode = 'all';
let iosCameraStorageMode = 'all';
let iosCameraFolderCustom = '';
let iosCameraImageFolderLimit = 400;
let iosCameraVideoFolderLimit = 300;
let iosCameraDeleteAfterUpload = false;
const iosCameraFailedNames = new Set();
let iosCameraStatsBusy = false;
let iosCameraStatsAt = 0;
let incomingShareFiles = [];
let incomingSharePromptOpen = false;
let overviewLocksReady = false;
let overviewContinueIdentity = '';
let overviewGalleryItems = [];
let overviewGalleryVisible = [];
let overviewGalleryFilter = 'all';
let overviewGalleryQuery = '';
let overviewGallerySort = 'date-desc';
let overviewGalleryFolderFilter = 'all';
let overviewGalleryDayFilter = 'all';
const overviewSortLabels = {
  'date-desc': 'Ngày · Mới nhất trước', 'date-asc': 'Ngày · Cũ nhất trước',
  'name-asc': 'Tên · A → Z', 'name-desc': 'Tên · Z → A',
  'size-desc': 'Dung lượng · Lớn nhất trước', 'size-asc': 'Dung lượng · Nhỏ nhất trước'
};
let overviewGalleryRenderLimit = 120;
let overviewGalleryBusy = false;
let overviewGalleryScope = '';
let overviewGalleryLastScanAt = 0;
let overviewGalleryScanSequence = 0;
let overviewGalleryObserver = null;
let overviewGallerySelectionMode = false;
const overviewGallerySelected = new Set();
let overviewGallerySuppressClickUntil = 0;
let overviewThumbWarmBusy = false;
let overviewThumbWarmRequested = false;
let overviewThumbWarmNextAttemptAt = 0;
let overviewThumbWarmComplete = false;
let overviewThumbWarmGeneration = 0;
const overviewThumbWarmControllers = new Set();
let overviewThumbReadySaveTimer = 0;
let overviewGalleryDeviceFolder = '';
let overviewGalleryDeviceOwnerScope = '';
let overviewGalleryDeviceChoices = [];
let overviewGalleryDeviceChoicesAt = 0;

const kvGet = (k) => { const v = DC.loadKV(k); try { return v ? JSON.parse(v) : null; } catch (e) { return v; } };
const kvSet = (k, v) => DC.saveKV(k, JSON.stringify(v));

function kFavs() { return 'favs:' + (server ? server.baseUrl : ''); }
function kSync() { return 'sync:' + (server ? server.baseUrl : ''); }
function kDlPaths() { return 'dl:' + (server ? server.baseUrl : ''); }
function kToken() { return 'token:' + (server ? server.baseUrl : ''); }
function kCreds() { return 'creds:' + (server ? server.baseUrl : ''); }
function kTrust() { return 'trust:' + (server ? server.baseUrl : '') + ':' + ((me && me.user) || ''); }
function kLocks() { return 'locks:' + (server ? server.baseUrl : ''); }
function kLockBans() { return 'lockban:' + (server ? server.baseUrl : ''); }
function kPending() { return 'pending:' + (server ? server.baseUrl : ''); }
function kLocalDrive() { return 'localDrive:' + (server ? server.baseUrl : ''); }
function kSyncSrc() { return 'syncSrc:' + (server ? server.baseUrl : ''); }
function kSyncDbUp() { return 'syncUp:' + (server ? server.baseUrl : ''); }
function kIOSCameraMediaMode() { return 'iosCameraMediaMode:' + (server ? server.baseUrl : ''); }
function kIOSCameraStorageMode() { return 'iosCameraStorageMode:' + (server ? server.baseUrl : ''); }
function kIOSCameraFolderName() { return 'iosCameraFolderName:' + (server ? server.baseUrl : ''); }
function kIOSCameraImageFolderLimit() { return 'iosCameraImageFolderLimit:' + (server ? server.baseUrl : ''); }
function kIOSCameraVideoFolderLimit() { return 'iosCameraVideoFolderLimit:' + (server ? server.baseUrl : ''); }
function kIOSCameraDeleteAfterUpload() { return 'iosCameraDeleteAfterUpload:' + (server ? server.baseUrl : ''); }
function overviewAccount() { return String((me && me.user) || '').trim().toLowerCase(); }
function overviewServer() { return String(server ? server.baseUrl : '').replace(/\/+$/, '').toLowerCase(); }
function legacyKQuickFolders() { return 'overviewQuickFolders:' + (server ? server.baseUrl : ''); }
function kQuickFolders() { return 'iosOverviewQuickFolders:v2:' + overviewServer() + ':' + encodeURIComponent(overviewAccount()); }
function kQuickFoldersLegacyOwner() { return 'iosOverviewQuickFolders:v2-owner:' + overviewServer(); }
function overviewFileKey() { return 'iosOverviewRecentFiles:v1:' + overviewServer() + ':' + encodeURIComponent(overviewAccount()); }
function overviewGalleryOwnDeviceFolder() { return iosCameraFolderName(); }
function overviewGalleryDeviceSessionScope() { return overviewServer() + ':' + encodeURIComponent(overviewAccount()); }
function ensureOverviewGalleryDeviceFolder() {
  const scope = overviewGalleryDeviceSessionScope();
  if (scope !== overviewGalleryDeviceOwnerScope) {
    overviewGalleryDeviceOwnerScope = scope;
    overviewGalleryDeviceFolder = overviewGalleryOwnDeviceFolder();
    overviewGalleryDeviceChoices = [];
    overviewGalleryDeviceChoicesAt = 0;
    overviewGalleryScanSequence += 1;
  }
  if (!overviewGalleryDeviceFolder) overviewGalleryDeviceFolder = overviewGalleryOwnDeviceFolder();
  return overviewGalleryDeviceFolder;
}
function overviewGalleryKey() { return 'iosOverviewGallery:v2:' + overviewServer() + ':' + encodeURIComponent(overviewAccount()) + ':' + encodeURIComponent(cameraPoolCache || 'pool_camera') + ':' + encodeURIComponent(ensureOverviewGalleryDeviceFolder()); }

/* ---------- Helpers ---------- */
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function fmtBytes(b) {
  if (b == null || b < 0) return '';
  if (b < 1024) return b + ' B';
  if (b < 1024 * 1024) return (b / 1024).toFixed(0) + ' KB';
  if (b < 1024 * 1024 * 1024) return (b / 1024 / 1024).toFixed(1) + ' MB';
  return (b / 1024 / 1024 / 1024).toFixed(2) + ' GB';
}
function fmtDuration(d) {
  if (d == null || d === '') return '';
  if (typeof d === 'string' && d.includes(':')) return d;
  const num = Number(d);
  if (isNaN(num) || num <= 0) return '';
  let s = Math.round(num);
  if (s > 86400) s = Math.round(s / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const p = (n) => (n < 10 ? '0' + n : '' + n);
  if (h > 0) {
    return `${h}:${p(m)}:${p(sec)}`;
  }
  return `${p(m)}:${p(sec)}`;
}
function fmtDateTime(iso) {
  if (!iso) return '';
  try {
    let d;
    let sec = 0;
    if (typeof iso === 'string') {
      const s = iso.trim();
      const m = s.match(/^(\d{4})[-/:](\d{2})[-/:](\d{2})(?:[T\s](\d{2})[:.](\d{2})(?:[:.](\d{2}))?)?/);
      if (m) {
        const yr = parseInt(m[1], 10);
        const mo = parseInt(m[2], 10) - 1;
        const dy = parseInt(m[3], 10);
        const hr = m[4] ? parseInt(m[4], 10) : 0;
        const mi = m[5] ? parseInt(m[5], 10) : 0;
        sec = m[6] ? parseInt(m[6], 10) : 0;
        d = new Date(yr, mo, dy, hr, mi, sec);
      } else {
        d = new Date(s);
      }
    } else {
      d = new Date(iso);
    }
    if (isNaN(d.getTime())) {
      if (typeof iso === 'string' && /^\d{4}/.test(iso)) return iso;
      return '';
    }
    const p = (n) => (n < 10 ? '0' + n : '' + n);
    return p(d.getDate()) + '/' + p(d.getMonth() + 1) + '/' + d.getFullYear() + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
  } catch (e) { return ''; }
}
function fmtDate(iso) {
  if (!iso) return '';
  try {
    let d;
    if (typeof iso === 'string') {
      const s = iso.trim();
      const m = s.match(/^(\d{4})[-/:](\d{2})[-/:](\d{2})(?:[T\s](\d{2})[:.](\d{2})(?:[:.](\d{2}))?)?/);
      if (m) {
        const yr = parseInt(m[1], 10);
        const mo = parseInt(m[2], 10) - 1;
        const dy = parseInt(m[3], 10);
        const hr = m[4] ? parseInt(m[4], 10) : 0;
        const mi = m[5] ? parseInt(m[5], 10) : 0;
        const sc = m[6] ? parseInt(m[6], 10) : 0;
        d = new Date(yr, mo, dy, hr, mi, sc);
      } else {
        d = new Date(s);
      }
    } else {
      d = new Date(iso);
    }
    if (isNaN(d.getTime())) {
      if (typeof iso === 'string' && /^\d{4}/.test(iso)) return iso;
      return '';
    }
    const p = (n) => (n < 10 ? '0' + n : '' + n);
    return p(d.getDate()) + '/' + p(d.getMonth() + 1) + '/' + d.getFullYear() + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  } catch (e) { return ''; }
}
function fmtAgo(iso) {
  const t = Date.now() - new Date(iso).getTime();
  if (t < 60000) return 'vừa xong';
  if (t < 3600000) return Math.floor(t / 60000) + ' phút trước';
  if (t < 86400000) return Math.floor(t / 3600000) + ' giờ trước';
  const d = Math.floor(t / 86400000);
  return d === 1 ? 'hôm qua' : d + ' ngày trước';
}
function fmtEta(total, done, speed) {
  if (!speed || speed <= 0 || done >= total) return '';
  let s = Math.round((total - done) / speed);
  const m = Math.floor(s / 60); s %= 60;
  if (m > 0) return m + ' phút ' + s + ' giây';
  return s + ' giây';
}
const VIDEO_EXT = ['mp4', 'mkv', 'mov', 'webm', 'avi', 'm4v', '3gp', '3gpp', 'flv', 'wmv', 'mpg', 'mpeg', 'ts', 'm2ts', 'mts', 'ogv', 'rm', 'rmvb'];
const AUDIO_EXT = ['mp3', 'wav', 'wave', 'ogg', 'oga', 'opus', 'm4a', 'aac', 'flac', 'alac', 'wma', 'amr'];
function isVideoFile(name) { return VIDEO_EXT.includes(String(name || '').split('.').pop().toLowerCase()); }
function fileIcon(name) {
  const value = String(name || '').toLowerCase();
  const dot = value.lastIndexOf('.');
  const ext = dot > 0 ? value.slice(dot + 1) : '';
  const has = (items) => items.includes(ext);
  if (VIDEO_EXT.includes(ext)) return { sym: 'i-video', color: 'var(--purple)' };
  if (AUDIO_EXT.includes(ext)) return { sym: 'i-music', color: '#0ea5e9' };
  if (has(['png','jpg','jpeg','gif','webp','bmp','svg','ico','avif','heic','heif','tif','tiff','raw','dng'])) return { sym: 'i-image', color: '#eab308' };
  if (ext === 'pdf') return { sym: 'i-pdf', color: '#dc2626' };
  if (has(['xls','xlsx','xlsm','xlsb','ods','csv','tsv'])) return { sym: 'i-sheet', color: '#16a34a' };
  if (has(['doc','docx','docm','odt','rtf','pages'])) return { sym: 'i-doc', color: '#2563eb' };
  if (has(['ppt','pptx','pptm','odp','key'])) return { sym: 'i-slide', color: '#ea580c' };
  if (has(['zip','rar','7z','tar','gz','tgz','bz2','xz','iso','cab','lz','zst'])) return { sym: 'i-archive', color: '#f59e0b' };
  if (has(['js','mjs','cjs','ts','jsx','tsx','py','java','kt','kts','swift','c','cc','cpp','h','hpp','cs','php','go','rs','rb','vue','html','htm','css','scss','sass','less','json','xml','yml','yaml','sql','sh','bat','cmd','ps1'])) return { sym: 'i-code', color: '#7c3aed' };
  if (has(['txt','md','markdown','log','ini','cfg','conf','env','srt','vtt'])) return { sym: 'i-text', color: '#64748b' };
  if (has(['db','sqlite','sqlite3','mdb','accdb','dbf'])) return { sym: 'i-database', color: '#0891b2' };
  if (has(['epub','mobi','azw','azw3','fb2'])) return { sym: 'i-book', color: '#4f46e5' };
  if (has(['apk','aab','apks','xapk'])) return { sym: 'i-apk', color: '#3ba55c' };
  if (has(['ipa','exe','msi','msix','appx','appxbundle','dmg','pkg','deb','rpm'])) return { sym: 'i-package', color: '#db2777' };
  if (has(['ttf','otf','woff','woff2','eot'])) return { sym: 'i-font', color: '#9333ea' };
  if (has(['psd','ai','eps','sketch','fig','xd','blend','dwg','dxf'])) return { sym: 'i-design', color: '#ec4899' };
  if (has(['onnx','pt','pth','safetensors','gguf','model','h5','bin','ckpt','pb','tflite'])) return { sym: 'i-cube', color: 'var(--cyan)' };
  return { sym: 'i-file', color: 'var(--muted)' };
}
function iconSvg(sym, cls) { return '<svg class="' + (cls || 'svg-24') + '"><use href="#' + sym + '"/></svg>'; }

function relOf(e) { return e._rel || (currentPath ? currentPath + '/' : '') + e.name; }
function normalizeHostFileResponse(data, requestedPool) {
  const d = data && typeof data === 'object' ? data : {};
  const resolvedPool = String(d.pool || requestedPool || '').trim();
  const resolvedPath = String(d.path || '').replace(/\\/g, '/').replace(/^\/+|\/+$/g, '');
  const resolvedParent = d.parent == null ? null : String(d.parent).replace(/\\/g, '/').replace(/^\/+|\/+$/g, '');
  const normalizedEntries = (Array.isArray(d.entries) ? d.entries : []).map((item) => {
    const entry = Object.assign({}, item || {});
    const name = String(entry.name || '');
    entry.pool = String(entry.pool || resolvedPool || requestedPool || 'main');
    entry.dirRel = resolvedPath;
    entry._rel = String(entry._rel || (resolvedPath ? resolvedPath + '/' : '') + name).replace(/\\/g, '/').replace(/^\/+/, '');
    return entry;
  });
  return { pool: resolvedPool || requestedPool, path: resolvedPath, parent: resolvedParent, entries: normalizedEntries };
}
function dirRelOf(rel) { return String(rel || '').includes('/') ? String(rel).slice(0, String(rel).lastIndexOf('/')) : ''; }
function isReader() { return !!me; }
function canWrite() { return me && me.role !== 'viewer'; }
function errText(e) {
  const msg = (e && (e.error || e.err || e.message)) || (typeof e === 'string' ? e : '') || 'Đã xảy ra lỗi không xác định.';
  if (typeof msg === 'string') {
    const lower = msg.toLowerCase();
    if (lower.includes('failed to connect') || lower.includes('connectexception') || lower.includes('timed out') || lower.includes('timeout') || lower.includes('econnrefused') || lower.includes('network connection was lost') || lower.includes('not connected to the internet')) {
      return 'Không kết nối được tới máy chủ (' + (server ? (server.ip + ':' + server.port) : '') + '). Hãy kiểm tra máy host đang chạy và app Tailscale trên điện thoại đã BẬT VPN.';
    }
  }
  return msg;
}
function isLocalMode() { return pool === LOCAL_POOL; }

/* ========== LOCKS (port từ web client: khóa bằng mật khẩu, lưu client-side) ========== */
function sha256js(s) {
  const K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  const rr = (v, n) => (v >>> n) | (v << (32 - n));
  const H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
  const bytes = new TextEncoder().encode(s);
  const l = bytes.length, bitLen = l * 8;
  const buf = new Uint8Array(((l + 9 + 63) >> 6) << 6);
  buf.set(bytes); buf[l] = 0x80;
  const dv = new DataView(buf.buffer);
  dv.setUint32(buf.length - 8, Math.floor(bitLen / 0x100000000), false);
  dv.setUint32(buf.length - 4, bitLen >>> 0, false);
  const w = new Uint32Array(64);
  for (let i = 0; i < buf.length; i += 64) {
    for (let j = 0; j < 16; j++) w[j] = dv.getUint32(i + j * 4, false);
    for (let j = 16; j < 64; j++) {
      const s0 = rr(w[j - 15], 7) ^ rr(w[j - 15], 18) ^ (w[j - 15] >>> 3);
      const s1 = rr(w[j - 2], 17) ^ rr(w[j - 2], 19) ^ (w[j - 2] >>> 10);
      w[j] = (w[j - 16] + s0 + w[j - 7] + s1) >>> 0;
    }
    let a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
    for (let j = 0; j < 64; j++) {
      const S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25);
      const ch = (e & f) ^ (~e & g);
      const t1 = (h + S1 + ch + K[j] + w[j]) >>> 0;
      const S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const t2 = (S0 + maj) >>> 0;
      h = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
    }
    H[0] = (H[0] + a) >>> 0; H[1] = (H[1] + b) >>> 0; H[2] = (H[2] + c) >>> 0; H[3] = (H[3] + d) >>> 0;
    H[4] = (H[4] + e) >>> 0; H[5] = (H[5] + f) >>> 0; H[6] = (H[6] + g) >>> 0; H[7] = (H[7] + h) >>> 0;
  }
  return H.map((v) => v.toString(16).padStart(8, '0')).join('');
}
const sha256 = sha256js;

function ensureLockMap() { if (!lockMap) lockMap = kvGet(kLocks()) || {}; return lockMap; }
function ensureLockBans() { if (!lockBans) lockBans = kvGet(kLockBans()) || {}; return lockBans; }
function saveLockMap() { kvSet(kLocks(), lockMap || {}); }
function saveLockBans() { kvSet(kLockBans(), lockBans || {}); }
async function syncLocksFromServer() {
  if (isLocalMode() || !server) return;
  try {
    const data = await api('/api/locks', 'GET');
    const serverLocks = (data && data.locks) || [];
    const map = {};
    for (const l of serverLocks) {
      if (l.type === 'drive') {
        map[poolLockKey(l.pool)] = l.hash;
      } else {
        const p = (l.path || '').replace(/^\/+/, '');
        const dir = p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : '';
        const nm = p.includes('/') ? p.slice(p.lastIndexOf('/') + 1) : p;
        map[lockKeyOf(l.pool || 'main', dir, nm)] = l.hash;
      }
    }
    const previousMap = ensureLockMap();
    for (const key of [...lockSession]) if (!map[key] || map[key] !== previousMap[key]) lockSession.delete(key);
    lockMap = map;
    saveLockMap();
    updateLockUI();
  } catch {}
}
function poolById(id) { return pools.find((p) => p.id === id) || null; }
function poolNameOf(id) { const p = poolById(id); return p ? p.name : (id || 'Ổ mặc định'); }
function normalizedLockPath(value) { return String(value || '').replace(/\\/g, '/').replace(/^\/+|\/+$/g, '').replace(/\/{2,}/g, '/').toLocaleLowerCase('en-US'); }
function lockKeyOf(p, dirRel, name) { return (server ? server.baseUrl : '') + '|' + String(p || 'main').toLocaleLowerCase('en-US') + '|' + normalizedLockPath((dirRel ? dirRel + '/' : '') + (name || '')); }
function poolLockKey(p) { return (server ? server.baseUrl : '') + '|pool:' + String(p || 'main').toLocaleLowerCase('en-US') + '|'; }
function lockKeyFor(f) { return lockKeyOf(f.pool || pool, f.dirRel != null ? f.dirRel : currentPath, f.name); }
function poolTargetOf(p) { return { kind: 'pool', name: poolNameOf(p), pool: p, _lockKey: poolLockKey(p) }; }
function hasPoolLock(p) { return !!ensureLockMap()[poolLockKey(p)]; }
function isPoolLocked(p) { return !!p && hasPoolLock(p) && !lockSession.has(poolLockKey(p)); }

function findLockedAncestor(p, dirRel) {
  const map = ensureLockMap();
  const parts = dirRel ? String(dirRel).replace(/\\/g, '/').replace(/^\/+|\/+$/g, '').replace(/\/{2,}/g, '/').split('/').filter(Boolean) : [];
  for (let i = 1; i <= parts.length; i++) {
    const parentDir = parts.slice(0, i - 1).join('/');
    const key = lockKeyOf(p, parentDir, parts[i - 1]);
    if (map[key] && !lockSession.has(key)) {
      return { kind: 'folder', name: parts[i - 1], type: 'dir', rel: (parentDir ? parentDir + '/' : '') + parts[i - 1], dirRel: parentDir, pool: p, _lockKey: key };
    }
  }
  return null;
}

function resolveLockTarget(f) {
  if (!f) return null;
  const p = f.pool || pool;
  const map = ensureLockMap();
  const pk = poolLockKey(p);
  if (map[pk] && !lockSession.has(pk)) return poolTargetOf(p);
  const anc = findLockedAncestor(p, f.dirRel != null ? f.dirRel : currentPath);
  if (anc) return anc;
  if (f.name && map[lockKeyFor(f)] && !lockSession.has(lockKeyFor(f))) return f;
  return null;
}

function overviewPathIsConfiguredProtected(pathValue, poolId) {
  const p = poolId || pool || 'main';
  const map = ensureLockMap();
  if (map[poolLockKey(p)]) return true;
  const parts = String(pathValue || '').replace(/\\/g, '/').replace(/^\/+|\/+$/g, '').split('/').filter(Boolean);
  for (let i = 1; i <= parts.length; i++) {
    const parentDir = parts.slice(0, i - 1).join('/');
    if (map[lockKeyOf(p, parentDir, parts[i - 1])]) return true;
  }
  return false;
}

function entryLocked(f) { return !!resolveLockTarget(f); }

function lockBanInfo(key) {
  const e = ensureLockBans()[key];
  if (e && e.until && Date.now() < e.until) return { fails: e.fails || 0, until: e.until };
  return { fails: 0, until: 0 };
}
function recordLockFail(key) {
  const m = ensureLockBans();
  let e = m[key];
  if (!e || (e.until && Date.now() >= e.until)) e = { fails: 0, until: 0 };
  e.fails = (e.fails || 0) + 1;
  if (e.fails >= 5) { e.until = Date.now() + 8 * 60 * 60 * 1000; e.fails = 0; }
  m[key] = e;
  saveLockBans();
  return e;
}
function clearLockBan(key) { delete ensureLockBans()[key]; saveLockBans(); }
function fmtLockDur(ms) {
  const s = Math.max(1, Math.round(ms / 1000));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  if (h) return h + ' giờ ' + m + ' phút';
  if (m) return m + ' phút ' + sec + ' giây';
  return sec + ' giây';
}

function unlockSheet(t, onOk, onCancel) {
  const key = t._lockKey || lockKeyFor(t);
  openSheet('Mở khóa "' + t.name + '"', (body) => {
    const hint = document.createElement('div');
    hint.style.cssText = 'font-size:12.5px;color:#667085;line-height:1.6;margin-bottom:12px';
    hint.textContent = t.kind === 'pool' ? 'Ổ đĩa này đang bị khóa — nhập đúng mật khẩu khóa để dùng.'
      : (t.kind === 'folder' ? 'Thư mục "' + t.name + '" đang bị khóa — nhập đúng mật khẩu khóa để mở các tệp bên trong.' : 'Nhập đúng mật khẩu khóa đã đặt để mở.');
    body.appendChild(hint);
    const wrap = document.createElement('div');
    wrap.className = 'field';
    wrap.innerHTML = '<div class="input-wrap">' + iconSvg('i-lock', 'svg-20') + '<input type="password" placeholder="Mật khẩu khóa"></div>';
    body.appendChild(wrap);
    const input = wrap.querySelector('input');
    const errEl = document.createElement('div');
    errEl.style.cssText = 'color:var(--red);font-size:12.5px;margin:2px 2px 8px;min-height:16px';
    body.appendChild(errEl);
    setTimeout(() => input.focus(), 120);
    const row = document.createElement('div');
    row.className = 'row-btn';
    row.innerHTML = '<button class="btn secondary">Hủy</button><button class="btn primary">Xác nhận</button>';
    row.children[0].addEventListener('click', () => { closeSheet(); if (onCancel) onCancel(); });
    row.children[1].addEventListener('click', async () => {
      const ban = lockBanInfo(key);
      if (ban.until > Date.now()) { errEl.textContent = 'Đã sai quá 5 lần — mở lại sau ' + fmtLockDur(ban.until - Date.now()); return; }
      const v = input.value;
      if (!v) return;
      const stored = ensureLockMap()[key];
      const poolMode = t.kind === 'pool';
      const poolId = t.pool || pool;
      const itemRel = poolMode ? '' : (t._rel || t.rel || ((t.dirRel != null ? t.dirRel : currentPath) ? (t.dirRel != null ? t.dirRel : currentPath) + '/' : '') + t.name);
      const itemType = poolMode ? 'drive' : (t.type === 'dir' ? 'folder' : 'file');

      let isOk = false;
      try {
        const vRes = await api('/api/locks/verify', 'POST', {
          id: t._serverLockId || undefined,
          pool: poolId,
          path: itemRel,
          type: itemType,
          password: v
        });
        if (vRes && vRes.ok && vRes.verified === true && vRes.locked === true) isOk = true;
      } catch (error) {
        if (Number(error && error.status) !== 403 && !(error && error.verified === false && error.error === 'Mật khẩu không đúng.')) {
          errEl.textContent = (error && (error.error || error.message)) || 'Không xác minh được mật khẩu. Hãy thử lại.';
          return;
        }
      }
      if (!server && stored && sha256js(v) === stored) isOk = true;

      if (isOk) {
        clearLockBan(key);
        lockSession.add(key);
        closeSheet();
        DC.toast('Đã mở khóa "' + t.name + '" — có hiệu lực đến khi đóng app');
        updateLockUI();
        onOk && onOk();
      } else {
        const e = recordLockFail(key);
        input.value = '';
        if (e.until && Date.now() < e.until) errEl.textContent = 'Đã sai quá 5 lần — không thể mở trong 8 giờ. Mở lại sau ' + fmtLockDur(e.until - Date.now());
        else errEl.textContent = 'Mật khẩu không đúng (' + (e.fails || 0) + '/5 lần). Còn sai thêm ' + (5 - (e.fails || 0)) + ' lần sẽ khóa 8 giờ.';
        input.focus();
      }
    });
    body.appendChild(row);
    const ban0 = lockBanInfo(key);
    if (ban0.until > Date.now()) errEl.textContent = 'Đã sai quá 5 lần — mở lại sau ' + fmtLockDur(ban0.until - Date.now());
    else if (ban0.fails > 0) errEl.textContent = 'Đã nhập sai ' + ban0.fails + '/5 lần.';
  });
}

function lockSheet(t, onDone) {
  const key = t._lockKey || lockKeyFor(t);
  const poolMode = t.kind === 'pool';
  openSheet('Khóa "' + t.name + '"', (body) => {
    const hint = document.createElement('div');
    hint.style.cssText = 'font-size:12.5px;color:#667085;line-height:1.6;margin-bottom:12px';
    hint.textContent = poolMode ? 'Khóa toàn bộ ổ đĩa này — mọi tệp và thư mục bên trong đều yêu cầu mật khẩu để mở trên cả PC và điện thoại.'
      : 'Mật khẩu khóa sẽ được lưu trên máy chủ và đồng bộ với cả PC và điện thoại.';
    body.appendChild(hint);
    const wrap = document.createElement('div');
    wrap.className = 'field';
    wrap.innerHTML = '<div class="input-wrap">' + iconSvg('i-lock', 'svg-20') + '<input type="password" placeholder="Mật khẩu khóa (tối thiểu 3 ký tự)"></div>';
    body.appendChild(wrap);
    const input = wrap.querySelector('input');
    const note = document.createElement('div');
    note.style.cssText = 'color:#98a2b3;font-size:12px;margin:4px 2px 10px';
    note.textContent = 'Mật khẩu đồng bộ trên tất cả thiết bị kết nối tới host.';
    body.appendChild(note);
    setTimeout(() => input.focus(), 120);
    const row = document.createElement('div');
    row.className = 'row-btn';
    row.innerHTML = '<button class="btn secondary">Hủy</button><button class="btn primary">Xác nhận</button>';
    row.children[0].addEventListener('click', closeSheet);
    row.children[1].addEventListener('click', async () => {
      if (input.value.length < 3) { note.textContent = '✕ Mật khẩu khóa cần tối thiểu 3 ký tự.'; note.style.color = 'var(--red)'; return; }
      const poolId = t.pool || pool;
      const itemRel = poolMode ? '' : (t._rel || t.rel || ((t.dirRel != null ? t.dirRel : currentPath) ? (t.dirRel != null ? t.dirRel : currentPath) + '/' : '') + t.name);
      const itemType = poolMode ? 'drive' : (t.type === 'dir' ? 'folder' : 'file');
      try {
        await api('/api/locks', 'POST', {
          pool: poolId,
          path: itemRel,
          type: itemType,
          name: t.name,
          password: input.value
        });
      } catch {}
      await syncLocksFromServer();
      closeSheet();
      DC.toast('Đã khóa "' + t.name + '"');
      updateLockUI();
      onDone && onDone();
    });
    body.appendChild(row);
  });
}

function removeLock(t, onDone) {
  sheetConfirm('Gỡ khóa "' + t.name + '"', 'Gỡ bỏ mật khẩu khóa — ai cũng có thể mở mục này mà không cần mật khẩu.', 'Gỡ khóa', async () => {
    const poolMode = t.kind === 'pool';
    const poolId = t.pool || pool;
    const itemRel = poolMode ? '' : (t._rel || t.rel || ((t.dirRel != null ? t.dirRel : currentPath) ? (t.dirRel != null ? t.dirRel : currentPath) + '/' : '') + t.name);
    const itemType = poolMode ? 'drive' : (t.type === 'dir' ? 'folder' : 'file');
    try {
      await api('/api/locks', 'DELETE', {
        pool: poolId,
        path: itemRel,
        type: itemType
      });
    } catch {}
    await syncLocksFromServer();
    DC.toast('Đã gỡ khóa "' + t.name + '"');
    updateLockUI();
    onDone && onDone();
  });
}

function requireUnlocked(f, fn) {
  const t = resolveLockTarget(f);
  if (!t) { fn(); return; }
  DC.toast((t.kind === 'pool' ? 'Ổ đĩa "' + t.name + '"' : '"' + t.name + '"') + ' đang bị khóa — hãy mở khóa trước.');
  unlockSheet(t, () => requireUnlocked(f, fn));
}

/* ========== POOL BAR (chọn ổ đĩa) ========== */
function isSharedPool(p) {
  if (!p) return false;
  const id = String(typeof p === 'string' ? p : (p.id || '')).trim().toLowerCase();
  const nm = String(typeof p === 'string' ? '' : (p.name || '')).trim().toLowerCase();
  return id === 'shared' || nm === 'shared' || id.startsWith('shared_') || nm.startsWith('shared') || /^(shared|dùng chung|đã chia sẻ)$/i.test(nm) || /^(shared|dùng chung|đã chia sẻ)$/i.test(id);
}

function syncDeviceFolderName() { return IS_IOS ? iosCameraFolderName() : phoneName(); }

async function openSyncDeviceFolder() {
  const hp = await cameraHostPool(true);
  if (!hp) { DC.toast('Chưa kết nối máy chủ.'); return; }
  const syncDeviceFolder = syncDeviceFolderName();
  syncDeviceBrowse = { pool: hp.id, root: syncDeviceFolder, requestedPool: hp.id, requestedRoot: syncDeviceFolder, pending: true };
  if (pool !== hp.id) pool = hp.id;
  currentPath = '';
  parentPath = null;
  entries = [];
  renderPoolBar();
  try {
    await api('/api/mkdir', 'POST', { path: syncDeviceFolder, pool: hp.id });
  } catch (e) {
    syncDeviceBrowse = null;
    DC.toast(errText(e));
    return;
  }
  await loadFiles(syncDeviceFolder);
}

function isSyncDeviceBrowseActive() {
  if (isLocalMode() || !syncDeviceBrowse) return false;
  const root = String(syncDeviceBrowse.root || '');
  return pool === syncDeviceBrowse.pool && !!root && (currentPath === root || currentPath.startsWith(root + '/'));
}

function driveCapacity(p) {
  const free = Number(p && p.free || 0);
  const total = Number(p && (p.total || p.capacity || p.size) || 0);
  const used = total > 0 ? Math.max(0, total - free) : 0;
  return { free, total, used, pct: total > 0 ? Math.max(0, Math.min(100, used * 100 / total)) : 0 };
}

function driveChoiceCard(item, selectedId, choose) {
  const cap = item.cap || { free: 0, total: 0, used: 0, pct: 0 };
  const card = document.createElement('button');
  card.type = 'button';
  card.className = 'drive-choice' + (item.id === selectedId ? ' selected' : '') + (item.offline ? ' offline' : '');
  const capacityText = cap.total > 0
    ? fmtBytes(cap.used) + ' / ' + fmtBytes(cap.total)
    : (cap.free > 0 ? 'Còn trống ' + fmtBytes(cap.free) : 'Dung lượng chưa xác định');
  card.innerHTML =
    '<span class="drive-choice-icon">' + iconSvg(item.icon || 'i-server', 'svg-28') + '</span>' +
    '<span class="drive-choice-main"><strong>' + esc(item.name) + '</strong>' +
    '<span class="drive-choice-cap">' + esc(capacityText) + '</span>' +
    '<span class="drive-choice-bar"><i style="width:' + cap.pct.toFixed(1) + '%"></i></span>' +
    '<span class="drive-choice-free">' + (cap.free > 0 ? 'Còn trống ' + esc(fmtBytes(cap.free)) : (item.offline ? 'Không khả dụng' : '')) + '</span></span>' +
    '<span class="drive-choice-check">' + (item.id === selectedId ? '✓' : '') + '</span>';
  card.addEventListener('click', () => { if (!item.offline) choose(item.id); });
  return card;
}

function openDrivePicker() {
  if (!server) return;
  const syncDeviceFolder = syncDeviceFolderName();
  let selectedId = (pool === LOCAL_POOL) ? LOCAL_POOL : pool;
  const syncActive = isSyncDeviceBrowseActive() || (!isLocalMode() && !!cameraPoolCache && pool === cameraPoolCache && (currentPath === syncDeviceFolder || currentPath.startsWith(syncDeviceFolder + '/')));
  if (syncActive) selectedId = 'sync_device_folder';
  const overlay = document.createElement('div');
  overlay.className = 'drive-picker-overlay';
  overlay.innerHTML =
    '<section class="drive-picker-dialog" role="dialog" aria-modal="true" aria-label="Chọn ổ đĩa">' +
    '<header><h2>Chọn ổ đĩa</h2><button type="button" class="drive-picker-x" aria-label="Đóng">×</button></header>' +
    '<div class="drive-picker-list"></div>' +
    '<footer><button type="button" class="drive-picker-cancel">Đóng</button></footer>' +
    '</section>';
  document.body.appendChild(overlay);
  const list = overlay.querySelector('.drive-picker-list');
  const close = () => overlay.remove();
  const choices = [
    { id: LOCAL_POOL, name: 'Thiết bị này', icon: 'i-phone', cap: { free: localFreeBytes, total: localTotalBytes, used: Math.max(0, localTotalBytes - localFreeBytes), pct: localTotalBytes > 0 ? Math.max(0, Math.min(100, (localTotalBytes - localFreeBytes) * 100 / localTotalBytes)) : 0 } },
    { id: 'sync_device_folder', name: 'Đồng bộ (' + syncDeviceFolder + ')', icon: 'i-sync', cap: driveCapacity(poolById(cameraPoolCache)) },
    ...pools.filter((p) => !isSharedPool(p)).map((p) => ({ id: p.id, name: p.name, icon: isPoolLocked(p.id) ? 'i-lock' : 'i-server', offline: p.online === false, cap: driveCapacity(p) })),
  ];
  const selectDrive = async (id) => {
    const target = choices.find((item) => item.id === id);
    if (!target || target.offline) return;
    close();
    activateMainView('files');
    if (id === 'sync_device_folder') { await openSyncDeviceFolder(); return; }
    if (id !== LOCAL_POOL && isPoolLocked(id)) {
      unlockSheet(poolTargetOf(id), () => switchPool(id));
      return;
    }
    switchPool(id);
  };
  const render = () => {
    list.innerHTML = '';
    choices.forEach((item) => list.appendChild(driveChoiceCard(item, selectedId, selectDrive)));
  };
  render();
  overlay.querySelector('.drive-picker-x').addEventListener('click', close);
  overlay.querySelector('.drive-picker-cancel').addEventListener('click', close);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
}

function renderPoolBar() {
  const bar = $('#poolBar');
  if (!bar) return;
  if (!server) { bar.style.display = 'none'; return; }
  bar.innerHTML = '';
  bar.style.display = '';
  const syncDeviceFolder = syncDeviceFolderName();
  const isSyncActive = isSyncDeviceBrowseActive() || (!isLocalMode() && !!cameraPoolCache && pool === cameraPoolCache && (currentPath === syncDeviceFolder || currentPath.startsWith(syncDeviceFolder + '/')));
  const mkPill = (cfg) => {
    const b = document.createElement('button');
    let isActive = false;
    if (cfg.id === 'sync_device_folder') {
      isActive = isSyncActive;
    } else if (cfg.id === LOCAL_POOL) {
      isActive = isLocalMode();
    } else {
      isActive = !isSyncActive && !isLocalMode() && cfg.id === pool;
    }
    b.className = 'pool-pill' + (isActive ? ' active' : '') + (cfg.offline ? ' offline' : '');
    b.innerHTML = cfg.html;
    b.addEventListener('click', cfg.onClick);
    bar.appendChild(b);
  };
  mkPill({
    id: 'drive_picker',
    html: iconSvg('i-server', 'svg-18') + '<span>Chọn ổ đĩa</span><span aria-hidden="true">⌄</span>',
    onClick: openDrivePicker,
  });
  mkPill({
    id: LOCAL_POOL,
    html: iconSvg('i-phone', 'svg-18') + '<span>Thiết bị này</span>' + (localFree ? '<span class="pf">' + esc(localFree) + '</span>' : ''),
    onClick: () => switchPool(LOCAL_POOL),
  });
  mkPill({
    id: 'sync_device_folder',
    html: iconSvg('i-sync', 'svg-18') + '<span>Đồng bộ (' + esc(syncDeviceFolder) + ')</span>',
    onClick: openSyncDeviceFolder,
  });
  const rawList = pools && pools.length ? pools : (pool && pool !== LOCAL_POOL ? [{ id: pool, name: poolNameOf(pool), online: true }] : []);
  const list = rawList.filter(p => !isSharedPool(p));
  if (isSharedPool(pool) && list.length) {
    pool = list[0].id;
  }
  list.forEach((p) => {
    const free = p.free != null ? 'trống ' + fmtBytes(p.free) : '';
    mkPill({
      id: p.id,
      offline: p.online === false,
      html: (isPoolLocked(p.id) ? iconSvg('i-lock', 'svg-18') : iconSvg('i-server', 'svg-18')) + '<span>' + esc(p.name) + '</span>' + (free ? '<span class="pf">' + esc(free) + '</span>' : ''),
      onClick: () => {
        if (p.online === false) { DC.toast('Ổ "' + p.name + '" đang không khả dụng trên máy chủ.'); return; }
        if (isPoolLocked(p.id)) { unlockSheet(poolTargetOf(p.id), () => switchPool(p.id)); return; }
        switchPool(p.id);
      },
    });
  });
}

function refreshLocalFree() {
  callNative('localFsInfo', '').then((r) => {
    if (r && r.rootPath && !localRootPath) localRootPath = r.rootPath;
    if (r && r.free != null) {
      localFreeBytes = Number(r.free || 0);
      localTotalBytes = Number(r.total || r.capacity || 0);
      localFree = 'trống ' + fmtBytes(r.free);
      renderPoolBar();
    }
  }).catch(() => {});
}

async function ensureLocalFsAccess() {
  try {
    const st = await callNative('localFsStatus', '');
    if (st && st.ok) {
      localDrive = { fs: true, name: 'Thiết bị này' };
      kvSet(kLocalDrive(), localDrive);
      refreshLocalFree();
      return true;
    }
    await callNative('requestLocalFsAccess', '');
    DC.toast('Sau khi cấp quyền, quay lại đây và bấm "Thiết bị này" lần nữa.');
    return false;
  } catch (e) {
    DC.toast(errText(e));
    return false;
  }
}

function pollLocalFsAfterResume() {
  if (pool !== LOCAL_POOL || (localDrive && localDrive.fs)) return;
  callNative('localFsStatus', '').then((st) => {
    if (st && st.ok) {
      localDrive = { fs: true, name: 'Thiết bị này' };
      kvSet(kLocalDrive(), localDrive);
      refreshLocalFree();
      if (pool === LOCAL_POOL) loadLocalFiles();
    }
  }).catch(() => {});
}
function refreshFavsAfterResume() {
  favs = kvGet(kFavs()) || [];
  if (currentView === 'favorites') renderFavorites();
}
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    pauseOverviewThumbnailWork();
  } else {
    pollLocalFsAfterResume();
    refreshFavsAfterResume();
    resumeOverviewThumbnailWork();
  }
});
window.addEventListener('focus', refreshFavsAfterResume);

function switchPool(id) {
  syncDeviceBrowse = null;
  pool = id;
  currentPath = '';
  parentPath = null;
  entries = [];
  if (pool === LOCAL_POOL) localNav = [];
  exitSelMode();
  updateFabVisibility();
  renderPoolBar();
  loadFiles('');
}

function renderLockedPoolState() {
  const list = $('#files .file-list');
  list.innerHTML = '';
  const d = document.createElement('div');
  d.className = 'empty';
  d.style.paddingTop = '60px';
  d.innerHTML = '<div style="color:var(--blue)">' + iconSvg('i-lock', 'svg-38') + '</div><div style="margin-top:14px">Ổ đĩa "' + esc(poolNameOf(pool)) + '" đang bị khóa.</div>';
  const btn = document.createElement('button');
  btn.className = 'btn primary';
  btn.style.cssText = 'width:auto;padding:0 22px;margin:18px auto 0;display:block';
  btn.textContent = 'Mở khóa bằng mật khẩu';
  btn.addEventListener('click', () => unlockSheet(poolTargetOf(pool), () => loadFiles('')));
  d.appendChild(btn);
  list.appendChild(d);
  const bc = $('#files .breadcrumb');
  if (bc) bc.innerHTML = '<span class="root">' + esc(server ? server.name : 'CW Datacenter') + '</span><span>›</span><span class="now">Ổ đĩa đang khóa</span>';
}

function updateLockUI() {
  renderPoolBar();
  if (currentView === 'files') {
    if (isPoolLocked(pool)) renderLockedPoolState();
    else renderFiles();
  }
}

/* ========== PREVIEW (xem trực tiếp trong app, stream từ server) ========== */
const STREAM_IMG = /\.(png|jpe?g|gif|webp|bmp|avif|svg|heic|heif)$/i;
const STREAM_VIDEO = /\.(mp4|webm|mkv|mov|m4v|avi|3gp|3gpp|flv|wmv|mpg|mpeg|ts|m2ts|mts|vob|ogv|rm|rmvb)$/i;
const STREAM_AUDIO = /\.(mp3|wav|wave|ogg|oga|opus|m4a|aac|flac|alac|wma|amr)$/i;
const STREAM_PDF = /\.pdf$/i;
const STREAM_BOOK = /\.(epub|fb2|txt|html?|md)$/i;
const STREAM_TEXT = /\.(txt|md|log|json|csv|tsv|xml|yml|yaml|ini|srt|vtt|js|css|html|c|cpp|h|py|sh|bat)$/i;
function isPreviewable(name) { return STREAM_IMG.test(name) || STREAM_VIDEO.test(name) || STREAM_AUDIO.test(name) || STREAM_PDF.test(name) || STREAM_BOOK.test(name) || STREAM_TEXT.test(name); }

function ePool(e) { return (e && e.pool) ? e.pool : pool; }

function fileApiUrl(rel, extra, poolId) {
  const p = poolId != null ? poolId : pool;
  return server.baseUrl + '/api/file?path=' + enc(rel) + (extra || '') + (p && p !== LOCAL_POOL ? '&pool=' + enc(p) : '');
}

function mediaProxyUrl(rel, video, poolId) {
  const p = poolId != null ? poolId : pool;
  // AVPlayer streams byte ranges directly from Host. The local proxy remains
  // for images/thumbnails, but must not buffer playlist video responses.
  if (video && IS_IOS && server) {
    return server.baseUrl + '/api/video?raw=1&ios=1&path=' + enc(rel) +
      (p && p !== LOCAL_POOL ? '&pool=' + enc(p) : '') +
      (token ? '&token=' + enc(token) : '');
  }
  try {
    const u = DC.proxyUrl(enc(rel), p && p !== LOCAL_POOL ? enc(p) : '', video);
    if (u) return u;
  } catch (e) {}
  return video
    ? (server.baseUrl + '/api/video?path=' + enc(rel) + (p && p !== LOCAL_POOL ? '&pool=' + enc(p) : ''))
    : fileApiUrl(rel, '&preview=1', p);
}

function localDocUrl(e) {
  if (!e || !e._p) return '';
  try {
    return String(DC.localFsUrl(JSON.stringify({ p: e._p, mime: e._mime || '' })) || '');
  } catch (err) { return ''; }
}

function localSpec(e) {
  return { p: e._p, name: e.name || '', mime: e._mime || '' };
}


let previewEntry = null;
let previewList = [];
let previewIdx = -1;

function isMediaEntry(name) { return STREAM_IMG.test(name) || STREAM_VIDEO.test(name) || STREAM_AUDIO.test(name); }

function previewMediaList() {
  return displayEntries().filter((e) => e.type === 'file' && isMediaEntry(e.name));
}

function launchMusicPlayer(e, localMode) {
  const list = displayEntries().filter((x) => x.type === 'file' && STREAM_AUDIO.test(x.name));
  let index = list.findIndex((x) => (x._p && e._p ? x._p === e._p : relOf(x) === relOf(e)));
  if (index < 0) index = 0;
  const playlist = list.map((x) => {
    const p = ePool(x);
    return {
      name: x.name,
      size: x.size || 0,
      url: localMode ? (localDocUrl(x) || '') : '',
      rel: localMode ? '' : relOf(x),
      pool: localMode ? '' : p
    };
  // Tệp trên Host dùng đường dẫn tương đối `rel`; chỉ tệp trong "Thiết bị này"
  // mới có file URL. Bản 1.5.3 vô tình loại toàn bộ bài hát trên Host ở đây.
  }).filter((x) => !!x.url || !!x.rel);
  if (!playlist.length) { DC.toast('Không mở được tệp nhạc này.'); return; }
  const selectedName = e.name;
  const adjustedIndex = Math.max(0, playlist.findIndex((x) => x.name === selectedName));
  callNative('playAudio', JSON.stringify({
    name: e.name,
    url: localMode ? (localDocUrl(e) || '') : '',
    rel: localMode ? '' : relOf(e),
    pool: localMode ? '' : ePool(e),
    baseUrl: server ? server.baseUrl : '',
    token: token || '',
    size: e.size || 0,
    plIndex: adjustedIndex,
    playlist
  })).catch((er) => DC.toast(errText(er)));
}

function updatePvNav() {
  const prevBtn = $('#pvPrev');
  const nextBtn = $('#pvNext');
  const has = previewList.length > 1 && isMediaEntry(previewEntry ? previewEntry.name : '');
  prevBtn.disabled = !(has && previewIdx > 0);
  nextBtn.disabled = !(has && previewIdx < previewList.length - 1);
}

function fmtTime(ms) {
  if (!ms || ms <= 0) return '00:00';
  let s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  s %= 3600;
  const m = Math.floor(s / 60);
  const ss = s % 60;
  if (h > 0) {
    return `${h}:${m < 10 ? '0' : ''}${m}:${ss < 10 ? '0' : ''}${ss}`;
  }
  return `${m < 10 ? '0' : ''}${m}:${ss < 10 ? '0' : ''}${ss}`;
}

let pendingResumeVideo = null;

function compactResumeFileName(value, maxLength = 34) {
  const name = String(value || 'Video');
  if (name.length <= maxLength) return name;
  const dot = name.lastIndexOf('.');
  const extension = dot > 0 && name.length - dot <= 10 ? name.slice(dot) : '';
  const headLength = Math.max(10, maxLength - extension.length - 1);
  return name.slice(0, headLength) + '…' + extension;
}

function showVideoResumePrompt(e, rel, p, plIdx, playlist, pos) {
  pendingResumeVideo = { e, rel, p, plIdx, playlist, pos };
  const modal = $('#videoResumeModal');
  if (!modal) {
    launchMobileVideo(e, rel, p, plIdx, playlist, -1);
    return;
  }
  const resumeTitle = $('#vrTitle');
  resumeTitle.textContent = compactResumeFileName(e && e.name);
  resumeTitle.title = String(e && e.name || '');
  $('#vrSub').innerHTML = `Bạn đã xem video này đến <b>${fmtTime(pos)}</b>.<br>Bạn muốn xem tiếp hay phát lại từ đầu?`;
  $('#vrResumeLabel').textContent = `▶ Xem tiếp (từ ${fmtTime(pos)})`;
  modal.style.display = 'flex';
}

function closeVideoResumeModal() {
  const modal = $('#videoResumeModal');
  if (modal) modal.style.display = 'none';
  pendingResumeVideo = null;
}

function launchMobileVideo(e, rel, p, plIdx, playlist, startPos) {
  const isIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent) || (window.webkit && window.webkit.messageHandlers);
  const directUrl = isIOS && server ? `${server.baseUrl}/api/video?raw=1&ios=1&path=${enc(rel)}${p ? '&pool=' + enc(p) : ''}${token ? '&token=' + enc(token) : ''}` : '';
  callNative('playVideo', JSON.stringify({
    url: directUrl,
    baseUrl: server ? server.baseUrl : '',
    token: token || '',
    rel,
    pool: p && p !== LOCAL_POOL ? p : '',
    name: e.name,
    size: e.size || 0,
    favorite: favs.some((fav) => String(fav.rel || '') === String(rel || '') && String(fav.pool || 'main') === String(p || 'main')),
    startPos: startPos != null ? startPos : -1,
    plIndex: plIdx != null ? plIdx : 0,
    playlist: playlist,
    subtitleCandidates: subtitleCandidatesInCurrentFolder()
  })).catch((er) => DC.toast(errText(er)));
}

// Không bao giờ quét toàn host: danh sách này chỉ lấy từ thư mục đang mở.
function subtitleCandidatesInCurrentFolder() {
  return (Array.isArray(entries) ? entries : [])
    .filter((x) => x && x.type !== 'dir' && /\.(srt|vtt|ass)$/i.test(x.name || ''))
    .map((x) => ({
      name: x.name || '',
      url: x._local ? localDocUrl(x) : mediaProxyUrl(relOf(x), false, ePool(x))
    }))
    .filter((x) => x.name && x.url);
}

function openPreview(e) {
  if (e && e._local) { openLocalPreview(e); return; }
  const rel = relOf(e);
  const name = e.name;
  const p = ePool(e);
  rememberOverviewFile({ name, rel, pool: p, size: e.size || 0, mtime: e.mtime || e.modified || '', type: 'file' });
  previewEntry = e;
  previewList = previewMediaList();
  previewIdx = previewList.findIndex((x) => x.name === e.name);
  if (previewIdx < 0) { previewList = [e]; previewIdx = 0; }
  if (STREAM_VIDEO.test(name)) {
    rememberOverviewVideo({ name, rel, pool: p, size: e.size || 0, at: Date.now() });
    let pl = undefined;
    let adjustedPlIndex = 0;
    if (previewList && previewList.length > 1) {
      const windowSize = 60;
      const startIdx = Math.max(0, previewIdx - 30);
      const endIdx = Math.min(previewList.length, startIdx + windowSize);
      const slice = previewList.slice(startIdx, endIdx);
      adjustedPlIndex = previewIdx - startIdx;
      pl = slice.map((x) => {
        const xp = ePool(x);
        const xRel = relOf(x);
        const u = mediaProxyUrl(xRel, true, xp);
        const thumbUrl = mediaThumbUrl({ name: x.name, rel: xRel, pool: xp, size: x.size || 0, mtime: x.mtime || x.modified || '' }, 160);
        return {
          name: x.name,
          url: u,
          thumbUrl,
          size: x.size || 0,
          rel: xRel,
          pool: xp || 'main',
          mtime: x.mtime || x.modified || '',
          favorite: favs.some((fav) => String(fav.rel || '') === String(xRel || '') && String(fav.pool || 'main') === String(xp || 'main'))
        };
      });
    }

    const directUrl = server ? `${server.baseUrl}/api/video?path=${enc(rel)}${p ? '&pool=' + enc(p) : ''}` : '';
    (async () => {
      try {
        const remote = await api('/api/watch-progress?pool=' + enc(p || 'main') + '&path=' + enc(rel));
        const remotePos = Number(remote && remote.item && remote.item.positionMs || 0);
        if (remotePos > 5000) showVideoResumePrompt(e, rel, p, adjustedPlIndex, pl, remotePos);
        else launchMobileVideo(e, rel, p, adjustedPlIndex, pl, 0);
      } catch (remoteError) {
        callNative('getVideoProgress', JSON.stringify({ name: e.name, url: directUrl })).then((res) => {
          if (res && res.pos > 5000) showVideoResumePrompt(e, rel, p, adjustedPlIndex, pl, res.pos);
          else launchMobileVideo(e, rel, p, adjustedPlIndex, pl, -1);
        }).catch(() => launchMobileVideo(e, rel, p, adjustedPlIndex, pl, -1));
      }
    })();
    return;
  }
  if (STREAM_PDF.test(name)) { openNativePdf(e, rel, p); return; }
  if (STREAM_BOOK.test(name)) { openNativeBook(e, rel, p); return; }
  if (STREAM_IMG.test(name)) {
    const imageList = displayEntries().filter((x) => x.type === 'file' && STREAM_IMG.test(x.name));
    let rawIdx = imageList.findIndex((x) => x.name === e.name);
    if (rawIdx < 0) rawIdx = 0;
    const windowSize = 80;
    const startIdx = Math.max(0, rawIdx - 40);
    const endIdx = Math.min(imageList.length, startIdx + windowSize);
    const slice = imageList.slice(startIdx, endIdx);
    const adjustedIdx = rawIdx - startIdx;
    const playlist = slice.map((x) => {
      const xp = ePool(x);
      const xRel = relOf(x);
      const directUrl = mediaPreviewUrl({ rel: xRel, pool: xp, size: x.size || 0, mtime: x.mtime || x.modified || '' });
      const thumbUrl = mediaThumbUrl({ name: x.name, rel: xRel, pool: xp, size: x.size || 0, mtime: x.mtime || x.modified || '' }, 160);
      return {
        name: x.name,
        url: directUrl,
        thumbUrl: thumbUrl,
        size: x.size || 0,
        rel: xRel,
        pool: xp,
        mtime: x.mtime || '',
        favorite: favs.some((fav) => fav.rel === xRel)
      };
    });
    const directUrl = server ? (server.baseUrl + '/api/file?path=' + enc(rel) + '&pool=' + enc(p) + '&preview=1') : '';
    const thumbUrl = server ? (server.baseUrl + '/api/thumb?path=' + enc(rel) + '&pool=' + enc(p) + '&size=160') : '';
    callNative('openPhoto', JSON.stringify({
      url: directUrl,
      thumbUrl,
      name,
      token,
      playlist,
      initialIndex: adjustedIdx,
      baseUrl: server ? server.baseUrl : '',
      pool: p
    })).catch((er) => DC.toast(errText(er)));
    return;
  }
  const modal = $('#pvModal');
  const stage = $('#pvStage');
  $('#pvTitle').textContent = name + (e.size ? ' · ' + fmtBytes(e.size) : '');
  stage.innerHTML = '<div class="pv-loading">Đang tải…</div>';
  modal.classList.add('show');
  updatePvNav();
  if (STREAM_AUDIO.test(name)) {
    modal.classList.remove('show');
    launchMusicPlayer(e, false);
    return;
  }
  if (STREAM_PDF.test(name)) { localOpenWith(e); return; }
  if (STREAM_TEXT.test(name)) { renderText(stage, rel, p); return; }
  stage.innerHTML = '<div class="pv-err">Loại tệp này chưa hỗ trợ xem trực tiếp.</div>';
}

function openLocalPreview(e) {
  const name = e.name;
  previewEntry = e;
  previewList = [e]; previewIdx = 0;
  if (STREAM_VIDEO.test(name)) {
    const url = localDocUrl(e);
    if (url) callNative('playVideo', JSON.stringify({
      url, name, size: e.size || 0,
      subtitleCandidates: subtitleCandidatesInCurrentFolder()
    })).catch((er) => DC.toast(errText(er)));
    else DC.toast('Không mở được tệp này.');
    return;
  }
  if (STREAM_PDF.test(name)) { openNativePdfLocal(e); return; }
  if (STREAM_IMG.test(name)) {
    const imageList = displayEntries().filter((x) => x.type === 'file' && STREAM_IMG.test(x.name));
    let rawIdx = imageList.findIndex((x) => x.name === e.name);
    if (rawIdx < 0) rawIdx = 0;
    const windowSize = 80;
    const startIdx = Math.max(0, rawIdx - 40);
    const endIdx = Math.min(imageList.length, startIdx + windowSize);
    const slice = imageList.slice(startIdx, endIdx);
    const adjustedIdx = rawIdx - startIdx;
    const playlist = slice.map((x) => ({
      name: x.name,
      localPath: x._p || '',
      url: localDocUrl(x) || '',
      size: x.size || 0,
      mtime: x.mtime || x.modified || '',
      local: true
    }));
    callNative('openPhoto', JSON.stringify({
      localPath: e._p || '',
      url: localDocUrl(e) || '',
      name,
      playlist,
      initialIndex: adjustedIdx,
      baseUrl: server ? server.baseUrl : ''
    })).catch((er) => DC.toast(errText(er)));
    return;
  }
  const modal = $('#pvModal');
  const stage = $('#pvStage');
  $('#pvTitle').textContent = name + (e.size ? ' · ' + fmtBytes(e.size) : '');
  stage.innerHTML = '<div class="pv-loading">Đang tải…</div>';
  modal.classList.add('show');
  updatePvNav();
  const url = localDocUrl(e);
  if (!url) { stage.innerHTML = '<div class="pv-err">Không mở được tệp này.</div>'; return; }
  if (STREAM_AUDIO.test(name)) {
    modal.classList.remove('show');
    launchMusicPlayer(e, true);
    return;
  }
  if (STREAM_PDF.test(name)) { localOpenWith(e); return; }
  if (STREAM_TEXT.test(name)) { renderLocalText(stage, url); return; }
  stage.innerHTML = '<div class="pv-err">Loại tệp này chưa hỗ trợ xem trực tiếp.</div>';
}

/* Mở PDF bằng trình đọc AndroidPdfViewer trong app (không tải về máy).
 * - PDF trên server: đọc qua proxy cục bộ (url) — PdfViewerActivity tự tải vào cache 1 lần.
 * - PDF trên bộ nhớ máy ("Thiết bị này"): mở thẳng bằng đường dẫn/uri. */
function openNativePdf(e, rel, poolId) {
  const p = poolId != null ? poolId : ePool(e);
  const spec = { rel, pool: p && p !== LOCAL_POOL ? p : '', name: e.name, size: e.size || 0 };
  callNative('openPdf', JSON.stringify(spec)).catch((er) => {
    DC.toast('Không mở được PDF: ' + errText(er));
    openOrFetch(e);
  });
}
function openNativePdfLocal(e) {
  const spec = { name: e.name };
  if (e._p) spec.path = e._p;
  callNative('openPdf', JSON.stringify(spec)).catch((er) => {
    DC.toast('Không mở được PDF: ' + errText(er));
    localOpenWith(e);
  });
}

function openNativeBook(e, rel, poolId) {
  const p = poolId != null ? poolId : ePool(e);
  if (!server || !server.baseUrl) { DC.toast('Cần kết nối Host để mở sách.'); return; }
  const file = server.baseUrl + '/api/file?path=' + enc(rel) + (p && p !== LOCAL_POOL ? '&pool=' + enc(p) : '') + '&preview=1' + (token ? '&token=' + enc(token) : '');
  const viewerUrl = server.baseUrl + '/book-reader.html?native=1&file=' + enc(file) + '&path=' + enc(rel) + '&pool=' + enc(p || 'main') + '&name=' + enc(e.name || 'Sách') + (token ? '&token=' + enc(token) : '');
  callNative('openPdf', JSON.stringify({ viewerUrl, name: e.name || 'Sách' })).catch((er) => DC.toast('Không mở được sách: ' + errText(er)));
}

async function renderText(stage, rel, poolId) {
  const p = poolId != null ? poolId : pool;
  try {
    const r = await callNative('invoke', 'GET', fileApiUrl(rel, '&preview=1', p), JSON.stringify(token ? { Authorization: 'Bearer ' + token } : {}), '');
    if (!stage.isConnected || !$('#pvModal').classList.contains('show')) return;
    if (r.status >= 400) throw r;
    let text = r.text || '';
    if (text.length > 512 * 1024) text = text.slice(0, 512 * 1024) + '\n\n…(tệp lớn, đã cắt bớt)…';
    const pre = document.createElement('pre');
    pre.textContent = text || '(tệp trống)';
    stage.innerHTML = '';
    stage.appendChild(pre);
  } catch (e) {
    stage.innerHTML = '<div class="pv-err">Không đọc được tệp này.</div>';
  }
}

async function renderLocalText(stage, url) {
  try {
    const resp = await fetch(url);
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    let text = await resp.text();
    if (text.length > 512 * 1024) text = text.slice(0, 512 * 1024) + '\n\n…(tệp lớn, đã cắt bớt)…';
    const pre = document.createElement('pre');
    pre.textContent = text || '(tệp trống)';
    stage.innerHTML = '';
    stage.appendChild(pre);
  } catch (e) {
    stage.innerHTML = '<div class="pv-err">Không đọc được tệp này.</div>';
  }
}

function pvNav(delta) {
  if (!isMediaEntry(previewEntry ? previewEntry.name : '')) return;
  const idx = previewIdx + delta;
  if (idx < 0 || idx >= previewList.length) return;
  openPreview(previewList[idx]);
}

function pvSetupSwipe() {
  const stage = $('#pvStage');
  let sx = 0, sy = 0, st = 0, swiping = false;
  stage.addEventListener('touchstart', (ev) => {
    if ((ev.touches && ev.touches.length !== 1)) return;
    const t = (ev.touches && ev.touches[0]) || ev;
    sx = t.clientX; sy = t.clientY; st = Date.now(); swiping = true;
  }, { passive: true });
  stage.addEventListener('touchend', (ev) => {
    if (!swiping) return;
    swiping = false;
    const t = (ev.changedTouches && ev.changedTouches[0]) || ev;
    const dx = t.clientX - sx, dy = t.clientY - sy, dt = Date.now() - st;
    if (Math.abs(dx) > 48 && Math.abs(dy) < Math.abs(dx) * 0.8 && dt < 700) {
      if (dx < 0) pvNav(1); else pvNav(-1);
    }
  }, { passive: true });
  $('#pvPrev').addEventListener('click', () => pvNav(-1));
  $('#pvNext').addEventListener('click', () => pvNav(1));
}
pvSetupSwipe();

function closePreview() {
  const stage = $('#pvStage');
  if (stage) {
    stage.querySelectorAll('video, audio').forEach((m) => { try { m.pause(); } catch (e) {} m.removeAttribute('src'); try { m.load(); } catch (e) {} });
    stage.innerHTML = '';
  }
  previewEntry = null;
  previewList = []; previewIdx = -1;
  updatePvNav();
  $('#pvModal').classList.remove('show');
}
$('#pvMore').addEventListener('click', () => {
  const e = previewEntry;
  if (!e) return;
  openFileSheet(e);
});
$('#pvDl').addEventListener('click', () => {
  const e = previewEntry;
  closePreview();
  if (e) {
    if (e._local) { localDownloadEntry(e); }
    else startDownloadFor(e);
  }
});
const pvCloseBtn = $('#pvClose');
if (pvCloseBtn) {
  pvCloseBtn.addEventListener('click', () => closePreview());
}

/* ---------- API ---------- */
async function api(path, method, body) {
  const headers = token ? { Authorization: 'Bearer ' + token } : {};
  const r = await callNative('invoke', method || 'GET', server.baseUrl + path, JSON.stringify(headers), body ? JSON.stringify(body) : '');
  let data;
  try { data = r.text ? JSON.parse(r.text) : {}; } catch (e) { data = { error: 'Phản hồi không hợp lệ (HTTP ' + r.status + ')' }; }
  if (data && typeof data === 'object') data.status = Number(r.status || 0);
  if (r.status === 401 && token) { onSessionLost(); throw data; }
  if (r.status === 423 && data.lock && /^\/api\/(files|item\/info)(?:\?|$)/.test(path)) {
    const l = data.lock, lp = String(l.path || ''), slash = lp.lastIndexOf('/');
    const target = { kind: l.type === 'drive' ? 'pool' : l.type, type: l.type === 'folder' ? 'dir' : 'file',
      pool: l.pool, name: l.type === 'drive' ? (l.name || l.pool) : lp.slice(slash + 1),
      dirRel: slash < 0 ? '' : lp.slice(0, slash), _rel: lp, _serverLockId: l.id };
    await new Promise((resolve, reject) => unlockSheet(target, resolve, () => reject(data)));
    return api(path, method, body);
  }
  if (r.status >= 400) throw data;
  return data;
}

async function tryApi(baseUrl, path, method, body, tk) {
  const headers = tk ? { Authorization: 'Bearer ' + tk } : {};
  const r = await callNative('invoke', method || 'GET', baseUrl + path, JSON.stringify(headers), body ? JSON.stringify(body) : '');
  let data;
  try { data = r.text ? JSON.parse(r.text) : {}; } catch (e) { data = {}; }
  if (r.status >= 400) throw data;
  return data;
}

/* ---------- Views ---------- */
const views = $$('.view');
const bottomNav = $('#bottomNav');
function go(id) {
  if (id !== 'overview') exitOverviewGallerySelection();
  currentView = id;
  views.forEach((v) => v.classList.toggle('active', v.id === id));
  const main = ['overview', 'files', 'transfers', 'favorites', 'sync', 'trash'].includes(id);
  bottomNav.style.display = main ? 'grid' : 'none';
  DC.setCanGoBack(id !== 'discover');
  if (id !== 'files') exitSelMode();
  if (typeof updatePasteFab === 'function') updatePasteFab();
}

$$('.nav-btn').forEach((btn) => btn.addEventListener('click', () => {
  if (btn.dataset.target === 'more') { openMoreSheet(); return; }
  activateMainView(btn.dataset.target);
}));

function handleBack() {
  if (sheetModal.classList.contains('show')) { closeSheet(); return; }
  if (overviewGallerySelectionMode) { exitOverviewGallerySelection(); return; }
  if (selMode) { exitSelMode(); return; }
  if ($('#pvModal').classList.contains('show')) { closePreview(); return; }
  if (currentView === 'signin') { go('discover'); return; }
  if (currentView === 'offlineView') { go('discover'); refreshOfflineCountBadge(); return; }
  if (currentView === 'trust') { go('signin'); return; }
  if (currentView !== 'overview' && ['files', 'transfers', 'favorites', 'sync', 'trash'].includes(currentView)) {
    activateMainView('overview');
    return;
  }
  if (currentView === 'files' && isLocalMode()) {
    if (goLocalBack()) return;
    callNative('exitApp', '').catch(() => {});
    return;
  }
  if (currentView === 'files' && currentPath) { goDir(parentPath || ''); return; }
  if (currentView === 'files') { switchPool(LOCAL_POOL); return; }
  if (currentView === 'discover') callNative('exitApp', '').catch(() => {});
}

/* ---------- Bottom sheet ---------- */
const sheetModal = document.createElement('div');
sheetModal.className = 'modal';
sheetModal.innerHTML = '<div class="sheet"><div class="handle"></div><h3 id="asTitle"></h3><div id="asBody"></div></div>';
document.querySelector('.app-shell').appendChild(sheetModal);
const style = document.createElement('style');
style.textContent = '.as-item{padding:14px 4px;border-bottom:1px solid var(--line-soft);font-size:14.5px;color:#1f2937;cursor:pointer;display:flex;align-items:center;gap:10px}'
  + '.as-item:last-child{border-bottom:0}.as-item.danger{color:var(--red)}'
  + '.dot.offline{background:#f97316!important}'
  + '.empty{padding:26px 12px;text-align:center;color:#98a2b3;font-size:13px;line-height:1.6}'
  + '.pill.gray{background:#f5f7fa;color:#667085}.pill.yellow{background:#fff8e6;color:#b45309}'
  + '.conn-info{color:#98a2b3;font-size:11px;margin-left:auto}'
  + '.item-info-grid{display:grid;grid-template-columns:96px minmax(0,1fr);gap:12px 10px;padding:4px 0 12px;font-size:13.5px}'
  + '.item-info-grid b{color:#667085;font-weight:500}.item-info-grid span{color:#111827;overflow-wrap:anywhere}'
  + '.item-info-grid .info-copyable{border-radius:7px;transition:background .16s ease,transform .16s ease}.item-info-grid .info-copyable.copy-holding{background:#eaf4ff;transform:scale(.98)}';
document.head.appendChild(style);

function openSheet(title, build) {
  $('#asTitle').textContent = title || '';
  const body = $('#asBody');
  body.innerHTML = '';
  body.className = '';
  body.removeAttribute('style');
  build(body);
  sheetModal.classList.add('show');
  if (typeof updateSelFab === 'function') updateSelFab();
  if (typeof updatePasteFab === 'function') updatePasteFab();
  if (typeof updateOverviewGallerySelectionChip === 'function') updateOverviewGallerySelectionChip();
}
function closeSheet() { sheetModal.classList.remove('show'); if (typeof updateSelFab === 'function') updateSelFab(); if (typeof updatePasteFab === 'function') updatePasteFab(); if (typeof updateOverviewGallerySelectionChip === 'function') updateOverviewGallerySelectionChip(); }
sheetModal.addEventListener('click', (e) => { if (e.target === sheetModal) closeSheet(); });

/* Nút nổi "Đã chọn N mục": khi đang ở chế độ chọn nhiều mà bảng thao tác đã đóng,
 * bấm vào để mở lại bảng thay vì phải nhấn giữ lại từ đầu. */
const selChip = document.createElement('button');
selChip.className = 'sel-fab';
document.querySelector('.app-shell').appendChild(selChip);
selChip.addEventListener('click', () => { if (selMode && selectedSet.size) openSelSheet(); });
function updateSelFab() {
  const show = selMode && selectedSet.size > 0 && currentView === 'files' && !sheetModal.classList.contains('show');
  selChip.style.display = show ? 'flex' : 'none';
  if (show) {
    selChip.textContent = 'Đã chọn ' + selectedSet.size + ' mục';
    selChip.style.left = '';
    selChip.style.right = '';
    /* Nếu nút Paste đang hiện thì đẩy nút "Đã chọn N mục" lên trên cho khỏi chồng. */
    const pasteVisible = typeof clipboard !== 'undefined' && clipboard.items.length > 0;
    selChip.style.bottom = pasteVisible ? 'calc(144px + var(--sab,env(safe-area-inset-bottom,0px)))' : '';
  }
}

function sheetItem(parent, label, opts) {
  const d = document.createElement('div');
  d.className = 'as-item' + (opts && opts.danger ? ' danger' : '') + (opts && opts.active ? ' active' : '');
  let content = (opts && opts.icon ? iconSvg(opts.icon, 'svg-20') : '');
  content += '<div style="flex:1;min-width:0"><div style="font-weight:500;display:flex;align-items:center;justify-content:space-between">' + esc(label);
  if (opts && opts.badge) {
    content += '<span class="pill ' + (opts.badgeClass || 'blue') + '" style="font-size:11px;padding:3px 8px;margin-left:6px">' + esc(opts.badge) + '</span>';
  }
  content += '</div>';
  if (opts && opts.sub) {
    content += '<div style="font-size:11.5px;color:#667085;margin-top:2px">' + esc(opts.sub) + '</div>';
  }
  content += '</div>';
  if (opts && opts.active) {
    content += '<div style="color:var(--blue);font-weight:bold;font-size:15px;margin-left:8px">✓</div>';
  }
  d.innerHTML = content;
  d.addEventListener('click', () => { closeSheet(); opts && opts.onClick && opts.onClick(); });
  parent.appendChild(d);
  return d;
}

function activateMainView(id) {
  $$('.nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.target === id));
  go(id);
  if (id === 'overview') renderOverview();
  if (id === 'files') { if (isLocalMode()) loadLocalFiles(); else loadFiles(currentPath); }
  if (id === 'transfers') renderTransfers();
  if (id === 'favorites') renderFavorites();
  if (id === 'sync') {
    renderSync();
    if (IS_IOS) refreshIOSCameraStats(true);
  }
  if (id === 'trash') loadTrash();
}

function openMoreSheet() {
  openSheet('Khác', (body) => {
    sheetItem(body, 'Truyền tải', { icon: 'i-transfer', onClick: () => activateMainView('transfers') });
    sheetItem(body, 'Thùng rác', { icon: 'i-trash', onClick: () => activateMainView('trash') });
    sheetItem(body, 'Cài đặt', { icon: 'i-settings', onClick: openDiscoverSettingsSheet });
  });
}

function overviewRecentKey() { return 'overviewRecent:' + (server ? server.baseUrl : ''); }
function overviewVideoKey() { return 'overviewVideos:' + (server ? server.baseUrl : ''); }

function normalizeQuickFolders(list) {
  return Array.isArray(list) ? list.filter((x) => x && x.path && x.pool).slice(0, 4) : [];
}

function saveQuickFolders(list) {
  const user = overviewAccount();
  if (!user || !server) return;
  kvSet(kQuickFolders(), { version: 2, user, server: overviewServer(), items: normalizeQuickFolders(list), updatedAt: Date.now() });
}

function quickFolders() {
  const user = overviewAccount();
  if (!user || !server) return [];
  const scoped = kvGet(kQuickFolders());
  if (scoped && !Array.isArray(scoped) && scoped.user === user) return normalizeQuickFolders(scoped.items);
  if (Array.isArray(scoped)) { saveQuickFolders(scoped); return normalizeQuickFolders(scoped); }
  const owner = String(kvGet(kQuickFoldersLegacyOwner()) || '').toLowerCase();
  const legacy = normalizeQuickFolders(kvGet(legacyKQuickFolders()));
  if (!owner && legacy.length) {
    saveQuickFolders(legacy);
    kvSet(kQuickFoldersLegacyOwner(), user);
    return legacy;
  }
  return [];
}

function openQuickFolderPicker(slot) {
  const current = (!isLocalMode() && currentPath) ? { path: currentPath, pool, name: currentPath.split('/').pop() || currentPath } : null;
  const recent = kvGet(overviewRecentKey()) || [];
  const candidates = [];
  [current].concat(recent).filter(Boolean).forEach((x) => {
    if (!candidates.some((y) => y.path === x.path && y.pool === x.pool)) candidates.push(x);
  });
  const overlay = document.createElement('div');
  overlay.className = 'quick-folder-overlay';
  overlay.innerHTML = '<section class="quick-folder-dialog" role="dialog" aria-modal="true"><header><h2>Chọn thư mục nhanh</h2><button type="button" class="quick-folder-close">×</button></header><div class="quick-folder-list"></div></section>';
  const list = overlay.querySelector('.quick-folder-list');
  if (!candidates.length) list.innerHTML = '<div class="empty">Hãy mở một thư mục trong tab Tệp trước, sau đó quay lại đây để thêm.</div>';
  else candidates.slice(0, 12).forEach((item) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'quick-folder-choice';
    button.innerHTML = '<span>' + iconSvg('i-folder', 'svg-22') + '</span><div><b>' + esc(item.name || item.path) + '</b><small>' + esc(item.path) + '</small></div>';
    button.addEventListener('click', () => {
      const saved = quickFolders().filter((x) => x.path !== item.path || x.pool !== item.pool);
      saved.splice(Math.max(0, Math.min(slot, saved.length)), 0, { path: item.path, pool: item.pool, name: item.name || item.path.split('/').pop() });
      saveQuickFolders(saved);
      overlay.remove();
      renderQuickFolders();
      DC.toast('Đã thêm thư mục chọn nhanh');
    });
    list.appendChild(button);
  });
  overlay.querySelector('.quick-folder-close').addEventListener('click', () => overlay.remove());
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

function renderQuickFolders() {
  const box = document.getElementById('overviewQuickFolders');
  if (!box) return;
  const saved = quickFolders();
  box.innerHTML = '';
  for (let i = 0; i < 4; i++) {
    const item = saved[i];
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'overview-quick-folder' + (item ? '' : ' empty');
    button.innerHTML = item ? iconSvg('i-folder', 'svg-24') + '<b>' + esc(item.name) + '</b><span class="overview-quick-delete">×</span>' : iconSvg('i-plus', 'svg-24');
    let timer = null, longPressed = false;
    const start = () => {
      if (!item) return;
      longPressed = false;
      timer = setTimeout(() => { longPressed = true; box.classList.add('editing'); }, 2000);
    };
    const cancel = () => { if (timer) clearTimeout(timer); timer = null; };
    button.addEventListener('pointerdown', start);
    button.addEventListener('pointerup', cancel);
    button.addEventListener('pointercancel', cancel);
    button.addEventListener('pointerleave', cancel);
    button.addEventListener('click', (e) => {
      if (longPressed) { e.preventDefault(); return; }
      if (!item) { openQuickFolderPicker(i); return; }
      if (e.target.closest('.overview-quick-delete')) {
        const next = quickFolders(); next.splice(i, 1); saveQuickFolders(next); renderQuickFolders(); return;
      }
      if (box.classList.contains('editing')) { box.classList.remove('editing'); return; }
      openProtectedOverviewFolder(item);
    });
    box.appendChild(button);
  }
}
function rememberOverviewFolder(path, poolId) {
  if (!path || !server) return;
  const list = kvGet(overviewRecentKey()) || [];
  const item = { path, pool: poolId || pool || 'main', name: path.split('/').pop() || path, at: Date.now() };
  kvSet(overviewRecentKey(), [item].concat(list.filter((x) => x.path !== item.path || x.pool !== item.pool)).slice(0, 8));
}

function rememberOverviewVideo(item) {
  if (!item || !item.rel || !server) return;
  if (overviewPathIsConfiguredProtected(item.rel, item.pool || 'main')) return;
  const list = kvGet(overviewVideoKey()) || [];
  const next = [item].concat(list.filter((x) => x.rel !== item.rel || x.pool !== item.pool)).slice(0, 5);
  kvSet(overviewVideoKey(), next);
  kvSet('overviewLastVideo:' + server.baseUrl, item);
}

function rememberOverviewFile(item) {
  if (!item || !item.rel || !item.name || !server || !me) return;
  const p = item.pool || pool || 'main';
  if (p === LOCAL_POOL || overviewPathIsConfiguredProtected(item.rel, p)) return;
  const list = kvGet(overviewFileKey()) || [];
  const next = Object.assign({}, item, { pool: p, at: Date.now() });
  kvSet(overviewFileKey(), [next].concat(list.filter((x) => x.rel !== next.rel || x.pool !== next.pool)).slice(0, 10));
}

function mediaThumbUrl(item, size) {
  if (!item || !item.rel || !server || !isThumbable(item.name || '')) return '';
  let url = '';
  try { url = DC.thumbUrl ? DC.thumbUrl(enc(item.rel), item.pool ? enc(item.pool) : '', size || 160) : ''; } catch (err) {}
  if (!url) url = server.baseUrl + '/api/thumb?path=' + enc(item.rel) + (item.pool ? '&pool=' + enc(item.pool) : '') + '&size=' + (size || 160);
  return versionedThumbUrl(url, item);
}

function mediaPreviewUrl(item) {
  if (!item || !item.rel || !server) return '';
  const p = item.pool || pool || 'main';
  return server.baseUrl + '/api/file?path=' + enc(item.rel) +
    (p && p !== LOCAL_POOL ? '&pool=' + enc(p) : '') +
    '&rev=' + thumbRevision(item);
}

function mediaRowThumbHtml(item, fallbackClass) {
  const icon = fileIcon(item && item.name);
  const url = mediaThumbUrl(item, 160);
  return '<div class="media-row-thumb ' + (fallbackClass || '') + '" style="color:' + icon.color + '">' +
    iconSvg(icon.sym, 'svg-24') + (url ? '<img src="' + esc(url) + '" alt="" loading="lazy" decoding="async" onerror="CWRetryThumbnail(this)">' : '') + '</div>';
}

function trashThumbKey(item) {
  return 'cwTrashThumb:' + overviewServer() + ':' + String(item && item.pool || 'main') + ':' + String(item && (item.rel || item.path) || '');
}

function saveTrashThumb(key, dataUrl) {
  try {
    localStorage.setItem(key, dataUrl);
    const indexKey = 'cwTrashThumbIndex:' + overviewServer();
    const list = JSON.parse(localStorage.getItem(indexKey) || '[]').filter((x) => x !== key);
    list.unshift(key);
    while (list.length > 24) { const old = list.pop(); localStorage.removeItem(old); }
    localStorage.setItem(indexKey, JSON.stringify(list));
  } catch (e) {}
}

async function cacheTrashThumbnail(entry) {
  if (!entry || entry.type === 'dir' || !isThumbable(entry.name || '')) return;
  const item = { name: entry.name, rel: relOf(entry), pool: ePool(entry), size: entry.size || 0, mtime: entry.mtime || '' };
  const url = mediaThumbUrl(item, 160);
  if (!url) return;
  try {
    const response = await fetch(url, { headers: token ? { Authorization: 'Bearer ' + token } : {} });
    if (!response.ok) return;
    const blob = await response.blob();
    if (blob.size > 180000) return;
    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader(); reader.onload = () => resolve(String(reader.result || '')); reader.onerror = reject; reader.readAsDataURL(blob);
    });
    saveTrashThumb(trashThumbKey(item), dataUrl);
  } catch (e) {}
}

function trashThumbUrl(item) {
  try { return localStorage.getItem(trashThumbKey(item)) || mediaThumbUrl(item, 160); } catch (e) { return mediaThumbUrl(item, 160); }
}

function openOverviewFile(item) {
  if (!item) return;
  withOverviewUnlock(item.rel, item.pool || 'main', 'file', () => openEntryByRel(item.pool || 'main', item.rel));
}

function renderOverviewRecentFiles() {
  const box = document.getElementById('overviewRecentFiles');
  if (!box) return;
  const items = (overviewLocksReady ? (kvGet(overviewFileKey()) || []) : [])
    .filter((x) => x && x.rel && !overviewPathIsConfiguredProtected(x.rel, x.pool || 'main')).slice(0, 10);
  box.innerHTML = items.length ? items.map((item, i) => {
    const icon = fileIcon(item.name);
    const thumb = mediaThumbUrl(item, 160);
    return '<button type="button" class="overview-file-card" data-recent-file="' + i + '"><span class="overview-file-thumb" style="color:' + icon.color + '">' +
      iconSvg(icon.sym, 'svg-24') + (thumb ? '<img src="' + esc(thumb) + '" alt="" loading="lazy" decoding="async" onerror="CWRetryThumbnail(this)">' : '') +
      '</span><b>' + esc(item.name) + '</b><small>' + esc(fmtAgo(item.at)) + '</small></button>';
  }).join('') : '<span class="card-sub">Chưa có file nào được xem gần đây.</span>';
  box.querySelectorAll('[data-recent-file]').forEach((button) => button.addEventListener('click', () => openOverviewFile(items[Number(button.dataset.recentFile)])));
}

function overviewThumbUrl(item) {
  if (!item || !item.rel || !server) return '';
  try { return DC.thumbUrl ? DC.thumbUrl(enc(item.rel), item.pool ? enc(item.pool) : '', 160) : ''; } catch (err) { return ''; }
}

function openOverviewVideo(item) {
  if (!item) return;
  withOverviewUnlock(item.rel, item.pool || 'main', 'file', () => {
    launchMobileVideo({ name: item.name, size: item.size || 0 }, item.rel, item.pool, 0, undefined, Number(item.positionMs || 0));
  });
}

function overviewLockTarget(pathValue, poolId, type) {
  const clean = String(pathValue || '').replace(/^\/+|\/+$/g, '');
  if (!clean) return resolveLockTarget({ pool: poolId || pool, dirRel: '', name: '', type: type || 'dir' });
  const cut = clean.lastIndexOf('/');
  return resolveLockTarget({
    pool: poolId || pool,
    dirRel: cut >= 0 ? clean.slice(0, cut) : '',
    name: cut >= 0 ? clean.slice(cut + 1) : clean,
    type: type || 'file'
  });
}

async function withOverviewUnlock(pathValue, poolId, type, onOpen) {
  await syncLocksFromServer();
  const target = overviewLockTarget(pathValue, poolId, type);
  if (target) { unlockSheet(target, onOpen); return; }
  onOpen && onOpen();
}

function navigateOverviewFolder(item) {
  if (!item) return;
  pool = item.pool || 'main';
  currentPath = item.path;
  parentPath = null;
  entries = [];
  activateMainView('files');
  renderPoolBar();
  loadFiles(item.path);
}

function openProtectedOverviewFolder(item) {
  if (!item) return;
  withOverviewUnlock(item.path, item.pool || 'main', 'dir', () => navigateOverviewFolder(item));
}

function openOverviewRecentSheet() {
  const recent = (kvGet(overviewRecentKey()) || []).filter((item) => item && item.path).slice(0, 8);
  openSheet('Thư mục gần đây', (body) => {
    if (!recent.length) {
      const empty = document.createElement('div');
      empty.className = 'empty';
      empty.textContent = 'Chưa có thư mục nào được mở gần đây.';
      body.appendChild(empty);
      return;
    }
    recent.forEach((item) => sheetItem(body, item.name || item.path, {
      icon: 'i-folder',
      sub: (poolNameOf(item.pool || 'main') || item.pool || 'Ổ mặc định') + ' · ' + item.path,
      onClick: () => openProtectedOverviewFolder(item),
    }));
  });
}

async function openOverviewMyFiles() {
  activateMainView('files');
  await openSyncDeviceFolder();
}

let overviewRemoteAt = 0;
let overviewRemoteLoading = false;

async function refreshOverviewWatchProgress() {
  if (!server || !token || overviewRemoteLoading || Date.now() - overviewRemoteAt < 10000) return;
  overviewRemoteLoading = true;
  try {
    await syncLocksFromServer();
    const data = await api('/api/watch-progress?limit=20');
    const items = (data.items || []).map((x) => ({
      name: x.name || String(x.path || '').split('/').pop(), rel: x.path, pool: x.pool || 'main',
      size: x.size || 0, positionMs: x.positionMs || 0, durationMs: x.durationMs || 0, at: x.updatedAtMs || Date.now()
    })).filter((x) => x.rel && !overviewPathIsConfiguredProtected(x.rel, x.pool)).slice(0, 5);
    kvSet(overviewVideoKey(), items);
  } catch (err) {
    // Host cũ hoặc mất mạng: tiếp tục dùng dữ liệu cục bộ.
  } finally {
    overviewRemoteAt = Date.now();
    overviewRemoteLoading = false;
    if (currentView === 'overview') renderOverview();
  }
}

function renderOverviewContinue(videos) {
  const cont = document.getElementById('overviewContinue');
  if (!cont) return;
  const safeVideos = (videos || []).slice(0, 5);
  const identity = safeVideos.map((x) => (x.pool || 'main') + '|' + x.rel).join('||');
  const rail = cont.querySelector('.overview-videos');
  const oldScroll = rail ? rail.scrollLeft : 0;
  if (identity !== overviewContinueIdentity || !rail) {
    overviewContinueIdentity = identity;
    cont.innerHTML = safeVideos.length ? '<div class="overview-videos">' + safeVideos.map((item, i) => {
      const thumb = overviewThumbUrl(item);
      const duration = Number(item.durationMs || 0), position = Number(item.positionMs || 0);
      const progress = duration > 0 ? Math.max(0, Math.min(100, Math.round(position * 100 / duration))) : 0;
      return '<button type="button" class="overview-video-card" data-video="' + i + '"><span class="overview-video-thumb">' +
        (thumb ? '<img src="' + esc(thumb) + '" alt="" loading="lazy" onerror="CWRetryThumbnail(this)">' : '') +
        '<span class="overview-video-play">' + iconSvg('i-video', 'svg-22') + '</span>' +
        (duration ? '<span class="overview-video-duration">' + fmtTime(duration) + '</span>' : '') + '</span>' +
        '<span class="overview-video-progress"><i style="width:' + progress + '%"></i></span><b>' + esc(item.name) + '</b><small>Tiếp tục từ ' + fmtTime(position) + '</small></button>';
    }).join('') + '</div>' : '<span class="card-sub">Chưa có video đang xem dở.</span>';
    const nextRail = cont.querySelector('.overview-videos');
    if (nextRail) nextRail.scrollLeft = oldScroll;
  } else {
    safeVideos.forEach((item, i) => {
      const card = cont.querySelector('[data-video="' + i + '"]');
      if (!card) return;
      const duration = Number(item.durationMs || 0), position = Number(item.positionMs || 0);
      const progress = duration > 0 ? Math.max(0, Math.min(100, Math.round(position * 100 / duration))) : 0;
      const small = card.querySelector('small'); if (small) small.textContent = 'Tiếp tục từ ' + fmtTime(position);
      const fill = card.querySelector('.overview-video-progress i'); if (fill) fill.style.width = progress + '%';
    });
  }
  cont.querySelectorAll('[data-video]').forEach((b) => {
    if (b.dataset.boundVideo === '1') return;
    b.dataset.boundVideo = '1';
    b.addEventListener('click', () => openOverviewVideo(safeVideos[Number(b.dataset.video)]));
  });
}

function overviewGalleryText(value) {
  return String(value || '').toLocaleLowerCase('vi-VN').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

function overviewParseDateFromFilename(name) {
  if (!name) return 0;
  const str = String(name);
  const m = str.match(/(?:IMG|VID|PXL|PHOTO|PIC|WP|Screenshot|Screen_Recording)?[-_]?(\d{4})[-_]?(\d{2})[-_]?(\d{2})[-_\sT]?(\d{2})[-_.:]?(\d{2})[-_.:]?(\d{2})/i);
  if (m) {
    const yr = Number(m[1]), mo = Number(m[2]) - 1, dy = Number(m[3]);
    const hr = Number(m[4]), mi = Number(m[5]), sc = Number(m[6]);
    if (yr >= 1990 && yr <= 2100 && mo >= 0 && mo <= 11 && dy >= 1 && dy <= 31 && hr < 24 && mi < 60 && sc < 60) {
      const d = new Date(yr, mo, dy, hr, mi, sc);
      if (Number.isFinite(d.getTime())) return d.getTime();
    }
  }
  const mDate = str.match(/(?:IMG|VID|PXL|PHOTO|PIC|WP|Screenshot)?[-_]?(\d{4})[-_](\d{2})[-_](\d{2})/i);
  if (mDate) {
    const yr = Number(mDate[1]), mo = Number(mDate[2]) - 1, dy = Number(mDate[3]);
    if (yr >= 1990 && yr <= 2100 && mo >= 0 && mo <= 11 && dy >= 1 && dy <= 31) {
      const d = new Date(yr, mo, dy, 12, 0, 0);
      if (Number.isFinite(d.getTime())) return d.getTime();
    }
  }
  return 0;
}

function overviewGalleryTimestampValue(raw) {
  if (!raw) return 0;
  if (typeof raw === 'number' && Number.isFinite(raw) && raw > 0) {
    return raw > 100000000000 ? raw : raw * 1000;
  }
  const str = String(raw).trim();
  if (!str) return 0;
  const num = Number(str);
  if (Number.isFinite(num) && num > 0) {
    return num > 100000000000 ? num : num * 1000;
  }
  const m = str.match(/^(\d{4})[-/:](\d{2})[-/:](\d{2})(?:[T\s](\d{2})[:.](\d{2})(?:[:.](\d{2}))?)?/);
  if (m) {
    const yr = Number(m[1]), mo = Number(m[2]) - 1, dy = Number(m[3]);
    const hr = Number(m[4] || 0), mi = Number(m[5] || 0), sc = Number(m[6] || 0);
    const d = new Date(yr, mo, dy, hr, mi, sc);
    if (Number.isFinite(d.getTime())) return d.getTime();
  }
  const parsed = Date.parse(str);
  return Number.isFinite(parsed) ? parsed : 0;
}

function overviewGalleryTimestamp(item) {
  if (!item) return 0;
  const original = item.captureDate || item.dateTaken || item.originalDate || item.sourceCreatedAt || item.creationDate;
  const originalStamp = overviewGalleryTimestampValue(original);
  if (originalStamp > 0) return originalStamp;

  const name = item.name || (item.rel ? String(item.rel).split('/').pop() : '');
  const filenameStamp = overviewParseDateFromFilename(name);
  if (filenameStamp > 0) return filenameStamp;

  const modified = item.sourceModifiedAt || item.mtime || item.modified || item.updatedAt;
  return overviewGalleryTimestampValue(modified);
}

function overviewGalleryDay(item) {
  const stamp = Number(item && item.at || 0) || overviewGalleryTimestamp(item) || 0;
  if (!stamp) return { key: 'unknown', label: 'Không rõ ngày' };
  const date = new Date(stamp);
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const day = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  if (day === today) return { key: 'today', label: 'Hôm nay' };
  if (day === today - 86400000) return { key: 'yesterday', label: 'Hôm qua' };
  return {
    key: date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0') + '-' + String(date.getDate()).padStart(2, '0'),
    label: new Intl.DateTimeFormat('vi-VN', { day: '2-digit', month: 'long', year: 'numeric' }).format(date)
  };
}

function overviewGalleryCalendarKey(item) {
  const stamp = Number(item && item.at || 0) || overviewGalleryTimestamp(item) || 0;
  if (!stamp) return 'unknown';
  const date = new Date(stamp);
  if (!Number.isFinite(date.getTime())) return 'unknown';
  return date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0') + '-' + String(date.getDate()).padStart(2, '0');
}

function overviewGalleryCalendarLabel(key) {
  const match = String(key || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return { day: 'Không rõ', monthYear: 'ngày' };
  return { day: Number(match[3]) + ' thg', monthYear: Number(match[2]) + ', ' + match[1] };
}

function loadOverviewGalleryCache() {
  ensureOverviewGalleryDeviceFolder();
  const scope = overviewGalleryKey();
  if (overviewGalleryScope === scope) return false;
  overviewGalleryScope = scope;
  const savedSort = kvGet(scope + ':sort');
  overviewGallerySort = Object.prototype.hasOwnProperty.call(overviewSortLabels, savedSort) && !String(savedSort).startsWith('name-') ? savedSort : 'date-desc';
  overviewGalleryFolderFilter = String(kvGet(scope + ':folder') || 'all');
  const savedDay = String(kvGet(scope + ':day') || 'all');
  overviewGalleryDayFilter = savedDay === 'all' || savedDay === 'unknown' || /^\d{4}-\d{2}-\d{2}$/.test(savedDay) ? savedDay : 'all';
  const cached = kvGet(scope);
  overviewGalleryItems = cached && Array.isArray(cached.items)
    ? cached.items.filter((x) => x && x.rel && x.name).map((item) => ({ ...item, at: overviewGalleryTimestamp(item) }))
    : [];
  overviewGalleryLastScanAt = Number(cached && cached.updatedAt || 0);
  overviewGalleryRenderLimit = 120;
  overviewThumbWarmComplete = overviewGalleryItems.length > 0 && overviewGalleryItems.every((item) => !isThumbable(item.name || '') || overviewThumbIsReady(item));
  return true;
}

function saveOverviewGalleryCache() {
  try {
    kvSet(overviewGalleryKey(), {
      version: 2,
      device: ensureOverviewGalleryDeviceFolder(),
      updatedAt: overviewGalleryLastScanAt,
      // Keep the newest index compact enough for WKWebView local storage.
      // The full library is restored by the background scan; thumbnail files
      // themselves live in the native disk cache and are not limited here.
      items: overviewGalleryItems.slice(0, 8000)
    });
  } catch (e) {}
}

function overviewThumbIdentity(item) {
  return String(item && item.pool || 'main') + '|' + String(item && item.rel || '');
}

function overviewThumbReadyRevision(item) {
  return String(item && item.thumbReadyRev || '');
}

function overviewThumbIsReady(item) {
  return !!item && overviewThumbReadyRevision(item) === thumbRevision(item);
}

function overviewThumbDomKey(item) {
  return encodeURIComponent(overviewThumbIdentity(item) + '|' + thumbRevision(item));
}

function adoptOverviewGalleryItems(nextItems) {
  const previous = new Map(overviewGalleryItems.map((item) => [overviewThumbIdentity(item), item]));
  overviewGalleryItems = (nextItems || []).map((item) => {
    const old = previous.get(overviewThumbIdentity(item));
    if (old && overviewThumbIsReady(old) && thumbRevision(old) === thumbRevision(item)) {
      item.thumbReadyRev = old.thumbReadyRev;
    }
    return item;
  }).sort((a, b) => (Number(b.at || 0) - Number(a.at || 0)) || a.name.localeCompare(b.name, 'vi'));
  overviewThumbWarmComplete = overviewGalleryItems.length > 0 && overviewGalleryItems.every((item) => !isThumbable(item.name || '') || overviewThumbIsReady(item));
}

function resetOverviewThumbnailWarmState() {
  overviewGalleryItems.forEach((item) => { if (item) delete item.thumbReadyRev; });
  overviewThumbWarmNextAttemptAt = 0;
  overviewThumbWarmComplete = false;
  saveOverviewGalleryCache();
}

function applyOverviewThumbnailToDOM(item) {
  const key = overviewThumbDomKey(item);
  const url = mediaThumbUrl(item, 160);
  if (!url) return;
  document.querySelectorAll('img[data-overview-thumb]').forEach((img) => {
    if (img.dataset.overviewThumb !== key) return;
    img.dataset.thumbOriginal = url;
    img.dataset.thumbRetry = '0';
    img.style.display = '';
    if (img.getAttribute('src') !== url || img.naturalWidth <= 0) {
      img.removeAttribute('src');
      requestAnimationFrame(() => { img.src = thumbnailRetryUrl(url, 1); });
    }
  });
}

function scheduleOverviewThumbReadySave() {
  clearTimeout(overviewThumbReadySaveTimer);
  overviewThumbReadySaveTimer = setTimeout(saveOverviewGalleryCache, 600);
}

window.CWOverviewThumbnailLoaded = function (img) {
  if (!img || img.naturalWidth <= 0) return false;
  img.style.display = '';
  const key = String(img.dataset.overviewThumb || '');
  const item = overviewGalleryItems.find((candidate) => overviewThumbDomKey(candidate) === key);
  if (item && !overviewThumbIsReady(item)) {
    item.thumbReadyRev = thumbRevision(item);
    scheduleOverviewThumbReadySave();
  }
  return true;
};

function armOverviewThumbnailWatchdogs(box) {
  if (!box) return;
  box.querySelectorAll('img[data-overview-thumb][src]').forEach((img) => {
    const expectedKey = img.dataset.overviewThumb;
    setTimeout(() => {
      if (document.hidden || !img.isConnected || img.dataset.overviewThumb !== expectedKey || img.naturalWidth > 0) return;
      window.CWOverviewThumbnailError(img);
    }, 7000);
  });
}

function pauseOverviewThumbnailWork() {
  overviewThumbWarmGeneration += 1;
  overviewThumbWarmRequested = true;
  overviewThumbWarmControllers.forEach((controller) => { try { controller.abort(); } catch (e) {} });
  overviewThumbWarmControllers.clear();
  if (overviewGalleryBusy) {
    overviewGalleryScanSequence += 1;
    overviewGalleryBusy = false;
  }
}

function resumeOverviewThumbnailWork() {
  if (!IS_IOS || !server || !me) return;
  renderOverviewGallery();
  setTimeout(() => {
    if (document.hidden) return;
    warmOverviewGalleryThumbnails();
    if (!overviewGalleryBusy && (!overviewGalleryLastScanAt || Date.now() - overviewGalleryLastScanAt > 300000)) refreshOverviewGallery(false);
  }, 120);
}

function overviewThumbnailDelay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function validateThumbnailBlob(blob) {
  const url = URL.createObjectURL(blob);
  try {
    await new Promise((resolve, reject) => {
      const img = new Image();
      const timer = setTimeout(() => { img.src = ''; reject(new Error('Thumbnail decode timeout')); }, 10000);
      img.onload = () => { clearTimeout(timer); img.naturalWidth > 0 ? resolve() : reject(new Error('Empty thumbnail')); };
      img.onerror = () => { clearTimeout(timer); reject(new Error('Invalid thumbnail image')); };
      img.src = url;
    });
  } finally { URL.revokeObjectURL(url); }
}

async function fetchOverviewThumbnail(item, generation) {
  const url = mediaThumbUrl(item, 160);
  if (!url) return false;
  const delays = [0, 250, 1000];
  for (let attempt = 0; attempt < delays.length; attempt += 1) {
    if (document.hidden || generation !== overviewThumbWarmGeneration) return false;
    if (delays[attempt]) await overviewThumbnailDelay(delays[attempt]);
    if (document.hidden || generation !== overviewThumbWarmGeneration) return false;
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    if (controller) overviewThumbWarmControllers.add(controller);
    // HEIC may still be queued on Host or undergoing native recovery.
    const timeout = controller ? setTimeout(() => controller.abort(), 120000) : 0;
    try {
      const requestUrl = attempt ? thumbnailRetryUrl(url, attempt) : url;
      const response = await fetch(requestUrl, { cache: attempt ? 'no-store' : 'force-cache', signal: controller ? controller.signal : undefined });
      if (!response.ok) throw new Error('Thumbnail HTTP ' + response.status);
      const blob = await response.blob();
      if (!blob || blob.size < 32 || (blob.type && !/^image\//i.test(blob.type))) throw new Error('Thumbnail không hợp lệ');
      await validateThumbnailBlob(blob);
      return true;
    } catch (error) {
      if (attempt === delays.length - 1 && DC.appLog) DC.appLog('WARN', 'THUMB_WARM', String(item.name || item.rel || '') + ': ' + errText(error));
    } finally {
      if (timeout) clearTimeout(timeout);
      if (controller) overviewThumbWarmControllers.delete(controller);
    }
  }
  return false;
}

async function warmOverviewGalleryThumbnails() {
  if (!IS_IOS || !server || !me || !overviewGalleryItems.length || document.hidden) return;
  if (overviewThumbWarmComplete) return;
  if (overviewThumbWarmBusy) { overviewThumbWarmRequested = true; return; }
  if (Date.now() < overviewThumbWarmNextAttemptAt) return;
  const scope = overviewGalleryKey();
  const pending = overviewGalleryItems.filter((item) => item && isThumbable(item.name || '') && !overviewThumbIsReady(item));
  if (!pending.length) {
    overviewThumbWarmRequested = false;
    overviewThumbWarmNextAttemptAt = 0;
    overviewThumbWarmComplete = true;
    return;
  }
  overviewThumbWarmBusy = true;
  overviewThumbWarmRequested = false;
  const generation = overviewThumbWarmGeneration;
  let cursor = 0;
  let completedSinceSave = 0;
  let failed = 0;
  const worker = async () => {
    while (scope === overviewGalleryKey() && generation === overviewThumbWarmGeneration && !document.hidden) {
      const item = pending[cursor++];
      if (!item) return;
      if (overviewThumbIsReady(item)) continue;
      const ok = await fetchOverviewThumbnail(item, generation);
      if (scope !== overviewGalleryKey() || generation !== overviewThumbWarmGeneration || document.hidden) return;
      const current = overviewGalleryItems.find((candidate) => overviewThumbIdentity(candidate) === overviewThumbIdentity(item));
      if (!current || thumbRevision(current) !== thumbRevision(item)) continue;
      if (ok) {
        current.thumbReadyRev = thumbRevision(current);
        applyOverviewThumbnailToDOM(current);
        completedSinceSave += 1;
        if (completedSinceSave >= 30) {
          completedSinceSave = 0;
          saveOverviewGalleryCache();
        }
      } else {
        failed += 1;
      }
    }
  };
  try {
    await Promise.all([worker(), worker(), worker()]);
  } finally {
    saveOverviewGalleryCache();
    overviewThumbWarmBusy = false;
    overviewThumbWarmNextAttemptAt = failed ? Date.now() + 15000 : 0;
    const shouldRunAgain = overviewThumbWarmRequested || overviewGalleryItems.some((item) => item && isThumbable(item.name || '') && !overviewThumbIsReady(item));
    overviewThumbWarmComplete = !shouldRunAgain;
    overviewThumbWarmRequested = false;
    if (shouldRunAgain && !document.hidden) setTimeout(warmOverviewGalleryThumbnails, failed ? 15000 : 120);
  }
}

window.CWOverviewThumbnailError = function (img) {
  if (!img) return false;
  if (retryThumbnailElement(img)) return false;
  const key = String(img.dataset.overviewThumb || '');
  const item = overviewGalleryItems.find((candidate) => overviewThumbDomKey(candidate) === key);
  if (item) {
    delete item.thumbReadyRev;
    overviewThumbWarmComplete = false;
    saveOverviewGalleryCache();
    overviewThumbWarmNextAttemptAt = Math.min(overviewThumbWarmNextAttemptAt || Date.now() + 1500, Date.now() + 1500);
    setTimeout(warmOverviewGalleryThumbnails, 1600);
  }
  img.style.display = 'none';
  return false;
};

async function overviewGalleryList(pathValue, poolId) {
  const data = await api('/api/files?path=' + enc(pathValue) + '&pool=' + enc(poolId));
  return Array.isArray(data && data.entries) ? data.entries : [];
}

async function overviewGalleryMapLimit(items, limit, worker) {
  const results = new Array(items.length);
  let cursor = 0;
  const runners = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (cursor < items.length) {
      const index = cursor++;
      try { results[index] = await worker(items[index], index); }
      catch (e) { results[index] = []; }
    }
  });
  await Promise.all(runners);
  return results;
}

function overviewGalleryPartKind(name) {
  const value = String(name || '');
  if (/^images?_\d+$/i.test(value)) return 'image';
  if (/^videos?_\d+$/i.test(value)) return 'video';
  return '';
}

function updateOverviewGalleryDeviceButton() {
  const label = document.getElementById('overviewGalleryDeviceName');
  const button = document.getElementById('overviewGalleryDeviceSwitch');
  const selected = ensureOverviewGalleryDeviceFolder();
  if (label) label.textContent = selected;
  if (button) button.title = 'Đang xem thư viện: ' + selected;
}

async function overviewGalleryFolderHasMediaParts(deviceName, poolId) {
  if (!deviceName || overviewPathIsConfiguredProtected(deviceName, poolId)) return false;
  const roots = await overviewGalleryList(deviceName, poolId);
  const mediaRoots = roots.filter((entry) => entry && entry.type === 'dir' && /^(images?|videos?)$/i.test(String(entry.name || '')));
  if (!mediaRoots.length) return false;
  const checks = await overviewGalleryMapLimit(mediaRoots, 2, async (root) => {
    const rootPath = deviceName + '/' + root.name;
    if (overviewPathIsConfiguredProtected(rootPath, poolId)) return false;
    const kind = /^images?$/i.test(root.name) ? 'image' : 'video';
    const entries = await overviewGalleryList(rootPath, poolId);
    return entries.some((entry) => entry && entry.type === 'dir' &&
      overviewGalleryPartKind(entry.name) === kind &&
      !overviewPathIsConfiguredProtected(rootPath + '/' + entry.name, poolId));
  });
  return checks.some(Boolean);
}

async function discoverOverviewGalleryDeviceFolders(force) {
  ensureOverviewGalleryDeviceFolder();
  if (!force && overviewGalleryDeviceChoices.length && Date.now() - overviewGalleryDeviceChoicesAt < 300000) return overviewGalleryDeviceChoices;
  await syncLocksFromServer();
  const hostPool = await cameraHostPool(!!force);
  if (!hostPool || !hostPool.id) throw new Error('Không tìm thấy ổ lưu thư mục Đồng bộ.');
  const poolId = String(hostPool.id);
  const rootEntries = await overviewGalleryList('', poolId);
  const candidates = rootEntries.filter((entry) => entry && entry.type === 'dir')
    .map((entry) => String(entry.name || '').trim()).filter(Boolean);
  const valid = await overviewGalleryMapLimit(candidates, 4, (name) => overviewGalleryFolderHasMediaParts(name, poolId));
  const own = overviewGalleryOwnDeviceFolder();
  const names = candidates.filter((name, index) => valid[index]);
  if (!names.some((name) => name.toLocaleLowerCase('vi-VN') === own.toLocaleLowerCase('vi-VN'))) names.push(own);
  overviewGalleryDeviceChoices = Array.from(new Set(names)).sort((a, b) => {
    if (a === own) return -1;
    if (b === own) return 1;
    return a.localeCompare(b, 'vi', { numeric: true, sensitivity: 'base' });
  });
  overviewGalleryDeviceChoicesAt = Date.now();
  return overviewGalleryDeviceChoices;
}

async function switchOverviewGalleryDeviceFolder(nextFolder) {
  const next = String(nextFolder || '').trim();
  if (!next || next === ensureOverviewGalleryDeviceFolder()) return;
  pauseOverviewThumbnailWork();
  overviewGalleryDeviceFolder = next;
  overviewGalleryScope = '';
  overviewGalleryItems = [];
  overviewGalleryVisible = [];
  overviewGalleryLastScanAt = 0;
  overviewGalleryRenderLimit = 120;
  overviewGalleryBusy = false;
  overviewGallerySelectionMode = false;
  overviewGallerySelected.clear();
  updateOverviewGalleryDeviceButton();
  loadOverviewGalleryCache();
  renderOverviewGallery();
  const scroller = document.querySelector('#overview .overview-scroll');
  if (scroller) scroller.scrollTop = 0;
  await refreshOverviewGallery(false);
}

async function openOverviewGalleryDevicePicker() {
  const button = document.getElementById('overviewGalleryDeviceSwitch');
  if (button) button.disabled = true;
  try {
    const choices = await discoverOverviewGalleryDeviceFolders(false);
    const selected = ensureOverviewGalleryDeviceFolder();
    openSheet('Chọn thư viện của máy', (body) => {
      choices.forEach((name) => sheetItem(body, name, {
        icon: 'i-phone',
        active: name === selected,
        sub: name === overviewGalleryOwnDeviceFolder() ? 'Thiết bị này · chỉ thay đổi nội dung đang xem' : 'Thư viện ảnh/video đã đồng bộ',
        onClick: () => switchOverviewGalleryDeviceFolder(name)
      }));
    });
  } catch (error) { DC.toast(errText(error)); }
  finally { if (button) button.disabled = false; }
}

async function overviewGalleryDeep(deviceRoot, poolId) {
  try {
    const data = await api('/api/files/deep?path=' + enc(deviceRoot) + '&camera=1&pool=' + enc(poolId));
    if (!data || !Array.isArray(data.files)) return null;
    const items = [];
    data.files.forEach((file) => {
      if (!file || !file.rel) return;
      const relative = String(file.rel).replace(/\\/g, '/').replace(/^\/+|\/+$/g, '');
      const parts = relative.split('/');
      if (parts.length < 3) return;
      const rootKind = /^images?$/i.test(parts[0]) ? 'image' : (/^videos?$/i.test(parts[0]) ? 'video' : '');
      if (!rootKind || overviewGalleryPartKind(parts[1]) !== rootKind) return;
      const name = parts[parts.length - 1];
      const kind = STREAM_IMG.test(name) ? 'image' : (STREAM_VIDEO.test(name) ? 'video' : '');
      if (!kind || kind !== rootKind) return;
      const rel = deviceRoot + '/' + relative;
      if (overviewPathIsConfiguredProtected(rel, poolId)) return;
      let effectiveCapture = '';
      const rawCapture = file.captureDate || file.dateTaken || file.sourceCreatedAt || file.creationDate || file.ctime || '';
      if (typeof rawCapture === 'number' && rawCapture > 0) {
        effectiveCapture = new Date(rawCapture).toISOString();
      } else if (typeof rawCapture === 'string' && rawCapture.trim()) {
        effectiveCapture = rawCapture.trim();
      }
      if (!effectiveCapture) {
        const fnDate = overviewParseDateFromFilename(name);
        if (fnDate > 0) effectiveCapture = new Date(fnDate).toISOString();
      }
      const item = {
        name,
        rel,
        pool: String(poolId),
        kind,
        size: Number(file.size || 0),
        mtime: file.mtime || file.modified || '',
        captureDate: effectiveCapture,
        sourceCreatedAt: file.sourceCreatedAt || '',
        sourceModifiedAt: file.sourceModifiedAt || '',
        width: Number(file.width || 0),
        height: Number(file.height || 0),
        latitude: file.latitude != null ? file.latitude : undefined,
        longitude: file.longitude != null ? file.longitude : undefined,
        at: 0
      };
      item.at = overviewGalleryTimestamp(item);
      items.push(item);
    });
    return items;
  } catch (e) {
    return null;
  }
}

async function refreshOverviewGallery(force) {
  if (!IS_IOS || !server || !me || overviewGalleryBusy || document.hidden) return;
  const sequence = ++overviewGalleryScanSequence;
  overviewGalleryBusy = true;
  renderOverviewGallery();
  try {
    await syncLocksFromServer();
    overviewLocksReady = true;
    const hostPool = await cameraHostPool(!!force);
    if (!hostPool || !hostPool.id) throw new Error('Không tìm thấy ổ lưu thư mục Đồng bộ.');
    const poolId = String(hostPool.id);
    const deviceRoot = ensureOverviewGalleryDeviceFolder();
    if (overviewPathIsConfiguredProtected(deviceRoot, poolId)) {
      overviewGalleryItems = [];
      overviewGalleryLastScanAt = Date.now();
      saveOverviewGalleryCache();
      renderOverviewGallery('Nội dung trong thư mục khóa không được hiển thị.');
      return;
    }

    const deepItems = await overviewGalleryDeep(deviceRoot, poolId);
    if (deepItems !== null) {
      if (sequence !== overviewGalleryScanSequence) return;
      const uniqueDeep = new Map();
      deepItems.forEach((item) => uniqueDeep.set(item.pool + '|' + item.rel, item));
      adoptOverviewGalleryItems(Array.from(uniqueDeep.values()));
      overviewGalleryLastScanAt = Date.now();
      overviewGalleryRenderLimit = 120;
      saveOverviewGalleryCache();
      renderOverviewGallery();
      warmOverviewGalleryThumbnails();
      return;
    }

    const rootEntries = await overviewGalleryList(deviceRoot, poolId);
    const mediaRoots = [];
    const directParts = [];
    rootEntries.filter((entry) => entry && entry.type === 'dir').forEach((entry) => {
      const name = String(entry.name || '');
      const rootKind = /^images?$/i.test(name) ? 'image' : (/^videos?$/i.test(name) ? 'video' : '');
      const partKind = overviewGalleryPartKind(name);
      const rel = deviceRoot + '/' + name;
      if (rootKind && !overviewPathIsConfiguredProtected(rel, poolId)) mediaRoots.push({ path: rel, kind: rootKind });
      else if (partKind && !overviewPathIsConfiguredProtected(rel, poolId)) directParts.push({ path: rel, kind: partKind });
    });

    const rootResults = await overviewGalleryMapLimit(mediaRoots, 2, async (root) => {
      const children = await overviewGalleryList(root.path, poolId);
      const parts = [];
      const directFiles = [];
      children.forEach((entry) => {
        if (!entry) return;
        const rel = root.path + '/' + entry.name;
        if (entry.type === 'dir' && overviewGalleryPartKind(entry.name) === root.kind && !overviewPathIsConfiguredProtected(rel, poolId)) {
          parts.push({ path: rel, kind: root.kind });
        } else if (entry.type !== 'dir') {
          directFiles.push({ entry, path: root.path, kind: root.kind });
        }
      });
      return { parts, directFiles };
    });
    const partFolders = directParts.slice();
    const looseFiles = [];
    rootResults.forEach((result) => {
      if (!result) return;
      partFolders.push(...result.parts);
      looseFiles.push(...result.directFiles);
    });

    const partResults = await overviewGalleryMapLimit(partFolders, 4, async (part) => {
      const children = await overviewGalleryList(part.path, poolId);
      return children.filter((entry) => entry && entry.type !== 'dir').map((entry) => ({ entry, path: part.path, kind: part.kind }));
    });
    const candidates = looseFiles.concat(...partResults);
    const unique = new Map();
    candidates.forEach((row) => {
      const entry = row.entry || {};
      const name = String(entry.name || '');
      const kind = STREAM_IMG.test(name) ? 'image' : (STREAM_VIDEO.test(name) ? 'video' : '');
      if (!kind || kind !== row.kind) return;
      const rel = row.path + '/' + name;
      if (overviewPathIsConfiguredProtected(rel, poolId)) return;
      const item = {
        name,
        rel,
        pool: poolId,
        kind,
        size: Number(entry.size || 0),
        mtime: entry.mtime || entry.modified || '',
        captureDate: entry.captureDate || entry.dateTaken || entry.sourceCreatedAt || entry.creationDate || entry.ctime || '',
        sourceCreatedAt: entry.sourceCreatedAt || '',
        sourceModifiedAt: entry.sourceModifiedAt || '',
        at: overviewGalleryTimestamp(entry)
      };
      unique.set(poolId + '|' + rel, item);
    });
    if (sequence !== overviewGalleryScanSequence) return;
    adoptOverviewGalleryItems(Array.from(unique.values()));
    overviewGalleryLastScanAt = Date.now();
    overviewGalleryRenderLimit = 120;
    saveOverviewGalleryCache();
    renderOverviewGallery();
    warmOverviewGalleryThumbnails();
  } catch (error) {
    if (sequence === overviewGalleryScanSequence) renderOverviewGallery(errText(error), true);
  } finally {
    if (sequence === overviewGalleryScanSequence) {
      overviewGalleryBusy = false;
      renderOverviewGallery();
    }
  }
}

function overviewGalleryFavorites() {
  const set = new Set();
  (kvGet(kFavs()) || []).forEach((item) => set.add(String(item.pool || 'main') + '|' + String(item.rel || '')));
  return set;
}

function compareOverviewMedia(a, b, mode) {
  const direction = mode.endsWith('-asc') ? 1 : -1;
  let value = 0;
  if (mode.startsWith('name-')) value = String(a.name || '').localeCompare(String(b.name || ''), 'vi', { numeric: true, sensitivity: 'base' });
  else if (mode.startsWith('size-')) value = Number(a.size || 0) - Number(b.size || 0);
  else value = Number(a.at || overviewGalleryTimestamp(a) || 0) - Number(b.at || overviewGalleryTimestamp(b) || 0);
  return value * direction || overviewThumbIdentity(a).localeCompare(overviewThumbIdentity(b));
}

function overviewMediaFolder(item) {
  const parts = String(item && item.rel || '').replace(/\\/g, '/').split('/').filter(Boolean);
  return parts.find((part) => /^(?:Images|Videos)_\d+$/i.test(part)) || (parts.length > 1 ? parts[parts.length - 2] : '');
}

function overviewSortCriterion(mode) { return String(mode || '').split('-')[0]; }
function toggleOverviewSort(criterion) {
  const current = overviewSortCriterion(overviewGallerySort);
  const direction = current === criterion
    ? (overviewGallerySort.endsWith('-asc') ? 'desc' : 'asc')
    : (criterion === 'date' ? 'desc' : 'asc');
  overviewGallerySort = criterion + '-' + direction;
  kvSet(overviewGalleryKey() + ':sort', overviewGallerySort);
  overviewGalleryRenderLimit = 120;
  renderOverviewGallery();
  const scroll = document.querySelector('#overview .overview-scroll');
  if (scroll) scroll.scrollTop = 0;
}

function renderOverviewGallery(errorText, isError) {
  const box = document.getElementById('overviewGallery');
  const meta = document.getElementById('overviewGalleryMeta');
  if (!box || !meta) return;
  const favorites = overviewGalleryFavorites();
  const query = overviewGalleryText(overviewGalleryQuery);
  overviewGalleryVisible = overviewGalleryItems.filter((item) => {
    if (!item || !item.rel || overviewPathIsConfiguredProtected(item.rel, item.pool || 'main')) return false;
    if (overviewGalleryFolderFilter !== 'all' && overviewMediaFolder(item) !== overviewGalleryFolderFilter) return false;
    if (overviewGalleryDayFilter !== 'all' && overviewGalleryCalendarKey(item) !== overviewGalleryDayFilter) return false;
    if (overviewGalleryFilter === 'image' && item.kind !== 'image') return false;
    if (overviewGalleryFilter === 'video' && item.kind !== 'video') return false;
    if (overviewGalleryFilter === 'favorite' && !favorites.has(String(item.pool || 'main') + '|' + item.rel)) return false;
    return !query || overviewGalleryText(item.name + ' ' + item.rel).includes(query);
  }).sort((a, b) => compareOverviewMedia(a, b, overviewGallerySort));
  updateOverviewGalleryDeviceButton();
  meta.innerHTML = overviewGalleryBusy
    ? '<span class="photos-scan-progress">Đang cập nhật · ' + overviewGalleryVisible.length.toLocaleString('vi-VN') + ' mục</span>'
    : overviewGalleryVisible.length.toLocaleString('vi-VN') + ' mục · ' + esc(ensureOverviewGalleryDeviceFolder());
  if (errorText && !overviewGalleryItems.length) {
    box.innerHTML = '<div class="photos-gallery-status' + (isError ? ' error' : '') + '">' + iconSvg(isError ? 'i-alert' : 'i-lock', 'svg-30') + esc(errorText) + '</div>';
    return;
  }
  if (!overviewGalleryVisible.length) {
    box.innerHTML = '<div class="photos-gallery-status">' + iconSvg('i-image', 'svg-30') + (overviewGalleryBusy ? 'Đang quét các thư mục Images_00x và Videos_00x…' : 'Không tìm thấy ảnh hoặc video phù hợp.') + '</div>';
    return;
  }
  const visible = overviewGalleryVisible.slice(0, overviewGalleryRenderLimit);
  const groups = [];
  visible.forEach((item, index) => {
    const day = overviewGallerySort.startsWith('date-') ? overviewGalleryDay(item)
      : { key: 'sorted', label: overviewSortLabels[overviewGallerySort] };
    let group = groups[groups.length - 1];
    if (!group || group.key !== day.key) { group = { key: day.key, label: day.label, rows: [] }; groups.push(group); }
    group.rows.push({ item, index });
  });
  box.innerHTML = groups.map((group) => '<section class="photos-day"><div class="photos-day-head"><strong>' + esc(group.label) + '</strong><span>' + group.rows.length + ' mục</span></div><div class="photos-grid">' + group.rows.map((row) => {
    const item = row.item;
    const thumb = mediaThumbUrl(item, 160);
    const thumbReady = overviewThumbIsReady(item);
    const thumbKey = overviewThumbDomKey(item);
    const favorite = favorites.has(String(item.pool || 'main') + '|' + item.rel);
    const selected = overviewGallerySelected.has(overviewThumbIdentity(item));
    const eager = thumbReady || row.index < 40;
    return '<button type="button" draggable="false" class="photos-tile' + (selected ? ' overview-selected' : '') + '" data-gallery-index="' + row.index + '" aria-label="' + (overviewGallerySelectionMode ? 'Chọn ' : 'Mở ') + esc(item.name) + '">' + iconSvg(item.kind === 'video' ? 'i-video' : 'i-image', 'svg-24') +
      (thumb ? '<img draggable="false" ondragstart="return false;" ' + (eager ? 'src="' + esc(thumb) + '" ' : '') + 'data-overview-thumb="' + esc(thumbKey) + '" alt="" decoding="async" fetchpriority="' + (row.index < 25 ? 'high' : 'low') + '" onload="CWOverviewThumbnailLoaded(this)" onerror="CWOverviewThumbnailError(this)">' : '') +
      (item.kind === 'video' ? '<span class="photos-video-badge">' + iconSvg('i-play', 'svg-14') + '</span>' : '') +
      (favorite ? '<span class="photos-tile-fav">' + iconSvg('i-heart', 'svg-14') + '</span>' : '') + '</button>';
  }).join('') + '</div></section>').join('');
  bindOverviewGallerySelection(box);
  armOverviewThumbnailWatchdogs(box);
  updateOverviewGallerySelectionChip();
}

const overviewGallerySelectionChip = document.createElement('button');
overviewGallerySelectionChip.className = 'sel-fab overview-gallery-selection-chip';
document.querySelector('.app-shell').appendChild(overviewGallerySelectionChip);
overviewGallerySelectionChip.addEventListener('click', openOverviewGallerySelectionSheet);

function updateOverviewGallerySelectionChip() {
  const show = overviewGallerySelectionMode && overviewGallerySelected.size > 0 && currentView === 'overview' && !sheetModal.classList.contains('show');
  overviewGallerySelectionChip.style.display = 'none';
  const bar = document.getElementById('overviewGallerySelectionBar');
  const count = document.getElementById('overviewGallerySelectionCount');
  if (bar) bar.classList.toggle('show', show);
  if (count) count.textContent = 'Đã chọn ' + overviewGallerySelected.size + ' mục';
}

function exitOverviewGallerySelection() {
  if (!overviewGallerySelectionMode && !overviewGallerySelected.size) return;
  overviewGallerySelectionMode = false;
  overviewGallerySelected.clear();
  updateOverviewGallerySelectionChip();
  if (currentView === 'overview') renderOverviewGallery();
}

function toggleOverviewGallerySelection(item) {
  if (!item) return;
  const key = overviewThumbIdentity(item);
  if (overviewGallerySelected.has(key)) overviewGallerySelected.delete(key);
  else overviewGallerySelected.add(key);
  if (!overviewGallerySelected.size) overviewGallerySelectionMode = false;
  renderOverviewGallery();
}

function beginOverviewGallerySelection(item) {
  if (!item) return;
  overviewGallerySelectionMode = true;
  overviewGallerySelected.add(overviewThumbIdentity(item));
  overviewGallerySuppressClickUntil = Date.now() + 700;
  if (navigator.vibrate) navigator.vibrate(20);
  renderOverviewGallery();
}

function bindOverviewGallerySelection(box) {
  box.querySelectorAll('[data-gallery-index]').forEach((button) => {
    const item = overviewGalleryVisible[Number(button.dataset.galleryIndex)];
    let timer = 0;
    let startX = 0;
    let startY = 0;
    const clear = () => { if (timer) window.clearTimeout(timer); timer = 0; };
    button.addEventListener('pointerdown', (event) => {
      if (overviewGallerySelectionMode) return;
      startX = event.clientX;
      startY = event.clientY;
      clear();
      timer = window.setTimeout(() => { timer = 0; beginOverviewGallerySelection(item); }, 1000);
    });
    button.addEventListener('pointermove', (event) => {
      if (Math.abs(event.clientX - startX) > 8 || Math.abs(event.clientY - startY) > 8) clear();
    });
    button.addEventListener('pointerup', clear);
    button.addEventListener('pointercancel', clear);
    button.addEventListener('dragstart', (event) => { event.preventDefault(); return false; });
    button.addEventListener('contextmenu', (event) => { event.preventDefault(); clear(); });
    button.addEventListener('click', (event) => {
      if (Date.now() < overviewGallerySuppressClickUntil) { event.preventDefault(); return; }
      if (overviewGallerySelectionMode) { event.preventDefault(); toggleOverviewGallerySelection(item); return; }
      openOverviewGalleryItem(item);
    });
  });
}

function overviewGallerySelectedItems() {
  return overviewGalleryItems.filter((item) => overviewGallerySelected.has(overviewThumbIdentity(item)));
}

function overviewGalleryEntry(item) {
  return {
    name: item.name,
    type: 'file',
    size: item.size || 0,
    mtime: item.mtime || '',
    pool: item.pool || 'main',
    _rel: item.rel,
    captureDate: item.captureDate || '',
    width: item.width || 0,
    height: item.height || 0,
    latitude: item.latitude != null ? item.latitude : undefined,
    longitude: item.longitude != null ? item.longitude : undefined,
  };
}

function addOverviewGalleryFavorites(items) {
  favs = kvGet(kFavs()) || [];
  let added = 0;
  items.forEach((item) => {
    const p = String(item.pool || 'main');
    const rel = String(item.rel || '');
    if (!favs.some((favorite) => String(favorite.rel || '') === rel && String(favorite.pool || 'main') === p)) {
      favs.unshift({ rel, name: item.name, type: 'file', pool: p, size: item.size || 0, mtime: item.mtime || '' });
      added++;
    }
  });
  kvSet(kFavs(), favs);
  DC.toast(added ? 'Đã thêm ' + added + ' mục vào yêu thích' : 'Các mục đã nằm trong Yêu thích');
  exitOverviewGallerySelection();
}

function deleteOverviewGalleryItems(items) {
  sheetConfirm('Xóa ' + items.length + ' mục', 'Các ảnh/video đã chọn sẽ được chuyển vào Thùng rác.', 'Xóa', async () => {
    let done = 0;
    for (const item of items) {
      try {
        await api('/api/file?path=' + enc(item.rel) + '&pool=' + enc(item.pool || 'main'), 'DELETE');
        done++;
      } catch (e) {}
    }
    const removed = new Set(items.slice(0, done === items.length ? items.length : 0).map(overviewThumbIdentity));
    if (done === items.length) overviewGalleryItems = overviewGalleryItems.filter((item) => !removed.has(overviewThumbIdentity(item)));
    saveOverviewGalleryCache();
    exitOverviewGallerySelection();
    DC.toast(done === items.length ? 'Đã chuyển ' + done + ' mục vào Thùng rác' : 'Đã xóa ' + done + '/' + items.length + ' mục');
    if (done !== items.length) scanOverviewGallery(true);
  });
}

function openOverviewGallerySelectionSheet() {
  const items = overviewGallerySelectedItems();
  if (!items.length) { exitOverviewGallerySelection(); return; }
  openSheet('Đã chọn ' + items.length + ' mục', (body) => {
    if (items.length === 1) sheetItem(body, 'Mở', { icon: 'i-open', onClick: () => { const item = items[0]; exitOverviewGallerySelection(); openOverviewGalleryItem(item); } });
    sheetItem(body, 'Tải về', { icon: 'i-download', onClick: () => { items.forEach((item) => startDownloadFor(overviewGalleryEntry(item))); DC.toast('Đang tải về ' + items.length + ' mục'); exitOverviewGallerySelection(); } });
    sheetItem(body, 'Chia sẻ link', { icon: 'i-upload', onClick: () => { const entries = items.map(overviewGalleryEntry); exitOverviewGallerySelection(); openShareSheet(entries); } });
    sheetItem(body, 'Thêm yêu thích', { icon: 'i-star', onClick: () => addOverviewGalleryFavorites(items) });
    sheetItem(body, 'Chọn tất cả (' + overviewGalleryVisible.length + ')', { icon: 'i-check-circle', onClick: () => { overviewGalleryVisible.forEach((item) => overviewGallerySelected.add(overviewThumbIdentity(item))); overviewGallerySelectionMode = true; renderOverviewGallery(); openOverviewGallerySelectionSheet(); } });
    if (canWrite()) sheetItem(body, 'Xóa (vào thùng rác)', { icon: 'i-trash', danger: true, onClick: () => deleteOverviewGalleryItems(items) });
    sheetItem(body, 'Bỏ chọn', { icon: 'i-deselect', onClick: exitOverviewGallerySelection });
    if (items.length === 1) sheetItem(body, 'Thông tin', { icon: 'i-info', onClick: () => {
      const entry = overviewGalleryEntry(items[0]);
      exitOverviewGallerySelection();
      openItemInfoSheet(entry);
    } });
  });
}

async function openOverviewGalleryItem(item) {
  if (!item) return;
  await syncLocksFromServer();
  if (overviewPathIsConfiguredProtected(item.rel, item.pool || 'main')) {
    overviewGalleryItems = overviewGalleryItems.filter((x) => x.rel !== item.rel || x.pool !== item.pool);
    saveOverviewGalleryCache();
    renderOverviewGallery();
    DC.toast('Nội dung khóa không được hiển thị trong thư viện.');
    return;
  }
  rememberOverviewFile(item);
  if (item.kind === 'video') {
    rememberOverviewVideo(item);
    const videos = overviewGalleryItems.filter((x) => x.kind === 'video' && !overviewPathIsConfiguredProtected(x.rel, x.pool || 'main'));
    const rawIndex = Math.max(0, videos.findIndex((x) => x.rel === item.rel && x.pool === item.pool));
    const start = Math.max(0, rawIndex - 30);
    const playlist = videos.slice(start, start + 60).map((x) => ({
      name: x.name,
      rel: x.rel,
      pool: x.pool,
      size: x.size || 0,
      mtime: x.mtime || '',
      url: mediaProxyUrl(x.rel, true, x.pool),
      thumbUrl: mediaThumbUrl(x, 160),
      favorite: overviewGalleryFavorites().has(String(x.pool || 'main') + '|' + x.rel)
    }));
    try {
      const remote = await api('/api/watch-progress?pool=' + enc(item.pool || 'main') + '&path=' + enc(item.rel));
      const position = Number(remote && remote.item && remote.item.positionMs || 0);
      if (position > 5000) showVideoResumePrompt(item, item.rel, item.pool, rawIndex - start, playlist, position);
      else launchMobileVideo(item, item.rel, item.pool, rawIndex - start, playlist, 0);
    } catch (e) { launchMobileVideo(item, item.rel, item.pool, rawIndex - start, playlist, -1); }
    return;
  }
  const images = overviewGalleryVisible.filter((x) => x.kind === 'image' && !overviewPathIsConfiguredProtected(x.rel, x.pool || 'main'));
  const rawIndex = Math.max(0, images.findIndex((x) => x.rel === item.rel && x.pool === item.pool));
  const start = Math.max(0, rawIndex - 40);
  const slice = images.slice(start, start + 80);
  const playlist = slice.map((x) => ({
    name: x.name,
    rel: x.rel,
    pool: x.pool,
    size: x.size || 0,
    mtime: x.mtime || '',
    captureDate: x.captureDate || x.sourceCreatedAt || '',
    width: x.width || 0,
    height: x.height || 0,
    latitude: x.latitude != null ? x.latitude : null,
    longitude: x.longitude != null ? x.longitude : null,
    url: mediaPreviewUrl(x),
    thumbUrl: mediaThumbUrl(x, 160),
    favorite: false
  }));
  const favoriteSet = overviewGalleryFavorites();
  playlist.forEach((x) => { x.favorite = favoriteSet.has(String(x.pool || 'main') + '|' + x.rel); });
  callNative('openPhoto', JSON.stringify({ playlist, initialIndex: rawIndex - start, token: token || '', baseUrl: server.baseUrl, pool: item.pool })).catch((error) => DC.toast(errText(error)));
}

function ensureOverviewGallery() {
  const changed = loadOverviewGalleryCache();
  if (changed) renderOverviewGallery();
  if (document.hidden) return;
  warmOverviewGalleryThumbnails();
  if (!overviewGalleryBusy && (!overviewGalleryLastScanAt || Date.now() - overviewGalleryLastScanAt > 300000)) refreshOverviewGallery(false);
}

async function renderOverview() {
  if (!document.getElementById('overview')) return;
  ensureOverviewGallery();
}

const overviewSyncBtn = document.getElementById('overviewSyncBtn'); if (overviewSyncBtn) overviewSyncBtn.addEventListener('click', () => syncCameraNow(false));
const overviewUpload = document.getElementById('overviewUpload'); if (overviewUpload) overviewUpload.addEventListener('click', () => { activateMainView('files'); setTimeout(openFabSheet, 80); });
const overviewFavorites = document.getElementById('overviewFavorites'); if (overviewFavorites) overviewFavorites.addEventListener('click', () => activateMainView('favorites'));
const overviewMyFiles = document.getElementById('overviewMyFiles'); if (overviewMyFiles) overviewMyFiles.addEventListener('click', openOverviewMyFiles);
const overviewDrive = document.getElementById('overviewDrive'); if (overviewDrive) overviewDrive.addEventListener('click', openDrivePicker);
const overviewRecentMore = document.getElementById('overviewRecentMore'); if (overviewRecentMore) overviewRecentMore.addEventListener('click', openOverviewRecentSheet);
const overviewGallerySearch = document.getElementById('overviewGallerySearch');
const overviewGallerySortButton = document.getElementById('overviewGallerySort');
function openOverviewGalleryFolderPicker() {
  const folders = Array.from(new Set(overviewGalleryItems.map(overviewMediaFolder).filter(Boolean))).sort((a, b) => a.localeCompare(b, 'vi', { numeric: true }));
  openSheet('Chọn thư mục', (body) => {
    body.style.cssText = 'max-height:65dvh;overflow-y:auto;-webkit-overflow-scrolling:touch;padding-right:2px';
    sheetItem(body, 'Tất cả thư mục', { icon: 'i-folder', active: overviewGalleryFolderFilter === 'all', sub: 'Hiển thị ảnh và video trong mọi thư mục', onClick: () => {
      overviewGalleryFolderFilter = 'all'; kvSet(overviewGalleryKey() + ':folder', 'all'); overviewGalleryRenderLimit = 120; closeSheet(); renderOverviewGallery();
    } });
    folders.forEach((folder) => sheetItem(body, folder, { icon: 'i-folder', active: overviewGalleryFolderFilter === folder, sub: 'Chỉ hiển thị nội dung trong ' + folder, onClick: () => {
      overviewGalleryFolderFilter = folder; kvSet(overviewGalleryKey() + ':folder', folder); overviewGalleryRenderLimit = 120; closeSheet(); renderOverviewGallery();
    } }));
  });
}
function openOverviewGalleryDayPicker() {
  const favorites = overviewGalleryFavorites();
  const query = overviewGalleryText(overviewGalleryQuery);
  const candidates = overviewGalleryItems.filter((item) => {
    if (!item || !item.rel || overviewPathIsConfiguredProtected(item.rel, item.pool || 'main')) return false;
    if (overviewGalleryFolderFilter !== 'all' && overviewMediaFolder(item) !== overviewGalleryFolderFilter) return false;
    if (overviewGalleryFilter === 'image' && item.kind !== 'image') return false;
    if (overviewGalleryFilter === 'video' && item.kind !== 'video') return false;
    if (overviewGalleryFilter === 'favorite' && !favorites.has(String(item.pool || 'main') + '|' + item.rel)) return false;
    return !query || overviewGalleryText(item.name + ' ' + item.rel).includes(query);
  }).sort((a, b) => Number(b.at || overviewGalleryTimestamp(b) || 0) - Number(a.at || overviewGalleryTimestamp(a) || 0));
  const days = new Map();
  candidates.forEach((item) => {
    const key = overviewGalleryCalendarKey(item);
    const group = days.get(key);
    if (group) group.count += 1;
    else days.set(key, { key, count: 1, item });
  });
  openSheet('Ngày', (body) => {
    body.className = 'media-day-picker-body';
    const clear = document.createElement('button');
    clear.type = 'button';
    clear.className = 'media-day-picker-clear' + (overviewGalleryDayFilter === 'all' ? ' active' : '');
    clear.innerHTML = iconSvg('i-image', 'svg-20') + '<span><strong>Tất cả ngày</strong><small>Hiển thị toàn bộ ảnh và video</small></span>' + (overviewGalleryDayFilter === 'all' ? iconSvg('i-check', 'svg-18') : '');
    clear.addEventListener('click', () => {
      overviewGalleryDayFilter = 'all';
      kvSet(overviewGalleryKey() + ':day', 'all');
      overviewGallerySort = 'date-desc';
      kvSet(overviewGalleryKey() + ':sort', overviewGallerySort);
      overviewGalleryRenderLimit = 120;
      closeSheet(); renderOverviewGallery();
    });
    body.appendChild(clear);
    const grid = document.createElement('div');
    grid.className = 'media-day-picker-grid';
    days.forEach((group) => {
      const label = overviewGalleryCalendarLabel(group.key);
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'media-day-card' + (overviewGalleryDayFilter === group.key ? ' active' : '');
      const thumb = mediaThumbUrl(group.item, 160);
      button.innerHTML = (thumb ? '<img src="' + esc(thumb) + '" alt="" decoding="async">' : iconSvg(group.item.kind === 'video' ? 'i-video' : 'i-image', 'svg-28')) +
        '<span class="media-day-card-label"><strong>' + esc(label.day) + '</strong><small>' + esc(label.monthYear) + '</small></span><span class="media-day-card-count">' + group.count + '</span>';
      button.addEventListener('click', () => {
        overviewGalleryDayFilter = group.key;
        kvSet(overviewGalleryKey() + ':day', group.key);
        overviewGallerySort = 'date-desc';
        kvSet(overviewGalleryKey() + ':sort', overviewGallerySort);
        overviewGalleryRenderLimit = 120;
        closeSheet(); renderOverviewGallery();
        const scroll = document.querySelector('#overview .overview-scroll');
        if (scroll) scroll.scrollTop = 0;
      });
      grid.appendChild(button);
    });
    if (!days.size) grid.innerHTML = '<div class="media-day-picker-empty">Không có ngày phù hợp với bộ lọc hiện tại.</div>';
    body.appendChild(grid);
  });
}
if (overviewGallerySortButton) overviewGallerySortButton.addEventListener('click', () => {
  openSheet('Sắp xếp ảnh và video', (body) => {
    sheetItem(body, 'Sắp xếp theo Ngày', { icon: 'i-sort', active: overviewGalleryDayFilter !== 'all', sub: overviewGalleryDayFilter === 'all' ? 'Chọn ngày để xem' : overviewGalleryCalendarLabel(overviewGalleryDayFilter).day + ' ' + overviewGalleryCalendarLabel(overviewGalleryDayFilter).monthYear, onClick: openOverviewGalleryDayPicker });
    [['size', 'Dung lượng']].forEach(([criterion, label]) => {
      const active = overviewSortCriterion(overviewGallerySort) === criterion;
      const direction = active ? overviewSortLabels[overviewGallerySort] : (criterion === 'date' ? 'Mới nhất trước' : criterion === 'name' ? 'A → Z' : 'Nhỏ nhất trước');
      sheetItem(body, 'Sắp xếp theo ' + label, { icon: 'i-sort', active, sub: direction, onClick: () => toggleOverviewSort(criterion) });
    });
    sheetItem(body, 'Sắp xếp theo Thư mục', { icon: 'i-folder', active: overviewGalleryFolderFilter !== 'all', sub: overviewGalleryFolderFilter === 'all' ? 'Tất cả thư mục' : overviewGalleryFolderFilter, onClick: openOverviewGalleryFolderPicker });
  });
});
if (overviewGallerySearch) {
  let overviewGallerySearchTimer = 0;
  overviewGallerySearch.addEventListener('input', () => {
    clearTimeout(overviewGallerySearchTimer);
    overviewGallerySearchTimer = setTimeout(() => {
      overviewGalleryQuery = overviewGallerySearch.value || '';
      overviewGalleryRenderLimit = 120;
      renderOverviewGallery();
    }, 160);
  });
}
const overviewGalleryFilters = document.getElementById('overviewGalleryFilters');
if (overviewGalleryFilters) overviewGalleryFilters.addEventListener('click', (event) => {
  const button = event.target.closest('[data-gallery-filter]');
  if (!button) return;
  overviewGalleryFilter = button.dataset.galleryFilter || 'all';
  overviewGalleryRenderLimit = 120;
  overviewGalleryFilters.querySelectorAll('[data-gallery-filter]').forEach((item) => item.classList.toggle('active', item === button));
  renderOverviewGallery();
});
const overviewGalleryRefresh = document.getElementById('overviewGalleryRefresh');
if (overviewGalleryRefresh) overviewGalleryRefresh.addEventListener('click', () => refreshOverviewGallery(true));
const overviewGallerySelectionAction = document.getElementById('overviewGallerySelectionAction');
if (overviewGallerySelectionAction) overviewGallerySelectionAction.addEventListener('click', openOverviewGallerySelectionSheet);
const overviewGalleryDeviceSwitch = document.getElementById('overviewGalleryDeviceSwitch');
if (overviewGalleryDeviceSwitch) overviewGalleryDeviceSwitch.addEventListener('click', openOverviewGalleryDevicePicker);
const overviewGalleryMore = document.getElementById('overviewGalleryMore');
if (overviewGalleryMore && 'IntersectionObserver' in window) {
  overviewGalleryObserver = new IntersectionObserver((entries) => {
    if (!entries.some((entry) => entry.isIntersecting) || overviewGalleryRenderLimit >= overviewGalleryVisible.length) return;
    overviewGalleryRenderLimit += 120;
    renderOverviewGallery();
  }, { root: document.querySelector('#overview .overview-scroll'), rootMargin: '500px 0px' });
  overviewGalleryObserver.observe(overviewGalleryMore);
}
$$('[data-overview-go]').forEach((b) => b.addEventListener('click', () => activateMainView(b.dataset.overviewGo)));
setInterval(() => { if (currentView === 'overview') renderOverview(); }, 2500);

function sheetPrompt(title, placeholder, value, onOk) {
  openSheet(title, (body) => {
    const wrap = document.createElement('div');
    wrap.className = 'field';
    wrap.innerHTML = '<div class="input-wrap"><input placeholder="' + esc(placeholder) + '"></div>';
    body.appendChild(wrap);
    const input = wrap.querySelector('input');
    input.value = value || '';
    setTimeout(() => input.focus(), 60);
    const row = document.createElement('div');
    row.className = 'row-btn';
    row.innerHTML = '<button class="btn secondary">Hủy</button><button class="btn primary">OK</button>';
    row.children[0].addEventListener('click', closeSheet);
    row.children[1].addEventListener('click', () => {
      const v = input.value.trim();
      if (!v) { DC.toast('Vui lòng nhập giá trị'); return; }
      closeSheet();
      onOk(v);
    });
    body.appendChild(row);
  });
}

function sheetConfirm(title, message, okLabel, onOk) {
  openSheet(title, (body) => {
    const p = document.createElement('div');
    p.style.cssText = 'font-size:13.5px;color:#475467;line-height:1.6;margin-bottom:6px';
    p.textContent = message;
    body.appendChild(p);
    const row = document.createElement('div');
    row.className = 'row-btn';
    row.innerHTML = '<button class="btn secondary">Hủy</button><button class="btn primary">' + esc(okLabel) + '</button>';
    row.children[0].addEventListener('click', closeSheet);
    row.children[1].addEventListener('click', () => { closeSheet(); onOk(); });
    body.appendChild(row);
  });
}

/* ---------- DISCOVER ---------- */
let discoverRunning = false;
async function runDiscover() {
  if (discoverRunning) return;
  discoverRunning = true;
  const scanBtn = $('#scanBtn');
  const oldText = scanBtn.innerHTML;
  scanBtn.textContent = 'Đang quét mạng...';
  scanBtn.disabled = true;
  try {
    const r = await Promise.race([
      callNative('discover', JSON.stringify({ timeoutMs: 2600 })),
      new Promise((res) => setTimeout(() => res({ hosts: [] }), 8500)),
    ]);
    renderHosts((r && r.hosts) || []);
  } catch (e) {
    renderHosts([]);
  } finally {
    scanBtn.innerHTML = oldText;
    scanBtn.disabled = false;
    discoverRunning = false;
  }
}

function getSavedManualHosts() {
  const v = kvGet('saved_manual_hosts');
  return Array.isArray(v) ? v : [];
}

function saveManualHost(h) {
  if (!h || !h.ip) return;
  let list = getSavedManualHosts();
  const port = h.port || 8080;
  list = list.filter(item => !(item.ip === h.ip && (item.port || 8080) === port));
  list.unshift({ ip: h.ip, port, host: h.host || h.ip, name: h.name || 'CW Datacenter' });
  if (list.length > 20) list = list.slice(0, 20);
  kvSet('saved_manual_hosts', list);
}

function isTailscaleHost(host) {
  const parts = String(host || '').trim().split('.').map(Number);
  return parts.length === 4 && parts.every(Number.isFinite) && parts[0] === 100 && parts[1] >= 64 && parts[1] <= 127;
}

function removeSavedManualHost(ip, port, e) {
  if (e) e.stopPropagation();
  let list = getSavedManualHosts();
  const p = parseInt(port, 10) || 8080;
  list = list.filter(item => !(item.ip === ip && (item.port || 8080) === p));
  kvSet('saved_manual_hosts', list);
  renderHosts([]);
  runDiscover();
}

function renderHosts(hosts) {
  const list = $('#discover .host-list');
  list.innerHTML = '';

  const savedHosts = getSavedManualHosts();
  const allMap = new Map();

  (hosts || []).forEach((h) => {
    const key = h.ip + ':' + (h.port || 8080);
    allMap.set(key, { ...h, isOnline: true, isManual: false });
  });

  savedHosts.forEach((sh) => {
    const key = sh.ip + ':' + (sh.port || 8080);
    if (!allMap.has(key)) {
      allMap.set(key, { ...sh, isOnline: false, isManual: true });
    } else {
      const existing = allMap.get(key);
      allMap.set(key, { ...existing, isSaved: true });
    }
  });

  const mergedHosts = Array.from(allMap.values());

  if (!mergedHosts.length) {
    const d = document.createElement('div');
    d.className = 'empty';
    d.textContent = 'Không tìm thấy máy chủ CW Datacenter trên mạng.\nHãy chắc chắn Host đang chạy, rồi bấm Quét lại hoặc Kết nối thủ công.';
    d.style.whiteSpace = 'pre-line';
    list.appendChild(d);
    return;
  }

  mergedHosts.forEach((h) => {
    const card = document.createElement('div');
    card.className = 'host-card';
    const statusBadge = h.isOnline !== false
      ? '<span class="badge online">● Trực tuyến</span>'
      : '<span class="badge" style="background:#f1f5f9;color:#64748b">Đã lưu</span>';
    const tagBadge = h.isManual
      ? '<span class="badge lan">Thủ công · ' + esc(h.name || 'CW Datacenter') + '</span>'
      : '<span class="badge lan">LAN · ' + esc(h.name || 'CW Datacenter') + '</span>';

    const pVal = h.port || 8080;
    const removeBtn = (h.isManual || h.isSaved)
      ? '<button class="icon-btn remove-host-btn" title="Xóa khỏi danh sách" style="padding:6px;margin-right:2px;color:#94a3b8"><svg class="svg-18"><use href="#i-trash"/></svg></button>'
      : '';

    card.innerHTML =
      '<div class="host-icon">' + iconSvg('i-server', 'svg-26') + '</div>' +
      '<div><div class="host-name">' + esc(h.host || h.ip) + '</div>' +
      '<div class="host-meta">' + esc(h.ip) + (h.port && h.port !== 8080 ? ' :' + h.port : '') + '</div>' +
      '<div class="host-badges">' + statusBadge + tagBadge + '</div></div>' +
      '<div style="display:flex;align-items:center;gap:2px">' + removeBtn + '<div style="color:#98a2b3">' + iconSvg('i-chevron-right', 'svg-22') + '</div></div>';

    const rBtn = card.querySelector('.remove-host-btn');
    if (rBtn) {
      rBtn.addEventListener('click', (e) => removeSavedManualHost(h.ip, pVal, e));
    }

    card.addEventListener('click', () => selectServer(h));
    list.appendChild(card);
  });
}

function selectServer(h) {
  const ip = h.ip;
  const port = h.port || 8080;
  server = {
    ip, port,
    baseUrl: 'http://' + ip + ':' + port,
    host: h.host || ip,
    name: h.host || ip,
    via: isTailscaleHost(ip) ? 'tailscale' : 'lan',
  };
  const signinError = $('#signinError');
  if (signinError) { signinError.textContent = ''; signinError.classList.remove('show'); }
  $('#signHost').textContent = server.name;
  $('#signIp').textContent = server.ip;
  const creds = kvGet(kCreds()) || {};
  $('#userInput').value = creds.u || '';
  $('#passInput').value = creds.p || '';
  rememberDevice = creds.rem !== false;
  $('#rememberBox').classList.toggle('checked', rememberDevice);
  $('#rememberBox').textContent = rememberDevice ? '✓' : '';
  go('signin');
  probeSignin();
}

async function probeSignin() {
  const p = $('#signin .server-summary p');
  if (p) p.innerHTML = '<span id="signIp">' + esc(server.ip) + '</span> · ' + (server.via === 'tailscale' ? 'Tailscale' : 'LAN') + ' · <span style="color:#667085">● Đang kiểm tra...</span>';
  try {
    const r = await tryApi(server.baseUrl, '/api/ping', 'GET');
    server.via = r.via || (isTailscaleHost(server.ip) ? 'tailscale' : 'lan');
    if (p) p.innerHTML = '<span id="signIp">' + esc(server.ip) + '</span> · ' + (server.via === 'tailscale' ? 'Tailscale' : 'LAN') + ' · <span style="color:var(--green)">● Trực tuyến</span>';
  } catch (e) {
    if (p) p.innerHTML = '<span id="signIp">' + esc(server.ip) + '</span> · ' + (server.via === 'tailscale' ? 'Tailscale' : 'LAN') + ' · <span style="color:var(--red)">● Chưa kết nối</span>';
  }
}

$('#scanBtn').addEventListener('click', runDiscover);
$('#manualBtn').addEventListener('click', () => $('#manualModal').classList.add('show'));
$('#closeManual').addEventListener('click', () => $('#manualModal').classList.remove('show'));
$('#manualModal').addEventListener('click', (e) => { if (e.target === $('#manualModal')) $('#manualModal').classList.remove('show'); });
$('#manualConnect').addEventListener('click', () => {
  let host = $('#manualHost').value.trim();
  if (!host) { DC.toast('Nhập địa chỉ máy chủ'); return; }
  host = host.replace(/^https?:\/\//i, '').replace(/\/+$/, '');
  let port = 8080;
  if (host.includes(':')) {
    const parts = host.split(':');
    host = parts[0];
    port = parseInt(parts[1], 10) || 8080;
  } else {
    const portInput = $$('#manualModal .input-wrap input')[1];
    port = parseInt(portInput && portInput.value, 10) || 8080;
  }
  $('#manualModal').classList.remove('show');
  const manualServer = { ip: host, port, host: host, name: 'CW Datacenter' };
  saveManualHost(manualServer);
  selectServer(manualServer);
});

const offVidBtn = document.getElementById('offlineVideosBtn');
if (offVidBtn) {
  offVidBtn.addEventListener('click', () => {
    if (hasOfflinePassword()) {
      openPromptOfflinePwdForAction('Mật khẩu Video Offline', 'Nhập mật khẩu để mở danh sách video offline:', () => {
        openOfflineView();
      });
    } else {
      openOfflineView();
    }
  });
}
const offBackBtn = document.getElementById('offlineBackBtn');
if (offBackBtn) offBackBtn.addEventListener('click', () => { go('discover'); refreshOfflineCountBadge(); });
const discSetBtn = document.getElementById('discoverSettingsBtn');
if (discSetBtn) discSetBtn.addEventListener('click', openDiscoverSettingsSheet);

/* ---------- OFFLINE PASSWORD MANAGEMENT ---------- */

const kOfflinePwdKey = 'cw_offline_pwd';

function getOfflinePasswordHash() {
  const v = DC.loadKV(kOfflinePwdKey);
  return (v && typeof v === 'string') ? v.trim() : '';
}

function hasOfflinePassword() {
  const h = getOfflinePasswordHash();
  return !!(h && h.length > 0);
}

function verifyOfflinePassword(input) {
  const stored = getOfflinePasswordHash();
  if (!stored) return true;
  if (!input) return false;
  const hash = sha256js(String(input).trim());
  return hash === stored || String(input).trim() === stored;
}

function setOfflinePassword(pwd) {
  const hash = sha256js(String(pwd).trim());
  DC.saveKV(kOfflinePwdKey, hash);
}

function removeOfflinePassword() {
  try { DC.removeKV(kOfflinePwdKey); } catch (e) {}
  DC.saveKV(kOfflinePwdKey, '');
}

function openCreateOfflinePwdSheet() {
  openSheet('Tạo mật khẩu Video Offline', (body) => {
    const desc = document.createElement('div');
    desc.style.cssText = 'font-size:13px;color:#64748b;line-height:1.5;margin-bottom:12px';
    desc.textContent = 'Thiết lập mật khẩu bảo vệ để chỉ người có mật khẩu mới xem hoặc xóa được video offline.';
    body.appendChild(desc);

    const f1 = document.createElement('div');
    f1.className = 'field';
    f1.innerHTML = '<label style="font-size:12px;font-weight:600;color:#475467">Mật khẩu mới</label><div class="input-wrap"><input type="password" placeholder="Nhập mật khẩu mới" autocomplete="new-password"></div>';
    body.appendChild(f1);

    const f2 = document.createElement('div');
    f2.className = 'field';
    f2.style.marginTop = '10px';
    f2.innerHTML = '<label style="font-size:12px;font-weight:600;color:#475467">Xác nhận mật khẩu</label><div class="input-wrap"><input type="password" placeholder="Nhập lại mật khẩu mới" autocomplete="new-password"></div>';
    body.appendChild(f2);

    const i1 = f1.querySelector('input');
    const i2 = f2.querySelector('input');
    setTimeout(() => i1.focus(), 60);

    const doSubmit = () => {
      const p1 = (i1.value || '').trim();
      const p2 = (i2.value || '').trim();
      if (!p1) { DC.toast('Vui lòng nhập mật khẩu'); return; }
      if (p1 !== p2) { DC.toast('Mật khẩu xác nhận không khớp'); return; }
      setOfflinePassword(p1);
      closeSheet();
      DC.toast('Đã tạo mật khẩu Video Offline thành công');
    };

    i1.addEventListener('keydown', (e) => { if (e.key === 'Enter') i2.focus(); });
    i2.addEventListener('keydown', (e) => { if (e.key === 'Enter') doSubmit(); });

    const row = document.createElement('div');
    row.className = 'row-btn';
    row.style.marginTop = '16px';
    row.innerHTML = '<button class="btn secondary">Hủy</button><button class="btn primary">Tạo mật khẩu</button>';
    row.children[0].addEventListener('click', closeSheet);
    row.children[1].addEventListener('click', doSubmit);
    body.appendChild(row);
  });
}

function openChangeOfflinePwdSheet() {
  openSheet('Đổi mật khẩu Video Offline', (body) => {
    const f0 = document.createElement('div');
    f0.className = 'field';
    f0.innerHTML = '<label style="font-size:12px;font-weight:600;color:#475467">Mật khẩu hiện tại</label><div class="input-wrap"><input type="password" placeholder="Nhập mật khẩu hiện tại" autocomplete="current-password"></div>';
    body.appendChild(f0);

    const f1 = document.createElement('div');
    f1.className = 'field';
    f1.style.marginTop = '10px';
    f1.innerHTML = '<label style="font-size:12px;font-weight:600;color:#475467">Mật khẩu mới</label><div class="input-wrap"><input type="password" placeholder="Nhập mật khẩu mới" autocomplete="new-password"></div>';
    body.appendChild(f1);

    const f2 = document.createElement('div');
    f2.className = 'field';
    f2.style.marginTop = '10px';
    f2.innerHTML = '<label style="font-size:12px;font-weight:600;color:#475467">Xác nhận mật khẩu mới</label><div class="input-wrap"><input type="password" placeholder="Nhập lại mật khẩu mới" autocomplete="new-password"></div>';
    body.appendChild(f2);

    const i0 = f0.querySelector('input');
    const i1 = f1.querySelector('input');
    const i2 = f2.querySelector('input');
    setTimeout(() => i0.focus(), 60);

    const doSubmit = () => {
      const oldP = (i0.value || '').trim();
      const p1 = (i1.value || '').trim();
      const p2 = (i2.value || '').trim();
      if (!verifyOfflinePassword(oldP)) { DC.toast('Mật khẩu hiện tại không đúng'); return; }
      if (!p1) { DC.toast('Vui lòng nhập mật khẩu mới'); return; }
      if (p1 !== p2) { DC.toast('Mật khẩu xác nhận không khớp'); return; }
      setOfflinePassword(p1);
      closeSheet();
      DC.toast('Đã đổi mật khẩu thành công');
    };

    i0.addEventListener('keydown', (e) => { if (e.key === 'Enter') i1.focus(); });
    i1.addEventListener('keydown', (e) => { if (e.key === 'Enter') i2.focus(); });
    i2.addEventListener('keydown', (e) => { if (e.key === 'Enter') doSubmit(); });

    const row = document.createElement('div');
    row.className = 'row-btn';
    row.style.marginTop = '16px';
    row.innerHTML = '<button class="btn secondary">Hủy</button><button class="btn primary">Đổi mật khẩu</button>';
    row.children[0].addEventListener('click', closeSheet);
    row.children[1].addEventListener('click', doSubmit);
    body.appendChild(row);
  });
}

function openRemoveOfflinePwdSheet() {
  openSheet('Xóa mật khẩu Video Offline', (body) => {
    const desc = document.createElement('div');
    desc.style.cssText = 'font-size:13px;color:#ef4444;line-height:1.5;margin-bottom:12px';
    desc.textContent = 'Sau khi xóa mật khẩu, bất kỳ ai cũng có thể vào xem và xóa video offline mà không cần mật khẩu.';
    body.appendChild(desc);

    const f0 = document.createElement('div');
    f0.className = 'field';
    f0.innerHTML = '<label style="font-size:12px;font-weight:600;color:#475467">Nhập mật khẩu hiện tại</label><div class="input-wrap"><input type="password" placeholder="Nhập mật khẩu hiện tại" autocomplete="current-password"></div>';
    body.appendChild(f0);

    const i0 = f0.querySelector('input');
    setTimeout(() => i0.focus(), 60);

    const doSubmit = () => {
      const oldP = (i0.value || '').trim();
      if (!verifyOfflinePassword(oldP)) { DC.toast('Mật khẩu không đúng'); return; }
      removeOfflinePassword();
      closeSheet();
      DC.toast('Đã xóa mật khẩu bảo vệ Video Offline');
    };

    i0.addEventListener('keydown', (e) => { if (e.key === 'Enter') doSubmit(); });

    const row = document.createElement('div');
    row.className = 'row-btn';
    row.style.marginTop = '16px';
    row.innerHTML = '<button class="btn secondary">Hủy</button><button class="btn primary" style="background:var(--red)">Xóa mật khẩu</button>';
    row.children[0].addEventListener('click', closeSheet);
    row.children[1].addEventListener('click', doSubmit);
    body.appendChild(row);
  });
}

function openPromptOfflinePwdForAction(title, descText, onOk) {
  openSheet(title, (body) => {
    if (descText) {
      const desc = document.createElement('div');
      desc.style.cssText = 'font-size:13px;color:#64748b;line-height:1.5;margin-bottom:12px';
      desc.textContent = descText;
      body.appendChild(desc);
    }

    const f0 = document.createElement('div');
    f0.className = 'field';
    f0.innerHTML = '<div class="input-wrap"><input type="password" placeholder="Nhập mật khẩu" autocomplete="current-password"></div>';
    body.appendChild(f0);

    const i0 = f0.querySelector('input');
    setTimeout(() => i0.focus(), 60);

    const doSubmit = () => {
      const p = (i0.value || '').trim();
      if (!verifyOfflinePassword(p)) { DC.toast('Mật khẩu không đúng, vui lòng thử lại'); return; }
      closeSheet();
      onOk();
    };

    i0.addEventListener('keydown', (e) => { if (e.key === 'Enter') doSubmit(); });

    const row = document.createElement('div');
    row.className = 'row-btn';
    row.style.marginTop = '16px';
    row.innerHTML = '<button class="btn secondary">Hủy</button><button class="btn primary">Xác nhận</button>';
    row.children[0].addEventListener('click', closeSheet);
    row.children[1].addEventListener('click', doSubmit);
    body.appendChild(row);
  });
}

/* ---------- OFFLINE VIDEOS (TẢI TRƯỚC / XEM NGOẠI TUYẾN) ---------- */

async function refreshOfflineCountBadge() {
  const badge = document.getElementById('offlineCountBadge');
  if (!badge) return;
  try {
    const res = await callNative('getOfflineVideos', '');
    if (res && res.ok && Array.isArray(res.videos)) {
      const count = res.videos.length;
      if (count > 0) {
        badge.textContent = count;
        badge.style.display = 'inline-block';
      } else {
        badge.style.display = 'none';
      }
      return res;
    }
  } catch (e) {}
  badge.style.display = 'none';
  return null;
}

async function openOfflineView() {
  go('offlineView');
  const summaryEl = document.getElementById('offlineSummary');
  const listEl = document.getElementById('offlineList');
  if (listEl) listEl.innerHTML = '<div class="empty">Đang tải danh sách video...</div>';
  try {
    const res = await callNative('getOfflineVideos', '');
    if (res && res.ok && Array.isArray(res.videos)) {
      const videos = res.videos;
      const totalSize = res.totalSize || 0;
      if (summaryEl) summaryEl.textContent = videos.length + ' video đã tải trước · ' + fmtBytes(totalSize);
      renderOfflineList(videos);
      return;
    }
  } catch (e) {}
  if (summaryEl) summaryEl.textContent = '0 video đã tải trước · 0 MB';
  if (listEl) listEl.innerHTML = '<div class="empty">Không có video offline nào.</div>';
}

function renderOfflineList(videos) {
  const listEl = document.getElementById('offlineList');
  if (!listEl) return;
  listEl.innerHTML = '';
  if (!videos || !videos.length) {
    const empty = document.createElement('div');
    empty.className = 'empty';
    empty.style.cssText = 'text-align:center;padding:2.5rem 1rem;color:#64748b;font-size:0.95rem;line-height:1.6;background:#f8fafc;border-radius:1rem;border:1px dashed #cbd5e1';
    empty.innerHTML = '<div style="margin-bottom:0.5rem;color:#7c3aed">' + iconSvg('i-video', 'svg-38') + '</div><b>Chưa có video nào được tải trước</b><br>Khi kết nối máy chủ, hãy nhấn <b>"Tải trước (Xem Offline)"</b> trên các video để xem ngoại tuyến tại đây.';
    listEl.appendChild(empty);
    return;
  }

  videos.forEach((v) => {
    const card = document.createElement('div');
    card.className = 'host-card';
    card.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:#fff;border:1px solid #e2e8f0;border-radius:12px;cursor:pointer;box-shadow:0 1px 3px rgba(0,0,0,0.04)';
    
    const sizeStr = fmtBytes(v.size || 0);
    const dateStr = v.savedAt ? fmtDate(v.savedAt) : '';

    card.innerHTML =
      '<div style="display:flex;align-items:center;gap:12px;flex:1;min-width:0">' +
        '<div style="width:40px;height:40px;border-radius:10px;background:#ede9fe;color:#7c3aed;display:flex;align-items:center;justify-content:center;flex-shrink:0">' +
          iconSvg('i-video', 'svg-22') +
        '</div>' +
        '<div style="min-width:0;flex:1">' +
          '<div style="font-weight:600;font-size:0.95rem;color:#1e293b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + esc(v.name || 'Video') + '</div>' +
          '<div style="font-size:0.8rem;color:#64748b;margin-top:2px;display:flex;align-items:center;gap:6px">' +
            '<span>' + sizeStr + '</span>' +
            (dateStr ? '<span>· ' + dateStr + '</span>' : '') +
            '<span class="badge" style="background:#ecfdf5;color:#059669;font-size:0.7rem;padding:1px 5px;border-radius:6px">Offline ✓</span>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div style="display:flex;align-items:center;gap:4px">' +
        '<button class="icon-btn del-off-btn" title="Xóa video này" style="color:#94a3b8;padding:8px"><svg class="svg-18"><use href="#i-trash"/></svg></button>' +
      '</div>';

    card.addEventListener('click', (e) => {
      if (e.target.closest('.del-off-btn')) return;
      callNative('playVideo', JSON.stringify({
        url: v.path,
        name: v.name,
        local: true
      }));
    });

    const delBtn = card.querySelector('.del-off-btn');
    if (delBtn) {
      delBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        sheetConfirm('Xóa video offline', 'Xóa "' + v.name + '" khỏi bộ nhớ ngoại tuyến của máy?', 'Xóa', async () => {
          try {
            await callNative('deleteOfflineVideo', JSON.stringify({ key: v.key }));
            DC.toast('Đã xóa "' + v.name + '"');
            openOfflineView();
            refreshOfflineCountBadge();
          } catch (err) {
            DC.toast('Lỗi: ' + errText(err));
          }
        });
      });
    }

    listEl.appendChild(card);
  });
}

function openDiscoverSettingsSheet() {
  openSheet('Cài đặt ứng dụng', async (body) => {
    let offRes = null;
    try { offRes = await callNative('getOfflineVideos', ''); } catch (e) {}
    const count = offRes && offRes.videos ? offRes.videos.length : 0;
    const totalSize = offRes ? fmtBytes(offRes.totalSize || 0) : '0 B';
    const hasPwd = hasOfflinePassword();

    // 1. Quản lý Mật khẩu Video Offline
    if (!hasPwd) {
      sheetItem(body, 'Tạo mật khẩu Video Offline', {
        icon: 'i-lock',
        sub: 'Khóa bảo vệ danh sách và dữ liệu video offline',
        onClick: () => {
          closeSheet();
          openCreateOfflinePwdSheet();
        }
      });
    } else {
      sheetItem(body, 'Đổi mật khẩu Video Offline', {
        icon: 'i-lock',
        sub: 'Thay đổi mật khẩu bảo vệ hiện tại',
        onClick: () => {
          closeSheet();
          openChangeOfflinePwdSheet();
        }
      });
      sheetItem(body, 'Xóa mật khẩu Video Offline', {
        icon: 'i-lock',
        danger: true,
        sub: 'Gỡ bỏ mật khẩu bảo vệ',
        onClick: () => {
          closeSheet();
          openRemoveOfflinePwdSheet();
        }
      });
    }

    // 2. Xóa toàn bộ video offline
    sheetItem(body, 'Xóa toàn bộ video offline (' + count + ' video · ' + totalSize + ')', {
      icon: 'i-trash',
      danger: true,
      onClick: () => {
        closeSheet();
        if (count === 0) {
          DC.toast('Không có video offline nào để xóa.');
          return;
        }
        if (hasOfflinePassword()) {
          openPromptOfflinePwdForAction('Xác nhận xóa video offline', 'Nhập mật khẩu để xác nhận xóa sạch toàn bộ ' + count + ' video (' + totalSize + '):', async () => {
            try {
              await callNative('clearAllOfflineVideos', '');
              DC.toast('Đã xóa toàn bộ video offline');
              refreshOfflineCountBadge();
              if (currentView === 'offlineView') openOfflineView();
            } catch (e) {
              DC.toast('Lỗi: ' + errText(e));
            }
          });
        } else {
          sheetConfirm('Xóa tất cả video offline', 'Bạn có chắc chắn muốn xóa sạch ' + count + ' video offline (' + totalSize + ') khỏi bộ nhớ máy?', 'Xóa tất cả', async () => {
            try {
              await callNative('clearAllOfflineVideos', '');
              DC.toast('Đã xóa toàn bộ video offline');
              refreshOfflineCountBadge();
              if (currentView === 'offlineView') openOfflineView();
            } catch (e) {
              DC.toast('Lỗi: ' + errText(e));
            }
          });
        }
      }
    });

    // 3. Xóa cache tạm
    sheetItem(body, 'Xóa bộ nhớ đệm tạm thời (Cache)', {
      icon: 'i-trash',
      onClick: async () => {
        closeSheet();
        try { await callNative('clearCache', ''); } catch (e) {}
        resetOverviewThumbnailWarmState();
        DC.toast('Đã dọn sạch bộ nhớ đệm tạm thời');
      }
    });
  });
}

function preloadVideosOffline(entries) {
  if (!entries || !entries.length) return;
  if (!server || !server.baseUrl) {
    DC.toast('Chưa kết nối máy chủ');
    return;
  }
  entries.forEach((e) => {
    const rel = relOf(e);
    const p = typeof ePool === 'function' ? ePool(e) : (pool || 'main');
    const streamUrl = server.baseUrl + '/api/file?path=' + enc(rel) + (p && p !== LOCAL_POOL ? '&pool=' + enc(p) : '');
    const tempKey = 'off:' + (p || 'main') + ':' + rel;

    transfers[tempKey] = {
      id: tempKey,
      key: tempKey,
      dir: 'down',
      name: e.name + ' (Offline)',
      rel: rel,
      pool: p || 'main',
      status: 'active',
      done: 0,
      total: e.size || 0,
      speed: 0,
      isOffline: true,
      spec: { url: streamUrl, name: e.name, pool: p, rel: rel },
      createdAt: Date.now()
    };

    callNative('startOfflinePreload', JSON.stringify({
      url: streamUrl,
      name: e.name,
      pool: p || 'main',
      rel: rel,
      token: token || ''
    })).then((res) => {
      if (res && res.key) {
        const realId = 'off:' + res.key;
        if (realId !== tempKey && transfers[tempKey]) {
          transfers[realId] = Object.assign({}, transfers[tempKey], { id: realId, key: realId });
          delete transfers[tempKey];
        }
        if (res.done && transfers[realId]) {
          transfers[realId].status = 'done';
          transfers[realId].finishedAt = Date.now();
        }
      }
      if (currentView === 'transfers') renderTransfers();
      refreshOfflineCountBadge();
    }).catch((err) => {
      if (transfers[tempKey]) {
        transfers[tempKey].status = 'error';
        transfers[tempKey].finishedAt = Date.now();
        transfers[tempKey].err = errText(err);
      }
      if (currentView === 'transfers') renderTransfers();
    });
  });
  renderFiles();
  if (currentView === 'transfers') renderTransfers();
  DC.toast(entries.length === 1 ? 'Đang tải trước "' + entries[0].name + '" (Xem trong tab Truyền tải)' : 'Đang tải trước ' + entries.length + ' video (Xem trong tab Truyền tải)');
}

/* ---------- SIGN IN ---------- */
$('#eyeBtn').addEventListener('click', () => {
  const i = $('#passInput');
  i.type = i.type === 'password' ? 'text' : 'password';
});
$('#rememberBox').addEventListener('click', () => {
  rememberDevice = !rememberDevice;
  $('#rememberBox').classList.toggle('checked', rememberDevice);
  $('#rememberBox').textContent = rememberDevice ? '✓' : '';
});
$('#signin .text-btn').addEventListener('click', () => DC.toast('Liên hệ người quản trị máy chủ để đặt lại mật khẩu.'));

$('#signinBtn').addEventListener('click', async () => {
  const username = $('#userInput').value.trim();
  const password = $('#passInput').value;
  const errorBox = $('#signinError');
  const showSigninError = (message) => {
    if (!errorBox) return;
    errorBox.textContent = message || '';
    errorBox.classList.toggle('show', !!message);
  };
  showSigninError('');
  if (!username || !password) {
    const message = 'Vui lòng nhập đầy đủ tên tài khoản và mật khẩu.';
    showSigninError(message);
    DC.toast(message);
    return;
  }
  const btn = $('#signinBtn');
  const old = btn.textContent;
  btn.disabled = true; btn.textContent = 'Đang đăng nhập...';
  try {
    const data = await api('/api/login', 'POST', { username, password, device: HOST + (IS_IOS ? ' (iOS)' : ' (Android)') });
    token = data.token;
    me = { role: data.role || 'admin', user: data.user || username || 'admin' };
    kvSet(kToken(), token);
    if (rememberDevice) {
      DC.saveKV(kCreds(), JSON.stringify({ u: username, p: password, rem: true }));
    } else {
      DC.saveKV(kCreds(), JSON.stringify({ u: username, p: '', rem: false }));
    }
    saveManualHost({ ip: server.ip, port: server.port, host: server.host, name: server.name });
    fillTrust();
    rememberLast();
    if (DC.loadKV(kTrust()) === '1') { enterMain(); }
    else { go('trust'); }
  } catch (e) {
    const message = errText(e);
    showSigninError(message);
    DC.toast(message);
    try { DC.appLog('ERROR', 'LOGIN', message + ' @ ' + (server ? server.baseUrl : '')); } catch (ignored) {}
  } finally {
    btn.disabled = false; btn.textContent = old;
  }
});

function fillTrust() {
  if (!server || !me) return;
  $('#trustHost').textContent = server.name;
  $('#trustHost2').textContent = server.name;
  $('#trustUser').textContent = me.user;
  const ipEl = $('#trustIp'); if (ipEl) ipEl.textContent = META.ip || '';
  const connEl = $('#trustConn'); if (connEl) connEl.textContent = server.via === 'tailscale' ? 'Tailscale' : 'LAN';
  const devEl = $('#trustDeviceInfo'); if (devEl) devEl.textContent = (IS_IOS ? (META.ios || 'iOS') : ('Android ' + (META.android || ''))) + ' · Ứng dụng CW';
}

/* ---------- TRUST ---------- */
$('#trustBtn').addEventListener('click', () => {
  DC.saveKV(kTrust(), '1');
  enterMain();
});
$('#trust .back').addEventListener('click', () => go('signin'));
$('#trust .row-btn .btn.secondary').addEventListener('click', () => go('signin'));
$('#signin .back').addEventListener('click', () => go('discover'));

/* Quét tự động ảnh camera mới -> đối chiếu host và đẩy lên (1 chiều). */
let autoSyncTimer = null;
let autoSyncRunning = false;
async function autoSyncCheck() {
  if (!server || !token || autoSyncRunning || syncPaused) return;
  if (!camOn) return;
  autoSyncRunning = true;
  try {
    if (typeof syncCameraNow === 'function') {
      await syncCameraNow(true);
    }
  } catch (e) {}
  autoSyncRunning = false;
}
function startAutoSync() {
  if (autoSyncTimer) clearInterval(autoSyncTimer);
  if (IS_IOS) { autoSyncTimer = null; return; }
  autoSyncTimer = setInterval(autoSyncCheck, 30000);
}

function enterMain() {
  $$('.activeHost').forEach((el) => el.textContent = server.name);
  favs = kvGet(kFavs()) || [];
  fileViewMode = ['auto', 'gallery', 'list'].includes(kvGet('fileViewMode')) ? kvGet('fileViewMode') : 'auto';
  syncDb = kvGet(kSync()) || {};
  dlPaths = kvGet(kDlPaths()) || {};
  const savedCameraAuto = kvGet('cam:' + server.baseUrl);
  camOn = IS_IOS ? false : !!savedCameraAuto;
  const savedMediaMode = kvGet(kIOSCameraMediaMode());
  iosCameraMediaMode = ['all', 'photos', 'videos'].includes(savedMediaMode) ? savedMediaMode : 'all';
  const savedStorageMode = kvGet(kIOSCameraStorageMode());
  iosCameraStorageMode = ['all', 'local', 'icloud'].includes(savedStorageMode) ? savedStorageMode : 'all';
  iosCameraFolderCustom = cleanIOSCameraFolderName(kvGet(kIOSCameraFolderName()) || '');
  iosCameraImageFolderLimit = Math.max(25, Math.min(5000, Number(kvGet(kIOSCameraImageFolderLimit()) || 400)));
  iosCameraVideoFolderLimit = Math.max(25, Math.min(5000, Number(kvGet(kIOSCameraVideoFolderLimit()) || 300)));
  iosCameraDeleteAfterUpload = kvGet(kIOSCameraDeleteAfterUpload()) === true;
  localDrive = kvGet(kLocalDrive()) || null;
  overviewLocksReady = false;
  overviewContinueIdentity = '';
  loadSyncDest();
  try { DC.setSession(server.baseUrl, token); } catch (e) {}
  $$('.nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.target === 'overview'));
  pool = LOCAL_POOL;
  currentPath = '';
  parentPath = null;
  entries = [];
  localNav = [];
  go('overview');
  renderOverview();
  syncLocksFromServer().finally(() => {
    overviewLocksReady = true;
    if (currentView === 'overview') renderOverview();
  });
  applyFabPos();
  updateFabVisibility();
  renderPoolBar();
  loadLocalFiles();
  loadPools().then(() => {
    renderPoolBar();
    if (IS_IOS) refreshIOSCameraStats(true);
  });
  collectIncomingShares();
  startKeepAlive();
  restorePending();
  // Chỉ upload khi người dùng chủ động nhấn Đồng bộ.
  // Vẫn tải thống kê read-only để hiển thị số mục đã có trên Host.
  if (!IS_IOS) startAutoSync();
  else if (autoSyncTimer) { clearInterval(autoSyncTimer); autoSyncTimer = null; }
}

function onSessionLost() {
  token = null;
  try { DC.setSession('', ''); } catch (e) {}
  DC.removeKV(kToken());
  DC.toast('Phiên đăng nhập đã hết hạn');
  go('signin');
  $('#passInput').value = '';
}

/* ---------- KEEP ALIVE ---------- */
let keepAliveTimer = null;
function startKeepAlive() {
  if (keepAliveTimer) clearInterval(keepAliveTimer);
  keepAliveTimer = setInterval(async () => {
    if (!token || !server) return;
    try {
      await Promise.race([
        api('/api/health'),
        new Promise((_, rej) => setTimeout(() => rej('timeout'), 4000)),
      ]);
      setConn(true);
    } catch (e) { setConn(false); }
  }, 12000);
}
function setConn(ok) {
  $$('.connected .dot').forEach((d) => d.classList.toggle('offline', !ok));
  $$('.connected').forEach((c) => {
    const host = server ? server.name : '';
    c.innerHTML = '';
    const dot = document.createElement('span'); dot.className = 'dot' + (ok ? '' : ' offline');
    c.appendChild(dot);
    c.appendChild(document.createTextNode(ok ? 'Đã kết nối tới ' : 'Mất kết nối · '));
    const b = document.createElement('span'); b.className = 'activeHost'; b.textContent = host;
    c.appendChild(b);
  });
}

/* ---------- FILES ---------- */
async function loadPools() {
  try {
    const d = await api('/api/pools');
    const all = d.pools || [];
    pools = all.filter(p => !isSharedPool(p));
    const cam = d.cameraPool || null;
    if (cam && cam.id) {
      cameraPoolCache = String(cam.id);
      cameraStorageRevision = Number(cam.revision || d.storageRevision || 0);
    }
    const prev = pool;
    if (prev === LOCAL_POOL) pool = LOCAL_POOL;
    else if (prev && !isSharedPool(prev) && pools.some((p) => p.id === prev && p.online)) pool = prev;
    else {
      const def = pools.find((p) => p.isDefault && p.online) || pools.find((p) => p.online) || pools[0];
      pool = def ? def.id : (pools.length ? pools[0].id : LOCAL_POOL);
    }
  } catch (e) { pools = []; pool = LOCAL_POOL; }
  renderPoolBar();
}

async function loadFiles(path, force) {
  const navSeq = ++fileNavSeq;
  const targetPool = pool;
  renderPoolBar();
  if (isLocalMode()) { loadLocalFiles(); return; }
  await syncLocksFromServer();
  if (navSeq !== fileNavSeq || pool !== targetPool) return;
  if (isPoolLocked(pool)) { renderLockedPoolState(); DC.setCanGoBack(false); return; }
  try {
    const d = await api('/api/files?path=' + enc(path || '') + (targetPool ? '&pool=' + enc(targetPool) : ''));
    if (navSeq !== fileNavSeq || pool !== targetPool) return;
    const resolved = normalizeHostFileResponse(d, targetPool);
    if (syncDeviceBrowse && syncDeviceBrowse.pending && targetPool === syncDeviceBrowse.requestedPool && String(path || '') === syncDeviceBrowse.requestedRoot) {
      syncDeviceBrowse.pool = resolved.pool;
      syncDeviceBrowse.root = resolved.path;
      syncDeviceBrowse.pending = false;
    }
    if (resolved.pool && resolved.pool !== pool) pool = resolved.pool;
    currentPath = resolved.path;
    parentPath = resolved.parent;
    entries = resolved.entries;
    renderCrumb();
    renderFiles();
    renderPoolBar();
    DC.setCanGoBack(currentPath !== '');
    maybePromptIncomingShares();
  } catch (e) {
    if (navSeq !== fileNavSeq || pool !== targetPool) return;
    const status = Number(e && e.status || 0);
    if (status > 0 && status < 500) {
      DC.toast(errText(e));
      return;
    }
    entries = [];
    currentPath = '';
    parentPath = null;
    renderCrumb();
    renderFiles();
    renderPoolBar();
    DC.toast(errText(e));
    if (path) setTimeout(() => { if (pool === targetPool && currentPath === '') loadFiles(''); }, 150);
  }
}

async function loadLocalFiles() {
  const list = $('#files .file-list');
  if (!localDrive || !localDrive.fs) {
    const ok = await ensureLocalFsAccess();
    if (!ok) { renderLocalNoAccess(); return; }
  } else {
    refreshLocalFree();
  }
  const cur = localNav.length ? localNav[localNav.length - 1].path : '';
  list.innerHTML = '<div class="empty">Đang tải…</div>';
  try {
    const r = await callNative('localFsList', JSON.stringify({ path: cur }));
    if (!localNav.length && r.parentId) localNav = [{ path: r.parentId, name: 'Bộ nhớ trong' }];
    entries = ((r && r.entries) || []).map((e) => ({
      name: e.name,
      type: (e.dir || e.type === 'dir') ? 'dir' : 'file',
      size: e.size || 0,
      mtime: e.mtime ? new Date(e.mtime).toISOString() : '',
      _local: true, _fs: true, _p: e.id || e.p || e.path || '', _mime: e.mime || '',
    }));
    renderLocalCrumb();
    renderFiles();
    DC.setCanGoBack(localNav.length > 1);
  } catch (e) {
    entries = [];
    renderLocalNoAccess();
    DC.toast(errText(e));
  }
}

function renderLocalNoAccess() {
  const list = $('#files .file-list');
  const d = document.createElement('div');
  d.className = 'empty';
  d.style.paddingTop = '60px';
  d.innerHTML = '<div style="color:var(--blue)">' + iconSvg('i-phone', 'svg-38') + '</div>'
    + '<div style="margin-top:14px">Để xem các file/folder trên thiết bị, hãy cấp quyền truy cập.<br>Trên iPhone: thư mục được lưu trong Ứng dụng Tệp.</div>';
  const btn = document.createElement('button');
  btn.className = 'btn primary';
  btn.style.cssText = 'width:auto;padding:0 22px;margin:18px auto 0;display:block';
  btn.textContent = 'Cấp quyền truy cập';
  btn.addEventListener('click', async () => {
    const ok = await ensureLocalFsAccess();
    if (ok) loadLocalFiles();
  });
  d.appendChild(btn);
  list.innerHTML = '';
  list.appendChild(d);
  renderLocalCrumb();
}

function goLocalDir(id) {
  const e = entries.find((x) => x._p === id);
  localNav.push({ path: id, name: e ? e.name : id });
  loadLocalFiles();
}

function goLocalBack() {
  if (localNav.length > 1) { localNav.pop(); loadLocalFiles(); return true; }
  return false;
}

function updateBackBtn(show) {
  const btn = document.getElementById('bcBackBtn');
  if (btn) {
    btn.classList.toggle('show', !!show);
  }
}

function renderLocalCrumb() {
  const trail = document.getElementById('bcTrail') || $('#files .breadcrumb');
  trail.innerHTML = '';
  const rootName = 'Thiết bị này';
  const isRootOnly = localNav.length <= 1;
  updateBackBtn(!isRootOnly);

  const root = document.createElement('span');
  root.className = isRootOnly ? 'now' : 'root';
  root.textContent = rootName;
  if (!isRootOnly) root.addEventListener('click', () => { localNav = localNav.slice(0, 1); loadLocalFiles(); });
  trail.appendChild(root);

  localNav.slice(1).forEach((seg, i) => {
    const sep = document.createElement('span'); sep.textContent = '›'; trail.appendChild(sep);
    const s = document.createElement('span');
    const isLast = i === localNav.length - 2;
    s.className = isLast ? 'now' : 'root';
    s.textContent = seg.name;
    if (!isLast) { const p = seg.path; s.addEventListener('click', () => { localNav = localNav.slice(0, i + 2); loadLocalFiles(); }); }
    trail.appendChild(s);
  });
}

function goDir(path) {
  rememberOverviewFolder(path || '', pool);
  loadFiles(path || '');
}

function renderCrumb() {
  const trail = document.getElementById('bcTrail') || $('#files .breadcrumb');
  trail.innerHTML = '';
  const parts = currentPath ? currentPath.split('/') : [];
  // Trên iOS luôn cho phép quay từ ổ Host về "Thiết bị này".
  updateBackBtn(true);

  const root = document.createElement('span');
  root.className = parts.length ? 'root' : 'now';
  root.textContent = server ? server.name : 'CW Datacenter';
  if (parts.length) root.addEventListener('click', () => goDir(''));
  trail.appendChild(root);

  let acc = '';
  parts.forEach((seg, i) => {
    acc += (i ? '/' : '') + seg;
    const sep = document.createElement('span'); sep.textContent = '›'; trail.appendChild(sep);
    const s = document.createElement('span');
    const isLast = i === parts.length - 1;
    s.className = isLast ? 'now' : 'root';
    s.textContent = seg;
    if (!isLast) { const p = acc; s.addEventListener('click', () => goDir(p)); }
    trail.appendChild(s);
  });
}

function transferFor(rel) {
  for (const k in transfers) {
    const t = transfers[k];
    if (t.rel === rel && (t.status === 'active' || t.status === 'paused')) return t;
  }
  return null;
}

function statusCell(e) {
  if (e._local) return '<span style="color:#b6bec9">—</span>';
  const rel = relOf(e);
  const t = transferFor(rel);
  if (t && t.total > 0) {
    const pc = Math.floor(t.done * 100 / t.total);
    return '<span class="status progress">◔ ' + pc + '%</span>';
  }
  if (e.type === 'file' && (syncDb[rel] || dlPaths[rel])) {
    return '<span style="color:var(--green);display:inline-flex;vertical-align:middle">' + iconSvg('i-check-circle', 'svg-18') + '</span> Đã đồng bộ';
  }
  return '<span style="color:#b6bec9">—</span>';
}

function displayEntries() {
  let shown = entries.slice();
  if (searchQuery) {
    const q = searchQuery.toLowerCase();
    shown = shown.filter((e) => e.name.toLowerCase().includes(q));
  }
  shown.sort((a, b) => {
    // Luôn ưu tiên thư mục hiển thị trước tệp tin
    if (a.type === 'dir' && b.type !== 'dir') return -1;
    if (a.type !== 'dir' && b.type === 'dir') return 1;

    switch (sortMode) {
      case 'media_img': {
        const isA = STREAM_IMG.test(a.name) ? 1 : (STREAM_VIDEO.test(a.name) ? 2 : 3);
        const isB = STREAM_IMG.test(b.name) ? 1 : (STREAM_VIDEO.test(b.name) ? 2 : 3);
        if (isA !== isB) return isA - isB;
        const ta = a.mtime ? new Date(a.mtime).getTime() : 0;
        const tb = b.mtime ? new Date(b.mtime).getTime() : 0;
        return tb - ta;
      }
      case 'media_vid': {
        const isA = STREAM_VIDEO.test(a.name) ? 1 : (STREAM_IMG.test(a.name) ? 2 : 3);
        const isB = STREAM_VIDEO.test(b.name) ? 1 : (STREAM_IMG.test(b.name) ? 2 : 3);
        if (isA !== isB) return isA - isB;
        const ta = a.mtime ? new Date(a.mtime).getTime() : 0;
        const tb = b.mtime ? new Date(b.mtime).getTime() : 0;
        return tb - ta;
      }
      case 'name_desc':
        return b.name.localeCompare(a.name, 'vi', { numeric: true, sensitivity: 'base' });
      case 'name_asc':
      case 'name':
        return a.name.localeCompare(b.name, 'vi', { numeric: true, sensitivity: 'base' });
      case 'size_asc':
        return (a.size || 0) - (b.size || 0);
      case 'size_desc':
      case 'size':
        return (b.size || 0) - (a.size || 0);
      case 'time_asc': {
        const ta = a.mtime ? new Date(a.mtime).getTime() : 0;
        const tb = b.mtime ? new Date(b.mtime).getTime() : 0;
        return ta - tb;
      }
      case 'time_desc':
      case 'time': {
        const ta = a.mtime ? new Date(a.mtime).getTime() : 0;
        const tb = b.mtime ? new Date(b.mtime).getTime() : 0;
        return tb - ta;
      }
      default:
        return a.name.localeCompare(b.name, 'vi', { numeric: true, sensitivity: 'base' });
    }
  });
  return shown;
}

function openSortSheet() {
  openSheet('Sắp xếp theo', (body) => {
    // 1. Tên (A-Z / Z-A)
    const isNameActive = sortMode === 'name_asc' || sortMode === 'name_desc' || sortMode === 'name';
    const isNameAsc = sortMode === 'name_asc' || sortMode === 'name';
    const nameSub = isNameActive 
      ? (isNameAsc ? 'Đang chọn: A → Z (Nhấn để đổi sang Z → A)' : 'Đang chọn: Z → A (Nhấn để đổi sang A → Z)')
      : 'Sắp xếp theo thứ tự bảng chữ cái';
    const nameBadge = isNameActive ? (isNameAsc ? 'A → Z' : 'Z → A') : '';
    
    sheetItem(body, 'Tên tệp (A-Z / Z-A)', {
      icon: 'i-sort',
      sub: nameSub,
      badge: nameBadge,
      badgeClass: 'blue',
      active: isNameActive,
      onClick: () => {
        if (sortMode === 'name_asc' || sortMode === 'name') {
          sortMode = 'name_desc';
          DC.toast('Sắp xếp: Tên (Z → A)');
        } else {
          sortMode = 'name_asc';
          DC.toast('Sắp xếp: Tên (A → Z)');
        }
        renderFiles();
      }
    });

    // 2. Dung lượng (Nhỏ -> Lớn / Lớn -> Nhỏ)
    const isSizeActive = sortMode === 'size_asc' || sortMode === 'size_desc';
    const isSizeAsc = sortMode === 'size_asc';
    const sizeSub = isSizeActive
      ? (isSizeAsc ? 'Đang chọn: Nhỏ → Lớn (Nhấn để đổi sang Lớn → Nhỏ)' : 'Đang chọn: Lớn → Nhỏ (Nhấn để đổi sang Nhỏ → Lớn)')
      : 'Sắp xếp theo kích thước dung lượng';
    const sizeBadge = isSizeActive ? (isSizeAsc ? 'Nhỏ → Lớn' : 'Lớn → Nhỏ') : '';

    sheetItem(body, 'Dung lượng (Nhỏ ↔ Lớn)', {
      icon: 'i-cube',
      sub: sizeSub,
      badge: sizeBadge,
      badgeClass: 'blue',
      active: isSizeActive,
      onClick: () => {
        if (sortMode === 'size_asc') {
          sortMode = 'size_desc';
          DC.toast('Sắp xếp: Dung lượng (Lớn → Nhỏ)');
        } else {
          sortMode = 'size_asc';
          DC.toast('Sắp xếp: Dung lượng (Nhỏ → Lớn)');
        }
        renderFiles();
      }
    });

    // 3. Ngày tháng (Gần nhất -> Xa nhất / Xa nhất -> Gần nhất)
    const isTimeActive = sortMode === 'time_desc' || sortMode === 'time_asc' || sortMode === 'time';
    const isTimeDesc = sortMode === 'time_desc' || sortMode === 'time';
    const timeSub = isTimeActive
      ? (isTimeDesc ? 'Đang chọn: Gần nhất → Xa nhất (Nhấn để đổi sang Xa nhất → Gần nhất)' : 'Đang chọn: Xa nhất → Gần nhất (Nhấn để đổi sang Gần nhất → Xa nhất)')
      : 'Sắp xếp theo ngày tạo / chỉnh sửa';
    const timeBadge = isTimeActive ? (isTimeDesc ? 'Gần nhất' : 'Xa nhất') : '';

    sheetItem(body, 'Ngày tháng (Mới ↔ Cũ)', {
      icon: 'i-sync',
      sub: timeSub,
      badge: timeBadge,
      badgeClass: 'blue',
      active: isTimeActive,
      onClick: () => {
        if (sortMode === 'time_desc' || sortMode === 'time') {
          sortMode = 'time_asc';
          DC.toast('Sắp xếp: Ngày tạo (Xa nhất → Gần nhất)');
        } else {
          sortMode = 'time_desc';
          DC.toast('Sắp xếp: Ngày tạo (Gần nhất → Xa nhất)');
        }
        renderFiles();
      }
    });

    // 4. Ảnh / Video (Ưu tiên Ảnh ↔ Ưu tiên Video)
    const isMediaActive = sortMode === 'media_img' || sortMode === 'media_vid';
    const isMediaImg = sortMode === 'media_img';
    const mediaSub = isMediaActive
      ? (isMediaImg ? 'Đang chọn: Ưu tiên Ảnh (Nhấn để đổi sang Ưu tiên Video)' : 'Đang chọn: Ưu tiên Video (Nhấn để đổi sang Ưu tiên Ảnh)')
      : 'Sắp xếp phân loại ưu tiên Ảnh hoặc Video lên đầu';
    const mediaBadge = isMediaActive ? (isMediaImg ? 'Ưu tiên Ảnh' : 'Ưu tiên Video') : '';

    sheetItem(body, 'Ảnh / Video (Ảnh ↔ Video)', {
      icon: 'i-video',
      sub: mediaSub,
      badge: mediaBadge,
      badgeClass: 'blue',
      active: isMediaActive,
      onClick: () => {
        if (sortMode === 'media_img') {
          sortMode = 'media_vid';
          DC.toast('Sắp xếp: Ưu tiên Video');
        } else {
          sortMode = 'media_img';
          DC.toast('Sắp xếp: Ưu tiên Ảnh');
        }
        renderFiles();
      }
    });
  });
}

let thumbObserver = null;
function getThumbObserver() {
  if (!thumbObserver && typeof IntersectionObserver !== 'undefined') {
    thumbObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const target = entry.target;
          thumbObserver.unobserve(target);
          if (target.dataset.thumbSrc) {
            target.src = target.dataset.thumbSrc;
            delete target.dataset.thumbSrc;
          }
        }
      });
    }, { rootMargin: '250px 0px' });
  }
  return thumbObserver;
}

function isThumbable(name) { return /\.(png|jpe?g|gif|webp|bmp|avif|heic|heif|mp4|webm|mkv|mov|m4v|avi|3gp|3gpp|flv|wmv|mpg|mpeg|ts|m2ts|mts|vob|ogv|rm|rmvb)$/i.test(name); }

function thumbRevision(e) {
  const modified = e && (e.mtime || e.modified || e.modifiedAt || e.updatedAt || e.date || '0');
  return encodeURIComponent(String((e && e.size) || 0) + '-' + String(modified));
}

function versionedThumbUrl(url, e) {
  if (!url) return '';
  return url + (url.includes('?') ? '&' : '?') + 'rev=' + thumbRevision(e) + '&image_validation=2';
}

function thumbnailRetryUrl(url, attempt) {
  return url + (url.includes('?') ? '&' : '?') + 'cw_retry=' + attempt + '_' + Date.now();
}

function retryThumbnailElement(img) {
  if (!img) return false;
  const original = img.dataset.thumbOriginal || img.getAttribute('src') || '';
  if (!original) return false;
  img.dataset.thumbOriginal = original;
  const attempt = Number(img.dataset.thumbRetry || 0);
  if (attempt >= 2) return false;
  const nextAttempt = attempt + 1;
  img.dataset.thumbRetry = String(nextAttempt);
  setTimeout(() => {
    if (!img.isConnected) return;
    img.style.display = '';
    img.src = thumbnailRetryUrl(original, nextAttempt);
  }, nextAttempt === 1 ? 180 : 650);
  return true;
}

window.CWRetryThumbnail = function (img) {
  if (!retryThumbnailElement(img) && img) img.style.display = 'none';
  return false;
};

function loadReliableThumbnail(img, url, finalFallback) {
  if (!img || !url) {
    if (typeof finalFallback === 'function') finalFallback();
    return;
  }
  img.dataset.thumbOriginal = url;
  img.dataset.thumbRetry = '0';
  img.onload = () => { img.style.display = ''; };
  img.onerror = () => {
    if (retryThumbnailElement(img)) return;
    img.onerror = null;
    if (typeof finalFallback === 'function') finalFallback();
    else img.style.display = 'none';
  };
  const observer = getThumbObserver();
  if (observer) {
    img.dataset.thumbSrc = url;
    observer.observe(img);
  } else {
    img.src = url;
  }
}

function makeRowIcon(e) {
  const isDir = e.type === 'dir';
  const thumbBase = e._local ? localDocUrl(e) : '';
  const isThumbOK = e._local ? !!thumbBase : true;
  if (!isDir && isThumbable(e.name) && isThumbOK) {
    const rel = relOf(e);
    const wrap = document.createElement('div');
    wrap.style.cssText = 'width:40px;height:40px;display:flex;align-items:center;justify-content:center;overflow:hidden;border-radius:9px;contain:strict;flex-shrink:0';
    const fallback = () => {
      const icon = fileIcon(e.name);
      wrap.innerHTML = '<div style="color:' + icon.color + '">' + iconSvg(icon.sym) + '</div>';
    };
    if (!STREAM_IMG.test(e.name) && STREAM_VIDEO.test(e.name)) {
      if (e._local) { fallback(); return wrap; }
      const img = document.createElement('img');
      img.className = 'file-thumb';
      img.loading = 'lazy';
      img.decoding = 'async';
      let targetSrc = '';
      try { targetSrc = DC.thumbUrl ? DC.thumbUrl(enc(rel), pool ? enc(pool) : '', 160) : ''; } catch (err) {}
      if (!targetSrc && server) {
        targetSrc = server.baseUrl + '/api/thumb?path=' + enc(rel) + (pool ? '&pool=' + enc(pool) : '') + '&size=160';
      }
      targetSrc = versionedThumbUrl(targetSrc, e);
      if (!targetSrc) {
        fallback();
      } else {
        loadReliableThumbnail(img, targetSrc, fallback);
        wrap.appendChild(img);
      }
      return wrap;
    }
    if (e._local) {
      const img = document.createElement('img');
      img.className = 'file-thumb';
      img.loading = 'lazy';
      img.decoding = 'async';
      loadReliableThumbnail(img, thumbBase + (thumbBase.includes('?') ? '&thumb=1&size=160' : '?thumb=1&size=160'), fallback);
      wrap.appendChild(img);
      return wrap;
    }

    const img = document.createElement('img');
    img.className = 'file-thumb';
    img.loading = 'lazy';
    img.decoding = 'async';
    let targetSrc = '';
    try { targetSrc = DC.thumbUrl ? DC.thumbUrl(enc(rel), pool ? enc(pool) : '', 160) : ''; } catch (err) {}
    if (!targetSrc && server) {
      targetSrc = server.baseUrl + '/api/thumb?path=' + enc(rel) + (pool ? '&pool=' + enc(pool) : '') + '&size=160';
    }
    targetSrc = versionedThumbUrl(targetSrc, e);
    if (!targetSrc) {
      fallback();
    } else {
      loadReliableThumbnail(img, targetSrc, fallback);
      wrap.appendChild(img);
    }
    return wrap;
  }
  const icon = isDir ? { sym: 'i-folder', color: 'var(--yellow)' } : fileIcon(e.name);
  const d = document.createElement('div');
  d.style.cssText = 'color:' + icon.color + ';display:flex;align-items:center;justify-content:center;width:40px;height:40px;flex-shrink:0';
  d.innerHTML = iconSvg(icon.sym, 'svg-24');
  return d;
}

function updateSelBar() {
  /* Thanh chọn đen đã bỏ — hành động nằm trong bảng (sheet) mở sau khi nhấn giữ. */
}

function selectedEntries() {
  return displayEntries().filter((e) => selectedSet.has(e.name));
}

let currentRenderedCount = 0;
const RENDER_CHUNK = 12;
let fileListObserver = null;

function updateMediaGridGeometry(list) {
  if (!list || currentFileLayout !== 'gallery') {
    if (list) list.style.removeProperty('--media-tile-size');
    return;
  }
  const columns = window.matchMedia('(orientation:landscape) and (min-width:600px)').matches ? 6 : 3;
  const gap = 4, horizontalPadding = 8;
  const usableWidth = Math.max(0, list.clientWidth - horizontalPadding - gap * (columns - 1));
  const tileSize = Math.max(72, Math.floor(usableWidth / columns));
  list.style.setProperty('--media-tile-size', tileSize + 'px');
}

let mediaGridResizeTimer = 0;
window.addEventListener('resize', () => {
  clearTimeout(mediaGridResizeTimer);
  mediaGridResizeTimer = setTimeout(() => updateMediaGridGeometry(document.querySelector('#files .file-list')), 80);
});

function renderFileRow(e) {
  const isDir = e.type === 'dir';
  const meta = isDir ? fmtDate(e.mtime) : ((e.size ? fmtBytes(e.size) : '') + (e.size ? ' · ' : '') + fmtDate(e.mtime));
  const locked = e._local ? false : entryLocked(e);
  const row = document.createElement('div');
  row.className = 'file-row' + (selMode && selectedSet.has(e.name) ? ' checked' : '');
  row.dataset.name = e.name;
  row.innerHTML =
    '<div class="row-ico"><div class="row-check">✓</div></div>' +
    '<div><div class="file-name">' + esc(e.name) + (locked ? '<span class="lock-ico">' + iconSvg('i-lock', 'svg-18') + '</span>' : '') + '</div><div class="meta">' + esc(meta) + '</div></div>' +
    '<div class="status">' + statusCell(e) + '</div>' +
    '<div style="color:#98a2b3;font-size:18px" class="more">⋮</div>';
  row.querySelector('.row-ico').prepend(makeRowIcon(e));
  row.addEventListener('click', () => onRowClick(e, row));
  const more = row.querySelector('.more');
  more.addEventListener('click', (ev) => { ev.stopPropagation(); openFileSheet(e); });
  return row;
}

function mediaDurationLabel(e) {
  const raw = Number(e.duration || e.durationSeconds || 0);
  if (!raw) return '';
  const total = Math.max(0, Math.round(raw));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return h ? (h + ':' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0')) : (m + ':' + String(s).padStart(2, '0'));
}

const mediaDurationCache = new Map();
window.CWReleaseMediaCaches = function () {
  mediaDurationCache.clear();
  if (mediaDurationObserver) mediaDurationObserver.disconnect();
  const viewportHeight = Math.max(window.innerHeight || 0, document.documentElement.clientHeight || 0);
  document.querySelectorAll('.media-tile img').forEach((img) => {
    const rect = img.getBoundingClientRect();
    if (!img.src || (rect.bottom >= -viewportHeight && rect.top <= viewportHeight * 2)) return;
    img.dataset.thumbSrc = img.src;
    img.removeAttribute('src');
    const observer = getThumbObserver();
    if (observer) observer.observe(img);
  });
};
let mediaDurationObserver = null;
function getMediaDurationObserver() {
  if (!mediaDurationObserver && typeof IntersectionObserver !== 'undefined') {
    mediaDurationObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        mediaDurationObserver.unobserve(entry.target);
        loadMediaDuration(entry.target);
      });
    }, { rootMargin: '180px 0px' });
  }
  return mediaDurationObserver;
}
async function loadMediaDuration(badge) {
  const rel = badge.dataset.rel || '', targetPool = badge.dataset.pool || '', localUrl = badge.dataset.localUrl || '';
  if (!rel || (!server && !localUrl)) { badge.remove(); return; }
  const key = localUrl ? 'local|' + rel : targetPool + '|' + rel;
  if (mediaDurationCache.has(key)) {
    const label = mediaDurationLabel({ duration: mediaDurationCache.get(key) });
    if (label) { badge.textContent = label; badge.classList.remove('loading'); } else badge.remove();
    return;
  }
  try {
    let seconds = 0;
    if (localUrl) {
      seconds = await new Promise((resolve) => {
        const video = document.createElement('video'); let settled = false;
        const done = (value) => { if (settled) return; settled = true; video.removeAttribute('src'); try { video.load(); } catch (e) {} resolve(value); };
        video.preload = 'metadata'; video.muted = true; video.onloadedmetadata = () => done(Number(video.duration || 0)); video.onerror = () => done(0);
        video.src = localUrl; setTimeout(() => done(0), 8000);
      });
    } else {
      const data = await api('/api/media-info?path=' + enc(rel) + (targetPool ? '&pool=' + enc(targetPool) : ''));
      seconds = Number(data && data.duration || 0);
    }
    mediaDurationCache.set(key, seconds);
    if (!badge.isConnected) return;
    const label = mediaDurationLabel({ duration: seconds });
    if (label) { badge.textContent = label; badge.classList.remove('loading'); } else badge.remove();
  } catch (err) { if (badge.isConnected) badge.remove(); }
}
function appendMediaDuration(visual, e, rel, isVideo) {
  if (!isVideo) return;
  const known = mediaDurationLabel(e);
  const badge = document.createElement('span'); badge.className = 'media-duration';
  if (known) badge.textContent = known;
  else {
    const localUrl = e._local ? localDocUrl(e) : '';
    if (e._local && !localUrl) return;
    badge.textContent = '…'; badge.classList.add('loading'); badge.dataset.rel = rel; badge.dataset.pool = ePool(e) || ''; if (localUrl) badge.dataset.localUrl = localUrl;
    const obs = getMediaDurationObserver(); if (obs) obs.observe(badge); else loadMediaDuration(badge);
  }
  visual.appendChild(badge);
}

function thumbSourceFor(e) {
  if (e._local) {
    const u = localDocUrl(e);
    return u ? u + (u.includes('?') ? '&thumb=1&size=160' : '?thumb=1&size=160') : '';
  }
  const rel = relOf(e);
  let u = '';
  try { u = DC.thumbUrl ? DC.thumbUrl(enc(rel), pool ? enc(pool) : '', 160) : ''; } catch (err) {}
  if (!u && server) u = server.baseUrl + '/api/thumb?path=' + enc(rel) + (pool ? '&pool=' + enc(pool) : '') + '&size=160';
  return versionedThumbUrl(u, e);
}

function effectiveFileLayout(shown) {
  if (fileViewMode === 'list') return 'list';
  if (fileViewMode === 'gallery') return 'gallery';
  const files = shown.filter((e) => e.type !== 'dir');
  const media = files.filter((e) => STREAM_IMG.test(e.name) || STREAM_VIDEO.test(e.name));
  return files.length >= 5 && media.length / files.length >= 0.65 ? 'gallery' : 'list';
}

function renderMediaTile(e) {
  const isDir = e.type === 'dir';
  const isVideo = !isDir && STREAM_VIDEO.test(e.name);
  const rel = relOf(e);
  const tile = document.createElement('div');
  tile.className = 'media-tile' + (isDir ? ' folder-tile' : '') + (selMode && selectedSet.has(e.name) ? ' checked' : '');
  tile.dataset.name = e.name;
  const visual = document.createElement('div');
  visual.className = 'media-tile-visual';
  if (isDir) {
    visual.innerHTML = iconSvg('i-folder', 'svg-38');
  } else {
    const src = thumbSourceFor(e);
    const img = document.createElement('img');
    img.alt = e.name;
    img.loading = 'lazy';
    img.decoding = 'async';
    if (src) {
      loadReliableThumbnail(img, src, () => { img.remove(); visual.classList.add('thumb-failed'); const fallback = document.createElement('div'); fallback.className = 'thumb-fallback'; fallback.innerHTML = iconSvg(isVideo ? 'i-video' : 'i-image', 'svg-38'); visual.prepend(fallback); });
      visual.appendChild(img);
    } else {
      visual.classList.add('thumb-failed');
      visual.innerHTML = iconSvg(isVideo ? 'i-video' : 'i-image', 'svg-38');
    }
    appendMediaDuration(visual, e, rel, isVideo);
    if (favs.some((f) => f.rel === rel)) {
      const heart = document.createElement('span');
      heart.className = 'media-favorite';
      heart.innerHTML = iconSvg('i-heart', 'svg-18');
      visual.appendChild(heart);
    }
  }
  const check = document.createElement('span');
  check.className = 'media-check';
  check.textContent = '✓';
  visual.appendChild(check);
  tile.appendChild(visual);
  const caption = document.createElement('div');
  caption.className = 'media-tile-caption';
  caption.textContent = e.name;
  tile.appendChild(caption);
  tile.addEventListener('click', () => onRowClick(e, tile));
  return tile;
}

function renderFileEntry(e) {
  return currentFileLayout === 'gallery' ? renderMediaTile(e) : renderFileRow(e);
}

function appendNextFileChunk(list, shown) {
  if (currentRenderedCount >= shown.length) return;
  const frag = document.createDocumentFragment();
  const nextSlice = shown.slice(currentRenderedCount, currentRenderedCount + RENDER_CHUNK);
  nextSlice.forEach((e) => {
    frag.appendChild(renderFileEntry(e));
  });
  currentRenderedCount += nextSlice.length;

  const sentinel = list.querySelector('#fileListSentinel');
  if (sentinel) {
    list.insertBefore(frag, sentinel);
    if (currentRenderedCount >= shown.length) {
      sentinel.remove();
    }
  } else {
    list.appendChild(frag);
  }
}

function renderFiles() {
  const list = $('#files .file-list');
  list.innerHTML = '';
  currentRenderedCount = 0;
  if (fileListObserver) {
    fileListObserver.disconnect();
    fileListObserver = null;
  }
  let shown = displayEntries();
  currentFileLayout = effectiveFileLayout(shown);
  list.classList.toggle('media-grid', currentFileLayout === 'gallery');
  updateMediaGridGeometry(list);
  if (!shown.length) {
    const d = document.createElement('div');
    d.className = 'empty';
    d.textContent = searchQuery ? 'Không có kết quả cho "' + searchQuery + '"'
      : isLocalMode() ? 'Thư mục trống.'
      : 'Thư mục trống. Bấm nút xanh để tải tệp lên.';
    list.appendChild(d);
    return;
  }

  const initialCount = Math.min(shown.length, RENDER_CHUNK);
  const frag = document.createDocumentFragment();
  for (let i = 0; i < initialCount; i++) {
    frag.appendChild(renderFileEntry(shown[i]));
  }
  currentRenderedCount = initialCount;

  if (shown.length > initialCount) {
    const sentinel = document.createElement('div');
    sentinel.id = 'fileListSentinel';
    sentinel.style.cssText = 'height:60px;display:flex;align-items:center;justify-content:center;color:#98a2b3;font-size:12px';
    sentinel.textContent = 'Đang tải thêm…';
    frag.appendChild(sentinel);
    list.appendChild(frag);

    fileListObserver = new IntersectionObserver((entries) => {
      if (entries[0] && entries[0].isIntersecting) {
        appendNextFileChunk(list, shown);
      }
    }, {
      root: list,
      rootMargin: '400px'
    });
    fileListObserver.observe(sentinel);
  } else {
    list.appendChild(frag);
  }
}

function onRowClick(e, row) {
  if (lpSuppressClick) return;
  if (selMode) { toggleSelect(e.name); return; }
  if (e._local) { onLocalRowClick(e); return; }
  if (e.type === 'dir') { requireUnlocked(e, () => goDir(relOf(e))); return; }
  if (isPreviewable(e.name)) { requireUnlocked(e, () => openPreview(e)); return; }
  requireUnlocked(e, () => openFileSheet(e));
}

function onLocalRowClick(e) {
  if (e.type === 'dir') { goLocalDir(e._p); return; }
  if (isPreviewable(e.name)) { openPreview(e); return; }
  localOpenWith(e);
}

function localOpenWith(e) {
  callNative('localFsOpen', JSON.stringify(localSpec(e)))
    .catch(() => DC.toast('File không hỗ trợ'));
}

function openDownloadedFile(path, name) {
  return callNative('openFile', JSON.stringify({ path, name: name || '' }))
    .catch(() => DC.toast('File không hỗ trợ'));
}

function openSelectedEntry(e) {
  closeSheet();
  if (!e) return;
  if (e.type === 'dir') {
    if (e._local) goLocalDir(e._p);
    else requireUnlocked(e, () => goDir(relOf(e)));
    return;
  }
  if (e._local) localOpenWith(e);
  else requireUnlocked(e, () => openOrFetch(e));
}

function shouldOfferOpenAction(e) {
  if (!e || e.type === 'dir') return true;
  return !(STREAM_IMG.test(e.name) || STREAM_VIDEO.test(e.name) || STREAM_PDF.test(e.name));
}

function bindInfoCopyHold(element, label, value) {
  if (!element) return;
  const text = String(value || '—');
  let timer = 0;
  let startX = 0;
  let startY = 0;
  const cancel = () => { clearTimeout(timer); timer = 0; element.classList.remove('copy-holding'); };
  element.classList.add('info-copyable');
  element.addEventListener('pointerdown', (event) => {
    cancel(); startX = event.clientX || 0; startY = event.clientY || 0;
    element.classList.add('copy-holding');
    timer = window.setTimeout(async () => {
      timer = 0; element.classList.remove('copy-holding');
      await copyToClipboard(text);
      if (navigator.vibrate) { try { navigator.vibrate(28); } catch (e) {} }
      DC.toast('Đã sao chép ' + label);
    }, 1000);
  });
  element.addEventListener('pointermove', (event) => {
    if (timer && (Math.abs((event.clientX || 0) - startX) > 8 || Math.abs((event.clientY || 0) - startY) > 8)) cancel();
  });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach((name) => element.addEventListener(name, cancel));
  element.addEventListener('contextmenu', (event) => event.preventDefault());
}

function renderItemInfoSheet(title, rows) {
  openSheet(title || 'Thông tin', (body) => {
    const grid = document.createElement('div');
    grid.className = 'item-info-grid';
    rows.forEach((row) => {
      const b = document.createElement('b');
      b.textContent = row[0];
      const span = document.createElement('span');
      span.textContent = row[1] || '—';
      bindInfoCopyHold(b, row[0], row[1]);
      bindInfoCopyHold(span, row[0], row[1]);
      grid.append(b, span);
    });
    body.appendChild(grid);
  });
}

async function openItemInfoSheet(e) {
  openSheet('Thông tin', (body) => { body.innerHTML = '<div class="empty">Đang tính dung lượng và đọc thông tin…</div>'; });
  try {
    let d;
    if (e && e._local) {
      let size = Number(e.size) || 0;
      let fileCount = e.type === 'file' ? 1 : 0;
      let folderCount = 0;
      let truncated = false;
      if (e.type === 'dir') {
        const deep = await callNative('localFsDeepList', JSON.stringify({ path: e._p, limit: 20000 }));
        const list = (deep && deep.files) || [];
        size = list.reduce((sum, it) => sum + (Number(it.size) || 0), 0);
        fileCount = list.length;
        const dirs = new Set();
        list.forEach((it) => {
          const parts = String(it.rel || '').replace(/\\/g, '/').split('/');
          parts.pop();
          let cur = '';
          parts.forEach((part) => { if (part) { cur = cur ? cur + '/' + part : part; dirs.add(cur); } });
        });
        folderCount = dirs.size;
        truncated = !!(deep && deep.truncated);
      }
      d = { name: e.name, type: e.type, path: e._p, poolName: 'Thiết bị này', size, fileCount, folderCount, modified: e.mtime, truncated };
    } else {
      d = await api('/api/item/info?path=' + enc(relOf(e)) + '&pool=' + enc(ePool(e)));
    }

    const isDir = d.type === 'dir';
    const ext = isDir ? '' : ((d.extension || String(d.name || '').split('.').pop() || '').replace(/^\./, '').toUpperCase());

    if (e) {
      if (!d.width && e.width) d.width = e.width;
      if (!d.height && e.height) d.height = e.height;
      if (!d.captureDate && e.captureDate) d.captureDate = e.captureDate;
      if (d.latitude == null && e.latitude != null) d.latitude = e.latitude;
      if (d.longitude == null && e.longitude != null) d.longitude = e.longitude;
    }

    const media = d.media || d.metadata || {};
    let width = Number(d.width || media.width || 0);
    let height = Number(d.height || media.height || 0);
    let captureDate = d.captureDate || media.captureDate || media.dateTaken;
    let latitude = d.latitude ?? media.latitude;
    let longitude = d.longitude ?? media.longitude;

    if (!isDir) {
      const isMedia = /\.(?:jpe?g|png|webp|gif|bmp|avif|heic|heif|mp4|m4v|mov|mkv|webm|avi|wmv|ts|m2ts)$/i.test(d.name || '');
      if (isMedia && (width <= 0 || height <= 0 || !captureDate || latitude == null || longitude == null)) {
        try {
          const directUrl = (typeof fileApiUrl === 'function' && e) ? fileApiUrl(relOf(e), '', ePool(e)) : '';
          const nativeRes = await callNative('probeMedia', JSON.stringify({
            url: directUrl,
            name: d.name || (e && e.name) || '',
            token: typeof token !== 'undefined' ? token : '',
            localPath: (e && e._local) ? e._p : ''
          }));
          if (nativeRes && nativeRes.ok) {
            if (width <= 0 && Number(nativeRes.width) > 0) width = Number(nativeRes.width);
            if (height <= 0 && Number(nativeRes.height) > 0) height = Number(nativeRes.height);
            if (!captureDate && nativeRes.captureDate) captureDate = nativeRes.captureDate;
            if (latitude == null && nativeRes.latitude != null) latitude = nativeRes.latitude;
            if (longitude == null && nativeRes.longitude != null) longitude = nativeRes.longitude;
          }
        } catch (ignored) {}

        if ((width <= 0 || height <= 0) && /\.(?:jpe?g|png|webp|gif|bmp|avif)$/i.test(d.name || '') && typeof fileApiUrl === 'function' && e) {
          try {
            await new Promise((resolve) => {
              const img = new Image();
              img.onload = () => {
                if (img.naturalWidth > 0 && img.naturalHeight > 0) {
                  width = img.naturalWidth;
                  height = img.naturalHeight;
                }
                resolve();
              };
              img.onerror = () => resolve();
              img.src = fileApiUrl(relOf(e), '&preview=1', ePool(e));
            });
          } catch (ignored) {}
        }

        if (!captureDate && d.name) {
          const m = String(d.name).match(/(?:IMG|VID|PXL|PHOTO|PIC)?_?(\d{4})[-_]?(\d{2})[-_]?(\d{2})[-_\sT]?(\d{2})[-_.:]?(\d{2})[-_.:]?(\d{2})/i);
          if (m) {
            const yr = Number(m[1]), mo = Number(m[2]), dy = Number(m[3]), hr = Number(m[4]), mi = Number(m[5]), sc = Number(m[6]);
            if (yr >= 1990 && yr <= 2100 && mo >= 1 && mo <= 12 && dy >= 1 && dy <= 31 && hr < 24 && mi < 60 && sc < 60) {
              captureDate = `${m[1]}:${m[2]}:${m[3]} ${m[4]}:${m[5]}:${m[6]}`;
            }
          }
        }
      }
    }

    const rows = [];
    rows.push(['Tên', d.name]);
    if (!isDir && ext) {
      rows.push(['Định dạng', ext]);
    } else if (isDir) {
      rows.push(['Loại', 'Thư mục']);
    }

    rows.push(['Dung lượng', fmtBytes(Number(d.size) || 0)]);

    if (width > 0 && height > 0) {
      rows.push(['Kích thước', width + ' × ' + height + ' px']);
    }

    const isVideo = (typeof isVideoFile === 'function' && isVideoFile(d.name || '')) || /\.(?:mp4|m4v|mov|mkv|webm|avi|wmv|ts|m2ts|3gp)$/i.test(d.name || '');
    if (isVideo && (d.duration || media.duration)) {
      const dur = fmtDuration(d.duration || media.duration);
      if (dur) rows.push(['Thời lượng', dur]);
    }

    if (isDir) {
      rows.push(['Bên trong', (d.fileCount || 0) + ' tệp · ' + (d.folderCount || 0) + ' thư mục' + (d.truncated ? ' (đã đạt giới hạn quét)' : '')]);
    }

    if (captureDate) {
      rows.push(['Ngày chụp gốc', fmtDateTime(captureDate) || captureDate]);
    }

    rows.push(['Ngày chỉnh sửa', d.modified ? fmtDateTime(d.modified) : '—']);

    if (latitude != null && longitude != null && !isNaN(Number(latitude)) && !isNaN(Number(longitude))) {
      rows.push(['Địa điểm', Number(latitude).toFixed(6) + ', ' + Number(longitude).toFixed(6)]);
    }

    let filePath = '';
    if (d.poolName) filePath += d.poolName;
    if (d.path) {
      const segs = String(d.path).replace(/\\/g, '/').split('/').filter(Boolean);
      if (segs.length) filePath = (filePath ? filePath + ' > ' : '') + segs.join(' > ');
    } else if (e) {
      const rel = relOf(e);
      if (rel) filePath = (filePath ? filePath + ' > ' : '') + String(rel).replace(/\\/g, '/').split('/').filter(Boolean).join(' > ');
    }
    if (!filePath) filePath = d.name;
    rows.push(['Vị trí tệp', filePath]);

    renderItemInfoSheet('Thông tin', rows);
  } catch (er) {
    renderItemInfoSheet('Thông tin', [['Lỗi', errText(er)]]);
  }
}

function openFileSheet(e) {
  if (e && e._local) { localFileSheet(e); return; }
  const rel = relOf(e);
  const favIdx = favs.findIndex((f) => f.rel === rel);
  if (entryLocked(e)) {
    openSheet(e.name, (body) => {
      sheetItem(body, 'Mở khóa bằng mật khẩu', { icon: 'i-lock', onClick: () =>
        unlockSheet(e, () => (e.type === 'dir' ? goDir(rel) : openFileSheet(e))) });
    });
    return;
  }
  openSheet(e.name, (body) => {
    if (shouldOfferOpenAction(e)) sheetItem(body, 'Mở', { icon: 'i-open', onClick: () => openSelectedEntry(e) });
    if (isPreviewable(e.name)) sheetItem(body, 'Xem trực tiếp', { icon: 'i-monitor', onClick: () => openPreview(e) });
    if (e.type === 'file' && isVideoFile(e.name)) {
      sheetItem(body, 'Tải trước (Xem Offline)', { icon: 'i-download', onClick: () => { closeSheet(); preloadVideosOffline([e]); } });
    }
    sheetItem(body, 'Chia sẻ link', { icon: 'i-upload', onClick: () => { closeSheet(); openShareSheet(e); } });
    sheetItem(body, 'Tải xuống', { icon: 'i-upload', onClick: () => { closeSheet(); startDownload(e); } });
    if (canWrite()) {
      sheetItem(body, 'Copy', { icon: 'i-copy', onClick: () => clipCopy(e) });
      sheetItem(body, 'Cut', { icon: 'i-cut', onClick: () => clipCut(e) });
      if (clipboard.items.length) sheetItem(body, 'Dán vào đây (' + clipboard.items.length + ' mục)', { icon: 'i-paste', onClick: () => { closeSheet(); clipPaste(); } });
      sheetItem(body, 'Đổi tên', { icon: 'i-settings', onClick: () =>
        sheetPrompt('Đổi tên', 'Tên mới', e.name, async (name) => {
          try { await api('/api/rename', 'POST', { path: rel, newName: name, pool }); DC.toast('Đã đổi tên'); loadFiles(currentPath); }
          catch (er) { DC.toast(errText(er)); }
        }) });
    }
    sheetItem(body, favIdx >= 0 ? 'Bỏ yêu thích' : 'Thêm yêu thích', { icon: 'i-star', onClick: () => toggleFav(e) });
    if (ensureLockMap()[lockKeyFor(e)]) {
      sheetItem(body, 'Gỡ mật khẩu khóa', { danger: true, icon: 'i-trash', onClick: () => removeLock(e) });
    } else {
      sheetItem(body, 'Khóa bằng mật khẩu', { icon: 'i-lock', onClick: () => lockSheet(e) });
    }
    if (canWrite()) {
      sheetItem(body, 'Xóa (vào thùng rác)', { danger: true, icon: 'i-trash', onClick: () =>
        sheetConfirm('Xóa ' + (e.type === 'dir' ? 'thư mục' : 'tệp'), '"' + e.name + '" sẽ được chuyển vào Thùng rác.', 'Xóa', async () => {
          try { await cacheTrashThumbnail(e); await api('/api/file?path=' + enc(rel) + '&pool=' + enc(pool), 'DELETE'); DC.toast('Đã chuyển vào thùng rác'); loadFiles(currentPath); }
          catch (er) { DC.toast(errText(er)); }
        }) });
    }
    sheetItem(body, 'Thông tin', { icon: 'i-info', onClick: () => openItemInfoSheet(e) });
  });
}

async function copyToClipboard(text) {
  try {
    const res = await callNative('copyClipboard', text);
    if (res && res.ok) return true;
  } catch (e) {}
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    document.execCommand('copy');
    ta.remove();
    return true;
  } catch (e) {}
  return false;
}

async function openShareSheet(entry) {
  const items = Array.isArray(entry) ? entry : [entry];
  if (!items.length) return;
  openSheet(items.length > 1 ? 'Chia sẻ ' + items.length + ' mục' : 'Chia sẻ "' + items[0].name + '"', async (body) => {
    const hint = document.createElement('div');
    hint.style.cssText = 'font-size:12px;color:#98a2b3;margin:-8px 0 12px;line-height:1.5';
    hint.textContent = 'Người nhận có thể tải trực tiếp qua trình duyệt không cần mật khẩu.';
    body.appendChild(hint);

    const outWrap = document.createElement('div');
    outWrap.style.cssText = 'display:flex;flex-direction:column;gap:8px;margin-bottom:12px';
    outWrap.innerHTML = '<div style="font-size:13px;color:#667085;padding:8px 0">Đang tạo link…</div>';
    body.appendChild(outWrap);

    try {
      const links = [];
      for (const it of items) {
        const p = ePool(it);
        const rel = relOf(it);
        const r = await api('/api/share', 'POST', { path: rel, pool: p, ttlHours: 24 });
        const linkUrl = r.shareUrl || (server ? server.baseUrl + '/s/?id=' + encodeURIComponent(r.id) : '');
        links.push({ name: it.name, url: linkUrl });
      }

      outWrap.innerHTML = '';
      links.forEach((l) => {
        const row = document.createElement('div');
        row.style.cssText = 'display:flex;align-items:center;gap:8px;background:#f5f7fa;padding:8px 12px;border-radius:10px';
        row.innerHTML = '<input type="text" readonly style="flex:1;background:transparent;border:0;font-size:12px;color:#344054" value="' + esc(l.url) + '"><button class="btn" style="height:32px;padding:0 12px;font-size:12px;background:var(--blue);color:#fff;border:0;border-radius:8px">Copy</button>';
        const b = row.querySelector('button');
        b.addEventListener('click', async () => {
          await copyToClipboard(l.url);
          b.textContent = 'Đã copy ✓';
          setTimeout(() => { b.textContent = 'Copy'; }, 1500);
        });
        outWrap.appendChild(row);
      });

      if (links.length > 1) {
        const copyAllBtn = document.createElement('button');
        copyAllBtn.className = 'btn';
        copyAllBtn.style.cssText = 'width:100%;height:38px;margin-top:4px;font-size:13px;background:#111827;color:#fff;border-radius:10px;border:0';
        copyAllBtn.textContent = 'Copy tất cả ' + links.length + ' link';
        copyAllBtn.addEventListener('click', async () => {
          await copyToClipboard(links.map((l) => l.url).join('\n'));
          copyAllBtn.textContent = 'Đã copy tất cả ✓';
          setTimeout(() => { copyAllBtn.textContent = 'Copy tất cả ' + links.length + ' link'; }, 1500);
        });
        outWrap.appendChild(copyAllBtn);
      }
    } catch (e) {
      outWrap.innerHTML = '<div style="color:var(--red);font-size:13px">Lỗi tạo link: ' + esc(errText(e)) + '</div>';
    }
  });
}

function localFileSheet(e) {
  openSheet(e.name, (body) => {
    if (shouldOfferOpenAction(e)) sheetItem(body, 'Mở', { icon: 'i-open', onClick: () => openSelectedEntry(e) });
    if (isPreviewable(e.name)) sheetItem(body, 'Xem trực tiếp', { icon: 'i-monitor', onClick: () => openPreview(e) });
    sheetItem(body, 'Tải về (lưu bản sao)', { icon: 'i-download', onClick: () => { closeSheet(); localDownloadEntry(e); } });
    if (canWrite()) {
      sheetItem(body, 'Copy', { icon: 'i-copy', onClick: () => clipCopy(e) });
      sheetItem(body, 'Cut', { icon: 'i-cut', onClick: () => clipCut(e) });
      if (clipboard.items.length) sheetItem(body, 'Dán vào đây (' + clipboard.items.length + ' mục)', { icon: 'i-paste', onClick: () => { closeSheet(); clipPaste(); } });
    }
    sheetItem(body, 'Thêm yêu thích', { icon: 'i-star', onClick: () => toggleFav(e) });
    sheetItem(body, 'Xóa khỏi thiết bị', { danger: true, icon: 'i-trash', onClick: () => localDeleteEntries([e]) });
    sheetItem(body, 'Thông tin', { icon: 'i-info', onClick: () => openItemInfoSheet(e) });
  });
}

async function localDeleteEntries(entries) {
  const paths = entries.map((e) => e._p || e.path || e.rel).filter(Boolean);
  if (!paths.length) return;
  sheetConfirm('Xóa ' + paths.length + ' mục', 'Bạn có chắc chắn muốn xóa vĩnh viễn ' + paths.length + ' mục này khỏi thiết bị không?', 'Xóa vĩnh viễn', async () => {
    try {
      const res = await callNative('localFsDelete', JSON.stringify({ items: paths }));
      if (res && res.ok) {
        DC.toast('Đã xóa ' + (res.done || paths.length) + ' mục khỏi thiết bị');
      } else {
        DC.toast('Xóa thất bại');
      }
    } catch (e) {
      DC.toast('Lỗi xóa: ' + (e.message || e));
    }
    loadLocalFiles();
  });
}

function localDeleteSelected() {
  const entries = selectedEntries();
  if (!entries.length) return;
  localDeleteEntries(entries);
  exitSelMode();
}

async function newFolderHere() {
  if (isLocalMode()) {
    sheetPrompt('Thư mục mới', 'Tên thư mục', '', async (name) => {
      if (!name || !name.trim()) return;
      try {
        const curLocal = localNav.length ? localNav[localNav.length - 1].path : (localRootPath || '');
        const r = await callNative('localFsMkdir', JSON.stringify({ parent: curLocal, name: name.trim() }));
        if (r && r.ok) {
          DC.toast('Đã tạo thư mục');
          loadLocalFiles();
        } else {
          DC.toast('Tạo thư mục thất bại' + (r && r.err ? ': ' + r.err : ''));
        }
      } catch (er) { DC.toast(errText(er)); }
    });
    return;
  }
  if (isPoolLocked(pool)) { unlockSheet(poolTargetOf(pool), () => newFolderHere()); return; }
  sheetPrompt('Thư mục mới', 'Tên thư mục', '', async (name) => {
    if (!name || !name.trim()) return;
    try {
      await api('/api/mkdir', 'POST', { path: (currentPath ? currentPath + '/' : '') + name.trim(), pool });
      DC.toast('Đã tạo thư mục');
      loadFiles(currentPath);
    } catch (er) { DC.toast(errText(er)); }
  });
}

function toggleFav(e) {
  if (e && e._local) {
    const keyId = e._p || e._id;
    const lrel = 'local:' + keyId;
    const i = favs.findIndex((f) => f.rel === lrel);
    if (i >= 0) { favs.splice(i, 1); DC.toast('Đã bỏ yêu thích'); }
    else {
      favs.unshift({ rel: lrel, name: e.name, type: e.type, local: true, _p: e._p || '', _mime: e._mime || '', size: e.size || 0 });
      DC.toast('Đã thêm vào yêu thích');
    }
    kvSet(kFavs(), favs);
    renderFiles();
    return;
  }
  const rel = relOf(e);
  const i = favs.findIndex((f) => f.rel === rel);
  if (i >= 0) { favs.splice(i, 1); DC.toast('Đã bỏ yêu thích'); }
  else {
    favs.unshift({ rel, name: e.name, type: e.type, pool, size: e.size || 0 });
    DC.toast('Đã thêm vào yêu thích');
  }
  kvSet(kFavs(), favs);
  renderFiles();
}

window.CWPhotoFavoriteToggle = function(item) {
  try {
    if (!item) return false;
    favs = kvGet(kFavs()) || [];
    const rel = String(item.rel || '');
    const p = String(item.pool || pool || 'main');
    const idx = favs.findIndex((x) => String(x.rel || '') === rel && String(x.pool || 'main') === p);
    const enabled = idx < 0;
    if (idx >= 0) favs.splice(idx, 1);
    else favs.unshift({ rel, name: item.name || 'Hình ảnh', type: 'file', pool: p, size: Number(item.size || 0), mtime: item.mtime || '' });
    kvSet(kFavs(), favs);
    if (currentView === 'files') renderFiles();
    if (currentView === 'favorites') renderFavorites();
    if (currentView === 'overview') renderOverviewGallery();
    return enabled;
  } catch (e) {
    return false;
  }
};

window.CWVideoFavoriteToggle = function(item) {
  try {
    if (!item) return false;
    favs = kvGet(kFavs()) || [];
    const rel = String(item.rel || '');
    const p = String(item.pool || pool || 'main');
    if (!rel) return false;
    const idx = favs.findIndex((x) => String(x.rel || '') === rel && String(x.pool || 'main') === p);
    const enabled = idx < 0;
    if (idx >= 0) favs.splice(idx, 1);
    else favs.unshift({ rel, name: item.name || 'Video', type: 'file', pool: p, size: Number(item.size || 0), mtime: item.mtime || '' });
    kvSet(kFavs(), favs);
    if (currentView === 'files') renderFiles();
    if (currentView === 'favorites') renderFavorites();
    if (currentView === 'overview') renderOverviewGallery();
    return enabled;
  } catch (e) {
    return false;
  }
};

window.CWVideoDeleted = function(item) {
  try {
    if (!item) return;
    const rel = String(item.rel || '');
    const p = String(item.pool || 'main');
    favs = (kvGet(kFavs()) || []).filter((x) => String(x.rel || '') !== rel || String(x.pool || 'main') !== p);
    kvSet(kFavs(), favs);
    const videos = (kvGet(overviewVideoKey()) || []).filter((x) => String(x.rel || '') !== rel || String(x.pool || 'main') !== p);
    kvSet(overviewVideoKey(), videos);
    const files = (kvGet(overviewFileKey()) || []).filter((x) => String(x.rel || '') !== rel || String(x.pool || 'main') !== p);
    kvSet(overviewFileKey(), files);
    overviewGalleryItems = overviewGalleryItems.filter((x) => String(x.rel || '') !== rel || String(x.pool || 'main') !== p);
    saveOverviewGalleryCache();
    if (currentView === 'files') loadFiles(currentPath);
    if (currentView === 'favorites') renderFavorites();
    if (currentView === 'overview') renderOverviewGallery();
  } catch (e) {}
};

window.CWOverviewMediaDeleted = function(item) {
  try {
    if (!item) return;
    const rel = String(item.rel || '');
    const p = String(item.pool || 'main');
    overviewGalleryItems = overviewGalleryItems.filter((x) => String(x.rel || '') !== rel || String(x.pool || 'main') !== p);
    saveOverviewGalleryCache();
    if (currentView === 'overview') renderOverviewGallery();
  } catch (e) {}
};

/* ---------- COPY / CUT / PASTE (giống app PC) ---------- */
let selMode = false;
const selectedSet = new Set();

/* Nút nổi "Paste (N mục)": hiện sau khi copy/cut, bấm vào để dán tại thư mục hiện tại
 * (giống nút "Đã chọn N mục"), áp dụng cho cả ổ máy chủ lẫn ổ "Thiết bị này",
 * và cho phép dán chéo giữa 2 ổ. */
const pasteFab = document.createElement('button');
pasteFab.className = 'paste-fab';
document.querySelector('.app-shell').appendChild(pasteFab);
pasteFab.addEventListener('click', () => { if (clipboard.items.length) clipPaste(); });

const pasteProgBox = document.createElement('div');
pasteProgBox.className = 'paste-progress-box';
pasteProgBox.innerHTML = '<div class="pb-text"><span class="pb-title">Đang dán…</span><span class="pb-pct">0%</span></div><div class="pb-bar"><div class="pb-fill"></div></div>';
document.querySelector('.app-shell').appendChild(pasteProgBox);

let pasteInProgress = false;

function updatePasteFab() {
  if (pasteInProgress) return;
  const show = clipboard.items.length > 0 && currentView === 'files' && !sheetModal.classList.contains('show');
  pasteFab.style.display = show ? 'flex' : 'none';
  if (show) {
    const verb = clipboard.mode === 'cut' ? 'Cắt' : 'Copy';
    pasteFab.innerHTML = '<svg><use href="#i-paste"/></svg><span>Paste (' + verb + ' ' + clipboard.items.length + ' mục)</span>';
  }
}

function showPasteProgress(title, pct) {
  pasteInProgress = true;
  pasteFab.style.display = 'none';
  pasteProgBox.style.display = 'flex';
  pasteProgBox.querySelector('.pb-title').textContent = title;
  pasteProgBox.querySelector('.pb-pct').textContent = Math.round(pct) + '%';
  pasteProgBox.querySelector('.pb-fill').style.width = Math.max(0, Math.min(100, pct)) + '%';
}

function hidePasteProgress(successMsg, isError) {
  if (successMsg) {
    pasteProgBox.querySelector('.pb-title').textContent = successMsg;
    pasteProgBox.querySelector('.pb-pct').textContent = isError ? '✕' : '✓';
    pasteProgBox.querySelector('.pb-fill').style.width = '100%';
    pasteProgBox.querySelector('.pb-fill').style.background = isError ? 'var(--red)' : 'var(--green)';
    setTimeout(() => {
      pasteProgBox.style.display = 'none';
      pasteProgBox.querySelector('.pb-fill').style.background = 'var(--blue)';
      pasteInProgress = false;
      updatePasteFab();
    }, isError ? 1800 : 700);
  } else {
    pasteProgBox.style.display = 'none';
    pasteInProgress = false;
    updatePasteFab();
  }
}

function clipLabel() {
  if (!clipboard.items.length) return '';
  const n = clipboard.items.length;
  return (clipboard.mode === 'copy' ? 'Đã copy ' : 'Đã cut ') + n + ' mục';
}
function clipSetList(items, mode, label) {
  clipboard = { items, mode, dir: currentPath, local: isLocalMode() };
  DC.toast(label);
  updateSelBar();
  updatePasteFab();
}
function clipCopy(e) {
  if (e && e._local) {
    clipSetList([{ p: e._p, dir: isLocalMode() ? localDirPath() : '', local: true, name: e.name }], 'copy', 'Đã copy "' + e.name + '"');
    return;
  }
  clipSetList([{ path: relOf(e), pool, type: e.type }], 'copy', 'Đã copy "' + e.name + '"');
}
function clipCut(e) {
  if (e && e._local) {
    clipSetList([{ p: e._p, dir: isLocalMode() ? localDirPath() : '', local: true, name: e.name }], 'cut', 'Đã cắt "' + e.name + '"');
    return;
  }
  clipSetList([{ path: relOf(e), pool, type: e.type }], 'cut', 'Đã cắt "' + e.name + '"');
}
function clipCopyMulti() {
  if (!selectedSet.size) return;
  if (isLocalMode()) {
    const items = selectedEntries().map((e) => ({ p: e._p, dir: localDirPath(), local: true, name: e.name }));
    clipSetList(items, 'copy', 'Đã copy ' + items.length + ' mục');
    exitSelMode();
    return;
  }
  const items = selectedEntries().map((e) => ({ path: relOf(e), pool, type: e.type }));
  clipSetList(items, 'copy', 'Đã copy ' + items.length + ' mục');
  exitSelMode();
}
function clipCutMulti() {
  if (!selectedSet.size) return;
  if (isLocalMode()) {
    const items = selectedEntries().map((e) => ({ p: e._p, dir: localDirPath(), local: true, name: e.name }));
    clipSetList(items, 'cut', 'Đã cắt ' + items.length + ' mục');
    exitSelMode();
    return;
  }
  const items = selectedEntries().map((e) => ({ path: relOf(e), pool, type: e.type }));
  clipSetList(items, 'cut', 'Đã cắt ' + items.length + ' mục');
  exitSelMode();
}
function localDirPath() {
  return localNav.length ? localNav[localNav.length - 1].path : localRootPath;
}

function enterSelMode(name) {
  if (isPoolLocked(pool)) return;
  if (currentView !== 'files') return;
  selMode = true;
  selectedSet.clear();
  if (name) selectedSet.add(name);
  document.body.classList.add('selmode');
  $$('#files .file-row, #files .media-tile').forEach((r) => {
    r.classList.toggle('checked', selectedSet.has(r.dataset.name));
  });
  updateSelBar();
  updatePoolBarSelection();
  updateSelFab();
}
function exitSelMode(forceRender) {
  if (!selMode && !forceRender) return;
  selMode = false;
  selectedSet.clear();
  document.body.classList.remove('selmode');
  $$('#files .file-row, #files .media-tile').forEach((r) => r.classList.remove('checked'));
  updateSelBar();
  updatePoolBarSelection();
  updateSelFab();
}
function toggleSelect(name) {
  if (selectedSet.has(name)) selectedSet.delete(name);
  else selectedSet.add(name);
  if (!selectedSet.size) { exitSelMode(); return; }
  const r = $(`#files .file-row[data-name="${CSS.escape(name)}"], #files .media-tile[data-name="${CSS.escape(name)}"]`);
  if (r) r.classList.toggle('checked', selectedSet.has(name));
  updateSelBar();
  updateSelFab();
}

/* ---------- BẢNG CHỌN NHIỀU (sheet hiện sau khi nhấn giữ) ---------- */
function selCountLabel() {
  const names = [];
  displayEntries().forEach((e) => { if (selectedSet.has(e.name) && names.length < 2) names.push(e.name); });
  if (!names.length) return '0 mục';
  return names.join(', ') + (selectedSet.size > 1 ? '… (' + selectedSet.size + ' mục)' : '');
}

function openSelSheet() {
  if (!selMode) return;
  const local = isLocalMode();
  const multi = selectedSet.size > 0;
  openSheet('Đã chọn ' + selectedSet.size + ' mục', (body) => {
    const sub = document.createElement('div');
    sub.style.cssText = 'font-size:12px;color:#98a2b3;margin:-8px 0 10px;line-height:1.5';
    sub.textContent = selCountLabel();
    body.appendChild(sub);
    const item = (label, icon, danger, canRun, run) => {
      const d = sheetItem(body, label, { icon, danger, onClick: () => { if (!canRun) { openSelSheet(); return; } run(); } });
      if (!canRun) { d.style.opacity = '.38'; }
      return d;
    };
    if (local) {
      item('Mở', 'i-open', false, selectedSet.size === 1, () => {
        const entry = selectedEntries()[0];
        exitSelMode();
        openSelectedEntry(entry);
      });
      item('Tải về thiết bị', 'i-download', false, multi, () => {
        const files = selectedEntries().filter((e) => e.type === 'file');
        files.forEach((e) => localDownloadEntry(e));
        DC.toast(files.length === 1 ? 'Đang tải về "' + files[0].name + '"' : 'Đang tải về ' + files.length + ' tệp');
        exitSelMode();
      });
      item('Thêm yêu thích', 'i-star', false, multi, () => {
        selAddFavs();
        exitSelMode();
      });
      item('Copy', 'i-copy', false, true, () => { clipCopyMulti(); });
      item('Cut', 'i-cut', false, true, () => { clipCutMulti(); });
      item('Dán vào đây (' + clipboard.items.length + ')', 'i-paste', false, clipboard.items.length > 0, () => { exitSelMode(); clipPaste(); });
      item('Chọn tất cả (' + displayEntries().length + ')', 'i-check-circle', false, true, () => {
        displayEntries().forEach((e) => selectedSet.add(e.name));
        renderFiles();
        openSelSheet();
      });
      item('Xóa khỏi thiết bị', 'i-trash', true, multi, () => localDeleteSelected());
    } else {
      item('Mở', 'i-open', false, selectedSet.size === 1, () => {
        const entry = selectedEntries()[0];
        exitSelMode();
        openSelectedEntry(entry);
      });
      const vids = selectedEntries().filter((e) => e.type === 'file' && isVideoFile(e.name));
      if (vids.length > 0) {
        item('Tải trước (' + vids.length + ' video offline)', 'i-download', false, true, () => {
          preloadVideosOffline(vids);
          exitSelMode();
        });
      }
      item('Tải về', 'i-download', false, multi, () => {
        const files = selectedEntries().filter((e) => e.type === 'file');
        files.forEach((e) => startDownloadFor(e));
        DC.toast(files.length === 1 ? 'Đang tải về "' + files[0].name + '"' : 'Đang tải về ' + files.length + ' tệp');
        exitSelMode();
      });
      item('Chia sẻ link', 'i-upload', false, multi, () => {
        const sel = selectedEntries();
        exitSelMode();
        openShareSheet(sel);
      });
      item('Thêm yêu thích', 'i-star', false, multi, () => {
        selAddFavs();
        exitSelMode();
      });
      item('Khóa bằng mật khẩu', 'i-lock', false, multi, () => selLockAll());
      if (canWrite()) {
        item('Copy', 'i-copy', false, true, () => { clipCopyMulti(); });
        item('Cut', 'i-cut', false, true, () => { clipCutMulti(); });
        item('Dán vào đây (' + clipboard.items.length + ')', 'i-paste', false, clipboard.items.length > 0, () => { exitSelMode(); clipPaste(); });
      }
      item('Chọn tất cả (' + displayEntries().length + ')', 'i-check-circle', false, true, () => {
        displayEntries().forEach((e) => selectedSet.add(e.name));
        renderFiles();
        openSelSheet();
      });
      item('Xóa (vào thùng rác)', 'i-trash', true, multi && canWrite(), () => selDeleteAll());
    }
    sheetItem(body, 'Bỏ chọn', { icon: 'i-deselect', onClick: () => exitSelMode() });
  });
}

function selAddFavs() {
  const list = selectedEntries();
  let added = 0;
  list.forEach((e) => {
    const rel = e._local ? 'local:' + e._p : relOf(e);
    if (favs.findIndex((f) => f.rel === rel) < 0) {
      if (e._local) favs.unshift({ rel, name: e.name, type: e.type, local: true, _p: e._p || '', _mime: e._mime || '', size: e.size || 0 });
      else favs.unshift({ rel, name: e.name, type: e.type, pool: ePool(e), size: e.size || 0 });
      added++;
    }
  });
  kvSet(kFavs(), favs);
  DC.toast(added ? 'Đã thêm ' + added + ' mục vào yêu thích' : 'Các mục này đã ở trong yêu thích');
}

function selDeleteAll() {
  const list = selectedEntries();
  if (!list.length) return;
  sheetConfirm('Xóa ' + list.length + ' mục', 'Các mục được chọn sẽ chuyển vào Thùng rác.', 'Xóa', async () => {
    let ok = 0, fail = 0;
    for (const e of list) {
      try {
        await cacheTrashThumbnail(e);
        await api('/api/file?path=' + enc(relOf(e)) + '&pool=' + enc(ePool(e)), 'DELETE');
        ok++;
      } catch (er) { fail++; }
    }
    DC.toast(fail ? 'Đã xóa ' + ok + ' mục, lỗi ' + fail + ' mục' : 'Đã chuyển ' + ok + ' mục vào thùng rác');
    exitSelMode();
    loadFiles(currentPath);
  });
}

function selLockAll() {
  const list = selectedEntries();
  if (!list.length) return;
  openSheet('Khóa ' + list.length + ' mục bằng mật khẩu', (body) => {
    const wrap = document.createElement('div');
    wrap.className = 'field';
    wrap.innerHTML = '<div class="input-wrap">' + iconSvg('i-lock', 'svg-20') + '<input type="password" placeholder="Mật khẩu khóa (tối thiểu 3 ký tự)"></div>';
    body.appendChild(wrap);
    const input = wrap.querySelector('input');
    const note = document.createElement('div');
    note.style.cssText = 'color:#98a2b3;font-size:12px;margin:4px 2px 10px';
    note.textContent = 'Mật khẩu khóa chỉ có hiệu lực trên thiết bị này.';
    body.appendChild(note);
    setTimeout(() => input.focus(), 120);
    const row = document.createElement('div');
    row.className = 'row-btn';
    row.innerHTML = '<button class="btn secondary">Hủy</button><button class="btn primary">Khóa tất cả</button>';
    row.children[0].addEventListener('click', closeSheet);
    row.children[1].addEventListener('click', async () => {
      if (input.value.length < 3) { note.textContent = '✕ Mật khẩu khóa cần tối thiểu 3 ký tự.'; note.style.color = 'var(--red)'; return; }
      const pw = input.value;
      const hash = sha256js(pw);
      list.forEach((e) => ensureLockMap()[lockKeyFor(e)] = hash);
      saveLockMap();
      for (const e of list) {
        if (!e._local) {
          try {
            await api('/api/locks', 'POST', {
              pool: e.pool || pool,
              path: relOf(e),
              type: e.type === 'dir' ? 'folder' : 'file',
              name: e.name,
              password: pw
            });
          } catch {}
        }
      }
      await syncLocksFromServer();
      closeSheet();
      DC.toast('Đã khóa ' + list.length + ' mục');
      exitSelMode();
      updateLockUI();
    });
    body.appendChild(row);
  });
}
async function clipPaste() {
  if (!clipboard.items.length || !clipboard.mode) { DC.toast('Chưa có mục nào được copy/cut.'); return; }
  if (isLocalMode()) { await clipPasteLocal(); return; }
  if (!canWrite()) { DC.toast('Tài khoản này không có quyền dán.'); return; }
  await clipPasteRemote();
}

/* Dán vào thư mục hiện tại của ổ "Thiết bị này" (hỗ trợ nguồn từ máy LAN). */
async function clipPasteLocal() {
  const to = localDirPath();
  if (!to) { DC.toast('Không xác định được thư mục hiện tại.'); return; }
  try {
    const st = await callNative('localFsStatus', '');
    if (!st || !st.ok) { DC.toast('Chưa có quyền truy cập bộ nhớ máy.'); return; }
  } catch (er) { DC.toast('Chưa có quyền truy cập bộ nhớ máy.'); return; }
  const isCopy = clipboard.mode === 'copy';
  const items = clipboard.items.slice();
  const n = items.length;
  showPasteProgress('Đang dán 0/' + n + ' mục…', 5);
  let doneCount = 0, hasFail = false;
  const cutRemoteItems = [];
  for (let i = 0; i < items.length; i++) {
    const it = items[i];
    showPasteProgress('Đang dán ' + (i + 1) + '/' + n + ' mục…', Math.round(((i + 1) / n) * 90));
    try {
      if (it.local || it.p) {
        const r = await callNative('localFsMove', JSON.stringify({ items: [it.p], to, cut: !isCopy }));
        if (r && r.failed > 0) hasFail = true; else doneCount++;
      } else {
        /* Nguồn từ máy LAN: tải từng mục (file/folder đệ quy) về thư mục hiện tại.
         * Chế độ cut: sau khi tải xong mới xóa nguồn ở máy chủ. */
        const srcPool = it.pool || pool;
        const rel = it.path || '';
        let ok = false;
        if (it.type === 'dir') {
          try {
            const d = await api('/api/files/deep?path=' + enc(rel) + '&pool=' + enc(srcPool));
            const baseName = rel.split('/').pop();
            const files = (d && d.files) || [];
            let allDone = true;
            for (const f of files) {
              const relF = rel + '/' + f.rel;
              const dir = f.rel.includes('/') ? f.rel.slice(0, f.rel.lastIndexOf('/')) : '';
              const sub = baseName + (dir ? '/' + dir : '');
              const r = await dlSubToLocal(relF, f.rel.split('/').pop(), srcPool, to, sub);
              if (!r) allDone = false;
            }
            ok = allDone || !files.length;
          } catch (er) { ok = false; }
        } else {
          ok = await dlSubToLocal(rel, rel.split('/').pop(), srcPool, to, '');
        }
        if (ok) { doneCount++; if (!isCopy) cutRemoteItems.push(it); }
        else hasFail = true;
      }
    } catch (er) { hasFail = true; }
  }
  if (!isCopy && cutRemoteItems.length) {
    for (const it of cutRemoteItems) {
      try { await api('/api/file?path=' + enc(it.path) + '&pool=' + enc(it.pool || pool), 'DELETE'); } catch (er) {}
    }
  }
  clipboard = { items: [], mode: '', dir: '' };
  loadLocalFiles();
  if (hasFail) {
    hidePasteProgress('Dán xong ' + doneCount + '/' + n + ' mục (có lỗi)', true);
  } else {
    hidePasteProgress('Đã dán thành công ' + n + ' mục', false);
  }
}

/* Tải 1 tệp từ máy chủ về thư mục cục bộ (không làm phiền UI truyền tải). */
async function dlToLocal(rel, name, srcPool, destPath) {
  return dlSubToLocal(rel, name, srcPool, destPath, '');
}

/* Tải 1 tệp về thư mục cục bộ, kèm thư mục con (giữ cấu trúc khi dán thư mục). */
async function dlSubToLocal(rel, name, srcPool, destPath, sub) {
  try {
    const url = server.baseUrl + '/api/file?path=' + enc(rel) + (srcPool && srcPool !== LOCAL_POOL ? '&pool=' + enc(srcPool) : '');
    const spec = { url, name, headers: JSON.stringify(token ? { Authorization: 'Bearer ' + token } : {}), destPath, sync: false };
    if (sub) spec.destSub = sub.replace(/^\/+/, '');
    const key = 'dl:' + (srcPool || pool) + ':paste:' + rel;
    const res = await callNative('download', JSON.stringify(spec));
    if (!res || !res.id) return false;
    transfers[key] = { key, dir: 'down', name, rel, pool: srcPool || pool, status: 'queued', done: 0, total: 0, speed: 0, spec };
    transfers[key].id = res.id;
    savePendingDls();
    return await new Promise((resolve) => {
      const check = () => {
        const t = transfers[key];
        if (t && t.status === 'done') { resolve(true); return; }
        if (t && (t.status === 'error' || t.status === 'paused')) { resolve(false); return; }
        setTimeout(check, 400);
      };
      check();
    });
  } catch (e) { return false; }
}

async function clipPasteRemote() {
  if (entryLockedDir(currentPath)) { DC.toast('Thư mục đang bị khóa.'); return; }
  const isCopy = clipboard.mode === 'copy';
  const items = clipboard.items.slice();
  const n = items.length;
  showPasteProgress('Đang dán 0/' + n + ' mục…', 5);

  /* Nếu trong clipboard có mục nguồn từ "Thiết bị này" -> tải từng mục lên máy host trước */
  const localItems = items.filter((it) => it.local || it.p);
  const remoteItems = items.filter((it) => !(it.local || it.p)).map((it) => ({ path: it.path, pool: it.pool }));
  let uploadedLocal = 0, failedLocal = 0;
  for (let i = 0; i < localItems.length; i++) {
    const it = localItems[i];
    showPasteProgress('Đang tải lên (' + (i + 1) + '/' + localItems.length + ')…', Math.round(((i + 1) / localItems.length) * 50));
    try {
      const ok = await uploadLocalItemToHost(it, !isCopy ? [it] : null, 0);
      if (ok) uploadedLocal++; else failedLocal++;
    } catch (er) { failedLocal++; }
  }
  if (remoteItems.length) {
    try {
      const r = await api('/api/move', 'POST', { items: remoteItems, toPool: pool, toPath: currentPath, copy: isCopy });
      if (r.jobId) {
        clipboard = { items: [], mode: '', dir: '' };
        watchPasteJob(r.jobId, remoteItems.length, isCopy);
        return;
      }
    } catch (er) {
      hidePasteProgress('Dán thất bại: ' + errText(er), true);
      return;
    }
  }
  clipboard = { items: [], mode: '', dir: '' };
  loadFiles(currentPath);
  if (failedLocal) {
    hidePasteProgress('Dán xong với ' + (uploadedLocal + remoteItems.length) + ' mục (có lỗi)', true);
  } else {
    hidePasteProgress('Đã dán thành công ' + n + ' mục', false);
  }
}

/* Upload 1 mục (file/folder đệ quy) từ "Thiết bị này" lên thư mục hiện tại của ổ host.
 * Với folder: liệt kê đệ quy rồi upload từng tệp giữ nguyên cấu trúc con.
 * cutAfter != null nghĩa là chế độ cut: upload xong thì xóa nguồn cục bộ. */
async function uploadLocalItemToHost(it, cutAfter, depth) {
  if (depth > 8) return false;
  try {
    const deep = await callNative('localFsDeepList', JSON.stringify({ path: it.p, limit: 10000 }));
    const files = (deep && deep.files) || [];
    if (!files.length) return false;
    let allOk = true;
    for (const f of files) {
      const relName = f.rel || f.name;
      const rel = (currentPath ? currentPath + '/' : '') + relName;
      const ok = await uploadOneLocalToHost(f.p, rel);
      if (!ok) allOk = false;
    }
    if (allOk && cutAfter) {
      const dels = cutAfter.map((x) => x.p);
      if (dels.length) callNative('localFsDelete', JSON.stringify({ items: dels })).catch(() => {});
    }
    return true;
  } catch (e) { return false; }
}

/* Upload 1 tệp cục bộ lên máy host qua cầu nối upload (resume/chunk). */
function uploadOneLocalToHost(p, rel) {
  const name = rel.split('/').pop();
  const key = 'up:' + rel;
  return callNative('upload', JSON.stringify({ baseUrl: server.baseUrl, token, pool, path: rel, name, file: p }))
    .then(async (res) => {
      if (!res || !res.id) return !!(res && res.done);
      if (!transfers[key]) {
        transfers[key] = { key, dir: 'up', name, rel, pool, status: 'queued', done: 0, total: 0, speed: 0, spec: { file: p } };
      }
      transfers[key].id = res.id;
      savePendingUps();
      return new Promise((resolve) => {
        const check = () => {
          const t = transfers[key];
          if (t && t.status === 'done') { resolve(true); return; }
          if (t && t.status === 'error') { resolve(false); return; }
          setTimeout(check, 400);
        };
        check();
      });
    })
    .catch(() => false);
}
function entryLockedDir(dirPath) {
  if (!dirPath) return isPoolLocked(pool);
  const clean = String(dirPath).replace(/\\/g, '/').replace(/^\/+|\/+$/g, '');
  const i = clean.lastIndexOf('/');
  const name = i >= 0 ? clean.slice(i + 1) : clean;
  const parent = i >= 0 ? clean.slice(0, i) : '';
  return !!resolveLockTarget({ name, type: 'dir', dirRel: parent, pool });
}
async function watchPasteJob(jobId, count, isCopy) {
  const tick = async () => {
    try {
      const j = await api('/api/move/progress?id=' + enc(jobId));
      const done = j.doneItems || 0;
      showPasteProgress('Đang dán (' + done + '/' + count + ')…', Math.round((done / Math.max(1, count)) * 100));
      const st = j.status;
      if (st === 'error') {
        hidePasteProgress('Dán bị lỗi: ' + (j.error || 'lỗi máy chủ'), true);
        DC.toast('Dán bị lỗi: ' + (j.error || 'lỗi máy chủ'));
        loadFiles(currentPath);
        return;
      }
      if (st === 'done') {
        hidePasteProgress('Đã dán thành công ' + count + ' mục', false);
        loadFiles(currentPath);
        return;
      }
      setTimeout(tick, 600);
    } catch (e) {
      hidePasteProgress('Dán xong', false);
      loadFiles(currentPath);
    }
  };
  setTimeout(tick, 600);
}

function setupRowLongPress() {
  const list = $('#files .file-list');
  let timer = null;
  let startX = 0, startY = 0, pendingName = null;
  let longDone = false;
  const LONG_MS = 2000;      // Giữ 2 giây để tích chọn theo yêu cầu người dùng
  const MOVE_TOL = 6;        // Di chuyển > 6px là hủy ngay lập tức (không vô tình chọn khi vuốt/cuộn)
  const doSelect = (name) => {
    if (navigator.vibrate) { try { navigator.vibrate(35); } catch (e2) {} }
    lpSuppressClick = true;  // chặn click sinh ra ngay sau khi nhả ngón tay
    setTimeout(() => { lpSuppressClick = false; }, 600);
    if (selMode) toggleSelect(name);
    else enterSelMode(name);
  };
  const fire = () => {
    if (pendingName == null) return;
    const name = pendingName;
    pendingName = null;
    timer = null;
    if (longDone) return;
    longDone = true;
    doSelect(name);
  };
  const clear = () => { if (timer) clearTimeout(timer); timer = null; pendingName = null; };
  list.addEventListener('touchstart', (ev) => {
    longDone = false;
    const row = ev.target.closest && ev.target.closest('.file-row, .media-tile');
    if (!row || !row.dataset.name) { clear(); return; }
    const isMore = ev.target.closest && ev.target.closest('.more');
    if (isMore) { clear(); return; }
    pendingName = row.dataset.name;
    startX = (ev.touches[0] || {}).clientX || 0;
    startY = (ev.touches[0] || {}).clientY || 0;
    if (timer) clearTimeout(timer);
    timer = setTimeout(fire, LONG_MS);
  }, { passive: true });
  list.addEventListener('touchmove', (ev) => {
    if (!timer) return;
    const t = ev.touches[0] || {};
    if (Math.abs((t.clientX || 0) - startX) > MOVE_TOL || Math.abs((t.clientY || 0) - startY) > MOVE_TOL) {
      clear();
    }
  }, { passive: true });
  list.addEventListener('touchend', clear, { passive: true });
  list.addEventListener('touchcancel', clear, { passive: true });
  list.addEventListener('contextmenu', (ev) => {
    // Chặn contextmenu mặc định 500ms của Android WebView để tránh tự chọn khi lướt chậm
    ev.preventDefault();
  });
}
setupRowLongPress();

function setupScrollTop() {
  const btn = $('#scrollTopFab');
  const fileList = $('#files .file-list');
  const shell = document.querySelector('.app-shell');
  const uploadFab = $('#files .fab') || $('.fab');
  if (!btn || !fileList || !shell) return;

  const positionKey = 'scrolltopfabpos-v2';
  let saved = kvGet(positionKey);
  let hasUserPosition = !!(saved && Number.isFinite(saved.x) && Number.isFinite(saved.y));
  let positioned = false;

  const clampPosition = (pos) => {
    const w = btn.offsetWidth || 46;
    const h = btn.offsetHeight || 46;
    return {
      x: Math.max(8, Math.min(Number(pos.x) || 0, Math.max(8, shell.clientWidth - w - 8))),
      y: Math.max(8, Math.min(Number(pos.y) || 0, Math.max(8, shell.clientHeight - h - 8)))
    };
  };
  const defaultPosition = () => {
    const sr = shell.getBoundingClientRect();
    const ur = uploadFab && uploadFab.getBoundingClientRect();
    if (ur && ur.width > 0 && ur.height > 0) {
      return clampPosition({
        x: ur.left - sr.left + (ur.width - (btn.offsetWidth || 46)) / 2,
        y: ur.top - sr.top - (btn.offsetHeight || 46) - 12
      });
    }
    return clampPosition({ x: shell.clientWidth - (btn.offsetWidth || 46) - 18, y: shell.clientHeight - 202 });
  };
  const applyPosition = (pos) => {
    const next = clampPosition(pos);
    btn.style.left = next.x + 'px';
    btn.style.top = next.y + 'px';
    btn.style.right = 'auto';
    btn.style.bottom = 'auto';
    positioned = true;
  };
  const ensurePosition = () => {
    requestAnimationFrame(() => applyPosition(hasUserPosition ? saved : defaultPosition()));
  };

  ensurePosition();
  btn.style.touchAction = 'none';
  const IDLE_HIDE_MS = 2000;
  let hideTimer = 0;
  const hideButton = () => {
    if (drag) return;
    btn.classList.remove('show');
  };
  const scheduleButtonHide = () => {
    if (hideTimer) clearTimeout(hideTimer);
    hideTimer = setTimeout(hideButton, IDLE_HIDE_MS);
  };
  const revealButton = () => {
    if (fileList.scrollTop <= 200 || currentView !== 'files') { hideButton(); return; }
    btn.classList.add('show');
    if (!positioned) ensurePosition();
    scheduleButtonHide();
  };
  let drag = null;
  let suppressClick = false;
  btn.addEventListener('pointerdown', (ev) => {
    if (ev.button !== 0 && ev.pointerType === 'mouse') return;
    if (hideTimer) clearTimeout(hideTimer);
    const rect = btn.getBoundingClientRect();
    drag = { id: ev.pointerId, sx: ev.clientX, sy: ev.clientY, ox: ev.clientX - rect.left, oy: ev.clientY - rect.top, moved: false };
    try { btn.setPointerCapture(ev.pointerId); } catch (e) {}
  });
  btn.addEventListener('pointermove', (ev) => {
    if (!drag || ev.pointerId !== drag.id) return;
    if (!drag.moved && Math.abs(ev.clientX - drag.sx) < 9 && Math.abs(ev.clientY - drag.sy) < 9) return;
    drag.moved = true;
    ev.preventDefault();
    btn.classList.add('show');
    const sr = shell.getBoundingClientRect();
    const x = Math.max(8, Math.min(ev.clientX - sr.left - drag.ox, sr.width - btn.offsetWidth - 8));
    const y = Math.max(8, Math.min(ev.clientY - sr.top - drag.oy, sr.height - btn.offsetHeight - 8));
    btn.style.left = x + 'px';
    btn.style.top = y + 'px';
    btn.style.right = 'auto';
    btn.style.bottom = 'auto';
  });
  btn.addEventListener('pointerup', (ev) => {
    if (!drag || ev.pointerId !== drag.id) return;
    const moved = drag.moved;
    drag = null;
    try { btn.releasePointerCapture(ev.pointerId); } catch (e) {}
    if (moved) {
      suppressClick = true;
      const sr = shell.getBoundingClientRect();
      const br = btn.getBoundingClientRect();
      saved = clampPosition({ x: br.left - sr.left, y: br.top - sr.top });
      hasUserPosition = true;
      kvSet(positionKey, saved);
    }
    scheduleButtonHide();
  });
  btn.addEventListener('pointercancel', () => { drag = null; scheduleButtonHide(); });
  fileList.addEventListener('scroll', revealButton, { passive: true });
  window.addEventListener('resize', () => {
    positioned = false;
    ensurePosition();
  }, { passive: true });
  btn.addEventListener('click', () => {
    if (suppressClick) { suppressClick = false; return; }
    try {
      fileList.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (e) {
      fileList.scrollTop = 0;
    }
    scheduleButtonHide();
  });
}
setupScrollTop();

function setupOverviewFastScroll() {
  const scroller = document.querySelector('#overview .overview-scroll');
  const topButton = document.getElementById('overviewScrollTop');
  const fastScroll = document.getElementById('overviewFastScroll');
  const track = fastScroll && fastScroll.querySelector('.overview-fast-scroll-track');
  const thumb = fastScroll && fastScroll.querySelector('.overview-fast-scroll-thumb');
  const gallery = document.getElementById('overviewGallery');
  if (!scroller || !topButton || !fastScroll || !track || !thumb) return;

  const IDLE_HIDE_MS = 2000;
  let hideTimer = 0;
  let dragging = null;
  let hasScrolled = false;

  const metrics = () => {
    const maxScroll = Math.max(0, scroller.scrollHeight - scroller.clientHeight);
    const trackHeight = Math.max(1, track.clientHeight);
    const proportional = maxScroll > 0 ? Math.round(trackHeight * scroller.clientHeight / scroller.scrollHeight) : trackHeight;
    const thumbHeight = Math.max(42, Math.min(trackHeight, proportional));
    const travel = Math.max(0, trackHeight - thumbHeight);
    return { maxScroll, trackHeight, thumbHeight, travel };
  };

  const syncThumb = () => {
    const m = metrics();
    thumb.style.height = m.thumbHeight + 'px';
    const ratio = m.maxScroll > 0 ? Math.max(0, Math.min(1, scroller.scrollTop / m.maxScroll)) : 0;
    track.style.setProperty('--fast-scroll-y', Math.round(m.travel * ratio) + 'px');
    fastScroll.setAttribute('aria-valuenow', String(Math.round(ratio * 100)));
    return m;
  };

  const hide = () => {
    if (dragging) return;
    topButton.classList.remove('show');
    fastScroll.classList.remove('show');
    topButton.setAttribute('aria-hidden', 'true');
    fastScroll.setAttribute('aria-hidden', 'true');
  };

  const scheduleHide = () => {
    if (hideTimer) clearTimeout(hideTimer);
    hideTimer = setTimeout(hide, IDLE_HIDE_MS);
  };

  const reveal = () => {
    const m = syncThumb();
    if (!hasScrolled || m.maxScroll <= 8 || scroller.scrollTop <= 8) {
      hide();
      return;
    }
    topButton.classList.add('show');
    fastScroll.classList.add('show');
    topButton.setAttribute('aria-hidden', 'false');
    fastScroll.setAttribute('aria-hidden', 'false');
    if (!dragging) scheduleHide();
  };

  const scrollFromPointer = (clientY) => {
    if (!dragging) return;
    const m = syncThumb();
    const rect = track.getBoundingClientRect();
    const y = Math.max(0, Math.min(m.travel, clientY - rect.top - dragging.offset));
    track.style.setProperty('--fast-scroll-y', Math.round(y) + 'px');
    scroller.scrollTop = m.travel > 0 ? (y / m.travel) * m.maxScroll : 0;
    fastScroll.setAttribute('aria-valuenow', String(Math.round(m.travel > 0 ? y / m.travel * 100 : 0)));
  };

  scroller.addEventListener('scroll', () => {
    hasScrolled = true;
    reveal();
  }, { passive: true });

  topButton.addEventListener('click', () => {
    if (hideTimer) clearTimeout(hideTimer);
    try { scroller.scrollTo({ top: 0, behavior: 'smooth' }); }
    catch (e) { scroller.scrollTop = 0; }
  });

  fastScroll.addEventListener('pointerdown', (event) => {
    if (event.button !== 0 && event.pointerType === 'mouse') return;
    if (hideTimer) clearTimeout(hideTimer);
    const m = syncThumb();
    if (m.maxScroll <= 8) return;
    const rect = track.getBoundingClientRect();
    const currentY = m.maxScroll > 0 ? m.travel * scroller.scrollTop / m.maxScroll : 0;
    const relativeY = event.clientY - rect.top;
    const insideThumb = relativeY >= currentY && relativeY <= currentY + m.thumbHeight;
    dragging = { id: event.pointerId, offset: insideThumb ? relativeY - currentY : m.thumbHeight / 2 };
    fastScroll.classList.add('dragging', 'show');
    topButton.classList.add('show');
    try { fastScroll.setPointerCapture(event.pointerId); } catch (e) {}
    scrollFromPointer(event.clientY);
    event.preventDefault();
  });

  fastScroll.addEventListener('pointermove', (event) => {
    if (!dragging || event.pointerId !== dragging.id) return;
    scrollFromPointer(event.clientY);
    event.preventDefault();
  });

  const endDrag = (event) => {
    if (!dragging || (event && event.pointerId != null && event.pointerId !== dragging.id)) return;
    const pointerId = dragging.id;
    dragging = null;
    fastScroll.classList.remove('dragging');
    try { fastScroll.releasePointerCapture(pointerId); } catch (e) {}
    syncThumb();
    scheduleHide();
  };
  fastScroll.addEventListener('pointerup', endDrag);
  fastScroll.addEventListener('pointercancel', endDrag);

  window.addEventListener('resize', () => { syncThumb(); }, { passive: true });
  if (window.ResizeObserver && gallery) new ResizeObserver(() => syncThumb()).observe(gallery);
  hide();
  syncThumb();
}
setupOverviewFastScroll();
$('#searchInput').addEventListener('input', (e) => {
  searchQuery = e.target.value.trim();
  renderFiles();
});
const sortMediaTrigger = $('#sortMediaBtn');
if (sortMediaTrigger) {
  sortMediaTrigger.addEventListener('click', (e) => {
    e.stopPropagation();
    openSheet('Kiểu hiển thị thư mục', (body) => {
      [['auto', 'Tự động', 'Dùng lưới khi thư mục chủ yếu là ảnh/video'], ['gallery', 'Thư viện ảnh/video', 'Thumbnail lớn, vuốt xem nhanh'], ['list', 'Danh sách', 'Hiện tên và thông tin tệp đầy đủ']].forEach((item) => {
        sheetItem(body, item[1], { icon: item[0] === 'list' ? 'i-list' : 'i-grid', sub: item[2], badge: fileViewMode === item[0] ? 'Đang dùng' : '', badgeClass: 'blue', active: fileViewMode === item[0], onClick: () => {
          fileViewMode = item[0];
          kvSet('fileViewMode', fileViewMode);
          closeSheet();
          renderFiles();
        }});
      });
    });
  });
}
const sortTrigger = $('#sortBtn') || $('#files .search > span:last-child');
if (sortTrigger) {
  sortTrigger.addEventListener('click', openSortSheet);
}

function updatePoolBarSelection() {
  // Giữ nguyên thanh tab ổ đĩa khi chọn nhiều để danh sách tệp không bị giật nảy vị trí
}

/* ---------- SELECTION: hành động giờ nằm trong bảng (sheet) — xem openSelSheet() ---------- */

/* ---------- FILES HEAD MENU / FAB ---------- */
$('#files .head-more').addEventListener('click', () => {
  openSheet(server ? server.name : '', (body) => {
    if (!isLocalMode()) {
      sheetItem(body, 'Thư mục mới', { icon: 'i-folder', onClick: newFolderHere });
      sheetItem(body, 'Tải tệp lên', { icon: 'i-upload', onClick: () => pickAndUpload('files') });
      if (clipboard.items.length && canWrite()) sheetItem(body, 'Dán vào đây (' + clipboard.items.length + ' mục)', { icon: 'i-paste', onClick: () => { closeSheet(); clipPaste(); } });
      const pt = poolTargetOf(pool);
      if (isPoolLocked(pool)) sheetItem(body, 'Mở khóa ổ "' + poolNameOf(pool) + '"', { icon: 'i-lock', onClick: () => unlockSheet(pt, () => loadFiles('')) });
      else if (hasPoolLock(pool)) sheetItem(body, 'Gỡ khóa ổ "' + poolNameOf(pool) + '"', { icon: 'i-lock', onClick: () => removeLock(pt) });
      else sheetItem(body, 'Khóa ổ "' + poolNameOf(pool) + '" bằng mật khẩu', { icon: 'i-lock', onClick: () => lockSheet(pt) });
    } else {
      sheetItem(body, 'Cấp quyền lại cho thiết bị', { icon: 'i-phone', onClick: () => { closeSheet(); ensureLocalFsAccess().then((ok) => { if (ok) { localNav = []; loadLocalFiles(); } }); } });
    }
    sheetItem(body, 'Làm mới', { icon: 'i-sync', onClick: () => { closeSheet(); if (isLocalMode()) loadLocalFiles(); else loadFiles(currentPath); DC.toast('Đã làm mới danh sách'); } });
    sheetItem(body, 'Xóa bộ nhớ đệm (Cache)', { icon: 'i-trash', onClick: clearAppCacheMobile });
    sheetItem(body, 'Ngắt kết nối', { icon: 'i-power', onClick: disconnectServer });
    sheetItem(body, 'Đăng xuất', { danger: true, icon: 'i-lock', onClick: logout });
  });
});

async function clearAppCacheMobile() {
  closeSheet();
  try {
    await callNative('clearCache', '');
  } catch (e) {}
  resetOverviewThumbnailWarmState();
  DC.toast('Đã dọn sạch bộ nhớ đệm trên thiết bị');
}

$('#powerBtn').addEventListener('click', disconnectServer);
const bcBackBtn = document.getElementById('bcBackBtn');
if (bcBackBtn) {
  bcBackBtn.addEventListener('click', () => {
    if (isLocalMode()) {
      goLocalBack();
    } else if (currentPath) {
      goDir(parentPath || '');
    } else {
      switchPool(LOCAL_POOL);
    }
  });
}

/* FAB: vừa là nút tải lên, vừa cầm-kéo được */
const fabEl = $('.fab');
let fabDrag = null;
let fabSuppressClick = false;
fabEl.addEventListener('pointerdown', (ev) => {
  if (ev.button !== 0 && ev.pointerType === 'mouse') return;
  const shell = document.querySelector('.app-shell');
  const rect = fabEl.getBoundingClientRect();
  fabDrag = { id: ev.pointerId, x: ev.clientX, y: ev.clientY, ox: ev.clientX - rect.left, oy: ev.clientY - rect.top, moved: false };
  try { fabEl.setPointerCapture(ev.pointerId); } catch (e) {}
});
fabEl.addEventListener('pointermove', (ev) => {
  if (!fabDrag || ev.pointerId !== fabDrag.id) return;
  if (!fabDrag.moved && Math.abs(ev.clientX - fabDrag.x) < 9 && Math.abs(ev.clientY - fabDrag.y) < 9) return;
  fabDrag.moved = true;
  const sr = document.querySelector('.app-shell').getBoundingClientRect();
  const w = fabEl.offsetWidth, h = fabEl.offsetHeight;
  let nx = Math.max(8, Math.min(ev.clientX - sr.left - fabDrag.ox, sr.width - w - 8));
  let ny = Math.max(8, Math.min(ev.clientY - sr.top - fabDrag.oy, sr.height - h - 8));
  fabEl.style.left = nx + 'px';
  fabEl.style.top = ny + 'px';
  fabEl.style.right = 'auto';
  fabEl.style.bottom = 'auto';
});
fabEl.addEventListener('pointerup', (ev) => {
  if (!fabDrag || ev.pointerId !== fabDrag.id) return;
  const moved = fabDrag.moved;
  fabDrag = null;
  try { fabEl.releasePointerCapture(ev.pointerId); } catch (e) {}
  if (moved) {
    fabSuppressClick = true;
    const sr = document.querySelector('.app-shell').getBoundingClientRect();
    const fr = fabEl.getBoundingClientRect();
    kvSet('fabpos:' + (server ? server.baseUrl : ''), { x: fr.left - sr.left, y: fr.top - sr.top });
  }
});
fabEl.addEventListener('pointercancel', () => { fabDrag = null; });
fabEl.addEventListener('click', () => {
  if (fabSuppressClick) { fabSuppressClick = false; return; }
  openFabSheet();
});

function openFabSheet() {
  const local = isLocalMode();
  openSheet('Thêm mới', (body) => {
    if (!local) {
      if (IS_IOS) {
        sheetItem(body, 'Chọn tệp trong máy', { icon: 'i-file', onClick: () => { closeSheet(); pickAndUpload('files'); } });
        sheetItem(body, 'Chọn ảnh hoặc video', { icon: 'i-image', onClick: () => { closeSheet(); pickAndUpload('photos'); } });
        sheetItem(body, 'Chụp ảnh', { icon: 'i-camera', onClick: () => { closeSheet(); pickAndUpload('camera'); } });
        sheetItem(body, 'Quay video', { icon: 'i-video', onClick: () => { closeSheet(); pickAndUpload('video'); } });
      } else {
        sheetItem(body, 'Tải tệp hoặc thư mục lên', { icon: 'i-upload', onClick: () => { closeSheet(); pickAndUpload(); } });
      }
      sheetItem(body, 'Tạo thư mục mới', { icon: 'i-folder', onClick: () => { closeSheet(); newFolderHere(); } });
    } else {
      sheetItem(body, 'Tạo thư mục mới', { icon: 'i-folder', onClick: () => { closeSheet(); newFolderHere(); } });
    }
  });
}

function applyFabPos() {
  const pos = kvGet('fabpos:' + (server ? server.baseUrl : ''));
  if (!pos) return;
  const shell = document.querySelector('.app-shell');
  const x = Math.max(8, Math.min(pos.x, shell.clientWidth - 66));
  const y = Math.max(8, Math.min(pos.y, shell.clientHeight - 66));
  fabEl.style.left = x + 'px';
  fabEl.style.top = y + 'px';
  fabEl.style.right = 'auto';
  fabEl.style.bottom = 'auto';
}

function updateFabVisibility() {
  fabEl.style.display = (currentView === 'files') ? '' : 'none';
}

/* Ngắt kết nối: giữ đăng nhập (token + tin cậy), chỉ quay lại màn hình chọn host */
function disconnectServer() {
  try { DC.setSession('', ''); } catch (e) {}
  stopKeepAlive();
  go('discover');
  runDiscover();
}

function switchServer() {
  sheetConfirm('Đổi máy chủ', 'Ngắt kết nối khỏi ' + (server ? server.name : '') + ' và quay lại màn hình chọn máy chủ?', 'Đổi máy chủ', async () => {
    try { if (token) await api('/api/logout', 'POST'); } catch (e) {}
    token = null; me = null;
    DC.removeKV(kToken());
    if (server) DC.removeKV(kTrust());
    server = null;
    stopKeepAlive();
    go('discover');
    runDiscover();
  });
}
function stopKeepAlive() { if (keepAliveTimer) { clearInterval(keepAliveTimer); keepAliveTimer = null; } }

function logout() {
  sheetConfirm('Đăng xuất', 'Đăng xuất khỏi ' + (server ? server.name : '') + '?', 'Đăng xuất', async () => {
    try { if (token) await api('/api/logout', 'POST'); } catch (e) {}
    token = null; me = null;
    try { DC.setSession('', ''); } catch (e) {}
    DC.removeKV(kToken());
    DC.removeKV(kTrust());
    go('signin');
    $('#passInput').value = '';
  });
}

/* ---------- UPLOAD ---------- */
async function pickAndUpload(source) {
  if (isLocalMode()) { DC.toast('Đang xem ổ "Thiết bị này" — hãy chọn một ổ của máy chủ để tải lên.'); return; }
  if (isPoolLocked(pool)) { unlockSheet(poolTargetOf(pool), () => pickAndUpload(source)); return; }
  if (!canWrite()) { DC.toast('Tài khoản này không có quyền tải lên.'); return; }
  try {
    const r = await callNative('pickFiles', source || 'files');
    const files = (r && r.files) || [];
    if (!files.length) return;
    for (const f of files) {
      const pickedRel = String(f.rel || f.name || 'file').replace(/^\/+/, '');
      const rel = (currentPath ? currentPath + '/' : '') + pickedRel;
      const key = 'up:' + rel;
      transfers[key] = { key, dir: 'up', name: f.name, rel, pool, status: 'queued', done: 0, total: Math.max(0, f.size || 0), speed: 0, spec: { uri: f.uri } };
      renderFiles();
      try {
        const res = await callNative('upload', JSON.stringify({
          baseUrl: server.baseUrl, token, pool, path: rel, name: f.name, uri: f.uri,
        }));
        if (res && res.done) {
          transfers[key].status = 'done';
          transfers[key].done = transfers[key].total;
          removePendingUp(rel);
          savePendingUps();
        } else {
          transfers[key].id = res.id;
          savePendingUps();
        }
      } catch (e) {
        transfers[key].status = 'error';
        removePendingUp(rel); savePendingUps();
        DC.toast('Tải lên "' + f.name + '" thất bại');
      }
    }
    DC.toast(files.length === 1 ? 'Bắt đầu tải lên "' + files[0].name + '"' : 'Bắt đầu tải lên ' + files.length + ' tệp');
  } catch (e) {}
}

window.collectIncomingShares = collectIncomingShares;
async function collectIncomingShares() {
  if (!IS_IOS || !server || !token) return;
  try {
    const result = await callNative('takeIncomingShares');
    const files = (result && result.files) || [];
    if (!files.length) return;
    const seen = new Set(incomingShareFiles.map((x) => x.uri));
    files.forEach((x) => {
      if (x && x.uri && !seen.has(x.uri)) { seen.add(x.uri); incomingShareFiles.push(x); }
    });
    if (isLocalMode()) DC.toast('Đã nhận ' + incomingShareFiles.length + ' tệp. Hãy chọn ổ và thư mục Host để tải lên.');
    else maybePromptIncomingShares();
  } catch (e) {}
}

function maybePromptIncomingShares() {
  if (!incomingShareFiles.length || incomingSharePromptOpen || isLocalMode() || currentView !== 'files') return;
  incomingSharePromptOpen = true;
  const count = incomingShareFiles.length;
  sheetConfirm('Tải tệp được chia sẻ lên Host',
    'Tải ' + count + ' ảnh/video vào thư mục đang mở: ' + (currentPath || 'thư mục gốc') + '?',
    'Tải lên', async () => {
      const files = incomingShareFiles.splice(0);
      incomingSharePromptOpen = false;
      for (const f of files) {
        const rel = (currentPath ? currentPath + '/' : '') + String(f.name || 'file').replace(/^\/+/, '');
        const key = 'up:' + rel;
        transfers[key] = { key, dir: 'up', name: f.name, rel, pool, status: 'queued', done: 0, total: Math.max(0, f.size || 0), speed: 0, spec: { uri: f.uri } };
        try {
          const res = await callNative('upload', JSON.stringify({ baseUrl: server.baseUrl, token, pool, path: rel, name: f.name, uri: f.uri }));
          if (res && res.done) { transfers[key].status = 'done'; transfers[key].done = transfers[key].total; }
          else { transfers[key].id = res.id; savePendingUps(); }
        } catch (e) { transfers[key].status = 'error'; }
      }
      renderFiles();
      DC.toast('Bắt đầu tải lên ' + files.length + ' tệp được chia sẻ');
    });
  const cancel = document.querySelector('#asBody .btn.secondary');
  if (cancel) cancel.addEventListener('click', () => { incomingSharePromptOpen = false; }, { once: true });
}

/* ---------- DOWNLOAD ---------- */
function startDownloadFor(e, openWhenDone) {
  const rel = relOf(e);
  const p = ePool(e);
  const key = 'dl:' + p + ':' + rel;
  const url = server.baseUrl + '/api/file?path=' + enc(rel) + (p && p !== LOCAL_POOL ? '&pool=' + enc(p) : '');
  const spec = Object.assign({ url, name: e.name, headers: JSON.stringify({ Authorization: 'Bearer ' + token }) }, destSpecFor(rel, false));
  transfers[key] = {
    key, dir: 'down', name: e.name, rel, pool: p,
    status: 'queued', done: 0, total: e.size || 0, speed: 0,
    openWhenDone: !!openWhenDone,
    spec,
    createdAt: Date.now()
  };
  renderFiles();
  callNative('download', JSON.stringify(spec))
    .then((res) => { transfers[key].id = res.id; savePendingDls(); })
    .catch((e2) => { transfers[key].status = 'error'; transfers[key].finishedAt = Date.now(); DC.toast('Tải xuống thất bại: ' + errText(e2)); });
}

function startDownload(e, openWhenDone) {
  if (e && e._local) { localDownloadEntry(e, openWhenDone); return; }
  startDownloadFor(e, openWhenDone);
}

function localDownloadEntry(e, openWhenDone) {
  if (!e || !e._p) { DC.toast('Không tải được tệp này.'); return; }
  const key = 'dl:local:' + e._p;
  const spec = Object.assign({ p: e._p, name: e.name, local: true, sync: true, openWhenDone: !!openWhenDone }, destSpecFor('local/' + e.name, false));
  delete spec.destSub;
  transfers[key] = {
    key, dir: 'down', name: e.name, rel: 'local:' + e._p, pool: LOCAL_POOL,
    status: 'queued', done: 0, total: e.size || 0, speed: 0,
    openWhenDone: !!openWhenDone,
    spec,
    createdAt: Date.now()
  };
  renderFiles();
  callNative('localFsDownload', JSON.stringify(spec))
    .then((res) => { transfers[key].id = res.id; savePendingDls(); })
    .catch((e2) => { transfers[key].status = 'error'; transfers[key].finishedAt = Date.now(); DC.toast('Tải xuống thất bại: ' + errText(e2)); });
}

function openOrFetch(e) {
  const rel = relOf(e);
  if (STREAM_PDF.test(e.name)) {
    const p = dlPaths[rel];
    if (p) { callNative('openPdf', JSON.stringify({ path: p, name: e.name })).catch(() => openDownloadedFile(p, e.name)); return; }
    openNativePdf(e, rel, ePool(e));
    return;
  }
  const p = dlPaths[rel];
  if (p) { openDownloadedFile(p, e.name); return; }
  DC.toast('Đang tải "' + e.name + '" về máy để mở...');
  startDownload(e, true);
}

/* ---------- NATIVE EVENTS ---------- */
function onNativeEvent(ev) {
  if (ev && ev.type === 'transfer') {
    let found = transfers[ev.id] || null;
    if (!found) {
      for (const k in transfers) if (transfers[k].id === ev.id) { found = transfers[k]; break; }
    }
    if (!found && ev.origin === 'videoPlayer' && ev.key && ev.name) {
      found = {
        key: String(ev.key), id: String(ev.id || ev.key), dir: 'down',
        name: String(ev.name), rel: String(ev.rel || ev.name), pool: String(ev.pool || 'main'),
        status: 'queued', done: Number(ev.done || 0), total: Number(ev.total || 0), speed: 0,
        spec: { videoPlayer: true, photoLibrary: true }, createdAt: Date.now()
      };
      transfers[found.key] = found;
    }
    if (!found && syncUpQueue.length) {
      const q0 = syncUpQueue[0];
      const k0 = 'up:sync:' + q0.rel + ':' + (q0.pool || '');
      if (transfers[k0]) {
        found = transfers[k0];
        found.id = ev.id;
      }
    }
    if (!found) return;
    const previousStatus = found.status;
    if (ev.status === 'done') {
      found.status = 'done';
      found.finishedAt = Date.now();
      found.done = ev.total || found.done;
      found.total = ev.total || found.total;
      if (found.isOffline) {
        DC.toast('Đã tải trước "' + (found.spec && found.spec.name || found.name) + '" (Xem offline)');
        refreshOfflineCountBadge();
        if (currentView === 'offlineView') openOfflineView();
      } else if (found.dir === 'up') {
        DC.toast('Đã tải lên "' + found.name + '"');
        if (currentView === 'files') loadFiles(currentPath);
      } else {
        const destTxt = found.spec && found.spec.photoLibrary
          ? 'vào ứng dụng Ảnh'
          : (found.spec && found.spec.destPath ? 'vào "' + (found.spec.destPath.split('/').pop() || 'thư mục đã chọn') + '"' : 'vào Downloads');
        DC.toast('Đã tải xuống "' + found.name + '" ' + destTxt);
        if (ev.path) {
          dlPaths[found.rel] = ev.path;
          kvSet(kDlPaths(), dlPaths);
          if (!syncDb[found.rel]) { syncDb[found.rel] = { size: found.total, mtime: Date.now() }; kvSet(kSync(), syncDb); }
        }
        if (found.openWhenDone && ev.path) openDownloadedFile(ev.path, found.name);
      }
      if (found.dir === 'up') { removePendingUp(found.rel); } else { removePendingDl(found.rel || (found.spec && found.spec.url)); }
      savePendingUps(); savePendingDls();
      bumpSyncQueueIfMatch(found);
    } else if (ev.status === 'error') {
      found.status = 'error';
      found.finishedAt = Date.now();
      found.err = ev.err || 'Lỗi mạng';
      if (found.isOffline) {
        DC.toast('Tải trước "' + (found.spec && found.spec.name || found.name) + '" bị lỗi: ' + (ev.err || 'Lỗi mạng'));
      } else {
        DC.toast(found.dir === 'up' ? 'Tải lên "' + found.name + '" bị lỗi' : 'Tải xuống "' + found.name + '" bị lỗi');
      }
      if (found.dir === 'up') { removePendingUp(found.rel); } else { removePendingDl(found.rel || (found.spec && found.spec.url)); }
      savePendingUps(); savePendingDls();
      bumpSyncQueueIfMatch(found);
    } else if (ev.status === 'paused') {
      found.status = 'paused';
      savePendingUps(); savePendingDls();
    } else {
      found.status = ev.status;
      found.done = ev.done;
      if (ev.total) found.total = ev.total;
      if (ev.speed) found.speed = ev.speed;
      // Chỉ gia hạn watchdog khi số byte thật sự tăng; tổng thời gian của video
      // lớn không còn bị xem là lỗi. Native tự retry/resume từng chunk.
      if (found.spec && found.spec.syncUp && ev.status === 'active') {
        resetSyncUpWatchdog(Number(ev.done || 0), false);
      }
    }
    const structuralChange = previousStatus !== found.status || ev.status === 'done' || ev.status === 'error' || ev.status === 'paused';
    if (currentView === 'transfers') {
      if (structuralChange || !updateTransferCardProgress(found)) renderTransfers();
    }
    if (currentView === 'files' && structuralChange) renderFiles();
    if (currentView === 'sync' && structuralChange) renderSync();
  }
}

function bumpSyncQueueIfMatch(t) {
  if (bumpSyncUpIfMatch(t)) return;
}

/* ---------- TRUYỀN TẢI CHẠY NGẦM: lưu hàng chờ để tự nối lại khi mở lại app ---------- */
let restoreDone = false;
let restoreToast = false;

function savePendingUps() {
  if (!server) return;
  const list = Object.values(transfers)
    .filter((t) => t.dir === 'up' && (t.status === 'active' || t.status === 'paused') && t.spec && (t.spec.uri || t.spec.file) && !(t.spec && t.spec.syncUp))
    .map((t) => ({ rel: t.rel, name: t.name, pool: t.pool || 'main', uri: t.spec.uri || '', file: t.spec.file || '', size: t.total || 0 }));
  kvSet(kPending() + ':up', list);
}

function savePendingDls() {
  if (!server) return;
  const list = Object.values(transfers)
    .filter((t) => t.dir === 'down' && (t.status === 'active' || t.status === 'paused') && t.spec && (t.spec.url || t.spec.local))
    .map((t) => ({ url: t.spec.url || '', name: t.name, headers: t.spec.headers || '', destTreeUri: t.spec.destTreeUri || '', destSub: t.spec.destSub || '', destPath: t.spec.destPath || '', rel: t.rel || '', size: t.total || 0, local: !!t.spec.local, tree: t.spec.tree || '', id: t.spec.id || '', mime: t.spec.mime || '' }));
  kvSet(kPending() + ':dl', list);
}

function removePendingUp(rel) {
  const list = kvGet(kPending() + ':up') || [];
  kvSet(kPending() + ':up', list.filter((x) => x.rel !== rel));
}

function removePendingDl(relOrUrl) {
  const list = kvGet(kPending() + ':dl') || [];
  kvSet(kPending() + ':dl', list.filter((x) => x.rel !== relOrUrl && x.url !== relOrUrl));
}

function restorePending() {
  if (restoreDone || !server || !token) return;
  restoreDone = true;
  const ups = kvGet(kPending() + ':up') || [];
  const dls = kvGet(kPending() + ':dl') || [];
  let n = 0;
  ups.forEach((x) => {
    if (transfers['up:' + x.rel]) return;
    const key = 'up:' + x.rel;
    transfers[key] = { key, dir: 'up', name: x.name, rel: x.rel, pool: x.pool, status: 'queued', done: 0, total: x.size || 0, speed: 0, spec: { uri: x.uri || '', file: x.file || '' }, createdAt: Date.now() };
    n++;
  });
  dls.forEach((x) => {
    const rel = x.rel || x.url;
    if (transfers['dl:' + rel]) return;
    const key = 'dl:' + rel;
    const spec = x.local
      ? { local: true, tree: x.tree || '', id: x.id || '', name: x.name, mime: x.mime || '', destTreeUri: x.destTreeUri || '', destSub: x.destSub || '', destPath: x.destPath || '', sync: !!x.destTreeUri, resumeRestore: true }
      : { url: x.url, name: x.name, headers: JSON.stringify(token ? { Authorization: 'Bearer ' + token } : {}), destTreeUri: x.destTreeUri || '', destSub: x.destSub || '', destPath: x.destPath || '', resumeRestore: true };
    transfers[key] = { key, dir: 'down', name: x.name, rel, pool: '', status: 'queued', done: 0, total: x.size || 0, speed: 0, spec, createdAt: Date.now() };
    (x.local ? callNative('localDownload', JSON.stringify(spec)) : callNative('download', JSON.stringify(spec)))
      .then((res) => { transfers[key].id = res.id; })
      .catch(() => { transfers[key].status = 'error'; transfers[key].finishedAt = Date.now(); removePendingDl(rel); savePendingDls(); });
    n++;
  });
  if (ups.length) {
    let i = 0;
    const next = () => {
      if (i >= ups.length) { if (currentView === 'files') renderFiles(); if (currentView === 'transfers') renderTransfers(); return; }
      const x = ups[i++];
      callNative('upload', JSON.stringify({ baseUrl: server.baseUrl, token, pool: x.pool, path: x.rel, name: x.name, uri: x.uri || '', file: x.file || '' }))
        .then((res) => {
          if (res && res.done) { removePendingUp(x.rel); savePendingUps(); delete transfers['up:' + x.rel]; }
          else if (res && res.id) { transfers['up:' + x.rel].id = res.id; }
          else { transfers['up:' + x.rel].status = 'error'; transfers['up:' + x.rel].finishedAt = Date.now(); }
          setTimeout(next, 120);
        })
        .catch(() => { transfers['up:' + x.rel].status = 'error'; transfers['up:' + x.rel].finishedAt = Date.now(); removePendingUp(x.rel); savePendingUps(); setTimeout(next, 120); });
    };
    next();
  }
  if (n && !restoreToast) {
    restoreToast = true;
    DC.toast('Đang tiếp tục ' + n + ' truyền tải chạy ngầm');
  }
  if (currentView === 'files') renderFiles();
  if (currentView === 'transfers') renderTransfers();
}

/* ---------- TRANSFERS VIEW ---------- */
function transferGroups() {
  const ups = [], downs = [], done = [];
  Object.values(transfers).forEach((t) => {
    if (t.status === 'done' || t.status === 'error') done.push(t);
    else if (t.dir === 'up') ups.push(t);
    else downs.push(t);
  });
  done.sort((a, b) => (b.finishedAt || b.createdAt || 0) - (a.finishedAt || a.createdAt || 0));
  return { ups, downs, done };
}

function transferCard(t) {
  const isIOSCamera = !!(t.spec && t.spec.iosCamera);
  const isPhotoLibraryDownload = !!(t.spec && t.spec.photoLibrary);
  const icon = t.dir === 'up' ? fileIcon(t.name) : fileIcon(t.name);
  const pc = t.total ? Math.floor(t.done * 100 / t.total) : 0;
  const isDone = t.status === 'done';
  const failed = t.status === 'error';
  const active = t.status === 'active';
  const queued = t.status === 'queued';
  const paused = t.status === 'paused';
  const dlDir = t.pool === LOCAL_POOL ? 'từ thiết bị này' : dirPart(t.rel);
  const sub = isIOSCamera ? (isDone ? 'Đã đồng bộ lên thư mục Camera trên máy host' : active ? 'Đang đồng bộ thư viện ảnh/video iOS' : queued ? 'Đang chờ đồng bộ thư viện iOS' : paused ? 'Đồng bộ thư viện iOS đang tạm dừng' : 'Đồng bộ iOS bị lỗi · ' + (t.err || '')) : t.dir === 'up'
    ? (isDone ? 'Đã tải lên ' + dirPart(t.rel) : active ? 'Đang tải lên ' + dirPart(t.rel) : queued ? 'Đang chờ tải lên · ' + dirPart(t.rel) : paused ? 'Đang tạm dừng · ' + dirPart(t.rel) : 'Bị lỗi · ' + (t.err || ''))
    : (isDone ? (isPhotoLibraryDownload ? 'Đã lưu vào ứng dụng Ảnh' : 'Đã tải xuống vào máy') : active ? 'Đang tải xuống ' + dlDir : queued ? 'Đang chờ tải xuống · ' + dlDir : paused ? 'Đang tạm dừng' : 'Bị lỗi · ' + (t.err || ''));
  const foot = isIOSCamera
    ? '<span>' + Math.max(0, t.done || 0) + ' / ' + Math.max(0, t.total || 0) + ' tệp</span><span>' + pc + '%</span><span>' + (active ? 'PhotoKit' : paused ? 'Đã dừng' : isDone ? 'Hoàn tất' : 'Có thể thử lại') + '</span>'
    : isDone
      ? '<span>' + fmtBytes(t.total) + '</span><span>100%</span><span style="color:var(--blue)">Bấm để mở →</span>'
      : failed
        ? '<span>' + fmtBytes(t.done) + (t.total ? ' / ' + fmtBytes(t.total) : '') + '</span><span>' + pc + '%</span><span style="color:var(--blue)">Có thể thử lại</span>'
        : '<span>' + fmtBytes(t.done) + (t.total ? ' / ' + fmtBytes(t.total) : '') + '</span><span>' + pc + '%</span><span>' + (active ? fmtEta(t.total, t.done, t.speed) || '...' : queued ? 'Đang chờ' : paused ? 'Đã dừng' : '') + '</span>';
  const stateBtn = isDone
    ? '<div class="pause" style="color:var(--green)">✓</div>'
    : (active ? '<div class="pause" data-act="pause">Ⅱ</div>' : queued ? '<div class="pause" data-act="pause">Ⅱ</div>' : paused ? '<div class="pause" data-act="resume">▶</div>' : '<button class="transfer-retry" type="button" data-act="retry">↻ Thử lại</button>');
  const controls = (active || queued || paused || failed)
    ? '<div class="transfer-actions">' + stateBtn + '<button class="transfer-discard" type="button" data-act="discard" aria-label="Bỏ truyền tải">×</button></div>'
    : stateBtn;
  return '<div class="transfer-card' + (t.status === 'done' ? ' done' : '') + '" data-key="' + enc(t.key) + '"><div class="transfer-top">' + mediaRowThumbHtml({ name: t.name, rel: t.rel, pool: t.pool || 'main', size: t.total || 0 })
    + '<div><div class="transfer-file">' + esc(t.name) + '</div><div class="transfer-sub">' + esc(sub) + '</div></div>'
    + controls + '</div>'
    + '<div class="progressbar transfer-progress' + (isDone ? ' green' : '') + '"><span style="width:' + pc + '%"></span></div>'
    + '<div class="transfer-foot" data-transfer-foot="1">' + foot + '</div></div>';
}

function dirPart(rel) {
  const i = rel.lastIndexOf('/');
  return i >= 0 ? '/' + rel.slice(0, i) : '/';
}

function allTransferCardsHtml() {
  const g = transferGroups();
  let html = '';
  const upsActive = g.ups.filter((t) => t.status !== 'paused');
  const downsActive = g.downs.filter((t) => t.status !== 'paused');
  const pausedAll = [].concat(g.ups, g.downs).filter((t) => t.status === 'paused');
  if (!upsActive.length && !downsActive.length && !pausedAll.length) {
    html = '<div class="empty">Không có truyền tải nào đang chạy.<br>Tải lên bằng nút ＋ ở màn hình Tệp, hoặc chọn "Tải xuống" từ menu của tệp.</div>';
  } else {
    if (upsActive.length) html += '<div class="group-title">Đang tải lên (' + upsActive.length + ')</div>' + upsActive.map(transferCard).join('');
    if (downsActive.length) html += '<div class="group-title">Đang tải xuống (' + downsActive.length + ')</div>' + downsActive.map(transferCard).join('');
    if (pausedAll.length) html += '<div class="group-title">Đang tạm dừng (' + pausedAll.length + ')</div>' + pausedAll.map(transferCard).join('');
  }
  return html;
}

function renderTransfers() {
  const box = $('#transfers .transfer-scroll');
  const tabActive = $$('#transfers .tab')[0].classList.contains('active');
  const g = transferGroups();
  box.innerHTML = tabActive ? allTransferCardsHtml()
    : (g.done.length ? '<div class="group-title">Đã hoàn tất (' + g.done.length + ')</div>' + g.done.map(transferCard).join('')
      : '<div class="empty">Chưa có truyền tải nào hoàn tất.</div>');
  $$('#transfers .transfer-card .pause[data-act]').forEach((b) => {
    b.addEventListener('click', (ev) => {
      ev.stopPropagation();
      const key = decodeURIComponent(b.closest('.transfer-card').dataset.key);
      const t = transfers[key];
      if (!t) return;
      if (b.dataset.act === 'pause') pauseTransfer(t);
      else resumeTransfer(t);
    });
  });
  $$('#transfers .transfer-card .transfer-discard[data-act="discard"]').forEach((b) => {
    b.addEventListener('click', (ev) => {
      ev.stopPropagation();
      const key = decodeURIComponent(b.closest('.transfer-card').dataset.key);
      const t = transfers[key];
      if (t) discardTransfer(t);
    });
  });
  $$('#transfers .transfer-card .transfer-retry[data-act="retry"]').forEach((b) => {
    b.addEventListener('click', (ev) => {
      ev.stopPropagation();
      const key = decodeURIComponent(b.closest('.transfer-card').dataset.key);
      const t = transfers[key];
      if (t) resumeTransfer(t);
    });
  });
  $$('#transfers .transfer-card.done').forEach((card) => {
    card.addEventListener('click', () => {
      const key = decodeURIComponent(card.dataset.key);
      const t = transfers[key];
      if (t) openTransfer(t);
    });
  });
}

function updateTransferCardProgress(t) {
  if (!t) return false;
  const card = document.querySelector('#transfers .transfer-card[data-key="' + enc(t.key) + '"]');
  if (!card) return false;
  const pc = t.total ? Math.max(0, Math.min(100, Math.floor((t.done || 0) * 100 / t.total))) : 0;
  const fill = card.querySelector('.transfer-progress span');
  if (fill) fill.style.width = pc + '%';
  const freshWrap = document.createElement('div');
  freshWrap.innerHTML = transferCard(t);
  const fresh = freshWrap.firstElementChild;
  const oldFoot = card.querySelector('[data-transfer-foot]');
  const freshFoot = fresh && fresh.querySelector('[data-transfer-foot]');
  if (oldFoot && freshFoot) oldFoot.innerHTML = freshFoot.innerHTML;
  const oldSub = card.querySelector('.transfer-sub');
  const freshSub = fresh && fresh.querySelector('.transfer-sub');
  if (oldSub && freshSub && oldSub.textContent !== freshSub.textContent) oldSub.textContent = freshSub.textContent;
  return true;
}

function openTransfer(t) {
  if (!t) return;
  if (t.dir === 'down') {
    const p = dlPaths[t.rel];
    if (p) { callNative('openFile', JSON.stringify({ path: p })); return; }
    DC.toast('Không tìm thấy bản đã tải về trên máy.');
    return;
  }
  if (t.dir === 'up') {
    if (!t.rel || isPoolLocked(t.pool)) {
      if (t.pool && hasPoolLock(t.pool)) { unlockSheet(poolTargetOf(t.pool), () => openTransfer(t)); return; }
      DC.toast('Không mở được file này.');
      return;
    }
    openEntryByRel(t.pool || 'main', t.rel);
  }
}

async function openEntryByRel(p, rel) {
  const prevPool = pool;
  try {
    const dir = dirPart(rel).slice(1);
    const d = await api('/api/files?path=' + enc(dir) + (p && p !== LOCAL_POOL ? '&pool=' + enc(p) : ''));
    const name = rel.split('/').pop();
    const e = (d.entries || []).find((x) => x.name === name);
    if (e) {
      requireUnlocked({ name: e.name, dirRel: dir, pool: p }, () => openPreviewWithRel(e, dir, p, rel));
    } else {
      DC.toast('Không tìm thấy file trên máy chủ.');
    }
  } catch (err) {
    DC.toast(errText(err));
  }
}

function openPreviewWithRel(e, dirRel, p, fullRel) {
  e.dirRel = dirRel;
  e.pool = p;
  if (fullRel != null) e._rel = fullRel;
  openPreview(e);
}

$$('#transfers .tab').forEach((tab) => tab.addEventListener('click', () => {
  $$('#transfers .tab').forEach((t) => t.classList.remove('active'));
  tab.classList.add('active');
  renderTransfers();
}));

function pauseTransfer(t) {
  if (t.spec && t.spec.iosCamera) {
    stopCameraSync();
    t.status = 'paused';
    renderTransfers();
    return;
  }
  if (!t.id) return;
  callNative('cancel', t.id).catch(() => {});
  t.status = 'paused';
  savePendingUps(); savePendingDls();
  renderTransfers();
  renderFiles();
}

async function discardTransfer(t) {
  if (!t || !confirm('Bỏ truyền tải "' + t.name + '"?\n\nFile nguồn và file hoàn chỉnh đã có sẽ không bị xóa.')) return;
  const isSyncItem = !!(t.spec && t.spec.syncUp);
  if (t.spec && t.spec.iosCamera) {
    stopCameraSync();
    delete transfers[t.key];
    renderTransfers();
    return;
  }
  if (t.id) {
    await callNative('discard', JSON.stringify({ id: t.id, name: t.name || '', dir: t.dir || '' })).catch(() => {});
  }
  if (t.dir === 'up') removePendingUp(t.rel);
  else removePendingDl(t.rel || (t.spec && t.spec.url) || '');
  if (isSyncItem) {
    clearSyncUpWatchdog();
    syncUpQueue = syncUpQueue.filter((q) => ('up:sync:' + q.rel + ':' + (q.pool || '')) !== t.key);
    syncUpBusy = false;
  }
  delete transfers[t.key];
  savePendingUps();
  savePendingDls();
  renderTransfers();
  if (currentView === 'files') renderFiles();
  if (currentView === 'sync') renderSync();
  DC.toast('Đã bỏ truyền tải "' + t.name + '"');
  if (isSyncItem) setTimeout(runSyncUpQueue, 250);
}

function resumeTransfer(t) {
  if (!t || !t.spec) { DC.toast('Không còn thông tin nguồn để thử lại file này.'); return; }
  const transferTabs = $$('#transfers .tab');
  transferTabs.forEach((tab) => tab.classList.remove('active'));
  if (transferTabs[0]) transferTabs[0].classList.add('active');
  if (t.spec && t.spec.iosCamera) {
    t.status = 'active';
    t.err = '';
    t.finishedAt = 0;
    syncCameraNow(false);
    renderTransfers();
    return;
  }
  if (t.dir === 'up' && !t.spec.uri && !t.spec.file) {
    DC.toast('Không còn quyền đọc file nguồn. Hãy chọn lại file từ tab Tệp.');
    return;
  }
  t.status = 'active';
  t.err = '';
  t.finishedAt = 0;
  t.speed = 0;
  t.createdAt = Date.now();
  if (t.dir === 'up') {
    callNative('upload', JSON.stringify({ baseUrl: server.baseUrl, token, pool: t.pool, path: t.rel, name: t.name, uri: (t.spec && t.spec.uri) || '', file: (t.spec && t.spec.file) || '' }))
      .then((res) => {
        if (res && res.done) { t.status = 'done'; t.done = t.total; t.finishedAt = Date.now(); }
        else if (res && res.id) t.id = res.id;
        savePendingUps();
        renderTransfers();
      }).catch((e) => { t.status = 'error'; t.err = errText(e); t.finishedAt = Date.now(); renderTransfers(); });
  } else {
    if (t.spec.url) t.spec.headers = JSON.stringify(token ? { Authorization: 'Bearer ' + token } : {});
    if (t.spec && t.spec.local) {
      callNative('localDownload', JSON.stringify(t.spec))
        .then((res) => { t.id = res.id; savePendingDls(); }).catch((e) => { t.status = 'error'; t.err = errText(e); t.finishedAt = Date.now(); renderTransfers(); });
    } else {
      callNative('download', JSON.stringify(t.spec))
        .then((res) => { t.id = res.id; savePendingDls(); }).catch((e) => { t.status = 'error'; t.err = errText(e); t.finishedAt = Date.now(); renderTransfers(); });
    }
  }
  savePendingUps();
  savePendingDls();
  renderTransfers();
}

/* ---------- FAVORITES ---------- */
function renderFavorites() {
  favs = kvGet(kFavs()) || [];
  const files = favs.filter((f) => f.type === 'file');
  const dirs = favs.filter((f) => f.type === 'dir');
  const stats = $$('#favorites .stat-value');
  if (stats[0]) stats[0].textContent = String(files.length);
  if (stats[1]) stats[1].textContent = String(dirs.length);
  const list = $('#favorites .list-card');
  list.innerHTML = '';
  if (!favs.length) {
    list.innerHTML = '<div class="empty">Chưa có mục yêu thích nào.<br>Trong màn hình Tệp, bấm ⋮ của tệp/thư mục rồi chọn "Thêm yêu thích".</div>';
    return;
  }
  favs.forEach((f) => {
    const icon = f.type === 'dir' ? { sym: 'i-folder', color: 'var(--yellow)' } : fileIcon(f.name);
    const meta = f.type === 'dir' ? 'Thư mục ghim' : 'Tệp yêu thích' + (f.size ? ' · ' + fmtBytes(f.size) : '');
    const locked = (f.local || f.type === 'dir') ? false : entryLocked({ name: f.name, dirRel: dirPart(f.rel).slice(1), pool: f.pool });
    const row = document.createElement('div');
    row.className = 'favorite-row';
    row.innerHTML =
      (f.type === 'file' ? mediaRowThumbHtml({ name: f.name, rel: f.rel, pool: f.pool || 'main', size: f.size || 0, mtime: f.mtime || '' }) : '<div style="color:' + icon.color + '">' + iconSvg(icon.sym) + '</div>') +
      '<div><div class="card-title">' + esc(f.name) + '</div><div class="meta2">' + esc(meta) + '</div></div>' +
      (locked ? '<div style="color:var(--blue);display:flex">' + iconSvg('i-lock', 'svg-20') + '</div>' : '<div class="pill blue">Đã thích</div>');
    const pill = row.querySelector('.pill');
    if (pill) pill.addEventListener('click', (ev) => {
      ev.stopPropagation();
      favs = favs.filter((x) => x.rel !== f.rel || String(x.pool || 'main') !== String(f.pool || 'main'));
      kvSet(kFavs(), favs);
      renderFavorites();
    });
    row.addEventListener('click', () => { openFavorite(f); });
    list.appendChild(row);
  });
}

function openFavorite(f) {
  if (f.local && f.type !== 'dir') {
    const e = { name: f.name, type: 'file', size: f.size || 0, _local: true, _fs: true, _p: f._p || '', _id: f._id, _mime: f._mime || '', _localTree: f.localTree };
    openPreview(e);
    return;
  }
  const p = f.pool || pool;
  const dirRel = dirPart(f.rel).slice(1);
  if (f.type === 'dir') {
    const locked = resolveLockTarget({ name: f.name, dirRel, pool: p, type: 'dir' });
    const doGo = () => {
      pool = p;
      renderPoolBar();
      $$('.nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.target === 'files'));
      go('files');
      loadFiles(f.rel);
    };
    if (locked) { unlockSheet(locked, doGo); return; }
    doGo();
    return;
  }
  const e = { name: f.name, type: 'file', size: f.size || 0, dirRel, pool: p };
  const t = resolveLockTarget(e);
  const open = () => openPreviewWithRel(e, dirRel, p, f.rel);
  if (t) { unlockSheet(t, open); return; }
  open();
}
$('#favorites .section-head .text-btn').addEventListener('click', () => DC.toast('Bấm vào mục để mở. Bấm "Đã thích" để bỏ yêu thích.'));

/* ---------- ĐỒNG BỘ 1 CHIỀU: thiết bị này -> thư mục shared của máy host ----------
 * Toàn bộ tệp trong thư mục đồng bộ trên điện thoại được ĐẨY LÊN host,
 * nằm trong thư mục con đặt theo tên điện thoại (để nhiều điện thoại cùng đồng bộ). */
function phoneName() {
  let n = String((IS_IOS && DC._deviceName) || META.device || META.manufacturer || (IS_IOS ? 'iPhone' : 'Android')).trim();
  n = n.replace(/[\\/:*?"<>|]/g, '_').replace(/\s+/g, ' ').trim();
  return n.slice(0, 40) || (IS_IOS ? 'iPhone' : 'Android');
}

function cleanIOSCameraFolderName(value) {
  let name = String(value || '').trim();
  name = name.replace(/[\\/:*?"<>|]+/g, '_').replace(/\s+/g, '_').replace(/_+/g, '_');
  name = name.replace(/^_+|_+$/g, '');
  return name.slice(0, 60);
}

function iosCameraFolderName() {
  return cleanIOSCameraFolderName(iosCameraFolderCustom) || cleanIOSCameraFolderName(phoneName()) || 'iPhone';
}

let hostPoolCache = null;
async function hostPool() {
  if (hostPoolCache) {
    const p = pools.find((x) => x.id === hostPoolCache);
    if (p && p.online !== false) return p;
  }
  if (!pools.length) { try { await loadPools(); } catch (e) {} }
  const p = pools.find((x) => x.isDefault && x.online !== false) || pools.find((x) => x.online !== false) || null;
  hostPoolCache = p ? p.id : null;
  return p;
}

let cameraPoolCache = null;
let cameraStorageRevision = 0;
async function cameraHostPool(forceRefresh) {
  if (forceRefresh) {
    cameraPoolCache = null;
    try { await loadPools(); } catch (e) {}
  }
  if (cameraPoolCache) {
    const p = pools.find((x) => x.id === cameraPoolCache);
    if (p && p.online !== false) return p;
  }
  if (!pools.length) { try { await loadPools(); } catch (e) {} }
  const p = pools.find((x) => x.id === 'pool_camera') ||
            pools.find((x) => /^[eE]:/i.test(x.path || x.root) || /camera/i.test(x.name)) ||
            pools.find((x) => x.isDefault && x.online !== false) || pools[0] || null;
  cameraPoolCache = p ? p.id : null;
  return p;
}

function isCameraSyncRunning() {
  if (IS_IOS) return !!iosCameraState.running;
  return syncUpQueue.some(q => /^Camera(_\d+)?\//i.test(q.rel));
}

function isFolderSyncRunning() {
  return syncUpQueue.some(q => !/^Camera(_\d+)?\//i.test(q.rel));
}

function stopCameraSync() {
  if (IS_IOS) {
    callNative('pauseCameraBackup').catch(() => {});
    iosCameraState.running = false;
    iosCameraState.filename = 'Đã tạm dừng';
    updateIOSCameraTransfer('paused');
    renderSyncSafe();
    DC.toast('Đã dừng đồng bộ thư viện ảnh/video');
    return;
  }
  clearSyncUpWatchdog();
  const camItems = syncUpQueue.filter(q => /^Camera(_\d+)?\//i.test(q.rel));
  camItems.forEach(q => {
    const t = transfers['up:sync:' + q.rel + ':' + (q.pool || '')];
    if (t && t.id) callNative('cancel', t.id).catch(() => {});
  });
  syncUpQueue = syncUpQueue.filter(q => !/^Camera(_\d+)?\//i.test(q.rel));
  syncUpBusy = false;
  renderSync();
  DC.toast('Đã dừng đồng bộ thư viện ảnh/video');
}

function stopFolderSync() {
  clearSyncUpWatchdog();
  const fItems = syncUpQueue.filter(q => !/^Camera(_\d+)?\//i.test(q.rel));
  fItems.forEach(q => {
    const t = transfers['up:sync:' + q.rel + ':' + (q.pool || '')];
    if (t && t.id) callNative('cancel', t.id).catch(() => {});
  });
  syncUpQueue = syncUpQueue.filter(q => /^Camera(_\d+)?\//i.test(q.rel));
  syncUpBusy = false;
  renderSync();
  DC.toast('Đã dừng đồng bộ thư mục');
}

async function syncFolderNow() {
  if (!server || !token) { DC.toast('Chưa kết nối máy chủ.'); return; }
  const srcPath = syncSrc && syncSrc.path;
  if (!srcPath) { DC.toast('Hãy nhấn "Chọn" để chọn thư mục cần đồng bộ.'); return; }
  try {
    const st = await callNative('localFsStatus', '');
    if (!st || !st.ok) { DC.toast('Chưa có quyền truy cập bộ nhớ máy. Vào tab "Thiết bị này" để cấp quyền.'); return; }
    const hp = await hostPool();
    if (!hp) { DC.toast('Không thấy ổ đĩa nào khả dụng trên máy chủ.'); return; }
    DC.toast('Đang quét và tính toán tệp cần đồng bộ…');
    const d = await callNative('localFsDeepList', JSON.stringify({ path: srcPath, limit: 20000 }));
    const files = (d && d.files) || [];
    if (!files.length) { DC.toast('Thư mục đồng bộ đang trống.'); return; }
    const phoneFolder = phoneName();
    const folderBaseName = (syncSrc && syncSrc.name) ? syncSrc.name : (srcPath.split('/').filter(Boolean).pop() || 'Files');

    // Quét đối chiếu toàn diện file đang có sẵn trên Host (chống trùng lặp tuyệt đối)
    let hostFiles = [];
    const hostPoolsToQuery = [hp.id, 'shared'].filter((v, i, a) => v && a.indexOf(v) === i);
    for (const pId of hostPoolsToQuery) {
      for (const pPath of [phoneFolder, 'shared/' + phoneFolder]) {
        try {
          const hRes = await api('/api/files/deep?path=' + enc(pPath) + '&pool=' + enc(pId));
          if (hRes && hRes.files && hRes.files.length) {
            hostFiles = hostFiles.concat(hRes.files);
          }
        } catch (e) {}
      }
    }

    const hostMapByName = new Map();
    const folderFileCounts = new Map();

    hostFiles.forEach((hf) => {
      if (hf && hf.rel) {
        const normRel = hf.rel.replace(/\\/g, '/').replace(/^\/+/, '');
        let subRel = normRel;
        if (subRel.toLowerCase().startsWith(phoneFolder.toLowerCase() + '/')) {
          subRel = subRel.slice(phoneFolder.length + 1);
        } else if (subRel.toLowerCase().startsWith('shared/' + phoneFolder.toLowerCase() + '/')) {
          subRel = subRel.slice(('shared/' + phoneFolder).length + 1);
        }
        const parts = subRel.split('/');
        const fileName = (parts.pop() || '').toLowerCase();
        const fld = parts.length ? parts[0] : '';
        if (fileName) {
          if (!hostMapByName.has(fileName)) hostMapByName.set(fileName, []);
          hostMapByName.get(fileName).push({ ...hf, normRel, folderName: fld });
        }
        if (fld) {
          folderFileCounts.set(fld, (folderFileCounts.get(fld) || 0) + 1);
        }
      }
    });

    const MAX_PER_FOLDER = 200;
    let currentChunkIdx = 1;
    while (true) {
      const count = folderFileCounts.get(`${folderBaseName}_${currentChunkIdx}`) || 0;
      if (count < MAX_PER_FOLDER) break;
      currentChunkIdx++;
    }

    function getNextAvailableFolder() {
      while (true) {
        const folder = `${folderBaseName}_${currentChunkIdx}`;
        const count = folderFileCounts.get(folder) || 0;
        if (count < MAX_PER_FOLDER) {
          folderFileCounts.set(folder, count + 1);
          return folder;
        }
        currentChunkIdx++;
      }
    }

    let skipped = 0;
    let fresh = 0;
    const freshQueue = [];

    files.forEach((f) => {
      const fileName = f.name || f.rel.split('/').pop() || '';
      const name = fileName.toLowerCase();
      const fSize = f.size || 0;

      // Chống trùng lặp theo tên và kích thước
      const existNames = hostMapByName.get(name);
      if (existNames && existNames.some(x => x.size === fSize || Math.abs((x.size || 0) - fSize) < 100)) {
        skipped++;
        return;
      }

      const targetFolder = getNextAvailableFolder();
      const targetRel = targetFolder + '/' + fileName;

      freshQueue.push({
        p: f.p,
        rel: targetRel,
        size: fSize,
        mtime: f.mtime || 0,
        pool: hp.id,
        phoneFolder,
        sharePrefix: ''
      });
      fresh++;
    });

    const isFldRel = (rel) => !/^Camera(_\d+)?\//i.test(rel);
    const nonFldItems = syncUpQueue.filter(q => !isFldRel(q.rel));
    syncUpQueue = nonFldItems.concat(freshQueue);

    if (!fresh) {
      if (skipped > 0) {
        DC.toast('Đồng bộ thư mục: Tất cả ' + skipped + ' tệp đã có trên máy chủ (Bỏ qua, không tải lại).');
      } else {
        DC.toast('Mọi tệp trong thư mục đã được đồng bộ lên máy chủ.');
      }
      renderSyncSafe();
      return;
    }

    syncPaused = false;
    if (skipped > 0) {
      DC.toast('Đồng bộ: Đã quét ' + files.length + ' tệp (' + skipped + ' có sẵn - Bỏ qua). Đang gửi ' + fresh + ' tệp mới (chia nhỏ ≤ 200 tệp/folder)…');
    } else {
      DC.toast('Đồng bộ: Đang gửi ' + fresh + ' tệp mới lên máy chủ (tối đa 200 tệp/folder)…');
    }
    runSyncUpQueue();
    renderSyncSafe();
  } catch (e) {
    DC.toast(errText(e));
  }
}

async function syncCameraNow(isAuto) {
  if (IS_IOS) return syncIOSCameraNow(isAuto);
  if (!server || !token) { if (!isAuto) DC.toast('Chưa kết nối máy chủ.'); return; }
  try {
    const st = await callNative('localFsStatus', '');
    if (!st || !st.ok) {
      if (!isAuto) DC.toast('Chưa có quyền truy cập bộ nhớ máy. Vào tab "Thiết bị này" để cấp quyền.');
      return;
    }
    // Luôn lấy lại cấu hình từ Host trước mỗi phiên đồng bộ. Ổ Camera có thể
    // đã được đổi trong Host khi ứng dụng vẫn đang mở.
    const hp = await cameraHostPool(true);
    if (!hp) { if (!isAuto) DC.toast('Không thấy ổ đĩa nào khả dụng trên máy chủ.'); return; }
    if (!localRootPath) await ensureLocalRootPath();
    const root = localRootPath || '/storage/emulated/0';
    if (!isAuto) DC.toast('Đang quét và tính toán ảnh/video cần đồng bộ…');
    // MediaStore is the source of truth for the Android Gallery. A raw
    // DCIM/Camera walk misses videos/photos stored in Screenshots, Downloads,
    // app albums, SD-card collections, and media exposed only by a provider.
    let d = null;
    try {
      d = await callNative('localMediaDeepList', JSON.stringify({ limit: 20000 }));
    } catch (e) {}
    if (!d || !Array.isArray(d.files) || !d.files.length) {
      d = await callNative('localFsDeepList', JSON.stringify({ path: root + '/DCIM/Camera', limit: 20000 }));
    }
    const files = ((d && d.files) || []).filter((f) => f && f.name && (f.uri || f.p));
    if (!files.length) { if (!isAuto) DC.toast('Không tìm thấy ảnh hoặc video trong thư viện.'); return; }
    const phoneFolder = phoneName();

    let hostFiles = [];
    const hostPoolsToQuery = [hp.id, 'shared'].filter((v, i, a) => v && a.indexOf(v) === i);
    for (const pId of hostPoolsToQuery) {
      for (const pPath of [phoneFolder, 'shared/' + phoneFolder]) {
        try {
          const hRes = await api('/api/files/deep?path=' + enc(pPath) + '&pool=' + enc(pId));
          if (hRes && hRes.files && hRes.files.length) {
            hostFiles = hostFiles.concat(hRes.files);
          }
        } catch (e) {}
      }
    }

    const hostMapByName = new Map();
    const folderFileCounts = new Map();

    hostFiles.forEach((hf) => {
      if (hf && hf.rel) {
        const normRel = hf.rel.replace(/\\/g, '/').replace(/^\/+/, '');
        let subRel = normRel;
        if (subRel.toLowerCase().startsWith(phoneFolder.toLowerCase() + '/')) {
          subRel = subRel.slice(phoneFolder.length + 1);
        } else if (subRel.toLowerCase().startsWith('shared/' + phoneFolder.toLowerCase() + '/')) {
          subRel = subRel.slice(('shared/' + phoneFolder).length + 1);
        }
        const parts = subRel.split('/');
        const fileName = (parts.pop() || '').toLowerCase();
        const folderName = parts.length ? parts[0] : '';

        if (fileName) {
          if (!hostMapByName.has(fileName)) hostMapByName.set(fileName, []);
          hostMapByName.get(fileName).push({ ...hf, normRel, folderName });
        }

        if (folderName) {
          folderFileCounts.set(folderName, (folderFileCounts.get(folderName) || 0) + 1);
        }
      }
    });

    const MAX_PER_FOLDER = 200;
    let currentChunkIdx = 1;
    while (true) {
      const count = folderFileCounts.get(`Camera_${currentChunkIdx}`) || 0;
      if (count < MAX_PER_FOLDER) break;
      currentChunkIdx++;
    }

    function getNextAvailableCameraFolder() {
      while (true) {
        const folder = `Camera_${currentChunkIdx}`;
        const count = folderFileCounts.get(folder) || 0;
        if (count < MAX_PER_FOLDER) {
          folderFileCounts.set(folder, count + 1);
          return folder;
        }
        currentChunkIdx++;
      }
    }

    let skipped = 0;
    let fresh = 0;
    const freshCamQueue = [];

    const localNameCounts = new Map();
    files.forEach((f) => {
      const baseName = f.name || (f.rel || '').split('/').pop() || '';
      const lowerBaseName = baseName.toLowerCase();
      const duplicateIndex = localNameCounts.get(lowerBaseName) || 0;
      localNameCounts.set(lowerBaseName, duplicateIndex + 1);
      let fileName = baseName;
      if (duplicateIndex > 0) {
        const dot = baseName.lastIndexOf('.');
        const stem = dot > 0 ? baseName.slice(0, dot) : baseName;
        const ext = dot > 0 ? baseName.slice(dot) : '';
        const stableSuffix = f.id || (duplicateIndex + 1);
        fileName = stem + '_' + stableSuffix + ext;
      }
      const name = fileName.toLowerCase();
      const fSize = f.size || 0;

      const existNames = hostMapByName.get(name);
      if (existNames && existNames.some(x => x.size === fSize || Math.abs((x.size || 0) - fSize) < 100)) {
        skipped++;
        return;
      }

      const targetFolder = getNextAvailableCameraFolder();
      const targetRel = targetFolder + '/' + fileName;

      freshCamQueue.push({
        p: f.p,
        uri: f.uri || '',
        rel: targetRel,
        size: fSize,
        mtime: f.mtime || 0,
        pool: hp.id,
        phoneFolder,
        sharePrefix: ''
      });
      fresh++;
    });

    const isCamRel = (rel) => /^Camera(_\d+)?\//i.test(rel);
    const nonCamItems = syncUpQueue.filter(q => !isCamRel(q.rel));
    const activeCam = syncUpQueue.length && syncUpBusy && isCamRel(syncUpQueue[0].rel) ? syncUpQueue[0] : null;
    if (activeCam) {
      syncUpQueue = nonCamItems.concat([activeCam]).concat(freshCamQueue.filter(q => q.rel !== activeCam.rel));
    } else {
      syncUpQueue = nonCamItems.concat(freshCamQueue);
    }

    if (!fresh) {
      if (!isAuto) {
        if (skipped > 0) {
          DC.toast('Thư viện: Tất cả ' + skipped + ' mục đã có trên máy chủ (Bỏ qua, không tải lại).');
        } else {
          DC.toast('Mọi ảnh/video trong thư viện đã được đồng bộ lên máy chủ.');
        }
      }
      renderSyncSafe();
      return;
    }

    syncPaused = false;
    if (skipped > 0) {
      DC.toast('Thư viện: Đã quét ' + files.length + ' mục (' + skipped + ' có sẵn - Bỏ qua). Đang gửi ' + fresh + ' mục mới (chia nhỏ ≤ 200 tệp/folder)…');
    } else {
      DC.toast('Thư viện: Đang gửi ' + fresh + ' ảnh/video mới lên máy chủ (tối đa 200 tệp/folder)…');
    }
    runSyncUpQueue();
    renderSyncSafe();
  } catch (e) {
    if (!isAuto) DC.toast(errText(e));
  }
}

function clearSyncUpWatchdog() {
  if (syncUpWatchdog) { clearTimeout(syncUpWatchdog); syncUpWatchdog = null; }
  syncUpLastProgressAt = 0;
  syncUpLastDone = -1;
}

function resetSyncUpWatchdog(done, force) {
  const progress = Number.isFinite(Number(done)) ? Number(done) : 0;
  if (!force && progress <= syncUpLastDone) return;
  if (syncUpWatchdog) clearTimeout(syncUpWatchdog);
  syncUpLastDone = progress;
  syncUpLastProgressAt = Date.now();
  syncUpWatchdog = setTimeout(() => {
    if (syncUpBusy && syncUpQueue.length > 0) {
      console.warn('Sync upload watchdog triggered: restarting stalled item');
      const stalled = syncUpQueue[0];
      if (stalled) {
        const key = 'up:sync:' + stalled.rel + ':' + (stalled.pool || '');
        const t = transfers[key];
        if (t && t.id) callNative('cancel', t.id).catch(() => {});
        if (t) t.status = 'paused';
      }
      syncUpBusy = false;
      // Keep the item at the head of the queue. TransferManager will resume
      // from the last accepted chunk instead of silently losing the file.
      setTimeout(runSyncUpQueue, 2500);
    }
  }, SYNC_UPLOAD_STALL_TIMEOUT_MS);
}

function runSyncUpQueue() {
  if (syncUpBusy || syncPaused) { renderSyncSafe(); return; }
  const next = syncUpQueue[0];
  if (!next) { clearSyncUpWatchdog(); renderSyncSafe(); return; }
  syncUpBusy = true;
  resetSyncUpWatchdog(0, true);
  const key = 'up:sync:' + next.rel + ':' + (next.pool || '');
  const relFull = (next.sharePrefix || '') + next.phoneFolder + '/' + next.rel;
  const nm = next.rel.split('/').pop();
  transfers[key] = { key, id: key, dir: 'up', name: nm, rel: relFull, pool: next.pool || pool, status: 'active', done: 0, total: next.size || 0, speed: 0, spec: { file: next.p || '', uri: next.uri || '', syncUp: true } };
  callNative('upload', JSON.stringify({ id: key, baseUrl: server.baseUrl, token, pool: next.pool || pool, path: relFull, name: nm, file: next.p || '', uri: next.uri || '' }))
    .then((res) => { if (res && res.id) transfers[key].id = res.id; savePendingUps(); })
    .catch(() => {
      clearSyncUpWatchdog();
      transfers[key].status = 'error';
      syncUpBusy = false;
      syncUpQueue.shift();
      setTimeout(runSyncUpQueue, 300);
    });
  renderSyncSafe();
}

function bumpSyncUpIfMatch(t) {
  if (!t || !t.spec || !t.spec.syncUp) return false;
  clearSyncUpWatchdog();
  const q = syncUpQueue[0];
  if (q) {
    const key = 'up:sync:' + q.rel + ':' + (q.pool || '');
    const nm = q.rel.split('/').pop();
    if (t.key === key || t.id === key || t.name === nm || (t.spec && (t.spec.file === q.p || (q.uri && t.spec.uri === q.uri)))) {
      if (t.status === 'done' || t.status === 'error') {
        if (t.status === 'done') {
          syncDbUp[q.rel] = { size: q.size || t.total, mtime: q.mtime || 0 };
          saveSyncDbUp();
        }
        syncUpQueue.shift();
        syncUpBusy = false;
        setTimeout(runSyncUpQueue, 50);
        return true;
      }
    }
  }
  return false;
}

function renderSyncSafe() { if (currentView === 'sync') renderSync(); }

async function iosCameraOptions() {
  // iOS chạy luồng đồng bộ native; vẫn phải làm mới pool ngay trước khi giao
  // cấu hình cho native để không giữ đường dẫn ổ Camera cũ.
  const hp = await cameraHostPool(true);
  if (!hp) throw new Error('Không tìm thấy ổ lưu Camera trên máy chủ.');
  return {
    mediaMode: iosCameraMediaMode,
    storageMode: iosCameraStorageMode,
    includeVideos: iosCameraMediaMode === 'all',
    wifiOnly: true,
    customDeviceName: iosCameraFolderName(),
    imageFolderLimit: iosCameraImageFolderLimit,
    videoFolderLimit: iosCameraVideoFolderLimit,
    deleteAfterUpload: !!iosCameraDeleteAfterUpload,
    baseUrl: server.baseUrl,
    pool: hp.id,
    token: token
  };
}

async function refreshIOSCameraStats(force) {
  if (!IS_IOS || !server || !token || iosCameraStatsBusy) return;
  if (!force && Date.now() - iosCameraStatsAt < 5000) return;
  iosCameraStatsBusy = true;
  try {
    const opts = await iosCameraOptions();
    const stats = await callNative('cameraBackupStats', opts);
    iosCameraState.total = Number(stats.total || 0);
    iosCameraState.backed = Number(stats.backed || 0);
    iosCameraState.pending = Number(stats.pending || 0);
    iosCameraState.error = stats.err || '';
    iosCameraState.recent = Array.isArray(stats.recent) ? stats.recent : [];
    iosCameraState.hostVerified = !!stats.hostVerified;
    iosCameraStatsAt = Date.now();
    if (DC.appLog) DC.appLog('INFO', 'SYNC_UI', 'Stats total=' + iosCameraState.total + ' backed=' + iosCameraState.backed + ' pending=' + iosCameraState.pending);
  } catch (e) {
    iosCameraState.error = errText(e);
    if (DC.appLog) DC.appLog('ERROR', 'SYNC_UI', 'Không đọc được thống kê: ' + iosCameraState.error);
  } finally {
    iosCameraStatsBusy = false;
    renderSyncSafe();
  }
}

function updateIOSCameraTransfer(status) {
  if (!IS_IOS) return;
  const key = 'ios:camera';
  const rawName = String(iosCameraState.filename || 'Thư viện ảnh/video iOS');
  const name = rawName.replace(/^\[[^\]]+\]\s*/, '').replace(/\s*\([^)]*(?:MB|KB|GB|B)\/s[^)]*\)\s*$/i, '') || 'Thư viện ảnh/video iOS';
  const done = Math.max(0, Number(iosCameraState.current || iosCameraState.backed || 0));
  const total = Math.max(done, Number(iosCameraState.total || 0));
  transfers[key] = Object.assign(transfers[key] || {}, {
    key,
    dir: 'up',
    name,
    rel: 'shared/' + iosCameraFolderName() + '/Images/Images_001',
    pool: cameraPoolCache || '',
    status,
    done,
    total,
    speed: 0,
    err: status === 'error' ? (iosCameraState.error || rawName) : '',
    createdAt: (transfers[key] && transfers[key].createdAt) || Date.now(),
    finishedAt: status === 'done' || status === 'error' ? Date.now() : 0,
    spec: { iosCamera: true }
  });
  if (currentView === 'transfers') renderTransfers();
}

function updateIOSCameraProgressUI() {
  if (!IS_IOS || currentView !== 'sync') return;
  const stats = $$('#sync .stat-value');
  if (stats[0]) stats[0].textContent = Math.max(Number(iosCameraState.backed || 0), Number(iosCameraState.current || 0)).toLocaleString('vi-VN');
  if (stats[1]) stats[1].textContent = String(Math.max(0, Number(iosCameraState.pending || 0)));
  if (stats[2]) stats[2].textContent = String(Math.max(0, Number(iosCameraState.failed || 0)));
  const message = $('#sync .ios-sync-message');
  if (message) message.textContent = iosCameraState.running
    ? 'Đang đồng bộ ' + (iosCameraState.filename || 'thư viện iOS')
    : (iosCameraState.error || (iosCameraState.hostVerified && iosCameraState.pending === 0
      ? 'Đã đồng bộ toàn bộ mục đã chọn lên Host.'
      : 'Đồng bộ 1 chiều từ thư viện iOS lên máy host.'));
  const fill = $('#sync .ios-sync-progress');
  if (fill) fill.style.width = (iosCameraState.running ? iosCameraState.percent : 0) + '%';
  const left = $('#sync .ios-sync-progress-label');
  if (left) left.textContent = iosCameraState.running ? (iosCameraState.part || (iosCameraState.current + ' / ' + iosCameraState.total)) : '';
  const cameraMeta = $('#sync .ios-camera-meta');
  if (cameraMeta) cameraMeta.textContent = 'Thư viện iOS · ' + ({ all: 'Ảnh và video', photos: 'Chỉ ảnh', videos: 'Chỉ video' }[iosCameraMediaMode] || 'Ảnh và video') + ' · ' + ({ all: 'Trên máy + iCloud', local: 'Chỉ trên máy', icloud: 'Chỉ iCloud' }[iosCameraStorageMode] || 'Trên máy + iCloud') + ' → ' + iosCameraFolderName() + '/Images + Videos' + (iosCameraDeleteAfterUpload ? ' · Xóa sau xác minh' : ' · Giữ trên iPhone');
}

async function syncIOSCameraNow(isAuto) {
  if (!server || !token) { if (!isAuto) DC.toast('Chưa kết nối máy chủ.'); return; }
  if (iosCameraState.running) return;
  try {
    const opts = await iosCameraOptions();
    iosCameraState.running = true;
    iosCameraState.error = '';
    iosCameraState.filename = 'Đang chuẩn bị thư viện ảnh/video…';
    iosCameraState.percent = 0;
    updateIOSCameraTransfer('active');
    renderSyncSafe();
    if (!isAuto) DC.toast('Đang quét thư viện ảnh/video trên iPhone…');
    if (DC.appLog) DC.appLog('INFO', 'SYNC_UI', 'Bắt đầu đồng bộ iOS; auto=' + !!isAuto);
    const result = await callNative('startCameraBackup', opts);
    iosCameraState.running = false;
    iosCameraState.filename = (result && result.message) || 'Hoàn tất sao lưu';
    await refreshIOSCameraStats(true);
    iosCameraState.current = iosCameraState.backed;
    const fullyVerified = iosCameraState.hostVerified && iosCameraState.pending === 0 && iosCameraState.backed === iosCameraState.total;
    iosCameraState.percent = fullyVerified ? 100 : (iosCameraState.total ? Math.floor(iosCameraState.backed * 100 / iosCameraState.total) : 0);
    if (!fullyVerified) {
      iosCameraState.error = iosCameraState.error || ('Còn ' + iosCameraState.pending + ' mục chưa được xác minh trên Host');
    }
    updateIOSCameraTransfer(fullyVerified ? 'done' : 'error');
    overviewGalleryLastScanAt = 0;
    if (currentView === 'overview') refreshOverviewGallery(true);
    if (!isAuto) DC.toast(iosCameraState.filename);
  } catch (e) {
    iosCameraState.running = false;
    const syncError = errText(e);
    iosCameraState.error = syncError;
    iosCameraState.filename = syncError;
    updateIOSCameraTransfer('error');
    await refreshIOSCameraStats(true);
    iosCameraState.error = syncError;
    iosCameraState.filename = syncError;
    renderSyncSafe();
    if (!isAuto) DC.toast(syncError);
    if (DC.appLog) DC.appLog('ERROR', 'SYNC_UI', syncError);
  }
}

DC._onCameraProgress = (current, total, filename, part, percent) => {
  if (!IS_IOS) return;
  iosCameraState.current = Number(current || 0);
  iosCameraState.total = Number(total || iosCameraState.total || 0);
  iosCameraState.pending = Math.max(0, iosCameraState.total - iosCameraState.current);
  iosCameraState.filename = String(filename || '');
  if (/^\[Lỗi/i.test(iosCameraState.filename)) {
    const failedName = iosCameraState.filename.replace(/^\[[^\]]+\]\s*/, '').split(':')[0].trim() || iosCameraState.filename;
    iosCameraFailedNames.add(failedName);
    iosCameraState.failed = iosCameraFailedNames.size;
    const errorKey = 'ios:camera:error:' + failedName;
    transfers[errorKey] = {
      key: errorKey, dir: 'up', name: failedName, rel: iosCameraFolderName(), pool: cameraPoolCache || '',
      status: 'error', done: 0, total: 0, speed: 0, err: iosCameraState.filename,
      createdAt: Date.now(), finishedAt: Date.now(), spec: { iosCamera: true, iosCameraFailed: true }
    };
  }
  iosCameraState.part = String(part || '');
  iosCameraState.percent = Math.max(0, Math.min(100, Number(percent || 0)));
  iosCameraState.running = !/^\[Dừng\]|hoàn tất|đã đồng bộ toàn bộ|còn \d+ mục|tạm dừng|không thể đồng bộ/i.test(iosCameraState.filename);
  const isDone = /hoàn tất|đã đồng bộ toàn bộ/i.test(iosCameraState.filename);
  updateIOSCameraTransfer(iosCameraState.running ? 'active' : (/tạm dừng/i.test(iosCameraState.filename) ? 'paused' : (isDone ? 'done' : 'error')));
  // Không dựng lại toàn bộ tab trên mỗi gói tiến độ; chỉ cập nhật các node thay đổi.
  updateIOSCameraProgressUI();
};

DC._onCameraUploaded = (record) => {
  if (!IS_IOS || !record) return;
  const path = String(record.path || '');
  const item = {
    name: String(record.name || (path.split('/').pop() || 'Tệp')),
    path,
    size: Number(record.size || 0),
    syncedAt: Number(record.syncedAt || (Date.now() / 1000))
  };
  iosCameraState.current = Math.max(Number(iosCameraState.current || 0), Number(record.current || 0));
  iosCameraState.backed = Math.max(Number(iosCameraState.backed || 0), iosCameraState.current);
  iosCameraState.total = Math.max(Number(iosCameraState.total || 0), Number(record.total || 0));
  iosCameraState.pending = Math.max(0, iosCameraState.total - iosCameraState.backed);
  iosCameraState.recent = [item].concat((iosCameraState.recent || []).filter((x) => String(x.path || '') !== path)).slice(0, 30);
  iosCameraStatsAt = Date.now();
  overviewGalleryLastScanAt = 0;
  renderSyncSafe();
};

function renderSync() {
  const syncedCount = IS_IOS ? iosCameraState.backed : Object.keys(syncDbUp).length + Object.keys(syncDb).length;
  const stats = $$('#sync .stat-value');
  if (stats[0]) stats[0].textContent = syncedCount.toLocaleString('vi-VN');
  if (stats[1]) stats[1].textContent = String(IS_IOS ? iosCameraState.pending : syncUpQueue.filter((q) => { const t = transfers['up:sync:' + q.rel + ':' + (q.pool || '')]; return !t || t.status !== 'active'; }).length);
  if (stats[2]) stats[2].textContent = String(IS_IOS ? iosCameraState.failed : 0);

  const overview = $$('#sync .sync-card')[0];
  if (overview) {
    const total = IS_IOS ? iosCameraState.pending : syncUpQueue.length;
    const q0 = syncUpQueue[0];
    const runningKey = q0 ? 'up:sync:' + q0.rel + ':' + (q0.pool || '') : null;
    const runningT = runningKey ? transfers[runningKey] : null;
    const pc = IS_IOS ? iosCameraState.percent : (runningT && runningT.total ? Math.floor(runningT.done * 100 / runningT.total) : 0);
    const iosRunning = IS_IOS && iosCameraState.running;
    const overviewMessage = IS_IOS
      ? (iosRunning ? 'Đang đồng bộ ' + (iosCameraState.filename || 'thư viện iOS') : (iosCameraState.error || (iosCameraState.hostVerified && iosCameraState.pending === 0 ? 'Đã đồng bộ toàn bộ mục đã chọn lên Host.' : 'Đồng bộ 1 chiều từ thư viện iOS lên máy host.')))
      : (syncPaused ? 'Đồng bộ đang tạm dừng.' : total ? 'Đang đẩy ' + total + ' tệp từ máy này lên máy chủ (1 chiều).' : 'Đồng bộ 1 chiều: gửi file từ điện thoại lên thư mục shared/' + esc(phoneName()) + ' trên máy host.');
    overview.innerHTML =
      '<div class="card-title">Tổng quan đồng bộ</div>' +
      '<div class="card-sub' + (IS_IOS ? ' ios-sync-message' : '') + '">' + esc(overviewMessage) + '</div>' +
      '<div class="progressbar"><span' + (IS_IOS ? ' class="ios-sync-progress"' : '') + ' style="width:' + ((iosRunning || runningT) ? pc : 0) + '%"></span></div>' +
      '<div class="transfer-foot"><span' + (IS_IOS ? ' class="ios-sync-progress-label"' : '') + '>' + (iosRunning ? esc(iosCameraState.part || (iosCameraState.current + ' / ' + iosCameraState.total)) : (runningT ? 'Đang gửi: ' + fmtBytes(runningT.done) + ' / ' + fmtBytes(runningT.total) : '')) + '</span><span>' + (token ? esc(server.name) : '') + '</span></div>';
  }

  const list = $('#sync .list-card');
  list.innerHTML = '';

  if (IS_IOS) {
    const primaryRow = document.createElement('div');
    primaryRow.className = 'ios-sync-primary-wrap';
    primaryRow.innerHTML = '<button class="ios-sync-primary ' + (iosCameraState.running ? 'stop' : '') + '">' +
      iconSvg(iosCameraState.running ? 'i-close' : 'i-sync') +
      '<span>' + (iosCameraState.running ? 'Dừng đồng bộ' : 'Bắt đầu đồng bộ ngay') + '</span></button>';
    primaryRow.querySelector('button').addEventListener('click', () => {
      if (iosCameraState.running) stopCameraSync(); else syncCameraNow(false);
    });
    list.appendChild(primaryRow);
  }

  if (!IS_IOS) {
  const srcRow = document.createElement('div');
  srcRow.className = 'sync-row';
  const isFldRunning = isFolderSyncRunning();
  srcRow.innerHTML =
    '<div style="color:var(--green)">' + iconSvg('i-sync') + '</div>' +
    '<div><div class="card-title">Thư mục đồng bộ (nguồn)</div><div class="meta2">' + esc(syncSrcLabel()) + ' → shared/' + esc(phoneName()) + ' trên máy chủ</div></div>' +
    '<div style="display:flex;gap:6px;align-items:center">' +
      '<div class="pill blue choose-src-btn">Chọn</div>' +
      '<div class="pill ' + (isFldRunning ? 'red' : 'blue') + ' sync-fld-btn">' + (isFldRunning ? 'Dừng lại' : 'Đồng bộ') + '</div>' +
    '</div>';
  srcRow.querySelector('.choose-src-btn').addEventListener('click', (e) => { e.stopPropagation(); chooseSyncSrcFolder(); });
  srcRow.querySelector('.sync-fld-btn').addEventListener('click', (e) => {
    e.stopPropagation();
    if (isFolderSyncRunning()) {
      stopFolderSync();
    } else {
      syncFolderNow();
    }
  });
  list.appendChild(srcRow);
  }

  const dlRow = document.createElement('div');
  dlRow.className = 'sync-row';
  dlRow.innerHTML = '<div style="color:var(--blue)">' + iconSvg('i-download') + '</div><div><div class="card-title">Nơi lưu file tải về</div><div class="meta2">' + esc(downloadDestLabel()) + '</div></div><div style="display:flex;gap:6px;align-items:center"><div class="pill blue">Chọn</div><div class="pill gray">Mở thư mục</div></div>';
  dlRow.querySelectorAll('.pill')[0].addEventListener('click', (e) => { e.stopPropagation(); chooseSyncFolder(); });
  dlRow.querySelectorAll('.pill')[1].addEventListener('click', (e) => { e.stopPropagation(); openDownloadFolder(); });
  if (!IS_IOS) list.appendChild(dlRow);

  if (IS_IOS) {
    const folderRow = document.createElement('div');
    folderRow.className = 'sync-row ios-camera-folder-row';
    folderRow.innerHTML =
      '<div style="color:var(--blue)">' + iconSvg('i-folder') + '</div>' +
      '<div><div class="card-title">Tên thư mục thiết bị trên Host</div><div class="meta2">Tự chia Images/Images_001… và Videos/Videos_001…</div></div>' +
      '<div style="display:flex;gap:6px;align-items:center;min-width:0">' +
        '<input class="ios-camera-folder-input" aria-label="Tên thư mục lưu đồng bộ" maxlength="60" value="' + esc(iosCameraFolderName()) + '"' + (iosCameraState.running ? ' disabled' : '') + ' style="width:132px;max-width:34vw;border:1px solid var(--line);border-radius:10px;padding:9px 10px;background:var(--card);color:var(--text);font:inherit" />' +
        '<div class="pill blue ios-camera-folder-save">Lưu</div>' +
      '</div>';
    const folderInput = folderRow.querySelector('.ios-camera-folder-input');
    const saveFolderName = async () => {
      if (iosCameraState.running) return;
      const nextName = cleanIOSCameraFolderName(folderInput.value);
      if (!nextName) { DC.toast('Tên thư mục không được để trống.'); folderInput.value = iosCameraFolderName(); return; }
      folderInput.value = nextName;
      if (nextName === iosCameraFolderName()) return;
      const galleryWasShowingOwnDevice = ensureOverviewGalleryDeviceFolder() === iosCameraFolderName();
      iosCameraFolderCustom = nextName;
      kvSet(kIOSCameraFolderName(), iosCameraFolderCustom);
      if (galleryWasShowingOwnDevice) {
        pauseOverviewThumbnailWork();
        overviewGalleryDeviceFolder = nextName;
        overviewGalleryScope = '';
        overviewGalleryItems = [];
        overviewGalleryVisible = [];
        overviewGalleryLastScanAt = 0;
        overviewGalleryDeviceChoices = [];
        overviewGalleryDeviceChoicesAt = 0;
        updateOverviewGalleryDeviceButton();
      }
      iosCameraState.backed = 0;
      iosCameraState.pending = iosCameraState.total;
      iosCameraState.current = 0;
      iosCameraState.recent = [];
      iosCameraState.error = '';
      iosCameraState.hostVerified = false;
      iosCameraStatsAt = 0;
      renderPoolBar();
      renderSync();
      DC.toast('Đã đặt thư mục đồng bộ: ' + iosCameraFolderCustom);
      await refreshIOSCameraStats(true);
    };
    folderRow.querySelector('.ios-camera-folder-save').addEventListener('click', (e) => { e.stopPropagation(); saveFolderName(); });
    folderInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); saveFolderName(); } });
    list.appendChild(folderRow);

    const modeRow = document.createElement('div');
    modeRow.className = 'sync-row ios-camera-mode-row';
    modeRow.innerHTML =
      '<div style="color:var(--blue)">' + iconSvg('i-video') + '</div>' +
      '<div><div class="card-title">Loại nội dung cần đồng bộ</div><div class="meta2">Chỉ bắt đầu khi bạn nhấn nút Đồng bộ</div></div>' +
      '<select class="ios-camera-mode" aria-label="Loại nội dung đồng bộ"' + (iosCameraState.running ? ' disabled' : '') + '>' +
        '<option value="all">Ảnh và video</option>' +
        '<option value="photos">Chỉ ảnh</option>' +
        '<option value="videos">Chỉ video</option>' +
      '</select>';
    const selector = modeRow.querySelector('.ios-camera-mode');
    selector.value = iosCameraMediaMode;
    selector.addEventListener('change', async () => {
      if (iosCameraState.running) return;
      iosCameraMediaMode = selector.value;
      kvSet(kIOSCameraMediaMode(), iosCameraMediaMode);
      iosCameraState.error = '';
      iosCameraState.hostVerified = false;
      iosCameraStatsAt = 0;
      renderSync();
      await refreshIOSCameraStats(true);
    });
    list.appendChild(modeRow);

    const storageRow = document.createElement('div');
    storageRow.className = 'sync-row ios-camera-storage-row';
    storageRow.innerHTML =
      '<div style="color:var(--cyan)">' + iconSvg('i-cloud') + '</div>' +
      '<div><div class="card-title">Vị trí ảnh/video nguồn</div><div class="meta2">iCloud sẽ được tải về tạm thời trước khi upload</div></div>' +
      '<select class="ios-camera-storage" aria-label="Vị trí nội dung đồng bộ"' + (iosCameraState.running ? ' disabled' : '') + '>' +
        '<option value="all">Trên máy + iCloud</option>' +
        '<option value="local">Chỉ có trên máy</option>' +
        '<option value="icloud">Chỉ có trên iCloud</option>' +
      '</select>';
    const storageSelector = storageRow.querySelector('.ios-camera-storage');
    storageSelector.value = iosCameraStorageMode;
    storageSelector.addEventListener('change', async () => {
      if (iosCameraState.running) return;
      iosCameraStorageMode = storageSelector.value;
      kvSet(kIOSCameraStorageMode(), iosCameraStorageMode);
      iosCameraState.error = '';
      iosCameraState.hostVerified = false;
      iosCameraStatsAt = 0;
      renderSync();
      await refreshIOSCameraStats(true);
    });
    list.appendChild(storageRow);

    const limitsRow = document.createElement('div');
    limitsRow.className = 'sync-row ios-camera-limits-row';
    limitsRow.innerHTML =
      '<div style="color:var(--blue)">' + iconSvg('i-grid') + '</div>' +
      '<div><div class="card-title">Số tệp tối đa mỗi thư mục</div><div class="meta2">Ảnh và video được đánh số thư mục ổn định</div></div>' +
      '<div class="ios-limit-fields"><label>Ảnh<input class="ios-image-limit" type="number" min="25" max="5000" value="' + iosCameraImageFolderLimit + '"' + (iosCameraState.running ? ' disabled' : '') + '></label><label>Video<input class="ios-video-limit" type="number" min="25" max="5000" value="' + iosCameraVideoFolderLimit + '"' + (iosCameraState.running ? ' disabled' : '') + '></label><button class="pill blue ios-limits-save">Lưu</button></div>';
    limitsRow.querySelector('.ios-limits-save').addEventListener('click', () => {
      if (iosCameraState.running) return;
      const imageLimit = Math.max(25, Math.min(5000, Number(limitsRow.querySelector('.ios-image-limit').value || 400)));
      const videoLimit = Math.max(25, Math.min(5000, Number(limitsRow.querySelector('.ios-video-limit').value || 300)));
      iosCameraImageFolderLimit = imageLimit;
      iosCameraVideoFolderLimit = videoLimit;
      kvSet(kIOSCameraImageFolderLimit(), imageLimit);
      kvSet(kIOSCameraVideoFolderLimit(), videoLimit);
      DC.toast('Đã lưu giới hạn: ' + imageLimit + ' ảnh · ' + videoLimit + ' video.');
      renderSync();
    });
    list.appendChild(limitsRow);

    const deleteRow = document.createElement('div');
    deleteRow.className = 'sync-row ios-camera-delete-row';
    deleteRow.innerHTML =
      '<div style="color:var(--red)">' + iconSvg('i-trash') + '</div>' +
      '<div><div class="card-title">Xóa khỏi iPhone sau khi upload</div><div class="meta2">Chỉ chuyển vào Đã xóa gần đây sau khi Host xác minh đủ file</div></div>' +
      '<label class="ios-switch" aria-label="Tự động xóa file sau khi upload thành công">' +
        '<input class="ios-camera-delete-toggle" type="checkbox" role="switch"' + (iosCameraDeleteAfterUpload ? ' checked' : '') + (iosCameraState.running ? ' disabled' : '') + ' />' +
        '<span class="ios-switch-track"><span class="ios-switch-thumb"></span></span>' +
      '</label>';
    const deleteToggle = deleteRow.querySelector('.ios-camera-delete-toggle');
    deleteToggle.addEventListener('change', () => {
      if (iosCameraState.running) return;
      iosCameraDeleteAfterUpload = !!deleteToggle.checked;
      kvSet(kIOSCameraDeleteAfterUpload(), iosCameraDeleteAfterUpload);
      renderSync();
      DC.toast(iosCameraDeleteAfterUpload
        ? 'Đã bật: chỉ xóa sau khi Host xác minh đầy đủ.'
        : 'Đã tắt: file vẫn được giữ trên iPhone.');
    });
    list.appendChild(deleteRow);
  }

  const camRow = document.createElement('div');
  camRow.className = 'sync-row ios-camera-row';
  const isCamRunning = isCameraSyncRunning();
  const modeLabel = IS_IOS ? ({ all: 'ảnh/video', photos: 'ảnh', videos: 'video' }[iosCameraMediaMode] || 'ảnh/video') : 'ảnh/video';
  camRow.innerHTML =
    '<div style="color:var(--cyan)">' + iconSvg('i-cloud') + '</div>' +
    '<div>' +
      '<div class="card-title">Sao lưu thư viện ' + modeLabel + '</div>' +
      '<div class="meta2"' + (IS_IOS ? ' id="ios-camera-meta"' : '') + '>Thư viện ' + (IS_IOS ? 'iOS · ' + ({ all: 'Ảnh và video', photos: 'Chỉ ảnh', videos: 'Chỉ video' }[iosCameraMediaMode] || 'Ảnh và video') : 'Android') + ' → ' + esc(IS_IOS ? iosCameraFolderName() + '/Images + Videos' + (iosCameraDeleteAfterUpload ? ' · Xóa sau xác minh' : ' · Giữ trên iPhone') : 'shared/' + phoneName() + '/Camera') + '</div>' +
    '</div>' +
    '<div style="display:flex;gap:6px;align-items:center">' +
      '<div class="pill ' + (isCamRunning ? 'red' : 'blue') + ' sync-cam-btn">' + (isCamRunning ? 'Dừng đồng bộ' : 'Đồng bộ ' + modeLabel) + '</div>' +
    '</div>';

  camRow.querySelector('.sync-cam-btn').addEventListener('click', (e) => {
    e.stopPropagation();
    if (isCameraSyncRunning()) {
      stopCameraSync();
    } else {
      syncCameraNow(false);
    }
  });
  if (!IS_IOS) list.appendChild(camRow);

  syncUpQueue.forEach((q) => {
    const t = transfers['up:sync:' + q.rel + ':' + (q.pool || '')];
    const name = q.rel.split('/').pop();
    const icon = fileIcon(name);
    const running = t && t.status === 'active';
    const pause = t && t.status === 'paused';
    const err = t && t.status === 'error';
    const pc = t && t.total ? Math.floor(t.done * 100 / t.total) : 0;
    const row = document.createElement('div');
    row.className = 'sync-row';
    row.innerHTML =
      mediaRowThumbHtml({ name, rel: q.rel, pool: q.pool || pool || 'main', size: q.size || 0 }) +
      '<div><div class="card-title">' + esc(name) + '</div><div class="meta2">' + esc(q.rel) + ' · ' + fmtBytes(q.size) + '</div></div>' +
      '<div class="pill ' + (running ? 'blue' : err ? 'red' : pause ? 'yellow' : 'gray') + '">' + (running ? pc + '%' : err ? 'Lỗi' : pause ? 'Dừng' : 'Chờ') + '</div>';
    list.appendChild(row);
  });

  if (IS_IOS) {
    const failedTransfers = Object.values(transfers).filter((t) => t && t.status === 'error' && t.spec && t.spec.iosCameraFailed);
    if (failedTransfers.length) {
      const head = document.createElement('div');
      head.className = 'ios-sync-section-label';
      head.textContent = 'FILE LỖI — CÓ THỂ THỬ LẠI';
      list.appendChild(head);
      failedTransfers.slice(-12).reverse().forEach((t) => {
        const row = document.createElement('div');
        row.className = 'sync-row ios-sync-error-row';
        row.innerHTML = '<div style="color:var(--red)">' + iconSvg('i-alert') + '</div><div><div class="card-title">' + esc(t.name) + '</div><div class="meta2">' + esc(t.err || 'Không đọc được dữ liệu từ Photos/iCloud') + '</div></div><button class="pill red">Thử lại</button>';
        row.querySelector('button').addEventListener('click', () => syncIOSCameraNow(false));
        list.appendChild(row);
      });
    }
  }

  const iosRecent = IS_IOS && Array.isArray(iosCameraState.recent) ? iosCameraState.recent : [];
  const syncedKeys = IS_IOS ? [] : Object.keys(syncDbUp).slice(-8).reverse();
  if ((iosRecent.length || syncedKeys.length) && !syncUpQueue.length) {
    const head = document.createElement('div');
    head.style.cssText = 'padding:12px 14px 6px;font-size:12px;color:#98a2b3';
    head.textContent = 'ĐÃ ĐẨY LÊN MÁY CHỦ GẦN ĐÂY';
    list.appendChild(head);
    const rows = IS_IOS ? iosRecent.slice(0, 8).map((x) => ({ rel: x.path || x.name || '', name: x.name || (x.path || '').split('/').pop() || 'Tệp', size: Number(x.size || 0), pool: x.pool || cameraPoolCache || 'main' })) : syncedKeys.slice(0, 6).map((rel) => ({ rel, name: rel.split('/').pop(), pool: pool || 'main' }));
    rows.forEach((item) => {
      const rel = item.rel;
      const name = item.name;
      const icon = fileIcon(name);
      const row = document.createElement('div');
      row.className = 'sync-row';
      row.innerHTML = mediaRowThumbHtml({ name, rel, pool: item.pool || 'main', size: item.size || 0 }) + '<div><div class="card-title">' + esc(name) + '</div><div class="meta2">' + esc(rel) + '</div></div><div class="pill green">✓</div>';
      list.appendChild(row);
    });
  }
}

function kSyncDest() { return 'syncDest:' + (server ? server.baseUrl : ''); }

function loadSyncDest() {
  syncDest = kvGet(kSyncDest()) || null;
  syncSrc = kvGet(kSyncSrc()) || null;
  syncDbUp = kvGet(kSyncDbUp()) || {};
}

function saveSyncDest() { kvSet(kSyncDest(), syncDest); }
function saveSyncSrc() { kvSet(kSyncSrc(), syncSrc); }
function saveSyncDbUp() { kvSet(kSyncDbUp(), syncDbUp); }

function destLabelOf(d) {
  if (!d) return '';
  if (d.path) return d.name || d.path;
  if (d.treeUri) return d.name || 'Thư mục đã chọn';
  return '';
}

function syncDestLabel() {
  if (syncDest && (syncDest.path || syncDest.treeUri)) return destLabelOf(syncDest);
  return 'Downloads/CW-Datacenter (mặc định)';
}

function downloadDestLabel() {
  if (syncDest && (syncDest.path || syncDest.treeUri)) return destLabelOf(syncDest);
  return 'Downloads/CW-Datacenter';
}

function syncSrcLabel() {
  if (syncSrc && syncSrc.path) return destLabelOf(syncSrc);
  return 'Chưa chọn';
}

/* Spec lưu file tải về: ưu tiên thư mục trên máy (path) -> SAF tree -> mặc định Downloads/CW-Datacenter */
function destSpecFor(rel, manual) {
  const spec = { sync: !manual };
  if (syncDest && syncDest.path) {
    spec.destPath = syncDest.path;
    if (!manual) {
      const i = rel.lastIndexOf('/');
      spec.destSub = i >= 0 ? rel.slice(0, i) : '';
    }
    return spec;
  }
  if (syncDest && syncDest.treeUri) {
    spec.destTreeUri = syncDest.treeUri;
    if (!manual) {
      const i = rel.lastIndexOf('/');
      spec.destSub = i >= 0 ? rel.slice(0, i) : '';
    }
  }
  return spec;
}

/* Chọn thư mục (nơi tải về / nguồn đồng bộ) ngay trong app, tab "Thiết bị này":
 * chuyển sang tab Tệp, mở ổ Thiết bị này và chờ người dùng duyệt tới thư mục rồi bấm chọn. */
let pickNavCtx = null; // {kind:'syncDest'|'syncSrc'|'dest', onPick}

function ensureLocalReady() {
  if (localRootPath) return Promise.resolve(true);
  return callNative('localFsStatus', '').then(async (st) => {
    if (!st || !st.ok) {
      await callNative('requestLocalFsAccess', '');
      DC.toast('Sau khi cấp quyền, quay lại đây và bấm nút chọn lần nữa.');
      return false;
    }
    const info = await callNative('localFsInfo', '');
    localRootPath = (info && info.rootPath) || '/storage/emulated/0';
    localDrive = { fs: true, name: 'Thiết bị này' };
    return true;
  }).catch(() => false);
}

function enterLocalPick(kind) {
  const title = kind === 'syncSrc' ? 'Chọn thư mục ĐỒNG BỘ (nguồn trên máy này)' : 'Chọn nơi lưu file tải về';
  ensureLocalReady().then((ok) => {
    if (!ok) return;
    pickNavCtx = { kind };
    $$('.nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.target === 'files'));
    go('files');
    if (pool !== LOCAL_POOL) { pool = LOCAL_POOL; localNav = []; renderPoolBar(); }
    if (!localNav.length) localNav = [{ path: localRootPath, name: 'Bộ nhớ trong' }];
    loadLocalFiles();
    DC.toast(title + ' — duyệt tới thư mục rồi bấm "Chọn thư mục này".');
    updateLocalPickBar();
  });
}

function updateLocalPickBar() {
  const bar = document.getElementById('localPickBar') || (() => {
    const d = document.createElement('div');
    d.id = 'localPickBar';
    d.style.cssText = 'display:none;gap:8px;padding:8px 14px 0;flex-wrap:wrap';
    const sel = document.createElement('button');
    sel.className = 'pill blue';
    sel.style.cssText = 'border:0;background:var(--blue);color:#fff;padding:9px 14px;font-size:12.5px;border-radius:999px;cursor:pointer';
    sel.textContent = '✓ Chọn thư mục này';
    sel.addEventListener('click', () => {
      if (!pickNavCtx) return;
      const cur = localNav.length ? localNav[localNav.length - 1].path : localRootPath;
      const nameSegs = localNav.slice(1).map((s) => s.name);
      const nm = nameSegs.join('/') || 'Bộ nhớ trong';
      applyLocalPick(pickNavCtx.kind, cur, nm);
      pickNavCtx = null;
      updateLocalPickBar();
    });
    const cancel = document.createElement('button');
    cancel.className = 'pill gray';
    cancel.style.cssText = 'border:0;background:#f5f7fa;color:#667085;padding:9px 14px;font-size:12.5px;border-radius:999px;cursor:pointer';
    cancel.textContent = 'Hủy';
    cancel.addEventListener('click', () => { pickNavCtx = null; updateLocalPickBar(); DC.toast('Đã hủy chọn thư mục.'); });
    d.appendChild(sel);
    d.appendChild(cancel);
    const filesSec = $('#files');
    const head = filesSec.querySelector('.app-head');
    head.after(d);
    return d;
  })();
  bar.style.display = pickNavCtx ? 'flex' : 'none';
}

function applyLocalPick(kind, path, name) {
  if (kind === 'syncDest' || kind === 'dest') {
    syncDest = { path, name };
    saveSyncDest();
    DC.toast('File tải về sẽ lưu vào: ' + name);
    hostPoolCache = null;
  } else if (kind === 'syncSrc') {
    syncSrc = { path, name };
    saveSyncSrc();
    DC.toast('Thư mục đồng bộ: ' + name + ' — chỉ đẩy file từ máy này lên máy chủ (1 chiều).');
  }
  if (currentView === 'sync') renderSync();
}

async function chooseSyncFolder() {
  enterLocalPick('syncDest');
}

async function chooseSyncSrcFolder() {
  enterLocalPick('syncSrc');
}

function clearSyncFolder() {
  syncDest = null;
  saveSyncDest();
  DC.toast('Dùng thư mục mặc định Downloads/CW-Datacenter');
  if (currentView === 'sync') renderSync();
}

/* Mở thư mục tải về / đồng bộ ngay trong app tại tab "Thiết bị này" (không mở app ngoài). */
async function openDownloadFolder() {
  const root = await ensureLocalRootPath();
  if (!root) return;
  let targetPath = null;
  if (syncDest && syncDest.path) {
    targetPath = syncDest.path;
  } else if (syncDest && syncDest.treeUri) {
    targetPath = root + '/Download/CW-Datacenter';
  } else {
    targetPath = root + '/Download/CW-Datacenter';
  }
  openLocalFolderInFiles(targetPath);
}

async function ensureLocalRootPath() {
  if (!localRootPath) {
    try {
      const info = await callNative('localFsInfo', '');
      localRootPath = (info && info.rootPath) || '/storage/emulated/0';
    } catch (e) { localRootPath = '/storage/emulated/0'; }
  }
  return localRootPath;
}

function openLocalFolderInFiles(path) {
  const root = localRootPath || '/storage/emulated/0';
  const rel = path.startsWith(root) ? path.slice(root.length).replace(/^\/+/, '') : '';
  const segs = rel ? rel.split('/').filter(Boolean) : [];
  /* Tạo sẵn thư mục để khi mở tab Thiết bị này là thấy ngay */
  try { callNative('localFsEnsure', JSON.stringify({ path })).catch(() => {}); } catch (e) {}
  localNav = [{ path: root, name: 'Bộ nhớ trong' }];
  let acc = root;
  for (const s of segs) { acc = acc + '/' + s; localNav.push({ path: acc, name: s }); }
  $$('.nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.target === 'files'));
  go('files');
  if (pool !== LOCAL_POOL) { pool = LOCAL_POOL; renderPoolBar(); }
  loadLocalFiles();
}

/* ---------- TRASH ---------- */
let trashItems = [];
async function loadTrash() {
  try {
    const d = await api('/api/trash');
    trashItems = d.items || [];
    renderTrash();
  } catch (e) { DC.toast(errText(e)); }
}

function renderTrash() {
  const stats = $$('#trash .stat-value');
  if (stats[0]) stats[0].textContent = String(trashItems.length);
  const total = trashItems.reduce((a, b) => a + (b.size || 0), 0);
  if (stats[1]) stats[1].textContent = fmtBytes(total) || '0 B';
  const list = $('#trash .list-card');
  list.innerHTML = '';
  if (!trashItems.length) {
    list.innerHTML = '<div class="empty">Thùng rác trống.</div>';
    return;
  }
  trashItems.forEach((it) => {
    const icon = it.type === 'dir' ? { sym: 'i-folder', color: 'var(--yellow)' } : fileIcon(it.name);
    const media = it.type === 'file' && isThumbable(it.name || '');
    const thumb = media ? trashThumbUrl({ name: it.name, rel: it.rel, pool: it.pool || 'main', size: it.size || 0 }) : '';
    const row = document.createElement('div');
    row.className = 'trash-row';
    row.innerHTML =
      (media ? '<div class="media-row-thumb" style="color:' + icon.color + '">' + iconSvg(icon.sym, 'svg-24') + (thumb ? '<img src="' + esc(thumb) + '" alt="" loading="lazy" onerror="CWRetryThumbnail(this)">' : '') + '</div>' : '<div style="color:' + icon.color + '">' + iconSvg(icon.sym) + '</div>') +
      '<div><div class="card-title">' + esc(it.name) + '</div><div class="meta2">Đã xóa ' + esc(fmtAgo(it.deletedAt)) + (it.size ? ' · ' + fmtBytes(it.size) : '') + '</div></div>' +
      '<div class="trash-actions"><button type="button" class="pill red trash-restore">Khôi phục</button><button type="button" class="trash-delete-one">Xóa</button></div>';
    row.querySelector('.trash-restore').addEventListener('click', async (e) => {
      e.stopPropagation();
      try { await api('/api/trash/restore', 'POST', { id: it.id }); DC.toast('Đã khôi phục "' + it.name + '"'); loadTrash(); }
      catch (er) { DC.toast(errText(er)); }
    });
    row.querySelector('.trash-delete-one').addEventListener('click', (e) => {
      e.stopPropagation();
      sheetConfirm('Xóa vĩnh viễn', 'Xóa vĩnh viễn "' + it.name + '"? Thao tác này không thể hoàn tác.', 'Xóa', async () => {
        try { await api('/api/trash/purge', 'POST', { id: it.id }); localStorage.removeItem(trashThumbKey(it)); DC.toast('Đã xóa vĩnh viễn "' + it.name + '"'); loadTrash(); }
        catch (er) { DC.toast(errText(er)); }
      });
    });
    list.appendChild(row);
  });
}

$$('#trash .small-btn').forEach((b, i) => b.addEventListener('click', () => {
  if (i === 0) { DC.toast('Bấm "Khôi phục" trên từng mục để lấy lại.'); }
  else {
    if (!trashItems.length) { DC.toast('Thùng rác đang trống'); return; }
    sheetConfirm('Dọn sạch thùng rác', 'Xóa vĩnh viễn toàn bộ ' + trashItems.length + ' mục? Không thể hoàn tác.', 'Xóa tất cả', async () => {
      try { await api('/api/trash/purge', 'POST', {}); DC.toast('Đã dọn sạch thùng rác'); loadTrash(); }
      catch (er) { DC.toast(errText(er)); }
    });
  }
}));
$('#trash .section-head .text-btn').addEventListener('click', () => DC.toast('Mục mới xóa luôn nằm trên cùng.'));

/* ---------- APP LOGS ---------- */
async function loadAppLogs() {
  const output = document.getElementById('logConsole');
  const summary = document.getElementById('logSummary');
  if (!output || !summary) return;
  summary.textContent = 'Đang đọc nhật ký…';
  try {
    const result = await callNative('appLogs', '');
    output.textContent = (result && result.text) || 'Chưa có nhật ký.';
    const bytes = Number(result && result.size || 0);
    summary.textContent = 'Phiên bản ' + ((result && result.version) || '1.6.60') + ' · ' + fmtBytes(bytes) + ' · mới nhất nằm cuối';
    output.scrollTop = output.scrollHeight;
  } catch (e) {
    output.textContent = 'Không đọc được nhật ký: ' + errText(e);
    summary.textContent = 'Có lỗi khi đọc nhật ký';
  }
}

const refreshLogsBtn = document.getElementById('refreshLogsBtn');
if (refreshLogsBtn) refreshLogsBtn.addEventListener('click', loadAppLogs);
const shareLogsBtn = document.getElementById('shareLogsBtn');
if (shareLogsBtn) shareLogsBtn.addEventListener('click', async () => {
  try { await callNative('shareAppLogs', ''); }
  catch (e) { DC.toast('Không gửi được log: ' + errText(e)); }
});
const clearLogsBtn = document.getElementById('clearLogsBtn');
if (clearLogsBtn) clearLogsBtn.addEventListener('click', () => {
  sheetConfirm('Xóa nhật ký', 'Xóa toàn bộ lịch sử thao tác và lỗi đang lưu trên máy?', 'Xóa log', async () => {
    try { await callNative('clearAppLogs', ''); await loadAppLogs(); }
    catch (e) { DC.toast('Không xóa được log: ' + errText(e)); }
  });
});
$('#transfers .head-row > span').addEventListener('click', () => {
  openSheet('Truyền tải', (body) => {
    const all = Object.values(transfers);
    const errs = all.filter((t) => t.status === 'error');
    if (errs.length) {
      sheetItem(body, 'Xóa mục lỗi khỏi danh sách (' + errs.length + ')', {
        icon: 'i-trash',
        onClick: () => {
          errs.forEach((t) => delete transfers[t.key]);
          renderTransfers();
          DC.toast('Đã xóa ' + errs.length + ' mục lỗi');
        }
      });
    }
    if (all.length) {
      sheetItem(body, 'Xóa toàn bộ danh sách (' + all.length + ')', {
        icon: 'i-trash',
        danger: true,
        onClick: () => {
          Object.keys(transfers).forEach((k) => delete transfers[k]);
          savePendingUps();
          savePendingDls();
          renderTransfers();
          DC.toast('Đã xóa toàn bộ danh sách truyền tải');
        }
      });
    }
    sheetItem(body, 'Đóng', { onClick: () => {} });
  });
});

const vrResumeBtn = document.getElementById('vrResumeBtn');
if (vrResumeBtn) {
  vrResumeBtn.addEventListener('click', () => {
    if (!pendingResumeVideo) return;
    const { e, rel, p, plIdx, playlist, pos } = pendingResumeVideo;
    closeVideoResumeModal();
    launchMobileVideo(e, rel, p, plIdx, playlist, pos);
  });
}

const vrRestartBtn = document.getElementById('vrRestartBtn');
if (vrRestartBtn) {
  vrRestartBtn.addEventListener('click', () => {
    if (!pendingResumeVideo) return;
    const { e, rel, p, plIdx, playlist } = pendingResumeVideo;
    closeVideoResumeModal();
    launchMobileVideo(e, rel, p, plIdx, playlist, 0);
  });
}

const vrCancelBtn = document.getElementById('vrCancelBtn');
if (vrCancelBtn) {
  vrCancelBtn.addEventListener('click', closeVideoResumeModal);
}

/* ---------- BOOT ---------- */
async function boot() {
  const last = kvGet('last');
  if (last && last.baseUrl) {
    try {
      const tk = kvGet('token:' + last.baseUrl);
      if (tk) {
        const d = await tryApi(last.baseUrl, '/api/me', 'GET', null, tk);
        server = last;
        token = tk;
        me = { role: d.role || 'admin', user: d.user || 'admin' };
        $('#signHost').textContent = server.name;
        $('#signIp').textContent = server.ip;
        fillTrust();
        const trusted = DC.loadKV(kTrust());
        if (trusted === '1') { enterMain(); return; }
        go('trust');
        return;
      }
    } catch (e) {}
  }
  go('discover');
  refreshOfflineCountBadge();
  runDiscover();
}

function rememberLast() {
  if (server) kvSet('last', { baseUrl: server.baseUrl, ip: server.ip, port: server.port, host: server.host, name: server.name, via: server.via });
}
const _enterMain = enterMain;
enterMain = function () { rememberLast(); _enterMain(); };

const origSelectServer = selectServer;

boot();
})();
