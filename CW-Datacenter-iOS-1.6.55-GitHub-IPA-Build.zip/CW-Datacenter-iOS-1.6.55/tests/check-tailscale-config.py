"""Fail packaging if the Tailscale HTTP exception or release identity is missing.

This validates configuration, not Apple's runtime ATS behavior on an iPhone.
Run again with --app <CWDatacenter.app> after Xcode has built the bundle.
"""
import argparse
import ipaddress
import plistlib
from pathlib import Path

VERSION = "1.6.55"
BUILD = "10655"
ROOT = Path(__file__).resolve().parents[1]


def check_plist(path):
    with path.open("rb") as stream:
        info = plistlib.load(stream)
    assert info["CFBundleShortVersionString"] == VERSION, "Wrong iOS version"
    assert info["CFBundleVersion"] == BUILD, "Wrong iOS build number"
    assert info["CFBundleIdentifier"] == "com.cw.datacenter.ios"
    ats = info["NSAppTransportSecurity"]
    assert ats["NSAllowsLocalNetworking"] is True, "Preserve LAN access"
    exceptions = ats.get("NSExceptionDomains", {})
    assert exceptions == {
        "100.64.0.0/10": {"NSExceptionAllowsInsecureHTTPLoads": True}
    }, "Missing or overbroad Tailscale exception"
    # Do not introduce global web/media bypasses or TLS/certificate downgrades.
    assert set(ats) == {
        "NSAllowsArbitraryLoads", "NSAllowsLocalNetworking", "NSExceptionDomains"
    }
    assert ats["NSAllowsArbitraryLoads"] is True  # Existing legacy setting only.
    assert info.get("NSLocalNetworkUsageDescription")


def check_source(root):
    check_plist(root / "CWDatacenter/Info.plist")
    project = (root / "CWDatacenter.xcodeproj/project.pbxproj").read_text(encoding="utf-8")
    assert project.count(f"CURRENT_PROJECT_VERSION = {BUILD};") == 4
    assert project.count(f"MARKETING_VERSION = {VERSION};") == 4
    assert '2017 /* HostConnectionDiagnostics.swift */ = {isa = PBXFileReference;' in project
    assert 'fileRef = 2017 /* HostConnectionDiagnostics.swift */;' in project
    assert '1014 /* HostConnectionDiagnostics.swift in Sources */,' in project
    main = (root / "CWDatacenter/ViewControllers/MainViewController.swift").read_text(encoding="utf-8")
    assert 'HostConnectionDiagnostics.message(for: error, url: url)' in main
    assert 'NSURLErrorAppTransportSecurityRequiresSecureConnection' in (
        root / "CWDatacenter/Network/HostConnectionDiagnostics.swift"
    ).read_text(encoding="utf-8")
    assert 'config.connectionProxyDictionary = [:]' in main
    assert 'config.allowsCellularAccess = true' in main
    assert 'config.allowsConstrainedNetworkAccess = true' in main
    assert 'defer { session.finishTasksAndInvalidate() }' in main
    assert f'private let webAssetVersion = "{VERSION}"' in main
    assert 'Hãy kiểm tra Tailscale trên iPhone/iPad và máy Host đều đang Online' not in main
    check_web(root / "CWDatacenter/Resources/Web")


def check_web(web):
    assert f"CW_WEB_VERSION = '{VERSION}'" in (web / "app.js").read_text(encoding="utf-8")
    assert f'cw-web-version" content="{VERSION}"' in (web / "index.html").read_text(encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--app", type=Path)
    args = parser.parse_args()
    check_source(args.root)
    network = ipaddress.ip_network("100.64.0.0/10")
    for address in ("100.66.66.66", "100.64.0.0", "100.127.255.255"):
        assert ipaddress.ip_address(address) in network
    for address in ("100.63.255.255", "100.128.0.0", "8.8.8.8", "192.168.1.47"):
        assert ipaddress.ip_address(address) not in network
    if args.app:
        check_plist(args.app / "Info.plist")
        check_web(args.app / "Web")
        assert (args.app / "PlugIns/CWDatacenterShare.appex").is_dir()
        print("PASS: built app version, web bundle, extension and narrow ATS exception")
    print("PASS: source version, Xcode wiring, Tailscale range, LAN/cellular settings and error wiring")


if __name__ == "__main__":
    main()
