const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const image = fs.readFileSync(path.join(root, 'CWDatacenter', 'ViewControllers', 'ImageViewController.swift'), 'utf8');
const player = fs.readFileSync(path.join(root, 'CWDatacenter', 'ViewControllers', 'PlayerViewController.swift'), 'utf8');

test('photo viewer has a compact Photos-style layout and one-tap fullscreen toggle', () => {
  assert.match(image, /UICollectionViewDataSource, UICollectionViewDelegateFlowLayout/);
  assert.match(image, /private var filmstrip: UICollectionView!/);
  assert.match(image, /PhotoFilmstripCell/);
  assert.match(image, /setControlsVisible\(!controlsVisible\)/);
  assert.match(image, /compactMediaConstraints/);
  assert.match(image, /fullMediaConstraints/);
  assert.match(image, /UIStackView\(arrangedSubviews: \[favoriteBtn, downloadBtn, shareBtn, infoBtn, deleteBtn\]\)/);
  assert.match(image, /title: "Yêu thích", symbol: "heart"/);
  assert.match(image, /title: "Tải về", symbol: "arrow\.down\.to\.line"/);
  assert.match(image, /title: "Chia sẻ", symbol: "square\.and\.arrow\.up"/);
  assert.match(image, /title: "Thông tin", symbol: "info\.circle"/);
  assert.match(image, /title: "Xóa", symbol: "trash"/);
});

test('video viewer mirrors the compact photo viewer with a thumbnail strip', () => {
  assert.match(player, /private let mediaContainer = UIView\(\)/);
  assert.match(player, /private var filmstrip: UICollectionView!/);
  assert.match(player, /VideoFilmstripCell/);
  assert.match(player, /controlsVisible \? hideControls\(\) : showControls\(\)/);
  assert.match(player, /compactMediaConstraints/);
  assert.match(player, /fullMediaConstraints/);
  assert.match(player, /UIStackView\(arrangedSubviews: \[favoriteBtn, downloadBtn, shareBtn, deleteBtn\]\)/);
  assert.match(player, /pagePreviewThumbnailURL/);
  assert.match(player, /URLQueryItem\(name: "size", value: "160"\)/);
});

test('both viewers expose date metadata and keep share safe on iPad', () => {
  assert.match(image, /mediaDate\(from: item\["mtime"\]\)/);
  assert.match(player, /mediaDate\(from: item\["mtime"\]\)/);
  assert.match(image, /popover\.sourceView = shareBtn/);
  assert.match(player, /popover\.sourceView = self\.shareBtn/);
});
