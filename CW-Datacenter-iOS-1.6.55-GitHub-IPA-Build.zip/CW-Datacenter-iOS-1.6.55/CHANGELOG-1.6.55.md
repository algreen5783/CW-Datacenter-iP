# CW Datacenter iOS 1.6.55

- Sửa lỗi build do hàm `performCameraRequest` bị đặt trong khối mã không biên dịch.
- Đồng bộ lại toàn bộ kiểm tra phiên bản và số build của workflow IPA.
- Tách menu sắp xếp Tổng quan thành Ngày, Tên, Dung lượng và Thư mục; popup thư mục hỗ trợ cuộn.
- Thêm Thông tin trong trình xem ảnh, gồm kích thước, dung lượng, ngày chụp và tọa độ GPS khi ảnh có dữ liệu.
- Thêm hành động Thông tin khi chọn một ảnh hoặc video trong Tổng quan.
