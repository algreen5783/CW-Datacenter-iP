# CW Datacenter iOS 1.6.54

- Gộp sắp xếp Ngày, Tên và Dung lượng; chọn lại cùng tiêu chí để đảo chiều.
- Thêm lọc ảnh/video theo thư mục đồng bộ ngay trong bảng sắp xếp.
- Sửa dải ảnh liền kề trong trình xem ảnh bằng cache, tải trước và tự thử lại khi thumbnail lỗi.
- Đồng bộ tệp gốc với tên và mốc thời gian nguồn; nhận diện tệp `_cw` cũ để không tải lại.
