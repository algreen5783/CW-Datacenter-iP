# CW Datacenter iOS 1.6.52

- Tổng quan có nút chọn thư viện ảnh/video của từng thiết bị đã đồng bộ.
- Mặc định vẫn mở thư viện của chính iPhone/iPad hiện tại.
- Việc đổi thư viện chỉ ảnh hưởng nội dung đang xem, không đổi đích đồng bộ.
- Chỉ liệt kê thư mục máy có cấu trúc `Images/Images_00x` hoặc `Videos/Videos_00x` và loại nội dung đang khóa.
- Chỉ mục và thumbnail cache được tách theo Host, tài khoản, ổ lưu và thiết bị được chọn.
