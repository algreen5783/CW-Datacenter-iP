# CW Datacenter iOS 1.6.53

- Giữ một giây để chọn ảnh/video trong tab Tổng quan.
- Mỗi mục đã chọn dùng dấu tích tròn kiểu Apple Photos, không phủ màu hoặc viền toàn thumbnail.
- Thanh số lượng và nút thao tác được đặt trong header, không che thumbnail hay thanh tab dưới.
- Nút lên đầu trang ở tab Tệp tự ẩn sau hai giây không thao tác và hiện lại khi cuộn.
