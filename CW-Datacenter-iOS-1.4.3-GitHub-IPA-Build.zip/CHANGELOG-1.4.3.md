# CW Datacenter iOS 1.4.3

Chỉ thay đổi source iOS. Không sửa Android Mobile, Tablet, TV, Windows Client hoặc Host.

## Giao diện

- Khóa kích thước mọi SVG/control quan trọng để nút nguồn không thể phóng lớn và làm chồng màn hình.
- Cưỡng chế mỗi thời điểm chỉ có một `.view.active` hiển thị.
- Dùng chiều cao WebView ổn định thay vì phụ thuộc hoàn toàn vào `100dvh` trên Safari/WKWebView.
- Đồng bộ marker giao diện/native `1.4.3`; app tự xóa cache và nạp lại một lần nếu phát hiện HTML/JavaScript lệch phiên bản.
- Workflow từ chối đóng gói nếu app bundle thiếu hoặc chứa sai `Web/index.html`/`Web/app.js`.

## Đồng bộ Camera iOS

- Dùng quyền Photos `.readWrite` hiện hành của iOS 14+.
- Sửa cầu nối JavaScript–Swift để truyền object trực tiếp, không bọc JSON hai lần.
- Sửa callback lỗi để trả trường `err` thật; UI hiện đúng lỗi Host/HTTP thay vì chỉ báo `Lỗi`.
- Bật và lưu đúng tùy chọn tự động sao lưu; tự kiểm tra ngay sau khi đăng nhập thay vì chờ vòng quét đầu tiên.
- Luồng tự động dùng Photos framework của iOS, không còn gọi đường dẫn Android `DCIM/Camera`.
- Bỏ retry lồng nhau. Mỗi bước init/chunk/complete vẫn retry và resume tối đa 3 lần, nhưng không thử lại toàn bộ tệp thêm 3 vòng.
- Khi một tệp upload thất bại, hàng đợi dừng tại tệp đó và giữ tệp ở trạng thái chưa đồng bộ; lần chạy sau sẽ thử lại đúng tệp thay vì bỏ qua để chuyển sang tệp khác.
- Làm sạch tên tệp Photos trước khi tạo đường dẫn/tệp tạm.
- Không đưa token đăng nhập vào query string của API quét file; chỉ dùng Authorization header.
- Mã hóa progress callback bằng JSON chuẩn để tên tệp có dấu nháy/ký tự đặc biệt không phá JavaScript.

## Build

- Phiên bản: `1.4.3`; build: `10403`.
- Có GitHub Actions tạo IPA unsigned và kiểm tra tài nguyên UI ngay trong `.app` trước khi đóng gói.
