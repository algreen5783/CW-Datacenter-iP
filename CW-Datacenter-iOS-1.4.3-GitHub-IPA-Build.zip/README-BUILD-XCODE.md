# Build CW Datacenter iOS 1.4.3 bằng GitHub Actions hoặc Xcode

## Cách dành cho máy Windows (tạo IPA trên GitHub)

1. Đưa **toàn bộ nội dung thư mục này** lên một repository GitHub, gồm cả thư mục ẩn `.github`.
2. Mở tab **Actions** > **Build CW Datacenter iOS 1.4.3 IPA** > **Run workflow**.
3. Khi job hoàn tất, tải artifact `CW-Datacenter-iOS-1.4.3-unsigned`.
4. Artifact chứa `CW-Datacenter-iOS-1.4.3-unsigned.ipa` và file SHA-256.

IPA tạo bởi workflow là bản **unsigned**. Hãy ký/sideload theo phương thức bạn đang dùng. Khi cài để kiểm tra UI, nên gỡ bản iOS cũ trước để loại bỏ tài nguyên WebView còn lưu từ bản cũ.

## Cách build trực tiếp bằng Xcode

1. Mở `CWDatacenter.xcodeproj` bằng Xcode 15 trở lên.
2. Chọn target **CWDatacenter** > **Signing & Capabilities** và chọn Apple Development Team.
3. Product > Clean Build Folder, sau đó Archive hoặc chạy trực tiếp trên iPhone.

## Kiểm tra bắt buộc sau build

- Phiên bản app: `1.4.3` (build `10403`).
- Trong app bundle phải có `Web/index.html` và `Web/app.js`, đều mang marker `1.4.3`.
- Cấp quyền **Tất cả ảnh** hoặc chọn các ảnh cần sao lưu. Nếu chỉ cấp quyền giới hạn, app chỉ quét các ảnh đã được iOS cho phép.
- Tài khoản Host phải có quyền `editor` hoặc `admin` trên ổ được chọn.
