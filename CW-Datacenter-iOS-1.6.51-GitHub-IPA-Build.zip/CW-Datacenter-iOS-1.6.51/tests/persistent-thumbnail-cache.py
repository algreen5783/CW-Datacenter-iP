from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
proxy = (ROOT / "CWDatacenter/Network/LocalProxy.swift").read_text(encoding="utf-8")
main = (ROOT / "CWDatacenter/ViewControllers/MainViewController.swift").read_text(encoding="utf-8")
assert "maximumThumbnailCacheBytes: Int64 = 500 * 1024 * 1024" in proxy
assert ".applicationSupportDirectory" in proxy
assert "trimThumbnailCache()" in proxy
clear = main[main.index('case "clearCache":'):main.index('case "exitApp":')]
assert "clearThumbnailCache" not in clear
print("PASS iOS persistent 500 MB thumbnail cache survives normal cache clearing")
