# CW Datacenter iOS 1.6.49 (10649)

- Thiết kế lại trình xem ảnh và video theo kiểu Apple Photos trên nền đen.
- Chế độ thu gọn hiển thị ảnh/video ở giữa, dải thumbnail ngang và bốn nút Yêu thích, Tải về, Chia sẻ, Xóa.
- Chạm một lần vào vùng ảnh/video để chuyển qua lại giữa chế độ thu gọn và toàn màn hình.
- Chạm thumbnail để chuyển trực tiếp tới ảnh/video tương ứng; mục hiện tại có viền chọn.
- Hiển thị ngày, giờ, tên tệp và vị trí hiện tại khi metadata sẵn có.
- Thumbnail video trong trình phát dùng kích thước 160 px và được tải trước quanh mục đang xem.
- Giữ nguyên điều khiển phát/tạm dừng/phát lại, thanh tiến trình và thao tác vuốt ngang đổi video.
- Bổ sung popover chia sẻ an toàn cho iPad và danh sách dự phòng khi mở một video đơn lẻ.
