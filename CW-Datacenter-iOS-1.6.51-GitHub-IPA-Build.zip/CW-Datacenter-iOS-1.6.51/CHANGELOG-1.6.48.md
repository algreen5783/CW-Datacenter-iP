# CW Datacenter iOS 1.6.48 (10648)

- Matches photo paging more closely by prefetching the previous and next video thumbnails before the drag starts.
- Keeps the adjacent video preview visible after release until AVPlayerLayer reports that the first frame of the new video is ready, removing the black flash seen in the supplied comparison recording.
- Keeps the gesture direction fixed for one drag and does not create a second AVPlayer, preserving the crash fix from 1.6.47.
