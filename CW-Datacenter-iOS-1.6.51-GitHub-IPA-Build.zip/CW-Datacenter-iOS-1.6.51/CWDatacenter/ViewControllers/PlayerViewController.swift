import UIKit
import AVFoundation

class PlayerViewController: UIViewController, UIGestureRecognizerDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    private var videoUrl: String
    private var videoName: String
    private var playlist: [[String: Any]]
    private var explicitStartPos: Int64
    private var subtitleCandidates: [[String: String]]
    private var watchBaseUrl: String
    private var watchToken: String
    private var videoRel: String
    private var videoPool: String
    private var videoSize: Int64
    private var currentPlaylistIndex = 0
    private var lastWatchProgressSentAt = Date.distantPast

    var onFavorite: (([String: Any], @escaping (Bool) -> Void) -> Void)?
    var onDownload: (([String: Any], @escaping (Bool, String?) -> Void) -> Void)?
    var onPrepareShare: (([String: Any], @escaping (URL?, String?) -> Void) -> Void)?
    var onDelete: (([String: Any], @escaping (Bool, String?) -> Void) -> Void)?

    private var player: AVPlayer?
    private var playerLayer: AVPlayerLayer?
    private var timeObserverToken: Any?

    private var isPlaying = false
    private var hasReachedEnd = false
    private var controlsVisible = true
    private var isFavorite = false
    private var actionInProgress = false
    private var wasDeleted = false

    // UI Elements
    private let topBar = UIView()
    private let titleLabel = UILabel()
    private let metaLabel = UILabel()
    private let closeBtn = UIButton(type: .system)
    private let mediaContainer = UIView()
    private var filmstrip: UICollectionView!
    private let toolBar = UIVisualEffectView(effect: UIBlurEffect(style: .systemThinMaterialDark))
    private let downloadBtn = UIButton(type: .system)
    private let favoriteBtn = UIButton(type: .system)
    private let shareBtn = UIButton(type: .system)
    private let deleteBtn = UIButton(type: .system)

    private let playPauseBtn = UIButton(type: .custom)

    private let bottomBar = UIView()
    private let currentTimeLabel = UILabel()
    private let durationLabel = UILabel()
    private let seekSlider = UISlider()
    private let muteBtn = UIButton(type: .system)

    private let toastLabel = UILabel()
    private let subtitleLabel = UILabel()
    private var subtitleCues: [(start: Double, end: Double, text: String)] = []
    private var subtitleOffset: Double = 0
    private var subtitleTextSize: CGFloat = 22
    private var subtitleName = ""

    private var hideTimer: Timer?
    private var isSeeking = false
    private var pagePreviewView: UIView?
    private var pagePreviewImageTask: URLSessionDataTask?
    private var pagePreviewIndex: Int?
    private var pageGestureOffset: Int?
    private let pageThumbnailCache = NSCache<NSString, UIImage>()
    private var pageReadyObservation: NSKeyValueObservation?
    private var pageReadyFallback: DispatchWorkItem?
    private var pageReadySawNotReady = false
    private var pageTransitionRunning = false
    private let pageGap: CGFloat = 12
    private var compactMediaConstraints: [NSLayoutConstraint] = []
    private var fullMediaConstraints: [NSLayoutConstraint] = []

    init(url: String, name: String?, playlist: [[String: Any]], startPos: Int64,
         subtitleCandidates: [[String: String]] = [], baseUrl: String = "", token: String = "",
         rel: String = "", pool: String = "", size: Int64 = 0, favorite: Bool = false) {
        let resolvedName = name ?? "Đang phát video"
        let resolvedPool = pool.isEmpty ? "main" : pool
        let effectivePlaylist: [[String: Any]] = playlist.isEmpty ? [[
            "name": resolvedName,
            "url": url,
            "rel": rel,
            "pool": resolvedPool,
            "size": size,
            "favorite": favorite
        ]] : playlist
        self.videoUrl = url
        self.videoName = resolvedName
        self.playlist = effectivePlaylist
        self.explicitStartPos = startPos
        self.subtitleCandidates = subtitleCandidates
        self.watchBaseUrl = baseUrl.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        self.watchToken = token
        self.videoRel = rel
        self.videoPool = resolvedPool
        self.videoSize = size
        self.isFavorite = favorite
        if let matched = effectivePlaylist.firstIndex(where: { item in
            let itemRel = item["rel"] as? String ?? ""
            let itemPool = (item["pool"] as? String).flatMap { $0.isEmpty ? nil : $0 } ?? "main"
            let requestedPool = resolvedPool
            if !rel.isEmpty { return itemRel == rel && itemPool == requestedPool }
            return (item["url"] as? String ?? "") == url
        }) {
            self.currentPlaylistIndex = matched
        }
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override var prefersStatusBarHidden: Bool {
        return !controlsVisible
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .allButUpsideDown
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        setupUI()
        setupPlayer()
        setupGestures()
        autoLoadMatchingSubtitle()
        prefetchAdjacentPageThumbnails()

        showControls()
        syncFilmstrip(animated: false)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        playerLayer?.frame = mediaContainer.bounds
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if !wasDeleted { saveCurrentPosition() }
        cleanupPlayer()
        cleanupPagePreview()
    }

    // MARK: - Player Setup
    private func setupPlayer() {
        guard let url = URL(string: videoUrl) else { return }
        let asset = AVURLAsset(url: url)
        let playerItem = AVPlayerItem(asset: asset)
        playerItem.preferredForwardBufferDuration = 2

        player = AVPlayer(playerItem: playerItem)
        player?.automaticallyWaitsToMinimizeStalling = false
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(playerItemDidReachEnd(_:)),
            name: .AVPlayerItemDidPlayToEndTime,
            object: nil
        )
        playerLayer = AVPlayerLayer(player: player)
        playerLayer?.videoGravity = .resizeAspect
        playerLayer?.frame = view.bounds
        if let layer = playerLayer {
            mediaContainer.layer.addSublayer(layer)
        }

        // Time observer
        let interval = CMTime(seconds: 0.5, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        timeObserverToken = player?.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            self?.onTimeUpdate(time: time)
        }

        // Resume position
        let posKey = "vpos_" + (videoName.isEmpty ? String(videoUrl.hashValue) : videoName)
        if explicitStartPos == 0 {
            UserDefaults.standard.removeObject(forKey: posKey)
            showToast("Phát lại từ đầu")
        } else if explicitStartPos > 0 {
            let targetTime = CMTime(seconds: Double(explicitStartPos) / 1000.0, preferredTimescale: 600)
            player?.seek(to: targetTime, toleranceBefore: .zero, toleranceAfter: .zero)
            showToast("Đang phát tiếp từ \(formatTime(seconds: Double(explicitStartPos) / 1000.0))")
        } else {
            let savedPos = UserDefaults.standard.integer(forKey: posKey)
            if savedPos > 5000 {
                let targetTime = CMTime(seconds: Double(savedPos) / 1000.0, preferredTimescale: 600)
                player?.seek(to: targetTime, toleranceBefore: .zero, toleranceAfter: .zero)
                showToast("Đang phát tiếp từ \(formatTime(seconds: Double(savedPos) / 1000.0))")
            }
            fetchRemoteWatchProgress()
        }

        player?.play()
        isPlaying = true
        updatePlayPauseButton()
    }

    private func cleanupPlayer() {
        if let token = timeObserverToken {
            player?.removeTimeObserver(token)
            timeObserverToken = nil
        }
        player?.pause()
        NotificationCenter.default.removeObserver(self, name: .AVPlayerItemDidPlayToEndTime, object: nil)
        player = nil
        playerLayer?.removeFromSuperlayer()
    }

    private func saveCurrentPosition() {
        guard let p = player else { return }
        let sec = CMTimeGetSeconds(p.currentTime())
        if sec > 3 && !sec.isNaN && !sec.isInfinite {
            let posKey = "vpos_" + (videoName.isEmpty ? String(videoUrl.hashValue) : videoName)
            let durationSec = p.currentItem.map { CMTimeGetSeconds($0.duration) } ?? 0
            let completed = durationSec.isFinite && durationSec > 0 && (sec >= durationSec - 5 || sec * 100 >= durationSec * 95)
            if completed { UserDefaults.standard.removeObject(forKey: posKey) }
            else { UserDefaults.standard.set(Int(sec * 1000), forKey: posKey) }
            sendRemoteWatchProgress(positionMs: Int64(sec * 1000),
                                    durationMs: durationSec.isFinite && durationSec > 0 ? Int64(durationSec * 1000) : 0,
                                    completed: completed)
        }
    }

    private func watchProgressURL(query: Bool) -> URL? {
        guard !watchBaseUrl.isEmpty, !watchToken.isEmpty, !videoRel.isEmpty else { return nil }
        guard var components = URLComponents(string: watchBaseUrl + "/api/watch-progress") else { return nil }
        if query {
            components.queryItems = [
                URLQueryItem(name: "pool", value: videoPool.isEmpty ? "main" : videoPool),
                URLQueryItem(name: "path", value: videoRel)
            ]
        }
        return components.url
    }

    private func authorizedRequest(url: URL, method: String) -> URLRequest {
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.timeoutInterval = 10
        request.setValue("Bearer \(watchToken)", forHTTPHeaderField: "Authorization")
        return request
    }

    private func fetchRemoteWatchProgress() {
        guard let url = watchProgressURL(query: true) else { return }
        let requestedRel = videoRel
        URLSession.shared.dataTask(with: authorizedRequest(url: url, method: "GET")) { [weak self] data, response, _ in
            guard let self, let http = response as? HTTPURLResponse, http.statusCode == 200,
                  let data,
                  let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let item = root["item"] as? [String: Any] else { return }
            let remotePos = (item["positionMs"] as? NSNumber)?.int64Value ?? 0
            DispatchQueue.main.async {
                guard self.videoRel == requestedRel, self.explicitStartPos < 0,
                      let player = self.player else { return }
                let current = CMTimeGetSeconds(player.currentTime()) * 1000
                if remotePos > 3000 && current < 5000 && abs(Double(remotePos) - current) > 3000 {
                    player.seek(to: CMTime(seconds: Double(remotePos) / 1000, preferredTimescale: 600),
                                toleranceBefore: .zero, toleranceAfter: .zero)
                    self.showToast("Đồng bộ xem tiếp từ \(self.formatTime(seconds: Double(remotePos) / 1000))")
                }
            }
        }.resume()
    }

    private func watchDeviceId() -> String {
        let key = "cw_watch_device_id"
        if let value = UserDefaults.standard.string(forKey: key), !value.isEmpty { return value }
        let value = UUID().uuidString
        UserDefaults.standard.set(value, forKey: key)
        return value
    }

    private func sendRemoteWatchProgress(positionMs: Int64, durationMs: Int64, completed: Bool) {
        guard let url = watchProgressURL(query: false) else { return }
        let payload: [String: Any] = [
            "pool": videoPool.isEmpty ? "main" : videoPool,
            "size": videoSize,
            "path": videoRel,
            "name": videoName,
            "positionMs": max(0, positionMs),
            "durationMs": max(0, durationMs),
            "completed": completed,
            "deviceId": watchDeviceId(),
            "deviceName": UIDevice.current.name
        ]
        guard let body = try? JSONSerialization.data(withJSONObject: payload) else { return }
        var request = authorizedRequest(url: url, method: "PUT")
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.httpBody = body
        URLSession.shared.dataTask(with: request).resume()
        lastWatchProgressSentAt = Date()
    }

    // MARK: - UI Setup
    private func setupUI() {
        setupMediaContainer()
        setupTopBar()
        setupCenterControls()
        setupToolBar()
        setupFilmstrip()
        setupBottomBar()
        setupMediaLayout()
        setupSubtitleOverlay()
        setupToast()
    }

    private func setupMediaContainer() {
        mediaContainer.backgroundColor = .black
        mediaContainer.clipsToBounds = true
        mediaContainer.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(mediaContainer)
    }

    private func setupTopBar() {
        topBar.backgroundColor = .black
        topBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(topBar)

        closeBtn.setImage(UIImage(systemName: "xmark"), for: .normal)
        closeBtn.tintColor = .systemBlue
        closeBtn.backgroundColor = UIColor.white.withAlphaComponent(0.10)
        closeBtn.layer.cornerRadius = 18
        closeBtn.addTarget(self, action: #selector(onCloseTapped), for: .touchUpInside)
        closeBtn.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(closeBtn)

        titleLabel.text = videoName
        titleLabel.textColor = .white
        titleLabel.font = UIFont.systemFont(ofSize: 22, weight: .bold)
        titleLabel.lineBreakMode = .byTruncatingMiddle
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(titleLabel)

        metaLabel.textColor = UIColor.white.withAlphaComponent(0.65)
        metaLabel.font = UIFont.systemFont(ofSize: 13, weight: .regular)
        metaLabel.lineBreakMode = .byTruncatingMiddle
        metaLabel.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(metaLabel)

        NSLayoutConstraint.activate([
            topBar.topAnchor.constraint(equalTo: view.topAnchor),
            topBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            topBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            topBar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 82),

            closeBtn.trailingAnchor.constraint(equalTo: topBar.trailingAnchor, constant: -14),
            closeBtn.bottomAnchor.constraint(equalTo: topBar.bottomAnchor, constant: -8),
            closeBtn.widthAnchor.constraint(equalToConstant: 36),
            closeBtn.heightAnchor.constraint(equalToConstant: 36),

            titleLabel.leadingAnchor.constraint(equalTo: topBar.leadingAnchor, constant: 24),
            titleLabel.topAnchor.constraint(equalTo: closeBtn.topAnchor, constant: -2),
            titleLabel.trailingAnchor.constraint(lessThanOrEqualTo: closeBtn.leadingAnchor, constant: -14),

            metaLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            metaLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 3),
            metaLabel.trailingAnchor.constraint(lessThanOrEqualTo: closeBtn.leadingAnchor, constant: -14)
        ])
        updateHeaderInfo()
    }

    private func setupSubtitleOverlay() {
        subtitleLabel.textColor = .white
        subtitleLabel.font = UIFont.systemFont(ofSize: subtitleTextSize, weight: .semibold)
        subtitleLabel.textAlignment = .center
        subtitleLabel.numberOfLines = 4
        subtitleLabel.backgroundColor = UIColor.black.withAlphaComponent(0.58)
        subtitleLabel.layer.cornerRadius = 6
        subtitleLabel.layer.masksToBounds = true
        subtitleLabel.isHidden = true
        subtitleLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(subtitleLabel)
        NSLayoutConstraint.activate([
            subtitleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            subtitleLabel.leadingAnchor.constraint(greaterThanOrEqualTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 24),
            subtitleLabel.trailingAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -24),
            subtitleLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -150)
        ])
    }

    private func setupCenterControls() {
        playPauseBtn.setImage(UIImage(systemName: "pause.fill"), for: .normal)
        playPauseBtn.tintColor = .white
        playPauseBtn.setPreferredSymbolConfiguration(UIImage.SymbolConfiguration(pointSize: 30, weight: .bold), forImageIn: .normal)
        playPauseBtn.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        playPauseBtn.layer.cornerRadius = 42
        playPauseBtn.layer.borderWidth = 1
        playPauseBtn.layer.borderColor = UIColor.white.withAlphaComponent(0.25).cgColor
        playPauseBtn.addTarget(self, action: #selector(onPlayPauseTapped), for: .touchUpInside)
        playPauseBtn.isUserInteractionEnabled = true
        playPauseBtn.isExclusiveTouch = true
        playPauseBtn.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(playPauseBtn)

        NSLayoutConstraint.activate([
            playPauseBtn.centerXAnchor.constraint(equalTo: mediaContainer.centerXAnchor),
            playPauseBtn.centerYAnchor.constraint(equalTo: mediaContainer.centerYAnchor),
            playPauseBtn.widthAnchor.constraint(equalToConstant: 84),
            playPauseBtn.heightAnchor.constraint(equalToConstant: 84)
        ])
    }

    private func setupBottomBar() {
        bottomBar.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        bottomBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bottomBar)

        currentTimeLabel.text = "00:00"
        currentTimeLabel.textColor = .white
        currentTimeLabel.font = UIFont.monospacedDigitSystemFont(ofSize: 13, weight: .regular)
        currentTimeLabel.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.addSubview(currentTimeLabel)

        durationLabel.text = "--:--"
        durationLabel.textColor = UIColor.white.withAlphaComponent(0.7)
        durationLabel.font = UIFont.monospacedDigitSystemFont(ofSize: 13, weight: .regular)
        durationLabel.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.addSubview(durationLabel)

        seekSlider.minimumTrackTintColor = UIColor(red: 1.0, green: 0.22, blue: 0.36, alpha: 1.0)
        seekSlider.maximumTrackTintColor = UIColor.white.withAlphaComponent(0.25)
        seekSlider.addTarget(self, action: #selector(onSliderChanged), for: .valueChanged)
        seekSlider.addTarget(self, action: #selector(onSliderTouchDown), for: .touchDown)
        seekSlider.addTarget(self, action: #selector(onSliderTouchUp), for: [.touchUpInside, .touchUpOutside, .touchCancel])
        seekSlider.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.addSubview(seekSlider)

        muteBtn.setImage(UIImage(systemName: "speaker.wave.2.fill"), for: .normal)
        muteBtn.tintColor = .white
        muteBtn.addTarget(self, action: #selector(onMuteTapped), for: .touchUpInside)
        muteBtn.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.addSubview(muteBtn)

        NSLayoutConstraint.activate([
            bottomBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bottomBar.heightAnchor.constraint(equalToConstant: 48),

            currentTimeLabel.leadingAnchor.constraint(equalTo: bottomBar.leadingAnchor, constant: 16),
            currentTimeLabel.topAnchor.constraint(equalTo: bottomBar.topAnchor, constant: 14),

            seekSlider.leadingAnchor.constraint(equalTo: currentTimeLabel.trailingAnchor, constant: 10),
            seekSlider.trailingAnchor.constraint(equalTo: durationLabel.leadingAnchor, constant: -10),
            seekSlider.centerYAnchor.constraint(equalTo: currentTimeLabel.centerYAnchor),

            durationLabel.trailingAnchor.constraint(equalTo: muteBtn.leadingAnchor, constant: -14),
            durationLabel.centerYAnchor.constraint(equalTo: currentTimeLabel.centerYAnchor),

            muteBtn.trailingAnchor.constraint(equalTo: bottomBar.trailingAnchor, constant: -16),
            muteBtn.centerYAnchor.constraint(equalTo: currentTimeLabel.centerYAnchor),
            muteBtn.widthAnchor.constraint(equalToConstant: 32)
        ])
    }

    private func setupToolBar() {
        toolBar.layer.cornerRadius = 18
        toolBar.clipsToBounds = true
        toolBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(toolBar)

        configureToolButton(downloadBtn, title: "Tải về", symbol: "arrow.down.to.line", action: #selector(onDownloadTapped))
        configureToolButton(favoriteBtn, title: "Yêu thích", symbol: isFavorite ? "heart.fill" : "heart", action: #selector(onFavoriteTapped))
        configureToolButton(shareBtn, title: "Chia sẻ", symbol: "square.and.arrow.up", action: #selector(onShareTapped))
        configureToolButton(deleteBtn, title: "Xóa", symbol: "trash", action: #selector(onDeleteTapped))
        setToolButtonColor(deleteBtn, .systemRed)

        let stack = UIStackView(arrangedSubviews: [favoriteBtn, downloadBtn, shareBtn, deleteBtn])
        stack.axis = .horizontal
        stack.distribution = .fillEqually
        stack.translatesAutoresizingMaskIntoConstraints = false
        toolBar.contentView.addSubview(stack)

        NSLayoutConstraint.activate([
            toolBar.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 12),
            toolBar.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -12),
            toolBar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -10),
            toolBar.heightAnchor.constraint(equalToConstant: 68),
            stack.leadingAnchor.constraint(equalTo: toolBar.contentView.leadingAnchor, constant: 4),
            stack.trailingAnchor.constraint(equalTo: toolBar.contentView.trailingAnchor, constant: -4),
            stack.topAnchor.constraint(equalTo: toolBar.contentView.topAnchor, constant: 4),
            stack.bottomAnchor.constraint(equalTo: toolBar.contentView.bottomAnchor, constant: -4)
        ])
    }

    private func setupFilmstrip() {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 5
        layout.minimumInteritemSpacing = 5
        layout.sectionInset = UIEdgeInsets(top: 2, left: 14, bottom: 2, right: 14)
        filmstrip = UICollectionView(frame: .zero, collectionViewLayout: layout)
        filmstrip.backgroundColor = .clear
        filmstrip.showsHorizontalScrollIndicator = false
        filmstrip.alwaysBounceHorizontal = true
        filmstrip.dataSource = self
        filmstrip.delegate = self
        filmstrip.register(VideoFilmstripCell.self, forCellWithReuseIdentifier: VideoFilmstripCell.reuseIdentifier)
        filmstrip.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(filmstrip)
        NSLayoutConstraint.activate([
            filmstrip.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            filmstrip.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            filmstrip.bottomAnchor.constraint(equalTo: toolBar.topAnchor, constant: -8),
            filmstrip.heightAnchor.constraint(equalToConstant: 54)
        ])
    }

    private func setupMediaLayout() {
        NSLayoutConstraint.activate([
            bottomBar.bottomAnchor.constraint(equalTo: filmstrip.topAnchor, constant: -6)
        ])
        compactMediaConstraints = [
            mediaContainer.topAnchor.constraint(equalTo: topBar.bottomAnchor, constant: 8),
            mediaContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 12),
            mediaContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -12),
            mediaContainer.bottomAnchor.constraint(equalTo: bottomBar.topAnchor, constant: -6)
        ]
        fullMediaConstraints = [
            mediaContainer.topAnchor.constraint(equalTo: view.topAnchor),
            mediaContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            mediaContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            mediaContainer.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ]
        NSLayoutConstraint.activate(compactMediaConstraints)
    }

    private func configureToolButton(_ button: UIButton, title: String, symbol: String, action: Selector) {
        button.tintColor = .white
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 9.5, weight: .medium)
        button.titleLabel?.numberOfLines = 1
        button.titleLabel?.lineBreakMode = .byTruncatingTail
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        button.titleLabel?.minimumScaleFactor = 0.78
        if #available(iOS 15.0, *) {
            var config = UIButton.Configuration.plain()
            config.image = UIImage(systemName: symbol)
            config.title = title
            config.imagePlacement = .top
            config.imagePadding = 4
            config.titleLineBreakMode = .byTruncatingTail
            config.baseForegroundColor = .white
            button.configuration = config
        } else {
            button.setImage(UIImage(systemName: symbol), for: .normal)
            button.setTitle(title, for: .normal)
        }
        button.addTarget(self, action: action, for: .touchUpInside)
    }

    private func updateToolTitle(_ button: UIButton, _ title: String) {
        if #available(iOS 15.0, *) {
            var config = button.configuration
            config?.title = title
            button.configuration = config
        } else {
            button.setTitle(title, for: .normal)
        }
    }

    private func setToolButtonColor(_ button: UIButton, _ color: UIColor) {
        button.tintColor = color
        button.setTitleColor(color, for: .normal)
        if #available(iOS 15.0, *) {
            var config = button.configuration
            config?.baseForegroundColor = color
            button.configuration = config
        }
    }

    private func setActionButtonsEnabled(_ enabled: Bool) {
        [downloadBtn, favoriteBtn, shareBtn, deleteBtn].forEach {
            $0.isEnabled = enabled
            $0.alpha = enabled ? 1 : 0.55
        }
    }

    private func updateFavoriteButton() {
        let image = UIImage(systemName: isFavorite ? "heart.fill" : "heart")
        if #available(iOS 15.0, *) {
            var config = favoriteBtn.configuration
            config?.image = image
            favoriteBtn.configuration = config
        } else {
            favoriteBtn.setImage(image, for: .normal)
        }
        setToolButtonColor(favoriteBtn, isFavorite ? .systemPink : .white)
    }

    private func setupToast() {
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        toastLabel.textColor = .white
        toastLabel.font = UIFont.systemFont(ofSize: 13.5, weight: .medium)
        toastLabel.textAlignment = .center
        toastLabel.layer.cornerRadius = 18
        toastLabel.layer.masksToBounds = true
        toastLabel.layer.borderWidth = 1
        toastLabel.layer.borderColor = UIColor.white.withAlphaComponent(0.2).cgColor
        toastLabel.alpha = 0
        toastLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(toastLabel)

        NSLayoutConstraint.activate([
            toastLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            toastLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 60),
            toastLabel.heightAnchor.constraint(equalToConstant: 36),
            toastLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 140)
        ])
    }

    private func setupGestures() {
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(onSurfaceTapped))
        singleTap.numberOfTapsRequired = 1
        singleTap.cancelsTouchesInView = false
        singleTap.delegate = self
        view.addGestureRecognizer(singleTap)

        let pagePan = UIPanGestureRecognizer(target: self, action: #selector(onPagePan(_:)))
        pagePan.maximumNumberOfTouches = 1
        pagePan.cancelsTouchesInView = false
        pagePan.delegate = self
        view.addGestureRecognizer(pagePan)
    }

    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        if let touchedView = touch.view, touchedView.isDescendant(of: playPauseBtn) {
            return false
        }
        var node: UIView? = touch.view
        while let current = node {
            if current is UIControl || current === topBar || current === bottomBar || current === toolBar.contentView || current === filmstrip {
                return false
            }
            node = current.superview
        }
        return true
    }

    func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        guard let pan = gestureRecognizer as? UIPanGestureRecognizer else { return true }
        let velocity = pan.velocity(in: view)
        return abs(velocity.x) > abs(velocity.y)
    }

    @objc private func onPagePan(_ gesture: UIPanGestureRecognizer) {
        guard !actionInProgress, !pageTransitionRunning else { return }
        let translation = gesture.translation(in: view)
        let velocity = gesture.velocity(in: view)
        let width = max(1, mediaContainer.bounds.width)

        switch gesture.state {
        case .began:
            pageGestureOffset = nil
            cleanupPagePreview()
        case .changed:
            guard abs(translation.x) >= abs(translation.y) else { return }
            if pageGestureOffset == nil {
                guard abs(translation.x) >= 8 else { return }
                pageGestureOffset = translation.x < 0 ? 1 : -1
            }
            guard let offset = pageGestureOffset else { return }
            let target = currentPlaylistIndex + offset
            guard playlist.indices.contains(target) else {
                if gesture.state == .changed {
                    let resisted = translation.x * 0.16
                    setPlayerTranslation(resisted)
                }
                return
            }
            if pagePreviewIndex != target { preparePagePreview(index: target, offset: offset) }
            setPlayerTranslation(translation.x)
            if let preview = pagePreviewView {
                let origin = offset > 0 ? width + pageGap : -width - pageGap
                preview.frame.origin.x = origin + translation.x
            }
        case .ended:
            pageGestureOffset = nil
            guard let target = pagePreviewIndex else {
                animatePageCancellation()
                showToast(translation.x < 0 ? "Đã đến video cuối" : "Đã đến video đầu")
                return
            }
            let progress = min(1, abs(translation.x) / width)
            let completes = progress >= 0.25 || abs(velocity.x) >= 650
            if completes { animatePageCompletion(target: target) }
            else { animatePageCancellation() }
        case .cancelled, .failed:
            pageGestureOffset = nil
            animatePageCancellation()
        default:
            break
        }
    }

    private func preparePagePreview(index: Int, offset: Int) {
        cleanupPagePreview()
        guard playlist.indices.contains(index) else { return }
        let width = mediaContainer.bounds.width
        let preview = UIView(frame: CGRect(x: offset > 0 ? width + pageGap : -width - pageGap,
                                           y: 0, width: width, height: mediaContainer.bounds.height))
        preview.backgroundColor = .black
        preview.isUserInteractionEnabled = false

        let imageView = UIImageView(frame: preview.bounds)
        imageView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .black
        preview.addSubview(imageView)

        let placeholder = UIImageView(image: UIImage(systemName: "play.rectangle.fill"))
        placeholder.tintColor = UIColor.white.withAlphaComponent(0.48)
        placeholder.contentMode = .scaleAspectFit
        placeholder.frame = CGRect(x: (width - 74) / 2, y: (mediaContainer.bounds.height - 58) / 2, width: 74, height: 58)
        placeholder.autoresizingMask = [.flexibleLeftMargin, .flexibleRightMargin, .flexibleTopMargin, .flexibleBottomMargin]
        preview.addSubview(placeholder)

        mediaContainer.insertSubview(preview, at: 0)
        pagePreviewView = preview
        pagePreviewIndex = index

        guard let request = pagePreviewThumbnailRequest(for: playlist[index]),
              let requestURL = request.url else { return }
        let cacheKey = requestURL.absoluteString as NSString
        if let cached = pageThumbnailCache.object(forKey: cacheKey) {
            imageView.image = cached
            placeholder.isHidden = true
            return
        }
        let task = URLSession.shared.dataTask(with: request) { [weak self, weak preview, weak imageView, weak placeholder] data, _, _ in
            guard let data, let image = UIImage(data: data) else { return }
            DispatchQueue.main.async {
                guard let self,
                      self.pagePreviewIndex == index,
                      self.pagePreviewView === preview else { return }
                self.pageThumbnailCache.setObject(image, forKey: cacheKey)
                imageView?.image = image
                placeholder?.isHidden = true
            }
        }
        pagePreviewImageTask = task
        task.resume()
    }

    private func pagePreviewThumbnailRequest(for item: [String: Any]) -> URLRequest? {
        guard let url = pagePreviewThumbnailURL(for: item) else { return nil }
        var request = URLRequest(url: url)
        request.cachePolicy = .returnCacheDataElseLoad
        if !watchToken.isEmpty { request.setValue("Bearer \(watchToken)", forHTTPHeaderField: "Authorization") }
        return request
    }

    private func pagePreviewThumbnailURL(for item: [String: Any]) -> URL? {
        if let value = item["thumbUrl"] as? String, !value.isEmpty, let url = URL(string: value) { return url }
        let rel = item["rel"] as? String ?? ""
        guard !watchBaseUrl.isEmpty, !rel.isEmpty,
              var components = URLComponents(string: watchBaseUrl + "/api/thumb") else { return nil }
        components.queryItems = [
            URLQueryItem(name: "path", value: rel),
            URLQueryItem(name: "pool", value: (item["pool"] as? String).flatMap { $0.isEmpty ? nil : $0 } ?? "main"),
            URLQueryItem(name: "size", value: "160")
        ]
        return components.url
    }

    private func prefetchAdjacentPageThumbnails() {
        let lower = max(0, currentPlaylistIndex - 8)
        let upper = min(playlist.count - 1, currentPlaylistIndex + 8)
        guard lower <= upper else { return }
        Array(lower...upper).filter { $0 != currentPlaylistIndex }.forEach { index in
            guard playlist.indices.contains(index),
                  let request = pagePreviewThumbnailRequest(for: playlist[index]),
                  let url = request.url else { return }
            let key = url.absoluteString as NSString
            guard pageThumbnailCache.object(forKey: key) == nil else { return }
            URLSession.shared.dataTask(with: request) { [weak self] data, _, _ in
                guard let data, let image = UIImage(data: data) else { return }
                self?.pageThumbnailCache.setObject(image, forKey: key)
            }.resume()
        }
    }

    // MARK: - Filmstrip
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return playlist.count
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 42, height: 50)
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: VideoFilmstripCell.reuseIdentifier, for: indexPath) as? VideoFilmstripCell else {
            return UICollectionViewCell()
        }
        cell.prepare(index: indexPath.item, selected: indexPath.item == currentPlaylistIndex)
        guard let request = pagePreviewThumbnailRequest(for: playlist[indexPath.item]), let url = request.url else { return cell }
        let key = url.absoluteString as NSString
        if let image = pageThumbnailCache.object(forKey: key) {
            cell.apply(image: image, index: indexPath.item)
            return cell
        }
        URLSession.shared.dataTask(with: request) { [weak self, weak cell] data, _, _ in
            guard let data, let image = UIImage(data: data) else { return }
            self?.pageThumbnailCache.setObject(image, forKey: key)
            DispatchQueue.main.async { cell?.apply(image: image, index: indexPath.item) }
        }.resume()
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard playlist.indices.contains(indexPath.item), indexPath.item != currentPlaylistIndex, !actionInProgress else { return }
        cleanupPagePreview()
        playPlaylistItem(indexPath.item)
    }

    private func syncFilmstrip(animated: Bool) {
        guard filmstrip != nil, playlist.indices.contains(currentPlaylistIndex) else { return }
        filmstrip.reloadData()
        DispatchQueue.main.async { [weak self] in
            guard let self, self.playlist.indices.contains(self.currentPlaylistIndex) else { return }
            self.filmstrip.scrollToItem(at: IndexPath(item: self.currentPlaylistIndex, section: 0), at: .centeredHorizontally, animated: animated)
        }
    }

    private func updateHeaderInfo() {
        guard playlist.indices.contains(currentPlaylistIndex) else {
            titleLabel.text = videoName
            metaLabel.text = ""
            return
        }
        let item = playlist[currentPlaylistIndex]
        if let date = mediaDate(from: item["mtime"]) {
            let dateFormatter = DateFormatter()
            dateFormatter.locale = Locale(identifier: "vi_VN")
            dateFormatter.dateFormat = "'ngày' d 'tháng' M, yyyy"
            let timeFormatter = DateFormatter()
            timeFormatter.locale = Locale(identifier: "vi_VN")
            timeFormatter.dateFormat = "HH:mm"
            titleLabel.text = dateFormatter.string(from: date)
            metaLabel.text = "\(timeFormatter.string(from: date)) · \(videoName) · \(currentPlaylistIndex + 1)/\(playlist.count)"
        } else {
            titleLabel.text = videoName
            metaLabel.text = "\(currentPlaylistIndex + 1) / \(playlist.count)"
        }
    }

    private func mediaDate(from value: Any?) -> Date? {
        if let number = value as? NSNumber {
            let raw = number.doubleValue
            return Date(timeIntervalSince1970: raw > 10_000_000_000 ? raw / 1000 : raw)
        }
        guard let text = value as? String, !text.isEmpty else { return nil }
        if let raw = Double(text) { return Date(timeIntervalSince1970: raw > 10_000_000_000 ? raw / 1000 : raw) }
        let iso = ISO8601DateFormatter()
        if let date = iso.date(from: text) { return date }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        for format in ["yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss.SSSZ", "yyyy-MM-dd'T'HH:mm:ssZ"] {
            formatter.dateFormat = format
            if let date = formatter.date(from: text) { return date }
        }
        return nil
    }

    private func setPlayerTranslation(_ x: CGFloat) {
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        playerLayer?.setAffineTransform(CGAffineTransform(translationX: x, y: 0))
        CATransaction.commit()
    }

    private func animatePageCompletion(target: Int) {
        guard let preview = pagePreviewView else { animatePageCancellation(); return }
        pageTransitionRunning = true
        let movingToNext = target > currentPlaylistIndex
        let width = mediaContainer.bounds.width
        let destination = movingToNext ? -width - pageGap : width + pageGap
        UIView.animate(withDuration: 0.22, delay: 0, options: [.curveEaseOut, .allowUserInteraction]) {
            self.playerLayer?.setAffineTransform(CGAffineTransform(translationX: destination, y: 0))
            preview.frame.origin.x = 0
        } completion: { [weak self] _ in
            guard let self else { return }
            self.playerLayer?.opacity = 0
            self.setPlayerTranslation(0)
            self.playPlaylistItem(target, keepPagePreviewUntilReady: true)
            self.playerLayer?.opacity = 1
        }
    }

    private func waitForNewVideoFrame() {
        pageReadyObservation?.invalidate()
        pageReadyFallback?.cancel()
        guard let layer = playerLayer else {
            finishCommittedPageTransition()
            return
        }
        pageReadySawNotReady = !layer.isReadyForDisplay
        pageReadyObservation = layer.observe(\.isReadyForDisplay, options: [.new]) { [weak self] observedLayer, _ in
            guard let self else { return }
            if !observedLayer.isReadyForDisplay {
                self.pageReadySawNotReady = true
                return
            }
            guard self.pageReadySawNotReady else { return }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.06) { [weak self] in
                self?.finishCommittedPageTransition()
            }
        }
        let fallback = DispatchWorkItem { [weak self] in self?.finishCommittedPageTransition() }
        pageReadyFallback = fallback
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0, execute: fallback)
    }

    private func finishCommittedPageTransition() {
        guard pageTransitionRunning else { return }
        pageReadyObservation?.invalidate()
        pageReadyObservation = nil
        pageReadyFallback?.cancel()
        pageReadyFallback = nil
        UIView.animate(withDuration: 0.12, animations: { [weak self] in
            self?.pagePreviewView?.alpha = 0
        }) { [weak self] _ in
            self?.cleanupPagePreview()
            self?.pageTransitionRunning = false
            self?.scheduleHide()
        }
    }

    private func animatePageCancellation() {
        let target = pagePreviewIndex
        let destination: CGFloat
        if let target { destination = target > currentPlaylistIndex ? mediaContainer.bounds.width + pageGap : -mediaContainer.bounds.width - pageGap }
        else { destination = 0 }
        UIView.animate(withDuration: 0.2, delay: 0, options: [.curveEaseOut, .allowUserInteraction]) {
            self.playerLayer?.setAffineTransform(.identity)
            self.pagePreviewView?.frame.origin.x = destination
        } completion: { [weak self] _ in
            self?.cleanupPagePreview()
            self?.scheduleHide()
        }
    }

    private func cleanupPagePreview() {
        pageReadyObservation?.invalidate()
        pageReadyObservation = nil
        pageReadyFallback?.cancel()
        pageReadyFallback = nil
        pagePreviewImageTask?.cancel()
        pagePreviewView?.removeFromSuperview()
        pagePreviewImageTask = nil
        pagePreviewView = nil
        pagePreviewIndex = nil
    }

    // MARK: - Actions
    @objc private func onSurfaceTapped() {
        controlsVisible ? hideControls() : showControls()
    }

    @objc private func onPlayPauseTapped() {
        guard let p = player else { return }
        if hasReachedEnd {
            hasReachedEnd = false
            isPlaying = true
            updatePlayPauseButton()
            p.seek(to: .zero, toleranceBefore: .zero, toleranceAfter: .zero) { [weak self, weak p] _ in
                DispatchQueue.main.async {
                    p?.play()
                    self?.showToast("Phát lại từ đầu")
                    self?.scheduleHide()
                }
            }
            return
        }
        if isPlaying {
            p.pause()
            isPlaying = false
            showToast("Đã tạm dừng")
        } else {
            p.play()
            isPlaying = true
            showToast("Đang phát")
        }
        updatePlayPauseButton()
        scheduleHide()
    }

    @objc private func onSliderTouchDown() {
        isSeeking = true
        hideTimer?.invalidate()
    }

    @objc private func onSliderChanged() {
        guard let dur = player?.currentItem?.duration else { return }
        let total = CMTimeGetSeconds(dur)
        guard !total.isNaN && total > 0 else { return }
        let current = Double(seekSlider.value) * total
        currentTimeLabel.text = formatTime(seconds: current)
    }

    @objc private func onSliderTouchUp() {
        isSeeking = false
        guard let p = player, let dur = p.currentItem?.duration else { return }
        let total = CMTimeGetSeconds(dur)
        guard !total.isNaN && total > 0 else { return }
        let target = Double(seekSlider.value) * total
        hasReachedEnd = false
        updatePlayPauseButton()
        let cmTarget = CMTime(seconds: target, preferredTimescale: 600)
        p.seek(to: cmTarget, toleranceBefore: .zero, toleranceAfter: .zero)
        scheduleHide()
    }

    private var currentVideoItem: [String: Any] {
        [
            "name": videoName,
            "url": videoUrl,
            "baseUrl": watchBaseUrl,
            "token": watchToken,
            "rel": videoRel,
            "pool": videoPool.isEmpty ? "main" : videoPool,
            "size": videoSize,
            "type": "file",
            "favorite": isFavorite
        ]
    }

    @objc private func onDownloadTapped() {
        guard !actionInProgress else { return }
        guard let action = onDownload else { showToast("Không thể tải video này"); return }
        actionInProgress = true
        setActionButtonsEnabled(false)
        updateToolTitle(downloadBtn, "Đang tải…")
        showToast("Đang tải video về máy…")
        action(currentVideoItem) { [weak self] ok, message in
            DispatchQueue.main.async {
                guard let self else { return }
                self.actionInProgress = false
                self.setActionButtonsEnabled(true)
                self.updateToolTitle(self.downloadBtn, "Tải về")
                self.showToast(message ?? (ok ? "Đã tải video về máy" : "Không tải được video"))
                self.scheduleHide()
            }
        }
    }

    @objc private func onFavoriteTapped() {
        guard !actionInProgress else { return }
        guard let action = onFavorite else { showToast("Không thể cập nhật yêu thích"); return }
        action(currentVideoItem) { [weak self] enabled in
            DispatchQueue.main.async {
                guard let self else { return }
                self.isFavorite = enabled
                self.updateFavoriteButton()
                self.showToast(enabled ? "Đã thêm vào yêu thích" : "Đã bỏ yêu thích")
                self.scheduleHide()
            }
        }
    }

    @objc private func onShareTapped() {
        guard !actionInProgress else { return }
        guard let action = onPrepareShare else { showToast("Không thể chia sẻ video này"); return }
        actionInProgress = true
        setActionButtonsEnabled(false)
        updateToolTitle(shareBtn, "Đang tải…")
        showToast("Đang chuẩn bị video để chia sẻ…")
        action(currentVideoItem) { [weak self] localUrl, message in
            DispatchQueue.main.async {
                guard let self else { return }
                self.actionInProgress = false
                self.setActionButtonsEnabled(true)
                self.updateToolTitle(self.shareBtn, "Chia sẻ")
                guard let localUrl else {
                    self.showToast(message ?? "Không chuẩn bị được video")
                    return
                }
                let controller = UIActivityViewController(activityItems: [localUrl], applicationActivities: nil)
                if let popover = controller.popoverPresentationController {
                    popover.sourceView = self.shareBtn
                    popover.sourceRect = self.shareBtn.bounds
                }
                self.present(controller, animated: true)
            }
        }
    }

    @objc private func onDeleteTapped() {
        guard !actionInProgress else { return }
        guard onDelete != nil else { showToast("Không thể xóa video này"); return }
        let alert = UIAlertController(
            title: "Xóa video?",
            message: "Video \"\(videoName)\" sẽ được chuyển vào Thùng rác của Host.",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "Hủy", style: .cancel))
        alert.addAction(UIAlertAction(title: "Xóa", style: .destructive) { [weak self] _ in
            guard let self, let onDelete = self.onDelete else { return }
            self.actionInProgress = true
            self.setActionButtonsEnabled(false)
            self.showToast("Đang xóa video…")
            onDelete(self.currentVideoItem) { [weak self] ok, message in
                DispatchQueue.main.async {
                    guard let self else { return }
                    self.actionInProgress = false
                    self.setActionButtonsEnabled(true)
                    guard ok else {
                        self.showToast(message ?? "Không xóa được video")
                        return
                    }
                    self.wasDeleted = true
                    self.player?.pause()
                    self.playlist.remove(at: self.currentPlaylistIndex)
                    if self.playlist.isEmpty {
                        self.dismiss(animated: true)
                        return
                    }
                    self.currentPlaylistIndex = min(self.currentPlaylistIndex, self.playlist.count - 1)
                    self.wasDeleted = false
                    self.playPlaylistItem(self.currentPlaylistIndex, savePrevious: false)
                    self.showToast(message ?? "Đã chuyển video vào Thùng rác")
                }
            }
        })
        present(alert, animated: true)
    }

    @objc private func onMuteTapped() {
        guard let p = player else { return }
        p.isMuted = !p.isMuted
        muteBtn.setImage(UIImage(systemName: p.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill"), for: .normal)
        showToast(p.isMuted ? "Đã tắt tiếng" : "Đã bật tiếng")
        scheduleHide()
    }

    private func playPlaylistItem(_ index: Int, keepPagePreviewUntilReady: Bool = false, savePrevious: Bool = true) {
        guard playlist.indices.contains(index), let nextUrl = playlist[index]["url"] as? String, let url = URL(string: nextUrl) else { return }
        let remainCompact = controlsVisible
        if savePrevious { saveCurrentPosition() }
        currentPlaylistIndex = index
        videoUrl = nextUrl
        videoName = playlist[index]["name"] as? String ?? "Đang phát video"
        videoRel = playlist[index]["rel"] as? String ?? ""
        videoPool = (playlist[index]["pool"] as? String).flatMap { $0.isEmpty ? nil : $0 } ?? "main"
        videoSize = (playlist[index]["size"] as? NSNumber)?.int64Value ?? 0
        isFavorite = playlist[index]["favorite"] as? Bool ?? false
        explicitStartPos = -1
        updateHeaderInfo()
        subtitleCues.removeAll()
        subtitleName = ""
        subtitleLabel.isHidden = true
        let item = AVPlayerItem(asset: AVURLAsset(url: url))
        item.preferredForwardBufferDuration = 2
        player?.replaceCurrentItem(with: item)
        if keepPagePreviewUntilReady { waitForNewVideoFrame() }
        hasReachedEnd = false
        let posKey = "vpos_" + (videoName.isEmpty ? String(videoUrl.hashValue) : videoName)
        let savedPos = UserDefaults.standard.integer(forKey: posKey)
        if savedPos > 5000 {
            player?.seek(to: CMTime(seconds: Double(savedPos) / 1000, preferredTimescale: 600),
                         toleranceBefore: .zero, toleranceAfter: .zero)
        }
        fetchRemoteWatchProgress()
        player?.play()
        isPlaying = true
        updatePlayPauseButton()
        updateFavoriteButton()
        autoLoadMatchingSubtitle()
        prefetchAdjacentPageThumbnails()
        syncFilmstrip(animated: true)
        showToast("Đang phát \(videoName)")
        if remainCompact { showControls() } else { hideControls() }
    }

    private func autoLoadMatchingSubtitle() {
        let base = (videoName as NSString).deletingPathExtension.lowercased()
        if let candidate = subtitleCandidates.first(where: { (($0["name"] ?? "") as NSString).deletingPathExtension.lowercased() == base }),
           let name = candidate["name"], let url = candidate["url"] {
            loadSubtitle(name: name, urlString: url)
        }
    }

    private func loadSubtitle(name: String, urlString: String) {
        guard let url = URL(string: urlString) else { showToast("Địa chỉ phụ đề không hợp lệ"); return }
        URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let self else { return }
            let text = data.flatMap { String(data: $0, encoding: .utf8) ?? String(data: $0, encoding: .unicode) }
            DispatchQueue.main.async {
                guard error == nil, let text else { self.showToast("Không tải được phụ đề"); return }
                let parsed = self.parseSubtitle(text)
                guard !parsed.isEmpty else { self.showToast("Phụ đề không có dòng hợp lệ"); return }
                self.subtitleCues = parsed
                self.subtitleName = name
                self.subtitleOffset = 0
                self.showToast("Đã thêm phụ đề \(name)")
            }
        }.resume()
    }

    private func parseSubtitle(_ raw: String) -> [(start: Double, end: Double, text: String)] {
        let normalized = raw.replacingOccurrences(of: "\r\n", with: "\n").replacingOccurrences(of: "\r", with: "\n")
        let blocks = normalized.components(separatedBy: "\n\n")
        var cues: [(Double, Double, String)] = []
        for block in blocks {
            let lines = block.components(separatedBy: "\n").filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
            guard let timingIndex = lines.firstIndex(where: { $0.contains("-->") }) else { continue }
            let times = lines[timingIndex].components(separatedBy: "-->")
            guard times.count == 2, let start = subtitleTime(times[0]), let end = subtitleTime(times[1]) else { continue }
            let value = lines.dropFirst(timingIndex + 1).joined(separator: "\n")
                .replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
                .trimmingCharacters(in: .whitespacesAndNewlines)
            if !value.isEmpty { cues.append((start, end, value)) }
        }
        return cues
    }

    private func subtitleTime(_ value: String) -> Double? {
        let clean = value.trimmingCharacters(in: .whitespaces).components(separatedBy: .whitespaces).first ?? value
        let parts = clean.replacingOccurrences(of: ",", with: ".").split(separator: ":").compactMap { Double($0) }
        if parts.count == 3 { return parts[0] * 3600 + parts[1] * 60 + parts[2] }
        if parts.count == 2 { return parts[0] * 60 + parts[1] }
        return nil
    }

    @objc private func onCloseTapped() {
        dismiss(animated: true)
    }

    // MARK: - Helpers
    private func onTimeUpdate(time: CMTime) {
        guard !isSeeking, let p = player else { return }
        let current = CMTimeGetSeconds(time)
        if Date().timeIntervalSince(lastWatchProgressSentAt) >= 15 { saveCurrentPosition() }
        currentTimeLabel.text = formatTime(seconds: current)
        if subtitleCues.isEmpty { subtitleLabel.isHidden = true }
        else {
            let adjusted = current - subtitleOffset
            if let cue = subtitleCues.first(where: { adjusted >= $0.start && adjusted <= $0.end }) { subtitleLabel.text = "  \(cue.text)  "; subtitleLabel.isHidden = false }
            else { subtitleLabel.isHidden = true }
        }

        if let dur = p.currentItem?.duration {
            let total = CMTimeGetSeconds(dur)
            if !total.isNaN && total > 0 {
                durationLabel.text = formatTime(seconds: total)
                seekSlider.value = Float(current / total)
            }
        }
    }

    @objc private func playerItemDidReachEnd(_ notification: Notification) {
        guard let endedItem = notification.object as? AVPlayerItem,
              endedItem === player?.currentItem else { return }
        hasReachedEnd = true
        isPlaying = false
        updatePlayPauseButton()
        showControls()
        hideTimer?.invalidate()
    }

    private func updatePlayPauseButton() {
        let symbol = hasReachedEnd ? "arrow.counterclockwise.circle.fill" : (isPlaying ? "pause.fill" : "play.fill")
        playPauseBtn.setImage(UIImage(systemName: symbol), for: .normal)
    }

    private func showControls() {
        let needsConstraintSwap = !controlsVisible
        controlsVisible = true
        hideTimer?.invalidate()
        topBar.isHidden = false
        bottomBar.isHidden = false
        playPauseBtn.isHidden = false
        toolBar.isHidden = false
        filmstrip.isHidden = false
        if needsConstraintSwap {
            NSLayoutConstraint.deactivate(fullMediaConstraints)
            NSLayoutConstraint.activate(compactMediaConstraints)
        }
        view.bringSubviewToFront(playPauseBtn)
        UIView.animate(withDuration: 0.24) {
            self.topBar.alpha = 1
            self.bottomBar.alpha = 1
            self.playPauseBtn.alpha = 1
            self.toolBar.alpha = 1
            self.filmstrip.alpha = 1
            self.view.layoutIfNeeded()
            self.playerLayer?.frame = self.mediaContainer.bounds
            self.setNeedsStatusBarAppearanceUpdate()
        }
    }

    private func hideControls() {
        let needsConstraintSwap = controlsVisible
        controlsVisible = false
        hideTimer?.invalidate()
        if needsConstraintSwap {
            NSLayoutConstraint.deactivate(compactMediaConstraints)
            NSLayoutConstraint.activate(fullMediaConstraints)
        }
        UIView.animate(withDuration: 0.24, animations: {
            self.topBar.alpha = 0
            self.bottomBar.alpha = 0
            self.playPauseBtn.alpha = 0
            self.toolBar.alpha = 0
            self.filmstrip.alpha = 0
            self.view.layoutIfNeeded()
            self.playerLayer?.frame = self.mediaContainer.bounds
            self.setNeedsStatusBarAppearanceUpdate()
        }) { _ in
            if !self.controlsVisible {
                self.topBar.isHidden = true
                self.bottomBar.isHidden = true
                self.playPauseBtn.isHidden = true
                self.toolBar.isHidden = true
                self.filmstrip.isHidden = true
            }
        }
    }

    private func scheduleHide() {
        hideTimer?.invalidate()
        hideTimer = nil
    }

    private func showToast(_ text: String) {
        toastLabel.text = "  \(text)  "
        toastLabel.sizeToFit()
        UIView.animate(withDuration: 0.2) {
            self.toastLabel.alpha = 1
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) {
            UIView.animate(withDuration: 0.3) {
                self.toastLabel.alpha = 0
            }
        }
    }

    private func formatTime(seconds: Double) -> String {
        guard !seconds.isNaN && !seconds.isInfinite else { return "00:00" }
        let total = Int(seconds)
        let h = total / 3600
        let m = (total % 3600) / 60
        let s = total % 60
        if h > 0 {
            return String(format: "%d:%02d:%02d", h, m, s)
        }
        return String(format: "%02d:%02d", m, s)
    }
}

fileprivate final class VideoFilmstripCell: UICollectionViewCell {
    static let reuseIdentifier = "VideoFilmstripCell"
    private let imageView = UIImageView()
    private let placeholder = UIImageView(image: UIImage(systemName: "play.rectangle.fill"))
    private let playBadge = UIImageView(image: UIImage(systemName: "play.fill"))
    fileprivate var representedIndex = -1

    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = UIColor.white.withAlphaComponent(0.08)
        contentView.layer.cornerRadius = 5
        contentView.layer.masksToBounds = true
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.translatesAutoresizingMaskIntoConstraints = false
        placeholder.contentMode = .scaleAspectFit
        placeholder.tintColor = UIColor.white.withAlphaComponent(0.42)
        placeholder.translatesAutoresizingMaskIntoConstraints = false
        playBadge.contentMode = .scaleAspectFit
        playBadge.tintColor = .white
        playBadge.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        playBadge.layer.cornerRadius = 8
        playBadge.layer.masksToBounds = true
        playBadge.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(imageView)
        contentView.addSubview(placeholder)
        contentView.addSubview(playBadge)
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: contentView.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            imageView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            placeholder.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            placeholder.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            placeholder.widthAnchor.constraint(equalToConstant: 20),
            placeholder.heightAnchor.constraint(equalToConstant: 20),
            playBadge.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 3),
            playBadge.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -3),
            playBadge.widthAnchor.constraint(equalToConstant: 16),
            playBadge.heightAnchor.constraint(equalToConstant: 16)
        ])
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func prepareForReuse() {
        super.prepareForReuse()
        representedIndex = -1
        imageView.image = nil
        placeholder.isHidden = false
        contentView.layer.borderWidth = 0
    }

    fileprivate func prepare(index: Int, selected: Bool) {
        representedIndex = index
        imageView.image = nil
        placeholder.isHidden = false
        contentView.layer.borderColor = UIColor.white.cgColor
        contentView.layer.borderWidth = selected ? 2.5 : 0
    }

    fileprivate func apply(image: UIImage, index: Int) {
        guard representedIndex == index else { return }
        imageView.image = image
        placeholder.isHidden = true
    }
}
