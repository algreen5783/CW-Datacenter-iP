import Foundation
import CryptoKit
import ImageIO

class LocalProxy {
    static let shared = LocalProxy()
    private static let maximumThumbnailCacheBytes: Int64 = 500 * 1024 * 1024

    private var serverSocket: Int32 = -1
    private(set) var port: Int = 0
    private var isRunning = false
    private let queue = DispatchQueue(label: "com.cw.datacenter.proxy", qos: .userInitiated, attributes: .concurrent)
    private let thumbnailCacheQueue = DispatchQueue(label: "com.cw.datacenter.thumbnail-cache", qos: .userInitiated)
    private let authLock = NSLock()
    private var upstreamSession = URLSession(configuration: .default)

    private(set) var baseUrl: String = ""
    private(set) var token: String = ""

    static func decodedImage(_ data: Data, maxPixelSize: Int) -> CGImage? {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              CGImageSourceGetStatus(source) == .statusComplete else { return nil }
        return CGImageSourceCreateThumbnailAtIndex(source, 0, [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixelSize,
            kCGImageSourceShouldCacheImmediately: true
        ] as CFDictionary)
    }

    static func jpegThumbnail(from file: URL, size: Int) -> Data? {
        guard let source = CGImageSourceCreateWithURL(file as CFURL, nil),
              CGImageSourceGetStatus(source) == .statusComplete,
              let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceThumbnailMaxPixelSize: size,
                kCGImageSourceShouldCacheImmediately: true
              ] as CFDictionary) else { return nil }
        let data = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(data, "public.jpeg" as CFString, 1, nil) else { return nil }
        CGImageDestinationAddImage(destination, image, [kCGImageDestinationLossyCompressionQuality: 0.75] as CFDictionary)
        guard CGImageDestinationFinalize(destination) else { return nil }
        return data as Data
    }

    private func thumbnailCacheDirectory() -> URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        let directory = base.appendingPathComponent("thumbnail_cache", isDirectory: true)
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        var excludedDirectory = directory
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        try? excludedDirectory.setResourceValues(values)
        return directory
    }

    private func thumbnailCacheKey(baseUrl: String, rel: String, pool: String?, size: Int, revision: String) -> String {
        let raw = "\(baseUrl):\(pool ?? "main"):\(rel):\(size):\(revision)"
        return SHA256.hash(data: Data(raw.utf8)).map { String(format: "%02x", $0) }.joined()
    }

    private func cachedThumbnail(key: String) -> Data? {
        thumbnailCacheQueue.sync {
            let file = thumbnailCacheDirectory().appendingPathComponent(key + ".jpg")
            guard let data = try? Data(contentsOf: file), !data.isEmpty else { return nil }
            guard Self.decodedImage(data, maxPixelSize: 512) != nil else {
                try? FileManager.default.removeItem(at: file)
                return nil
            }
            try? FileManager.default.setAttributes([.modificationDate: Date()], ofItemAtPath: file.path)
            return data
        }
    }

    private func storeThumbnail(_ data: Data, key: String) {
        guard Self.decodedImage(data, maxPixelSize: 512) != nil else { return }
        thumbnailCacheQueue.async { [weak self] in
            guard let self = self else { return }
            let file = self.thumbnailCacheDirectory().appendingPathComponent(key + ".jpg")
            try? data.write(to: file, options: .atomic)
            self.trimThumbnailCache()
        }
    }

    private func trimThumbnailCache() {
        let directory = thumbnailCacheDirectory()
        let keys: Set<URLResourceKey> = [.isRegularFileKey, .fileSizeKey, .contentModificationDateKey]
        guard let files = try? FileManager.default.contentsOfDirectory(at: directory,
            includingPropertiesForKeys: Array(keys), options: [.skipsHiddenFiles]) else { return }
        var rows: [(url: URL, size: Int64, date: Date)] = []
        var total: Int64 = 0
        for file in files where file.pathExtension.lowercased() == "jpg" {
            guard let values = try? file.resourceValues(forKeys: keys), values.isRegularFile == true else { continue }
            let size = Int64(values.fileSize ?? 0)
            total += size
            rows.append((file, size, values.contentModificationDate ?? .distantPast))
        }
        guard total > Self.maximumThumbnailCacheBytes else { return }
        for row in rows.sorted(by: { $0.date < $1.date }) {
            if total <= Self.maximumThumbnailCacheBytes { break }
            if (try? FileManager.default.removeItem(at: row.url)) != nil { total -= row.size }
        }
    }

    func clearThumbnailCache() {
        thumbnailCacheQueue.sync {
            let directory = thumbnailCacheDirectory()
            try? FileManager.default.removeItem(at: directory)
            try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        }
    }

    private func sendThumbnail(_ socket: Int32, data: Data, method: String) {
        defer { close(socket) }
        let header = "HTTP/1.1 200 OK\r\nContent-Type: image/jpeg\r\nContent-Length: \(data.count)\r\nCache-Control: public, max-age=31536000, immutable\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n"
        guard sendAll(socket, data: Data(header.utf8)) else { return }
        if method != "HEAD" { _ = sendAll(socket, data: data) }
    }

    private func recoverHEICThumbnail(socket: Int32, upstream: (baseUrl: String, token: String, session: URLSession),
                                      rel: String, pool: String?, size: Int, key: String, method: String) {
        guard var components = URLComponents(string: upstream.baseUrl + "/api/file") else {
            Self.sendError(socket, status: 502, msg: "Invalid Host URL"); close(socket); return
        }
        // No preview=1: let Image I/O decode the original HEIC on the phone.
        components.queryItems = [URLQueryItem(name: "path", value: rel), URLQueryItem(name: "pool", value: pool ?? "main")]
        guard let url = components.url else { Self.sendError(socket, status: 502, msg: "Invalid image URL"); close(socket); return }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 120)
        if !upstream.token.isEmpty { request.setValue("Bearer " + upstream.token, forHTTPHeaderField: "Authorization") }
        // Download to disk so even a large HEIC does not accumulate in RAM.
        upstream.session.downloadTask(with: request) { [weak self] file, response, error in
            guard let self = self else { close(socket); return }
            let status = (response as? HTTPURLResponse)?.statusCode ?? 502
            guard error == nil, status == 200, let file = file,
                  let data = Self.jpegThumbnail(from: file, size: size) else {
                Self.sendError(socket, status: [401, 403, 423].contains(status) ? status : 503, msg: "Thumbnail unavailable")
                close(socket)
                return
            }
            self.storeThumbnail(data, key: key)
            self.sendThumbnail(socket, data: data, method: method)
        }.resume()
    }

    private func isTailscaleAddress(_ host: String?) -> Bool {
        guard let host = host, !host.isEmpty else { return false }
        let octets = host.split(separator: ".").compactMap { Int($0) }
        return octets.count == 4 && octets[0] == 100 && (64...127).contains(octets[1])
    }

    private func makeUpstreamSession(baseUrl: String) -> URLSession {
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 30
        configuration.timeoutIntervalForResource = 60
        configuration.requestCachePolicy = .useProtocolCachePolicy
        configuration.waitsForConnectivity = false
        configuration.allowsCellularAccess = true
        configuration.allowsExpensiveNetworkAccess = true
        configuration.allowsConstrainedNetworkAccess = true
        configuration.httpShouldUsePipelining = true
        configuration.httpMaximumConnectionsPerHost = 10
        configuration.urlCache = URLCache(memoryCapacity: 32 * 1024 * 1024, diskCapacity: 256 * 1024 * 1024)
        if isTailscaleAddress(URL(string: baseUrl)?.host) {
            configuration.connectionProxyDictionary = [:]
        }
        return URLSession(configuration: configuration)
    }

    private func upstreamSnapshot() -> (baseUrl: String, token: String, session: URLSession) {
        authLock.lock()
        defer { authLock.unlock() }
        return (baseUrl, token, upstreamSession)
    }

    func setAuth(baseUrl: String, token: String) {
        let normalizedBaseUrl = baseUrl.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        authLock.lock()
        let hostChanged = self.baseUrl != normalizedBaseUrl
        let previousSession = hostChanged ? upstreamSession : nil
        self.baseUrl = normalizedBaseUrl
        self.token = token
        if hostChanged {
            upstreamSession = makeUpstreamSession(baseUrl: normalizedBaseUrl)
        }
        authLock.unlock()
        previousSession?.finishTasksAndInvalidate()
        AppLogger.shared.log(.debug, category: "PROXY", "setAuth host=\(baseUrl); authenticated=\(!token.isEmpty)")
        if !isRunning {
            start()
        }
    }

    func start() {
        guard !isRunning else { return }
        isRunning = true

        var addr = sockaddr_in()
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_port = in_port_t(0) // random port
        addr.sin_addr.s_addr = inet_addr("127.0.0.1")

        let sock = socket(AF_INET, SOCK_STREAM, 0)
        guard sock >= 0 else {
            AppLogger.shared.log(.error, category: "PROXY", "Không tạo được local socket")
            isRunning = false
            return
        }

        var yes: Int32 = 1
        setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &yes, socklen_t(MemoryLayout<Int32>.size))

        let bindRes = withUnsafePointer(to: &addr) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                bind(sock, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        guard bindRes == 0 else {
            AppLogger.shared.log(.error, category: "PROXY", "Không bind được local socket; errno=\(errno)")
            close(sock)
            isRunning = false
            return
        }

        listen(sock, 64)
        serverSocket = sock

        var assignedAddr = sockaddr_in()
        var len = socklen_t(MemoryLayout<sockaddr_in>.size)
        _ = withUnsafeMutablePointer(to: &assignedAddr) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                getsockname(sock, $0, &len)
            }
        }
        port = Int(UInt16(bigEndian: assignedAddr.sin_port))
        AppLogger.shared.log(.info, category: "PROXY", "Local proxy chạy tại 127.0.0.1:\(port)")

        queue.async { [weak self] in
            self?.acceptLoop()
        }
    }

    func stop() {
        isRunning = false
        if serverSocket >= 0 {
            close(serverSocket)
            serverSocket = -1
        }
        port = 0
    }

    func urlFor(relEncoded: String, poolEncoded: String?, video: Bool) -> String {
        guard port > 0 else { return "" }
        var u = "http://127.0.0.1:\(port)/play?path=\(relEncoded)"
        if let p = poolEncoded, !p.isEmpty { u += "&pool=\(p)" }
        if video { u += "&video=1" }
        return u
    }

    func thumbUrl(relEncoded: String, poolEncoded: String?) -> String {
        guard port > 0 else { return "" }
        var u = "http://127.0.0.1:\(port)/play?path=\(relEncoded)&thumb=1&size=160"
        if let p = poolEncoded, !p.isEmpty { u += "&pool=\(p)" }
        return u
    }

    private func acceptLoop() {
        while isRunning && serverSocket >= 0 {
            var clientAddr = sockaddr_in()
            var clientLen = socklen_t(MemoryLayout<sockaddr_in>.size)
            let clientSock = withUnsafeMutablePointer(to: &clientAddr) {
                $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                    accept(serverSocket, $0, &clientLen)
                }
            }
            guard clientSock >= 0 else { continue }
            queue.async { [weak self] in
                self?.handleClient(clientSock)
            }
        }
    }

    private func handleClient(_ clientSock: Int32) {
        var closeWhenReturning = true
        defer { if closeWhenReturning { close(clientSock) } }

        var buffer = [UInt8](repeating: 0, count: 8192)
        let bytesRead = recv(clientSock, &buffer, buffer.count, 0)
        guard bytesRead > 0 else { return }

        guard let requestString = String(bytes: buffer.prefix(bytesRead), encoding: .utf8) else { return }
        let lines = requestString.components(separatedBy: "\r\n")
        guard let requestLine = lines.first else { return }
        let reqParts = requestLine.components(separatedBy: " ")
        guard reqParts.count >= 2 else { return }

        let method = reqParts[0].uppercased()
        let target = reqParts[1]

        var headers = [String: String]()
        for line in lines.dropFirst() {
            if line.isEmpty { break }
            let parts = line.split(separator: ":", maxSplits: 1).map(String.init)
            if parts.count == 2 {
                headers[parts[0].trimmingCharacters(in: .whitespaces).lowercased()] = parts[1].trimmingCharacters(in: .whitespaces)
            }
        }

        if method == "OPTIONS" {
            let res = "HTTP/1.1 204 No Content\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: Range, Authorization, Content-Type\r\nAccess-Control-Allow-Methods: GET, HEAD, OPTIONS\r\nConnection: close\r\n\r\n"
            _ = send(clientSock, res, res.utf8.count, 0)
            return
        }

        guard let urlComponents = URLComponents(string: "http://127.0.0.1" + target) else { return }
        let queryItems = urlComponents.queryItems ?? []
        let queryMap = Dictionary(queryItems.compactMap { item in item.value.map { (item.name, $0) } }, uniquingKeysWith: { first, _ in first })

        if urlComponents.path == "/local" {
            guard let spec = queryMap["spec"] else {
                sendError(clientSock, status: 400, msg: "Missing local file")
                return
            }
            serveLocalFile(clientSock, method: method, spec: spec, headers: headers)
            return
        }

        guard let rel = queryMap["path"] ?? queryMap["file"], !rel.isEmpty else {
            sendError(clientSock, status: 404, msg: "Not found")
            return
        }

        let isVideo = queryMap["video"] == "1"
        let isThumb = queryMap["thumb"] == "1"
        let thumbSize = min(512, max(80, Int(queryMap["size"] ?? "360") ?? 360))
        let pool = queryMap["pool"]
        let ss = queryMap["ss"]
        let revision = queryMap["rev"] ?? "0"
        let upstream = upstreamSnapshot()
        guard !upstream.baseUrl.isEmpty else {
            sendError(clientSock, status: 503, msg: "Host is not configured")
            return
        }
        let thumbKey = isThumb ? thumbnailCacheKey(baseUrl: upstream.baseUrl, rel: rel, pool: pool, size: thumbSize, revision: revision) : ""

        if isThumb, let cached = cachedThumbnail(key: thumbKey) {
            let header = "HTTP/1.1 200 OK\r\nContent-Type: image/jpeg\r\nContent-Length: \(cached.count)\r\nCache-Control: public, max-age=31536000, immutable\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n"
            guard sendAll(clientSock, data: Data(header.utf8)) else { return }
            if method != "HEAD" { _ = sendAll(clientSock, data: cached) }
            return
        }

        let endpoint = isVideo ? "/api/video" : (isThumb ? "/api/thumb" : "/api/file")
        guard var upstreamComponents = URLComponents(string: upstream.baseUrl + endpoint) else {
            sendError(clientSock, status: 400, msg: "Invalid URL")
            return
        }
        var upstreamItems = [URLQueryItem(name: "path", value: rel)]
        if isVideo {
            upstreamItems.insert(URLQueryItem(name: "raw", value: "1"), at: 0)
            if let ssVal = ss, !ssVal.isEmpty { upstreamItems.append(URLQueryItem(name: "ss", value: ssVal)) }
        } else if isThumb {
            upstreamItems.append(URLQueryItem(name: "size", value: String(thumbSize)))
        } else {
            upstreamItems.append(URLQueryItem(name: "preview", value: "1"))
        }
        if let p = pool, !p.isEmpty { upstreamItems.append(URLQueryItem(name: "pool", value: p)) }
        upstreamComponents.queryItems = upstreamItems
        guard let upstreamUrl = upstreamComponents.url else {
            sendError(clientSock, status: 400, msg: "Invalid URL")
            return
        }

        var req = URLRequest(url: upstreamUrl)
        req.httpMethod = method
        // Native disk cache is validated above. Do not replay an old invalid
        // HTTP cache entry after the web UI requests a thumbnail retry.
        if isThumb {
            req.httpMethod = "GET"
            req.cachePolicy = .reloadIgnoringLocalCacheData
            if queryMap["cw_retry"] != nil { req.setValue("no-cache", forHTTPHeaderField: "Cache-Control") }
        }
        if !upstream.token.isEmpty {
            req.setValue("Bearer " + upstream.token, forHTTPHeaderField: "Authorization")
        }
        if let rangeHeader = headers["range"] {
            req.setValue(rangeHeader, forHTTPHeaderField: "Range")
        }

        closeWhenReturning = false
        let task = upstream.session.dataTask(with: req) { data, response, error in
            if isThumb {
                let status = (response as? HTTPURLResponse)?.statusCode ?? 502
                if error == nil, status == 200, let data = data, Self.decodedImage(data, maxPixelSize: 512) != nil {
                    self.storeThumbnail(data, key: thumbKey)
                    self.sendThumbnail(clientSock, data: data, method: method)
                } else if ["heic", "heif"].contains((rel as NSString).pathExtension.lowercased()),
                          ![401, 403, 423].contains(status) {
                    self.recoverHEICThumbnail(socket: clientSock, upstream: upstream, rel: rel,
                                              pool: pool, size: thumbSize, key: thumbKey, method: method)
                } else {
                    LocalProxy.sendError(clientSock, status: [401, 403, 423].contains(status) ? status : 503, msg: "Thumbnail unavailable")
                    close(clientSock)
                }
                return
            }
            defer { close(clientSock) }
            if let error = error {
                AppLogger.shared.log(.warning, category: "PROXY", "Upstream \(upstreamUrl.path) lỗi: \(error.localizedDescription)")
            }
            guard let httpResponse = response as? HTTPURLResponse else {
                LocalProxy.sendError(clientSock, status: 502, msg: "Bad Gateway")
                return
            }

            var headerStr = "HTTP/1.1 \(httpResponse.statusCode) OK\r\n"
            if httpResponse.statusCode == 206 {
                headerStr = "HTTP/1.1 206 Partial Content\r\n"
            }
            headerStr += "Access-Control-Allow-Origin: *\r\n"
            headerStr += "Accept-Ranges: bytes\r\n"

            for (k, v) in httpResponse.allHeaderFields {
                let keyStr = String(describing: k)
                let valStr = String(describing: v)
                if ["content-type", "content-length", "content-range", "etag", "cache-control"].contains(keyStr.lowercased()) {
                    headerStr += "\(keyStr): \(valStr)\r\n"
                }
            }
            headerStr += "Connection: close\r\n\r\n"

            guard self.sendAll(clientSock, data: Data(headerStr.utf8)) else { return }
            if let d = data, method != "HEAD" {
                _ = self.sendAll(clientSock, data: d)
            }
        }
        task.resume()
    }

    private func serveLocalFile(_ sock: Int32, method: String, spec: String, headers: [String: String]) {
        guard let data = spec.data(using: .utf8),
              let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let rawPath = object["p"] as? String,
              !rawPath.isEmpty else {
            sendError(sock, status: 400, msg: "Invalid local file")
            return
        }

        let fileUrl = URL(fileURLWithPath: rawPath).standardizedFileURL
        let documentsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!.standardizedFileURL
        let allowedRoot = documentsUrl.path.hasSuffix("/") ? documentsUrl.path : documentsUrl.path + "/"
        guard fileUrl.path == documentsUrl.path || fileUrl.path.hasPrefix(allowedRoot) else {
            sendError(sock, status: 403, msg: "Local file is outside app storage")
            return
        }

        guard let attributes = try? FileManager.default.attributesOfItem(atPath: fileUrl.path),
              let number = attributes[.size] as? NSNumber else {
            sendError(sock, status: 404, msg: "Local file not found")
            return
        }

        let fileSize = number.uint64Value
        var start: UInt64 = 0
        var end = fileSize > 0 ? fileSize - 1 : 0
        var partial = false
        if let range = headers["range"], range.lowercased().hasPrefix("bytes=") {
            let value = String(range.dropFirst(6)).split(separator: ",", maxSplits: 1).first.map(String.init) ?? ""
            let pieces = value.split(separator: "-", maxSplits: 1, omittingEmptySubsequences: false)
            if let first = pieces.first, let requestedStart = UInt64(first), requestedStart < fileSize {
                start = requestedStart
                if pieces.count > 1, let requestedEnd = UInt64(pieces[1]) {
                    end = min(requestedEnd, fileSize - 1)
                }
                partial = true
            }
        }

        let length = fileSize == 0 ? 0 : end - start + 1
        let statusLine = partial ? "HTTP/1.1 206 Partial Content" : "HTTP/1.1 200 OK"
        var response = "\(statusLine)\r\n"
        response += "Content-Type: \(mimeType(for: fileUrl.pathExtension))\r\n"
        response += "Content-Length: \(length)\r\n"
        response += "Accept-Ranges: bytes\r\n"
        response += "Access-Control-Allow-Origin: *\r\n"
        if partial { response += "Content-Range: bytes \(start)-\(end)/\(fileSize)\r\n" }
        response += "Connection: close\r\n\r\n"
        guard sendAll(sock, data: Data(response.utf8)) else { return }
        guard method != "HEAD", length > 0, let handle = try? FileHandle(forReadingFrom: fileUrl) else { return }
        defer { try? handle.close() }
        try? handle.seek(toOffset: start)
        var remaining = length
        while remaining > 0 {
            let chunk = handle.readData(ofLength: Int(min(remaining, 256 * 1024)))
            if chunk.isEmpty || !sendAll(sock, data: chunk) { break }
            remaining -= UInt64(chunk.count)
        }
    }

    private func sendAll(_ sock: Int32, data: Data) -> Bool {
        if data.isEmpty { return true }
        return data.withUnsafeBytes { bytes in
            guard let base = bytes.baseAddress else { return false }
            var offset = 0
            while offset < data.count {
                let sent = send(sock, base.advanced(by: offset), data.count - offset, 0)
                if sent <= 0 { return false }
                offset += sent
            }
            return true
        }
    }

    private func mimeType(for ext: String) -> String {
        switch ext.lowercased() {
        case "mp3": return "audio/mpeg"
        case "m4a", "mp4": return "audio/mp4"
        case "aac": return "audio/aac"
        case "wav": return "audio/wav"
        case "flac": return "audio/flac"
        case "mov": return "video/quicktime"
        case "mkv": return "video/x-matroska"
        case "jpg", "jpeg": return "image/jpeg"
        case "png": return "image/png"
        default: return "application/octet-stream"
        }
    }

    private static func sendError(_ sock: Int32, status: Int, msg: String) {
        let body = msg.data(using: .utf8) ?? Data()
        let resp = "HTTP/1.1 \(status) Error\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: \(body.count)\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n\(msg)"
        _ = send(sock, resp, resp.utf8.count, 0)
    }

    private func sendError(_ sock: Int32, status: Int, msg: String) {
        LocalProxy.sendError(sock, status: status, msg: msg)
    }
}
