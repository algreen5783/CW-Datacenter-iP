# CW Datacenter iOS 1.6.50 (10650)

- Nhấn giữ ảnh/video trong Tổng quan đủ 2 giây để vào chế độ chọn nhiều.
- Hỗ trợ chọn thêm mục, chọn tất cả và mở lại bảng thao tác từ nút nổi.
- Các thao tác chọn nhiều gồm mở, tải về, chia sẻ link, thêm yêu thích và chuyển vào Thùng rác.
- Giữ nguyên trình xem Apple Photos, cache thumbnail bền vững 500 MB và cơ chế nạp thumbnail nền.
- Đồng bộ toàn bộ nhận diện phiên bản source, Web bundle, Xcode project và workflow build IPA lên 1.6.50 (10650).

