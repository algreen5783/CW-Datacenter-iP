# CW Datacenter iOS 1.6.46 (10646)

- Replaced the discrete video swipe with an interactive page transition matching the photo viewer.
- The current video follows the user's finger while the adjacent video is prepared and shown beside it with a narrow gap.
- Releasing after 25% of the screen width, or with a fast horizontal swipe, completes the page change; otherwise both pages slide back into place.
- Swipe left opens the next playlist video; swipe right opens the previous video.
- Vertical gestures no longer change brightness or volume, and horizontal dragging no longer seeks through the current video.
- Player controls remain fixed above the sliding video pages and continue to accept touches.
- Includes the password-lock corrections from iOS 1.6.44 and the corrected 1.6.45 Tailscale build validator.
