# CW Datacenter iOS 1.6.47 (10647)

- Raises the durable on-device thumbnail store to 500 MB and prunes the least recently used thumbnails only after that limit.
- Keeps thumbnails when the normal viewed-file cache is cleared; app removal/data removal still deletes them.
- Retains the interactive video paging and lock fixes from 1.6.46.
- Prevents left/right video paging crashes by locking the gesture direction and using a cached static thumbnail for the adjacent-page preview instead of repeatedly creating and destroying a second AVPlayer.
