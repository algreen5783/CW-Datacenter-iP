# CW Datacenter iOS 1.6.45 (10645)

- Replaced the video player's pan-based brightness, volume and horizontal seeking gestures with discrete left/right navigation gestures.
- Swipe left to open the next video in the same playlist; swipe right to open the previous video, matching the image viewer's paging direction.
- Adjacent navigation works whether the current video is playing, paused or finished.
- Switching videos saves the current watch position, updates the active playlist index, title, favorite state and watch-progress identity, then starts the selected video.
- Reaching either end of the playlist keeps the current video and displays a short boundary message.
- Kept the existing play/pause/replay control, scrubber, mute control, download, favorite, share and delete actions.
- Includes the password-lock corrections from iOS 1.6.44.
- Updated the Tailscale/source validation script to expect version 1.6.45 (10645), so GitHub Actions no longer stops before the Xcode build with “Wrong iOS version”.
