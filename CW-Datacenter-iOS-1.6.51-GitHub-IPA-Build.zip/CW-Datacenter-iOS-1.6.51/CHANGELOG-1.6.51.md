# CW Datacenter iOS 1.6.51

- Khắc phục các ô thumbnail thỉnh thoảng bị trắng cho tới khi khởi động lại app.
- Xác nhận thumbnail chỉ được đánh dấu đã sẵn sàng sau khi ảnh thật sự giải mã thành công.
- Tự thử lại thumbnail bị treo và tiếp tục tải đúng chỗ khi app quay lại foreground.
- Dừng tải thumbnail hàng loạt khi app ở background và giảm mức tải đồng thời để tránh áp lực bộ nhớ.
- Củng cố phát nhạc nền: giữ AudioSession, xử lý gián đoạn/reset dịch vụ âm thanh, tăng bộ đệm và tự phục hồi khi mạng bị khựng.

