import UIKit
import AVFoundation
import MediaPlayer

struct MusicTrack {
    let name: String
    let url: URL
    let size: Int64
    let headers: [String: String]
}

final class MusicPlaybackManager {
    static let shared = MusicPlaybackManager()
    static let changed = Notification.Name("CWMusicPlaybackChanged")

    private(set) var tracks: [MusicTrack] = []
    private(set) var index = 0
    private(set) var player: AVPlayer?
    private(set) var lastError: String?
    private var endObserver: NSObjectProtocol?
    private var failedObserver: NSObjectProtocol?
    private var stalledObserver: NSObjectProtocol?
    private var timeObserver: Any?
    private weak var timeObserverPlayer: AVPlayer?
    private var statusObservation: NSKeyValueObservation?
    private var remoteCommandsReady = false
    private var wantsAutoplay = true

    var current: MusicTrack? {
        guard tracks.indices.contains(index) else { return nil }
        return tracks[index]
    }
    var isPlaying: Bool { (player?.rate ?? 0) > 0 }
    var duration: Double {
        let value = player?.currentItem?.duration.seconds ?? 0
        return value.isFinite && value > 0 ? value : 0
    }
    var position: Double {
        let value = player?.currentTime().seconds ?? 0
        return value.isFinite && value > 0 ? value : 0
    }

    private init() {
        configureRemoteCommands()
    }

    deinit { removeObservers() }

    func load(_ newTracks: [MusicTrack], index requestedIndex: Int, autoplay: Bool = true) {
        guard Thread.isMainThread else {
            DispatchQueue.main.async { [weak self] in self?.load(newTracks, index: requestedIndex, autoplay: autoplay) }
            return
        }
        guard !newTracks.isEmpty else { return }
        tracks = newTracks
        index = max(0, min(requestedIndex, newTracks.count - 1))
        AppLogger.shared.log(.info, category: "MUSIC", "Mở playlist \(newTracks.count) bài; index=\(index); file=\(tracks[index].name)")
        loadCurrent(autoplay: autoplay)
    }

    func toggle() {
        guard Thread.isMainThread else { DispatchQueue.main.async { [weak self] in self?.toggle() }; return }
        guard let player else { return }
        if isPlaying {
            player.pause()
            AppLogger.shared.log(.info, category: "MUSIC", "Tạm dừng \(current?.name ?? "")")
        } else {
            configureAudioSession()
            player.play()
            AppLogger.shared.log(.info, category: "MUSIC", "Phát \(current?.name ?? "")")
        }
        publish()
    }

    func next() {
        guard Thread.isMainThread else { DispatchQueue.main.async { [weak self] in self?.next() }; return }
        guard !tracks.isEmpty else { return }
        index = index + 1 < tracks.count ? index + 1 : 0
        loadCurrent(autoplay: true)
    }

    func previous() {
        guard Thread.isMainThread else { DispatchQueue.main.async { [weak self] in self?.previous() }; return }
        if position > 4 { seek(to: 0); return }
        guard !tracks.isEmpty else { return }
        index = index > 0 ? index - 1 : tracks.count - 1
        loadCurrent(autoplay: true)
    }

    func seek(to seconds: Double) {
        guard Thread.isMainThread else { DispatchQueue.main.async { [weak self] in self?.seek(to: seconds) }; return }
        let target = max(0, min(duration > 0 ? duration : seconds, seconds))
        player?.seek(to: CMTime(seconds: target, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero)
        publish()
    }

    func close() {
        guard Thread.isMainThread else { DispatchQueue.main.async { [weak self] in self?.close() }; return }
        AppLogger.shared.log(.info, category: "MUSIC", "Đóng trình phát nhạc")
        removeObservers()
        player?.pause()
        player = nil
        tracks.removeAll()
        index = 0
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
        lastError = nil
        publish()
    }

    private func loadCurrent(autoplay: Bool) {
        guard let track = current else { return }
        removeObservers()
        configureAudioSession()
        lastError = nil
        wantsAutoplay = autoplay

        let asset: AVURLAsset
        if track.headers.isEmpty {
            asset = AVURLAsset(url: track.url)
        } else {
            asset = AVURLAsset(url: track.url, options: ["AVURLAssetHTTPHeaderFieldsKey": track.headers])
        }
        let item = AVPlayerItem(asset: asset)
        let newPlayer = AVPlayer(playerItem: item)
        newPlayer.automaticallyWaitsToMinimizeStalling = true
        player = newPlayer

        statusObservation = item.observe(\.status, options: [.initial, .new]) { [weak self, weak item] _, _ in
            DispatchQueue.main.async {
                guard let self = self, let item = item, self.player?.currentItem === item else { return }
                switch item.status {
                case .readyToPlay:
                    self.lastError = nil
                    AppLogger.shared.log(.info, category: "MUSIC", "Sẵn sàng phát \(track.name); duration=\(item.duration.seconds)")
                    if self.wantsAutoplay { self.player?.play() }
                case .failed:
                    let message = item.error?.localizedDescription ?? "AVPlayerItem không xác định"
                    self.lastError = message
                    AppLogger.shared.log(.error, category: "MUSIC", "Không phát được \(track.name): \(message)")
                case .unknown:
                    break
                @unknown default:
                    break
                }
                self.publish()
            }
        }
        endObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: item,
            queue: .main
        ) { [weak self] _ in self?.next() }
        failedObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemFailedToPlayToEndTime,
            object: item,
            queue: .main
        ) { [weak self] note in
            let error = (note.userInfo?[AVPlayerItemFailedToPlayToEndTimeErrorKey] as? Error)?.localizedDescription ?? "Không rõ lỗi"
            self?.lastError = error
            AppLogger.shared.log(.error, category: "MUSIC", "Phát bị dừng: \(track.name): \(error)")
            self?.publish()
        }
        stalledObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemPlaybackStalled,
            object: item,
            queue: .main
        ) { [weak self] _ in
            AppLogger.shared.log(.warning, category: "MUSIC", "Đang chờ dữ liệu mạng: \(track.name)")
            self?.publish()
        }
        timeObserverPlayer = newPlayer
        timeObserver = newPlayer.addPeriodicTimeObserver(
            forInterval: CMTime(seconds: 1, preferredTimescale: 10),
            queue: .main
        ) { [weak self] _ in self?.updateNowPlaying() }
        if autoplay { newPlayer.play() }
        updateNowPlaying()
        publish()
    }

    private func removeObservers() {
        statusObservation?.invalidate()
        statusObservation = nil
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        endObserver = nil
        if let failedObserver { NotificationCenter.default.removeObserver(failedObserver) }
        failedObserver = nil
        if let stalledObserver { NotificationCenter.default.removeObserver(stalledObserver) }
        stalledObserver = nil
        if let timeObserver, let observerPlayer = timeObserverPlayer { observerPlayer.removeTimeObserver(timeObserver) }
        timeObserver = nil
        timeObserverPlayer = nil
    }

    @discardableResult
    private func configureAudioSession() -> Bool {
        let session = AVAudioSession.sharedInstance()
        do {
            // AirPlay is implicit for .playback. Passing .allowAirPlay explicitly
            // is only valid with .playAndRecord and returns OSStatus -50 on iOS 18.
            try session.setCategory(.playback, mode: .default, options: [])
            try session.setActive(true)
            return true
        } catch {
            let nsError = error as NSError
            AppLogger.shared.log(.error, category: "MUSIC", "Không bật được AudioSession: domain=\(nsError.domain); code=\(nsError.code); \(nsError.localizedDescription)")
            return false
        }
    }

    private func configureRemoteCommands() {
        guard !remoteCommandsReady else { return }
        remoteCommandsReady = true
        let commands = MPRemoteCommandCenter.shared()
        commands.playCommand.addTarget { [weak self] _ in
            DispatchQueue.main.async { self?.player?.play(); self?.publish() }
            return .success
        }
        commands.pauseCommand.addTarget { [weak self] _ in
            DispatchQueue.main.async { self?.player?.pause(); self?.publish() }
            return .success
        }
        commands.togglePlayPauseCommand.addTarget { [weak self] _ in self?.toggle(); return .success }
        commands.nextTrackCommand.addTarget { [weak self] _ in self?.next(); return .success }
        commands.previousTrackCommand.addTarget { [weak self] _ in self?.previous(); return .success }
        commands.changePlaybackPositionCommand.addTarget { [weak self] event in
            guard let value = event as? MPChangePlaybackPositionCommandEvent else { return .commandFailed }
            self?.seek(to: value.positionTime)
            return .success
        }
    }

    private func updateNowPlaying() {
        guard let track = current else { return }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [
            MPMediaItemPropertyTitle: track.name,
            MPMediaItemPropertyArtist: "CW Datacenter",
            MPMediaItemPropertyPlaybackDuration: duration,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: position,
            MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? 1.0 : 0.0
        ]
    }

    private func publish() {
        updateNowPlaying()
        NotificationCenter.default.post(name: Self.changed, object: self)
    }
}

final class MiniMusicPlayerView: UIView {
    var onOpen: (() -> Void)?
    var onVisibilityChanged: ((Bool) -> Void)?

    private let titleButton = UIButton(type: .system)
    private let detailLabel = UILabel()
    private let previousButton = UIButton(type: .system)
    private let playButton = UIButton(type: .system)
    private let nextButton = UIButton(type: .system)
    private let closeButton = UIButton(type: .system)
    private let progress = UIProgressView(progressViewStyle: .bar)
    private var timer: Timer?
    private var observer: NSObjectProtocol?

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .systemBackground
        layer.cornerRadius = 16
        layer.borderWidth = 1
        layer.borderColor = UIColor.systemGray5.cgColor
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOpacity = 0.12
        layer.shadowRadius = 10
        layer.shadowOffset = CGSize(width: 0, height: 4)

        let art = UIImageView(image: UIImage(systemName: "music.note"))
        art.tintColor = .white
        art.contentMode = .center
        art.backgroundColor = UIColor(red: 0.12, green: 0.44, blue: 0.94, alpha: 1)
        art.layer.cornerRadius = 12

        titleButton.contentHorizontalAlignment = .leading
        titleButton.titleLabel?.font = .systemFont(ofSize: 14, weight: .semibold)
        titleButton.setTitleColor(.label, for: .normal)
        titleButton.titleLabel?.lineBreakMode = .byTruncatingTail
        titleButton.addTarget(self, action: #selector(openPlayer), for: .touchUpInside)
        detailLabel.font = .systemFont(ofSize: 11)
        detailLabel.textColor = .secondaryLabel

        [previousButton, playButton, nextButton, closeButton].forEach {
            $0.tintColor = .label
            $0.translatesAutoresizingMaskIntoConstraints = false
            addSubview($0)
        }
        previousButton.setImage(UIImage(systemName: "backward.end.fill"), for: .normal)
        playButton.setImage(UIImage(systemName: "play.fill"), for: .normal)
        nextButton.setImage(UIImage(systemName: "forward.end.fill"), for: .normal)
        closeButton.setImage(UIImage(systemName: "xmark"), for: .normal)
        playButton.tintColor = .white
        playButton.backgroundColor = UIColor(red: 0.12, green: 0.44, blue: 0.94, alpha: 1)
        playButton.layer.cornerRadius = 18
        previousButton.addTarget(self, action: #selector(handlePreviousTrack), for: .touchUpInside)
        playButton.addTarget(self, action: #selector(handleTogglePlayback), for: .touchUpInside)
        nextButton.addTarget(self, action: #selector(handleNextTrack), for: .touchUpInside)
        closeButton.addTarget(self, action: #selector(handleClosePlayer), for: .touchUpInside)

        [art, titleButton, detailLabel, progress].forEach { $0.translatesAutoresizingMaskIntoConstraints = false; addSubview($0) }
        NSLayoutConstraint.activate([
            art.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10), art.centerYAnchor.constraint(equalTo: centerYAnchor),
            art.widthAnchor.constraint(equalToConstant: 44), art.heightAnchor.constraint(equalToConstant: 44),
            closeButton.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -6), closeButton.centerYAnchor.constraint(equalTo: centerYAnchor),
            closeButton.widthAnchor.constraint(equalToConstant: 32), closeButton.heightAnchor.constraint(equalToConstant: 36),
            nextButton.trailingAnchor.constraint(equalTo: closeButton.leadingAnchor, constant: -2), nextButton.centerYAnchor.constraint(equalTo: centerYAnchor),
            nextButton.widthAnchor.constraint(equalToConstant: 34), nextButton.heightAnchor.constraint(equalToConstant: 36),
            playButton.trailingAnchor.constraint(equalTo: nextButton.leadingAnchor, constant: -5), playButton.centerYAnchor.constraint(equalTo: centerYAnchor),
            playButton.widthAnchor.constraint(equalToConstant: 36), playButton.heightAnchor.constraint(equalToConstant: 36),
            previousButton.trailingAnchor.constraint(equalTo: playButton.leadingAnchor, constant: -5), previousButton.centerYAnchor.constraint(equalTo: centerYAnchor),
            previousButton.widthAnchor.constraint(equalToConstant: 34), previousButton.heightAnchor.constraint(equalToConstant: 36),
            titleButton.leadingAnchor.constraint(equalTo: art.trailingAnchor, constant: 10),
            titleButton.trailingAnchor.constraint(equalTo: previousButton.leadingAnchor, constant: -6),
            titleButton.topAnchor.constraint(equalTo: topAnchor, constant: 9), titleButton.heightAnchor.constraint(equalToConstant: 23),
            detailLabel.leadingAnchor.constraint(equalTo: titleButton.leadingAnchor), detailLabel.trailingAnchor.constraint(equalTo: titleButton.trailingAnchor),
            detailLabel.topAnchor.constraint(equalTo: titleButton.bottomAnchor, constant: -1),
            progress.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12), progress.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),
            progress.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -1)
        ])
        observer = NotificationCenter.default.addObserver(forName: MusicPlaybackManager.changed, object: nil, queue: .main) { [weak self] _ in self?.refresh() }
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in self?.refresh() }
        refresh()
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    deinit { if let observer { NotificationCenter.default.removeObserver(observer) }; timer?.invalidate() }

    private func refresh() {
        let manager = MusicPlaybackManager.shared
        let shouldShow = manager.current != nil
        if isHidden == shouldShow { isHidden = !shouldShow; onVisibilityChanged?(shouldShow) }
        guard let track = manager.current else { return }
        titleButton.setTitle(track.name, for: .normal)
        detailLabel.text = manager.lastError.map { "Lỗi: \($0)" } ?? "\(manager.index + 1) / \(manager.tracks.count) · CW Datacenter"
        detailLabel.textColor = manager.lastError == nil ? .secondaryLabel : .systemRed
        playButton.setImage(UIImage(systemName: manager.isPlaying ? "pause.fill" : "play.fill"), for: .normal)
        progress.progress = manager.duration > 0 ? Float(manager.position / manager.duration) : 0
    }

    @objc private func openPlayer() { onOpen?() }
    @objc private func handlePreviousTrack() { MusicPlaybackManager.shared.previous() }
    @objc private func handleTogglePlayback() { MusicPlaybackManager.shared.toggle() }
    @objc private func handleNextTrack() { MusicPlaybackManager.shared.next() }
    @objc private func handleClosePlayer() { MusicPlaybackManager.shared.close() }
}

final class MusicPlayerViewController: UIViewController {
    private let titleLabel = UILabel()
    private let detailLabel = UILabel()
    private let slider = UISlider()
    private let elapsedLabel = UILabel()
    private let durationLabel = UILabel()
    private let playButton = UIButton(type: .system)
    private var timer: Timer?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.035, green: 0.055, blue: 0.095, alpha: 1)
        buildUI()
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in self?.refresh() }
        refresh()
    }
    deinit { timer?.invalidate() }

    private func buildUI() {
        let close = button("chevron.down", #selector(handleDismissPlayer))
        let art = UIImageView(image: UIImage(systemName: "music.note"))
        art.tintColor = .white
        art.contentMode = .center
        art.preferredSymbolConfiguration = UIImage.SymbolConfiguration(pointSize: 72, weight: .medium)
        art.backgroundColor = UIColor(red: 0.11, green: 0.35, blue: 0.82, alpha: 1)
        art.layer.cornerRadius = 28
        titleLabel.font = .systemFont(ofSize: 23, weight: .bold); titleLabel.textColor = .white; titleLabel.textAlignment = .center
        detailLabel.font = .systemFont(ofSize: 14); detailLabel.textColor = UIColor.white.withAlphaComponent(0.62); detailLabel.textAlignment = .center
        elapsedLabel.textColor = .white; durationLabel.textColor = .white
        elapsedLabel.font = .monospacedDigitSystemFont(ofSize: 12, weight: .regular); durationLabel.font = elapsedLabel.font
        slider.minimumTrackTintColor = UIColor(red: 0.16, green: 0.49, blue: 1, alpha: 1)
        slider.maximumTrackTintColor = UIColor.white.withAlphaComponent(0.2)
        slider.addTarget(self, action: #selector(handleSeek), for: .valueChanged)
        let previous = button("backward.end.fill", #selector(handlePreviousTrack))
        let next = button("forward.end.fill", #selector(handleNextTrack))
        playButton.setImage(UIImage(systemName: "play.fill"), for: .normal); playButton.tintColor = .white
        playButton.backgroundColor = UIColor(red: 0.16, green: 0.49, blue: 1, alpha: 1); playButton.layer.cornerRadius = 34
        playButton.addTarget(self, action: #selector(handleTogglePlayback), for: .touchUpInside)

        [close, art, titleLabel, detailLabel, slider, elapsedLabel, durationLabel, previous, playButton, next].forEach { $0.translatesAutoresizingMaskIntoConstraints = false; view.addSubview($0) }
        NSLayoutConstraint.activate([
            close.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 18), close.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 12), close.widthAnchor.constraint(equalToConstant: 42), close.heightAnchor.constraint(equalToConstant: 42),
            art.centerXAnchor.constraint(equalTo: view.centerXAnchor), art.topAnchor.constraint(equalTo: close.bottomAnchor, constant: 34),
            art.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.72), art.heightAnchor.constraint(equalTo: art.widthAnchor),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 28), titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -28), titleLabel.topAnchor.constraint(equalTo: art.bottomAnchor, constant: 30),
            detailLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor), detailLabel.trailingAnchor.constraint(equalTo: titleLabel.trailingAnchor), detailLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 7),
            slider.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 28), slider.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -28), slider.topAnchor.constraint(equalTo: detailLabel.bottomAnchor, constant: 30),
            elapsedLabel.leadingAnchor.constraint(equalTo: slider.leadingAnchor), elapsedLabel.topAnchor.constraint(equalTo: slider.bottomAnchor, constant: 3),
            durationLabel.trailingAnchor.constraint(equalTo: slider.trailingAnchor), durationLabel.topAnchor.constraint(equalTo: elapsedLabel.topAnchor),
            playButton.centerXAnchor.constraint(equalTo: view.centerXAnchor), playButton.topAnchor.constraint(equalTo: elapsedLabel.bottomAnchor, constant: 32), playButton.widthAnchor.constraint(equalToConstant: 68), playButton.heightAnchor.constraint(equalToConstant: 68),
            previous.trailingAnchor.constraint(equalTo: playButton.leadingAnchor, constant: -38), previous.centerYAnchor.constraint(equalTo: playButton.centerYAnchor), previous.widthAnchor.constraint(equalToConstant: 48), previous.heightAnchor.constraint(equalToConstant: 48),
            next.leadingAnchor.constraint(equalTo: playButton.trailingAnchor, constant: 38), next.centerYAnchor.constraint(equalTo: playButton.centerYAnchor), next.widthAnchor.constraint(equalToConstant: 48), next.heightAnchor.constraint(equalToConstant: 48)
        ])
    }

    private func button(_ symbol: String, _ action: Selector) -> UIButton {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: symbol), for: .normal)
        button.tintColor = .white
        button.addTarget(self, action: action, for: .touchUpInside)
        return button
    }

    private func refresh() {
        let manager = MusicPlaybackManager.shared
        guard let track = manager.current else { dismiss(animated: true); return }
        titleLabel.text = track.name
        detailLabel.text = manager.lastError.map { "Không phát được: \($0)" } ?? "\(manager.index + 1) / \(manager.tracks.count) · CW Datacenter"
        detailLabel.textColor = manager.lastError == nil ? UIColor.white.withAlphaComponent(0.62) : .systemRed
        playButton.setImage(UIImage(systemName: manager.isPlaying ? "pause.fill" : "play.fill"), for: .normal)
        slider.value = manager.duration > 0 ? Float(manager.position / manager.duration) : 0
        elapsedLabel.text = time(manager.position); durationLabel.text = time(manager.duration)
    }

    private func time(_ seconds: Double) -> String {
        let value = max(0, Int(seconds)); return String(format: "%02d:%02d", value / 60, value % 60)
    }
    @objc private func handleDismissPlayer() { dismiss(animated: true) }
    @objc private func handlePreviousTrack() { MusicPlaybackManager.shared.previous(); refresh() }
    @objc private func handleTogglePlayback() { MusicPlaybackManager.shared.toggle(); refresh() }
    @objc private func handleNextTrack() { MusicPlaybackManager.shared.next(); refresh() }
    @objc private func handleSeek() { MusicPlaybackManager.shared.seek(to: Double(slider.value) * MusicPlaybackManager.shared.duration) }
}
